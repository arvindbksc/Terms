﻿Imports com.nss.DBAccess
Imports System.Data
Imports System.Text
Partial Class Data_TransactionLog
    Inherits System.Web.UI.Page

#Region "Properties"

    Property ProcessID() As Integer
        Get
            Return ViewState("ProcessID")
        End Get
        Set(ByVal value As Integer)
            ViewState("ProcessID") = value
            Session("ProcessID") = value
        End Set
    End Property
    Property Campaigntype() As Integer
        Get
            Return ViewState("Campaigntype")
        End Get
        Set(ByVal value As Integer)
            ViewState("Campaigntype") = value
            'Session("ProcessID") = value
        End Set
    End Property
    Property ReportType() As Integer
        Get
            Return ViewState("ReportType")
        End Get
        Set(ByVal value As Integer)
            ViewState("ReportType") = value
        End Set
    End Property
    Property CampaignID() As Integer
        Get
            Return ViewState("CampaignID")
        End Get
        Set(ByVal value As Integer)
            ViewState("CampaignID") = value
        End Set
    End Property

    Property AgentID() As String
        Get
            Return ViewState("AgentID")
        End Get
        Set(ByVal value As String)
            ViewState("AgentID") = value
        End Set
    End Property

    Property dtHour() As DataTable
        Get
            Return ViewState("dtHour")
        End Get
        Set(ByVal value As DataTable)
            ViewState("dtHour") = value
        End Set
    End Property

    Property dtMin() As DataTable
        Get
            Return ViewState("dtMin")
        End Get
        Set(ByVal value As DataTable)
            ViewState("dtMin") = value
        End Set
    End Property

    Property startday() As Integer
        Get
            Return ViewState("startday")
        End Get
        Set(ByVal value As Integer)
            ViewState("startday") = value
        End Set
    End Property
    Property endday() As Integer
        Get
            Return ViewState("endday")
        End Get
        Set(ByVal value As Integer)
            ViewState("endday") = value
        End Set
    End Property

#End Region

#Region "Load Data"
    Private Sub LoadData()
        FillCommonFilters()
        FillProcessCampaigns()
        'PopulateAgents()
        FillHourMin()
    End Sub
#End Region

#Region "Load Functions"

    Private Sub FillCommonFilters()
        Try
            Dim db As New DBAccess
            Dim dt As DataTable = db.ReturnTable("select * from tbl_Reports_DatePeriods")
            db = Nothing
            Dim dr As DataRow = dt.NewRow
            dr(0) = 10
            dr(1) = "Between"
            dt.Rows.Add(dr)
            CboPeriod.DataTextField = "Caption"
            CboPeriod.DataValueField = "Period"
            CboPeriod.DataSource = dt
            CboPeriod.DataBind()
        Catch ex As Exception
            Throw ex
        End Try
    End Sub

    Private Sub FillProcessCampaigns()
        Try
            Common.FillProcessCampaigns(CboProcess, cboCampaigns, AgentID, CampaignID)
            Dim lstCamp As New ListItem
            lstCamp.Value = 0
            lstCamp.Text = "All"
            If cboCampaigns.Items.Contains(lstCamp) Then
                cboCampaigns.Items.Remove(lstCamp)
            End If
        Catch ex As Exception
            Throw ex
        End Try
    End Sub

    Private Sub FillHourMin()
        Try
            Dim colHour As DataColumn = New DataColumn("Hour", System.Type.GetType("System.String"))
            If dtHour Is Nothing Then
                dtHour = New DataTable
                If Not dtHour.Columns.Contains("Hour") Then
                    dtHour.Columns.Add(colHour)

                    Dim rowHour As DataRow '= dtHour.NewRow
                    For i As Integer = 0 To 23
                        rowHour = dtHour.NewRow
                        If i < 10 Then
                            rowHour("Hour") = "0" & i.ToString
                        Else
                            rowHour("Hour") = i.ToString
                        End If
                        dtHour.Rows.Add(rowHour)
                    Next

                End If
            End If
            '-----------------------------------------------------------------------------------------------------
            Dim colMin As DataColumn = New DataColumn("Min", System.Type.GetType("System.String"))
            If dtMin Is Nothing Then
                dtMin = New DataTable
                If Not dtMin.Columns.Contains("Min") Then
                    dtMin.Columns.Add(colMin)

                    Dim rowMin As DataRow '= dtMin.NewRow
                    For i As Integer = 0 To 59
                        rowMin = dtMin.NewRow
                        If i < 10 Then
                            rowMin("Min") = "0" & i.ToString
                        Else
                            rowMin("Min") = i.ToString
                        End If
                        dtMin.Rows.Add(rowMin)
                    Next
                End If
            End If
        Catch ex As Exception
            Throw ex
        End Try
    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Try
            HumanMessage.Style.Item("visibility") = "hidden"
            If Not IsPostBack Then
                ReportType = Request.QueryString("ReportType")
                If Session("AgentID") <> "" Then
                    ucDateFrom.value = DateTime.Now  'to initialise time

                    ' CampaignID = Session("CampaignID")
                    AgentID = Session("AgentID")
                    PanelReports.Controls.Add(Common.GetMenu(Request.Url, AgentID, Request.ApplicationPath))
                    LoadData()
                    fillgrid()
                    UcDateTo.Visible = False
                    ucDateFrom.Visible = False
                    lblAnd.Visible = False
                End If
            Else
                'gvDataTimeSlot.EditIndex = -1
                fillgrid()
            End If

        Catch ex As Exception
            AlertMessage(ex.Message)
        End Try
    End Sub

    Dim TIdle As Integer = 0
    Dim TTrans As Integer = 0
    Private Sub fillgrid()
        Try
            Dim db As DBAccess
            If CboPeriod.SelectedValue = 10 Then
                startday = ucDateFrom.yyyymmdd
                endday = UcDateTo.yyyymmdd
            Else
                db = New DBAccess
                db.slDataAdd("Period", CboPeriod.SelectedValue)
                db.slDataAdd("Campaignid", CampaignID)
                Dim dr As DataRow = db.ReturnRow("usp_GetStart_EndDateForAPeriod", True)
                db = Nothing
                startday = dr(0)
                endday = dr(1)
            End If

            'Dim dt As DataTable
            'db.slDataAdd("startday", ucDateFrom.yyyymmdd)
            'db.slDataAdd("campaignid", CampaignID)
            'dt = db.ReturnTable("usp_getOrionTimeSlotData", , True)
            'db = Nothing

            Dim dt As DataTable
            db = New DBAccess
            db.slDataAdd("startday", startday)
            db.slDataAdd("endDay", endday)
            db.slDataAdd("campaignid", CampaignID)
            dt = db.ReturnTable("usp_getOrionTimeSlotData", , True)
            db = Nothing

            lblReportName.Text = "Break Time Slot "
            LblError.Text = "Between " & IntegerToDateString(startday) & "  and " & IntegerToDateString(endday) & " for " & cboCampaigns.SelectedItem.Text & " campaign"

            If dt.Rows.Count > 0 Then
                gvDataTimeSlot.DataSource = dt
                gvDataTimeSlot.DataBind()
                dt = Nothing
            Else
                If CboPeriod.SelectedValue <> 0 Then  'not today i.e. yesterday'
                    gvDataTimeSlot.DataSource = Nothing
                    gvDataTimeSlot.DataBind()

                ElseIf CboPeriod.SelectedValue = 0 Then
                    Dim dtVain As DataTable = New DataTable

                    Dim col1 As DataColumn = New DataColumn("SlotID", System.Type.GetType("System.String"))
                    Dim col2 As DataColumn = New DataColumn("Slot", System.Type.GetType("System.String"))

                    Dim col3 As DataColumn = New DataColumn("StartDay", System.Type.GetType("System.String"))
                    Dim col4 As DataColumn = New DataColumn("StartTimeHour", System.Type.GetType("System.String"))
                    Dim col5 As DataColumn = New DataColumn("StartTimeMin", System.Type.GetType("System.String"))

                    Dim col14 As DataColumn = New DataColumn("EndDay", System.Type.GetType("System.String"))
                    Dim col6 As DataColumn = New DataColumn("EndTimeHour", System.Type.GetType("System.String"))
                    Dim col7 As DataColumn = New DataColumn("EndTimeMin", System.Type.GetType("System.String"))

                    Dim col8 As DataColumn = New DataColumn("btSubmit", System.Type.GetType("System.String"))
                    Dim col9 As DataColumn = New DataColumn("btFreeze", System.Type.GetType("System.String"))
                    Dim col10 As DataColumn = New DataColumn("StartTime", System.Type.GetType("System.String"))
                    Dim col11 As DataColumn = New DataColumn("EndTime", System.Type.GetType("System.String"))

                    Dim col12 As DataColumn = New DataColumn("Break Duration", System.Type.GetType("System.String"))
                    Dim col13 As DataColumn = New DataColumn("isDeleted", System.Type.GetType("System.String"))

                    dtVain.Columns.Add(col1)
                    dtVain.Columns.Add(col2)

                    dtVain.Columns.Add(col3)
                    dtVain.Columns.Add(col4)
                    dtVain.Columns.Add(col5)

                    dtVain.Columns.Add(col14)
                    dtVain.Columns.Add(col6)
                    dtVain.Columns.Add(col7)

                    dtVain.Columns.Add(col8)
                    dtVain.Columns.Add(col9)
                    dtVain.Columns.Add(col10)
                    dtVain.Columns.Add(col11)

                    dtVain.Columns.Add(col12)
                    dtVain.Columns.Add(col13)

                    dtVain.Rows.Add(String.Empty, String.Empty, String.Empty, String.Empty, String.Empty, String.Empty, String.Empty, String.Empty, String.Empty, String.Empty, String.Empty, String.Empty, String.Empty, String.Empty)

                    gvDataTimeSlot.DataSource = dtVain
                    gvDataTimeSlot.DataBind()

                    gvDataTimeSlot.Rows(0).Visible = False
                End If
                ' ScriptManager.RegisterStartupScript(Me, Me.GetType(), "SortGrid", "$(function(){{$('#" & gvDataTimeSlot.ClientID & "').tablesorter({cancelSelection:true}); }});", True)
            End If

        Catch ex As Exception
            Throw ex
        End Try
    End Sub
#End Region

#Region "Events"
    Protected Sub cboCampaigns_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboCampaigns.SelectedIndexChanged
        Try
            CampaignID = cboCampaigns.SelectedValue
            'PopulateAgents()
            fillgrid()
        Catch ex As Exception
            AlertMessage(ex.Message)
        End Try
    End Sub

    Protected Sub CboPeriod_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles CboPeriod.SelectedIndexChanged
        Try
            If CboPeriod.SelectedValue = 10 Then
                ucDateFrom.Visible = True
                UcDateTo.Visible = True
                lblAnd.Visible = True
                fillgrid()
            Else
                ucDateFrom.Visible = False
                UcDateTo.Visible = False
                lblAnd.Visible = False
                fillgrid()
            End If
        Catch ex As Exception
            AlertMessage(ex.Message)
        End Try
    End Sub

    'Protected Sub ImageButton1_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton1.Click
    '    Try
    '        fillgrid()
    '        GridViewExportUtil.Export(lblReportName.Text & "-" & LblError.Text & ".xls", Me.gvDataTimeSlot)
    '    Catch ex As Exception
    '        AlertMessage(ex.Message)
    '    End Try
    'End Sub
    'Protected Sub btnFilter_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnFilter.Click
    '    fillgrid()

    'End Sub
    Protected Sub btnRefresh_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnRefresh.Click
        Try
            fillgrid()
        Catch ex As Exception
            AlertMessage(ex.Message)
        End Try
    End Sub

    Protected Sub imgfav_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles imgfav.Click
        Try
            Common.AddToFav(AgentID, "Break Adherence TimeSlot")
            SuccessMessage("Report has been added to your favourite list")
            fillgrid()
        Catch ex As Exception
            AlertMessage(ex.Message)
        End Try
    End Sub

    Protected Sub gvDataTimeSlot_RowCommand(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewCommandEventArgs) Handles gvDataTimeSlot.RowCommand
        Try
            If e.CommandName.ToLower = "addnew" Then
                Dim SlotName As String = CType(gvDataTimeSlot.FooterRow.FindControl("txtSlotFooter"), TextBox).Text
                Dim StartTimeHour As Integer = CType(gvDataTimeSlot.FooterRow.FindControl("gvddlHourStartTimeFooter"), DropDownList).SelectedValue
                Dim StartTimeMin As Integer = CType(gvDataTimeSlot.FooterRow.FindControl("gvddlMinStartTimeFooter"), DropDownList).SelectedValue
                Dim EndTimeHour As Integer = CType(gvDataTimeSlot.FooterRow.FindControl("gvddlHourEndTimeFooter"), DropDownList).SelectedValue
                Dim EndTimeMin As Integer = CType(gvDataTimeSlot.FooterRow.FindControl("gvddlMinEndTimeFooter"), DropDownList).SelectedValue

                If validation(SlotName, StartTimeHour, StartTimeMin, EndTimeHour, EndTimeMin, -1) = True Then
                    Dim db As DBAccess = New DBAccess("report")
                    db.slDataAdd("mode", "INSERT")

                    db.slDataAdd("CampaignID", CampaignID)
                    db.slDataAdd("SlotName", SlotName)
                    '  db.slDataAdd("Day", ucDateFrom.yyyymmdd)

                    db.slDataAdd("StartTimeHour", StartTimeHour)
                    db.slDataAdd("StartTimeMin", StartTimeMin)
                    db.slDataAdd("EndTimeHour", EndTimeHour)
                    db.slDataAdd("EndTimeMin", EndTimeMin)
                    'db.slDataAdd("btSubmit", 1)
                    'db.slDataAdd("btFreeze", 1)
                    db.Executeproc("usp_InserUpdateOrionTimeSlotData")
                    db = Nothing
                    fillgrid()
                End If

                ' Dim abc2 As String = "hi333"
            ElseIf e.CommandName.ToLower = "update" Then
                'Dim index As Integer = Convert.ToInt32(e.CommandArgument)

                'Dim db As DBAccess = New DBAccess("report")
                'db.slDataAdd("mode", "UPDATE")
                'db.slDataAdd("SlotID", CType(gvDataTimeSlot.Rows(index).FindControl("hdfSlotID"), HiddenField).Value)
                'db.slDataAdd("SlotName", CType(gvDataTimeSlot.Rows(index).FindControl("txtSlot"), TextBox).Text)
                'db.slDataAdd("CampaignID", CampaignID)
                '' db.slDataAdd("Day", Day)

                'db.slDataAdd("StartTimeHour", CType(gvDataTimeSlot.Rows(index).FindControl("gvddlHourStartTime"), DropDownList).SelectedValue)
                'db.slDataAdd("StartTimeMin", CType(gvDataTimeSlot.Rows(index).FindControl("gvddlMinStartTime"), DropDownList).SelectedValue)
                'db.slDataAdd("EndTimeHour", CType(gvDataTimeSlot.Rows(index).FindControl("gvddlHourEndTime"), DropDownList).SelectedValue)
                'db.slDataAdd("EndTimeMin", CType(gvDataTimeSlot.Rows(index).FindControl("gvddlMinEndTime"), DropDownList).SelectedValue)

                ''db.slDataAdd("btSubmit", btSubmit)
                ''db.slDataAdd("btFreeze", btFreeze)

                'db.Executeproc("usp_InserUpdateOrionTimeSlotData")
                'db = Nothing

                'gvDataTimeSlot.EditIndex = -1
                'fillgrid()
            End If
        Catch ex As Exception
            AlertMessage(ex.Message)
        End Try
    End Sub

    Protected Sub gvDataTimeSlot_RowDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles gvDataTimeSlot.RowDataBound
        Try
            If e.Row.RowType = DataControlRowType.Header Then  'for header
                If CboPeriod.SelectedValue <> 0 Then   ''''i.e. not equal to today  i.e. if e.g. yesterday
                    e.Row.Cells(5).Visible = False  'to hide the Delete/Edit Buttons
                End If

            ElseIf e.Row.RowType = DataControlRowType.DataRow Then
                If CboPeriod.SelectedValue <> 0 Then   ''''i.e. not equal to today i.e. if e.g. yesterday
                    e.Row.Cells(5).Visible = False    'to hide the Delete/Edit Buttons

                    CType(e.Row.FindControl("gvlblStartTime"), Label).Visible = True
                    CType(e.Row.FindControl("gvlblEndTime"), Label).Visible = True

                    CType(e.Row.FindControl("gvLblHourStartTime"), Label).Visible = False
                    CType(e.Row.FindControl("gvLblHourStartTime_Hour"), Label).Visible = False
                    CType(e.Row.FindControl("gvLblMinStartTime"), Label).Visible = False
                    CType(e.Row.FindControl("gvLblMinStartTime_Min"), Label).Visible = False

                    CType(e.Row.FindControl("gvLblHourEndTime"), Label).Visible = False
                    CType(e.Row.FindControl("gvLblHourEndTime_Hour"), Label).Visible = False
                    CType(e.Row.FindControl("gvLblMinEndTime"), Label).Visible = False
                    CType(e.Row.FindControl("gvLblMinEndTime_Min"), Label).Visible = False

                ElseIf CboPeriod.SelectedValue = 0 Then  ''''for today

                    CType(e.Row.FindControl("gvlblStartTime"), Label).Visible = False
                    CType(e.Row.FindControl("gvlblEndTime"), Label).Visible = False

                    '    CType(e.Row.FindControl("gvLblHourStartTime"), Label).Visible = True
                    '    CType(e.Row.FindControl("gvLblHourStartTime_Hour"), Label).Visible = True
                    '    CType(e.Row.FindControl("gvLblMinStartTime"), Label).Visible = True
                    '    CType(e.Row.FindControl("gvLblMinStartTime_Min"), Label).Visible = True

                    '    CType(e.Row.FindControl("gvLblHourEndTime"), Label).Visible = True
                    '    CType(e.Row.FindControl("gvLblHourEndTime_Hour"), Label).Visible = True
                    '    CType(e.Row.FindControl("gvLblMinEndTime"), Label).Visible = True
                    '    CType(e.Row.FindControl("gvLblMinEndTime_Min"), Label).Visible = True

                End If
                ''''Start Time
                Dim gvddlHourStartTime As DropDownList = CType(e.Row.FindControl("gvddlHourStartTime"), DropDownList)
                Dim gvddlMinStartTime As DropDownList = CType(e.Row.FindControl("gvddlMinStartTime"), DropDownList)

                If Not gvddlHourStartTime Is Nothing Then
                    gvddlHourStartTime.DataTextField = "Hour"
                    gvddlHourStartTime.DataValueField = "Hour"
                    gvddlHourStartTime.DataSource = dtHour
                    gvddlHourStartTime.DataBind()
                    gvddlHourStartTime.SelectedValue = IIf(CType(e.Row.FindControl("gvHdfHourStartTime"), HiddenField).Value < 10, "0" & CType(e.Row.FindControl("gvHdfHourStartTime"), HiddenField).Value.ToString, CType(e.Row.FindControl("gvHdfHourStartTime"), HiddenField).Value)
                End If

                If Not gvddlMinStartTime Is Nothing Then
                    gvddlMinStartTime.DataTextField = "Min"
                    gvddlMinStartTime.DataValueField = "Min"
                    gvddlMinStartTime.DataSource = dtMin
                    gvddlMinStartTime.DataBind()
                    gvddlMinStartTime.SelectedValue = IIf(CType(e.Row.FindControl("gvHdfMinStartTime"), HiddenField).Value < 10, "0" & CType(e.Row.FindControl("gvHdfMinStartTime"), HiddenField).Value.ToString, CType(e.Row.FindControl("gvHdfMinStartTime"), HiddenField).Value)
                End If

                ''''End Time
                Dim gvddlHourEndTime As DropDownList = CType(e.Row.FindControl("gvddlHourEndTime"), DropDownList)
                Dim gvddlMinEndTime As DropDownList = CType(e.Row.FindControl("gvddlMinEndTime"), DropDownList)


                If Not gvddlHourEndTime Is Nothing Then
                    gvddlHourEndTime.DataTextField = "Hour"
                    gvddlHourEndTime.DataValueField = "Hour"
                    gvddlHourEndTime.DataSource = dtHour
                    gvddlHourEndTime.DataBind()
                    gvddlHourEndTime.SelectedValue = IIf(CType(e.Row.FindControl("gvHdfHourEndTime"), HiddenField).Value < 10, "0" & CType(e.Row.FindControl("gvHdfHourEndTime"), HiddenField).Value.ToString, CType(e.Row.FindControl("gvHdfHourEndTime"), HiddenField).Value)
                End If

                If Not gvddlMinEndTime Is Nothing Then
                    gvddlMinEndTime.DataTextField = "Min"
                    gvddlMinEndTime.DataValueField = "Min"
                    gvddlMinEndTime.DataSource = dtMin
                    gvddlMinEndTime.DataBind()
                    gvddlMinEndTime.SelectedValue = IIf(CType(e.Row.FindControl("gvHdfMinEndTime"), HiddenField).Value < 10, "0" & CType(e.Row.FindControl("gvHdfMinEndTime"), HiddenField).Value.ToString, CType(e.Row.FindControl("gvHdfMinEndTime"), HiddenField).Value)
                End If


            ElseIf e.Row.RowType = DataControlRowType.Footer Then
                If CboPeriod.SelectedValue <> 0 Then   ''''i.e. not equal to today
                    e.Row.Visible = False
                ElseIf CboPeriod.SelectedValue = 0 Then   ''''here opposite i.e. Equal to today
                    e.Row.Visible = True

                    ''''Start Time
                    Dim gvddlHourStartTimeFooter As DropDownList = CType(e.Row.FindControl("gvddlHourStartTimeFooter"), DropDownList)
                    Dim gvddlMinStartTimeFooter As DropDownList = CType(e.Row.FindControl("gvddlMinStartTimeFooter"), DropDownList)

                    gvddlHourStartTimeFooter.DataTextField = "Hour"
                    gvddlHourStartTimeFooter.DataValueField = "Hour"
                    gvddlHourStartTimeFooter.DataSource = dtHour
                    gvddlHourStartTimeFooter.DataBind()

                    gvddlMinStartTimeFooter.DataTextField = "Min"
                    gvddlMinStartTimeFooter.DataValueField = "Min"
                    gvddlMinStartTimeFooter.DataSource = dtMin
                    gvddlMinStartTimeFooter.DataBind()

                    ''''End Time
                    Dim gvddlHourEndTimeFooter As DropDownList = CType(e.Row.FindControl("gvddlHourEndTimeFooter"), DropDownList)
                    Dim gvddlMinEndTimeFooter As DropDownList = CType(e.Row.FindControl("gvddlMinEndTimeFooter"), DropDownList)

                    gvddlHourEndTimeFooter.DataTextField = "Hour"
                    gvddlHourEndTimeFooter.DataValueField = "Hour"
                    gvddlHourEndTimeFooter.DataSource = dtHour
                    gvddlHourEndTimeFooter.DataBind()

                    gvddlMinEndTimeFooter.DataTextField = "Min"
                    gvddlMinEndTimeFooter.DataValueField = "Min"
                    gvddlMinEndTimeFooter.DataSource = dtMin
                    gvddlMinEndTimeFooter.DataBind()
                End If

                'ElseIf e.Row.RowType = DataControlRowType.EmptyDataRow Then
                '    Dim a As String = "abc"

            End If
        Catch ex As Exception
            AlertMessage(ex.Message & "T")
        End Try
    End Sub

    Protected Sub gvDataTimeSlot_RowDeleting(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewDeleteEventArgs) Handles gvDataTimeSlot.RowDeleting
        Try
            Dim db As DBAccess = New DBAccess("report")
            db.slDataAdd("CampaignID", CampaignID)
            db.slDataAdd("SlotID", CType(gvDataTimeSlot.Rows(e.RowIndex).FindControl("hdfSlotID"), HiddenField).Value)
            db.slDataAdd("mode", "DELETE")
            db.Executeproc("usp_InserUpdateOrionTimeSlotData")
            db = Nothing

            fillgrid()
        Catch ex As Exception
            AlertMessage(ex.Message)
        End Try
    End Sub

    Protected Sub gvDataTimeSlot_RowEditing(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewEditEventArgs) Handles gvDataTimeSlot.RowEditing
        Try
            gvDataTimeSlot.EditIndex = e.NewEditIndex
            fillgrid()
        Catch ex As Exception
            AlertMessage(ex.Message)
        End Try
    End Sub

    Protected Sub gvDataTimeSlot_RowUpdating(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewUpdateEventArgs) Handles gvDataTimeSlot.RowUpdating
        Try
            Dim SlotName As String = CType(gvDataTimeSlot.Rows(e.RowIndex).FindControl("txtSlot"), TextBox).Text
            Dim StartTimeHour As Integer = CType(gvDataTimeSlot.Rows(e.RowIndex).FindControl("gvddlHourStartTime"), DropDownList).SelectedValue
            Dim StartTimeMin As Integer = CType(gvDataTimeSlot.Rows(e.RowIndex).FindControl("gvddlMinStartTime"), DropDownList).SelectedValue
            Dim EndTimeHour As Integer = CType(gvDataTimeSlot.Rows(e.RowIndex).FindControl("gvddlHourEndTime"), DropDownList).SelectedValue
            Dim EndTimeMin As Integer = CType(gvDataTimeSlot.Rows(e.RowIndex).FindControl("gvddlMinEndTime"), DropDownList).SelectedValue


            If validation(SlotName, StartTimeHour, StartTimeMin, EndTimeHour, EndTimeMin, e.RowIndex) = True Then
                Dim db As DBAccess = New DBAccess("report")
                db.slDataAdd("mode", "UPDATE")
                db.slDataAdd("SlotID", CType(gvDataTimeSlot.Rows(e.RowIndex).FindControl("hdfSlotID"), HiddenField).Value)
                db.slDataAdd("SlotName", SlotName)
                db.slDataAdd("CampaignID", CampaignID)
                ' db.slDataAdd("Day", Day)

                db.slDataAdd("StartTimeHour", StartTimeHour)
                db.slDataAdd("StartTimeMin", StartTimeMin)
                db.slDataAdd("EndTimeHour", EndTimeHour)
                db.slDataAdd("EndTimeMin", EndTimeMin)

                'db.slDataAdd("btSubmit", btSubmit)
                'db.slDataAdd("btFreeze", btFreeze)

                db.Executeproc("usp_InserUpdateOrionTimeSlotData")
                db = Nothing

                gvDataTimeSlot.EditIndex = -1
                fillgrid()
            End If
        Catch ex As Exception
            AlertMessage(ex.Message)
        End Try
    End Sub

    Protected Sub gvDataTimeSlot_RowCancelingEdit(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewCancelEditEventArgs) Handles gvDataTimeSlot.RowCancelingEdit
        Try
            gvDataTimeSlot.EditIndex = -1
            fillgrid()
        Catch ex As Exception
            AlertMessage(ex.Message)
        End Try
    End Sub

#End Region

#Region "Support Functions"
    Private Function IntegerToDateString(ByVal d As Integer) As String
        Try
            Return d.ToString.Substring(0, 4) & "-" & d.ToString.Substring(4, 2) & "-" & d.ToString.Substring(6, 2)
        Catch ex As Exception
            Throw ex
        End Try
    End Function

    Public Function TimeString(ByVal Seconds As Long) As String
        Try
            'if verbose = false, returns
            'something like
            '02:22.08
            'if true, returns
            '2 hours, 22 minutes, and 8 seconds

            Dim lHrs As Long
            Dim lMinutes As Long
            Dim lSeconds As Long

            lSeconds = Seconds

            lHrs = Int(lSeconds / 3600)
            lMinutes = (Int(lSeconds / 60)) - (lHrs * 60)
            lSeconds = Int(lSeconds Mod 60)

            If lSeconds = 60 Then
                lMinutes = lMinutes + 1
                lSeconds = 0
            End If

            If lMinutes = 60 Then
                lMinutes = 0
                lHrs = lHrs + 1
            End If

            TimeString = lHrs.ToString("####00") & ":" & _
            lMinutes.ToString("00") & ":" & _
             lSeconds.ToString("00")
        Catch ex As Exception
            Throw ex
        End Try
    End Function

    Private Function validation(ByVal SlotName As String, ByVal StartTimeHour As Integer, ByVal StartTimeMin As Integer, ByVal EndTimeHour As Integer, ByVal EndTimeMin As Integer, ByVal roIndex As Integer) As Boolean
        Try
            Dim flag As Boolean = True

            If SlotName = "" Then
                flag = False
                AlertMessage("The Slot cannot be blank.")
                Return flag
            End If

            If CboPeriod.SelectedValue = 0 Then  '''''only for today
                For Each row As GridViewRow In gvDataTimeSlot.Rows
                    If row.RowIndex <> roIndex Then   '' not for present index while updating and in "Add New" the roIndex is -1
                        If SlotName = CType(row.FindControl("lblSlot"), Label).Text Then
                            flag = False
                            AlertMessage("The same Slot name cannot be added again.")
                            Return flag
                        End If
                    End If
                Next
            End If
            ''---------------------------------------------------------------------
            If StartTimeHour > EndTimeHour Then  ''incorrect
                If StartTimeHour = 23 Then   ''i.e last hour exclude it
                    flag = True
                    Return flag
                Else  '''''any hour other than 23 then include it.
                    flag = False
                    AlertMessage("The Start Time cannot be greater than End Time.")
                    Return flag
                End If
            ElseIf StartTimeHour = EndTimeHour Then
                If StartTimeMin >= EndTimeMin Then
                    flag = False
                    AlertMessage("The Start Time cannot be greater\equal to End Time.")
                    Return flag
                End If
            Else  ''''  StartTimeHour < EndTimeHour
                ''''Do Nothing
            End If

            Return flag

        Catch ex As Exception
            Throw ex
        End Try
    End Function
#End Region

#Region "Utility"
    Private Sub AlertMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMFail"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub

    Private Sub SuccessMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMSuccess"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub

    'Protected Sub ImageButton1_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton1.Click
    '    'fillgrid()
    '    GridViewExportUtil.Export(lblReportName.CurrentPage & "-" & LblError.Text & ".xls", Me.GdAttendance)
    'End Sub
#End Region

End Class
