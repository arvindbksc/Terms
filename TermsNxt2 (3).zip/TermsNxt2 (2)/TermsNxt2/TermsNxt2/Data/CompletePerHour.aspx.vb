﻿Imports com.nss.DBAccess
Imports System.Data
Imports System.Text
Imports System.Data.SqlClient
Partial Class Data_CompletePerHour
    Inherits System.Web.UI.Page
    Dim footerval(23) As Double
    Dim breakCounter As Integer = 0

#Region "------Properties"

    Property ProcessID() As Integer
        Get
            Return ViewState("ProcessID")
        End Get
        Set(ByVal value As Integer)
            ViewState("ProcessID") = value
            Session("ProcessID") = value
        End Set
    End Property
    Property Campaigntype() As Integer
        Get
            Return ViewState("Campaigntype")
        End Get
        Set(ByVal value As Integer)
            ViewState("Campaigntype") = value
            'Session("ProcessID") = value
        End Set
    End Property
    Property Period() As Integer
        Get
            Return ViewState("Period")
        End Get
        Set(ByVal value As Integer)
            ViewState("Period") = value
            'Session("ProcessID") = value
        End Set
    End Property
    Property ReportType() As Integer
        Get
            Return ViewState("ReportType")
        End Get
        Set(ByVal value As Integer)
            ViewState("ReportType") = value
        End Set
    End Property
    Property CampaignID() As Integer
        Get
            Return ViewState("CampaignID")
        End Get
        Set(ByVal value As Integer)
            ViewState("CampaignID") = value
        End Set
    End Property

    Property AgentID() As String
        Get
            Return ViewState("AgentID")
        End Get
        Set(ByVal value As String)
            ViewState("AgentID") = value
        End Set
    End Property
#End Region

#Region " ----------Load-------"

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        HumanMessage.Style.Item("visibility") = "hidden"
        If Not IsPostBack Then
            ReportType = Request.QueryString("ReportType")
            If Session("AgentID") <> "" Then
                If Not Request.QueryString("Campaign") Is Nothing Then
                    Session("CampaignID") = Request.QueryString("Campaign")
                End If
                CampaignID = Session("CampaignID")
                AgentID = Session("AgentID")
                PanelReports.Controls.Add(Common.GetMenu(Request.Url, AgentID, Request.ApplicationPath))
                LoadData()
                FillSlot()

                Dim ddlSlotItem As New ListItem
                ddlSlotItem.Value = 0
                ddlSlotItem.Text = "ALL"
                If ddlCPH.Items.Contains(ddlSlotItem) Then
                    ddlCPH.SelectedValue = 0
                End If

                fillgrid()
                UcDateTo.Visible = False
                ucDateFrom.Visible = False
                lblAnd.Visible = False
            End If
        End If
    End Sub

    Private Sub LoadData()
        FillCommonFilters()
        FillProcessCampaigns()
        'FillSlot()
    End Sub

#End Region

#Region " -----------Events------"
    Protected Sub cboCampaigns_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboCampaigns.SelectedIndexChanged
        CampaignID = cboCampaigns.SelectedValue
        FillSlot()
        'TO set the Slot Item to "ALL"
        Dim ddlSlotItem As New ListItem
        ddlSlotItem.Value = 0
        ddlSlotItem.Text = "ALL"
        If ddlCPH.Items.Contains(ddlSlotItem) Then
            ddlCPH.SelectedValue = 0
        End If

        fillgrid()
        'Dim helper As GridViewHelper = New GridViewHelper(GridView1)
        'helper.RegisterGroup("Agents", True, True)
        'helper.ApplyGroupSort()
    End Sub

    Protected Sub GridView1_PreRender(ByVal sender As Object, ByVal e As System.EventArgs) Handles GridView1.PreRender
        If Not GridView1 Is Nothing Then
            If GridView1.HeaderRow Is Nothing Then
            Else
                GridView1.HeaderRow.TableSection = TableRowSection.TableHeader
                GridView1.FooterRow.TableSection = TableRowSection.TableFooter
            End If
        End If
    End Sub

    Protected Sub btnFilter_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnFilter.Click
        FillSlot()
        fillgrid()
    End Sub

    'Protected Sub btnRefresh_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnRefresh.Click
    '    FillSlot()

    '    'TO set the Slot Item to "ALL"
    '    Dim ddlSlotItem As New ListItem
    '    ddlSlotItem.Value = 0
    '    ddlSlotItem.Text = "ALL"
    '    If ddlCPH.Items.Contains(ddlSlotItem) Then
    '        ddlCPH.SelectedValue = 0
    '    End If

    '    fillgrid()
    'End Sub

    Protected Sub CboProcess_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles CboProcess.SelectedIndexChanged
        ProcessID = CboProcess.SelectedValue
        Common.FillCampaigns(cboCampaigns, AgentID, CboProcess.SelectedValue)
        CampaignID = cboCampaigns.SelectedValue
        FillSlot()
        fillgrid()
    End Sub

    Protected Sub CboPeriod_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles CboPeriod.SelectedIndexChanged
        If CboPeriod.SelectedValue = 10 Then
            ucDateFrom.Visible = True
            UcDateTo.Visible = True
            lblAnd.Visible = True
            FillSlot()

            'TO set the Slot Item to "ALL"
            Dim ddlSlotItem As New ListItem
            ddlSlotItem.Value = 0
            ddlSlotItem.Text = "ALL"
            If ddlCPH.Items.Contains(ddlSlotItem) Then
                ddlCPH.SelectedValue = 0
            End If

            fillgrid()
        Else
            ucDateFrom.Visible = False
            UcDateTo.Visible = False
            lblAnd.Visible = False
            FillSlot()
            'TO set the Slot Item to "ALL"
            Dim ddlSlotItem As New ListItem
            ddlSlotItem.Value = 0
            ddlSlotItem.Text = "ALL"
            If ddlCPH.Items.Contains(ddlSlotItem) Then
                ddlCPH.SelectedValue = 0
            End If

            fillgrid()
        End If
    End Sub

    Protected Sub imgfav_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles imgfav.Click
        Common.AddToFav(AgentID, "CPH Slot Summary")
        SuccessMessage("Report has been added to your favourite list")
        fillgrid()
    End Sub

    Protected Sub ddlCPH_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ddlCPH.SelectedIndexChanged
        fillgrid()
    End Sub

    Protected Sub rptSlot_ItemDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.RepeaterItemEventArgs) Handles rptSlot.ItemDataBound
        Dim dt As DataTable = Nothing

        Dim lblSlot As Label = e.Item.FindControl("lblSlotRange")
        ' Dim lblcampid As Label = e.Item.FindControl("lblcampid")
        Dim dgdata As GridView = e.Item.FindControl("gvSlotRange")
        '-------------------------------------------------------------------------
        '-------------------------------------------------------------------------
        Dim db As DBAccess 'or report
        Dim ds As DataSet
        'For Each obj In footerval
        '    obj = 0
        'Next
        ''Dim columns As String
        'Dim db As New DBAccess
        Dim startday As Integer, endday As Integer
        If CboPeriod.SelectedValue = 10 Then
            startday = ucDateFrom.yyyymmdd
            endday = UcDateTo.yyyymmdd
        Else
            db = New DBAccess
            db.slDataAdd("Period", CboPeriod.SelectedValue)
            db.slDataAdd("Campaignid", cboCampaigns.SelectedValue)
            Dim dr As DataRow = db.ReturnRow("usp_GetStart_EndDateForAPeriod", True)
            db = Nothing
            startday = dr(0)
            endday = dr(1)
        End If

        Dim SlotText As Integer = 0
        Dim Slot1 As Double = 0
        Dim Slot2 As Double = 0

        Dim var As String
        Dim varArray() As String
        Dim varFloat1 As Double
        Dim varFloat2 As Double

        If ddlCPH.Items.Count > 0 Then
            'If ddlCPH.SelectedItem.Text = "ALL" Then ' -- For "All"
            If lblSlot.Text = "ALL" Then ' -- For "All"
                SlotText = 0
                varFloat1 = 0
                varFloat2 = 0
            Else
                SlotText = 100
                'var = ddlCPH.SelectedValue
                var = lblSlot.Text
                varArray = var.Replace(" ", "").Split("-")
                varFloat1 = varArray(0)
                varFloat2 = varArray(1)
            End If
        End If

        db = New DBAccess
        db.slDataAdd("ProcessID", CboProcess.SelectedValue)
        db.slDataAdd("CampaignID", cboCampaigns.SelectedValue)
        db.slDataAdd("FromDate", startday)
        db.slDataAdd("ToDate", endday)
        db.slDataAdd("SLOTText", SlotText)
        db.slDataAdd("SLOT1", varFloat1)
        db.slDataAdd("SLOT2", varFloat2)

        ds = db.ReturnDataset("usp_getCPHSummary", True)

        ds.Tables(1).Columns.Remove("SlotRange")

        dgdata.DataSource = ds.Tables(1)
        dgdata.DataBind()

    End Sub

#End Region

#Region " -----------Functions------"
    Private Sub FillCommonFilters()
        Dim db As New DBAccess
        Dim dt As DataTable = db.ReturnTable("select * from tbl_Reports_DatePeriods")
        db = Nothing
        Dim dr As DataRow = dt.NewRow
        dr(0) = 10
        dr(1) = "Between"
        dt.Rows.Add(dr)
        CboPeriod.DataTextField = "Caption"
        CboPeriod.DataValueField = "Period"
        CboPeriod.DataSource = dt
        CboPeriod.DataBind()

        db = New DBAccess
        dt = db.ReturnTable("Select * from tbl_Reports_GroupBy")
        db = Nothing

        'Period = Request.QueryString("period")
        'CboPeriod.SelectedValue = Period
        CboPeriod.SelectedValue = 1

    End Sub

    Private Sub FillSlot()
        Try
            Dim db As New DBAccess
            Dim dr As DataRow

            Dim startday As Integer, endday As Integer
            If CboPeriod.SelectedValue = 10 Then
                startday = ucDateFrom.yyyymmdd
                endday = UcDateTo.yyyymmdd
            Else
                db = New DBAccess
                db.slDataAdd("Period", CboPeriod.SelectedValue)
                db.slDataAdd("Campaignid", cboCampaigns.SelectedValue)
                dr = db.ReturnRow("usp_GetStart_EndDateForAPeriod", True)
                db = Nothing
                startday = dr(0)
                endday = dr(1)
            End If

            db = New DBAccess
            db.slDataAdd("ProcessID", CboProcess.SelectedValue)
            db.slDataAdd("CampaignID", cboCampaigns.SelectedValue)
            db.slDataAdd("FromDate", startday)
            db.slDataAdd("ToDate", endday)
            ' db.slDataAdd("MODE", "SLOT")

            '  Dim dt As DataTable = db.ReturnTable("usp_getCPHSummary", , True)
            Dim dt As DataTable = db.ReturnTable("usp_getCPHSummary_Slot", , True)
            db = Nothing

            If dt.Rows.Count > 0 Then
                ddlCPH.Items.Clear()
                ddlCPH.DataSource = Nothing
                ddlCPH.DataBind()

                dr = dt.NewRow
                dr(0) = 0
                dr(1) = "ALL"
                dt.Rows.Add(dr)

                ddlCPH.DataSource = dt
                ddlCPH.DataTextField = "SLOTTEXT"
                ddlCPH.DataValueField = "SLOTVALUE"
                ddlCPH.DataBind()
                ddlCPH.SelectedIndex = -1
                'ddlCPH.SelectedIndex = 3
                'ddlCPH.SelectedValue = 0
            Else
                ddlCPH.DataSource = Nothing
                ddlCPH.DataBind()
            End If

        Catch ex As Exception
            AlertMessage(ex.Message)
        End Try

    End Sub

    Private Sub fillgrid()
        GridView1.DataSource = Nothing
        Dim db As DBAccess 'or report
        Dim ds As DataSet
        'For Each obj In footerval
        '    obj = 0
        'Next
        ''Dim columns As String
        'Dim db As New DBAccess
        Dim startday As Integer, endday As Integer
        If CboPeriod.SelectedValue = 10 Then
            startday = ucDateFrom.yyyymmdd
            endday = UcDateTo.yyyymmdd
        Else
            db = New DBAccess
            db.slDataAdd("Period", CboPeriod.SelectedValue)
            db.slDataAdd("Campaignid", cboCampaigns.SelectedValue)
            Dim dr As DataRow = db.ReturnRow("usp_GetStart_EndDateForAPeriod", True)
            db = Nothing
            startday = dr(0)
            endday = dr(1)
        End If

        Dim SlotText As Integer = 0
        Dim Slot1 As Double = 0
        Dim Slot2 As Double = 0

        Dim var As String
        Dim varArray() As String
        Dim varFloat1 As Double
        Dim varFloat2 As Double

        If ddlCPH.Items.Count > 0 Then
            If ddlCPH.SelectedItem.Text = "ALL" Then ' -- For "All"
                SlotText = 0
                varFloat1 = 0
                varFloat2 = 0
            Else
                SlotText = 100
                var = ddlCPH.SelectedValue
                varArray = var.Replace(" ", "").Split("-")
                varFloat1 = varArray(0)
                varFloat2 = varArray(1)
            End If
        End If

        db = New DBAccess
        db.slDataAdd("ProcessID", CboProcess.SelectedValue)
        db.slDataAdd("CampaignID", cboCampaigns.SelectedValue)
        db.slDataAdd("FromDate", startday)
        db.slDataAdd("ToDate", endday)
        db.slDataAdd("SLOTText", SlotText)
        db.slDataAdd("SLOT1", varFloat1)
        db.slDataAdd("SLOT2", varFloat2)

        ds = db.ReturnDataset("usp_getCPHSummary", True)
        'breadcrumbs.CurrentPage = " Date of joing Report "
        '& IntegerToDateString(startday) & "  and " & IntegerToDateString(endday)
        LblError.Text = ""
        LblError.Text = "for " & CboProcess.SelectedItem.Text
        db = Nothing

        If ds.Tables.Count > 0 Then
            GridView1.AutoGenerateColumns = True
            GridView1.DataSource = ds.Tables(0)
            GridView1.DataBind()

            'gvAgents.AutoGenerateColumns = True
            'gvAgents.DataSource = ds.Tables(1)
            'gvAgents.DataBind()

            Dim dtSlotDistinct As DataTable
            dtSlotDistinct = ds.Tables(1).DefaultView().ToTable(True, "SlotRange")

            rptSlot.DataSource = dtSlotDistinct
            rptSlot.DataBind()

        End If
        ds = Nothing

    End Sub

    Private Function IntegerToDateString(ByVal d As Integer) As String
        Return d.ToString.Substring(0, 4) & "-" & d.ToString.Substring(4, 2) & "-" & d.ToString.Substring(6, 2)
    End Function

    Private Sub CreateGridColumns(ByVal cols As DataColumnCollection)
        GridView1.Columns.Clear()
        Dim tempcolumn As TemplateField
        Dim bouncol As BoundField
        Dim objcol As DataColumn
        For Each objcol In cols
            If objcol.ColumnName = "Agents" Then
                tempcolumn = New TemplateField
                Dim tmpagcol As New TemplateAgentName
                tempcolumn.HeaderText = "Agents"
                tmpagcol.DataImageField = "AgentStatus"
                tmpagcol.DataTextField = objcol.ColumnName
                tempcolumn.ItemStyle.HorizontalAlign = HorizontalAlign.Left
                tempcolumn.ItemTemplate = tmpagcol
                GridView1.Columns.Add(tempcolumn)
            Else
                If objcol.ColumnName <> "Agentstatus" Then
                    bouncol = New BoundField
                    bouncol.HeaderText = objcol.ColumnName
                    bouncol.DataField = objcol.ColumnName

                    GridView1.Columns.Add(bouncol)
                End If
            End If
        Next
    End Sub

    Private Sub FillProcessCampaigns()
        Common.FillProcesses(CboProcess, AgentID)
        'Common.FillProcessCampaigns(CboProcess, cboCampaigns, AgentID, CampaignID)
        Dim lstprocess As New ListItem
        lstprocess.Value = 0
        lstprocess.Text = "All"
        If CboProcess.Items.Contains(lstprocess) Then
            CboProcess.Items.Remove(lstprocess)
        End If

        Dim db As New DBAccess
        db.slDataAdd("Agentid", AgentID)
        CboProcess.SelectedValue = db.ReturnRow("usp_getAgentProcess", True)(4)
        db = Nothing

        Dim lstOrion As New ListItem
        lstOrion.Value = 9
        lstOrion.Text = "Orion"
        If CboProcess.Items.Contains(lstOrion) Then
            CboProcess.SelectedValue = 9
        End If
        Common.FillCampaigns(cboCampaigns, AgentID, CboProcess.SelectedValue)

    End Sub

    Private Sub ExportToexcel()
        Dim tw As New IO.StringWriter()
        Dim hw As New System.Web.UI.HtmlTextWriter(tw)
        'Dim frm As HtmlForm = New HtmlForm()
        Response.ContentType = "application/vnd.ms-excel"
        Response.AddHeader("content-disposition", "attachment;filename=" & lblReportName.Text & "-" & LblError.Text & ".xls")
        Response.Charset = ""
        EnableViewState = False
        'Controls.Add(frm)
        GridView1.RenderControl(hw)
        Response.Write(tw.ToString())
        Response.End()
    End Sub

#End Region

#Region "----------Utility-----"
    Private Sub AlertMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMFail"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub

    Private Sub SuccessMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMSuccess"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub

#End Region

End Class
