﻿Imports com.nss.DBAccess
Imports System.Data
Imports System.Web.UI.DataVisualization.Charting
Imports System.Drawing

Partial Class PerfSum_GordonDashboard
    Inherits System.Web.UI.Page

#Region "--- Properties ---"
    'Property CampaignID() As Integer
    '    Get
    '        Return ViewState("CampaignID")
    '    End Get
    '    Set(ByVal value As Integer)
    '        ViewState("CampaignID") = value
    '        Session("CampaignID") = value
    '    End Set
    'End Property
    Property AgentID() As String
        Get
            Return ViewState("AgentID")
        End Get
        Set(ByVal value As String)
            ViewState("AgentID") = value
        End Set
    End Property
#End Region

    Dim dtData As DataTable
    Dim dtSummarise As DataTable

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        HumanMessage.Style.Item("visibility") = "hidden"
        If Not IsPostBack Then
            If Session("agentid") Is Nothing Then
                FormsAuthentication.SignOut()
            End If
            'Session("AgentID") = "NSS51102"
            If Session("AgentID") <> "" Then
                'BindGroupByMembers()
                ' CampaignID = Session("CampaignID")
                AgentID = Session("AgentID")
                LoadData()
                FillData()
                UcDateTo.Visible = False
                ucDateFrom.Visible = False
                lblAnd.Visible = False
                PanelReports.Controls.Add(Common.GetMenu(Request.Url, AgentID, Request.ApplicationPath))
            End If
        End If
    End Sub

#Region "--- Functions ---"
    Private Sub LoadData()
        FillCommonFilters()
    End Sub
    Private Sub FillCommonFilters()
        Dim db As New DBAccess
        Dim dt As DataTable = db.ReturnTable("select * from tbl_Reports_DatePeriods")
        db = Nothing
        Dim dr As DataRow = dt.NewRow
        dr(0) = 10
        dr(1) = "Between"
        dt.Rows.Add(dr)
        CboPeriod.DataTextField = "Caption"
        CboPeriod.DataValueField = "Period"
        CboPeriod.DataSource = dt
        CboPeriod.DataBind()

        db = New DBAccess
        dt = db.ReturnTable("Select * from tbl_Reports_GroupBy")
        db = Nothing
    End Sub

    Private Function IntegerToDateString(ByVal d As Integer) As String
        Return d.ToString.Substring(0, 4) & "-" & d.ToString.Substring(4, 2) & "-" & d.ToString.Substring(6, 2)
    End Function

    Private Sub FillData()
        Dim db As New DBAccess
        Dim startday As Integer, endday As Integer
        Dim sdate, edate As DateTime
        If CboPeriod.SelectedValue = 10 Then
            startday = ucDateFrom.yyyymmdd
            endday = UcDateTo.yyyymmdd
            sdate = ucDateFrom.value
            edate = UcDateTo.value
        Else
            db = New DBAccess
            db.slDataAdd("Period", CboPeriod.SelectedValue)
            db.slDataAdd("Campaignid", 281)
            Dim dr As DataRow = db.ReturnRow("usp_GetStart_EndDateForAPeriod", True)
            db = Nothing
            startday = dr(0)
            endday = dr(1)
            sdate = IntegerToDateString(startday)
            edate = IntegerToDateString(endday)
            ' ChartPeriod = DateDiff(DateInterval.Day, sdate, edate)
        End If
        db = Nothing
        '----------------- 
        db = New DBAccess

        db.slDataAdd("DateFrom", startday)
        db.slDataAdd("DateTo", endday)
        db.slDataAdd("campaignid", 281)
        'db.slDataAdd("inputType", cboComplexitySLA.SelectedValue)
        dtData = db.ReturnTable("usp_Morris_ShiftUtilisation", , True)
        db = Nothing

        '------------------------------------
        FillDataWithFormula()
        '---------------------------------
        gvData.DataSource = dtData
        gvData.DataBind()

        ' FillSummariseData()
        gvSummarise.DataSource = dtSummarise
        gvSummarise.DataBind()

    End Sub

#End Region

#Region "--- Functions---"

    Private Sub FillDataWithFormula()
        If dtData.Rows.Count > 0 Then

            Dim SumOverAllVol As Double = 0
            Dim SumMorningVol As Double = 0
            Dim SumEveningVol As Double = 0
            Dim SumNightVol As Double = 0

            Dim WeightageOverAllVol As Double = 0
            Dim WeightageMorningVol As Double = 0
            Dim WeightageEveningVol As Double = 0
            Dim WeightageNightVol As Double = 0

            '-----------------------------
            Dim drow As DataRow = dtData.NewRow
            drow(0) = "Total"

            drow("OverAll Vol") = 0
            drow("Morning Vol") = 0
            drow("Evening Vol") = 0
            drow("Night Vol") = 0
            dtData.Rows.Add(drow)
            '--------------------------
            Dim dr2 As DataRow = dtData.NewRow
            dr2(0) = "Weighted Avg Time"

            'dr2("OverAll Vol") = 0
            'dr2("Morning Vol") = 0
            'dr2("Evening Vol") = 0
            'dr2("Night Vol") = 0
            dtData.Rows.Add(dr2)
            '--------------------------
            For i As Integer = 0 To dtData.Rows.Count - 2
                SumOverAllVol += IIf(IsDBNull(dtData.Rows(i).Item("OverAll Vol")), 0, dtData.Rows(i).Item("OverAll Vol"))
                SumMorningVol += IIf(IsDBNull(dtData.Rows(i).Item("Morning Vol")), 0, dtData.Rows(i).Item("Morning Vol"))
                SumEveningVol += IIf(IsDBNull(dtData.Rows(i).Item("Evening Vol")), 0, dtData.Rows(i).Item("Evening Vol"))
                SumNightVol += IIf(IsDBNull(dtData.Rows(i).Item("Night Vol")), 0, dtData.Rows(i).Item("Night Vol"))
            Next
            dtData.Rows(dtData.Rows.Count - 2)("OverAll Vol") = SumOverAllVol
            dtData.Rows(dtData.Rows.Count - 2)("Morning Vol") = SumMorningVol
            dtData.Rows(dtData.Rows.Count - 2)("Evening Vol") = SumEveningVol
            dtData.Rows(dtData.Rows.Count - 2)("Night Vol") = SumNightVol
            '-------------------------------

            For k As Integer = 0 To dtData.Rows.Count - 2 '-- one more less as to avoid the last row of TOTAL
                If SumOverAllVol = 0 Then
                    dtData.Rows(k)("OverAll Work Mix%") = 0
                Else
                    dtData.Rows(k)("OverAll Work Mix%") = Math.Round(IIf(IsDBNull(dtData.Rows(k).Item("OverAll Vol")), 0, dtData.Rows(k).Item("OverAll Vol")) / SumOverAllVol * 100.0, 2)
                End If

                If SumMorningVol = 0 Then
                    dtData.Rows(k)("Morning Work Mix%") = 0
                Else
                    dtData.Rows(k)("Morning Work Mix%") = Math.Round(IIf(IsDBNull(dtData.Rows(k).Item("Morning Vol")), 0, dtData.Rows(k).Item("Morning Vol")) / SumMorningVol * 100.0, 2)
                End If

                If SumEveningVol = 0 Then
                    dtData.Rows(k)("Evening Work Mix%") = 0
                Else
                    dtData.Rows(k)("Evening Work Mix%") = Math.Round(IIf(IsDBNull(dtData.Rows(k).Item("Evening Vol")), 0, dtData.Rows(k).Item("Evening Vol")) / SumEveningVol * 100.0, 2)
                End If

                If SumNightVol = 0 Then
                    dtData.Rows(k)("Night Work Mix%") = 0
                Else
                    dtData.Rows(k)("Night Work Mix%") = Math.Round(IIf(IsDBNull(dtData.Rows(k).Item("Night Vol")), 0, dtData.Rows(k).Item("Night Vol")) / SumNightVol * 100.0, 2)
                End If
                '-----------------------------------------------
                If SumOverAllVol = 0 Then
                    WeightageOverAllVol = 0
                Else
                    WeightageOverAllVol += (IIf(IsDBNull(dtData.Rows(k).Item("OverAll Vol")), 0, dtData.Rows(k).Item("OverAll Vol")) / SumOverAllVol) * IIf(IsDBNull(dtData.Rows(k).Item("AHT")), 0, dtData.Rows(k).Item("AHT"))
                End If

                If SumMorningVol = 0 Then
                    WeightageMorningVol = 0
                Else
                    WeightageMorningVol += (IIf(IsDBNull(dtData.Rows(k).Item("Morning Vol")), 0, dtData.Rows(k).Item("Morning Vol")) / SumMorningVol) * IIf(IsDBNull(dtData.Rows(k).Item("AHT")), 0, dtData.Rows(k).Item("AHT"))
                End If

                If SumEveningVol = 0 Then
                    WeightageEveningVol = 0
                Else
                    WeightageEveningVol += (IIf(IsDBNull(dtData.Rows(k).Item("Evening Vol")), 0, dtData.Rows(k).Item("Evening Vol")) / SumEveningVol) * IIf(IsDBNull(dtData.Rows(k).Item("AHT")), 0, dtData.Rows(k).Item("AHT"))
                End If

                If SumNightVol = 0 Then
                    WeightageNightVol = 0
                Else
                    WeightageNightVol += (IIf(IsDBNull(dtData.Rows(k).Item("Night Vol")), 0, dtData.Rows(k).Item("Night Vol")) / SumNightVol) * IIf(IsDBNull(dtData.Rows(k).Item("AHT")), 0, dtData.Rows(k).Item("AHT"))
                End If

            Next
            '----------------------------------
            dtData.Rows(dtData.Rows.Count - 1)("OverAll Work Mix%") = Math.Round(WeightageOverAllVol, 2)
            dtData.Rows(dtData.Rows.Count - 1)("Morning Work Mix%") = Math.Round(WeightageMorningVol, 2)
            dtData.Rows(dtData.Rows.Count - 1)("Evening Work Mix%") = Math.Round(WeightageEveningVol, 2)
            dtData.Rows(dtData.Rows.Count - 1)("Night Work Mix%") = Math.Round(WeightageNightVol, 2)


            '---------------------------------------------------------------------------------------------------
            '-----------For Summarise Datatable --------------------------------------------------------------------
            '---------------------------------------------------------------------------------------------------
            dtSummarise = New DataTable

            Dim col1 As DataColumn = New DataColumn("Capacity Calculations - Overall", System.Type.GetType("System.String"))
            Dim col2 As DataColumn = New DataColumn("Overall", System.Type.GetType("System.String"))
            Dim col3 As DataColumn = New DataColumn("Morning", System.Type.GetType("System.String"))
            Dim col4 As DataColumn = New DataColumn("Eve", System.Type.GetType("System.String"))
            Dim col5 As DataColumn = New DataColumn("Night", System.Type.GetType("System.String"))

            dtSummarise.Columns.Add(col1)
            dtSummarise.Columns.Add(col2)
            dtSummarise.Columns.Add(col3)
            dtSummarise.Columns.Add(col4)
            dtSummarise.Columns.Add(col5)

            Dim row As DataRow = dtSummarise.NewRow
            row(0) = "Total Available Time/day/agent"
            row(1) = "08:00:00"
            row(2) = "08:00:00"
            row(3) = "08:00:00"
            row(4) = "08:00:00"
            dtSummarise.Rows.Add(row)

            row = dtSummarise.NewRow
            row(0) = "Weighted Average Time"
            row(1) = Common.TimeString(dtData.Rows(dtData.Rows.Count - 1)("OverAll Work Mix%"))
            row(2) = Common.TimeString(dtData.Rows(dtData.Rows.Count - 1)("Morning Work Mix%"))
            row(3) = Common.TimeString(dtData.Rows(dtData.Rows.Count - 1)("Evening Work Mix%"))
            row(4) = Common.TimeString(dtData.Rows(dtData.Rows.Count - 1)("Night Work Mix%"))
            dtSummarise.Rows.Add(row)

            row = dtSummarise.NewRow
            row(0) = "No of transactions an agent can do in a day @ 10% Shrinkage"

            If dtData.Rows(dtData.Rows.Count - 1)("OverAll Work Mix%") = 0 Then
                row(1) = 0
            Else
                row(1) = Math.Round((28800 / dtData.Rows(dtData.Rows.Count - 1)("OverAll Work Mix%")) * 0.9, 2) '08:00:00 * [Weighted Average Time] /9
            End If

            If dtData.Rows(dtData.Rows.Count - 1)("Morning Work Mix%") = 0 Then
                row(2) = 0
            Else
                row(2) = Math.Round((28800 / dtData.Rows(dtData.Rows.Count - 1)("Morning Work Mix%")) * 0.9, 2) '08:00:00 * [Weighted Average Time] /9
            End If

            If dtData.Rows(dtData.Rows.Count - 1)("Evening Work Mix%") = 0 Then
                row(3) = 0
            Else
                row(3) = Math.Round((28800 / dtData.Rows(dtData.Rows.Count - 1)("Evening Work Mix%")) * 0.9, 2) '08:00:00 * [Weighted Average Time] /9
            End If

            If dtData.Rows(dtData.Rows.Count - 1)("Night Work Mix%") = 0 Then
                row(4) = 0
            Else
                row(4) = Math.Round((28800 / dtData.Rows(dtData.Rows.Count - 1)("Night Work Mix%")) * 0.9, 2) '08:00:00 * [Weighted Average Time] /9
            End If

            dtSummarise.Rows.Add(row)

            row = dtSummarise.NewRow
            row(0) = "Total Ads Done"
            row(1) = dtData.Rows(dtData.Rows.Count - 2)("OverAll Vol")
            row(2) = dtData.Rows(dtData.Rows.Count - 2)("Morning Vol")
            row(3) = dtData.Rows(dtData.Rows.Count - 2)("Evening Vol")
            row(4) = dtData.Rows(dtData.Rows.Count - 2)("Night Vol")
            dtSummarise.Rows.Add(row)


            row = dtSummarise.NewRow
            row(0) = "Targets for 24 Resources"
            row(1) = Math.Round(dtSummarise.Rows(2)("Overall") * 24, 2)
            row(2) = Math.Round(dtSummarise.Rows(2)("Morning") * 8, 2)
            row(3) = Math.Round(dtSummarise.Rows(2)("Eve") * 8, 2)
            row(4) = Math.Round(dtSummarise.Rows(2)("Night") * 8, 2)
            dtSummarise.Rows.Add(row)


            row = dtSummarise.NewRow
            row(0) = "UTILIZATION"
            If dtSummarise.Rows(4)("Overall") = 0 Then
                row(1) = 0 & " %"
            Else
                row(1) = Math.Round(dtSummarise.Rows(3)("Overall") / dtSummarise.Rows(4)("Overall") * 100, 2) & " %"
            End If

            If dtSummarise.Rows(4)("Morning") = 0 Then
                row(2) = 0 & " %"
            Else
                row(2) = Math.Round(dtSummarise.Rows(3)("Morning") / dtSummarise.Rows(4)("Morning") * 100, 2) & " %"
            End If

            If dtSummarise.Rows(4)("Eve") = 0 Then
                row(3) = 0 & " %"
            Else
                row(3) = Math.Round(dtSummarise.Rows(3)("Eve") / dtSummarise.Rows(4)("Eve") * 100, 2) & " %"
            End If


            If dtSummarise.Rows(4)("Night") = 0 Then
                row(4) = 0 & " %"
            Else
                row(4) = Math.Round(dtSummarise.Rows(3)("Night") / dtSummarise.Rows(4)("Night") * 100, 2) & " %"
            End If

            dtSummarise.Rows.Add(row)

            '------------------------------------Now convert it into time format for the view for upper gridview for first datatable
            dtData.Rows(dtData.Rows.Count - 1)("OverAll Work Mix%") = Common.TimeString(Math.Round(WeightageOverAllVol, 2))
            dtData.Rows(dtData.Rows.Count - 1)("Morning Work Mix%") = Common.TimeString(Math.Round(WeightageMorningVol, 2))
            dtData.Rows(dtData.Rows.Count - 1)("Evening Work Mix%") = Common.TimeString(Math.Round(WeightageEveningVol, 2))
            dtData.Rows(dtData.Rows.Count - 1)("Night Work Mix%") = Common.TimeString(Math.Round(WeightageNightVol, 2))
            '----------------------------------

        End If
    End Sub

    Protected Sub GridView1_RowDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles gvData.RowDataBound
        If e.Row.RowType = DataControlRowType.DataRow Then
            If IsNumeric(e.Row.Cells(2).Text) Then
                e.Row.Cells(2).Text = Common.TimeString(e.Row.Cells(2).Text)
            End If

            If IsNumeric(e.Row.Cells(4).Text) Then
                e.Row.Cells(4).Text = Common.TimeString(e.Row.Cells(4).Text)
            End If

        End If
    End Sub


#End Region

#Region "--- Events ---"

    Protected Sub CboPeriod_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles CboPeriod.SelectedIndexChanged
        If CboPeriod.SelectedValue = 10 Then
            ucDateFrom.Visible = True
            UcDateTo.Visible = True
            lblAnd.Visible = True
            FillData()
        Else
            ucDateFrom.Visible = False
            UcDateTo.Visible = False
            lblAnd.Visible = False
            FillData()
        End If
    End Sub

    Protected Sub ucDateFrom_Changed(ByVal sender As Object, ByVal e As System.EventArgs) Handles ucDateFrom.Changed
        FillData()
    End Sub

    Protected Sub UcDateTo_Changed(ByVal sender As Object, ByVal e As System.EventArgs) Handles UcDateTo.Changed
        FillData()
    End Sub

    Protected Sub btnRefresh_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnRefresh.Click
        FillData()
    End Sub


    Protected Sub ImageButton1_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton1.Click
        FillData()
        Dim gv As New GridView
        gv.DataSource = dtData
        gv.DataBind()
        GridViewExportUtil.Export(lblReportName.Text & ".xls", gv)
    End Sub

    Protected Sub imgfav_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles imgfav.Click
        Common.AddToFav(AgentID, "Shift Utilisation")
        SuccessMessage("Report has been added to your favourite list")
        FillData()
    End Sub

#End Region

#Region "Utility"

    Private Sub AlertMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMFail"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub

    Private Sub SuccessMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMSuccess"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub

#End Region


End Class
