﻿using Microsoft.VisualBasic;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using com.nss.DBAccess;
using System.Data.SqlClient;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Web.Services;
using System.Drawing;
using System.Globalization;
using System.Text.RegularExpressions;
using System.IO;
using System.Net;
using System.Web;

public partial class ZionsInput : System.Web.UI.Page
 {
       
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
               this.getuser();
                EmployeeDataGrid();
            }
        }

     public void getuser()
    {
        if (Session["UserID"] != null)
        {
            if (User.Identity.Name.ToString().Contains("NSS\\"))
            {
                Session["Lanid"] = User.Identity.Name.ToString().Replace("NSS\\", "");
            }
            else
            {
                Session["Lanid"] = User.Identity.Name;
            }
            //if (string.IsNullOrEmpty(Session["Lanid"].ToString()))
            //{
            //    Session["Lanid"] = Convert.ToString()(Mid(Request.ServerVariables["LOGON_USER"], Strings.InStr(Request.ServerVariables["LOGON_USER"], "\\") + 1, Strings.Len(Request.ServerVariables("LOGON_USER"))));
            //}

            com.nss.DBAccess.DBAccess db = new com.nss.DBAccess.DBAccess();
            //Dim dr As System.Data.DataRow = db.ReturnRow("select Agentid,AgentName,campaignid,btVerifier from tbl_agentmaster where lanid='" & Session["Lanid"] & "' and active=1")
            db.slDataAdd("UserId", "akanksha.shakya");
            System.Data.DataRow dr = db.ReturnRow("usp_CheckTermsUser", true);
            db = null;
            if (dr == null)
            {
                Response.Write("There is some problem in authenticating your credentials. Please make sure you are authorized to use this website.");
                return;
            }
            Session["CampaignID"] = dr["campaignid"];
            Session["AgentID"] = dr["AgentID"];
            Session["UserID"] = dr["AgentID"];
            Session["username"] = dr["AgentName"];
            Session["IsVerifier"] = dr["btVerifier"];
            Response.Write(Session["username"]);
            Response.Write(Session["Lanid"]);
        }                
    }

        private void EmployeeDataGrid()
        {
           DataTable dt = new DataTable();
           DBAccess db = new DBAccess("CRM");
             dt = db.ReturnTable("select * from tbl_zionsTeamwise","",false);

             try
                    {                      
                        GridEmpData.DataSource = dt;
                        GridEmpData.DataBind();
                    }
                    catch (Exception)
                    {
                        lblmsg.Text = "record not found";
                    }                
            
        }

        protected void btnSave_Click(object sender, EventArgs e)
        {
            Button btn = (Button)sender;
            GridViewRow GrdRow = (GridViewRow)btn.Parent.Parent;            
            DropDownList ddlId = (DropDownList)GrdRow.Cells[0].FindControl("ddlId");            
            DropDownList ddlName = (DropDownList)GrdRow.Cells[0].FindControl("ddlName");
          
            TextBox txtAS19_p1 = (TextBox)GrdRow.Cells[0].FindControl("txtAS19_p1");           
            TextBox txtAS16_p1 = (TextBox)GrdRow.Cells[0].FindControl("txtAS16_p1");          
            TextBox txtKITTING_P1 = (TextBox)GrdRow.Cells[0].FindControl("txtKITTING_P1");      
            TextBox txtANF_p1 = (TextBox)GrdRow.Cells[0].FindControl("txtANF_p1");          

            if ((ddlId.SelectedValue!= "") && (txtAS19_p1.Text != "") && (txtAS16_p1.Text !="") && (txtKITTING_P1.Text!= "") && (txtANF_p1.Text!=""))
            {            
              
                 DBAccess db = new DBAccess("CRM");
                 db.slDataAdd("EmpId", ddlId.SelectedItem.Text);
            db.slDataAdd("EmpName", ddlName.SelectedItem.Text);
            db.slDataAdd("AS19_p1", txtAS19_p1.Text.Trim());
            db.slDataAdd("AS16_p1", txtAS16_p1.Text.Trim());
            db.slDataAdd("KITTING_P1", txtKITTING_P1.Text.Trim());
            db.slDataAdd("ANF_p1", txtANF_p1.Text.Trim());
            db.slDataAdd("EDate", DateTime.Now);
            db.Executeproc("sp_EmpDataInsert");           
            }
               
            else if((ddlId.SelectedValue== "") || (txtAS19_p1.Text=="") || (txtAS16_p1.Text=="") || (txtKITTING_P1.Text=="") || (txtANF_p1.Text==""))
            {
              
                lblMessage.Text = "Please fill all the fields";
            }

            EmployeeDataGrid();
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            lblerror.Text = "";
            if ((Text.Text != "") && (txtRec1.Text != "") && (txtRec2.Text != "") && (txtRec3.Text != "") && (txtRec4.Text != "") && (txtPro1.Text != "") && (txtPro2.Text != "") && (txtPro3.Text != "") && (txtPro4.Text != ""))
            {                                                                                                                                                                              
                
                DBAccess db1 = new DBAccess("CRM");
            db1.slDataAdd("Heading", "AS19");
            db1.slDataAdd("Received", txtRec1.Text);
            db1.slDataAdd("Processed", txtPro1.Text);
            db1.slDataAdd("ZDate", Text.Text);
            db1.InsertinTable("tbl_Zions_save1");
       

            db1.slDataAdd("Heading", "AS16");
            db1.slDataAdd("Received", txtRec2.Text);
            db1.slDataAdd("Processed", txtPro2.Text);
            db1.slDataAdd("ZDate", Text.Text);
            db1.InsertinTable("tbl_Zions_save1");
          
                
         
            db1.slDataAdd("Heading", "KITTING");
            db1.slDataAdd("Received", txtRec3.Text);
            db1.slDataAdd("Processed", txtPro3.Text);
            db1.slDataAdd("ZDate", Text.Text);
            db1.InsertinTable("tbl_Zions_save1");

          
            db1.slDataAdd("Heading", "ANF");
            db1.slDataAdd("Received", txtRec4.Text);
            db1.slDataAdd("Processed", txtPro4.Text);
            db1.slDataAdd("ZDate", Text.Text);
            db1.InsertinTable("tbl_Zions_save1");
            Clear();
            }
            else if(Text.Text== "")
            {
                lblerror.Visible = true;
                lblerror.Text = "Please select Date";
            }  
            else if((txtRec1.Text=="") || (txtRec2.Text=="") || (txtRec3.Text =="") ||(txtRec4.Text=="")|| (txtPro1.Text=="") || (txtPro2.Text=="") || (txtPro3.Text=="") ||(txtPro4.Text==""))
            {
                lblerror.Visible = true;
                lblerror.Text = "Please enter value";
            }         
        }
        public void Clear()
        {
            txtRec1.Text = "";
            txtRec2.Text = "";
            txtRec3.Text = "";
            txtRec4.Text = "";
            txtPro1.Text = "";
            txtPro2.Text = "";
            txtPro3.Text = "";
            txtPro4.Text = "";
            Text.Text = null;
        }
       

        protected void GridView1_RowDataBound(object sender, EventArgs e)
        {

            DropDownList ddlEmpId = GridEmpData.FooterRow.FindControl("ddlId") as DropDownList;
           
              
            DataTable dt2 = new DataTable();
            DBAccess db2 = new DBAccess("CRM");

            dt2 = db2.ReturnTable("select AgentID, agentname from tbl_agentmaster WHERE CampaignID='309' and btActive=1 order by AgentID", "", false);
           System.Data.DataRow dr = dt2.NewRow();
       
        dt2.Rows.Add(dr);
        ddlEmpId.DataTextField = "AgentID";
        ddlEmpId.DataValueField = "AgentID";
        ddlEmpId.DataSource = dt2;
        ddlEmpId.DataBind();
        ddlEmpId.Items.Insert(0, new ListItem("Select", ""));
        ddlEmpId.Items.Insert(1, new ListItem("00", "00"));        

            DropDownList ddlEmpName = GridEmpData.FooterRow.FindControl("ddlName") as DropDownList;
           

             DataTable dt1 = new DataTable();
             DBAccess db1 = new DBAccess("CRM");
             dt1 = db1.ReturnTable("select AgentID, agentname from tbl_agentmaster WHERE CampaignID='309' and btActive=1 order by AgentID", "", false);
           //DataRow dr1;
           DataRow dr1 = dt1.NewRow();
       
        dt1.Rows.Add(dr1);
        ddlEmpName.DataTextField = "agentname";
        ddlEmpName.DataValueField = "AgentID";
        ddlEmpName.DataSource = dt1;
        ddlEmpName.DataBind();
        ddlEmpName.Items.Insert(0, new ListItem("Select", "0"));
        ddlEmpName.Items.Insert(1, new ListItem("OTHERS", "OTHERS"));
           
        }

       
        protected void ddlId_SelectedIndexChanged(object sender, EventArgs e)
        {
            DropDownList ddlEmpId = GridEmpData.FooterRow.FindControl("ddlId") as DropDownList;
          
            DropDownList ddlEmpName = GridEmpData.FooterRow.FindControl("ddlName") as DropDownList;
            if (ddlEmpId.Text == "00")
            {
                ddlEmpName.SelectedItem.Text = "OTHERS";
            }
            else
            {

              DataTable dt1 = new DataTable();
              DBAccess db1 = new DBAccess("CRM");

              dt1 = db1.ReturnTable("select AgentID, agentname from tbl_agentmaster where AgentID='" + ddlEmpId.SelectedValue + "' and campaignid=309 and btActive=1 order by AgentID ", "", false);
           DataRow dr1 = dt1.NewRow();
          
            dt1.Rows.Add(dr1);
            ddlEmpName.DataTextField = "agentname";
            ddlEmpName.DataSource = dt1;
            ddlEmpName.DataBind();
            }
        }

        protected void ddlName_SelectedIndexChanged(object sender, EventArgs e)
        {
            DropDownList ddlEmpId = GridEmpData.FooterRow.FindControl("ddlId") as DropDownList;

            DropDownList ddlEmpName = GridEmpData.FooterRow.FindControl("ddlName") as DropDownList;
            if (ddlEmpName.SelectedItem.Text == "OTHERS")
            {
                ddlEmpId.SelectedValue = "00";
            }
            else
            {               

                DataTable dt1 = new DataTable();
                DBAccess db1 = new DBAccess("CRM");

                dt1 = db1.ReturnTable("select AgentID, agentname from tbl_agentmaster where agentname='" + ddlEmpName.SelectedItem + "' and campaignid=309 and btActive=1 order by AgentID ", "", false);
                DataRow dr1 = dt1.NewRow();

                dt1.Rows.Add(dr1);
                ddlEmpId.DataTextField = "AgentID";
                ddlEmpId.DataSource = dt1;
                ddlEmpId.DataBind();
            }
        }

        protected void grvHeader_RowCreated(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.Header)
            {
                GridView HeaderGrid = (GridView)sender;
                GridViewRow HeaderGridRow = new GridViewRow(0, 0, DataControlRowType.Header, DataControlRowState.Insert);

                TableCell HeaderCell = new TableCell();
                HeaderCell.Text = "TeamWise";
                HeaderCell.Attributes.Add("style", "padding:5px; font-weight:bold;background-color: #429ABE; border: solid 1px #525252;color:Black;Width:80px;text - align:center;font - size:medium;font - family: Calibri;");
                HeaderCell.ColumnSpan = 2;
                HeaderGridRow.Cells.Add(HeaderCell);

                HeaderCell = new TableCell();
                HeaderCell.Text = "ASI-19";
                HeaderCell.Attributes.Add("style", "padding:5px; font-weight:bold;background-color: #429ABE; border: solid 1px #525252;color:Black;text - align:center;font - size:medium;font - family: Calibri;");
               
                HeaderGridRow.Cells.Add(HeaderCell);  
                HeaderCell = new TableCell();
                HeaderCell.Text = "ASI-16";
                HeaderCell.Attributes.Add("style", "padding:5px; font-weight:bold;background-color: #429ABE; border: solid 1px #525252;color:Black;text - align:center;font - size:medium;font - family: Calibri;");
               
                HeaderGridRow.Cells.Add(HeaderCell); 
                HeaderCell = new TableCell();
                HeaderCell.Text = "KITING";
                HeaderCell.Attributes.Add("style", "padding:5px; font-weight:bold;background-color: #429ABE; border: solid 1px #525252;color:Black;text - align:center;font - size:medium;font - family: Calibri;");
               
                HeaderGridRow.Cells.Add(HeaderCell);
                HeaderCell = new TableCell();
                HeaderCell.Text = "ANF";
                HeaderCell.Attributes.Add("style", "padding:5px; font-weight:bold;background-color: #429ABE; border: solid 1px #525252;color:Black;text - align:center;font - size:medium;font - family: Calibri;");
                HeaderGridRow.Cells.Add(HeaderCell);

                GridEmpData.Controls[0].Controls.AddAt(0, HeaderGridRow);
            }
        }
    } 
   