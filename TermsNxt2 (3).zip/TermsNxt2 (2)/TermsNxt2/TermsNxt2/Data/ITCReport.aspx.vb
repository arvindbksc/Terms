﻿Imports com.nss.DBAccess
Imports System.Data
Imports System.Text
Partial Class Data_ITCReport
    Inherits System.Web.UI.Page
    Dim dt, dt1 As DataTable
#Region "--- Properties ---"
    Property ProcessID() As Integer
        Get
            Return ViewState("ProcessID")
        End Get
        Set(ByVal value As Integer)
            ViewState("ProcessID") = value
            Session("ProcessID") = value
        End Set
    End Property
    Property CampaignID() As Integer
        Get
            Return ViewState("CampaignID")
        End Get
        Set(ByVal value As Integer)
            ViewState("CampaignID") = value
        End Set
    End Property
    Property AgentID() As String
        Get
            Return ViewState("AgentID")
        End Get
        Set(ByVal value As String)
            ViewState("AgentID") = value
        End Set
    End Property
    Property startday() As Integer
        Get
            Return ViewState("startday")
        End Get
        Set(ByVal value As Integer)
            ViewState("startday") = value
        End Set
    End Property
    Property endday() As Integer
        Get
            Return ViewState("endday")
        End Get
        Set(ByVal value As Integer)
            ViewState("endday") = value
        End Set
    End Property
#End Region
#Region "--- Load Data ---"
    Private Sub LoadData()
        FillCommonFilters()
        FillProcessCampaigns()
        If cboCampaigns.SelectedItem.Text = "HPS" Then
            CboPeriod.SelectedValue = 3
        End If
    End Sub
#End Region
#Region "--- Load Functions ---"
    Private Sub FillCommonFilters()
        Dim db As New DBAccess
        Dim dt As DataTable = db.ReturnTable("select * from tbl_Reports_DatePeriods")
        db = Nothing
        Dim dr As DataRow = dt.NewRow
        dr(0) = 10
        dr(1) = "Between"
        dt.Rows.Add(dr)
        CboPeriod.DataTextField = "Caption"
        CboPeriod.DataValueField = "Period"
        CboPeriod.DataSource = dt
        CboPeriod.DataBind()
    End Sub
    Private Sub FillProcessCampaigns()
        Common.FillProcessCampaigns(CboProcess, cboCampaigns, AgentID, CampaignID)
        Dim lstCamp As New ListItem
        lstCamp.Value = 0
        lstCamp.Text = "All"
        If cboCampaigns.Items.Contains(lstCamp) Then
            cboCampaigns.Items.Remove(lstCamp)
        End If
    End Sub
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        HumanMessage.Style.Item("visibility") = "hidden"
        If Not IsPostBack Then
            If Session("AgentID") <> "" Then
                CampaignID = Session("CampaignID")
                AgentID = Session("AgentID")
                PanelReports.Controls.Add(Common.GetMenu(Request.Url, AgentID, Request.ApplicationPath))
                LoadData()
                CboPeriod.SelectedValue = Request.QueryString("period")
                cboCampaigns.SelectedValue = Request.QueryString("campaign")
                fillgrid()
                UcDateTo.Visible = False
                ucDateFrom.Visible = False
                lblAnd.Visible = False
                GetWorkType()
            End If
        End If
    End Sub
    Private Sub GetWorkType()
        Dim dtWrktp As DataTable
        Dim db As New DBAccess
        dtWrktp = db.ReturnTable("select b.Ansid, b.Description  from tbl_Config_QuestAnsMaps a inner join tbl_Config_Answers b on b.AnsID=a.AnsID   where CampaignID=282 and QuestID=2820001", False)
        Dim dr As DataRow
        dr = dtWrktp.NewRow
        dr("Description") = "All"
        dr("Ansid") = 0
        dtWrktp.Rows.Add(dr)
        db = Nothing
        cboFilterBy.DataTextField = "Description"
        cboFilterBy.DataValueField = "Ansid"
        cboFilterBy.DataSource = dtWrktp
        cboFilterBy.DataBind()
        cboFilterBy.SelectedValue = 0
    End Sub
#End Region
#Region "--- Grid Ops ---"
    Protected Sub GridView1_RowDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles GridView1.RowDataBound
        If e.Row.RowType = DataControlRowType.Header Then
            e.Row.Cells(1).Text = cboGroupBy1.SelectedItem.Text
            If cboGroupBy2.SelectedItem.Text <> "None" Then
                e.Row.Cells(2).Text = cboGroupBy2.SelectedItem.Text
            End If
        End If
    End Sub
    Protected Sub GridView1_PageIndexChanging(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewPageEventArgs) Handles GridView1.PageIndexChanging
        GridView1.PageIndex = e.NewPageIndex
        fillgrid()
    End Sub
#End Region
#Region "--- Events ---"
    Protected Sub cboCampaigns_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboCampaigns.SelectedIndexChanged
        CampaignID = cboCampaigns.SelectedValue
        fillgrid()
    End Sub
    Protected Sub CboPeriod_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles CboPeriod.SelectedIndexChanged
        If CboPeriod.SelectedValue = 10 Then
            ucDateFrom.Visible = True
            UcDateTo.Visible = True
            lblAnd.Visible = True
            fillgrid()
        Else
            ucDateFrom.Visible = False
            UcDateTo.Visible = False
            lblAnd.Visible = False
            fillgrid()
        End If
    End Sub
    Protected Sub cboGroupBy1_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboGroupBy1.SelectedIndexChanged
        fillgrid()
    End Sub
    Protected Sub cboGroupBy2_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboGroupBy2.SelectedIndexChanged
        fillgrid()
    End Sub
    Protected Sub ImageButton1_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton1.Click
        If cboCampaigns.SelectedItem.Text = "HPS" Then
            CboPeriod.SelectedValue = 3
        End If
        fillgrid()
        Dim gv As New GridView
        gv.DataSource = dt
        gv.DataBind()
        GridViewExportUtil.Export(lblReportName.Text & ".xls", gv)
    End Sub
    Protected Sub btnFilter_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnFilter.Click
        FilterData()
    End Sub
    Protected Sub btnRefresh_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnRefresh.Click
        fillgrid()
    End Sub
    Protected Sub cboFilterBy_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboFilterBy.SelectedIndexChanged
        FilterData()
    End Sub
    Protected Sub imgfav_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles imgfav.Click
        Common.AddToFav(AgentID, "ITC Report")
        SuccessMessage("Report has been added to your favourite list")
        fillgrid()
    End Sub
#End Region
#Region "--- Support Functions ---"
    Private Sub fillgrid()
        Dim db As New DBAccess
        If CboPeriod.SelectedValue = 10 Then
            startday = ucDateFrom.yyyymmdd
            endday = UcDateTo.yyyymmdd
        Else
            db = New DBAccess
            db.slDataAdd("Period", CboPeriod.SelectedValue)
            db.slDataAdd("Campaignid", CampaignID)
            Dim dr As DataRow = db.ReturnRow("usp_GetStart_EndDateForAPeriod", True)
            db = Nothing
            startday = dr(0)
            endday = dr(1)
        End If
        db = New DBAccess
        db.slDataAdd("startday", startday)
        db.slDataAdd("endDay", endday)
        db.slDataAdd("campaignid", cboCampaigns.SelectedValue)
        db.slDataAdd("GroupBy1", cboGroupBy1.SelectedItem.Text)
        db.slDataAdd("GroupBy2", cboGroupBy2.SelectedItem.Text)
        db.slDataAdd("Flag", 1)
        dt = db.ReturnTable("usp_QuestData_ITC", , True)
        GridView1.DataSource = dt
        GridView1.DataBind()
        db = Nothing
        lblReportName.Text = "Custom Report "
        LblError.Text = "Between " & IntegerToDateString(startday) & "  and " & IntegerToDateString(endday) & " for " & cboCampaigns.SelectedItem.Text & " campaign"
    End Sub
    Private Sub FilterData()
        fillgrid()
        If cboFilterBy.SelectedValue <> 0 Then
            If dt.Rows.Count > 0 Then
                Dim dtfiltered As DataTable = dt.Clone
                Dim drs As DataRow()
                drs = dt.Select("@GroupBy1 = '" & cboFilterBy.SelectedItem.Text & "'")
                For Each dr1 As DataRow In drs
                    dtfiltered.ImportRow(dr1)
                Next
                dt = dtfiltered
                GridView1.DataSource = Nothing
                GridView1.DataSource = dtfiltered
            Else
                GridView1.DataSource = dt
            End If
        Else
            GridView1.DataSource = dt
        End If
        GridView1.DataBind()
    End Sub
    Private Function IntegerToDateString(ByVal d As Integer) As String
        Return d.ToString.Substring(0, 4) & "-" & d.ToString.Substring(4, 2) & "-" & d.ToString.Substring(6, 2)
    End Function
    Public Function TimeString(ByVal Seconds As Long) As String
        Dim lHrs As Long
        Dim lMinutes As Long
        Dim lSeconds As Long
        lSeconds = Seconds
        lHrs = Int(lSeconds / 3600)
        lMinutes = (Int(lSeconds / 60)) - (lHrs * 60)
        lSeconds = Int(lSeconds Mod 60)
        If lSeconds = 60 Then
            lMinutes = lMinutes + 1
            lSeconds = 0
        End If
        If lMinutes = 60 Then
            lMinutes = 0
            lHrs = lHrs + 1
        End If
        TimeString = lHrs.ToString("####00") & ":" & _
        lMinutes.ToString("00") & ":" & _
        lSeconds.ToString("00")
    End Function
    Private Sub ExportToexcel()
        Dim tw As New IO.StringWriter()
        Dim hw As New System.Web.UI.HtmlTextWriter(tw)
        Response.ContentType = "application/vnd.ms-excel"
        Response.AddHeader("content-disposition", "attachment;filename=" & lblReportName.Text & "-" & LblError.Text & ".xls")
        Response.Charset = ""
        EnableViewState = False
        GridView1.RenderControl(hw)
        Response.Write(tw.ToString())
        Response.End()
    End Sub
#End Region
#Region "--- Utility ---"
    Private Sub AlertMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMFail"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub
    Private Sub SuccessMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMSuccess"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub
    Public Overrides Sub VerifyRenderingInServerForm(ByVal Control As Control)

    End Sub

#End Region
    
End Class
