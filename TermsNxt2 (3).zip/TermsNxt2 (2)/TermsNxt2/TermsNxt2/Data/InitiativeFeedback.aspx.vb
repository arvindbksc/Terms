﻿Imports com.nss.DBAccess
Imports System.Data

Partial Class InitiativeFeedback
    Inherits System.Web.UI.Page

#Region "==== Property ===="
    Public Property currentdate() As Date
        Get
            Return ViewState("currentdate")
        End Get
        Set(ByVal value As DateTime)
            ViewState("currentdate") = value
        End Set
    End Property

    Property AgentID() As String
        Get
            Return ViewState("AgentID")
        End Get
        Set(ByVal value As String)
            ViewState("AgentID") = value
        End Set
    End Property
    Property CampaignID() As Integer
        Get
            Return ViewState("CampaignID")
        End Get
        Set(ByVal value As Integer)
            ViewState("CampaignID") = value
        End Set
    End Property
#End Region
#Region "==== Load ==="

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        HumanMessage.Style.Item("visibility") = "hidden"
        'btnClose.Visible = False
        'btnSave.Visible = False
        If Not IsPostBack Then
            If Session("AgentID") <> "" Then
                AgentID = Session("AgentID")
                CampaignID = Session("CampaignID")
                PanelReports.Controls.Add(Common.GetMenu(Request.Url, AgentID, Request.ApplicationPath))
                Dim dbdate As New DBAccess
                currentdate = dbdate.ReturnValue("select getdate()", False)
                dbdate = Nothing
                txtDate.value = currentdate
                ' GetUserId()
                bindData()
            End If
        End If
    End Sub

#End Region

#Region "===== Functions ===="
    Private Sub bindData()
        Dim db As New DBAccess("report")
        Dim dtData As New DataTable

        db.slDataAdd("CampaignID", 281) 'CampaignID)
        db.slDataAdd("date", txtDate.value.ToString("yyyyMMdd"))
        dtData = db.ReturnTable("usp_getData_Morris_FeedbackInitiative", , True)
        db = Nothing

        gvData.DataSource = dtData
        gvData.DataBind()

        'If dtData.Rows.Count > 0 Then
        '    btnClose.Visible = True
        '    btnSave.Visible = True
        'Else
        'End If
    End Sub

    Private Sub SaveData()
        Dim db As DBAccess
        db = New DBAccess("report")
        Try
            db.BeginTrans()
            For Each row As GridViewRow In gvData.Rows

                db.slDataAdd("MODE", "INSERT")
                db.slDataAdd("CampaignID", 281)
                db.slDataAdd("Date", txtDate.value.ToString("yyyyMMdd"))
                db.slDataAdd("AgentID", CType(row.FindControl("lblEMpCode"), Label).Text)
                db.slDataAdd("ExternalError", CType(row.FindControl("gvTXTexternalError"), TextBox).Text)
                db.slDataAdd("InitiativePoints", CType(row.FindControl("gvTXInitiativePoints"), TextBox).Text)

                db.Executeproc("usp_getData_Morris_FeedbackInitiative")
            Next

            db.CommitTrans()
            SuccessMessage("Data has been saved successfully.")
            db = Nothing

        Catch ex As Exception
            db.RollBackTrans()
        End Try
    End Sub

    Private Function isValidate() As Boolean
        Dim flag As Boolean = True

        For Each row As GridViewRow In gvData.Rows
            If Not IsNumeric(CType(row.FindControl("gvTXTexternalError"), TextBox).Text) Or Not IsNumeric(CType(row.FindControl("gvTXInitiativePoints"), TextBox).Text) Then
                AlertMessage("Data should be numeric for " & CType(row.FindControl("lblEmpName"), Label).Text)
                flag = False
                Exit For
            End If
        Next
        Return flag
    End Function

#End Region

#Region "==== Event ==="

    Protected Sub btnRefresh_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnRefresh.Click
        bindData()
    End Sub
    Protected Sub DateChange(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtDate.Changed
        bindData()
    End Sub
    Protected Sub btnSave_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnSave.Click
        Try
            If isValidate() Then
                SaveData()
                bindData()
            End If
        Catch ex As Exception
            AlertMessage(ex.ToString)
        End Try
    End Sub
    Protected Sub btnClose_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnClose.Click
        Response.Redirect("~/Default.aspx")
    End Sub
    Protected Sub imgfav_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles imgfav.Click
        Common.AddToFav(AgentID, "Initiative Feedback")
        SuccessMessage("Initiative Feedback application has been added to your favourite list")
        bindData()
    End Sub
#End Region
#Region "=== Utility ===="

    Private Sub AlertMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMFail"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub
    Private Sub SuccessMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMSuccess"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub
#End Region

End Class
