﻿Imports com.nss.DBAccess
Imports System.Data
Partial Class Data_PIPAgents
    Inherits System.Web.UI.Page
#Region "--- Properties ---"
    Property Startweek() As Integer
        Get
            Return ViewState("Startweek")
        End Get
        Set(ByVal value As Integer)
            ViewState("Startweek") = value
        End Set
    End Property
    Property Endweek() As Integer
        Get
            Return ViewState("Endweek")
        End Get
        Set(ByVal value As Integer)
            ViewState("Endweek") = value
        End Set
    End Property
    Property CampaignID() As Integer
        Get
            Return ViewState("CampaignID")
        End Get
        Set(ByVal value As Integer)
            ViewState("CampaignID") = value
        End Set
    End Property
    Property AgentID() As String
        Get
            Return ViewState("AgentID")
        End Get
        Set(ByVal value As String)
            ViewState("AgentID") = value
        End Set
    End Property
#End Region
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        HumanMessage.Style.Item("visibility") = "hidden"
        If Not IsPostBack Then
            CampaignID = Session("CampaignID")
            AgentID = Session("AgentID")
            PanelReports.Controls.Add(Common.GetMenu(Request.Url, AgentID, Request.ApplicationPath))
            FillProcessCampaigns()
            Last3WeeksPIP()
            BindTeamMembers()
        End If
    End Sub
#Region "--- Support function ---"
    Private Sub FillProcessCampaigns()
        'Common.FillProcessCampaigns(CboProcess, cboCampaigns, AgentID, CampaignID)
        'Dim lstCamp As New ListItem
        'lstCamp.Value = 0
        'lstCamp.Text = "All"
        'If cboCampaigns.Items.Contains(lstCamp) Then
        '    cboCampaigns.Items.Remove(lstCamp)
        'End If
        Common.FillProcesses(CboProcess, AgentID)
        Dim lstprocess As New ListItem
        lstprocess.Value = 0
        lstprocess.Text = "All"
        If CboProcess.Items.Contains(lstprocess) Then
            CboProcess.Items.Remove(lstprocess)
        End If
    End Sub
    Private Sub BindTeamMembers()
        Dim db As New DBAccess
        Dim dt As New DataTable
        db.slDataAdd("ProcessId", CboProcess.SelectedValue)
        db.slDataAdd("WeekNO", cboWeeks.SelectedValue)
        dt = db.ReturnTable("usp_GetPIPAgents", , True)
        db = Nothing
        gvTeamMamber.DataSource = dt
        gvTeamMamber.DataBind()
        If cboWeeks.SelectedValue = Startweek Then
            gvTeamMamber.Enabled = True
            btnSave.Enabled = True
        Else
            btnSave.Enabled = False
            gvTeamMamber.Enabled = False
        End If
    End Sub
    
    Private Sub SavePIP()
        Dim db As New DBAccess
        Dim chk As CheckBox
        Try
            For Each row As GridViewRow In gvTeamMamber.Rows
                Dim PIP As Integer = 0
                chk = row.FindControl("chkPIP")
                If chk.Checked = True Then
                    PIP = 1
                End If
                db.slDataAdd("ProcessId", CboProcess.SelectedValue)
                db.slDataAdd("AgentId", gvTeamMamber.DataKeys(row.RowIndex)("AgentId").ToString)
                db.slDataAdd("PIP", PIP)
                db.slDataAdd("WeekNo", cboWeeks.SelectedValue)
                db.slDataAdd("FilledBY", AgentID)
                db.Executeproc("usp_InsertPIPData")
            Next
            db = Nothing
        Catch ex As Exception
            AlertMessage(ex.ToString)
        End Try
    End Sub
    Private Sub Last3WeeksPIP()
        Dim db As New DBAccess
        Dim dt As DataTable
        dt = db.ReturnTable("SELECT CONVERT(varchar,(DATEPART(WW ,GETDATE()))) As StartWeek,CONVERT(varchar,(DATEPART(WW ,dateadd(WW,-2,GETDATE())))) As EndWeek", False)
        Startweek = dt.Rows(0).Item("StartWeek")
        Endweek = dt.Rows(0).Item("EndWeek")
        db = Nothing
        For ictr = Startweek To Endweek Step -1
            cboWeeks.Items.Add(New ListItem("Week " & ictr, ictr))
        Next
        cboWeeks.SelectedIndex = cboWeeks.Items.IndexOf(cboWeeks.Items.FindByValue(Startweek))
    End Sub

#End Region
#Region "--- Events ---"
    Protected Sub CboProcess_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles CboProcess.SelectedIndexChanged
        BindTeamMembers()
    End Sub
    Protected Sub cboWeeks_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboWeeks.SelectedIndexChanged
        BindTeamMembers()
    End Sub
    Protected Sub btnSave_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnSave.Click
        SavePIP()
        SuccessMessage("Successfully Saved")
    End Sub
    Protected Sub btnRefresh_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnRefresh.Click
        BindTeamMembers()
    End Sub
    Protected Sub chkAll_CheckedChanged(ByVal sender As Object, ByVal e As System.EventArgs)
        Dim cb As CheckBox = gvTeamMamber.HeaderRow.FindControl("chkAll")
        For Each row As GridViewRow In gvTeamMamber.Rows
            Dim chkall As CheckBox = row.FindControl("chkPIP")
            If cb.Checked = True Then
                chkall.Checked = True
            Else
                chkall.Checked = False
            End If
        Next
    End Sub
    Protected Sub imgfav_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles imgfav.Click
        Common.AddToFav(AgentID, "PIP Users")
        SuccessMessage("Report has been added to your favourite list")
        BindTeamMembers()
    End Sub
#End Region
#Region "--- Utility ---"
    Private Sub AlertMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMFail"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub
    Private Sub SuccessMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMSuccess"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub
    'Public Overrides Sub VerifyRenderingInServerForm(ByVal Control As Control)
    'End Sub
#End Region

    
End Class
