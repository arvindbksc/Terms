﻿Imports com.nss.DBAccess
Imports System.Data

Partial Class Data_TradusClientCases
    Inherits System.Web.UI.Page
#Region "Properties"
    Property AgentID() As String
        Get
            Return ViewState("AgentID")
        End Get
        Set(ByVal value As String)
            ViewState("AgentID") = value
        End Set
    End Property
#End Region
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        HumanMessage.Style.Item("visibility") = "hidden"
        If Not IsPostBack Then
            AgentID = Session("AgentID")
            GetData()
            PanelReports.Controls.Add(Common.GetMenu(Request.Url, AgentID, Request.ApplicationPath))
        End If
    End Sub
    Private Sub GetData()
        Dim db As New DBAccess
        Dim dt As DataTable
        db.slDataAdd("ReportType", 1)
        db.slDataAdd("CampID", 238)
        'db.slDataAdd("DateFrom", "")
        'db.slDataAdd("DateTo", "")
        dt = db.ReturnTable("usp_getClientTransaction", , True)
        'Dim strQuery As String = "SELECT  C.AgentName + '('+C.AgentID+')' AS [Team Member],Question10 AS TransID,Question20 AS [Item Id],Question21 AS [Product], Question23 AS [Complaint Type],Question24 AS [Complaint Description],Question25 AS [Complaint Date],Question26 AS [Action],LS.Comments, B.Remarks,isnull(B.ClientStatus,'Open') AS [Client Status] from [ggn-nss-sql2].[Leads].[dbo].tbl_leadmASter238 B INNER JOIN tbl_Summary_CollectedData A on A.TransID=B.LAStTransId AND A.CampaignID =238 AND B.client <> 'NA' AND B.client <> '' AND B.isdeleted<>1 AND isnull(B.ClientStatus,'Open') <>'closed' INNER JOIN tbl_AgentMASter c on c.AgentID=A.agentid INNER JOIN  tbl_Customer_LASt_Status  LS on A.TransID=LS.lASttransid AND LS.CampaignID=238"
        'dt = db.ReturnTable(strQuery, False)
        db = Nothing
        If dt.Rows.Count > 0 Then
            gvClientReport.DataSource = dt
            gvClientReport.DataBind()
        End If
    End Sub

    Protected Sub imgfav_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles imgfav.Click
        Common.AddToFav(AgentID, "Tradus Pending Cases")
        SuccessMessage("Report has been added to your favourite list")
        GetData()
    End Sub
#Region "Utility"

    Private Sub AlertMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMFail"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub

    Private Sub SuccessMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMSuccess"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub

    'Protected Sub ImageButton1_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton1.Click
    '    'fillgrid()
    '    GridViewExportUtil.Export(lblReportName.CurrentPage & "-" & LblError.Text & ".xls", Me.GdAttendance)
    'End Sub


    Public Overrides Sub VerifyRenderingInServerForm(ByVal Control As Control)

    End Sub

#End Region

    Protected Sub ImageButton1_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton1.Click
        GetData()
        GridViewExportUtil.Export(lblReportName.Text & ".xls", Me.gvClientReport)
    End Sub
End Class
