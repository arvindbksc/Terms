﻿Imports com.nss.DBAccess
Imports System.Data
Partial Class AtriumLeadStatusReport
    Inherits System.Web.UI.Page
#Region "Properties"

    Property AgentID() As String
        Get
            Return ViewState("AgentID")
        End Get
        Set(ByVal value As String)
            ViewState("AgentID") = value
        End Set
    End Property

    Property startday() As Integer
        Get
            Return ViewState("startday")
        End Get
        Set(ByVal value As Integer)
            ViewState("startday") = value
        End Set
    End Property

    Property endday() As Integer
        Get
            Return ViewState("endday")
        End Get
        Set(ByVal value As Integer)
            ViewState("endday") = value
        End Set
    End Property

#End Region
#Region "Load"
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            If Session("AgentID") <> "" Then
                AgentID = Session("AgentID")
                PanelReports.Controls.Add(Common.GetMenu(Request.Url, AgentID, Request.ApplicationPath))
                'raj 1 17082011 Start
                FillCommonFilters()
                UcDateTo.Visible = False
                ucDateFrom.Visible = False
                lblAnd.Visible = False
                'raj 1 17082011 End

                Dim db As New DBAccess
                Dim curdate As Date = db.ReturnValue("select getdate()", False)
                db = Nothing
                ucDateFrom.value = curdate
                UcDateTo.value = curdate.adddays(1)
                FillCampaign()

                '  GetData()
            End If

        End If
    End Sub

    Private Sub FillCampaign()
        Dim db As New DBAccess("CRM")
        Dim dtCampaign As New DataTable
        dtCampaign = db.ReturnTable("select CampaignId,Name from tbl_Config_Campaigns where Active=1 order by name asc", False)
        db = Nothing
        Dim row As DataRow = dtCampaign.NewRow
        row.Item(0) = -1
        row.Item(1) = "ALL"
        dtCampaign.Rows.InsertAt(row, 0)
        cboCampaigns.Items.Clear()
        cboCampaigns.DataTextField = "Name"
        cboCampaigns.DataValueField = "CampaignID"
        cboCampaigns.DataSource = dtCampaign
        cboCampaigns.DataBind()
        dtCampaign = Nothing
    End Sub

    

    Dim dtDisposition As DataTable
    Private Sub GetData()
       
        gvLeadStatus.DataSource = Nothing
        Dim db As New DBAccess("report")

        'old code
        Dim startday As Integer, endday As Integer
        If CboPeriod.SelectedValue = 10 Then
            startday = ucDateFrom.yyyymmdd
            endday = UcDateTo.yyyymmdd
        Else

            db = New DBAccess("report")
            db.slDataAdd("Period", CboPeriod.SelectedValue)
            db.slDataAdd("Campaignid", cboCampaigns.SelectedItem.Value)
            Dim dr As DataRow = db.ReturnRow("usp_GetStart_EndDateForAPeriod", True)

            startday = dr(0)
            endday = dr(1)
        End If
 

        'New  Code Search Based on UK Time Zone
        'Dim startday As DateTime, endday As DateTime
        'Dim dtstartday As DateTime
        'dtstartday = DateTime.ParseExact(ucDateFrom.yyyymmdd.ToString(), "yyyymmdd", System.Globalization.CultureInfo.InvariantCulture)
        'dtstartday = TimeZoneInfo.ConvertTimeBySystemTimeZoneId(dtstartday, "GMT Standard Time")
        'Dim dtendday As DateTime
        'dtendday = DateTime.ParseExact(UcDateTo.yyyymmdd.ToString(), "yyyymmdd", System.Globalization.CultureInfo.InvariantCulture)
        'dtendday = TimeZoneInfo.ConvertTimeBySystemTimeZoneId(dtendday, "GMT Standard Time")
        'db.slDataAdd("startday", dtstartday.ToString("dd-MMM-yyyy HH:mm"))
        'db.slDataAdd("endday", dtendday.ToString("dd-MMM-yyyy HH:mm"))


        db.slDataAdd("startday", startday)
        db.slDataAdd("endday", endday)


            If cboCampaigns.SelectedItem.Text.ToUpper <> "ALL" Then
                db.slDataAdd("CampaignID", cboCampaigns.SelectedItem.Value)
            Else

                db.slDataAdd("CampaignID", "-1")
            End If


            dtDisposition = db.ReturnTable("[dbo].[usp_get_LeadStatus_Atrium]", , True)

            db = Nothing
            gvLeadStatus.DataSource = dtDisposition
            gvLeadStatus.DataBind()

    End Sub

    'raj 4 17082011 Start
    Private Sub FillCommonFilters()
        Dim db As New DBAccess
        Dim dt As DataTable = db.ReturnTable("select * from tbl_Reports_DatePeriods")
        db = Nothing
        Dim dr As DataRow = dt.NewRow
        dr(0) = 10
        dr(1) = "Between"
        dt.Rows.Add(dr)
        CboPeriod.DataTextField = "Caption"
        CboPeriod.DataValueField = "Period"
        CboPeriod.DataSource = dt
        CboPeriod.DataBind()
    End Sub
    'raj 4 17082011 End

#End Region

#Region "Events"
    Protected Sub cboCampaigns_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboCampaigns.SelectedIndexChanged

        GetData()
    End Sub
    Protected Sub btnRefresh_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnRefresh.Click

        GetData()
    End Sub

    Protected Sub gvLeadStatus_PageIndexChanging(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewPageEventArgs) Handles gvLeadStatus.PageIndexChanging
        gvLeadStatus.PageIndex = e.NewPageIndex
        GetData()
    End Sub
    Protected Sub ImageButton1_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton1.Click
        GetData()
        Dim gv As New GridView
        gv.DataSource = dtDisposition
        gv.DataBind()
        GridViewExportUtil.Export(lblReportName.Text & ".xls", gv)
    End Sub
 


    Protected Sub CboPeriod_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles CboPeriod.SelectedIndexChanged
        'GetData()
        If CboPeriod.SelectedValue = 10 Then
            ucDateFrom.Visible = True
            UcDateTo.Visible = True
            lblAnd.Visible = True
            'fillgrid()

            GetData()
        Else
            ucDateFrom.Visible = False
            UcDateTo.Visible = False
            lblAnd.Visible = False
            ' fillgrid()

            GetData()
        End If
    End Sub


#End Region

    Protected Sub imgfav_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles imgfav.Click
        Common.AddToFav(AgentID, "Atrium Lead Status Report ")
        SuccessMessage("Report has been added to your favourite list")
        GetData()
    End Sub
#Region "Utility"

    Private Sub AlertMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMFail"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub

    Private Sub SuccessMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMSuccess"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub

    'Protected Sub ImageButton1_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton1.Click
    '    'fillgrid()
    '    GridViewExportUtil.Export(lblReportName.CurrentPage & "-" & LblError.Text & ".xls", Me.GdAttendance)
    'End Sub


    Public Overrides Sub VerifyRenderingInServerForm(ByVal Control As Control)

    End Sub

#End Region
End Class

