﻿Imports System.Data
Imports com.nss.DBAccess


Public Class Data_SiteMap2
    Inherits System.Web.UI.Page

#Region "Properties"

    Property CampaignID() As Integer
        Get
            Return ViewState("CampaignID")
        End Get
        Set(ByVal value As Integer)
            ViewState("CampaignID") = value
            Session("CampaignID") = value
        End Set
    End Property
    Property AgentID() As String
        Get
            Return ViewState("AgentID")
        End Get
        Set(ByVal value As String)
            ViewState("AgentID") = value
        End Set
    End Property
    Property ChartPeriod() As Integer
        Get
            Return ViewState("ChartPeriod")
        End Get
        Set(ByVal value As Integer)
            ViewState("ChartPeriod") = value
        End Set
    End Property

    Property ChartGroupBy() As Integer
        Get
            Return ViewState("ChartGroupBy")
        End Get
        Set(ByVal value As Integer)
            ViewState("ChartGroupBy") = value
        End Set
    End Property


#End Region
    Private Sub FillMenu()
        Dim db As New DBAccess
        db.slDataAdd("userid", AgentID)
        Dim dt As DataTable = db.ReturnTable("usp_User_Module_Report_bkup_20190205", , True)
        db = Nothing
        Dim usermodule() As String = {"displayname"}
        Dim dt1 As DataTable
        dt1 = dt.DefaultView.ToTable(True, usermodule)
        Dim serverpath As String

        ''If Request.Url.Host = "localhost" Then
        ''    serverpath = HttpContext.Current.Request.ApplicationPath
        ''Else
        ''    ' serverpath = "http://termsmonitor.niitsmartserve.com"
        ''    ' serverpath = "http://TMhelpdesk.niit-tech.com"
        ''    '  serverpath = "http://ggn-nss-web1:7225"   ''publish
        ''    serverpath = System.Configuration.ConfigurationManager.AppSettings("LiveServerPath")

        ''End If


        Dim tbl As New HtmlTable
        'tbl.Attributes.Add("class", "menu")
        tbl.Width = "100%"
        tbl.Height = "300px"
        tbl.CellPadding = "4"
        tbl.CellSpacing = "4"
        tbl.Border = "1"
        tbl.BorderColor = "Active Border"

        Dim tr As HtmlTableRow
        Dim td As HtmlTableCell

        tr = New HtmlTableRow
        For Each row As DataRow In dt1.Rows

            td = New HtmlTableCell
            td.VAlign = "top"
            td.InnerHtml = "<fieldset><legend><b><span style='color: #000000;font-size: 15px;'>" & row.Item(0) & "</span></b></legend><table width='100%'>"
            For Each row1 As DataRow In dt.Select("displayname='" & row.Item(0) & "'")
                td.InnerHtml += "<tr><td align='left'><a href='" & serverpath & "/" & row1("shorturl") & "'>"
                td.InnerHtml += "<div class='item'><span class='left'>" & row1("name") & "</span></div></a></td>"
                If row1.Item(5) <> 0 Then
                    'td.InnerHtml += "<td><a href='sitemap.aspx?mode=rem&reportid=" & row1("ID") & "'><span class='right'><img src='../_assets/img/removefav.png' width='20px' height='20px' alt='Remove from favourite' /></span></a></td></tr>"
                    td.InnerHtml += "<td><a href='^Sitemap?mode=rem&reportid=" & row1("ID") & "'><span class='right'><img src='../_assets/img/removefav.png' width='20px' height='20px' alt='Remove from favourite' /></span></a></td></tr>"
                Else
                    ' td.InnerHtml += "<td><a href='sitemap.aspx?mode=add&reportid=" & row1("ID") & "'><span class='right'><img src='../_assets/img/fav.png' width='20px' height='20px' alt='Add to favourite' /></span></a></td></tr>"
                    td.InnerHtml += "<td><a href='^Sitemap?mode=add&reportid=" & row1("ID") & "'><span class='right'><img src='../_assets/img/fav.png' width='20px' height='20px' alt='Add to favourite' /></span></a></td></tr>"
                End If
            Next
            'td.InnerHtml += "</a>"
            td.InnerHtml += "</table></fieldset>"
            tr.Cells.Add(td)
        Next
        tbl.Rows.Add(tr)
        divmenu.Controls.Add(tbl)
    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            If Session("AgentID") <> "" Then
                AgentID = Session("AgentID")
                If Request.QueryString("mode") = "rem" And Not Request.QueryString("reportid") Is Nothing Then
                    RemoveFav()
                End If
                If Request.QueryString("mode") = "add" And Not Request.QueryString("reportid") Is Nothing Then
                    AddFav()
                End If
                '    '@old Menu
                '    ' FillMenu()

                'Responsive Menu
                ' AgentID = "NSS50689"
                Dim dt As DataTable = Me.GetData(AgentID, 0)
                PopulateMenu(dt, 0, Nothing)


            End If
        End If
    End Sub
    Private Sub RemoveFav()
        Dim db As New DBAccess
        db.slDataAdd("reportid", Request.QueryString("reportid"))
        db.slDataAdd("userid", AgentID)
        db.slDataAdd("mode", Request.QueryString("mode"))
        db.Executeproc("usp_RemoveFavReport")
        db = Nothing
    End Sub
    Private Sub AddFav()
        Dim db As New DBAccess
        db.slDataAdd("reportid", Request.QueryString("reportid"))
        db.slDataAdd("userid", AgentID)
        db.slDataAdd("mode", Request.QueryString("mode"))
        db.Executeproc("usp_RemoveFavReport")
        db = Nothing
    End Sub



    Private Function GetData(Aid As String, parentMenuId As Integer) As DataTable
        Dim db As New DBAccess("Report")
        db.slDataAdd("userid", Aid)
        db.slDataAdd("parentMenuId", parentMenuId)
        Dim dt As DataTable = db.ReturnTable("usp_User_Module_Report2", , True)
        db = Nothing

        Return dt
    End Function



    Private Sub PopulateMenu(dt As DataTable, parentMenuId As Integer, parentMenuItem As MenuItem)
        ' Dim currentPage As String = Path.GetFileName(Request.Url.AbsolutePath)

        Dim serverpath As String = ""

        'If Request.Url.Host = "localhost" Then
        '    serverpath = HttpContext.Current.Request.ApplicationPath
        'Else
        '    ' serverpath = "http://termsmonitor.niitsmartserve.com"
        '    ' serverpath = "http://TMhelpdesk.niit-tech.com"
        '    '  serverpath = "http://ggn-nss-web1:7225"   ''publish
        '    serverpath = System.Configuration.ConfigurationManager.AppSettings("LiveServerPath")

        'End If

        Dim currentPage As String = serverpath

        For Each row As DataRow In dt.Rows
            Dim menuItem As New MenuItem() With {
            .Value = row("MenuId").ToString(),
            .Text = row("Title").ToString(),
            .NavigateUrl = serverpath & "/" & row("Url").ToString(),
            .Selected = row("Url").ToString().EndsWith(currentPage, StringComparison.CurrentCultureIgnoreCase)
        }
            If parentMenuId = 0 Then
                Menu1.Items.Add(menuItem)
                Dim dtChild As DataTable = Me.GetData(AgentID, Integer.Parse(menuItem.Value))
                PopulateMenu(dtChild, Integer.Parse(menuItem.Value), menuItem)
            Else
                parentMenuItem.ChildItems.Add(menuItem)
                If parentMenuId > 0 Then
                    Dim dtChild As DataTable = Me.GetData(AgentID, Integer.Parse(menuItem.Value))
                    PopulateMenu(dtChild, Integer.Parse(menuItem.Value), menuItem)
                End If
            End If
        Next
    End Sub

End Class
