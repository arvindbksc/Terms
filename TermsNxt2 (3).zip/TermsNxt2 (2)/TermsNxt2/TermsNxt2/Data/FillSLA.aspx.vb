﻿Imports com.nss.DBAccess
Imports System.Data
Partial Class Data_FillSLA
    Inherits System.Web.UI.Page
#Region "Properties"

    Property dtsummary() As DataTable
        Get
            Return ViewState("dtSummary")
        End Get
        Set(ByVal value As DataTable)
            ViewState("dtSummary") = value
        End Set
    End Property
    Property SupervisorID() As String
        Get
            Return ViewState("SupervisorID")
        End Get
        Set(ByVal value As String)
            ViewState("SupervisorID") = value
        End Set
    End Property
    Property TransID() As Integer
        Get
            Return ViewState("TransID")
        End Get
        Set(ByVal value As Integer)
            ViewState("TransID") = value
        End Set
    End Property
    Property UserID() As String
        Get
            Return ViewState("UserID")
        End Get
        Set(ByVal value As String)
            ViewState("UserID") = value
        End Set
    End Property

    Property CampaignID() As Integer
        Get
            Return 0 'ViewState("CampaignID")
        End Get
        Set(ByVal value As Integer)
            'ViewState("CampaignID") = value
            'Session("CampaignID") = value
        End Set
    End Property

    Property ProcessID() As Integer
        Get
            Return ViewState("ProcessID")
        End Get
        Set(ByVal value As Integer)
            ViewState("ProcessID") = value
            Session("ProcessID") = value
        End Set
    End Property
    Property AgentID() As String
        Get
            Return ViewState("AgentID")
        End Get
        Set(ByVal value As String)
            ViewState("AgentID") = value
        End Set
    End Property
    Property UsrID() As Integer
        Get
            Return ViewState("UsrID")
        End Get
        Set(ByVal value As Integer)
            ViewState("UsrID") = value
        End Set
    End Property
    Property LoginID() As Integer
        Get
            Return ViewState("LoginID")
        End Get
        Set(ByVal value As Integer)
            ViewState("LoginID") = value
        End Set
    End Property
    Property CurrentDate() As Date
        Get
            Return ViewState("CurrentDate")
        End Get
        Set(ByVal value As Date)
            ViewState("CurrentDate") = value
        End Set
    End Property
    Property IncentiveMonth() As String
        Get
            Return ViewState("IncentiveMonth")
        End Get
        Set(ByVal value As String)
            ViewState("IncentiveMonth") = value
        End Set
    End Property
    Property IncentiveYear() As Integer
        Get
            Return ViewState("IncentiveYear")
        End Get
        Set(ByVal value As Integer)
            ViewState("IncentiveYear") = value
        End Set
    End Property
    Property IsAdmin() As Boolean
        Get
            Return ViewState("IsAdmin")
        End Get
        Set(ByVal value As Boolean)
            ViewState("IsAdmin") = value
        End Set
    End Property
    Property MinDate() As Date
        Get
            Return ViewState("MinDate")
        End Get
        Set(ByVal value As Date)
            ViewState("MinDate") = value
        End Set
    End Property
    Property AchievementValue() As String
        Get
            Return ViewState("AchievementValue")
        End Get
        Set(ByVal value As String)
            ViewState("AchievementValue") = value
        End Set
    End Property
    Property TargetValue() As String
        Get
            Return ViewState("TargetValue")
        End Get
        Set(ByVal value As String)
            ViewState("TargetValue") = value
        End Set
    End Property
#End Region
#Region "Load"
    Private Sub LoadData()
        FillProcessCampaigns()
        Dim db As New DBAccess("CRM")
        Dim dr As DataRow = db.ReturnRow("SELECT getdate() as currentdate  FROM [tbl_LastFreezedDate]")
        CurrentDate = dr("currentDate")
        db = Nothing
        ucDateFrom.value = DateTime.Now.AddDays(-1)
    End Sub
    Private Sub FillProcessCampaigns()
        Common.FillProcessCampaigns(CboProcess, cboCampaigns, AgentID, CampaignID)
        Dim lstCamp As New ListItem
        lstCamp.Value = 0
        lstCamp.Text = "All"
        If cboCampaigns.Items.Contains(lstCamp) Then
            cboCampaigns.Items.Remove(lstCamp)
        End If
    End Sub
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        HumanMessage.Style.Item("visibility") = "hidden"
        If Not IsPostBack Then
            If Session("AgentID") <> "" Then
                'CampaignID = cboCampaigns.SelectedValue
                AgentID = Session("AgentID")
                LoadData()
                PanelReports.Controls.Add(Common.GetMenu(Request.Url, AgentID, Request.ApplicationPath))
                ucDateFrom.Visible = True
                fillgrid()
            End If

        End If
    End Sub
#End Region
#Region "date movement"
    Private Function validdate(ByVal selecteddate As DateTime) As Boolean
        If selecteddate > CurrentDate Then
            Return False
        End If
        Return True
    End Function
#End Region
#Region "gridops"
    Private Sub fillgrid()
        Dim db As New DBAccess("CRM")
        Dim dt As DataTable
        db.slDataAdd("Campaignid", cboCampaigns.SelectedValue)
        db.slDataAdd("SLADate", ucDateFrom.yyyymmdd)
        dt = db.ReturnTable("usp_ShowSLA", , True)
        db = Nothing
        dt.Columns.Add("Target1")
        'dt.Columns.Add("Achievement1")

        If dt.Rows.Count > 0 Then
            db = New DBAccess("CRM")
            Dim dt1 As DataTable
            dt1 = db.ReturnTable("select top 1 * FROM tbl_Data_DailyCampaignSLA_Mst where Campaignid =" & cboCampaigns.SelectedValue & " and [Date]=" & ucDateFrom.yyyymmdd, False)
            db = Nothing
            If dt1.Rows.Count = 0 Then

                dt.Columns("Target1").DefaultValue = ""
                'dt.Columns("Achievement1").DefaultValue = ""
                db = New DBAccess("crm")
                Dim dt2 As DataTable
                db.slDataAdd("Campaignid", cboCampaigns.SelectedValue)
                db.slDataAdd("SLADate", ucDateFrom.yyyymmdd)
                dt2 = db.ReturnTable("usp_getPreviousDaySLATarget", , True)
                db = Nothing
                For Each row1 As DataRow In dt.Rows
                    If dt2.Select("SLAID='" & row1.Item("SLAID") & "'").Length > 0 Then
                        row1.Item("Target1") = IIf(IsDBNull(dt2.Select("SLAID='" & row1.Item("SLAID") & "'")(0).Item("Target")), "N/A", dt2.Select("SLAID='" & row1.Item("SLAID") & "'")(0).Item("Target"))
                        'row1.Item("Achievement1") = IIf(IsDBNull(dt2.Select("SLAID='" & row1.Item("SLAID") & "'")(0).Item("Achievement")), "", dt2.Select("SLAID='" & row1.Item("SLAID") & "'")(0).Item("Achievement"))
                    End If
                Next
            Else
                dt.Columns("Target1").DefaultValue = "N/A"
                'dt.Columns("Achievement1").DefaultValue = ""
                For Each row As DataRow In dt.Rows
                    row.Item("Target1") = IIf(IsDBNull(row.Item("Target")), "N/A", row.Item("Target"))
                    'row.Item("Achievement1") = IIf(IsDBNull(row.Item("Achievement")), "", row.Item("Achievement"))
                Next
                txtComment.Text = dt1.Rows(0)(2).ToString()
                txtactionstep.Text = dt1.Rows(0)(3).ToString()
            End If
        End If
        dt.Columns.Remove("Target")
        'dt.Columns.Remove("Achievement")
        db = Nothing

        If dt.Rows.Count > 0 Then
           
            GridView1.DataSource = dt
            GridView1.DataBind()

            lblReportName.Text = "Fill SLA for " & cboCampaigns.SelectedItem.Text
            db = New DBAccess("crm")
            db.slDataAdd("Campaignid", cboCampaigns.SelectedValue)
            db.slDataAdd("SLADate", ucDateFrom.yyyymmdd)
            Dim isfrozen As Boolean = db.ReturnValue("usp_SLA_IsFrozen", True)
            GridView1.Enabled = Not isfrozen
            btnsave.Enabled = Not isfrozen
            txtComment.Enabled = Not isfrozen
            txtactionstep.Enabled = Not isfrozen
            If isfrozen Then
                GridView1.BackImageUrl = "~/_assets/img/Frozen.JPG"
            Else
                GridView1.BackImageUrl = ""
            End If
        Else
            btnsave.Enabled = False
            txtComment.Enabled = False
            txtactionstep.Enabled = False
            GridView1.DataSource = Nothing
            GridView1.DataBind()
        End If
        dt = Nothing
    End Sub
    Protected Sub GridView1_RowDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles GridView1.RowDataBound
        If e.Row.RowType = DataControlRowType.DataRow Then
            If CType(e.Row.FindControl("hdIsSLA"), HiddenField).Value.ToLower = "false" And CType(e.Row.FindControl("hdformula"), HiddenField).Value = "" Then
                CType(e.Row.FindControl("txtAchievement"), TextBox).Enabled = True
                CType(e.Row.FindControl("txtTarget"), TextBox).Enabled = False
            ElseIf CType(e.Row.FindControl("hdIsSLA"), HiddenField).Value.ToLower = "true" And CType(e.Row.FindControl("hdformula"), HiddenField).Value = "" Then
                CType(e.Row.FindControl("txtAchievement"), TextBox).Enabled = True
                CType(e.Row.FindControl("txtTarget"), TextBox).Enabled = True
            ElseIf CType(e.Row.FindControl("hdIsSLA"), HiddenField).Value.ToLower = "true" And CType(e.Row.FindControl("hdformula"), HiddenField).Value <> "" Then
                CType(e.Row.FindControl("txtAchievement"), TextBox).Enabled = False
                CType(e.Row.FindControl("txtTarget"), TextBox).Enabled = True
            End If
            If CType(e.Row.FindControl("txtTarget"), TextBox).Enabled = False Then
                If CType(e.Row.FindControl("txtTarget"), TextBox).Text.Trim.ToUpper = "N/A" Or CType(e.Row.FindControl("txtTarget"), TextBox).Text.Trim.ToUpper = "" Then
                    CType(e.Row.FindControl("txtTarget"), TextBox).Text = "N/A"
                End If
            End If
            
        End If
    End Sub
#End Region
#Region "Event"

    Protected Sub btnsave_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnsave.Click
        SaveMetricsDetails()
    End Sub

    Protected Sub btnRefresh_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnRefresh.Click
        fillgrid()
    End Sub
    Protected Sub cboCampaigns_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboCampaigns.SelectedIndexChanged
        fillgrid()
    End Sub
    Protected Sub ucDateFrom_Changed(ByVal sender As Object, ByVal e As System.EventArgs) Handles ucDateFrom.Changed
        If validdate(ucDateFrom.value) Then
            fillgrid()
        Else
            AlertMessage("Date not in valid range")
            ucDateFrom.value = DateTime.Now.AddDays(-1)
            fillgrid()
        End If

        'fillgrid()
    End Sub
    Protected Sub imgfav_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles imgfav.Click
        Common.AddToFav(AgentID, "Fill SLA")
        SuccessMessage("Fill SLA has been added to your favourite list")
        fillgrid()
    End Sub
#End Region
#Region "Utility"

    Private Sub AlertMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMFail"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub

    Private Sub SuccessMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMSuccess"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub
    Public Overrides Sub VerifyRenderingInServerForm(ByVal Control As Control)

    End Sub
#End Region
#Region "Support Function"
    Private Sub SaveMetricsDetails()
        Dim db As New DBAccess("CRM")
        Dim gridrow As GridViewRow
        Dim txtTarget As TextBox, txtAchievement As TextBox
        Dim lblAchievement As Label
        Dim hdformat As HiddenField
        db.BeginTrans()
        Try
            For Each gridrow In GridView1.Rows
                txtTarget = CType(gridrow.FindControl("txtTarget"), TextBox)
                txtAchievement = CType(gridrow.FindControl("txtAchievement"), TextBox)
                lblAchievement = CType(gridrow.FindControl("lblSLA"), Label)
                hdformat = CType(gridrow.FindControl("hdformat"), HiddenField)
                'If txtTarget.Enabled = True And txtTarget.Text = "" Then
                '    AlertMessage("Please enter the Target")
                '    Exit Sub
                'End If
                TargetValue = txtTarget.Text
                AchievementValue = txtAchievement.Text
                If txtAchievement.Enabled = True And txtAchievement.Text = "" Then
                    AlertMessage("Please enter the Achievement for " & lblAchievement.Text)
                    db.RollBackTrans()
                    db = Nothing
                    Exit Sub
                End If
                If txtTarget.Text.Trim.ToUpper = "N/A" Or txtTarget.Text.Trim.ToUpper = "" Then
                    txtTarget.Text = ""
                    TargetValue = ""
                End If
                If txtAchievement.Text.Trim.ToUpper = "N/A" Or txtAchievement.Text.Trim.ToUpper = "" Then
                    txtAchievement.Text = ""
                    AchievementValue = ""
                End If
                If hdformat.Value.ToString.ToLower = "time" Then
                    If txtAchievement.Enabled = True And Not txtAchievement.Text.Trim.ToString.Contains(":") Then
                        AlertMessage("Achievement for " & lblAchievement.Text & " should be in hh:mm:ss format")
                        db.RollBackTrans()
                        db = Nothing
                        Exit Sub
                    End If
                    If txtTarget.Enabled = True And Not txtTarget.Text.Trim.ToString.Contains(":") Then
                        AlertMessage("Target for " & lblAchievement.Text & " should be in hh:mm:ss format")
                        db.RollBackTrans()
                        db = Nothing
                        Exit Sub
                    End If
                End If
                ' If lblAchievement.Text.Trim.ToString.ToLower.Contains("login hours") Then
                If hdformat.Value.ToString.ToLower = "time" Then
                    Dim Achievement() As String
                    Dim target() As String
                    If txtAchievement.Enabled = True Then
                        Achievement = txtAchievement.Text.Trim.Split(":")
                        If Achievement.Length <> 3 Then
                            AlertMessage("Please insert correct Achievement for " & lblAchievement.Text)
                            db.RollBackTrans()
                            db = Nothing
                            Exit Sub
                        Else
                            'txtAchievement.Text = (Math.Round((Convert.ToInt64(Achievement(0)) * 3600 + Convert.ToInt64(Achievement(1)) * 60 + Convert.ToInt64(Achievement(2))), 2)).ToString()
                            AchievementValue = (Math.Round((Convert.ToInt64(Achievement(0)) * 3600 + Convert.ToInt64(Achievement(1)) * 60 + Convert.ToInt64(Achievement(2))), 2)).ToString()
                        End If
                    End If
                    If txtTarget.Enabled = True And txtTarget.Text <> "" Then
                        target = txtTarget.Text.Trim.Split(":")
                        If target.Length <> 3 Then
                            AlertMessage("Please insert correct target for " & lblAchievement.Text)
                            db.RollBackTrans()
                            db = Nothing
                            Exit Sub
                        Else
                            'txtTarget.Text = (Math.Round((Convert.ToInt64(target(0)) * 3600 + Convert.ToInt64(target(1)) * 60 + Convert.ToInt64(target(2))), 2)).ToString()
                            TargetValue = (Math.Round((Convert.ToInt64(target(0)) * 3600 + Convert.ToInt64(target(1)) * 60 + Convert.ToInt64(target(2))), 2)).ToString()
                        End If
                    End If

                    'ElseIf loginhour.Length = 2 Then
                    '    txtAchievement.Text = (Math.Round((Convert.ToInt64(loginhour(0)) * 3600 + Convert.ToInt64(loginhour(1)) * 60) / 3600.0, 2)).ToString()
                    'ElseIf loginhour.Length = 1 Then
                    '    txtAchievement.Text = (Convert.ToInt64(loginhour(0))).ToString()
                    'End If
                End If
                ' End If

                If txtAchievement.Enabled = True Then
                    'If Not IsNumeric(txtAchievement.Text) Then
                    If Not IsNumeric(AchievementValue) Then
                        AlertMessage("Achievement should be numeric for " & lblAchievement.Text)
                        db.RollBackTrans()
                        db = Nothing
                        Exit Sub
                    End If
                    If AchievementValue.Contains(",") Then
                        AlertMessage("Achievement should be numeric for " & lblAchievement.Text)
                        db.RollBackTrans()
                        db = Nothing
                        Exit Sub
                    End If
                End If
                If txtTarget.Enabled = True And txtTarget.Text <> "" Then
                    'If Not IsNumeric(txtTarget.Text) Then
                    If Not IsNumeric(TargetValue) Then
                        AlertMessage("Target should be numeric for " & lblAchievement.Text)
                        db.RollBackTrans()
                        db = Nothing
                        Exit Sub
                    End If
                    If TargetValue.Contains(",") Then
                        AlertMessage("Target should be numeric for " & lblAchievement.Text)
                        db.RollBackTrans()
                        db = Nothing
                        Exit Sub
                    End If
                End If


                'If IsNumeric(txtAchievement.Text) And IsNumeric(txtTarget.Text) Then
                db.slDataAdd("UserID", AgentID)
                db.slDataAdd("CampaignID", cboCampaigns.SelectedValue)
                db.slDataAdd("SLAID", CType(gridrow.FindControl("hdSLAID"), HiddenField).Value)
                db.slDataAdd("Target", TargetValue) ' txtTarget.Text.Trim.ToString())
                db.slDataAdd("Achievement", AchievementValue) ' txtAchievement.Text.Trim.ToString())
                db.slDataAdd("SLADate", ucDateFrom.yyyymmdd)
                db.slDataAdd("Comments", txtComment.Text.Trim)
                db.slDataAdd("ActionSteps", txtactionstep.Text.Trim)
                db.slDataAdd("SLAFormula", CType(gridrow.FindControl("hdformula"), HiddenField).Value)
                db.Executeproc("usp_InsertSLADetails")
                'Else
                'AlertMessage("Achievement and Target should be numeric")

                '  End If

            Next
            db.CommitTrans()
            db = Nothing
            SuccessMessage("Data has been saved")
            fillgrid()
        Catch ex As Exception
            db.RollBackTrans()
            db = Nothing
            AlertMessage(ex.Message.ToString)
        Finally
            db = Nothing
        End Try
    End Sub
   
#End Region

    
End Class
