﻿Imports com.nss.DBAccess
Imports System.Data
Imports System.Text
Partial Class Data_updates
    Inherits System.Web.UI.Page
#Region "--- Properties --- "
    Property CampaignID() As Integer
        Get
            Return ViewState("CampaignID")
        End Get
        Set(ByVal value As Integer)
            ViewState("CampaignID") = value
        End Set
    End Property
    Property AgentID() As String
        Get
            Return ViewState("AgentID")
        End Get
        Set(ByVal value As String)
            ViewState("AgentID") = value
        End Set
    End Property
#End Region

#Region "--- Load Functions --- "
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            If Session("AgentID") <> "" Then
                CampaignID = Session("CampaignID")
                AgentID = Session("AgentID")
                PanelReports.Controls.Add(Common.GetMenu(Request.Url, AgentID, Request.ApplicationPath))
                FillProcessCampaigns()
                GetUpdates()
            End If
        Else
            PanelReports.Controls.Add(Common.GetMenu(Request.Url, AgentID, Request.ApplicationPath))
        End If
    End Sub
    Private Sub FillProcessCampaigns()
        Common.FillProcessCampaigns(CboProcess, cboCampaigns, AgentID, CampaignID)
        Dim lstCamp As New ListItem
        lstCamp.Value = 0
        lstCamp.Text = "All"
        If cboCampaigns.Items.Contains(lstCamp) Then
            cboCampaigns.Items.Remove(lstCamp)
        End If
    End Sub
#End Region

#Region "--- Functions --- "
    Private Sub GetUpdates()
        Dim db As New DBAccess("CRM")
        db.slDataAdd("CampaignID", cboCampaigns.SelectedValue)
        Dim updates As String = db.ReturnValue("usp_GetUpdates", True)
        If updates <> "" Then
            txtupate.InnerHtml = updates
        Else
            txtupate.InnerHtml = ""
        End If
        db = Nothing
    End Sub
    Private Sub SaveUpdates()
        Dim db As New DBAccess("CRM")
        db.slDataAdd("CampaignID", cboCampaigns.SelectedValue)
        db.slDataAdd("Updates", txtupate.InnerHtml.ToString.Replace("&lt;", "<").Replace("&gt;", ">").Replace("&amp;nbsp;", " ").Trim)
        db.Executeproc("usp_SaveCRMUpdates")
        db = Nothing
    End Sub
#End Region

#Region "--- Events --- "
    Protected Sub btnUpdate_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnUpdate.Click
        SaveUpdates()
    End Sub
    Protected Sub cboCampaigns_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboCampaigns.SelectedIndexChanged
        GetUpdates()
    End Sub
    Protected Sub btnReset_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnReset.Click
        GetUpdates()
    End Sub
#End Region
End Class
