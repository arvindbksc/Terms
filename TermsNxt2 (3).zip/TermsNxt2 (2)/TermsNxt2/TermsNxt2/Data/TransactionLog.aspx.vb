﻿Imports com.nss.DBAccess
Imports System.Data
Imports System.Text
Partial Class Data_TransactionLog
    Inherits System.Web.UI.Page
#Region "Properties"

    Property ProcessID() As Integer
        Get
            Return ViewState("ProcessID")
        End Get
        Set(ByVal value As Integer)
            ViewState("ProcessID") = value
            Session("ProcessID") = value
        End Set
    End Property
    Property Campaigntype() As Integer
        Get
            Return ViewState("Campaigntype")
        End Get
        Set(ByVal value As Integer)
            ViewState("Campaigntype") = value
            'Session("ProcessID") = value
        End Set
    End Property
    Property ReportType() As Integer
        Get
            Return ViewState("ReportType")
        End Get
        Set(ByVal value As Integer)
            ViewState("ReportType") = value
        End Set
    End Property
    Property CampaignID() As Integer
        Get
            Return ViewState("CampaignID")
        End Get
        Set(ByVal value As Integer)
            ViewState("CampaignID") = value
        End Set
    End Property

    Property AgentID() As String
        Get
            Return ViewState("AgentID")
        End Get
        Set(ByVal value As String)
            ViewState("AgentID") = value
        End Set
    End Property
#End Region
#Region "Load Data"
    Private Sub LoadData()
        FillCommonFilters()
        FillProcessCampaigns()
        PopulateAgents()
    End Sub
#End Region
#Region "Load Functions"
    Private Sub FillCommonFilters()
        Dim db As New DBAccess
        Dim dt As DataTable = db.ReturnTable("select * from tbl_Reports_DatePeriods where period in (0,1)")
        db = Nothing
        Dim dr As DataRow = dt.NewRow
        dr(0) = 10
        dr(1) = "On"
        dt.Rows.Add(dr)
        CboPeriod.DataTextField = "Caption"
        CboPeriod.DataValueField = "Period"
        CboPeriod.DataSource = dt
        CboPeriod.DataBind()
    End Sub
    Private Sub FillProcessCampaigns()
        Common.FillProcessCampaigns(CboProcess, cboCampaigns, AgentID, CampaignID)
        Dim lstCamp As New ListItem
        lstCamp.Value = 0
        lstCamp.Text = "All"
        If cboCampaigns.Items.Contains(lstCamp) Then
            cboCampaigns.Items.Remove(lstCamp)
        End If
    End Sub
    Private Sub PopulateAgents()
        Try
            Dim db As New DBAccess("CRM")
            db.slDataAdd("campaignid", CampaignID)
            Dim dt As DataTable = db.ReturnTable("usp_GetAgentsOfTheProcess", "", True)
            cboFilterBy.DataSource = Nothing
            cboFilterBy.DataTextField = "Agent Name"
            cboFilterBy.DataValueField = "agentid"
            cboFilterBy.DataSource = dt
            cboFilterBy.DataBind()
            db = Nothing
            dt = Nothing
            Dim lstagent As New ListItem
            lstagent.Value = "%"
            lstagent.Text = "All"
            cboFilterBy.Items.Add(lstagent)
            cboFilterBy.SelectedValue = "%"
        Catch ex As Exception
            'AlertMessage(ex.Message.ToString)
            LblError.Visible = True
            LblError.Text = ex.Message.ToString
        End Try
    End Sub
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        HumanMessage.Style.Item("visibility") = "hidden"
        If Not IsPostBack Then
            ReportType = Request.QueryString("ReportType")
            If Session("AgentID") <> "" Then
                CampaignID = Session("CampaignID")
                AgentID = Session("AgentID")
                PanelReports.Controls.Add(Common.GetMenu(Request.Url, AgentID, Request.ApplicationPath))
                LoadData()
                fillgrid()
                'UcDateTo.Visible = False
                ucDateFrom.Visible = False
                ' lblAnd.Visible = False
            End If
        End If
    End Sub
    Dim TIdle As Integer = 0
    Dim TTrans As Integer = 0
    Private Sub fillgrid()
        'Dim columns As String
        Dim db As New DBAccess
        Dim startday As Integer, endday As Integer
        If CboPeriod.SelectedValue = 10 Then
            startday = ucDateFrom.yyyymmdd
            'endday = UcDateTo.yyyymmdd
        Else
            db = New DBAccess
            db.slDataAdd("Period", CboPeriod.SelectedValue)
            db.slDataAdd("Campaignid", CampaignID)
            Dim dr As DataRow = db.ReturnRow("usp_GetStart_EndDateForAPeriod", True)
            db = Nothing
            startday = dr(0)
            'endday = dr(1)
        End If
        db = New DBAccess

        Dim dt As DataTable
        db.slDataAdd("startday", startday)
        'db.slDataAdd("endDay", endday)
        db.slDataAdd("campaignid", CampaignID)
        db.slDataAdd("agentid", cboFilterBy.SelectedValue)
        dt = db.ReturnTable("usp_getTransactionLog", , True)
        db = Nothing
        lblReportName.Text = "Transaction Log Summary "
        LblError.Text = "On " & IntegerToDateString(startday) & " for " & cboCampaigns.SelectedItem.Text & " campaign"

        If dt.Rows.Count > 0 Then
            dt.Rows(0).Item(4) = ""
            For m As Integer = 1 To dt.Rows.Count - 1
                If (dt.Rows(m).Item(0) <> dt.Rows(m - 1).Item(0)) Then
                    dt.Rows(m).Item(4) = ""
                Else
                    TIdle = TIdle + DateDiff(DateInterval.Second, dt.Rows(m - 1).Item(3), dt.Rows(m).Item(2))
                    dt.Rows(m).Item(4) = TimeString(DateDiff(DateInterval.Second, dt.Rows(m - 1).Item(3), dt.Rows(m).Item(2)))
                End If

                If dt.Rows(m).Item(1).ToString.ToLower <> "break" Then
                    TTrans = TTrans + 1
                    'dt.Rows(m).Item(4) = ""
                End If
            Next
            GridView1.DataSource = dt
            GridView1.DataBind()
            dt = Nothing
            ScriptManager.RegisterStartupScript(Me, Me.GetType(), "SortGrid", "$(function(){{$('#" & GridView1.ClientID & "').tablesorter({cancelSelection:true}); }});", True)
        End If
    End Sub
#End Region
#Region "Events"
    Protected Sub cboCampaigns_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboCampaigns.SelectedIndexChanged
        CampaignID = cboCampaigns.SelectedValue
        PopulateAgents()
        fillgrid()
    End Sub
    Protected Sub CboPeriod_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles CboPeriod.SelectedIndexChanged
        If CboPeriod.SelectedValue = 10 Then
            ucDateFrom.Visible = True
            'UcDateTo.Visible = True
            'lblAnd.Visible = True
            fillgrid()
        Else
            ucDateFrom.Visible = False
            'UcDateTo.Visible = False
            'lblAnd.Visible = False
            fillgrid()
        End If
    End Sub
    Protected Sub ImageButton1_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton1.Click
        fillgrid()
        GridViewExportUtil.Export(lblReportName.Text & "-" & LblError.Text & ".xls", Me.GridView1)
    End Sub
    'Protected Sub btnFilter_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnFilter.Click
    '    fillgrid()

    'End Sub
    Protected Sub btnRefresh_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnRefresh.Click
        fillgrid()
    End Sub
    Protected Sub imgfav_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles imgfav.Click
        Common.AddToFav(AgentID, "Transaction Log Summary")
        SuccessMessage("Report has been added to your favourite list")
        fillgrid()
    End Sub
#End Region
#Region "Support Functions"
    Private Function IntegerToDateString(ByVal d As Integer) As String
        Return d.ToString.Substring(0, 4) & "-" & d.ToString.Substring(4, 2) & "-" & d.ToString.Substring(6, 2)
    End Function
    Public Function TimeString(ByVal Seconds As Long) As String

        'if verbose = false, returns
        'something like
        '02:22.08
        'if true, returns
        '2 hours, 22 minutes, and 8 seconds

        Dim lHrs As Long
        Dim lMinutes As Long
        Dim lSeconds As Long

        lSeconds = Seconds

        lHrs = Int(lSeconds / 3600)
        lMinutes = (Int(lSeconds / 60)) - (lHrs * 60)
        lSeconds = Int(lSeconds Mod 60)

        If lSeconds = 60 Then
            lMinutes = lMinutes + 1
            lSeconds = 0
        End If

        If lMinutes = 60 Then
            lMinutes = 0
            lHrs = lHrs + 1
        End If

        TimeString = lHrs.ToString("####00") & ":" & _
        lMinutes.ToString("00") & ":" & _
         lSeconds.ToString("00")

    End Function
    
   
#End Region
#Region "Utility"

    Private Sub AlertMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMFail"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub

    Private Sub SuccessMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMSuccess"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub

    'Protected Sub ImageButton1_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton1.Click
    '    'fillgrid()
    '    GridViewExportUtil.Export(lblReportName.CurrentPage & "-" & LblError.Text & ".xls", Me.GdAttendance)
    'End Sub


    Public Overrides Sub VerifyRenderingInServerForm(ByVal Control As Control)

    End Sub

#End Region

    Protected Sub cboFilterBy_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboFilterBy.SelectedIndexChanged
        fillgrid()
    End Sub

    Protected Sub GridView1_PreRender(ByVal sender As Object, ByVal e As System.EventArgs) Handles GridView1.PreRender
        If Not GridView1 Is Nothing Then
            If GridView1.HeaderRow Is Nothing Then
            Else
                GridView1.HeaderRow.TableSection = TableRowSection.TableHeader
                GridView1.FooterRow.TableSection = TableRowSection.TableFooter
            End If
        End If
    End Sub

    Protected Sub GridView1_RowDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles GridView1.RowDataBound
        If e.Row.RowType = DataControlRowType.Footer Then
            e.Row.Cells(0).Text = "Total:-"
            e.Row.Cells(1).Text = "Transactions"
            e.Row.Cells(2).Text = TTrans
            e.Row.Cells(4).Text = "Idle Time"
            e.Row.Cells(5).Text = TimeString(TIdle)
        End If
    End Sub
End Class
