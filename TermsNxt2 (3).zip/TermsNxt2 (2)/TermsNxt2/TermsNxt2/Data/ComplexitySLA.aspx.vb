﻿Imports com.nss.DBAccess
Imports System.Data
Imports System.Web.UI.DataVisualization.Charting
Imports System.Drawing

Partial Class PerfSum_GordonDashboard
    Inherits System.Web.UI.Page

#Region "--- Properties ---"
    Property ProcessID() As Integer
        Get
            Return ViewState("ProcessID")
        End Get
        Set(ByVal value As Integer)
            ViewState("ProcessID") = value
            Session("ProcessID") = value
        End Set
    End Property
    Property CampaignID() As Integer
        Get
            Return ViewState("CampaignID")
        End Get
        Set(ByVal value As Integer)
            ViewState("CampaignID") = value
            Session("CampaignID") = value
        End Set
    End Property
    Property AgentID() As String
        Get
            Return ViewState("AgentID")
        End Get
        Set(ByVal value As String)
            ViewState("AgentID") = value
        End Set
    End Property
#End Region

    Dim dtData As DataTable

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        HumanMessage.Style.Item("visibility") = "hidden"
        If Not IsPostBack Then
            If Session("agentid") Is Nothing Then
                FormsAuthentication.SignOut()
            End If
            'Session("AgentID") = "NSS51102"
            If Session("AgentID") <> "" Then
                'BindGroupByMembers()
                CampaignID = Session("CampaignID")
                AgentID = Session("AgentID")
                LoadData()
                FillData()
                UcDateTo.Visible = False
                ucDateFrom.Visible = False
                lblAnd.Visible = False
                PanelReports.Controls.Add(Common.GetMenu(Request.Url, AgentID, Request.ApplicationPath))
            End If
        End If
    End Sub

#Region "--- Functions ---"
    Private Sub LoadData()
        FillCommonFilters()
        FillProcessCampaigns()
    End Sub
    Private Sub FillCommonFilters()
        Dim db As New DBAccess
        Dim dt As DataTable = db.ReturnTable("select * from tbl_Reports_DatePeriods")
        db = Nothing
        Dim dr As DataRow = dt.NewRow
        dr(0) = 10
        dr(1) = "Between"
        dt.Rows.Add(dr)
        CboPeriod.DataTextField = "Caption"
        CboPeriod.DataValueField = "Period"
        CboPeriod.DataSource = dt
        CboPeriod.DataBind()

        db = New DBAccess
        dt = db.ReturnTable("Select * from tbl_Reports_GroupBy")
        db = Nothing
    End Sub

    Private Sub FillProcessCampaigns()
        Common.FillProcesses(CboProcess, AgentID)
        'Common.FillProcessCampaigns(CboProcess, cboCampaigns, AgentID, CampaignID)
        Dim lstprocess As New ListItem
        lstprocess.Value = 0
        lstprocess.Text = "All"
        If CboProcess.Items.Contains(lstprocess) Then
            CboProcess.Items.Remove(lstprocess)
        End If
        Dim db As New DBAccess
        db.slDataAdd("Agentid", AgentID)
        CboProcess.SelectedValue = db.ReturnRow("usp_getAgentProcess", True)(4)
        db = Nothing
        Common.FillCampaigns(cboCampaigns, AgentID, CboProcess.SelectedValue)

        Dim removeItem As ListItem = cboCampaigns.Items.FindByValue("0")
        cboCampaigns.Items.Remove(removeItem)

    End Sub

    Private Function IntegerToDateString(ByVal d As Integer) As String
        Return d.ToString.Substring(0, 4) & "-" & d.ToString.Substring(4, 2) & "-" & d.ToString.Substring(6, 2)
    End Function

    Private Sub FillData()
        'If cboGroupMembers.SelectedItem.Text = "--Select--" Then
        '    Exit Sub
        'End If
        '------------------
        Dim db As New DBAccess
        Dim startday As Integer, endday As Integer
        Dim sdate, edate As DateTime
        If CboPeriod.SelectedValue = 10 Then
            startday = ucDateFrom.yyyymmdd
            endday = UcDateTo.yyyymmdd
            sdate = ucDateFrom.value
            edate = UcDateTo.value
        Else
            db = New DBAccess
            db.slDataAdd("Period", CboPeriod.SelectedValue)
            'db.slDataAdd("Campaignid", 281)
            db.slDataAdd("Campaignid", cboCampaigns.SelectedValue)
            Dim dr As DataRow = db.ReturnRow("usp_GetStart_EndDateForAPeriod", True)
            db = Nothing
            startday = dr(0)
            endday = dr(1)
            sdate = IntegerToDateString(startday)
            edate = IntegerToDateString(endday)
            ' ChartPeriod = DateDiff(DateInterval.Day, sdate, edate)
        End If
        db = Nothing
        '----------------- 
        db = New DBAccess("Leads")

        db.slDataAdd("DateFrom", startday)
        db.slDataAdd("DateTo", endday)
        'db.slDataAdd("campaignid", 281)
        db.slDataAdd("campaignid", CampaignID)
        db.slDataAdd("inputType", cboComplexitySLA.SelectedValue)

        dtData = db.ReturnTable("usp_Morris_ComplexityAndSLA", , True)
        db = Nothing

        LblError.Text = "Between " & IntegerToDateString(startday) & "  and " & IntegerToDateString(endday)
        '-------------------------------------------
        If dtData.Rows.Count > 0 Then
            If cboComplexitySLA.SelectedValue = "complexity" Then
                lblReportName.Text = "Complexity"
                Dim dr2 As DataRow = dtData.NewRow

                Dim sumAdCount As Integer = 0, sumOnTime As Integer = 0, sumlate As Integer = 0

                For Each row As DataRow In dtData.Rows
                    row("Late") = CDbl(row("AdCount")) - CDbl(row("OnTime"))

                    If row("AdCount") = 0 Then
                        row("OnTime% AS Per Complexity") = 0
                    Else
                        row("OnTime% AS Per Complexity") = Math.Round(CDbl(row("OnTime")) * 100.0 / CDbl(row("AdCount")), 2)
                    End If

                    sumAdCount += row("AdCount")
                    sumOnTime += row("OnTime")
                    sumlate += row("Late")
                Next

                dr2("Complexity") = "Total="
                dr2("AdCount") = sumAdCount
                dr2("OnTime") = sumOnTime
                dr2("Late") = sumlate

                If dr2("AdCount") = 0 Then
                    dr2("OnTime% AS Per Complexity") = 0
                Else
                    dr2("OnTime% AS Per Complexity") = Math.Round(CDbl(sumOnTime) * 100.0 / CDbl(sumAdCount), 2)
                End If

                dtData.Rows.Add(dr2)

            End If
            '---------------------------------
            '-------------------------------------------
            If cboComplexitySLA.SelectedValue = "complexityAndSLA" Then
                lblReportName.Text = "Complexity and SLA"
                Dim dr As DataRow = dtData.NewRow
                Dim sumMorning As Integer = 0, sumNight As Integer = 0
                Dim Count As Integer = 0
                Dim sumSLAMeet As Integer = 0, sumComplexity As Integer = 0

                For Each row As DataRow In dtData.Rows
                    If row("Total Ads in Morning") = 1 Then
                        sumMorning += 1
                    End If

                    If row("Total Ads in Night") = 1 Then
                        sumNight += 1
                    End If

                    If row("Complexity Meet OnTime").ToString.ToLower = "yes" Then
                        sumComplexity += 1
                    End If

                    If row("SLA Meet OnTime").ToString.ToLower = "yes" Then
                        sumSLAMeet += 1
                    End If

                    Count += 1
                Next

                dr("AD Name") = "Total="
                dr("Total Ads in Morning") = sumMorning
                dr("Total Ads in Night") = sumNight

                dr("Complexity Meet OnTime") = "OnTime Complexity% (" & Math.Round(CDbl(sumComplexity) * 100.0 / CDbl(Count), 2) & ")"

                dr("SLA Meet OnTime") = "OnTime SLA% (" & Math.Round(CDbl(sumSLAMeet) * 100.0 / CDbl(Count), 2) & ")"

                dtData.Rows.Add(dr)
            End If
            '---------------------------------
        End If

        GridView1.DataSource = dtData
        GridView1.DataBind()

    End Sub

#End Region

#Region "--- Functions---"
#End Region

#Region "--- Events ---"

    'Protected Sub CboGroupByCriteria_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles CboGroupByCriteria.SelectedIndexChanged
    '    BindGroupByMembers()
    'End Sub

    Protected Sub CboPeriod_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles CboPeriod.SelectedIndexChanged
        If CboPeriod.SelectedValue = 10 Then
            ucDateFrom.Visible = True
            UcDateTo.Visible = True
            lblAnd.Visible = True
            FillData()
        Else
            ucDateFrom.Visible = False
            UcDateTo.Visible = False
            lblAnd.Visible = False
            FillData()
        End If
    End Sub

    Protected Sub ucDateFrom_Changed(ByVal sender As Object, ByVal e As System.EventArgs) Handles ucDateFrom.Changed
        FillData()
    End Sub

    Protected Sub UcDateTo_Changed(ByVal sender As Object, ByVal e As System.EventArgs) Handles UcDateTo.Changed
        FillData()
    End Sub

    'Protected Sub cboGroupMembers_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboGroupMembers.SelectedIndexChanged
    '    FillData()
    'End Sub

    Protected Sub btnRefresh_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnRefresh.Click
        FillData()
    End Sub

    Protected Sub cboComplexitySLA_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboComplexitySLA.SelectedIndexChanged
        FillData()
    End Sub


    Protected Sub ImageButton1_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton1.Click
        'If cboCampaigns.SelectedItem.Text = "HPS" Then
        '    CboPeriod.SelectedValue = 3
        'End If
        FillData()
        Dim gv As New GridView
        gv.DataSource = dtdata
        gv.DataBind()
        GridViewExportUtil.Export(lblReportName.Text & ".xls", gv)
    End Sub

    Protected Sub imgfav_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles imgfav.Click
        Common.AddToFav(AgentID, "Complexity and SLA")
        SuccessMessage("Report has been added to your favourite list")
        FillData()
    End Sub

    Protected Sub cboCampaigns_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboCampaigns.SelectedIndexChanged
        CampaignID = cboCampaigns.SelectedValue
        FillData()
    End Sub

    Protected Sub CboProcess_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles CboProcess.SelectedIndexChanged
        ProcessID = CboProcess.SelectedValue
        Common.FillCampaigns(cboCampaigns, AgentID, CboProcess.SelectedValue)
        Dim removeItem As ListItem = cboCampaigns.Items.FindByValue("0")
        cboCampaigns.Items.Remove(removeItem)

        CampaignID = cboCampaigns.SelectedValue
        FillData()
    End Sub

#End Region

#Region "Utility"

    Private Sub AlertMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMFail"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub

    Private Sub SuccessMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMSuccess"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub

#End Region


End Class
