﻿Imports com.nss.DBAccess
Imports System.Data

Partial Class Data_BucketSummary
    Inherits System.Web.UI.Page

#Region "--- Properties ---"
    Property AgentID() As String
        Get
            Return ViewState("AgentID")
        End Get
        Set(ByVal value As String)
            ViewState("AgentID") = value
        End Set
    End Property
    Property CampaignID() As String
        Get
            Return ViewState("CampaignID")
        End Get
        Set(ByVal value As String)
            ViewState("CampaignID") = value
        End Set
    End Property

    Property TimeDifference() As Integer
        Get
            Return ViewState("TimeDifference")
        End Get
        Set(ByVal value As Integer)
            ViewState("TimeDifference") = value
        End Set
    End Property

    Property receivedtimebased() As Boolean
        Get
            Return ViewState("receivedtimebased")
        End Get
        Set(ByVal value As Boolean)
            ViewState("receivedtimebased") = value
        End Set
    End Property

#End Region
    Dim startday As Integer, endday As Integer
#Region "--- Page Load ---"
    Private Sub LoadData()
        FillCommonFilters()
        FillCampaigns()
    End Sub
    Private Sub FillCommonFilters()
        Dim db As New DBAccess
        Dim dt As DataTable = db.ReturnTable("select * from tbl_Reports_DatePeriods")
        db = Nothing
        Dim dr As DataRow = dt.NewRow
        dr(0) = 10
        dr(1) = "Between"
        dt.Rows.Add(dr)
        CboPeriod.DataTextField = "Caption"
        CboPeriod.DataValueField = "Period"
        CboPeriod.DataSource = dt
        CboPeriod.DataBind()

        db = New DBAccess
        dt = db.ReturnTable("Select * from tbl_Reports_GroupBy")
        If dt.Rows.Count > 0 Then
            For i As Integer = dt.Rows.Count - 1 To 0 Step -1
                If dt.Rows(i).Item("Caption").ToString.ToUpper = "DAY" Or dt.Rows(i).Item("Caption").ToString.ToUpper = "HOUR" Then
                    dt.Rows.RemoveAt(i)
                End If
            Next
        End If
        CboGroup.DataTextField = "Caption"
        CboGroup.DataValueField = "ID"
        CboGroup.DataSource = dt
        CboGroup.DataBind()
        db = Nothing

    End Sub
    Private Sub FillCampaigns()
        Common.FillProcessCampaigns(CboProcess, cboCampaigns, AgentID, CampaignID)
        Dim lstCamp As New ListItem
        lstCamp.Value = 0
        lstCamp.Text = "All"
        If cboCampaigns.Items.Contains(lstCamp) Then
            cboCampaigns.Items.Remove(lstCamp)
        End If
    End Sub
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        HumanMessage.Style.Item("visibility") = "hidden"
        If Not IsPostBack Then
            If Session("AgentID") <> "" Then
                AgentID = Session("AgentID")
                CampaignID = Session("CampaignID")
                PanelReports.Controls.Add(Common.GetMenu(Request.Url, AgentID, Request.ApplicationPath))
                LoadData()
                fillGrid()
                UcDateTo.Visible = False
                ucDateFrom.Visible = False
                lblAnd.Visible = False
            End If
        End If
    End Sub
#End Region
#Region "--- Event ---"
    Protected Sub btnRefresh_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnRefresh.Click
        fillGrid()
    End Sub
    Protected Sub ImageButton1_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton1.Click
        fillGrid()
        GridViewExportUtil.Export(lblReportName.Text & ".xls", Me.GridView1)
    End Sub
    Protected Sub CboPeriod_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles CboPeriod.SelectedIndexChanged
        If CboPeriod.SelectedValue = 10 Then
            ucDateFrom.Visible = True
            UcDateTo.Visible = True
            lblAnd.Visible = True
        Else
            ucDateFrom.Visible = False
            UcDateTo.Visible = False
            lblAnd.Visible = False
            fillGrid()
        End If
    End Sub
    Protected Sub imgfav_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles imgfav.Click
        Common.AddToFav(AgentID, "Bucket Summary")
        SuccessMessage("Report has been added to your favourite list")
        fillGrid()
    End Sub
    Protected Sub cboCampaigns_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboCampaigns.SelectedIndexChanged
        fillGrid()
    End Sub
    Protected Sub CboGroup_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles CboGroup.SelectedIndexChanged
        fillGrid()
    End Sub
#End Region
#Region "--- Function ---"
    Private Sub fillGrid()
        Dim db As New DBAccess
        Dim dtGetData As New DataTable
        If CboPeriod.SelectedValue = 10 Then
            startday = ucDateFrom.yyyymmdd
            endday = UcDateTo.yyyymmdd
        Else
            db = New DBAccess
            db.slDataAdd("Period", CboPeriod.SelectedValue)
            db.slDataAdd("Campaignid", cboCampaigns.SelectedValue)
            Dim dr As DataRow = db.ReturnRow("usp_GetStart_EndDateForAPeriod", True)
            db = Nothing
            startday = dr(0)
            endday = dr(1)
        End If

        Dim obj As Object = Nothing

        db = New DBAccess("CRM")
        obj = db.ReturnValue("SELECT TimeDiff FROM tbl_Config_Campaign_TimeDifference WHERE Campaignid=" & cboCampaigns.SelectedValue, False)
        If obj Is Nothing Then
            TimeDifference = 0
        Else
            TimeDifference = CInt(obj)
        End If
        db = Nothing


        db = New DBAccess("CRM")
        obj = db.ReturnValue("SELECT SettingValue FROM tbl_Config_Campaign_Settings WHERE SettingName ='ReceivedDateTimeBased' AND Campaignid=" & cboCampaigns.SelectedValue, False)
        If obj Is Nothing Then
            receivedtimebased = 0
        Else
            receivedtimebased = CBool(obj)
        End If
        db = Nothing


        db = New DBAccess
        'db.slDataAdd("userid", AgentID)
        db.slDataAdd("DateFrom", startday)
        db.slDataAdd("DateTo", endday)
        db.slDataAdd("campID", cboCampaigns.SelectedValue)
        db.slDataAdd("groupBy", CboGroup.SelectedValue)
        db.slDataAdd("diffInTime", TimeDifference)
        db.slDataAdd("receivedtimebased", receivedtimebased)

        dtGetData = db.ReturnTable("usp_BucketSummary_Terms2", , True)
        GridView1.DataSource = dtGetData
        GridView1.DataBind()

        lblReportName.Text = "Bucket Summary Report Between " & IntegerToDateString(startday) & "  and " & IntegerToDateString(endday) & " for " & cboCampaigns.SelectedItem.Text & " campaign"
    End Sub
    Private Function IntegerToDateString(ByVal d As Integer) As String
        Return d.ToString.Substring(0, 4) & "-" & d.ToString.Substring(4, 2) & "-" & d.ToString.Substring(6, 2)
    End Function

#End Region
#Region "--- Utility ---"

    Private Sub AlertMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMFail"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub
    Private Sub SuccessMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMSuccess"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub

#End Region

  
End Class
