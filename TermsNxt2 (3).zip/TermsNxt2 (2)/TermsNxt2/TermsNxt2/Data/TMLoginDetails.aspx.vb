﻿Imports com.nss.DBAccess
Imports System.Data
Imports System.Text

Partial Class Data_TMLoginDetails
    Inherits System.Web.UI.Page

#Region "Properties"
    Property AgentID() As String
        Get
            Return ViewState("AgentID")
        End Get
        Set(ByVal value As String)
            ViewState("AgentID") = value
        End Set
    End Property
    Public Property currentdate() As Date
        Get
            Return ViewState("currentdate")
        End Get
        Set(ByVal value As DateTime)
            ViewState("currentdate") = value
        End Set
    End Property
#End Region

    Private Sub LoadData()
        FillCampaigns()
    End Sub
    Private Sub FillCampaigns()
        Common.FillCampaigns(cboCampaigns, AgentID, 0, 0)
    End Sub

    Private Sub fillGrid()
        Dim db As New DBAccess
        Dim dtGetData As New DataTable

        db = New DBAccess
        db.slDataAdd("campid", cboCampaigns.SelectedValue)
        db.slDataAdd("mfdate", ucDateFrom.yyyymmdd)
        dtGetData = db.ReturnTable("usp_getAgentLoginTimeGordon", , True)

        gvTMLoginDetail.DataSource = dtGetData
        gvTMLoginDetail.DataBind()

        lblReportName.Text = "Team Member Login Details for " & ucDateFrom.yyyymmdd & " for " & cboCampaigns.SelectedItem.Text & " campaign"
    End Sub
    Protected Sub btnRefresh_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnRefresh.Click
        fillgrid()
    End Sub
    Protected Sub ImageButton1_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton1.Click
        fillgrid()
        GridViewExportUtil.Export(lblReportName.Text & ".xls", Me.gvTMLoginDetail)
    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        HumanMessage.Style.Item("visibility") = "hidden"
        If Not IsPostBack Then
            Dim dbdate As New DBAccess
            currentdate = dbdate.ReturnValue("select getdate()", False)
            dbdate = Nothing
            ucDateFrom.value = currentdate
            If Session("AgentID") <> "" Then
                AgentID = Session("AgentID")
                PanelReports.Controls.Add(Common.GetMenu(Request.Url, AgentID, Request.ApplicationPath))
                LoadData()
                fillGrid()
            End If
        End If
    End Sub

    Protected Sub cboCampaigns_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboCampaigns.SelectedIndexChanged
        fillGrid()
    End Sub

    Protected Sub imgfav_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles imgfav.Click
        Common.AddToFav(AgentID, "Team Member Login Detail")
        SuccessMessage("Report has been added to your favourite list")
        fillGrid()
    End Sub
#Region "Utility"

    Private Sub AlertMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMFail"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub

    Private Sub SuccessMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMSuccess"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub

    'Protected Sub ImageButton1_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton1.Click
    '    'fillgrid()
    '    GridViewExportUtil.Export(lblReportName.CurrentPage & "-" & LblError.Text & ".xls", Me.GdAttendance)
    'End Sub


    Public Overrides Sub VerifyRenderingInServerForm(ByVal Control As Control)

    End Sub

#End Region
End Class
