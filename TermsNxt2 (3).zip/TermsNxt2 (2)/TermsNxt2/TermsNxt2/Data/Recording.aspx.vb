﻿Imports com.nss.DBAccess
Imports System.Data

Partial Class Data_Recording
    Inherits System.Web.UI.Page

#Region "==== Property ===="
    Public Property currentdate() As Date
        Get
            Return ViewState("currentdate")
        End Get
        Set(ByVal value As DateTime)
            ViewState("currentdate") = value
        End Set
    End Property
    Public Property UserId() As Integer
        Get
            Return ViewState("UserId")
        End Get
        Set(ByVal value As Integer)
            ViewState("UserId") = value
        End Set
    End Property
    Public Property UserType() As String
        Get
            Return ViewState("UserType")
        End Get
        Set(ByVal value As String)
            ViewState("UserType") = value
        End Set
    End Property
    Property AgentID() As String
        Get
            Return ViewState("AgentID")
        End Get
        Set(ByVal value As String)
            ViewState("AgentID") = value
        End Set
    End Property
    Property CampaignID() As Integer
        Get
            Return ViewState("CampaignID")
        End Get
        Set(ByVal value As Integer)
            ViewState("CampaignID") = value
        End Set
    End Property
#End Region
#Region "==== Load ==="
    Private Sub GetUserId()
        Dim db As New DBAccess
        ' Dim Isclient As Boolean
        'Isclient = db.ReturnValue("select isclient from tbl_AgentMaster where active=1 and Agentid='" & AgentID & "'", False)
        UserType = db.ReturnValue("select UserType from tbl_Config_OrionRecordingUser where Agentid='" & AgentID & "'", False)
        'If Isclient = True Then
        '    UserType = "Client"
        'Else
        '    UserType = "NSS"
        'End If
        db = Nothing
    End Sub
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        HumanMessage.Style.Item("visibility") = "hidden"
        btnClose.Visible = False
        btnSave.Visible = False
        If Not IsPostBack Then
            If Session("AgentID") <> "" Then
                AgentID = Session("AgentID")
                CampaignID = Session("CampaignID")
                PanelReports.Controls.Add(Common.GetMenu(Request.Url, AgentID, Request.ApplicationPath))
                Dim dbdate As New DBAccess
                currentdate = dbdate.ReturnValue("select getdate()", False)
                dbdate = Nothing
                txtDate.value = currentdate
                GetUserId()
                bindRecordingGrid()
            End If
        End If
    End Sub

#End Region
#Region "===== Functions ===="
    Private Sub bindRecordingGrid()
        Dim db As New DBAccess
        Dim dtARecording As New DataTable
        db.slDataAdd("datefrom", txtDate.value.ToString("yyyyMMdd"))
        dtARecording = db.ReturnTable("usp_getRecordingDetail", , True)
        'dtARecording = db.ReturnTable("usp_getRecord_Attendance2", , True)
        db = Nothing
        gvRcording.DataSource = dtARecording
        gvRcording.DataBind()
        If dtARecording.Rows.Count > 0 Then
            btnClose.Visible = True
            btnSave.Visible = True
            tbllegend.Visible = True
        Else
            tbllegend.Visible = False
        End If
    End Sub
    Private Sub RecordingRequest()
        Dim db As New DBAccess

        Dim dt As DataTable = db.ReturnTable("select * from tbl_Data_ApplicationEmails where processid=9 and applicationname='RecordApp'", , False)
        db = Nothing
        Dim recNeeded As CheckBox
        Dim slNo As Int16 = 0
        Dim strTo, strCC, strBCC As String
        Dim EMPCode, subject, str, strMailBody, strMailcontent As String
        strMailcontent = ""
        If UserType.ToUpper = "CLIENT" Then
            str = "Recording needed "
        ElseIf UserType.ToUpper = "NSS" Then
            str = "Recording has been uploaded"
        End If
        strMailBody = "<html xmlns='http://www.w3.org/1999/xhtml'>"
        strMailBody += "<body style='font-family: Verdana; font-size: .8em'>"
        strMailBody += "<strong> " & str & " for following agents for date: " & txtDate.Text & "</strong><br /><br />"
        strMailBody += "<table border='1' width='40%' style='border: 1px solid; border-collapse: collapse; font-family: Verdana; font-size: .8em'>"
        strMailBody += "<tr>"
        strMailBody += "<td ><b>Sr. No.</b></td>"
        strMailBody += "<td ><b>Agents</b></td>"
        strMailBody += "<td ><b>Type of Call</b></td>"
        strMailBody += "<td ><b>Call Time</b></td>"
        strMailBody += "</tr>"
        If UserType.ToUpper = "CLIENT" Then          '=== For Client Only
            For Each row As GridViewRow In gvRcording.Rows
                subject = "Recording Needed for date: " & txtDate.Text & ""
                Dim dbRequest As New DBAccess
                recNeeded = CType(row.FindControl("chkneeded"), CheckBox)
                If recNeeded.Checked = True Then
                    slNo = slNo + 1
                    EMPCode = CType(row.FindControl("lblAliasName"), Label).Text & " (" & CType(row.FindControl("lblEMpCode"), Label).Text & " )"
                    dbRequest.slDataAdd("userid", AgentID) 'Session("AgentId")
                    dbRequest.slDataAdd("AgentId", CType(row.FindControl("lblEMpCode"), Label).Text)
                    dbRequest.slDataAdd("RecDateFrom", txtDate.value.ToString("yyyyMMdd"))
                    dbRequest.slDataAdd("RecStatus", recNeeded.Checked)
                    dbRequest.slDataAdd("calltype", CType(row.FindControl("ddlCallType"), DropDownList).SelectedValue)
                    dbRequest.slDataAdd("calltime", CType(row.FindControl("ddlCallTime"), DropDownList).SelectedValue)
                    dbRequest.Executeproc("usp_InsertRecordingNeeded")
                    strMailcontent += "<tr>"
                    strMailcontent += "<td>" & slNo & "</td>"
                    strMailcontent += "<td>" & EMPCode & "</td>"
                    strMailcontent += "<td>" & CType(row.FindControl("ddlCallType"), DropDownList).SelectedItem.Text & "</td>"
                    strMailcontent += "<td>" & CType(row.FindControl("ddlCallTime"), DropDownList).SelectedValue & "</td>"
                    strMailcontent += "</tr>"
                End If
                dbRequest = Nothing
            Next
            strTo = dt.Rows(0).Item("MailTo").ToString
            strCC = dt.Rows(0).Item("MailCC").ToString
            strBCC = dt.Rows(0).Item("MailBcc").ToString
            If strMailcontent = "" Then
                MsgBox("Please select a call")
                Exit Sub
            End If
            SuccessMessage("Recording request has been sent successfully")
        ElseIf UserType.ToUpper = "NSS" Then        '========= For NSS User Only
            subject = "Recording uploaded for date: " & txtDate.Text & ""
            For Each row As GridViewRow In gvRcording.Rows
                Dim dbUpload As New DBAccess
                recNeeded = CType(row.FindControl("chkuploaded"), CheckBox)
                If recNeeded.Checked = True Then
                    slNo = slNo + 1
                    EMPCode = CType(row.FindControl("lblAliasName"), Label).Text & " (" & CType(row.FindControl("lblEMpCode"), Label).Text & " )"
                    dbUpload.slDataAdd("userid", AgentID) 'Session("AgentId")
                    dbUpload.slDataAdd("AgentId", CType(row.FindControl("lblEMpCode"), Label).Text)
                    dbUpload.slDataAdd("RecDateFrom", txtDate.value.ToString("yyyyMMdd"))
                    dbUpload.slDataAdd("RecStatus", recNeeded.Checked)
                    dbUpload.slDataAdd("RecUploaded", 1)
                    dbUpload.Executeproc("usp_InsertRecordingUploaded")
                    strMailcontent += "<tr>"
                    strMailcontent += "<td>" & slNo & "</td>"
                    strMailcontent += "<td>" & EMPCode & "</td>"
                    strMailcontent += "<td>" & CType(row.FindControl("ddlCallType"), DropDownList).SelectedItem.Text & "</td>"
                    strMailcontent += "<td>" & CType(row.FindControl("ddlCallTime"), DropDownList).SelectedValue & "</td>"
                    strMailcontent += "</tr>"
                End If
                dbUpload = Nothing
            Next
            strTo = dt.Rows(0).Item("MailToClient").ToString
            strCC = dt.Rows(0).Item("MailCC").ToString
            strBCC = dt.Rows(0).Item("MailBcc").ToString
            If strMailcontent = "" Then
                MsgBox("Please select a call")
                Exit Sub
            End If
            SuccessMessage("Recording has been uploaded successfully")
        End If
        strMailBody += strMailcontent + "</table>"
        'strMailBody = strMailBody
        Dim objWSMail As New ServiceReference2.MailSoapClient
        Dim strFrom As String = "TermsMonitor<Termsmonitor@coforge.com>" 'System.Configuration.ConfigurationManager.AppSettings("FROM")
        objWSMail.MailSend(strTo, strMailBody, "", strCC, strBCC, strFrom, subject)
        'objWSMail.MailSend("satyendrac@niitsmartserve.com", strMailBody, "", "rajendrar_nss@niitsmartserve.com", "rajendrar_nss@niitsmartserve.com", strFrom, subject)
        objWSMail = Nothing
    End Sub
   
#End Region
#Region "==== Event ==="
    Protected Sub gvRcording_RowCreated(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles gvRcording.RowCreated
        Dim dtCallType As New DataTable
        Dim dbCalltype As New DBAccess("CRM")
        dbCalltype.slDataAdd("campaign_id", 208)
        dtCallType = dbCalltype.ReturnTable("usp_GetDispositions_Amendment", , True)
        'dtCallType = dbCalltype.ReturnTable("SELECT * FROM tbl_Orion_Recording_Disposition")
        dbCalltype = Nothing
        Dim ddlCallType, ddlCallTime As DropDownList
        Dim chkNeeded, chkUploaded As CheckBox
        Dim loginstatus As Label
        If e.Row.RowType = DataControlRowType.DataRow Then
            ddlCallType = CType(e.Row.FindControl("ddlCallType"), DropDownList)
            ddlCallTime = CType(e.Row.FindControl("ddlCallTime"), DropDownList)
            loginstatus = CType(e.Row.FindControl(""), Label)
            ddlCallType.DataSource = dtCallType
            ddlCallType.DataTextField = "Caption"
            ddlCallType.DataValueField = "Code"
            ddlCallType.DataBind()
            chkNeeded = CType(e.Row.FindControl("chkneeded"), CheckBox)
            chkUploaded = CType(e.Row.FindControl("chkuploaded"), CheckBox)
            If gvRcording.DataKeys(e.Row.RowIndex)("calltime").ToString() <> "" Then
                ddlCallTime.SelectedValue = gvRcording.DataKeys(e.Row.RowIndex)("calltime").ToString()
            End If
            If UserType.ToUpper = "NSS" Then
                ddlCallTime.Enabled = False
                ddlCallType.Enabled = False
                chkNeeded.Enabled = False
            ElseIf UserType.ToUpper = "CLIENT" Then
                ddlCallTime.Enabled = True
                ddlCallType.Enabled = True
                chkUploaded.Enabled = False
            End If
            
        End If
    End Sub
    Protected Sub gvRcording_RowDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles gvRcording.RowDataBound
        If e.Row.RowType = DataControlRowType.DataRow Then
            Dim lblcategory As Label
            'Dim ddlCallType As DropDownList
            Dim LoginStatus As String = gvRcording.DataKeys(e.Row.RowIndex)("LoginStatus").ToString()
            If LoginStatus = "FullDay" Then
                e.Row.Cells(1).BackColor = Drawing.Color.LightGreen
            ElseIf LoginStatus = "Afternoon" Then
                e.Row.Cells(1).BackColor = Drawing.Color.Orange
            ElseIf LoginStatus = "Evening" Then
                e.Row.Cells(1).BackColor = Drawing.Color.LightBlue
            End If
            CType(e.Row.FindControl("ddlCallType"), DropDownList).SelectedValue = gvRcording.DataKeys(e.Row.RowIndex)("calltype").ToString()
            'ddlCallType = CType(e.Row.FindControl("ddlCallType"), DropDownList)
            'ddlCallType.SelectedValue = gvRcording.DataKeys(e.Row.RowIndex)("calltype").ToString()
            lblcategory = CType(e.Row.FindControl("lblcategory"), Label)
            If lblcategory.Text = "A" Then
                e.Row.Cells(8).BackColor = Drawing.Color.LightGreen
            ElseIf lblcategory.Text = "B" Then
                e.Row.Cells(8).BackColor = Drawing.Color.LightYellow
            ElseIf lblcategory.Text = "C" Then
                e.Row.Cells(8).BackColor = Drawing.Color.Pink
            End If
        End If
    End Sub
    Protected Sub btnRefresh_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnRefresh.Click
        bindRecordingGrid()
    End Sub
    Protected Sub DateChange(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtDate.Changed
        bindRecordingGrid()
    End Sub
    Protected Sub btnSave_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnSave.Click
        Try
            RecordingRequest()
            bindRecordingGrid()
        Catch ex As Exception
            AlertMessage(ex.ToString)
        End Try
    End Sub
    Protected Sub btnClose_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnClose.Click
        Response.Redirect("~/Default.aspx")
    End Sub
    Protected Sub imgfav_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles imgfav.Click
        Common.AddToFav(AgentID, "Recording")
        SuccessMessage("Recording application has been added to your favourite list")
        bindRecordingGrid()
    End Sub
#End Region
#Region "=== Utility ===="

    Private Sub AlertMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMFail"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub
    Private Sub SuccessMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMSuccess"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub
#End Region

  
    Protected Sub ImageButton1_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton1.Click
        bindRecordingGrid()
        GridViewExportUtil.Export(lblReportName.Text & ".xls", Me.gvRcording)
    End Sub
End Class
