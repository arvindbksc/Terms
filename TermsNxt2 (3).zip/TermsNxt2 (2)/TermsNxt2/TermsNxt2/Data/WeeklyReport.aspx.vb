﻿Imports com.nss.DBAccess
Imports System.Data
Partial Class Data_WeeklyReport
    Inherits System.Web.UI.Page
#Region "--- Properties ---"
    Property ProcessID() As Integer
        Get
            Return ViewState("ProcessID")
        End Get
        Set(ByVal value As Integer)
            ViewState("ProcessID") = value
        End Set
    End Property
    Property CampaignID() As Integer
        Get
            Return ViewState("CampaignID")
        End Get
        Set(ByVal value As Integer)
            ViewState("CampaignID") = value
        End Set
    End Property
    Property AgentID() As String
        Get
            Return ViewState("AgentID")
        End Get
        Set(ByVal value As String)
            ViewState("AgentID") = value
        End Set
    End Property
#End Region
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        HumanMessage.Style.Item("visibility") = "hidden"
        If Not IsPostBack Then
            CampaignID = Session("CampaignID")
            AgentID = Session("AgentID")
            PanelReports.Controls.Add(Common.GetMenu(Request.Url, AgentID, Request.ApplicationPath))
            FillProcessCampaigns()
            Fillgrid()
        End If
    End Sub

#Region "--- Support function ---"
   
    Private Sub FillProcessCampaigns()
        Common.FillProcesses(CboProcess, AgentID)
        Dim lstprocess As New ListItem
        lstprocess.Value = 0
        lstprocess.Text = "All"
        If CboProcess.Items.Contains(lstprocess) Then
            CboProcess.Items.Remove(lstprocess)
        End If
        Common.FillCampaigns(cboCampaigns, AgentID, CboProcess.SelectedValue)
        'Dim lstcmp As New ListItem
        'lstcmp.Value = 0
        'lstcmp.Text = "All"
        'If cboCampaigns.Items.Contains(lstcmp) Then
        '    cboCampaigns.Items.Remove(lstcmp)
        'End If
    End Sub
    Private Function IntegerToDateString(ByVal d As Integer) As String
        Return d.ToString.Substring(0, 4) & "-" & d.ToString.Substring(4, 2) & "-" & d.ToString.Substring(6, 2)
    End Function
    Private Sub ExportToexcel()
        Dim tw As New IO.StringWriter()
        Dim hw As New System.Web.UI.HtmlTextWriter(tw)
        Response.ContentType = "application/vnd.ms-excel"
        Response.AddHeader("content-disposition", "attachment;filename=" & lblReportName.Text & "-" & LblError.Text & ".xls")
        Response.Charset = ""
        EnableViewState = False
        gvWeeklyReport.RenderControl(hw)
        Response.Write(tw.ToString())
        Response.End()
    End Sub
    Dim dt, dtcol As New DataTable
    Private Sub Fillgrid()
        Dim db As New DBAccess
        db = New DBAccess
        db.slDataAdd("CampaignID", cboCampaigns.SelectedValue)
        db.slDataAdd("ProcessID", CboProcess.SelectedValue)
        db.slDataAdd("UserId", AgentID)
        db.slDataAdd("GroupBy", CboGroupBy.SelectedValue)
        dt = db.ReturnTable("usp_WeeklyReport", , True)
        db = Nothing
        dt = TransposeTable(dt)
        lblReportName.Text = "Weekly Report"
        LblError.Text = "For " & cboCampaigns.SelectedItem.Text
        db = Nothing
        gvWeeklyReport.DataSource = dt
        gvWeeklyReport.DataBind()
        dt = Nothing

    End Sub
    Private Function TransposeTable(ByVal InputTable As Data.DataTable) As Data.DataTable
        Dim od As New DataTable
        Dim distinctAgent As DataTable = InputTable.DefaultView.ToTable(True, "AgentID", "AgentName", "Alias")
        Dim distinctWeek As DataTable = InputTable.DefaultView.ToTable(True, "week")

        Dim week3rd As Integer

        Dim dt8Weeks_Initial As DataTable = InputTable.Copy
        Dim dt8Weeks_Final As DataTable = Nothing
        Dim dt3Weeks_Initial As DataTable = InputTable.Copy
        Dim dt3Weeks_Final As DataTable = Nothing

        'to remove formula columns from "InputTable"
        For m As Integer = InputTable.Columns.Count - 1 To 0 Step -1
            If InputTable.Columns(m).ColumnName.Contains("$A") Or InputTable.Columns(m).ColumnName.Contains("$B") Then
                InputTable.Columns.RemoveAt(m)
            End If
        Next


        ' to left with only formula columns ,"AgentID" and "Week"
        For p As Integer = dt8Weeks_Initial.Columns.Count - 1 To 0 Step -1
            If dt8Weeks_Initial.Columns(p).ColumnName.ToUpper = "WEEK" Or dt8Weeks_Initial.Columns(p).ColumnName.ToUpper = "AGENTID" Or dt8Weeks_Initial.Columns(p).ColumnName.Contains("$A") Or dt8Weeks_Initial.Columns(p).ColumnName.Contains("$B") Then
            Else
                dt8Weeks_Initial.Columns.RemoveAt(p)
            End If
        Next

        dt8Weeks_Final = dt8Weeks_Initial.Clone  'only columns
        For r As Integer = dt8Weeks_Initial.Columns.Count - 1 To 0 Step -1
            If dt8Weeks_Initial.Columns(r).ColumnName.ToUpper = "AGENTID" Then

            ElseIf dt8Weeks_Initial.Columns(r).ColumnName.Contains("$A") Then
                dt8Weeks_Final.Columns(r).ColumnName = dt8Weeks_Final.Columns(r).ColumnName.Replace("$A", "")
                dt8Weeks_Final.Columns(r).DataType = System.Type.GetType("System.Decimal")  'to change for decimal values
            Else
                dt8Weeks_Final.Columns.RemoveAt(r)
            End If
        Next

        dt3Weeks_Final = dt8Weeks_Final.Clone

        Dim drLast As DataRow
        Dim drLast2 As DataRow

        Dim arrRow() As DataRow = Nothing
        Dim colName As String = "", colNumerator As String = "", colDenominator As String = ""
        Dim Numerator As Double = 0, Denominator As Double = 0

        '---for last 8 weeks------start

        For Each row As DataRow In distinctAgent.Rows
            'arrRow = dt8Weeks_Initial.Select("AgentID='" & row(AgentID) & "'")
            drLast = dt8Weeks_Final.NewRow
            drLast("AgentID") = row("AgentID")

            For k As Integer = 0 To dt8Weeks_Final.Columns.Count - 1
                colName = dt8Weeks_Final.Columns(k).ColumnName

                If colName.ToUpper <> "AGENTID" Then

                    colNumerator = colName & "$A"
                    colDenominator = colName & "$B"

                    Numerator = 0
                    Denominator = 0

                    'Numerator = dt8Weeks_Initial.Compute("SUM(" & IIf(IsDBNull(colNumerator), 0, colNumerator) & ")", "AgentID='" & row("AgentID") & "'")  'for "$A"
                    'Denominator = dt8Weeks_Initial.Compute("SUM(" & IIf(IsDBNull(colDenominator), 0, colDenominator) & ")", "AgentID='" & row("AgentID") & "'") 'for "$B"

                    If dt8Weeks_Initial.Select("AgentID='" & row("AgentID") & "' AND " & colNumerator & " IS NOT NULL ").Length > 0 Then  'for "$A"
                        Numerator = dt8Weeks_Initial.Compute("SUM(" & colNumerator & ")", "AgentID='" & row("AgentID") & "' AND " & colNumerator & " IS NOT NULL ")  'for "$A"
                    End If


                    If dt8Weeks_Initial.Select("AgentID='" & row("AgentID") & "' AND " & colDenominator & " IS NOT NULL ").Length > 0 Then  'for "$A"
                        Denominator = dt8Weeks_Initial.Compute("SUM(" & colDenominator & ")", "AgentID='" & row("AgentID") & "' AND " & colDenominator & " IS NOT NULL ") 'for "$B"
                    End If


                    drLast(colName) = Math.Round(IIf(Denominator = 0, 0, CDbl(Numerator / Denominator * 1.0)), 2)
                End If
            Next
            dt8Weeks_Final.Rows.Add(drLast)
        Next

        'GridView1.DataSource = dt8Weeks_Final
        'GridView1.DataBind()
        '-----for last 8 weeks end------

        ' ----For the last 3 weeks   start
        If distinctWeek.Rows.Count >= 3 Then
            week3rd = distinctWeek.Rows(distinctWeek.Rows.Count - 3)(0).ToString
        End If


        For Each row As DataRow In distinctAgent.Rows
            'arrRow = dt8Weeks_Initial.Select("AgentID='" & row(AgentID) & "'")
            drLast2 = dt3Weeks_Final.NewRow
            drLast2("AgentID") = row("AgentID")

            For k As Integer = 0 To dt3Weeks_Final.Columns.Count - 1
                colName = dt3Weeks_Final.Columns(k).ColumnName

                If colName.ToUpper <> "AGENTID" Then

                    colNumerator = colName & "$A"
                    colDenominator = colName & "$B"

                    Numerator = 0
                    Denominator = 0

                    'Numerator = dt8Weeks_Initial.Compute("SUM(" & IIf(IsDBNull(colNumerator), 0, colNumerator) & ")", "AgentID='" & row("AgentID") & "'")  'for "$A"
                    'Denominator = dt8Weeks_Initial.Compute("SUM(" & IIf(IsDBNull(colDenominator), 0, colDenominator) & ")", "AgentID='" & row("AgentID") & "'") 'for "$B"

                    If dt3Weeks_Initial.Select("AgentID='" & row("AgentID") & "' AND " & colNumerator & " IS NOT NULL " & " AND Week>=" & week3rd).Length > 0 Then  'for "$A"
                        Numerator = dt3Weeks_Initial.Compute("SUM(" & colNumerator & ")", "AgentID='" & row("AgentID") & "' AND " & colNumerator & " IS NOT NULL " & " AND Week>=" & week3rd)  'for "$A"
                    End If


                    If dt3Weeks_Initial.Select("AgentID='" & row("AgentID") & "' AND " & colDenominator & " IS NOT NULL " & " AND Week>=" & week3rd).Length > 0 Then  'for "$A"
                        Denominator = dt3Weeks_Initial.Compute("SUM(" & colDenominator & ")", "AgentID='" & row("AgentID") & "' AND " & colDenominator & " IS NOT NULL " & " AND Week>=" & week3rd) 'for "$B"
                    End If


                    drLast2(colName) = Math.Round(IIf(Denominator = 0, 0, CDbl(Numerator / Denominator * 1.0)), 2)
                End If
            Next
            dt3Weeks_Final.Rows.Add(drLast2)
        Next

        'GridView2.DataSource = dt3Weeks_Final
        'GridView2.DataBind()
        ' ----For the last 3 weeks   end


        Dim col As DataColumn
        If InputTable.Rows.Count > 0 Then
            od.Columns.Add("AgentID")
            od.Columns.Add("AgentName")
            od.Columns.Add("Alias")
            If distinctWeek.Rows.Count > 0 Then
                For j As Integer = 4 To InputTable.Columns.Count - 1
                    For k As Integer = 0 To distinctWeek.Rows.Count - 1
                        col = New DataColumn
                        col.ColumnName = InputTable.Columns(j).ColumnName & "_" & distinctWeek.Rows(k).Item(0)
                        od.Columns.Add(col)
                    Next

                    If InputTable.Columns(j).ColumnName.Contains("PIP") Then

                    Else
                        col = New DataColumn
                        col.ColumnName = InputTable.Columns(j).ColumnName & "?" & "8WeekAverage"
                        od.Columns.Add(col)

                        col = New DataColumn
                        col.ColumnName = InputTable.Columns(j).ColumnName & "?" & "Last3Weeks"
                        od.Columns.Add(col)
                    End If
                Next
            End If
        End If
        '------------------------------------ To insert data
        Dim dr() As DataRow = Nothing
        Dim query As String = ""
        Dim drow As DataRow
        Dim splitVar() As String

        Dim firstColumnName As String = ""
        Dim secondColumnName As String = ""
        Dim sumUnique_8Column As Double = 0
        Dim sumUnique_3Column As Double = 0

        Dim firstColumn_8Count As Integer = 0
        Dim firstColumn_3Count As Integer = 0
        Dim allCount As Integer = 0

        Dim currentValue As Object = 0
        Dim AgentID_Current As String = ""
        Dim flagColumn As Boolean = False


        If distinctAgent.Rows.Count > 0 Then
            For m As Integer = 0 To distinctAgent.Rows.Count - 1
                drow = od.NewRow

                AgentID_Current = distinctAgent.Rows(m)("AgentID")
                drow("AgentID") = AgentID_Current

                drow("AgentName") = distinctAgent.Rows(m)("AgentName")
                drow("Alias") = distinctAgent.Rows(m)("Alias")
                For j As Integer = 1 To od.Columns.Count - 1
                    If od.Columns(j).ColumnName.ToString.Contains("_") Then  ''excluding the ? character
                        splitVar = od.Columns(j).ColumnName.Split("_")
                        firstColumnName = splitVar(0)

                        query = "AgentID='" & distinctAgent.Rows(m).Item(0) & "' AND Week='" & splitVar(1) & "'"
                        dr = InputTable.Select(query, "week")
                        If dr.Length > 0 Then
                            drow(od.Columns(j).ColumnName.ToString) = dr(0)(splitVar(0))
                            currentValue = dr(0)(splitVar(0))
                        Else
                            currentValue = 0
                        End If

                        'If Not firstColumnName.Contains("PIP") Then
                        If Not firstColumnName.Contains("PIP") Then
                            If firstColumnName = "" Then
                                firstColumn_8Count = 0
                                firstColumn_3Count = 0
                                allCount = 1
                                sumUnique_8Column += CDbl(IIf(IsDBNull(currentValue), 0, currentValue))

                            ElseIf firstColumnName <> splitVar(0) Then

                            ElseIf firstColumnName = splitVar(0) Then
                                allCount += 1
                                If CDbl(IIf(IsDBNull(currentValue), 0, currentValue)) <> 0 Then
                                    sumUnique_8Column += CDbl(IIf(IsDBNull(currentValue), 0, currentValue))
                                    firstColumn_8Count += 1
                                End If
                                If allCount >= 6 Then  'for last 3weeks
                                    If CDbl(IIf(IsDBNull(currentValue), 0, currentValue)) <> 0 Then
                                        sumUnique_3Column += CDbl(IIf(IsDBNull(currentValue), 0, currentValue))
                                        firstColumn_3Count += 1
                                    End If
                                End If
                            End If
                        End If

                    ElseIf od.Columns(j).ColumnName.ToString.Contains("?8WeekAverage") Then
                        flagColumn = False

                        'to compare current column of od in dt8Weeks_Final
                        For Each row As DataColumn In dt8Weeks_Final.Columns
                            If od.Columns(j).ColumnName.ToString.Contains(row.ColumnName) Then
                                flagColumn = True
                                Exit For
                            End If
                        Next

                        If flagColumn = True Then
                            'for columns having formula and present in dt8Weeks_Final
                            'to fetch first row from dt8Weeks_Final of corresponding AgentID and then the corresponding column
                            drow(od.Columns(j).ColumnName.ToString) = dt8Weeks_Final.Select("AgentID='" & AgentID_Current & "'")(0)(od.Columns(j).ColumnName.ToString.Replace("?8WeekAverage", ""))
                            'for coulmns having no formula and as it is before
                        ElseIf firstColumn_8Count = 0 Then
                            drow(od.Columns(j).ColumnName.ToString) = 0
                        Else
                            drow(od.Columns(j).ColumnName.ToString) = sumUnique_8Column / firstColumn_8Count
                        End If
                        firstColumn_8Count = 0
                        firstColumnName = ""
                        sumUnique_8Column = 0
                        allCount = 0
                        ' End If

                    ElseIf od.Columns(j).ColumnName.ToString.Contains("?Last3Weeks") Then
                        flagColumn = False

                        'to compare current column of od in dt3Weeks_Final
                        For Each row As DataColumn In dt3Weeks_Final.Columns
                            If od.Columns(j).ColumnName.ToString.Contains(row.ColumnName) Then
                                flagColumn = True
                                Exit For
                            End If
                        Next

                        If flagColumn = True Then
                            'for columns having formula and present in dt3Weeks_Final
                            'to fetch first row from dt3Weeks_Final of corresponding AgentID and then the corresponding column
                            drow(od.Columns(j).ColumnName.ToString) = dt3Weeks_Final.Select("AgentID='" & AgentID_Current & "'")(0)(od.Columns(j).ColumnName.ToString.Replace("?Last3Weeks", ""))
                        ElseIf firstColumn_3Count = 0 Then
                            drow(od.Columns(j).ColumnName.ToString) = 0
                        Else
                            drow(od.Columns(j).ColumnName.ToString) = sumUnique_3Column / firstColumn_3Count
                        End If
                        firstColumn_3Count = 0
                        firstColumnName = ""
                        sumUnique_3Column = 0
                        allCount = 0
                    End If
                Next
                od.Rows.Add(drow)
            Next
            '----- Remove first 5 column of dt
            Dim weekname As Integer
            If distinctWeek.Rows.Count > 3 Then
                For n As Integer = 0 To distinctWeek.Rows.Count - 4   '-4 for less than 3
                    weekname = distinctWeek.Rows(n).Item(0)
                    For p As Integer = od.Columns.Count - 1 To 1 Step -1
                        If od.Columns(p).ColumnName.Contains(weekname) Then
                            od.Columns.RemoveAt(p)
                        End If
                    Next
                Next
            End If


        End If
        Return od
    End Function

#End Region

#Region "--- Event ---"
    Protected Sub CboProcess_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles CboProcess.SelectedIndexChanged
        ProcessID = CboProcess.SelectedValue
        Common.FillCampaigns(cboCampaigns, AgentID, CboProcess.SelectedValue)
        'Dim lstcmp As New ListItem
        'lstcmp.Value = 0
        'lstcmp.Text = "All"
        'If cboCampaigns.Items.Contains(lstcmp) Then
        '    cboCampaigns.Items.Remove(lstcmp)
        'End If
        CampaignID = cboCampaigns.SelectedValue
        Fillgrid()
    End Sub
    Protected Sub imgfav_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles imgfav.Click
        Common.AddToFav(AgentID, "Weekly Report")
        SuccessMessage("Report has been added to your favourite list")
        Fillgrid()
    End Sub
    Protected Sub btnRefresh_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnRefresh.Click
        Fillgrid()
    End Sub
    Protected Sub ImageButton1_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton1.Click
        Fillgrid()
        GridViewExportUtil.Export(lblReportName.Text & ".xls", Me.gvWeeklyReport)
    End Sub
    Protected Sub cboCampaigns_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboCampaigns.SelectedIndexChanged
        Fillgrid()
    End Sub
    Protected Sub CboGroupBy_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles CboGroupBy.SelectedIndexChanged
        Fillgrid()
    End Sub
#End Region
#Region "--- Grid Ops ---"
    Protected Sub gvWeeklyReport_RowCreated(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles gvWeeklyReport.RowCreated
        If e.Row.RowType = DataControlRowType.Header Then
            For i As Integer = 4 To e.Row.Cells.Count - 1
                If e.Row.Cells(i).Text.Contains("PIP_") Then
                    e.Row.Cells(i).Text = e.Row.Cells(i).Text.Replace("PIP_", "Week ")
                ElseIf e.Row.Cells(i).Text.Contains("OverallScore_") Then
                    e.Row.Cells(i).Text = e.Row.Cells(i).Text.Replace("OverallScore_", "Week ")
                ElseIf e.Row.Cells(i).Text.Contains("OverallScore?8WeekAverage") Then
                    e.Row.Cells(i).Text = e.Row.Cells(i).Text.Replace("OverallScore?8WeekAverage", "8 Weeks Average ")
                ElseIf e.Row.Cells(i).Text.Contains("OverallScore?Last3Weeks") Then
                    e.Row.Cells(i).Text = e.Row.Cells(i).Text.Replace("OverallScore?Last3Weeks", "Last 3 Weeks ")
                ElseIf e.Row.Cells(i).Text.Contains("CPH_") Then
                    e.Row.Cells(i).Text = e.Row.Cells(i).Text.Replace("CPH_", "Week ")
                ElseIf e.Row.Cells(i).Text.Contains("CPH?8WeekAverage") Then
                    e.Row.Cells(i).Text = e.Row.Cells(i).Text.Replace("CPH?8WeekAverage", "8 Weeks Average ")
                ElseIf e.Row.Cells(i).Text.Contains("CPH?Last3Weeks") Then
                    e.Row.Cells(i).Text = e.Row.Cells(i).Text.Replace("CPH?Last3Weeks", "Last 3 Weeks ")
                ElseIf e.Row.Cells(i).Text.Contains("LoggedIn_") Then
                    e.Row.Cells(i).Text = e.Row.Cells(i).Text.Replace("LoggedIn_", "Week ")
                ElseIf e.Row.Cells(i).Text.Contains("LoggedIn?8WeekAverage") Then
                    e.Row.Cells(i).Text = e.Row.Cells(i).Text.Replace("LoggedIn?8WeekAverage", "8 Weeks Average ")
                ElseIf e.Row.Cells(i).Text.Contains("LoggedIn?Last3Weeks") Then
                    e.Row.Cells(i).Text = e.Row.Cells(i).Text.Replace("LoggedIn?Last3Weeks", "Last 3 Weeks ")
                ElseIf e.Row.Cells(i).Text.Contains("Contacts_") Then
                    e.Row.Cells(i).Text = e.Row.Cells(i).Text.Replace("Contacts_", "Week ")
                ElseIf e.Row.Cells(i).Text.Contains("Contacts?8WeekAverage") Then
                    e.Row.Cells(i).Text = e.Row.Cells(i).Text.Replace("Contacts?8WeekAverage", "8 Weeks Average ")
                ElseIf e.Row.Cells(i).Text.Contains("Contacts?Last3Weeks") Then
                    e.Row.Cells(i).Text = e.Row.Cells(i).Text.Replace("Contacts?Last3Weeks", "Last 3 Weeks ")

                ElseIf e.Row.Cells(i).Text.Contains("PartCompletes_") Then
                    e.Row.Cells(i).Text = e.Row.Cells(i).Text.Replace("PartCompletes_", "Week ")
                ElseIf e.Row.Cells(i).Text.Contains("PartCompletes?8WeekAverage") Then
                    e.Row.Cells(i).Text = e.Row.Cells(i).Text.Replace("PartCompletes?8WeekAverage", "8 Weeks Average ")
                ElseIf e.Row.Cells(i).Text.Contains("PartCompletes?Last3Weeks") Then
                    e.Row.Cells(i).Text = e.Row.Cells(i).Text.Replace("PartCompletes?Last3Weeks", "Last 3 Weeks ")

                ElseIf e.Row.Cells(i).Text.Contains("Completes_") Then
                    e.Row.Cells(i).Text = e.Row.Cells(i).Text.Replace("Completes_", "Week ")
                ElseIf e.Row.Cells(i).Text.Contains("Completes?8WeekAverage") Then
                    e.Row.Cells(i).Text = e.Row.Cells(i).Text.Replace("Completes?8WeekAverage", "8 Weeks Average ")
                ElseIf e.Row.Cells(i).Text.Contains("Completes?Last3Weeks") Then
                    e.Row.Cells(i).Text = e.Row.Cells(i).Text.Replace("Completes?Last3Weeks", "Last 3 Weeks ")

                ElseIf e.Row.Cells(i).Text.Contains("Combined Applications_") Then
                    e.Row.Cells(i).Text = e.Row.Cells(i).Text.Replace("Combined Applications_", "Week ")
                ElseIf e.Row.Cells(i).Text.Contains("Combined Applications?8WeekAverage") Then
                    e.Row.Cells(i).Text = e.Row.Cells(i).Text.Replace("Combined Applications?8WeekAverage", "8 Weeks Average ")
                ElseIf e.Row.Cells(i).Text.Contains("Combined Applications?Last3Weeks") Then
                    e.Row.Cells(i).Text = e.Row.Cells(i).Text.Replace("Combined Applications?Last3Weeks", "Last 3 Weeks ")
                ElseIf e.Row.Cells(i).Text.Contains("IdleDuration_") Then
                    e.Row.Cells(i).Text = e.Row.Cells(i).Text.Replace("IdleDuration_", "Week ")
                ElseIf e.Row.Cells(i).Text.Contains("IdleDuration?8WeekAverage") Then
                    e.Row.Cells(i).Text = e.Row.Cells(i).Text.Replace("IdleDuration?8WeekAverage", "8 Weeks Average ")
                ElseIf e.Row.Cells(i).Text.Contains("IdleDuration?Last3Weeks") Then
                    e.Row.Cells(i).Text = e.Row.Cells(i).Text.Replace("IdleDuration?Last3Weeks", "Last 3 Weeks ")
                ElseIf e.Row.Cells(i).Text.Contains("AHT_") Then
                    e.Row.Cells(i).Text = e.Row.Cells(i).Text.Replace("AHT_", "Week ")
                ElseIf e.Row.Cells(i).Text.Contains("AHT?8WeekAverage") Then
                    e.Row.Cells(i).Text = e.Row.Cells(i).Text.Replace("AHT?8WeekAverage", "8 Weeks Average ")
                ElseIf e.Row.Cells(i).Text.Contains("AHT?Last3Weeks") Then
                    e.Row.Cells(i).Text = e.Row.Cells(i).Text.Replace("AHT?Last3Weeks", "Last 3 Weeks ")
                ElseIf e.Row.Cells(i).Text.Contains("Present_") Then
                    e.Row.Cells(i).Text = e.Row.Cells(i).Text.Replace("Present_", "Week ")
                ElseIf e.Row.Cells(i).Text.Contains("Present?8WeekAverage") Then
                    e.Row.Cells(i).Text = e.Row.Cells(i).Text.Replace("Present?8WeekAverage", "8 Weeks Average ")
                ElseIf e.Row.Cells(i).Text.Contains("Present?Last3Weeks") Then
                    e.Row.Cells(i).Text = e.Row.Cells(i).Text.Replace("Present?Last3Weeks", "Last 3 Weeks ")
                ElseIf e.Row.Cells(i).Text.Contains("ConversionRate_") Then
                    e.Row.Cells(i).Text = e.Row.Cells(i).Text.Replace("ConversionRate_", "Weeks ")
                ElseIf e.Row.Cells(i).Text.Contains("ConversionRate?8WeekAverage") Then
                    e.Row.Cells(i).Text = e.Row.Cells(i).Text.Replace("ConversionRate?8WeekAverage", "8 Weeks Average ")
                ElseIf e.Row.Cells(i).Text.Contains("ConversionRate?Last3Weeks") Then
                    e.Row.Cells(i).Text = e.Row.Cells(i).Text.Replace("ConversionRate?Last3Weeks", "Last 3 Weeks ")
                End If
            Next

            Dim headerrow As GridViewRow = New GridViewRow(0, 0, DataControlRowType.Header, DataControlRowState.Insert)
            Dim cell_header As TableCell = New TableCell
            cell_header.Text = ""
            cell_header.HorizontalAlign = HorizontalAlign.Center
            cell_header.ColumnSpan = 4
            headerrow.Cells.Add(cell_header)

            cell_header = New TableCell
            cell_header.Text = "PIP"
            cell_header.HorizontalAlign = HorizontalAlign.Center
            cell_header.ColumnSpan = 3
            cell_header.BorderStyle = BorderStyle.Solid
            cell_header.BorderWidth = 1
            cell_header.BorderColor = Drawing.Color.FromName("#bbd9ee")
            cell_header.Font.Bold = True
            headerrow.Cells.Add(cell_header)

            cell_header = New TableCell
            cell_header.Text = "QA Score"
            cell_header.HorizontalAlign = HorizontalAlign.Center
            cell_header.ColumnSpan = 5
            cell_header.BorderStyle = BorderStyle.Solid
            cell_header.BorderWidth = 1
            cell_header.BorderColor = Drawing.Color.FromName("#bbd9ee")
            cell_header.Font.Bold = True
            headerrow.Cells.Add(cell_header)

            cell_header = New TableCell
            cell_header.Text = "CPH"
            cell_header.HorizontalAlign = HorizontalAlign.Center
            cell_header.ColumnSpan = 5
            cell_header.BorderStyle = BorderStyle.Solid
            cell_header.BorderWidth = 1
            cell_header.BorderColor = Drawing.Color.FromName("#bbd9ee")
            cell_header.Font.Bold = True
            headerrow.Cells.Add(cell_header)

            cell_header = New TableCell
            cell_header.Text = "Attendance (Days)"
            cell_header.HorizontalAlign = HorizontalAlign.Center
            cell_header.ColumnSpan = 5
            cell_header.BorderStyle = BorderStyle.Solid
            cell_header.BorderWidth = 1
            cell_header.BorderColor = Drawing.Color.FromName("#bbd9ee")
            cell_header.Font.Bold = True
            headerrow.Cells.Add(cell_header)

            cell_header = New TableCell
            cell_header.Text = "Log in Hours"
            cell_header.HorizontalAlign = HorizontalAlign.Center
            cell_header.ColumnSpan = 5
            cell_header.BorderStyle = BorderStyle.Solid
            cell_header.BorderWidth = 1
            cell_header.BorderColor = Drawing.Color.FromName("#bbd9ee")
            cell_header.Font.Bold = True
            headerrow.Cells.Add(cell_header)

            cell_header = New TableCell
            cell_header.Text = "Contacts"
            cell_header.HorizontalAlign = HorizontalAlign.Center
            cell_header.ColumnSpan = 5
            cell_header.BorderStyle = BorderStyle.Solid
            cell_header.BorderWidth = 1
            cell_header.BorderColor = Drawing.Color.FromName("#bbd9ee")
            cell_header.Font.Bold = True
            headerrow.Cells.Add(cell_header)

            cell_header = New TableCell
            cell_header.Text = "Completes"
            cell_header.HorizontalAlign = HorizontalAlign.Center
            cell_header.ColumnSpan = 5
            cell_header.BorderStyle = BorderStyle.Solid
            cell_header.BorderWidth = 1
            cell_header.BorderColor = Drawing.Color.FromName("#bbd9ee")
            cell_header.Font.Bold = True
            headerrow.Cells.Add(cell_header)

            cell_header = New TableCell
            cell_header.Text = "Part Completes"
            cell_header.HorizontalAlign = HorizontalAlign.Center
            cell_header.ColumnSpan = 5
            cell_header.BorderStyle = BorderStyle.Solid
            cell_header.BorderWidth = 1
            cell_header.BorderColor = Drawing.Color.FromName("#bbd9ee")
            cell_header.Font.Bold = True
            headerrow.Cells.Add(cell_header)

            cell_header = New TableCell
            cell_header.Text = "Combined Applications"
            cell_header.HorizontalAlign = HorizontalAlign.Center
            cell_header.ColumnSpan = 5
            cell_header.BorderStyle = BorderStyle.Solid
            cell_header.BorderWidth = 1
            cell_header.BorderColor = Drawing.Color.FromName("#bbd9ee")
            cell_header.Font.Bold = True
            headerrow.Cells.Add(cell_header)

            cell_header = New TableCell
            cell_header.Text = "Conversion (%)"
            cell_header.HorizontalAlign = HorizontalAlign.Center
            cell_header.ColumnSpan = 5
            cell_header.BorderStyle = BorderStyle.Solid
            cell_header.BorderWidth = 1
            cell_header.BorderColor = Drawing.Color.FromName("#bbd9ee")
            cell_header.Font.Bold = True
            headerrow.Cells.Add(cell_header)

            cell_header = New TableCell
            cell_header.Text = "Idle Time (%)"
            cell_header.HorizontalAlign = HorizontalAlign.Center
            cell_header.ColumnSpan = 5
            cell_header.BorderStyle = BorderStyle.Solid
            cell_header.BorderWidth = 1
            cell_header.BorderColor = Drawing.Color.FromName("#bbd9ee")
            cell_header.Font.Bold = True
            headerrow.Cells.Add(cell_header)

            cell_header = New TableCell
            cell_header.Text = "AHT"
            cell_header.HorizontalAlign = HorizontalAlign.Center
            cell_header.ColumnSpan = 5
            cell_header.BorderStyle = BorderStyle.Solid
            cell_header.BorderWidth = 1
            cell_header.BorderColor = Drawing.Color.FromName("#bbd9ee")
            cell_header.Font.Bold = True
            headerrow.Cells.Add(cell_header)

            gvWeeklyReport.Controls(0).Controls.AddAt(0, headerrow)
        End If
    End Sub
    Protected Sub gvWeeklyReport_RowDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles gvWeeklyReport.RowDataBound
     
        If e.Row.RowType = DataControlRowType.DataRow Then
            e.Row.Cells(2).Attributes.Add("style", "white-space:nowrap")
            e.Row.Cells(2).Style.Add("text-align", "left")
            ' e.Row.Cells(3).Attributes.Add("style", "border-color: #bbd9ee")

            e.Row.Cells(7).Text = Math.Round((IIf(e.Row.Cells(7).Text = "&nbsp;", 0, e.Row.Cells(7).Text) / 1.0), 2)
            e.Row.Cells(8).Text = Math.Round((IIf(e.Row.Cells(8).Text = "&nbsp;", 0, e.Row.Cells(8).Text) / 1.0), 2)
            e.Row.Cells(9).Text = Math.Round((IIf(e.Row.Cells(9).Text = "&nbsp;", 0, e.Row.Cells(9).Text) / 1.0), 2)

            e.Row.Cells(12).Text = Math.Round((IIf(e.Row.Cells(12).Text = "&nbsp;", 0, e.Row.Cells(12).Text) / 1.0), 2)
            e.Row.Cells(13).Text = Math.Round((IIf(e.Row.Cells(13).Text = "&nbsp;", 0, e.Row.Cells(13).Text) / 1.0), 2)
            e.Row.Cells(14).Text = Math.Round((IIf(e.Row.Cells(14).Text = "&nbsp;", 0, e.Row.Cells(14).Text) / 1.0), 2)
            e.Row.Cells(15).Text = Math.Round((e.Row.Cells(15).Text / 1.0), 2) ' 8 Week CPH
            e.Row.Cells(16).Text = Math.Round((e.Row.Cells(16).Text / 1.0), 2) ' 3 Week CPH
            e.Row.Cells(20).Text = Math.Round((e.Row.Cells(20).Text / 1.0), 0) ' 8 Week Attendance 
            e.Row.Cells(21).Text = Math.Round((e.Row.Cells(21).Text / 1.0), 0) ' 3 Week Attendance 

            e.Row.Cells(22).Text = Math.Round((IIf(e.Row.Cells(22).Text = "&nbsp;", 0, e.Row.Cells(22).Text) / 1.0), 2)
            e.Row.Cells(23).Text = Math.Round((IIf(e.Row.Cells(23).Text = "&nbsp;", 0, e.Row.Cells(23).Text) / 1.0), 2)
            e.Row.Cells(24).Text = Math.Round((IIf(e.Row.Cells(24).Text = "&nbsp;", 0, e.Row.Cells(24).Text) / 1.0), 2)
            e.Row.Cells(25).Text = Math.Round((e.Row.Cells(25).Text / 1.0), 2) ' 8 Week LoggedIn 
            e.Row.Cells(26).Text = Math.Round((e.Row.Cells(26).Text / 1.0), 2) ' 3 Week LoggedIn 
            e.Row.Cells(30).Text = Math.Round((e.Row.Cells(30).Text / 1.0), 0) ' 8 Week Contacts 
            e.Row.Cells(31).Text = Math.Round((e.Row.Cells(31).Text / 1.0), 0) ' 3 Week Contacts 
            e.Row.Cells(35).Text = Math.Round((e.Row.Cells(35).Text / 1.0), 0) ' 8 Week Completes
            e.Row.Cells(36).Text = Math.Round((e.Row.Cells(36).Text / 1.0), 0) ' 3 Week Completes
            e.Row.Cells(40).Text = Math.Round((e.Row.Cells(40).Text / 1.0), 0) ' 8 Week Part Completes
            e.Row.Cells(41).Text = Math.Round((e.Row.Cells(41).Text / 1.0), 0) ' 3 Week Part Completes
            e.Row.Cells(45).Text = Math.Round((e.Row.Cells(45).Text / 1.0), 0) ' 8 Week Combined Applications
            e.Row.Cells(46).Text = Math.Round((e.Row.Cells(46).Text / 1.0), 0) ' 3 Week Combined Applications

            e.Row.Cells(47).Text = Math.Round((IIf(e.Row.Cells(47).Text = "&nbsp;", 0, e.Row.Cells(47).Text) / 1.0), 2)
            e.Row.Cells(48).Text = Math.Round((IIf(e.Row.Cells(48).Text = "&nbsp;", 0, e.Row.Cells(48).Text) / 1.0), 2)
            e.Row.Cells(49).Text = Math.Round((IIf(e.Row.Cells(49).Text = "&nbsp;", 0, e.Row.Cells(49).Text) / 1.0), 2)
            e.Row.Cells(50).Text = Math.Round((e.Row.Cells(50).Text / 1.0), 2) ' 8 Week Conversion %
            e.Row.Cells(51).Text = Math.Round((e.Row.Cells(51).Text / 1.0), 2) ' 3 Week Conversion %

            e.Row.Cells(52).Text = Math.Round(IIf(e.Row.Cells(52).Text = "&nbsp;", 0, e.Row.Cells(52).Text) / 1.0, 2)
            e.Row.Cells(53).Text = Math.Round(IIf(e.Row.Cells(53).Text = "&nbsp;", 0, e.Row.Cells(53).Text) / 1.0, 2)
            e.Row.Cells(54).Text = Math.Round(IIf(e.Row.Cells(54).Text = "&nbsp;", 0, e.Row.Cells(54).Text) / 1.0, 2)
            e.Row.Cells(55).Text = Math.Round(e.Row.Cells(55).Text / 1.0, 2) ' 8 Week Idle Time 
            e.Row.Cells(56).Text = Math.Round(e.Row.Cells(56).Text / 1.0, 2) ' 3 Week Idle Time 

            e.Row.Cells(57).Text = Common.TimeString(IIf(e.Row.Cells(57).Text = "&nbsp;", 0, e.Row.Cells(57).Text))
            e.Row.Cells(58).Text = Common.TimeString(IIf(e.Row.Cells(58).Text = "&nbsp;", 0, e.Row.Cells(58).Text))
            e.Row.Cells(59).Text = Common.TimeString(IIf(e.Row.Cells(59).Text = "&nbsp;", 0, e.Row.Cells(59).Text))
            e.Row.Cells(60).Text = Common.TimeString(e.Row.Cells(60).Text) ' 8 Week AHT
            e.Row.Cells(61).Text = Common.TimeString(e.Row.Cells(61).Text) ' 3 Week AHT


        End If
    End Sub
#End Region
#Region "--- Utility ---"
    Private Sub AlertMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMFail"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub
    Private Sub SuccessMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMSuccess"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub
    Public Overrides Sub VerifyRenderingInServerForm(ByVal Control As Control)
    End Sub
#End Region
    
   
End Class
