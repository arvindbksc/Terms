﻿Imports com.nss.DBAccess
Imports System.Data
Imports System.Text
Partial Class Data_DrishtiReport
    Inherits System.Web.UI.Page
#Region "Properties"

    Property AgentID() As String
        Get
            Return ViewState("AgentID")
        End Get
        Set(ByVal value As String)
            ViewState("AgentID") = value
        End Set
    End Property
#End Region
   
#Region " ---- Load ---"
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        HumanMessage.Style.Item("visibility") = "hidden"
        If Not IsPostBack Then
            If Session("AgentID") <> "" Then
                AgentID = Session("AgentID")
                PanelReports.Controls.Add(Common.GetMenu(Request.Url, AgentID, Request.ApplicationPath))
                Dim db As New DBAccess
                Dim curdate = db.ReturnValue("select getdate()", False)
                db = Nothing
                ucDateFrom.value = curdate
                ucDateTo.value = curdate
                fillcampaign()
                GetData()
            End If

        End If
    End Sub
    Public Sub fillcampaign()
        Dim db As New DBAccess("CRM")
        Dim dtcampaign As New DataTable
        Dim str As String = ""
        str = "select distinct A.campaignid,B.Name as campaignname from [tbl_DHRISTI_Mst] A"
        str += " inner join tbl_DHRISTI_CampaignMst B on A.CampaignId=B.CampaignId"
        str += " where convert(varchar,[TransDate],112) between " & ucDateFrom.yyyymmdd & " and " & ucDateTo.yyyymmdd
        dtcampaign = db.ReturnTable(str, , False)
        db = Nothing
        cboCampaigns.DataTextField = "CampaignName"
        cboCampaigns.DataValueField = "CampaignID"
        cboCampaigns.DataSource = dtcampaign
        cboCampaigns.DataBind()
        dtcampaign = Nothing
    End Sub
    Dim dt As New DataTable
    Private Sub GetData()
        'Dim camp As Integer
        'If IsPostBack Then
        '    camp = cboCampaigns.SelectedValue
        'End If
        Dim db As New DBAccess("CRM")

        'Dim dt As New DataTable
        db.slDataAdd("Datefrom", ucDateFrom.yyyymmdd)
        db.slDataAdd("DateTo", ucDateTo.yyyymmdd)
        db.slDataAdd("CampaignId", cboCampaigns.SelectedValue)
        dt = db.ReturnTable("usp_getdrishtidata", , True)
        db = Nothing
        'Dim col() As String = {"CampaignName", "CampaignID"}
        'Dim dtCampaign As DataTable = dt.DefaultView.ToTable(True, col)
        'Dim row As DataRow = dtCampaign.NewRow
        'row.Item(0) = "ALL"
        'row.Item(1) = 0
        'dtCampaign.Rows.InsertAt(row, 0)
        'cboCampaigns.Items.Clear()
        'cboCampaigns.DataTextField = "CampaignName"
        'cboCampaigns.DataValueField = "CampaignID"
        'cboCampaigns.DataSource = dtCampaign
        'cboCampaigns.DataBind()
        gvDrisithiReport.DataSource = dt
        gvDrisithiReport.DataBind()

       
        
        'If IsPostBack Then
        '    cboCampaigns.SelectedValue = camp
        'End If
        'dt = Nothing
    End Sub
   
#End Region
#Region " ---- Event -----"
    Protected Sub btnRefresh_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnRefresh.Click
        fillcampaign()
        GetData()
    End Sub
    Protected Sub cboCampaigns_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboCampaigns.SelectedIndexChanged
        GetData()
    End Sub
    Protected Sub ucDateTo_Changed(ByVal sender As Object, ByVal e As System.EventArgs) Handles ucDateTo.Changed
        fillcampaign()
        GetData()
    End Sub
    Protected Sub ucDateFrom_Changed(ByVal sender As Object, ByVal e As System.EventArgs) Handles ucDateFrom.Changed
        fillcampaign()
        GetData()
    End Sub
    Protected Sub ImageButton1_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton1.Click
        GetData()
        Dim gv As New GridView
        gv.DataSource = dt
        gv.DataBind()
        GridViewExportUtil.Export(lblReportName.Text & ".xls", gv)
        ' dt = Nothing
    End Sub
#End Region

    Protected Sub gvDrisithiReport_PageIndexChanging(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewPageEventArgs) Handles gvDrisithiReport.PageIndexChanging
        gvDrisithiReport.PageIndex = e.NewPageIndex
        GetData()
    End Sub
   
    Protected Sub imgfav_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles imgfav.Click
        Common.AddToFav(AgentID, "Drishti Report")
        SuccessMessage("Report has been added to your favourite list")
        GetData()
    End Sub
#Region "Utility"

    Private Sub AlertMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMFail"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub

    Private Sub SuccessMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMSuccess"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub

    'Protected Sub ImageButton1_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton1.Click
    '    'fillgrid()
    '    GridViewExportUtil.Export(lblReportName.CurrentPage & "-" & LblError.Text & ".xls", Me.GdAttendance)
    'End Sub


    Public Overrides Sub VerifyRenderingInServerForm(ByVal Control As Control)

    End Sub

#End Region
End Class
