﻿Imports com.nss.DBAccess
Imports System.Data
Imports System.Text
Partial Class Data_SLASummaryDetail
    Inherits System.Web.UI.Page
#Region "Properties"
    Property CampaignID() As Integer
        Get
            Return ViewState("CampaignID")
        End Get
        Set(ByVal value As Integer)
            ViewState("CampaignID") = value
        End Set
    End Property
    Property hdCampaignID() As Integer
        Get
            Return ViewState("hdCampaignID")
        End Get
        Set(ByVal value As Integer)
            ViewState("hdCampaignID") = value
        End Set
    End Property
    Property AgentID() As String
        Get
            Return ViewState("AgentID")
        End Get
        Set(ByVal value As String)
            ViewState("AgentID") = value
        End Set
    End Property
    Property startday() As Integer
        Get
            Return ViewState("startday")
        End Get
        Set(ByVal value As Integer)
            ViewState("startday") = value
        End Set
    End Property
    Property endday() As Integer
        Get
            Return ViewState("endday")
        End Get
        Set(ByVal value As Integer)
            ViewState("endday") = value
        End Set
    End Property
    Property PrevDay() As DateTime
        Get
            Return ViewState("PrevDay")
        End Get
        Set(ByVal value As DateTime)
            ViewState("PrevDay") = value
        End Set
    End Property
    Property campaignname() As String
        Get
            Return ViewState("campaignname")
        End Get
        Set(ByVal value As String)
            ViewState("campaignname") = value
        End Set
    End Property
    Property categoryid() As Integer
        Get
            Return ViewState("categoryid")
        End Get
        Set(ByVal value As Integer)
            ViewState("categoryid") = value
        End Set
    End Property
    Property SLAMonth() As Integer
        Get
            Return ViewState("SLAMonth")
        End Get
        Set(ByVal value As Integer)
            ViewState("SLAMonth") = value
        End Set
    End Property
    Property SLAYear() As Integer
        Get
            Return ViewState("SLAYear")
        End Get
        Set(ByVal value As Integer)
            ViewState("SLAYear") = value
        End Set
    End Property
    Private m_currentdate As Date
    Property CurrentDate() As Date
        Get
            Return m_currentdate
        End Get
        Set(ByVal value As Date)
            m_currentdate = value
        End Set
    End Property
#End Region
    Public sb, sb1 As New StringBuilder()
    Private Sub getcategorysummary()
        sb.AppendLine("<table border='1' width='90%' style='border: 1px solid; border-collapse: collapse; font-family: Verdana; font-size: 1.2em'>")


        Dim db As New DBAccess("crm")
        PrevDay = db.ReturnValue("select CONVERT(datetime,convert(varchar," & Request.QueryString("prevday").ToString() & ",103))", False)
        db = Nothing
        db = New DBAccess("crm")
        startday = PrevDay.Year & PrevDay.Month.ToString.PadLeft(2, "0") & "01" 'db.ReturnValue("select convert(varchar,DATEPART(year," & PrevDay & ")) +  RIGHT ('00'+ CAST (DATEPART(month," & PrevDay & ") AS varchar), 2) + '01'", False)
        endday = PrevDay.Year & PrevDay.Month.ToString.PadLeft(2, "0") & PrevDay.Day.ToString.PadLeft(2, "0")
        Dim dbtarget As New DBAccess("crm")
        hdcampaignid = Request.QueryString("campaignid")
        campaignname = db.ReturnValue("select Name from tbl_config_campaigns where campaignid='" & hdcampaignid & "'", False)
        db = Nothing

        db = New DBAccess("crm")
        db.slDataAdd("DateFrom", Request.QueryString("PrevDay"))
        db.slDataAdd("DateTo", Request.QueryString("PrevDay"))
        db.slDataAdd("CampaignID", hdcampaignid)
        db.slDataAdd("SLACategoryid", Request.QueryString("categoryid"))
        db.slDataAdd("mtddayfrom", startday)
        db.slDataAdd("mtddayto", endday)
        dbtarget.slDataAdd("CampaignID", hdcampaignid)
        dbtarget.slDataAdd("SLACategoryid", Request.QueryString("categoryid"))
        dbtarget.slDataAdd("mtddayfrom", startday)
        dbtarget.slDataAdd("mtddayto", endday)

        Dim dtsummary As DataTable = db.ReturnTable("usp_getSLASummaryDetail", , True)
        db = Nothing


        Dim dtsummaryTarget As DataTable = dbtarget.ReturnTable("usp_getSLASummaryTarget", , True)
        dbtarget = Nothing
        If dtsummary.Rows.Count > 0 Then
            If Request.QueryString("categoryid") = 1 Then
                sb.AppendLine("<tr><td align='left' colspan='" & dtsummaryTarget.Columns.Count + 1 & "'><b><span style='margin-left:5px'>Service Summary for date " & PrevDay.ToString("dd-MMM-yyyy") & "</span></b></td></tr>")
            ElseIf Request.QueryString("categoryid") = 2 Then
                sb.AppendLine("<tr><td align='left' colspan='" & dtsummaryTarget.Columns.Count + 1 & "'><b><span style='margin-left:5px'>Efficiency Summary for date " & PrevDay.ToString("dd-MMM-yyyy") & "</span></b></td></tr>")
            ElseIf Request.QueryString("categoryid") = 3 Then
                sb.AppendLine("<tr><td align='left' colspan='" & dtsummaryTarget.Columns.Count + 1 & "'><b><span style='margin-left:5px'>Quality(MTD) Summary for date " & PrevDay.ToString("dd-MMM-yyyy") & "</span></b></td></tr>")
            ElseIf Request.QueryString("categoryid") = 4 Then
                sb.AppendLine("<tr><td align='left' colspan='" & dtsummaryTarget.Columns.Count + 1 & "'><b><span style='margin-left:5px'>Absenteeism Summary for date " & PrevDay.ToString("dd-MMM-yyyy") & "</span></b></td></tr>")
            ElseIf Request.QueryString("categoryid") = 0 Then
                sb.AppendLine("<tr><td align='left' colspan='" & dtsummaryTarget.Columns.Count + 1 & "'><b><span style='margin-left:5px'>Overall Summary for date " & PrevDay.ToString("dd-MMM-yyyy") & "</span></b></td></tr>")
            End If

            sb.AppendLine("<tr><td style='color:white; background-color:#632523; width:150px'>" & campaignname & "/Targets</td>")
            If dtsummaryTarget.Rows.Count > 0 Then
                For a As Integer = 0 To dtsummaryTarget.Columns.Count - 1
                    Dim dbtargetformat As New DBAccess("CRM")
                    Dim targetformat As String
                    targetformat = dbtargetformat.ReturnValue("select inputformat from tbl_config_SLAMst where SLACaption='" & dtsummaryTarget.Columns(a).ColumnName & "'", False)
                    dbtargetformat = Nothing
                    If targetformat Is Nothing Or targetformat = "" Then
                        sb.AppendLine("<td style='color:#000000; background-color:#DCE6F1'>" & dtsummaryTarget.Rows(0)(a) & "</td>")
                    Else
                        If targetformat.ToLower = "time" Then
                            sb.AppendLine("<td style='color:#000000; background-color:#DCE6F1'>" & TimeString(dtsummaryTarget.Rows(0)(a)) & "</td>")
                        Else
                            sb.AppendLine("<td style='color:#000000; background-color:#DCE6F1'>" & dtsummaryTarget.Rows(0)(a) & "</td>")
                        End If
                    End If
                Next
                ' Next
            Else
                For a As Integer = 0 To dtsummaryTarget.Columns.Count - 1
                    sb.AppendLine("<td style='color:#000000; background-color:#DCE6F1'>&nbsp;</td>")
                Next
            End If
            sb.Append("</tr><tr bgcolor='#76933C'><td>&nbsp;</td>")
            For i As Integer = 0 To dtsummary.Columns.Count - 1
                sb.AppendLine("<td>" & dtsummary.Columns(i).ColumnName & "</td>")
            Next
            sb.Append("</tr>")
        End If
        If dtsummary.Rows.Count > 0 Then
            For Each row1 As DataRow In dtsummary.Rows
                sb.Append("<tr><td>&nbsp;</td>")
                For j As Integer = 0 To dtsummary.Columns.Count - 1
                    'If j > 0 Then
                    If dtsummaryTarget.Rows.Count > 0 Then
                        Dim dbhigh As New DBAccess("crm")
                        Dim Highisbetter As Boolean
                        Dim slaformat As String
                        Dim dtsummaryvalue As DataTable

                        dtsummaryvalue = dbhigh.ReturnTable("select HigherIsBetter,inputformat from tbl_config_SLAMst where SLACaption='" & dtsummary.Columns(j).ColumnName & "'", , False)
                        dbhigh = Nothing
                        If dtsummaryvalue.Rows.Count > 0 Then
                            Highisbetter = dtsummaryvalue.Rows(0)(0)
                            slaformat = dtsummaryvalue.Rows(0)(1)

                            If dtsummaryTarget.Rows(0)(j) <> "" Then
                                If slaformat.ToLower = "time" Then
                                    If Convert.ToDouble(dtsummaryTarget.Rows(0)(j)) > Convert.ToDouble(row1(j)) And Highisbetter = True Then
                                        sb.AppendLine("<td style='color:white; background-color:#FF0000'>" & TimeString(row1(j)) & "</td>")
                                    ElseIf Convert.ToDouble(dtsummaryTarget.Rows(0)(j)) < Convert.ToDouble(row1(j)) And Highisbetter = False Then
                                        sb.AppendLine("<td style='color:white; background-color:#FF0000'>" & TimeString(row1(j)) & "</td>")
                                    Else
                                        sb.AppendLine("<td>" & TimeString(row1(j)) & "</td>")
                                    End If
                                Else
                                    If Convert.ToDouble(dtsummaryTarget.Rows(0)(j)) > Convert.ToDouble(row1(j)) And Highisbetter = True Then
                                        sb.AppendLine("<td style='color:white; background-color:#FF0000'>" & row1(j) & "</td>")
                                    ElseIf Convert.ToDouble(dtsummaryTarget.Rows(0)(j)) < Convert.ToDouble(row1(j)) And Highisbetter = False Then
                                        sb.AppendLine("<td style='color:white; background-color:#FF0000'>" & row1(j) & "</td>")
                                    Else
                                        sb.AppendLine("<td>" & row1(j) & "</td>")
                                    End If
                                End If
                            Else
                                sb.AppendLine("<td>" & row1(j) & "</td>")
                            End If
                        ElseIf Request.QueryString("categoryid") = 3 Then
                            Highisbetter = True
                            If Convert.ToDouble(dtsummaryTarget.Rows(0)(j)) > Convert.ToDouble(row1(j)) And Highisbetter = True Then
                                sb.AppendLine("<td style='color:white; background-color:#FF0000'>" & row1(j) & "</td>")
                            ElseIf Convert.ToDouble(dtsummaryTarget.Rows(0)(j)) < Convert.ToDouble(row1(j)) And Highisbetter = False Then
                                sb.AppendLine("<td style='color:white; background-color:#FF0000'>" & row1(j) & "</td>")
                            Else
                                sb.AppendLine("<td>" & row1(j) & "</td>")
                            End If
                        ElseIf Request.QueryString("categoryid") = 0 And (dtsummary.Columns(j).ColumnName = "NFAR" Or dtsummary.Columns(j).ColumnName = "FAR") Then
                            Highisbetter = True
                            If Convert.ToDouble(dtsummaryTarget.Rows(0)(j)) > Convert.ToDouble(row1(j)) And Highisbetter = True Then
                                sb.AppendLine("<td style='color:white; background-color:#FF0000'>" & row1(j) & "</td>")
                            ElseIf Convert.ToDouble(dtsummaryTarget.Rows(0)(j)) < Convert.ToDouble(row1(j)) And Highisbetter = False Then
                                sb.AppendLine("<td style='color:white; background-color:#FF0000'>" & row1(j) & "</td>")
                            Else
                                sb.AppendLine("<td>" & row1(j) & "</td>")
                            End If
                        Else
                            sb.AppendLine("<td>" & row1(j) & "</td>")
                        End If
                        'Else
                        '    sb.AppendLine("<td>" & row1(j) & "</td>")
                        'End If

                    Else
                        sb.AppendLine("<td>" & row1(j) & "</td>")
                    End If
                Next
                sb.Append("</tr>")
            Next
        End If
        sb.AppendLine("</table>")
    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        HumanMessage.Style.Item("visibility") = "hidden"
        If Not IsPostBack Then
            If Session("AgentID") <> "" Then
                AgentID = Session("AgentID")
                PanelReports.Controls.Add(Common.GetMenu(Request.Url, AgentID, Request.ApplicationPath))
                categoryid = Request.QueryString("categoryid")
                'createsummarytable()
                getcategorysummary()
                getcurrentmonth()
                getsummary()
                lblReportName.Text = "SLA Summary For " & PrevDay.ToString("dd-MMM-yyyy")
            End If
        End If
    End Sub
    Private Function TimeString(ByVal Seconds As Long) As String

        'if verbose = false, returns
        'something like
        '02:22.08
        'if true, returns
        '2 hours, 22 minutes, and 8 seconds

        Dim lHrs As Long
        Dim lMinutes As Long
        Dim lSeconds As Long

        lSeconds = Seconds

        lHrs = Int(lSeconds / 3600)
        lMinutes = (Int(lSeconds / 60)) - (lHrs * 60)
        lSeconds = Int(lSeconds Mod 60)

        If lSeconds = 60 Then
            lMinutes = lMinutes + 1
            lSeconds = 0
        End If

        If lMinutes = 60 Then
            lMinutes = 0
            lHrs = lHrs + 1
        End If

        TimeString = lHrs.ToString("####00") & ":" & _
        lMinutes.ToString("00") & ":" & _
         lSeconds.ToString("00")

    End Function
    Private Sub getsummary()
        Dim currentday As String
        Dim weekstart, weekend As String
        sb1.AppendLine("<table border='1' width='90%' style='border: 1px solid; border-collapse: collapse; font-family: Verdana; font-size: 1.2em'>")

        'SLAMonth = PrevDay.Month
        'SLAYear = PrevDay.Year
        Dim db As New DBAccess("crm")
        Dim dbtarget As New DBAccess("crm")
        'hdcampaignid = Request.QueryString("campaignid")
        'campaignname = db.ReturnValue("select Name from tbl_config_campaigns where campaignid='" & hdcampaignid & "'", False)
        'db = Nothing
        currentday = db.ReturnValue("select DATENAME(DW,getdate())", False)
        If currentday = "Monday" Then
            db.slDataAdd("Period", 3)
            db.slDataAdd("Campaignid", 0)
        Else
            db.slDataAdd("Period", 2)
            db.slDataAdd("Campaignid", 0)
        End If

        Dim dr As DataRow = db.ReturnRow("usp_GetStart_EndDateForAPeriod", True)
        db = Nothing
        weekstart = dr(0)
        weekend = dr(1)
        Dim PrevDay1 As DateTime
        db = New DBAccess("CRM")
        PrevDay1 = db.ReturnValue("select dateadd(dd,-1,getdate())", False)
        db = Nothing
        startday = PrevDay1.Year & PrevDay1.Month.ToString.PadLeft(2, "0") & "01" 'db.ReturnValue("select convert(varchar,DATEPART(year," & PrevDay & ")) +  RIGHT ('00'+ CAST (DATEPART(month," & PrevDay & ") AS varchar), 2) + '01'", False)
        endday = PrevDay1.Year & PrevDay1.Month.ToString.PadLeft(2, "0") & PrevDay1.Day.ToString.PadLeft(2, "0")
        'weekstart = PrevDay.AddDays(1 - Convert.ToDouble(PrevDay.DayOfWeek)).ToString("yyyyMMdd")
        'weekend = PrevDay.AddDays(7 - Convert.ToDouble(PrevDay.DayOfWeek)).ToString("yyyyMMdd")
        db = New DBAccess("crm")
        db.slDataAdd("DateFrom", weekstart)
        db.slDataAdd("DateTo", weekend)
        db.slDataAdd("CampaignID", hdCampaignID)
        db.slDataAdd("SLACategoryid", 10)
        db.slDataAdd("mtddayfrom", startday)
        db.slDataAdd("mtddayto", endday)

        dbtarget.slDataAdd("CampaignID", hdCampaignID)
        dbtarget.slDataAdd("SLACategoryid", 10)
        dbtarget.slDataAdd("mtddayfrom", startday)
        dbtarget.slDataAdd("mtddayto", endday)

        Dim dtsummary As DataTable = db.ReturnTable("usp_getSLASummaryDetail", , True)
        db = Nothing


        Dim dtsummaryTarget As DataTable = dbtarget.ReturnTable("usp_getSLASummaryTarget", , True)
        dbtarget = Nothing

        db = New DBAccess("CRM")
        db.slDataAdd("Month", SLAMonth)
        db.slDataAdd("Year", SLAYear)
        db.slDataAdd("CampaignID", hdCampaignID)
        db.slDataAdd("mtddayfrom", startday)
        db.slDataAdd("mtddayto", endday)
        db.slDataAdd("reporttype", 1)
        Dim dtmonthtarget As DataTable = db.ReturnTable("usp_MonthlySLASummaryTarget", , True)
        db = Nothing

        db = New DBAccess("CRM")
        db.slDataAdd("Month", SLAMonth)
        db.slDataAdd("Year", SLAYear)
        db.slDataAdd("CampaignID", hdCampaignID)
        db.slDataAdd("mtddayfrom", startday)
        db.slDataAdd("mtddayto", endday)
        Dim dtmonthsummary As DataTable = db.ReturnTable("usp_GetMonthlySLASummary", , True)
        db = Nothing

        If dtsummary.Rows.Count > 0 Or dtmonthsummary.Rows.Count > 0 Then
            sb1.AppendLine("<tr><td align='left' colspan='" & dtsummaryTarget.Columns.Count & "'><b><span style='margin-left:5px'>Week to date SLA data</span></b></td></tr>")
            sb1.AppendLine("<tr><td style='color:white; background-color:#632523; width:150px'>" & campaignname & "/Targets</td>")
            If dtsummaryTarget.Rows.Count > 0 Then
                For a As Integer = 1 To dtsummaryTarget.Columns.Count - 1
                    Dim dbtargetformat As New DBAccess("CRM")
                    Dim targetformat As String
                    targetformat = dbtargetformat.ReturnValue("select inputformat from tbl_config_SLAMst where SLACaption='" & dtsummaryTarget.Columns(a).ColumnName & "'", False)
                    dbtargetformat = Nothing
                    If targetformat Is Nothing Or targetformat = "" Then
                        sb1.AppendLine("<td style='color:#000000; background-color:#DCE6F1'>" & dtsummaryTarget.Rows(0)(a) & "</td>")
                    Else
                        If targetformat.ToLower = "time" Then
                            sb1.AppendLine("<td style='color:#000000; background-color:#DCE6F1'>" & TimeString(dtsummaryTarget.Rows(0)(a)) & "</td>")
                        Else
                            sb1.AppendLine("<td style='color:#000000; background-color:#DCE6F1'>" & dtsummaryTarget.Rows(0)(a) & "</td>")
                        End If
                    End If
                Next
                ' Next
            Else
                For a As Integer = 0 To dtsummaryTarget.Columns.Count - 1
                    sb1.AppendLine("<td style='color:#000000; background-color:#DCE6F1'>&nbsp;</td>")
                Next
            End If
            sb1.Append("</tr><tr bgcolor='#76933C'>")
            For i As Integer = 0 To dtsummary.Columns.Count - 1
                sb1.AppendLine("<td>" & dtsummary.Columns(i).ColumnName & "</td>")
            Next
            sb1.Append("</tr>")
        End If
        If dtsummary.Rows.Count > 0 Then
            For Each row1 As DataRow In dtsummary.Rows
                sb1.Append("<tr>")
                For j As Integer = 0 To dtsummary.Columns.Count - 1
                    'If j > 0 Then
                    If dtsummaryTarget.Rows.Count > 0 Then
                        Dim dbhigh As New DBAccess("crm")
                        Dim HigherIsbetter As Boolean
                        Dim slaformat As String
                        Dim dtsummaryvalue As DataTable

                        dtsummaryvalue = dbhigh.ReturnTable("select HigherIsbetter,inputformat from tbl_config_SLAMst where SLACaption='" & dtsummary.Columns(j).ColumnName & "'", , False)
                        dbhigh = Nothing
                        If dtsummaryvalue.Rows.Count > 0 Then
                            HigherIsbetter = dtsummaryvalue.Rows(0)(0)
                            slaformat = dtsummaryvalue.Rows(0)(1)

                            If dtsummaryTarget.Rows(0)(j) <> "" Then
                                If slaformat.ToLower = "time" Then
                                    If Convert.ToDouble(dtsummaryTarget.Rows(0)(j)) > Convert.ToDouble(row1(j)) And HigherIsbetter = True Then
                                        sb1.AppendLine("<td style='color:white; background-color:#FF0000'>" & TimeString(row1(j)) & "</td>")
                                    ElseIf Convert.ToDouble(dtsummaryTarget.Rows(0)(j)) < Convert.ToDouble(row1(j)) And HigherIsbetter = False Then
                                        sb1.AppendLine("<td style='color:white; background-color:#FF0000'>" & TimeString(row1(j)) & "</td>")
                                    Else
                                        sb1.AppendLine("<td>" & TimeString(row1(j)) & "</td>")
                                    End If
                                Else
                                    If Convert.ToDouble(dtsummaryTarget.Rows(0)(j)) > Convert.ToDouble(row1(j)) And HigherIsbetter = True Then
                                        sb1.AppendLine("<td style='color:white; background-color:#FF0000'>" & row1(j) & "</td>")
                                    ElseIf Convert.ToDouble(dtsummaryTarget.Rows(0)(j)) < Convert.ToDouble(row1(j)) And HigherIsbetter = False Then
                                        sb1.AppendLine("<td style='color:white; background-color:#FF0000'>" & row1(j) & "</td>")
                                    Else
                                        sb1.AppendLine("<td>" & row1(j) & "</td>")
                                    End If
                                End If
                            Else
                                sb1.AppendLine("<td>" & row1(j) & "</td>")
                            End If
                        ElseIf dtsummary.Columns(j).ColumnName = "NFAR" Or dtsummary.Columns(j).ColumnName = "FAR" Then
                            HigherIsbetter = True
                            If Convert.ToDouble(dtsummaryTarget.Rows(0)(j)) > Convert.ToDouble(row1(j)) And HigherIsbetter = True Then
                                sb1.AppendLine("<td style='color:white; background-color:#FF0000'>" & row1(j) & "</td>")
                            ElseIf Convert.ToDouble(dtsummaryTarget.Rows(0)(j)) < Convert.ToDouble(row1(j)) And HigherIsbetter = False Then
                                sb1.AppendLine("<td style='color:white; background-color:#FF0000'>" & row1(j) & "</td>")
                            Else
                                sb1.AppendLine("<td>" & row1(j) & "</td>")
                            End If
                            'ElseIf Request.QueryString("categoryid") = 0 And (dtsummary.Columns(j).ColumnName = "NFAR" Or dtsummary.Columns(j).ColumnName = "FAR") Then
                            '    HigherIsbetter = True
                            '    If Convert.ToDouble(dtsummaryTarget.Rows(0)(j)) > Convert.ToDouble(row1(j)) And HigherIsbetter = True Then
                            '        sb1.AppendLine("<td style='color:white; background-color:#FF0000'>" & row1(j) & "</td>")
                            '    ElseIf Convert.ToDouble(dtsummaryTarget.Rows(0)(j)) < Convert.ToDouble(row1(j)) And HigherIsbetter = False Then
                            '        sb1.AppendLine("<td style='color:white; background-color:#FF0000'>" & row1(j) & "</td>")
                            '    Else
                            '        sb1.AppendLine("<td>" & row1(j) & "</td>")
                            '    End If
                        Else
                            sb1.AppendLine("<td>" & row1(j) & "</td>")
                        End If
                        'Else
                        '    sb1.AppendLine("<td>" & row1(j) & "</td>")
                        'End If

                    Else
                        sb1.AppendLine("<td>" & row1(j) & "</td>")
                    End If
                Next
                sb1.Append("</tr>")
            Next
        End If
        If dtmonthsummary.Rows.Count > 0 Then

            sb1.Append("<tr bgcolor='#76933C'>")
            sb1.AppendLine("<td style='color:white'>MTD</td>")
            For k As Integer = 1 To dtmonthsummary.Columns.Count - 1
                If dtsummaryTarget.Rows.Count > 0 Then
                    Dim dbhighmonth As New DBAccess("crm")
                    Dim Highisbettermonth As Boolean
                    Dim slaformula As String = ""
                    Dim slamonthformat As String = ""
                    Dim dthigh As DataTable
                    Dim strmonth As String = ""
                    strmonth = "select A.HigherIsBetter,B.SLAFormula,A.inputformat from tbl_config_SLAMst A inner join tbl_config_SLACampaignMap B"
                    strmonth = strmonth & " on A.SLAID=B.SLAID and B.CampaignId=" & hdCampaignID & " and A.SLACaption='" & dtmonthsummary.Columns(k).ColumnName & "'"
                    dthigh = dbhighmonth.ReturnTable(strmonth, , False)
                    dbhighmonth = Nothing
                    Dim dayofmonth As Integer
                    Dim dbmonthdate As New DBAccess("report")
                    Dim startdayofmonth As Integer, enddayofmonth As Integer
                    dbmonthdate.slDataAdd("Period", 4)
                    dbmonthdate.slDataAdd("Campaignid", 0)
                    Dim drmonth As DataRow = dbmonthdate.ReturnRow("usp_GetStart_EndDateForAPeriod", True)
                    dbmonthdate = Nothing
                    startdayofmonth = drmonth(0)
                    enddayofmonth = drmonth(1)

                    dbhighmonth = New DBAccess("CRM")
                    dbhighmonth.slDataAdd("startday", startdayofmonth)
                    dbhighmonth.slDataAdd("endday", enddayofmonth)
                    dbhighmonth.slDataAdd("CampaignID", hdCampaignID)
                    dbhighmonth.slDataAdd("SLACaption", dtmonthsummary.Columns(k).ColumnName.ToString())
                    dayofmonth = dbhighmonth.ReturnValue("usp_CountSLADays", True)
                    dbhighmonth = Nothing
                    If dthigh.Rows.Count > 0 Then
                        Highisbettermonth = dthigh.Rows(0)(0)
                        slaformula = dthigh.Rows(0)(1).ToString()
                        slamonthformat = dthigh.Rows(0)(2).ToString()
                    End If


                    If slaformula <> "" Then
                        If dtsummaryTarget.Rows(0)(k) <> "" Then
                            If slamonthformat.ToLower = "time" Then
                                If Convert.ToDouble(dtsummaryTarget.Rows(0)(k)) > Convert.ToDouble(dtmonthsummary.Rows(0)(k)) And Highisbettermonth = True Then
                                    sb1.AppendLine("<td style='color:white; background-color:#FF0000'>" & TimeString(dtmonthsummary.Rows(0)(k)) & "</td>")
                                ElseIf Convert.ToDouble(dtsummaryTarget.Rows(0)(k)) < Convert.ToDouble(dtmonthsummary.Rows(0)(k)) And Highisbettermonth = False Then
                                    sb1.AppendLine("<td style='color:white; background-color:#FF0000'>" & TimeString(dtmonthsummary.Rows(0)(k)) & "</td>")
                                Else
                                    sb1.AppendLine("<td>" & TimeString(dtmonthsummary.Rows(0)(k)) & "</td>")
                                End If
                            Else
                                If Convert.ToDouble(dtsummaryTarget.Rows(0)(k)) > Convert.ToDouble(dtmonthsummary.Rows(0)(k)) And Highisbettermonth = True Then
                                    sb1.AppendLine("<td style='color:white; background-color:#FF0000'>" & dtmonthsummary.Rows(0)(k) & "</td>")
                                ElseIf Convert.ToDouble(dtsummaryTarget.Rows(0)(k)) < Convert.ToDouble(dtmonthsummary.Rows(0)(k)) And Highisbettermonth = False Then
                                    sb1.AppendLine("<td style='color:white; background-color:#FF0000'>" & dtmonthsummary.Rows(0)(k) & "</td>")
                                Else
                                    sb1.AppendLine("<td>" & dtmonthsummary.Rows(0)(k) & "</td>")
                                End If
                            End If

                        Else
                            If slamonthformat.ToLower = "time" Then
                                sb1.AppendLine("<td>" & TimeString(dtmonthsummary.Rows(0)(k)) & "</td>")
                            Else
                                sb1.AppendLine("<td>" & dtmonthsummary.Rows(0)(k) & "</td>")
                            End If

                        End If
                    Else
                        If dayofmonth = 1 Then
                            If dtsummaryTarget.Rows(0)(k) <> "" Then
                                If CampaignID = 246 Then
                                    If slamonthformat.ToLower = "time" Then
                                        If Convert.ToDouble(dtmonthtarget.Rows(0)(k)) > Convert.ToDouble(dtmonthsummary.Rows(0)(k)) And Highisbettermonth = True Then
                                            sb1.AppendLine("<td style='color:white; background-color:#FF0000'>" & TimeString(dtmonthsummary.Rows(0)(k)) & "</td>")
                                        ElseIf Convert.ToDouble(dtmonthtarget.Rows(0)(k)) < Convert.ToDouble(dtmonthsummary.Rows(0)(k)) And Highisbettermonth = False Then
                                            sb1.AppendLine("<td style='color:white; background-color:#FF0000'>" & TimeString(dtmonthsummary.Rows(0)(k)) & "</td>")
                                        Else
                                            sb1.AppendLine("<td>" & TimeString(dtmonthsummary.Rows(0)(k)) & "</td>")
                                        End If
                                    Else
                                        If Convert.ToDouble(dtmonthtarget.Rows(0)(k)) > Convert.ToDouble(dtmonthsummary.Rows(0)(k)) And Highisbettermonth = True Then
                                            sb1.AppendLine("<td style='color:white; background-color:#FF0000'>" & dtmonthsummary.Rows(0)(k) & "</td>")
                                        ElseIf Convert.ToDouble(dtmonthtarget.Rows(0)(k)) < Convert.ToDouble(dtmonthsummary.Rows(0)(k)) And Highisbettermonth = False Then
                                            sb1.AppendLine("<td style='color:white; background-color:#FF0000'>" & dtmonthsummary.Rows(0)(k) & "</td>")
                                        Else
                                            sb1.AppendLine("<td>" & dtmonthsummary.Rows(0)(k) & "</td>")
                                        End If
                                    End If
                                Else
                                    If slamonthformat.ToLower = "time" Then
                                        If Convert.ToDouble(dtsummaryTarget.Rows(0)(k)) > Convert.ToDouble(dtmonthsummary.Rows(0)(k)) And Highisbettermonth = True Then
                                            sb1.AppendLine("<td style='color:white; background-color:#FF0000'>" & TimeString(dtmonthsummary.Rows(0)(k)) & "</td>")
                                        ElseIf Convert.ToDouble(dtsummaryTarget.Rows(0)(k)) < Convert.ToDouble(dtmonthsummary.Rows(0)(k)) And Highisbettermonth = False Then
                                            sb1.AppendLine("<td style='color:white; background-color:#FF0000'>" & TimeString(dtmonthsummary.Rows(0)(k)) & "</td>")
                                        Else
                                            sb1.AppendLine("<td>" & TimeString(dtmonthsummary.Rows(0)(k)) & "</td>")
                                        End If
                                    Else
                                        If Convert.ToDouble(dtsummaryTarget.Rows(0)(k)) > Convert.ToDouble(dtmonthsummary.Rows(0)(k)) And Highisbettermonth = True Then
                                            sb1.AppendLine("<td style='color:white; background-color:#FF0000'>" & dtmonthsummary.Rows(0)(k) & "</td>")
                                        ElseIf Convert.ToDouble(dtsummaryTarget.Rows(0)(k)) < Convert.ToDouble(dtmonthsummary.Rows(0)(k)) And Highisbettermonth = False Then
                                            sb1.AppendLine("<td style='color:white; background-color:#FF0000'>" & dtmonthsummary.Rows(0)(k) & "</td>")
                                        Else
                                            sb1.AppendLine("<td>" & dtmonthsummary.Rows(0)(k) & "</td>")
                                        End If
                                    End If
                                End If
                                

                            Else
                                If slamonthformat.ToLower = "time" Then
                                    sb1.AppendLine("<td>" & TimeString(dtmonthsummary.Rows(0)(k)) & "</td>")
                                Else
                                    sb1.AppendLine("<td>" & dtmonthsummary.Rows(0)(k) & "</td>")
                                End If

                            End If
                        Else
                            If dtmonthsummary.Columns(k).ColumnName = "NFAR" Or dtmonthsummary.Columns(k).ColumnName = "FAR" Then
                                Highisbettermonth = True
                                If Convert.ToDouble(dtsummaryTarget.Rows(0)(k)) > Convert.ToDouble(dtmonthsummary.Rows(0)(k)) And Highisbettermonth = True Then
                                    sb1.AppendLine("<td style='color:white; background-color:#FF0000'>" & dtmonthsummary.Rows(0)(k) & "</td>")
                                ElseIf Convert.ToDouble(dtsummaryTarget.Rows(0)(k)) < Convert.ToDouble(dtmonthsummary.Rows(0)(k)) And Highisbettermonth = False Then
                                    sb1.AppendLine("<td style='color:white; background-color:#FF0000'>" & dtmonthsummary.Rows(0)(k) & "</td>")
                                Else
                                    sb1.AppendLine("<td>" & dtmonthsummary.Rows(0)(k) & "</td>")
                                End If
                            Else

                                If dtsummaryTarget.Rows(0)(k) <> "" Then
                                    If CampaignID = 246 Then
                                        If slamonthformat.ToLower = "time" Then
                                            If Convert.ToDouble(dtmonthtarget.Rows(0)(k)) > (Convert.ToDouble(dtmonthsummary.Rows(0)(k)) / (dayofmonth) * 1.0) And Highisbettermonth = True Then
                                                sb1.AppendLine("<td style='color:white; background-color:#FF0000'>" & TimeString(dtmonthsummary.Rows(0)(k)) & "</td>")
                                            ElseIf Convert.ToDouble(dtmonthtarget.Rows(0)(k)) < (Convert.ToDouble(dtmonthsummary.Rows(0)(k)) / (dayofmonth) * 1.0) And Highisbettermonth = False Then
                                                sb1.AppendLine("<td style='color:white; background-color:#FF0000'>" & TimeString(dtmonthsummary.Rows(0)(k)) & "</td>")
                                            Else
                                                sb1.AppendLine("<td>" & TimeString(dtmonthsummary.Rows(0)(k)) & "</td>")
                                            End If
                                        Else
                                            If Convert.ToDouble(dtmonthtarget.Rows(0)(k)) > (Convert.ToDouble(dtmonthsummary.Rows(0)(k)) / (dayofmonth) * 1.0) And Highisbettermonth = True Then
                                                sb1.AppendLine("<td style='color:white; background-color:#FF0000'>" & dtmonthsummary.Rows(0)(k) & "</td>")
                                            ElseIf Convert.ToDouble(dtmonthtarget.Rows(0)(k)) < (Convert.ToDouble(dtmonthsummary.Rows(0)(k)) / (dayofmonth) * 1.0) And Highisbettermonth = False Then
                                                sb1.AppendLine("<td style='color:white; background-color:#FF0000'>" & dtmonthsummary.Rows(0)(k) & "</td>")
                                            Else
                                                sb1.AppendLine("<td>" & dtmonthsummary.Rows(0)(k) & "</td>")
                                            End If
                                        End If
                                    Else
                                        If slamonthformat.ToLower = "time" Then
                                            If Convert.ToDouble(dtsummaryTarget.Rows(0)(k)) > (Convert.ToDouble(dtmonthsummary.Rows(0)(k)) / (dayofmonth) * 1.0) And Highisbettermonth = True Then
                                                sb1.AppendLine("<td style='color:white; background-color:#FF0000'>" & TimeString(dtmonthsummary.Rows(0)(k)) & "</td>")
                                            ElseIf Convert.ToDouble(dtsummaryTarget.Rows(0)(k)) < (Convert.ToDouble(dtmonthsummary.Rows(0)(k)) / (dayofmonth) * 1.0) And Highisbettermonth = False Then
                                                sb1.AppendLine("<td style='color:white; background-color:#FF0000'>" & TimeString(dtmonthsummary.Rows(0)(k)) & "</td>")
                                            Else
                                                sb1.AppendLine("<td>" & TimeString(dtmonthsummary.Rows(0)(k)) & "</td>")
                                            End If
                                        Else
                                            If Convert.ToDouble(dtsummaryTarget.Rows(0)(k)) > (Convert.ToDouble(dtmonthsummary.Rows(0)(k)) / (dayofmonth) * 1.0) And Highisbettermonth = True Then
                                                sb1.AppendLine("<td style='color:white; background-color:#FF0000'>" & dtmonthsummary.Rows(0)(k) & "</td>")
                                            ElseIf Convert.ToDouble(dtsummaryTarget.Rows(0)(k)) < (Convert.ToDouble(dtmonthsummary.Rows(0)(k)) / (dayofmonth) * 1.0) And Highisbettermonth = False Then
                                                sb1.AppendLine("<td style='color:white; background-color:#FF0000'>" & dtmonthsummary.Rows(0)(k) & "</td>")
                                            Else
                                                sb1.AppendLine("<td>" & dtmonthsummary.Rows(0)(k) & "</td>")
                                            End If
                                        End If
                                    End If
                                    

                                Else
                                    If slamonthformat.ToLower = "time" Then
                                        sb1.AppendLine("<td>" & TimeString(dtmonthsummary.Rows(0)(k)) & "</td>")
                                    Else
                                        sb1.AppendLine("<td>" & dtmonthsummary.Rows(0)(k) & "</td>")
                                    End If

                                End If

                            End If

                        End If
                    End If
                Else
                    sb1.AppendLine("<td style='color:white'>" & dtmonthsummary.Rows(0)(k) & "</td>")
                End If
            Next
            sb1.Append("</tr>")
            ' Next

        End If
        sb1.AppendLine("</table>")
    End Sub
    Private Sub getcurrentmonth()
        Dim db As New DBAccess("CRM")
        'TODO: change this query to stored procedure
        Dim dr As DataRow = db.ReturnRow("SELECT getdate() as currentdate")
        CurrentDate = dr("currentDate")
        SLAMonth = DatePart(DateInterval.Month, DateAdd(DateInterval.Month, 0, CurrentDate))
        SLAYear = DatePart(DateInterval.Year, DateAdd(DateInterval.Month, 0, CurrentDate))
        db = Nothing
    End Sub
End Class
