﻿Imports com.nss.DBAccess
Imports System.Data
Imports System.Text
Partial Class Data_TransactionLog
    Inherits System.Web.UI.Page

#Region "Properties"

    Property ProcessID() As Integer
        Get
            Return ViewState("ProcessID")
        End Get
        Set(ByVal value As Integer)
            ViewState("ProcessID") = value
            Session("ProcessID") = value
        End Set
    End Property
    Property Campaigntype() As Integer
        Get
            Return ViewState("Campaigntype")
        End Get
        Set(ByVal value As Integer)
            ViewState("Campaigntype") = value
            'Session("ProcessID") = value
        End Set
    End Property
    Property ReportType() As Integer
        Get
            Return ViewState("ReportType")
        End Get
        Set(ByVal value As Integer)
            ViewState("ReportType") = value
        End Set
    End Property
    Property CampaignID() As Integer
        Get
            Return ViewState("CampaignID")
        End Get
        Set(ByVal value As Integer)
            ViewState("CampaignID") = value
        End Set
    End Property

    Property AgentID() As String
        Get
            Return ViewState("AgentID")
        End Get
        Set(ByVal value As String)
            ViewState("AgentID") = value
        End Set
    End Property

    Property dtHour() As DataTable
        Get
            Return ViewState("dtHour")
        End Get
        Set(ByVal value As DataTable)
            ViewState("dtHour") = value
        End Set
    End Property

    Property dtMin() As DataTable
        Get
            Return ViewState("dtMin")
        End Get
        Set(ByVal value As DataTable)
            ViewState("dtMin") = value
        End Set
    End Property

    Property startday() As Integer
        Get
            Return ViewState("startday")
        End Get
        Set(ByVal value As Integer)
            ViewState("startday") = value
        End Set
    End Property
    Property endday() As Integer
        Get
            Return ViewState("endday")
        End Get
        Set(ByVal value As Integer)
            ViewState("endday") = value
        End Set
    End Property


    Property supervisorID() As String
        Get
            Return ViewState("supervisorID")
        End Get
        Set(ByVal value As String)
            ViewState("supervisorID") = value
        End Set
    End Property

#End Region

#Region "Load Data"
    Private Sub LoadData()
        Try
            FillCommonFilters()
            FillProcessCampaigns()
            'PopulateAgents()
            FillHourMin()
            populateSupervisors()
        Catch ex As Exception
            Throw ex
        End Try
    End Sub
#End Region

#Region "Load Functions"

    Private Sub FillCommonFilters()
        Try
            Dim db As New DBAccess
            Dim dt As DataTable = db.ReturnTable("select * from tbl_Reports_DatePeriods")
            db = Nothing
            Dim dr As DataRow = dt.NewRow
            dr(0) = 10
            dr(1) = "Between"
            dt.Rows.Add(dr)
            CboPeriod.DataTextField = "Caption"
            CboPeriod.DataValueField = "Period"
            CboPeriod.DataSource = dt
            CboPeriod.DataBind()
        Catch ex As Exception
            Throw ex
        End Try
    End Sub

    Private Sub FillProcessCampaigns()
        Try
            Common.FillProcesses(CboProcess, AgentID)
            'Common.FillProcessCampaigns(CboProcess, cboCampaigns, AgentID, CampaignID)
            Dim lstprocess As New ListItem
            lstprocess.Value = 0
            lstprocess.Text = "All"
            If CboProcess.Items.Contains(lstprocess) Then
                CboProcess.Items.Remove(lstprocess)
            End If
            Dim db As New DBAccess
            db.slDataAdd("Agentid", AgentID)
            CboProcess.SelectedValue = db.ReturnRow("usp_getAgentProcess", True)(4)
            ProcessID = CboProcess.SelectedValue
            db = Nothing

            ' Common.FillCampaigns(cboCampaigns, AgentID, CboProcess.SelectedValue)

        Catch ex As Exception
            Throw ex
        End Try
    End Sub

    Private Sub FillHourMin()
        Try
            Dim colHour As DataColumn = New DataColumn("Hour", System.Type.GetType("System.String"))
            If dtHour Is Nothing Then
                dtHour = New DataTable
                If Not dtHour.Columns.Contains("Hour") Then
                    dtHour.Columns.Add(colHour)

                    Dim rowHour As DataRow '= dtHour.NewRow

                    rowHour = dtHour.NewRow
                    rowHour("Hour") = "NA"
                    dtHour.Rows.Add(rowHour)

                    For i As Integer = 13 To 23
                        rowHour = dtHour.NewRow
                        If i < 10 Then
                            rowHour("Hour") = "0" & i.ToString
                        Else
                            rowHour("Hour") = i.ToString
                        End If
                        dtHour.Rows.Add(rowHour)
                    Next

                    For i As Integer = 0 To 4
                        rowHour = dtHour.NewRow
                        If i < 10 Then
                            rowHour("Hour") = "0" & i.ToString
                        Else
                            rowHour("Hour") = i.ToString
                        End If
                        dtHour.Rows.Add(rowHour)
                    Next
                End If
            End If
            '-----------------------------------------------------------------------------------------------------
            Dim colMin As DataColumn = New DataColumn("Min", System.Type.GetType("System.String"))
            If dtMin Is Nothing Then
                dtMin = New DataTable
                If Not dtMin.Columns.Contains("Min") Then
                    dtMin.Columns.Add(colMin)

                    Dim rowMin As DataRow '= dtMin.NewRow

                    rowMin = dtMin.NewRow
                    rowMin("Min") = "NA"
                    dtMin.Rows.Add(rowMin)

                    For i As Integer = 0 To 59
                        rowMin = dtMin.NewRow
                        If i < 10 Then
                            rowMin("Min") = "0" & i.ToString
                        Else
                            rowMin("Min") = i.ToString
                        End If
                        dtMin.Rows.Add(rowMin)
                    Next
                End If
            End If
        Catch ex As Exception
            Throw ex
        End Try
    End Sub

    Private Sub populateSupervisors()
        Try
            Dim db As New DBAccess
            db.slDataAdd("processid", ProcessID)
            Dim dt As DataTable = db.ReturnTable("usp_ProcessSupervisors", "", True)

            cboSupervisor.DataSource = Nothing
            cboSupervisor.DataTextField = "AgentName"
            cboSupervisor.DataValueField = "agentid"
            cboSupervisor.DataSource = dt
            cboSupervisor.DataBind()
            'cboSupervisor.SelectedValue = AgentID  '' to populate the current supervisor
            supervisorID = cboSupervisor.SelectedValue
            db = Nothing
            dt = Nothing

            If CboPeriod.SelectedValue <> 0 Then '' NOT for today 
                Dim lstagent As New ListItem
                lstagent.Value = "%"
                lstagent.Text = "All"
                cboSupervisor.Items.Add(lstagent)
                'cboSupervisor.SelectedValue = "%"
            End If
           
        Catch ex As Exception
            ' LblError.Visible = True
            ' LblError.Text = ex.Message.ToString
            ' AlertMessage(ex.Message)
        End Try
    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Try
            HumanMessage.Style.Item("visibility") = "hidden"
            If Not IsPostBack Then
                ReportType = Request.QueryString("ReportType")
                If Session("AgentID") <> "" Then
                    ucDateFrom.value = DateTime.Now  'to initialise time

                    ' CampaignID = Session("CampaignID")
                    AgentID = Session("AgentID")
                    PanelReports.Controls.Add(Common.GetMenu(Request.Url, AgentID, Request.ApplicationPath))
                    LoadData()
                    fillgrid()
                    UcDateTo.Visible = False
                    ucDateFrom.Visible = False
                    lblAnd.Visible = False
                End If
            Else
                'gvDataTimeSlot.EditIndex = -1
                fillgrid()
            End If

        Catch ex As Exception
            AlertMessage(ex.Message)
        End Try
    End Sub

    Private Sub fillgrid()
        Try
            Dim db As DBAccess
            If CboPeriod.SelectedValue = 10 Then
                startday = ucDateFrom.yyyymmdd
                endday = UcDateTo.yyyymmdd
            Else
                db = New DBAccess
                db.slDataAdd("Period", CboPeriod.SelectedValue)
                'db.slDataAdd("Campaignid", CampaignID)
                db.slDataAdd("Campaignid", 208)  '' for script_1  ,remain it
                Dim dr As DataRow = db.ReturnRow("usp_GetStart_EndDateForAPeriod", True)
                db = Nothing
                startday = dr(0)
                endday = dr(1)
            End If


            If CboPeriod.SelectedValue = 0 Then '' for today only
                Dim dtNew As DataTable
                db = New DBAccess
                db.slDataAdd("startday", startday)
                db.slDataAdd("endDay", endday)
                db.slDataAdd("processid", ProcessID)
                db.slDataAdd("supervisorID", supervisorID)
                ' db.slDataAdd("supervisorID", "NSS42330")
                ' dt = db.ReturnTable("usp_getOrionTimeSlotData", , True)
                dtNew = db.ReturnTable("usp_getOrionTimeSlotData_2", , True)
                db = Nothing

                lblReportName.Text = "Break Time Slot "
                LblError.Text = "Between " & IntegerToDateString(startday) & "  and " & IntegerToDateString(endday) & " for " & CboProcess.SelectedItem.Text & " Process"

                If dtNew.Rows.Count > 0 Then
                    gvDataTimeSlot2.DataSource = dtNew
                    gvDataTimeSlot2.DataBind()
                    dtNew = Nothing
                    btnSave.Visible = True
                    btnCancel.Visible = True
                Else
                    gvDataTimeSlot2.DataSource = Nothing
                    gvDataTimeSlot2.DataBind()
                    btnSave.Visible = False
                    btnCancel.Visible = False
                End If

            Else   '' other than today

                Dim dtAll As DataTable
                db = New DBAccess
                db.slDataAdd("startday", startday)
                db.slDataAdd("endDay", endday)
                db.slDataAdd("processid", ProcessID)
                db.slDataAdd("supervisorID", supervisorID)
                ' db.slDataAdd("supervisorID", "NSS42330")
                ' dt = db.ReturnTable("usp_getOrionTimeSlotData", , True)
                dtAll = db.ReturnTable("usp_getOrionTimeSlotData_All", , True)
                db = Nothing

                lblReportName.Text = "Break Time Slot "
                LblError.Text = "Between " & IntegerToDateString(startday) & "  and " & IntegerToDateString(endday) & " for " & CboProcess.SelectedItem.Text & " Process"

                btnSave.Visible = False
                btnCancel.Visible = False

                If dtAll.Rows.Count > 0 Then
                    gvAllData.DataSource = dtAll
                    gvAllData.DataBind()
                    dtAll = Nothing
                Else
                    gvAllData.DataSource = Nothing
                    gvAllData.DataBind()
                End If

            End If

            ' ScriptManager.RegisterStartupScript(Me, Me.GetType(), "SortGrid", "$(function(){{$('#" & gvDataTimeSlot.ClientID & "').tablesorter({cancelSelection:true}); }});", True)
        Catch ex As Exception
            Throw ex
        End Try
    End Sub
#End Region

#Region "Events"

    Protected Sub CboPeriod_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles CboPeriod.SelectedIndexChanged
        Try

            '''' Remove "All" or Add "All" in cboSupervisor combobox accorrding to the selected value in CboPeriod  (for today and other than today)
            ''-----------------------Start
            Dim flag_ALL As Boolean = False
            For Each listit As ListItem In cboSupervisor.Items  ''check in supervisors
                If listit.Text = "All" Then
                    flag_ALL = True
                    Exit For
                End If
            Next

            If CboPeriod.SelectedValue = 0 Then '' for today 
                If flag_ALL = True Then    '' i.e "All" is present
                    For Each listit As ListItem In cboSupervisor.Items  ''check in supervisors
                        If listit.Text = "All" Then
                            cboSupervisor.Items.Remove(listit) '''''remove "All"
                            Exit For
                        End If
                    Next
                Else '''''for false
                End If

            Else    ''other than today
                If flag_ALL = True Then    '' i.e "All" is present
                Else '''''for false
                    Dim lstagent As New ListItem
                    lstagent.Value = "%"
                    lstagent.Text = "All"
                    cboSupervisor.Items.Add(lstagent)
                    ' cboSupervisor.SelectedValue = "%"
                End If
            End If
            supervisorID = cboSupervisor.SelectedValue
            ''''---------------------------End


            If CboPeriod.SelectedValue = 10 Then
                ucDateFrom.Visible = True
                UcDateTo.Visible = True
                lblAnd.Visible = True
                fillgrid()
            Else
                ucDateFrom.Visible = False
                UcDateTo.Visible = False
                lblAnd.Visible = False
                fillgrid()
            End If
        Catch ex As Exception
            AlertMessage(ex.Message)
        End Try
    End Sub

    Protected Sub btnRefresh_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnRefresh.Click
        Try
            fillgrid()
        Catch ex As Exception
            AlertMessage(ex.Message)
        End Try
    End Sub

    Protected Sub imgfav_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles imgfav.Click
        Try
            Common.AddToFav(AgentID, "Break Adherence TimeSlot")
            SuccessMessage("Report has been added to your favourite list")
            fillgrid()
        Catch ex As Exception
            AlertMessage(ex.Message)
        End Try
    End Sub

    Protected Sub gvDataTimeSlot2_RowDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles gvDataTimeSlot2.RowDataBound
        Try
            If e.Row.RowType = DataControlRowType.Header Then  'for header
                'If CboPeriod.SelectedValue <> 0 Then   ''''i.e. not equal to today  i.e. if e.g. yesterday
                '    e.Row.Cells(5).Visible = False  'to hide the Delete/Edit Buttons
                'End If

            ElseIf e.Row.RowType = DataControlRowType.DataRow Then
                ''''Start Time
                Dim gvddlHourStartTime1 As DropDownList = CType(e.Row.FindControl("gvddlHourStartTimeSlot1"), DropDownList)
                Dim gvddlMinStartTime1 As DropDownList = CType(e.Row.FindControl("gvddlMinStartTimeSlot1"), DropDownList)

                Dim hdfStartHour1 As HiddenField = CType(e.Row.FindControl("gvHdfHourStartTime1"), HiddenField)
                Dim hdfStartMin1 As HiddenField = CType(e.Row.FindControl("gvHdfMinStartTime1"), HiddenField)

                ''''End Time
                Dim gvddlHourEndTime1 As DropDownList = CType(e.Row.FindControl("gvddlHourEndTimeSlot1"), DropDownList)
                Dim gvddlMinEndTime1 As DropDownList = CType(e.Row.FindControl("gvddlMinEndTimeSlot1"), DropDownList)

                Dim hdfEndHour1 As HiddenField = CType(e.Row.FindControl("gvHdfHourEndTime1"), HiddenField)
                Dim hdfEndMin1 As HiddenField = CType(e.Row.FindControl("gvHdfMinEndTime1"), HiddenField)

                BindDropDownListHourMinute(gvddlHourStartTime1, gvddlMinStartTime1, hdfStartHour1, hdfStartMin1, gvddlHourEndTime1, gvddlMinEndTime1, hdfEndHour1, hdfEndMin1)
                'If Not gvddlHourEndTime Is Nothing Then
                '    gvddlHourEndTime.DataTextField = "Hour"
                '    gvddlHourEndTime.DataValueField = "Hour"
                '    gvddlHourEndTime.DataSource = dtHour
                '    gvddlHourEndTime.DataBind()
                '    gvddlHourEndTime.SelectedValue = IIf(CType(e.Row.FindControl("gvHdfHourEndTime"), HiddenField).Value < 10, "0" & CType(e.Row.FindControl("gvHdfHourEndTime"), HiddenField).Value.ToString, CType(e.Row.FindControl("gvHdfHourEndTime"), HiddenField).Value)
                'End If

                'If Not gvddlMinEndTime Is Nothing Then
                '    gvddlMinEndTime.DataTextField = "Min"
                '    gvddlMinEndTime.DataValueField = "Min"
                '    gvddlMinEndTime.DataSource = dtMin
                '    gvddlMinEndTime.DataBind()
                '    gvddlMinEndTime.SelectedValue = IIf(CType(e.Row.FindControl("gvHdfMinEndTime"), HiddenField).Value < 10, "0" & CType(e.Row.FindControl("gvHdfMinEndTime"), HiddenField).Value.ToString, CType(e.Row.FindControl("gvHdfMinEndTime"), HiddenField).Value)
                'End If


                Dim gvddlHourStartTime2 As DropDownList = CType(e.Row.FindControl("gvddlHourStartTimeSlot2"), DropDownList)
                Dim gvddlMinStartTime2 As DropDownList = CType(e.Row.FindControl("gvddlMinStartTimeSlot2"), DropDownList)

                Dim hdfStartHour2 As HiddenField = CType(e.Row.FindControl("gvHdfHourStartTime2"), HiddenField)
                Dim hdfStartMin2 As HiddenField = CType(e.Row.FindControl("gvHdfMinStartTime2"), HiddenField)

                Dim gvddlHourEndTime2 As DropDownList = CType(e.Row.FindControl("gvddlHourEndTimeSlot2"), DropDownList)
                Dim gvddlMinEndTime2 As DropDownList = CType(e.Row.FindControl("gvddlMinEndTimeSlot2"), DropDownList)

                Dim hdfEndHour2 As HiddenField = CType(e.Row.FindControl("gvHdfHourEndTime2"), HiddenField)
                Dim hdfEndMin2 As HiddenField = CType(e.Row.FindControl("gvHdfMinEndTime2"), HiddenField)

                BindDropDownListHourMinute(gvddlHourStartTime2, gvddlMinStartTime2, hdfStartHour2, hdfStartMin2, gvddlHourEndTime2, gvddlMinEndTime2, hdfEndHour2, hdfEndMin2)

                '---------------
                Dim gvddlHourStartTime3 As DropDownList = CType(e.Row.FindControl("gvddlHourStartTimeSlot3"), DropDownList)
                Dim gvddlMinStartTime3 As DropDownList = CType(e.Row.FindControl("gvddlMinStartTimeSlot3"), DropDownList)

                Dim hdfStartHour3 As HiddenField = CType(e.Row.FindControl("gvHdfHourStartTime3"), HiddenField)
                Dim hdfStartMin3 As HiddenField = CType(e.Row.FindControl("gvHdfMinStartTime3"), HiddenField)

                Dim gvddlHourEndTime3 As DropDownList = CType(e.Row.FindControl("gvddlHourEndTimeSlot3"), DropDownList)
                Dim gvddlMinEndTime3 As DropDownList = CType(e.Row.FindControl("gvddlMinEndTimeSlot3"), DropDownList)

                Dim hdfEndHour3 As HiddenField = CType(e.Row.FindControl("gvHdfHourEndTime3"), HiddenField)
                Dim hdfEndMin3 As HiddenField = CType(e.Row.FindControl("gvHdfMinEndTime3"), HiddenField)

                BindDropDownListHourMinute(gvddlHourStartTime3, gvddlMinStartTime3, hdfStartHour3, hdfStartMin3, gvddlHourEndTime3, gvddlMinEndTime3, hdfEndHour3, hdfEndMin3)
                '---------------
                Dim gvddlHourStartTime4 As DropDownList = CType(e.Row.FindControl("gvddlHourStartTimeSlot4"), DropDownList)
                Dim gvddlMinStartTime4 As DropDownList = CType(e.Row.FindControl("gvddlMinStartTimeSlot4"), DropDownList)

                Dim hdfStartHour4 As HiddenField = CType(e.Row.FindControl("gvHdfHourStartTime4"), HiddenField)
                Dim hdfStartMin4 As HiddenField = CType(e.Row.FindControl("gvHdfMinStartTime4"), HiddenField)

                Dim gvddlHourEndTime4 As DropDownList = CType(e.Row.FindControl("gvddlHourEndTimeSlot4"), DropDownList)
                Dim gvddlMinEndTime4 As DropDownList = CType(e.Row.FindControl("gvddlMinEndTimeSlot4"), DropDownList)

                Dim hdfEndHour4 As HiddenField = CType(e.Row.FindControl("gvHdfHourEndTime4"), HiddenField)
                Dim hdfEndMin4 As HiddenField = CType(e.Row.FindControl("gvHdfMinEndTime4"), HiddenField)

                BindDropDownListHourMinute(gvddlHourStartTime4, gvddlMinStartTime4, hdfStartHour4, hdfStartMin4, gvddlHourEndTime4, gvddlMinEndTime4, hdfEndHour4, hdfEndMin4)

                '---------------
                Dim gvddlHourStartTime5 As DropDownList = CType(e.Row.FindControl("gvddlHourStartTimeSlot5"), DropDownList)
                Dim gvddlMinStartTime5 As DropDownList = CType(e.Row.FindControl("gvddlMinStartTimeSlot5"), DropDownList)

                Dim hdfStartHour5 As HiddenField = CType(e.Row.FindControl("gvHdfHourStartTime5"), HiddenField)
                Dim hdfStartMin5 As HiddenField = CType(e.Row.FindControl("gvHdfMinStartTime5"), HiddenField)

                Dim gvddlHourEndTime5 As DropDownList = CType(e.Row.FindControl("gvddlHourEndTimeSlot5"), DropDownList)
                Dim gvddlMinEndTime5 As DropDownList = CType(e.Row.FindControl("gvddlMinEndTimeSlot5"), DropDownList)

                Dim hdfEndHour5 As HiddenField = CType(e.Row.FindControl("gvHdfHourEndTime5"), HiddenField)
                Dim hdfEndMin5 As HiddenField = CType(e.Row.FindControl("gvHdfMinEndTime5"), HiddenField)

                BindDropDownListHourMinute(gvddlHourStartTime5, gvddlMinStartTime5, hdfStartHour5, hdfStartMin5, gvddlHourEndTime5, gvddlMinEndTime5, hdfEndHour5, hdfEndMin5)

            End If

        Catch ex As Exception
            AlertMessage(ex.Message & "T")
        End Try

    End Sub

    Protected Sub btnSave_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnSave.Click

        Dim headerCount As Integer = 0
        Try
            If validation() = False Then
                Exit Sub
            End If

            btnSave.Enabled = False
            For i = 0 To gvDataTimeSlot2.Columns.Count - 1
                If gvDataTimeSlot2.Columns(i).HeaderText <> "Agents" And gvDataTimeSlot2.Columns(i).HeaderText <> "S.No." Then
                    headerCount = headerCount + 1
                    For Each gvrow As GridViewRow In gvDataTimeSlot2.Rows
                        Dim employeeID As String = CType(gvrow.FindControl("hdfAgentID"), HiddenField).Value

                        Dim StartTimeHour As String = CType(gvrow.FindControl("gvddlHourStartTimeSlot" & headerCount), DropDownList).SelectedValue
                        Dim StartTimeMin As String = CType(gvrow.FindControl("gvddlMinStartTimeSlot" & headerCount), DropDownList).SelectedValue
                        Dim EndTimeHour As String = CType(gvrow.FindControl("gvddlHourEndTimeSlot" & headerCount), DropDownList).SelectedValue
                        Dim EndTimeMin As String = CType(gvrow.FindControl("gvddlMinEndTimeSlot" & headerCount), DropDownList).SelectedValue

                        '''''not saving data if all values are "NA"
                        If StartTimeHour <> "NA" And StartTimeMin <> "NA" And EndTimeHour <> "NA" And EndTimeMin <> "NA" Then
                            Dim db As DBAccess = New DBAccess
                            db.slDataAdd("Mode", "UpdateInsert")
                            db.slDataAdd("processid", ProcessID)
                            db.slDataAdd("AgentID", employeeID)
                            db.slDataAdd("slotname", gvDataTimeSlot2.Columns(i).HeaderText.Replace(" ", ""))

                            db.slDataAdd("StartTimeHour", IIf(StartTimeHour = "NA", -1, StartTimeHour))
                            db.slDataAdd("StartTimeMin", IIf(StartTimeMin = "NA", -1, StartTimeMin))
                            db.slDataAdd("EndTimeHour", IIf(EndTimeHour = "NA", -1, EndTimeHour))
                            db.slDataAdd("EndTimeMin", IIf(EndTimeMin = "NA", -1, EndTimeMin))

                            db.slDataAdd("filledby", AgentID)   ''session of current user

                            db.Executeproc("usp_InserUpdateOrionTimeSlotData_2")
                            db = Nothing

                            'for entries having only "NA" entry the delete that entry from DB if exists
                        ElseIf StartTimeHour = "NA" And StartTimeMin = "NA" And EndTimeHour = "NA" And EndTimeMin = "NA" Then
                            Dim db As DBAccess = New DBAccess
                            db.slDataAdd("Mode", "DELETE")
                            db.slDataAdd("processid", ProcessID)
                            db.slDataAdd("AgentID", employeeID)
                            db.slDataAdd("slotname", gvDataTimeSlot2.Columns(i).HeaderText.Replace(" ", ""))

                            db.slDataAdd("StartTimeHour", IIf(StartTimeHour = "NA", -1, StartTimeHour))
                            db.slDataAdd("StartTimeMin", IIf(StartTimeMin = "NA", -1, StartTimeMin))
                            db.slDataAdd("EndTimeHour", IIf(EndTimeHour = "NA", -1, EndTimeHour))
                            db.slDataAdd("EndTimeMin", IIf(EndTimeMin = "NA", -1, EndTimeMin))

                            db.slDataAdd("filledby", AgentID)   ''session of current user


                            db.Executeproc("usp_InserUpdateOrionTimeSlotData_2")
                            db = Nothing

                        End If

                    Next
                End If
            Next
            btnSave.Enabled = True
            fillgrid()
            SuccessMessage("Data Saved successfully")  '''' if no exception occurs

        Catch ex As Exception
            AlertMessage(ex.Message)
        End Try
    End Sub

    Protected Sub CboProcess_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles CboProcess.SelectedIndexChanged
        Try
            ProcessID = CboProcess.SelectedValue
            populateSupervisors()
            fillgrid()
        Catch ex As Exception
            AlertMessage(ex.Message)
        End Try
    End Sub

    Protected Sub cboSupervisor_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboSupervisor.SelectedIndexChanged
        Try
            supervisorID = cboSupervisor.SelectedValue
            fillgrid()
        Catch ex As Exception
            AlertMessage(ex.Message)
        End Try
    End Sub

    Protected Sub btnCancel_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnCancel.Click
        Try
            fillgrid()
        Catch ex As Exception
            AlertMessage(ex.Message)
        End Try
    End Sub
#End Region

#Region "Support Functions"
    Private Function IntegerToDateString(ByVal d As Integer) As String
        Try
            Return d.ToString.Substring(0, 4) & "-" & d.ToString.Substring(4, 2) & "-" & d.ToString.Substring(6, 2)
        Catch ex As Exception
            Throw ex
        End Try
    End Function

    Public Function TimeString(ByVal Seconds As Long) As String
        Try
            'if verbose = false, returns
            'something like
            '02:22.08
            'if true, returns
            '2 hours, 22 minutes, and 8 seconds

            Dim lHrs As Long
            Dim lMinutes As Long
            Dim lSeconds As Long

            lSeconds = Seconds

            lHrs = Int(lSeconds / 3600)
            lMinutes = (Int(lSeconds / 60)) - (lHrs * 60)
            lSeconds = Int(lSeconds Mod 60)

            If lSeconds = 60 Then
                lMinutes = lMinutes + 1
                lSeconds = 0
            End If

            If lMinutes = 60 Then
                lMinutes = 0
                lHrs = lHrs + 1
            End If

            TimeString = lHrs.ToString("####00") & ":" & _
            lMinutes.ToString("00") & ":" & _
             lSeconds.ToString("00")
        Catch ex As Exception
            Throw ex
        End Try
    End Function

    Private Function validation() As Boolean
        Try
            Dim flag As Boolean = True

            Dim headerCount As Integer = 0

            For i = 0 To gvDataTimeSlot2.Columns.Count - 1
                If gvDataTimeSlot2.Columns(i).HeaderText <> "Agents" And gvDataTimeSlot2.Columns(i).HeaderText <> "S.No." Then
                    headerCount = headerCount + 1
                    For Each gvrow As GridViewRow In gvDataTimeSlot2.Rows
                        Dim employeeID As String = CType(gvrow.FindControl("hdfAgentID"), HiddenField).Value
                        Dim employeeName As String = CType(gvrow.FindControl("gvLblAgent"), Label).Text

                        Dim StartTimeHour As String = CType(gvrow.FindControl("gvddlHourStartTimeSlot" & headerCount), DropDownList).SelectedValue
                        Dim StartTimeMin As String = CType(gvrow.FindControl("gvddlMinStartTimeSlot" & headerCount), DropDownList).SelectedValue
                        Dim EndTimeHour As String = CType(gvrow.FindControl("gvddlHourEndTimeSlot" & headerCount), DropDownList).SelectedValue
                        Dim EndTimeMin As String = CType(gvrow.FindControl("gvddlMinEndTimeSlot" & headerCount), DropDownList).SelectedValue

                        '''''not saving data if all values are "NA"
                        ''Validation 1

                        If StartTimeHour <> "NA" Or StartTimeMin <> "NA" Or EndTimeHour <> "NA" Or EndTimeMin <> "NA" Then ''''if anyone is not "NA" i.e.  13 hours
                            If StartTimeHour = "NA" Or StartTimeMin = "NA" Or EndTimeHour = "NA" Or EndTimeMin = "NA" Then  '' if atleast one is "NA"
                                flag = False
                                AlertMessage("The whole part should be defined for " & employeeName & "  & Slot is " & gvDataTimeSlot2.Columns(i).HeaderText)
                                Return flag
                            End If
                        End If

                        ''Validation 2
                        If StartTimeHour <> "NA" And StartTimeMin <> "NA" And EndTimeHour <> "NA" And EndTimeMin <> "NA" Then
                            If StartTimeHour > EndTimeHour Then  ''incorrect
                                'If StartTimeHour = 23 Then   ''i.e last hour exclude it
                                '    flag = True
                                '    Return flag
                                'Else  '''''any hour other than 23 then include it.
                                flag = False
                                AlertMessage("The Start Time cannot be greater than End Time.")
                                Return flag
                                'End If
                            ElseIf StartTimeHour = EndTimeHour Then
                                If StartTimeMin >= EndTimeMin Then
                                    flag = False
                                    AlertMessage("The Start Time cannot be greater\equal to End Time.")
                                    Return flag
                                End If
                            Else  ''''  StartTimeHour < EndTimeHour
                                ''''Do Nothing
                            End If

                        End If

                    Next
                End If
            Next

            Return flag

        Catch ex As Exception
            Throw ex
        End Try
    End Function

    Private Sub BindDropDownListHourMinute(ByVal gvddlHourStartTime As DropDownList, ByVal gvddlMinStartTime As DropDownList, ByVal hdfStartHour As HiddenField, ByVal hdfStartMin As HiddenField, ByVal gvddlHourEndTime As DropDownList, ByVal gvddlMinEndTime As DropDownList, ByVal hdfEndHour As HiddenField, ByVal hdfEndMin As HiddenField)
        Try
            If Not gvddlHourStartTime Is Nothing Then
                gvddlHourStartTime.DataTextField = "Hour"
                gvddlHourStartTime.DataValueField = "Hour"
                gvddlHourStartTime.DataSource = dtHour
                gvddlHourStartTime.DataBind()
                'gvddlHourStartTime.SelectedValue = IIf(CType(e.Row.FindControl("gvHdfHourStartTime"), HiddenField).Value < 10, "0" & CType(e.Row.FindControl("gvHdfHourStartTime"), HiddenField).Value.ToString, CType(e.Row.FindControl("gvHdfHourStartTime"), HiddenField).Value)
                gvddlHourStartTime.SelectedValue = IIf(hdfStartHour.Value < 10, "0" & hdfStartHour.Value.ToString, hdfStartHour.Value)
            End If

            If Not gvddlMinStartTime Is Nothing Then
                gvddlMinStartTime.DataTextField = "Min"
                gvddlMinStartTime.DataValueField = "Min"
                gvddlMinStartTime.DataSource = dtMin
                gvddlMinStartTime.DataBind()
                gvddlMinStartTime.SelectedValue = IIf(hdfStartMin.Value < 10, "0" & hdfStartMin.Value.ToString, hdfStartMin.Value)
            End If

            If Not gvddlHourEndTime Is Nothing Then
                gvddlHourEndTime.DataTextField = "Hour"
                gvddlHourEndTime.DataValueField = "Hour"
                gvddlHourEndTime.DataSource = dtHour
                gvddlHourEndTime.DataBind()
                gvddlHourEndTime.SelectedValue = IIf(hdfEndHour.Value < 10, "0" & hdfEndHour.Value.ToString, hdfEndHour.Value)
            End If

            If Not gvddlMinEndTime Is Nothing Then
                gvddlMinEndTime.DataTextField = "Min"
                gvddlMinEndTime.DataValueField = "Min"
                gvddlMinEndTime.DataSource = dtMin
                gvddlMinEndTime.DataBind()
                gvddlMinEndTime.SelectedValue = IIf(hdfEndMin.Value < 10, "0" & hdfEndMin.Value.ToString, hdfEndMin.Value)
            End If

        Catch ex As Exception
            Throw ex
        End Try
    End Sub

#End Region

#Region "Utility"
    Private Sub AlertMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMFail"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub

    Private Sub SuccessMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMSuccess"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub

    'Protected Sub ImageButton1_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton1.Click
    '    'fillgrid()
    '    GridViewExportUtil.Export(lblReportName.CurrentPage & "-" & LblError.Text & ".xls", Me.GdAttendance)
    'End Sub
#End Region


End Class
