﻿Imports com.nss.DBAccess
Imports System.Data
Partial Class Data_ActivityDetail
    Inherits System.Web.UI.Page
#Region "--- Properties ---"

    Property ReportType() As Integer
        Get
            Return ViewState("ReportType")
        End Get
        Set(ByVal value As Integer)
            ViewState("ReportType") = value
        End Set
    End Property
    Property CampaignID() As Integer
        Get
            Return ViewState("CampaignID")
        End Get
        Set(ByVal value As Integer)
            ViewState("CampaignID") = value
        End Set
    End Property
    Property AgentID() As String
        Get
            Return ViewState("AgentID")
        End Get
        Set(ByVal value As String)
            ViewState("AgentID") = value
        End Set
    End Property
#End Region

#Region "--- Load ---"
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            ReportType = Request.QueryString("ReportType")
            If Session("AgentID") <> "" Then
                CampaignID = Session("CampaignID")
                AgentID = Session("AgentID")
                PanelReports.Controls.Add(Common.GetMenu(Request.Url, AgentID, Request.ApplicationPath))
                FillCommonFilters()
                FillProcessCampaigns()
                fillgrid()
                'UcDateTo.Visible = False
                'ucDateFrom.Visible = False
                'lblAnd.Visible = False
            End If
        End If
    End Sub
#End Region
#Region "--- Support function ---"
    Private Sub FillCommonFilters()
        Dim db As New DBAccess
        Dim dt As DataTable = db.ReturnTable("select * from tbl_Reports_DatePeriods where Period < 4")
        db = Nothing
        'Dim dr As DataRow = dt.NewRow
        'dr(0) = 10
        'dr(1) = "Between"
        'dt.Rows.Add(dr)
        CboPeriod.DataTextField = "Caption"
        CboPeriod.DataValueField = "Period"
        CboPeriod.DataSource = dt
        CboPeriod.DataBind()
    End Sub
    Private Sub FillProcessCampaigns()
        Common.FillProcessCampaigns(CboProcess, cboCampaigns, AgentID, CampaignID)
        Dim lstCamp As New ListItem
        lstCamp.Value = 0
        lstCamp.Text = "All"
        If CboProcess.Items.Contains(lstCamp) Then
            CboProcess.Items.Remove(lstCamp)
        End If
    End Sub
    Private Function IntegerToDateString(ByVal d As Integer) As String
        Return d.ToString.Substring(0, 4) & "-" & d.ToString.Substring(4, 2) & "-" & d.ToString.Substring(6, 2)
    End Function
    Private Sub ExportToexcel()
        Dim tw As New IO.StringWriter()
        Dim hw As New System.Web.UI.HtmlTextWriter(tw)
        Response.ContentType = "application/vnd.ms-excel"
        Response.AddHeader("content-disposition", "attachment;filename=" & lblReportName.Text & "-" & LblError.Text & ".xls")
        Response.Charset = ""
        EnableViewState = False
        gdActivity.RenderControl(hw)
        Response.Write(tw.ToString())
        Response.End()
    End Sub
    Private Sub fillgrid()
        Dim db As New DBAccess
        Dim startday As Integer, endday As Integer
        'If CboPeriod.SelectedValue = 10 Then
        '    startday = ucDateFrom.yyyymmdd
        '    endday = UcDateTo.yyyymmdd
        'Else
        db = New DBAccess
        db.slDataAdd("Period", CboPeriod.SelectedValue)
        db.slDataAdd("Campaignid", CampaignID)
        Dim dr As DataRow = db.ReturnRow("usp_GetStart_EndDateForAPeriod", True)
        db = Nothing
        startday = dr(0)
        endday = dr(1)
        'End If
        db = New DBAccess("crm")
        Dim dt As New DataTable
        db.slDataAdd("DateFrom", startday)
        db.slDataAdd("DateTo", endday)
        db.slDataAdd("ProcessId", CboProcess.SelectedValue)
        dt = db.ReturnTable("usp_ActivityLogDetail", , True)
        lblReportName.Text = "Activity Log"
        LblError.Text = "Between " & IntegerToDateString(startday) & "  and " & IntegerToDateString(endday)
        db = Nothing
        gdActivity.DataSource = dt
        gdActivity.DataBind()
        dt = Nothing
    End Sub
#End Region
#Region "--- Event ---"
    Protected Sub ImageButton1_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton1.Click
        fillgrid()
        GridViewExportUtil.Export(lblReportName.Text & "-" & LblError.Text & ".xls", Me.gdActivity)
    End Sub
    Protected Sub btnRefresh_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnRefresh.Click
        fillgrid()
    End Sub
    Protected Sub imgfav_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles imgfav.Click
        Common.AddToFav(AgentID, "Activity Data")
        SuccessMessage("Report has been added to your favourite list")
        fillgrid()
    End Sub
    Protected Sub CboPeriod_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles CboPeriod.SelectedIndexChanged
        fillgrid()
    End Sub
    'Protected Sub ucDateFrom_Changed(ByVal sender As Object, ByVal e As System.EventArgs) Handles ucDateFrom.Changed
    '    fillgrid()
    'End Sub
    'Protected Sub UcDateTo_Changed(ByVal sender As Object, ByVal e As System.EventArgs) Handles UcDateTo.Changed
    '    fillgrid()
    'End Sub
    Protected Sub gdActivity_RowDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles gdActivity.RowDataBound
        If e.Row.RowType = DataControlRowType.Header Then
            'e.Row.Cells(2).Visible = False
        End If
        If e.Row.RowType = DataControlRowType.DataRow Then
            'e.Row.Cells(2).Visible = False
            If e.Row.Cells(4).Text <> "&nbsp;" Then
                e.Row.Cells(4).Text = Common.TimeString(e.Row.Cells(4).Text)
            End If
            If e.Row.Cells(5).Text <> "&nbsp;" Then
                e.Row.Cells(5).Text = Common.TimeString(e.Row.Cells(5).Text)
            End If
            If e.Row.Cells(6).Text <> "&nbsp;" Then
                e.Row.Cells(6).Text = Common.TimeString(e.Row.Cells(6).Text)
            End If
            If e.Row.Cells(7).Text <> "&nbsp;" Then
                e.Row.Cells(7).Text = Common.TimeString(e.Row.Cells(7).Text)
            End If
            If e.Row.Cells(8).Text <> "&nbsp;" Then
                e.Row.Cells(8).Text = Common.TimeString(e.Row.Cells(8).Text)
            End If
        End If
    End Sub
    Protected Sub CboProcess_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles CboProcess.SelectedIndexChanged
        fillgrid()
    End Sub
#End Region
#Region "--- Utility ---"
    Private Sub AlertMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMFail"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub
    Private Sub SuccessMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMSuccess"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub
    Public Overrides Sub VerifyRenderingInServerForm(ByVal Control As Control)
    End Sub
#End Region
End Class
