﻿Imports com.nss.DBAccess
Imports System.Data
Partial Class Data_Razoncount
    Inherits System.Web.UI.Page
#Region "--- Properties ---"
    Property AgentID() As String
        Get
            Return ViewState("AgentID")
        End Get
        Set(ByVal value As String)
            ViewState("AgentID") = value
        End Set
    End Property
#End Region
#Region "Utility"
    Private Sub AlertMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMFail"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub

    Private Sub SuccessMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMSuccess"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub
#End Region
#Region "load"
    Private Sub FillCommonFilters()
        Dim db As New DBAccess
        Dim dt As DataTable = db.ReturnTable("select * from tbl_Reports_DatePeriods")
        db = Nothing
        Dim dr As DataRow = dt.NewRow
        dr(0) = 10
        dr(1) = "Between"
        dt.Rows.Add(dr)
        CboPeriod.DataTextField = "Caption"
        CboPeriod.DataValueField = "Period"
        CboPeriod.DataSource = dt
        CboPeriod.DataBind()
    End Sub

#End Region
#Region "Function"
    Private Sub FillGrid()
        Dim db As New DBAccess
        Dim startday As Integer, endday As Integer
        If CboPeriod.SelectedValue = 10 Then
            startday = ucDateFrom.yyyymmdd
            endday = UcDateTo.yyyymmdd
        Else
            db = New DBAccess
            db.slDataAdd("Period", CboPeriod.SelectedValue)
            db.slDataAdd("Campaignid", 159)
            Dim dr As DataRow = db.ReturnRow("usp_GetStart_EndDateForAPeriod", True)
            db = Nothing
            startday = dr(0)
            endday = dr(1)
        End If
        db = Nothing
        db = New DBAccess("Report")
        Dim dt As New DataTable
        db.slDataAdd("DateFrom", startday)
        db.slDataAdd("DateTo", endday)
        dt = db.ReturnTable("usp_razoncount", , True)
        db = Nothing
        breadcrumbs.CurrentPage = " Razon Counts Report "
        GridView1.DataSource = dt
        GridView1.DataBind()
        dt = Nothing
    End Sub
#End Region
#Region "Event"
    Protected Sub CboPeriod_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles CboPeriod.SelectedIndexChanged
        If CboPeriod.SelectedValue = 10 Then
            ucDateFrom.Visible = True
            UcDateTo.Visible = True
            lblAnd.Visible = True
            FillGrid()
        Else
            ucDateFrom.Visible = False
            UcDateTo.Visible = False
            lblAnd.Visible = False
            FillGrid()
        End If
    End Sub
    Protected Sub btnRefresh_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnRefresh.Click
        FillGrid()
    End Sub
    Protected Sub imgfav_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles imgfav.Click
        Common.AddToFav(AgentID, "Razon EOD Report")
        SuccessMessage("Report has been added to your favourite list")
        FillGrid()
    End Sub
    Protected Sub ImageButton1_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton1.Click
        FillGrid()
        GridViewExportUtil.Export(breadcrumbs.CurrentPage & ".xls", Me.GridView1)
    End Sub
#End Region

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            If Session("AgentID") <> "" Then
                AgentID = Session("AgentID")
                PanelReports.Controls.Add(Common.GetMenu(Request.Url, AgentID, Request.ApplicationPath))
                FillCommonFilters()
                FillGrid()
                UcDateTo.Visible = False
                ucDateFrom.Visible = False
                lblAnd.Visible = False
            End If
        End If
    End Sub
End Class
