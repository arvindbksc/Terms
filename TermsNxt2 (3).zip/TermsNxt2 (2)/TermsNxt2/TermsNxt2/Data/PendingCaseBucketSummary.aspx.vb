﻿Imports com.nss.DBAccess
Imports System.Data
Imports System.Text
Partial Class Data_PendingCaseBucketSummary
    Inherits System.Web.UI.Page
#Region "Properties"

    Property campaignid() As Integer
        Get
            Return ViewState("campaignid")
        End Get
        Set(ByVal value As Integer)
            ViewState("campaignid") = value
        End Set
    End Property
    Property AgentID() As String
        Get
            Return ViewState("AgentID")
        End Get
        Set(ByVal value As String)
            ViewState("AgentID") = value
        End Set
    End Property
    Property AgentName() As String
        Get
            Return ViewState("AgentName")
        End Get
        Set(ByVal value As String)
            ViewState("AgentName") = value
        End Set
    End Property
#End Region
#Region "Load"
    Private Sub LoadData()
        FillProcessCampaigns()
    End Sub
    Private Sub FillProcessCampaigns()
        Common.FillProcessCampaigns(CboProcess, cboCampaigns, AgentID, CampaignID)
        Dim lstCamp As New ListItem
        lstCamp.Value = 0
        lstCamp.Text = "All"
        If cboCampaigns.Items.Contains(lstCamp) Then
            cboCampaigns.Items.Remove(lstCamp)
        End If
    End Sub
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        HumanMessage.Style.Item("visibility") = "hidden"
        If Not IsPostBack Then
            If Session("AgentID") <> "" Then
                AgentID = Session("AgentID")
                PanelReports.Controls.Add(Common.GetMenu(Request.Url, AgentID, Request.ApplicationPath))
                LoadData()
                FillGrid()
            End If

        End If
    End Sub
    Private Sub FillGrid()
        Dim dtsummary As New DataTable
        Dim db As New DBAccess
        db.slDataAdd("campaignid", cboCampaigns.SelectedValue)
        dtsummary = db.ReturnTable("usp_getClientPendingCases_BucketSummary", , True)
        db = Nothing
        lblReportName.Text = cboCampaigns.SelectedItem.Text & " Client Pending Case Bucket Summary"
        gridview1.DataSource = dtsummary
        gridview1.DataBind()
        dtsummary = Nothing
    End Sub
#End Region
    Dim footerval() As Integer
#Region "grid ops"
    Protected Sub gridview1_RowDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles gridview1.RowDataBound
        If e.Row.RowType = DataControlRowType.Header Then
            ReDim footerval(e.Row.Cells.Count - 1)
        End If
        If e.Row.RowType = DataControlRowType.DataRow Then
            'e.Row.Cells(0).Style.Add("white-space", "nowrap")
            'e.Row.Cells(0).Style.Add("text-align", "left")
            For i As Integer = 1 To footerval.Length - 1
                If Not e.Row.Cells(i).Text.Contains("nbsp") Then
                    footerval(i) = footerval(i) + e.Row.Cells(i).Text
                End If
            Next
        End If
        If e.Row.RowType = DataControlRowType.Footer Then
            e.Row.Cells(0).Text = "Total:"
            For i As Integer = 1 To footerval.Length - 1
                e.Row.Cells(i).Text = footerval(i)
            Next
        End If
    End Sub
#End Region
#Region "Events"
    Protected Sub cboCampaigns_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboCampaigns.SelectedIndexChanged
        FillGrid()
    End Sub
    Protected Sub ImageButton1_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton1.Click
        FillGrid()
        GridViewExportUtil.Export(lblReportName.Text & ".xls", Me.gridview1)
    End Sub
    Protected Sub imgfav_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles imgfav.Click
        Common.AddToFav(AgentID, "Client Pending Case Bucket Summary")
        SuccessMessage("Report has been added to your favourite list")
        FillGrid()
    End Sub
    Protected Sub btnRefresh_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnRefresh.Click
        FillGrid()
    End Sub
#End Region
#Region "Utility"

    Private Sub AlertMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMFail"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub

    Private Sub SuccessMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMSuccess"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub
#End Region

    
End Class
