﻿Imports com.nss.DBAccess
Imports System.Data
Imports System.Text
Partial Class Data_BreakTypeSummary
    Inherits System.Web.UI.Page

    Dim startday As Integer, endday As Integer

#Region "--- Properties ---"
    Property AgentID() As String
        Get
            Return ViewState("AgentID")
        End Get
        Set(ByVal value As String)
            ViewState("AgentID") = value
        End Set
    End Property
    Property CampaignID() As String
        Get
            Return ViewState("CampaignID")
        End Get
        Set(ByVal value As String)
            ViewState("CampaignID") = value
        End Set
    End Property
#End Region
#Region "--- Page Load ---"
    Private Sub LoadData()
        FillCommonFilters()
        FillCampaigns()
    End Sub
    Private Sub FillCommonFilters()
        Dim db As New DBAccess
        Dim dt As DataTable = db.ReturnTable("select * from tbl_Reports_DatePeriods")
        db = Nothing
        Dim dr As DataRow = dt.NewRow
        dr(0) = 10
        dr(1) = "Between"
        dt.Rows.Add(dr)
        CboPeriod.DataTextField = "Caption"
        CboPeriod.DataValueField = "Period"
        CboPeriod.DataSource = dt
        CboPeriod.DataBind()
        db = New DBAccess
        dt = db.ReturnTable("Select * from tbl_Reports_GroupBy")
        db = Nothing

    End Sub
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        HumanMessage.Style.Item("visibility") = "hidden"
        If Not IsPostBack Then
            If Session("AgentID") <> "" Then
                AgentID = Session("AgentID")
                CampaignID = Session("CampaignID")
                PanelReports.Controls.Add(Common.GetMenu(Request.Url, AgentID, Request.ApplicationPath))
                LoadData()
                fillGrid()
                UcDateTo.Visible = False
                ucDateFrom.Visible = False
                lblAnd.Visible = False
            End If
        End If
    End Sub
#End Region
#Region "--- Function ---"
    Private Sub fillGrid()
        Dim db As New DBAccess
        Dim dtGetData As New DataTable

        If CboPeriod.SelectedValue = 10 Then
            startday = ucDateFrom.yyyymmdd
            endday = UcDateTo.yyyymmdd
        Else
            db = New DBAccess
            db.slDataAdd("Period", CboPeriod.SelectedValue)
            db.slDataAdd("Campaignid", cboCampaigns.SelectedValue)
            Dim dr As DataRow = db.ReturnRow("usp_GetStart_EndDateForAPeriod", True)
            db = Nothing
            startday = dr(0)
            endday = dr(1)
        End If

        db = New DBAccess
        db.slDataAdd("DateFrom", startday)
        db.slDataAdd("DateTo", endday)
        db.slDataAdd("CampaignID", cboCampaigns.SelectedValue)
        dtGetData = db.ReturnTable("usp_GetBreakTypeBreakUp", , True)

        GridView1.DataSource = dtGetData
        GridView1.DataBind()

        lblReportName.Text = "Break Type Summary Report Between " & IntegerToDateString(startday) & "  and " & IntegerToDateString(endday) & " for " & cboCampaigns.SelectedItem.Text & " campaign"
        ScriptManager.RegisterStartupScript(Me, Me.GetType(), "SortGrid", "$(function(){{$('#" & GridView1.ClientID & "').tablesorter({cancelSelection:true}); }});", True)
    End Sub
    Private Sub FillCampaigns()
        'Common.FillCampaigns(cboCampaigns, AgentID, 0, 0)
        Common.FillProcessCampaigns(CboProcess, cboCampaigns, AgentID, CampaignID)
        Dim lstCamp As New ListItem
        lstCamp.Value = 0
        lstCamp.Text = "All"
        If cboCampaigns.Items.Contains(lstCamp) Then
            cboCampaigns.Items.Remove(lstCamp)
        End If
    End Sub
    Private Function IntegerToDateString(ByVal d As Integer) As String
        Return d.ToString.Substring(0, 4) & "-" & d.ToString.Substring(4, 2) & "-" & d.ToString.Substring(6, 2)
    End Function

#End Region
#Region "--- Event ---"
    Protected Sub btnRefresh_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnRefresh.Click
        fillGrid()
    End Sub
    Protected Sub ImageButton1_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton1.Click
        fillGrid()
        GridViewExportUtil.Export(lblReportName.Text & ".xls", Me.GridView1)
    End Sub
    Protected Sub CboPeriod_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles CboPeriod.SelectedIndexChanged
        If CboPeriod.SelectedValue = 10 Then
            ucDateFrom.Visible = True
            UcDateTo.Visible = True
            lblAnd.Visible = True
        Else
            ucDateFrom.Visible = False
            UcDateTo.Visible = False
            lblAnd.Visible = False
            fillGrid()
        End If
    End Sub
    Protected Sub imgfav_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles imgfav.Click
        Common.AddToFav(AgentID, "Breaktype Summary")
        SuccessMessage("Report has been added to your favourite list")
        fillGrid()
    End Sub
    Protected Sub cboCampaigns_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboCampaigns.SelectedIndexChanged
        fillGrid()
    End Sub
#End Region

#Region "--- Utility ---"

    Private Sub AlertMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMFail"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub

    Private Sub SuccessMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMSuccess"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub

    'Protected Sub ImageButton1_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton1.Click
    '    'fillgrid()
    '    GridViewExportUtil.Export(lblReportName.CurrentPage & "-" & LblError.Text & ".xls", Me.GdAttendance)
    'End Sub


    Public Overrides Sub VerifyRenderingInServerForm(ByVal Control As Control)

    End Sub

#End Region

    Protected Sub Page_PreRender(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.PreRender
        If Not GridView1 Is Nothing Then
            If GridView1.HeaderRow Is Nothing Then
            Else
                GridView1.HeaderRow.TableSection = TableRowSection.TableHeader
                GridView1.FooterRow.TableSection = TableRowSection.TableFooter
            End If
        End If
    End Sub
End Class
