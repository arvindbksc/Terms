﻿Imports com.nss.DBAccess
Imports System.Data
Imports System.Text
Partial Class Data_TeamMails
    Inherits System.Web.UI.Page
#Region "--- Properties ---"
    'Property CampaignID() As Integer
    '    Get
    '        Return ViewState("CampaignID")
    '    End Get
    '    Set(ByVal value As Integer)
    '        ViewState("CampaignID") = value
    '    End Set
    'End Property
    Property AgentID() As String
        Get
            Return ViewState("AgentID")
        End Get
        Set(ByVal value As String)
            ViewState("AgentID") = value
        End Set
    End Property
    Property startday() As Integer
        Get
            Return ViewState("startday")
        End Get
        Set(ByVal value As Integer)
            ViewState("startday") = value
        End Set
    End Property
    Property endday() As Integer
        Get
            Return ViewState("endday")
        End Get
        Set(ByVal value As Integer)
            ViewState("endday") = value
        End Set
    End Property
    Dim dt As DataTable
#End Region
#Region "--- Load ---"

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        HumanMessage.Style.Item("visibility") = "hidden"
        If Not IsPostBack Then
            If Session("AgentID") <> "" Then
                ' CampaignID = Session("CampaignID")
                AgentID = Session("AgentID")
                PanelReports.Controls.Add(Common.GetMenu(Request.Url, AgentID, Request.ApplicationPath))
                FillCommonFilters()
                FillGrid()
                BindTMs()
                UcDateTo.Visible = False
                ucDateFrom.Visible = False
                lblAnd.Visible = False
            End If
        End If
    End Sub
#End Region
#Region "--- Functions ---"
    Private Sub FillCommonFilters()
        Dim db As New DBAccess
        Dim dt As DataTable = db.ReturnTable("select * from tbl_Reports_DatePeriods")
        db = Nothing
        Dim dr As DataRow = dt.NewRow
        dr(0) = 10
        dr(1) = "Between"
        dt.Rows.Add(dr)
        CboPeriod.DataTextField = "Caption"
        CboPeriod.DataValueField = "Period"
        CboPeriod.DataSource = dt
        CboPeriod.DataBind()
    End Sub
    Private Function IntegerToDateString(ByVal d As Integer) As String
        Return d.ToString.Substring(0, 4) & "-" & d.ToString.Substring(4, 2) & "-" & d.ToString.Substring(6, 2)
    End Function
    Private Sub FillGrid(Optional ByVal AgentId As String = "")
        Dim dbdate As New DBAccess("CRM")
        Dim startday As Integer, endday As Integer
        If CboPeriod.SelectedValue = 10 Then
            startday = ucDateFrom.yyyymmdd
            endday = UcDateTo.yyyymmdd
        Else
            dbdate = New DBAccess
            dbdate.slDataAdd("Period", CboPeriod.SelectedValue)
            dbdate.slDataAdd("Campaignid", 237)
            Dim dr As DataRow = dbdate.ReturnRow("usp_GetStart_EndDateForAPeriod", True)
            dbdate = Nothing
            startday = dr(0)
            endday = dr(1)
        End If
        Dim db As New DBAccess("CRM")
        db.slDataAdd("AgentId", IIf(cboTeamMember.SelectedValue = "", "%", cboTeamMember.SelectedValue))
        db.slDataAdd("DateFrom", startday)
        db.slDataAdd("DateTo", endday)
        dt = db.ReturnTable("usp_GetEmailDetail", , True)
        db = Nothing
        If AgentId <> "" Then
            Dim dv As DataView = dt.DefaultView
            dv.RowFilter = "Agentid like '" & cboTeamMember.SelectedValue & "'"
            dt = dv.ToTable
        End If
        GridView1.DataSource = dt
        GridView1.DataBind()
        lblReportName.Text = "Email Sent Summary "
        LblError.Text = "From " & IntegerToDateString(startday) & " To " & IntegerToDateString(endday)
    End Sub
    Private Sub BindTMs()
        Dim selectedval As String = cboTeamMember.SelectedValue
        Dim col() As String = {"Agentname", "AgentId"}
        cboTeamMember.DataTextField = "Agentname"
        cboTeamMember.DataValueField = "AgentId"
        Dim dtagents As DataTable = dt.DefaultView.ToTable(True, col)
        Dim row As DataRow = dtagents.NewRow
        row.Item(0) = "All"
        row.Item(1) = ""
        dtagents.Rows.InsertAt(row, 0)
        cboTeamMember.DataSource = dtagents
        cboTeamMember.DataBind()
        If Not cboTeamMember.Items.FindByValue(selectedval) Is Nothing Then
            cboTeamMember.SelectedValue = selectedval
        End If
    End Sub
#End Region
#Region "--- Events ---"
    Protected Sub cboTeamMember_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboTeamMember.SelectedIndexChanged
        FillGrid(cboTeamMember.SelectedValue)
    End Sub
    Protected Sub CboPeriod_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles CboPeriod.SelectedIndexChanged
        If CboPeriod.SelectedValue = 10 Then
            ucDateFrom.Visible = True
            UcDateTo.Visible = True
            lblAnd.Visible = True
            FillGrid(cboTeamMember.SelectedValue)
            BindTMs()
        Else
            ucDateFrom.Visible = False
            UcDateTo.Visible = False
            lblAnd.Visible = False
            FillGrid(cboTeamMember.SelectedValue)
            BindTMs()
        End If
    End Sub
    Protected Sub btnRefresh_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnRefresh.Click
        FillGrid(cboTeamMember.SelectedValue)
        BindTMs()
    End Sub
    Protected Sub ucDateFrom_Changed(ByVal sender As Object, ByVal e As System.EventArgs) Handles ucDateFrom.Changed
        FillGrid(cboTeamMember.SelectedValue)
        BindTMs()
    End Sub
    Protected Sub UcDateTo_Changed(ByVal sender As Object, ByVal e As System.EventArgs) Handles UcDateTo.Changed
        FillGrid(cboTeamMember.SelectedValue)
        BindTMs()
    End Sub
    Protected Sub ImageButton1_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton1.Click
        FillGrid(cboTeamMember.SelectedValue)
        Dim gv As New GridView
        gv.DataSource = dt
        gv.DataBind()
        GridViewExportUtil.Export(lblReportName.Text & ".xls", gv)
    End Sub
    Protected Sub imgfav_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles imgfav.Click
        Common.AddToFav(AgentID, "Email Summary")
        SuccessMessage("Report has been added to your favourite list")
        FillGrid(cboTeamMember.SelectedValue)
        BindTMs()
    End Sub
    Protected Sub GridView1_PageIndexChanging(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewPageEventArgs) Handles GridView1.PageIndexChanging
        GridView1.PageIndex = e.NewPageIndex
        FillGrid(cboTeamMember.SelectedValue)
        BindTMs()
    End Sub
#End Region
#Region "--- Utility ---"
    Private Sub AlertMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMFail"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub
    Private Sub SuccessMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMSuccess"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub
    Public Overrides Sub VerifyRenderingInServerForm(ByVal Control As Control)

    End Sub
#End Region

   
End Class
