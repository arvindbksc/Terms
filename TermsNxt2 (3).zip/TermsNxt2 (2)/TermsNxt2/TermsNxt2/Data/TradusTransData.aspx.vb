﻿Imports com.nss.DBAccess
Imports System.Data
Imports System.Text

Partial Class Data_TradusTransData
    Inherits System.Web.UI.Page

#Region "Properties"

    Property campaignid() As Integer
        Get
            Return ViewState("campaignid")
        End Get
        Set(ByVal value As Integer)
            ViewState("campaignid") = value
        End Set
    End Property
    Property TransID() As Integer
        Get
            Return ViewState("TransID")
        End Get
        Set(ByVal value As Integer)
            ViewState("TransID") = value
        End Set
    End Property
    Property AgentID() As String
        Get
            Return ViewState("AgentID")
        End Get
        Set(ByVal value As String)
            ViewState("AgentID") = value
        End Set
    End Property
    Property AgentName() As String
        Get
            Return ViewState("AgentName")
        End Get
        Set(ByVal value As String)
            ViewState("AgentName") = value
        End Set
    End Property
#End Region

#Region "---- Load -----"
    Private Sub LoadData()
        FillProcessCampaigns()
    End Sub
    Private Sub FillProcessCampaigns()
        Common.FillProcessCampaigns(CboProcess, cboCampaigns, AgentID, CampaignID)
        Dim lstCamp As New ListItem
        lstCamp.Value = 0
        lstCamp.Text = "All"
        If cboCampaigns.Items.Contains(lstCamp) Then
            cboCampaigns.Items.Remove(lstCamp)
        End If
    End Sub
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        HumanMessage.Style.Item("visibility") = "hidden"
        If Not IsPostBack Then
            'Dim dbdate As New DBAccess
            'ucDateFrom.value = dbdate.ReturnValue("select getdate()", False)
            'ucDateTo.value = dbdate.ReturnValue("select getdate()", False)
            'dbdate = Nothing
            If Session("AgentID") <> "" Then
                AgentID = Session("AgentID")
                LoadData()
                FillData()
            End If
            
        End If
    End Sub
    Private Sub FillData()
        Dim dbclient As New DBAccess("CRM")
        Dim dt As New DataTable
        dt = dbclient.ReturnTable("select AgentName,campaignid from tbl_agentMaster where Agentid='" & AgentID & " '", False)
        AgentName = dt.Rows(0).Item("AgentName")
        dbclient = Nothing
        campaignid = cboCampaigns.SelectedValue
        'Dim dtclientsummary As DataTable
        Dim dtsummary As New DataTable

        Dim db As New DBAccess
        db.slDataAdd("CampID", campaignid)
        'If dt.Rows(0).Item("campaignid") = 52 Or dt.Rows(0).Item("campaignid") = 92 Then
        '    db.slDataAdd("client", "%")
        'Else
        '    db.slDataAdd("client", AgentName)
        'End If

        dtsummary = db.ReturnTable("usp_getClientTransaction", , True)
        db = Nothing
        lblReportName.Text = cboCampaigns.SelectedItem.Text & " Tracker"
        ' If dtsummary.Rows.Count > 0 Then
        While gvTransactionReport.Columns.Count > 3
            gvTransactionReport.Columns.RemoveAt(gvTransactionReport.Columns.Count - 1)
        End While

        'If Not IsPostBack Then
        Dim bouncol As BoundField
        For Each col As DataColumn In dtsummary.Columns
            bouncol = New BoundField
            If col.ColumnName.ToLower <> "customerid" And col.ColumnName.ToLower <> "clientstatus" Then 'And col.ColumnName.ToLower <> "remarks" Then
                bouncol.HeaderText = col.ColumnName
                bouncol.DataField = col.ColumnName
                bouncol.HeaderStyle.CssClass = "ROgridMidItem"
                bouncol.ItemStyle.CssClass = "ROgridMidItem"
                gvTransactionReport.Columns.Add(bouncol)

            End If
            'If bouncol.HeaderText <> "Remarks" Then
            '    bouncol.ReadOnly = True
            'End If
        Next
        'End If
        gvTransactionReport.DataSource = dtsummary
        gvTransactionReport.DataBind()

        ViewState("dynamicGrid") = True
        'gvTransactionReport.Columns(dtsummary.Columns.Count + 1).Visible = False
        'gvTransactionReport.Columns(dtsummary.Columns.Count + 2).Visible = False
        ' End If
        dtsummary = Nothing
        dt = Nothing
    End Sub
    Protected Overrides Sub LoadViewState(ByVal earlierState As Object)
        MyBase.LoadViewState(earlierState)
        If ViewState("dynamicGrid") Then
            LoadData()
            FillData()
        End If
    End Sub
    Private Sub FillStatus()
        Dim db As New DBAccess
        Dim dt As DataTable
        db.slDataAdd("CampId", campaignid)
        dt = db.ReturnTable("usp_getClientStatus", , True)
        cbostatus.DataValueField = "ResultCode"
        cbostatus.DataTextField = "Description"
        cbostatus.DataSource = dt
        cbostatus.DataBind()
        db = Nothing
    End Sub
#End Region
#Region "---- Event ---"
    Protected Sub gvTransactionReport_RowCommand(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewCommandEventArgs) Handles gvTransactionReport.RowCommand
        If e.CommandName = "Change" Then
            FillStatus()
            'Dim db As New DBAccess("leads")
            'Dim strsql As String = ""
            'strsql = "select customerid,remarks,isnull(ClientStatus,'Open') as ClientStatus,LastTransId,ClientComments"
            'strsql = strsql + " from tbl_leadmaster" & campaignid & " where customerid='" & e.CommandArgument & "'"
            'Dim dt As DataTable = db.ReturnTable(strsql, , False)
            'db = Nothing
            'hdoldremarks.Value = dt.Rows(0).Item("ClientComments").ToString
            'lblcustomerid.Text = e.CommandArgument
            'cbostatus.SelectedValue = dt.Rows(0).Item("ClientStatus")
            'hdoldstatus.Value = dt.Rows(0).Item("ClientStatus")
            'txtRemarks.Text = ""
            lblcustomerid.Text = e.CommandArgument
            txtRemarks.Text = ""
            Dim str As String
            str = "$('#DialogBackground').height($(document).height()-10);$('#DialogBackground').width($(window).width());$('#DialogBackground').css('visibility','visible');$('#Pnlremarks').css('visibility','visible');" & _
            " $('#Pnlremarks').css('left',($(window).width() - $('#Pnlremarks').width())/2); "
            ScriptManager.RegisterStartupScript(Page, Page.GetType(), "Movedialog", str, True)
        End If
    End Sub
    Protected Sub btnOK_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnOK.Click
        Try
            btnOK.Enabled = False
            'Dim closingdate As Date
            Dim db As New DBAccess
            Dim remarks As String = ""
            remarks = txtRemarks.Text.Replace("<", "").Replace(">", "").Trim
            'closingdate = db.ReturnValue("select getdate()", False)
            db = Nothing
            If (remarks <> "" And remarks <> hdoldremarks.Value.Trim.Replace("&nbsp;", "")) Or cbostatus.SelectedValue <> hdoldstatus.Value.Trim.Replace("&nbsp;", "") Then
                Dim dbUpdate As New DBAccess("leads")
                dbUpdate.slDataAdd("Remarks", remarks)
                dbUpdate.slDataAdd("Result", cbostatus.SelectedItem.Text)
                dbUpdate.slDataAdd("ClientStatus", cbostatus.SelectedValue)
                dbUpdate.slDataAdd("customerid", lblcustomerid.Text)
                dbUpdate.Executeproc("usp_UpdateLeads" & campaignid)
                'dbUpdate.UpdateinTable("tbl_leadmaster238", "customerid=" & customerid)
                dbUpdate = Nothing
                dbUpdate = New DBAccess
                dbUpdate.slDataAdd("CampaignID", campaignid)
                dbUpdate.slDataAdd("customerid", lblcustomerid.Text)
                dbUpdate.slDataAdd("Updatedby", AgentID)
                dbUpdate.slDataAdd("Status", cbostatus.SelectedItem.Text)
                If cbostatus.SelectedItem.Text.ToLower = "closed" Then
                    dbUpdate.slDataAdd("Iscompleted", 1)
                Else
                    dbUpdate.slDataAdd("Iscompleted", 0)
                End If
                dbUpdate.Executeproc("usp_UpdateClientTatDetail")
                dbUpdate = Nothing
            End If
            SuccessMessage(" Data Saved Successfully")
            FillData()
            btnOK.Enabled = True
        Catch ex As Exception
            AlertMessage(ex.ToString())
            btnOK.Enabled = True
        End Try
    End Sub
    Protected Sub ImageButton1_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton1.Click
        GridViewExportUtil.Export(lblReportName.Text & "-" & LblError.Text & ".xls", Me.gvTransactionReport)
    End Sub
    Protected Sub cboCampaigns_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboCampaigns.SelectedIndexChanged
        FillData()
    End Sub
    Protected Sub btnRefresh_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnRefresh.Click
        FillData()
    End Sub
#End Region


#Region "--- Utility ---"

    Private Sub AlertMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMFail"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub

    Private Sub SuccessMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMSuccess"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub
#End Region
   
    
End Class
