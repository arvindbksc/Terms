﻿Imports com.nss.DBAccess
Imports System.Web.UI.DataVisualization.Charting
Imports System.Data
Imports System.Web
Imports System.Drawing
Imports System.Web.UI
Imports System.Web.Services
Imports System.Web.Services.WebService
Imports System.Text
Partial Class Data_ActivityDashboard
    Inherits System.Web.UI.Page
#Region "--- Properties ---"
    Property CampaignID() As Integer
        Get
            Return ViewState("CampaignID")
        End Get
        Set(ByVal value As Integer)
            ViewState("CampaignID") = value
        End Set
    End Property
    Property AgentID() As String
        Get
            Return ViewState("AgentID")
        End Get
        Set(ByVal value As String)
            ViewState("AgentID") = value
        End Set
    End Property
    Property AgentName() As String
        Get
            Return ViewState("AgentName")
        End Get
        Set(ByVal value As String)
            ViewState("AgentName") = value
        End Set
    End Property
    Property LanId() As String
        Get
            Return ViewState("LanId")
        End Get
        Set(ByVal value As String)
            ViewState("LanId") = value
        End Set
    End Property
#End Region
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        'OSR
        If Not IsPostBack Then
            If Session("UserID") Is Nothing Then
                FormsAuthentication.SignOut()
            ElseIf Session("UserID") = "" Then
                FormsAuthentication.SignOut()
            Else
                GetFilters(Session("UserID"))
                CampaignID = Session("CampaignID")
                AgentID = Session("AgentID")
                AgentName = Session("username")
                LanId = Session("Lanid")
                hdnAgentId.Value = AgentID
                hdnCampaignId.Value = CampaignID
                GetProcessName()
                'BindGridview()
                'BindGridview1()
                BindFooter()
                spnName.InnerText = "Welcome : " & AgentName
                spnProcessName.InnerText = hdnProcessName.Value
            End If
        Else
            If Session("UserID") Is Nothing Then
                FormsAuthentication.SignOut()
            ElseIf Session("UserID") = "" Then
                FormsAuthentication.SignOut()
            End If
        End If
    End Sub
#Region "---- Support Functions ----"
    <WebMethod()> _
    Public Shared Function GetData(ByVal datefrom As String, ByVal dateto As String, ByVal groupby As Int32, ByVal process As Int32, ByVal AgentId As String, ByVal CampaignID As Int32) As String()
        Dim ds As New DataSet
        Dim db As New DBAccess("CRM")
        db.slDataAdd("datefrom", datefrom)
        db.slDataAdd("dateto", dateto)
        db.slDataAdd("ProcessId", process)
        db.slDataAdd("GroupBy", groupby)
        db.slDataAdd("Agentid", AgentId)
        db.slDataAdd("CampaignID", CampaignID)
        ds = db.ReturnDataset("usp_ActivitySummary_New_15Dec2015", True)
        Dim sjData(ds.Tables.Count) As String
        Dim i As Integer = 0
        For Each dt As DataTable In ds.Tables
            If ds.Tables(i).Rows.Count > 0 Then
                sjData(i) = GetJson(ds.Tables(i))
            End If
            i += 1
        Next
        Return sjData
    End Function
    <WebMethod()> _
    Public Shared Function BindGrid(ByVal datefrom As String, ByVal dateto As String, ByVal process As Int32, ByVal Agent As String, ByVal CampaignID As Int32) As String
        Dim dt As New DataTable
        Dim db As New DBAccess("CRM")
        db.slDataAdd("datefrom", datefrom)
        db.slDataAdd("dateto", dateto)
        db.slDataAdd("ProcessId", process)
        db.slDataAdd("AgentId", Agent)
        db.slDataAdd("CampaignID", CampaignID)
        'dt = db.ReturnTable("usp_getActivityDetail_01July2015", , True)
        dt = db.ReturnTable("usp_getActivityDetail_15Dec2015", , True)
        Dim sjData As String = ""
        If dt.Rows.Count > 0 Then
            sjData = GetJson(dt)
        End If
        Dim a As String = ""
        a = sjData
        Return sjData
    End Function

    Public Shared Function GetJson(ByVal dt As DataTable) As String
        Dim serializer As New System.Web.Script.Serialization.JavaScriptSerializer()
        serializer.MaxJsonLength = Integer.MaxValue
        Dim rows As New List(Of Dictionary(Of String, Object))()
        Dim row As Dictionary(Of String, Object) = Nothing
        Dim row2 As Dictionary(Of Integer, Object) = Nothing
        For Each dr As DataRow In dt.Rows
            row = New Dictionary(Of String, Object)()
            row2 = New Dictionary(Of Integer, Object)()
            For Each dc As DataColumn In dt.Columns
                row.Add(dc.ColumnName.Trim(), dr(dc))
            Next
            rows.Add(row)
        Next
        Return serializer.Serialize(rows)
    End Function
    Private Sub BindGridview()
        Dim dt As New DataTable
        Dim db As New DBAccess("CRM")
        db.slDataAdd("datefrom", DateTime.Now.Year.ToString() + DateTime.Now.Month.ToString.PadLeft(2, "0") + DateTime.Now.Day.ToString.PadLeft(2, "0"))
        db.slDataAdd("dateto", DateTime.Now.Year.ToString() + DateTime.Now.Month.ToString.PadLeft(2, "0") + DateTime.Now.Day.ToString.PadLeft(2, "0"))
        db.slDataAdd("ProcessId", hdnProcessId.Value)
        db.slDataAdd("AgentId", AgentID)
        dt = db.ReturnTable("usp_getActivityDetail", , True)
        Dim dt1 As New DataTable()
        For Each col As DataColumn In dt.Columns
            dt1.Columns.Add(col.ColumnName)
        Next
        dt1.Rows.Add()
        'gvData.DataSource = dt1
        'gvData.DataBind()
        dt = Nothing
    End Sub
    <WebMethod()> _
    Public Shared Function BindGrid1(ByVal datefrom As String, ByVal dateto As String, ByVal processid As String, ByVal CategoryID As Integer, ByVal Agentid As String) As String
        Dim dt As New DataTable
        Dim db As New DBAccess("CRM")
        db.slDataAdd("datefrom", datefrom)
        db.slDataAdd("dateto", dateto)
        db.slDataAdd("processid", processid)
        db.slDataAdd("CategoryID", CategoryID)
        db.slDataAdd("AgentID", Agentid)
        dt = db.ReturnTable("usp_GetActivityDetails", , True)
        Dim data As String = ""
        If dt.Rows.Count > 0 Then
            data = GetJson(dt)
        End If
        Return data
    End Function
    <WebMethod()> _
    Public Shared Function GetCategory()
        Dim dt As New DataTable
        Dim db As New DBAccess("CRM")
        dt = db.ReturnTable("Show_Cateogary", , True)
        Dim sjData As String = ""
        If dt.Rows.Count > 0 Then
            sjData = GetJson(dt)
        End If
        Return sjData
    End Function
    <WebMethod()> _
    Public Shared Function InsertBreakDescription(ByVal CateogryId As Integer, ByVal BReakId As Integer) As String
        Dim dt As New DataTable
        Dim db As New DBAccess("CRM")
        db.slDataAdd("ISProductive", CateogryId)
        db.slDataAdd("BreakID", BReakId)
        db.Executeproc("Change_BreakType")
    End Function
    <WebMethod()> _
    Public Shared Function InsertCateogry(ByVal Cateogry As Integer, ByVal Appname As String, ByVal AppTittle As String, ByVal PID As Integer) As String
        Dim dt As New DataTable
        Dim db As New DBAccess("CRM")
        db.slDataAdd("CategoryID", Cateogry)
        db.slDataAdd("AppName", Appname)
        db.slDataAdd("ApplicationTittle", AppTittle)
        db.slDataAdd("ProcessID", PID)
        db.ReturnTable("Add_Cateogary", , True)
    End Function
    <WebMethod()> _
    Public Shared Function GetBreakType(ByVal datefrom As String, ByVal dateto As String, ByVal processid As String, ByVal IsBreakProductive As Integer, ByVal Agentid As String) As String
        Dim dt As New DataTable
        Dim db As New DBAccess("CRM")
        db.slDataAdd("datefrom", datefrom)
        db.slDataAdd("dateto", dateto)
        db.slDataAdd("processid", processid)
        db.slDataAdd("IsBreakProductive", IsBreakProductive)
        db.slDataAdd("AgentID", Agentid)
        dt = db.ReturnTable("uspAct_GetBreakDetails", , True)
        Dim data As String = ""
        If dt.Rows.Count > 0 Then
            data = GetJson(dt)
        End If
        Return data
    End Function

    Private Sub BindGridview1()
        Dim dt As New DataTable
        Dim db As New DBAccess("CRM")
        db.slDataAdd("datefrom", DateTime.Now.Year.ToString() + DateTime.Now.Month.ToString.PadLeft(2, "0") + DateTime.Now.Day.ToString.PadLeft(2, "0"))
        db.slDataAdd("dateto", DateTime.Now.Year.ToString() + DateTime.Now.Month.ToString.PadLeft(2, "0") + DateTime.Now.Day.ToString.PadLeft(2, "0"))
        db.slDataAdd("processid", hdnProcessId.Value)
        db.slDataAdd("AgentID", AgentID)
        dt = db.ReturnTable("usp_GetActivityDetails", , True)
        'usp_ActivitySummary
        Dim dt1 As New DataTable()
        For Each col As DataColumn In dt.Columns
            dt1.Columns.Add(col.ColumnName)
        Next
        dt1.Rows.Add()
        'GridView1.DataSource = dt1
        'GridView1.DataBind()
        dt = Nothing

    End Sub
    <WebMethod()> _
  Public Shared Function BindProcess(ByVal AgentId As String) As String
        Dim db As New DBAccess
        Dim dt As New DataTable
        AgentId = AgentId
        db.slDataAdd("AgentID", AgentId)
        dt = db.ReturnTable("usp_MyProcesses", , True)
        db = Nothing
        Dim sjData As String = ""
        If dt.Rows.Count > 0 Then
            sjData = GetJson(dt)
        End If
        Return sjData
    End Function
    'Added by Gaurav Dutt 15 Dec 2015
    <WebMethod()> _
 Public Shared Function BindCampaigns(ByVal AgentId As String, ByVal ProcessID As Integer) As String
        Dim db As New DBAccess
        Dim dt As New DataTable
        AgentId = AgentId
        ProcessID = ProcessID
        db.slDataAdd("Agentid", AgentId)
        db.slDataAdd("ProcessId", ProcessID)
        dt = db.ReturnTable("usp_MyCampaigns", , True)
        db = Nothing
        Dim sjData As String = ""
        If dt.Rows.Count > 0 Then
            sjData = GetJson(dt)
        End If
        Return sjData
    End Function
    <WebMethod()> _
   Public Shared Function BindAgent(ByVal CampaignId As Int32) As String
        Dim dt As New DataTable
        Dim db As New DBAccess("CRM")
        db.slDataAdd("CampaignId", CampaignId)
        dt = db.ReturnTable("usp_ActivityCampaignAgents", , True)
        Dim sjData As String = ""
        If dt.Rows.Count > 0 Then
            sjData = GetJson(dt)
        End If
        Return sjData
    End Function

    <WebMethod()> _
   Public Shared Function BindAgentGrid(ByVal ProcessId As Int32) As String
        Dim dt As New DataTable
        Dim db As New DBAccess("CRM")
        db.slDataAdd("ProcessId", ProcessId)
        dt = db.ReturnTable("usp_ActivityProcessAgents", , True)
        Dim sjData As String = ""
        If dt.Rows.Count > 0 Then
            sjData = GetJson(dt)
        End If
        Return sjData
    End Function

    <WebMethod()> _
    Public Shared Function SaveFilter(ByVal UserId As String, ByVal SelectedFilter As Int32, ByVal SelectedProcess As Int32, ByVal SelectedAgent As String, ByVal SelectedCampaignId As Int32) As String
        Dim db As New DBAccess("CRM")
        db.slDataAdd("UserId", UserId)
        db.slDataAdd("SelectedFilter", SelectedFilter)
        db.slDataAdd("SelectedProcess", SelectedProcess)
        db.slDataAdd("SelectedAgent", SelectedAgent)
        db.slDataAdd("SelectedCampaignId", SelectedCampaignId)
        db.Executeproc("usp_Activity_SaveFilter")
        db = Nothing
        Return ""
    End Function
    <WebMethod()> _
    Public Shared Function GetUserFilter(ByVal UserId As String) As String
        Dim db As New DBAccess("CRM")
        Dim dt As New DataTable
        db.slDataAdd("UserId", UserId)
        'db.Executeproc("usp_GetActivityFilter")
        dt = db.ReturnTable("usp_GetActivityFilter", , True)
        db = Nothing
        Dim sjData As String = ""
        If dt.Rows.Count > 0 Then
            sjData = GetJson(dt)
        End If
        Return sjData
    End Function

    Private Sub GetProcessName()
        Dim db As New DBAccess("CRM")
        db.slDataAdd("LanId", LanId)
        Dim row As DataRow = db.ReturnRow("usp_ActivityUserProcess", True)
        hdnProcessName.Value = row.Item("ProcessName").ToString
        hdnProcessId.Value = row.Item("ProcessId").ToString
        db = Nothing
    End Sub
    Private Sub BindFooter()
        Dim db As New DBAccess
        db.slDataAdd("userid", AgentID)
        Dim dt As DataTable = db.ReturnTable("usp_User_Module_Report", , True)
        db = Nothing
        Dim usermodule() As String = {"displayname"}
        Dim dt1 As DataTable
        dt1 = dt.DefaultView.ToTable(True, usermodule)
        Dim serverpath As String
        If Request.Url.Host = "localhost" Then
            serverpath = HttpContext.Current.Request.ApplicationPath
        Else
            'serverpath = "http://termsmonitor.niitsmartserve.com"
            'serverpath = "http://TMhelpdesk.niit-tech.com"
            'serverpath = "http://ggn-nss-web1:7225"   ''publish

            serverpath = System.Configuration.ConfigurationManager.AppSettings("LiveServerPath")

        End If
        Dim tbl As New HtmlTable
        tbl.Attributes.Add("class", "menu")
        tbl.Width = "100%"
        'tbl.Height = "300px"
        tbl.CellPadding = "6"
        tbl.CellSpacing = "6"
        Dim tr As HtmlTableRow
        Dim td As HtmlTableCell

        tr = New HtmlTableRow
        For Each row As DataRow In dt1.Rows
            td = New HtmlTableCell
            td.VAlign = "top"
            td.InnerHtml = "<fieldset><legend><b><span style='color: white;'>" & row.Item(0) & "</span></b></legend><table width='100%'>"
            For Each row1 As DataRow In dt.Select("displayname='" & row.Item(0) & "'")
                td.InnerHtml += "<tr><td align='left'><a href='" & serverpath & "/" & row1("shorturl") & "'>"
                td.InnerHtml += "<div class='item'><span class='left'>" & row1("name") & "</span></div></a></td>"
                'If row1.Item(5) <> 0 Then
                '    td.InnerHtml += "<td><a href='sitemap.aspx?mode=rem&reportid=" & row1("ID") & "'><span class='right'><img src='../_assets/img/removefav.png' width='20px' height='20px' alt='Remove from favourite' /></span></a></td></tr>"
                'Else
                '    td.InnerHtml += "<td><a href='sitemap.aspx?mode=add&reportid=" & row1("ID") & "'><span class='right'><img src='../_assets/img/fav.png' width='20px' height='20px' alt='Add to favourite' /></span></a></td></tr>"
                'End If
            Next
            'td.InnerHtml += "</a>"
            td.InnerHtml += "</table></fieldset>"
            tr.Cells.Add(td)
        Next
        tbl.Rows.Add(tr)
        divmenu.Controls.Add(tbl)
    End Sub
#End Region

    Private Sub GetFilters(ByVal UserId As String)
        Dim db As New DBAccess("CRM")
        Dim dt As New DataTable
        db.slDataAdd("UserId", UserId)
        dt = db.ReturnTable("usp_GetActivityFilter", , True)
        db = Nothing

        If (dt.Rows.Count > 0) Then
            CampaignID = If(IsDBNull(dt.Rows(0)("CampaignId")), -1, dt.Rows(0)("CampaignId"))
            AgentID = dt.Rows(0)("SelectedAgent").ToString
            hdnProcessId.Value = dt.Rows(0)("ProcessId").ToString
            hdnUserId.Value = Session("UserID").ToString()
        Else
            CampaignID = Session("CampaignID")
            AgentID = Session("AgentID")
            hdnUserId.Value = Session("UserID").ToString()
        End If


    End Sub
End Class
