﻿Imports com.nss.DBAccess
Imports LibFolder.TermsNxt2
Imports System.Globalization

Public Class _TransactionData
    Inherits System.Web.UI.Page

    'Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

    'End Sub

    Dim footerval(12) As Integer
    Dim dt, dt1 As DataTable
#Region "Properties"

    Property ProcessID() As Integer
        Get
            Return ViewState("ProcessID")
        End Get
        Set(ByVal value As Integer)
            ViewState("ProcessID") = value
            Session("ProcessID") = value
        End Set
    End Property
    Property Campaigntype() As Integer
        Get
            Return ViewState("Campaigntype")
        End Get
        Set(ByVal value As Integer)
            ViewState("Campaigntype") = value
            'Session("ProcessID") = value
        End Set
    End Property
    Property ReportType() As Integer
        Get
            Return ViewState("ReportType")
        End Get
        Set(ByVal value As Integer)
            ViewState("ReportType") = value
        End Set
    End Property
    Property CampaignID() As Integer
        Get
            Return ViewState("CampaignID")
        End Get
        Set(ByVal value As Integer)
            ViewState("CampaignID") = value
        End Set
    End Property

    Property AgentID() As String
        Get
            Return ViewState("AgentID")
        End Get
        Set(ByVal value As String)
            ViewState("AgentID") = value
        End Set
    End Property
    Property startday() As String
        Get
            Return ViewState("startday")
        End Get
        Set(ByVal value As String)
            ViewState("startday") = value
        End Set
    End Property
    Property endday() As String
        Get
            Return ViewState("endday")
        End Get
        Set(ByVal value As String)
            ViewState("endday") = value
        End Set
    End Property
#End Region
#Region "Load Data"
    Private Sub LoadData()
        FillCommonFilters()
        FillProcessCampaigns()
        If cboCampaigns.SelectedItem.Text = "HPS" Then
            CboPeriod.SelectedValue = 3
        End If
    End Sub
#End Region
#Region "Load Functions"
    Private Sub FillCommonFilters()
        Dim db As New DBAccess
        Dim dt As DataTable = db.ReturnTable("select * from tbl_Reports_DatePeriods")
        db = Nothing
        Dim dr As DataRow = dt.NewRow
        dr(0) = 10
        dr(1) = "Between"
        dt.Rows.Add(dr)
        CboPeriod.DataTextField = "Caption"
        CboPeriod.DataValueField = "Period"
        CboPeriod.DataSource = dt
        CboPeriod.DataBind()
        'db = New DBAccess
        'dt = db.ReturnTable("Select * from tbl_Reports_GroupBy")
        'db = Nothing
        'CboGroup.DataTextField = "Caption"
        'CboGroup.DataValueField = "ID"
        'CboGroup.DataSource = dt
        'CboGroup.DataBind()
    End Sub
    Private Sub FillProcessCampaigns()
        Common.FillProcessCampaigns(cboProcess, cboCampaigns, AgentID, CampaignID)
        Dim lstCamp As New ListItem
        lstCamp.Value = 0
        lstCamp.Text = "All"
        If cboCampaigns.Items.Contains(lstCamp) Then
            cboCampaigns.Items.Remove(lstCamp)
        End If
    End Sub
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        HumanMessage.Style.Item("visibility") = "hidden"
        If Not IsPostBack Then
            ReportType = Request.QueryString("ReportType")
            If Session("AgentID") <> "" Then
                CampaignID = Session("CampaignID")
                AgentID = Session("AgentID")
                PanelReports.Controls.Add(Common.GetMenu(Request.Url, AgentID, Request.ApplicationPath))
                LoadData()
                CboPeriod.SelectedValue = Request.QueryString("period")
                cboCampaigns.SelectedValue = Request.QueryString("campaign")
                fillgrid()

                'UcDateTo.Visible = False
                'ucDateFrom.Visible = False
                'lblAnd.Visible = False
                ' Dim dateF As DateTime = DateTime.ParseExact(Text, "dd/MM/yyyy", CultureInfo.InvariantCulture)
                '  Dim reformatted As String = dateF.ToString("yyyyMMdd", CultureInfo.InvariantCulture)
                'MM/dd/yyyy
                '  txtFrom.Text = DateTime.Today.AddDays(-1).ToString("yyyymmdd", CultureInfo.InvariantCulture)
                ' txtTo.Text = DateTime.Today.ToString("yyyymmdd", CultureInfo.InvariantCulture)

                txtFrom.Visible = False
                lblAnd.Visible = False
                txtTo.Visible = False
                If cboCampaigns.SelectedValue = "200" Or cboCampaigns.SelectedValue = "295" Then
                    getsearch()
                Else
                    getsearch()
                End If


            End If
        End If
        'If Not GridView1 Is Nothing Then
        '    If GridView1.HeaderRow Is Nothing Then
        '    Else
        '        GridView1.HeaderRow.TableSection = TableRowSection.TableHeader
        '        'GridView1.FooterRow.TableSection = TableRowSection.TableFooter
        '    End If
        'End If
    End Sub
    Private Sub fillgrid()
        For Each obj In footerval
            obj = 0
        Next


        Dim db As New DBAccess
        If CboPeriod.SelectedValue = 10 Then
            If (txtFrom.Text <> "") Then
                startday = Convert.ToDateTime(txtFrom.Text).ToString("yyyyMMdd", CultureInfo.InvariantCulture).ToString()
            End If
            If (txtTo.Text <> "") Then
                endday = Convert.ToDateTime(txtTo.Text).ToString("yyyyMMdd", CultureInfo.InvariantCulture).ToString()
            End If
        Else
            db = New DBAccess
            db.slDataAdd("Period", CboPeriod.SelectedValue)
            db.slDataAdd("Campaignid", CampaignID)
            Dim dr As DataRow = db.ReturnRow("usp_GetStart_EndDateForAPeriod", True)
            db = Nothing
            startday = dr(0)
            endday = dr(1)
        End If
        db = New DBAccess


        db.slDataAdd("startday", startday)
        db.slDataAdd("endDay", endday)
        db.slDataAdd("campaignid", cboCampaigns.SelectedValue)
        'db.slDataAdd("groupBy", CboGroup.SelectedValue)

        'If cboFilterBy.SelectedItem.Text <> "None" And txtFilterValue.Text.Trim <> "" Then
        '    lblFilter.Text = "Filtered for " & cboFilterBy.SelectedItem.Text & " = " & txtFilterValue.Text
        '    If cboFilterBy.SelectedValue.Contains("String") Then
        '        'db.slDataAdd("Filterby", "'" & cboFilterBy.SelectedItem.Text & "'")
        '    End If
        '    db.slDataAdd("Filterby", cboFilterBy.SelectedItem.Text)
        '    db.slDataAdd("Filterbyvalue", txtFilterValue.Text)
        'End If
        'Dim strsql As String
        'strsql = "select * from tbl_Summary_CollectedData where Day >= '" & dr(0) & "' AND  Day <= '" & dr(1) & "' AND campaignid='" & CampaignID & "'"
        dt = db.ReturnTable("usp_QuestData", , True)
        ' dt = db.ReturnTable("usp_QuestData_current_20201123_Quality", , True)

        '@ kush changes
        'dt = db.ReturnTable("usp_QuestData", , True)
        'dt = db.ReturnTable("Usp_questdata_20181016_Format", , True)
        'dt = db.ReturnTable("usp_QuestData_original_20181126", , True)
        'Dim dtime As Date
        'dtime = dr(0).ToString
        db = Nothing
        lblReportName.Text = "Transaction Summary "
        LblError.Text = "Between " & IntegerToDateString(startday) & "  and " & IntegerToDateString(endday) & " for " & cboCampaigns.SelectedItem.Text & " campaign"

        ' GridView1.AutoGenerateColumns = True
        CreateGridColumns(dt.Columns)
        'If dt.Columns.Contains("Question") Then
        '    dt.Columns.Remove(
        'End If
        dt1 = dt.Copy
        For Each col As DataColumn In dt.Columns
            If col.ColumnName.Contains("Question") Or col.ColumnName.Contains("question") Then
                dt1.Columns.Remove(col.ColumnName)
            End If
        Next
        dt = dt1
        dt1 = Nothing



        If dt.Rows.Count > 0 Then
            sendmail()
            GridView1.DataSource = dt
            GridView1.DataBind()
        End If

        If txtFilterValue.Text = "" Then
            'GetData()
            GridView1.DataSource = Nothing
            GridView1.DataSource = dt.DefaultView
        Else
            If txtFilterValue.Text <> "" Then
                If dt.Rows.Count > 0 Then

                    Dim dtfiltered As DataTable = dt.Clone
                    Dim drs As DataRow()
                    drs = dt.Select("[" & cboFilterBy.SelectedItem.Text & "] = '" & txtFilterValue.Text & "'")
                    For Each dr1 As DataRow In drs
                        dtfiltered.ImportRow(dr1)
                    Next
                    dt = dtfiltered
                    GridView1.DataSource = Nothing
                    GridView1.DataSource = dtfiltered
                Else
                    GridView1.DataSource = dt
                End If
                GridView1.DataBind()
            End If

        End If


        'getsearch()
        'System.Threading.Thread.Sleep(100)
        ' ScriptManager.RegisterStartupScript(Me, Me.GetType(), "SortGrid", "$(function(){{$('#" & GridView1.ClientID & "').tablesorter({cancelSelection:true});  $('#" & GridView1.ClientID & "').bind('sortStart', function () {pageRow = $(this).children('tbody').children('tr:.foo');$(this).children('tbody').children('tr:.foo').remove();});}});", True)
    End Sub

    Private Sub getsearch()
        If dt.Columns.Count > 0 Then
            cboFilterBy.Items.Clear()
            For Each col As DataColumn In dt.Columns
                cboFilterBy.Items.Add(col.ColumnName)
            Next
        End If
    End Sub

#End Region
#Region "Grid Ops"
    Private Sub CreateGridColumns(ByVal cols As DataColumnCollection)
        Dim db As New DBAccess
        Try

            db.slDataAdd("CampaignID", cboCampaigns.SelectedValue)
            db.slDataAdd("startday", startday)
            db.slDataAdd("endDay", endday)
            Dim dtoutcome As DataTable = db.ReturnTable("usp_ReportQuestDataDescription", , True)
            For Each dr In dtoutcome.Rows
                cols("Question" & dr("ReportSequence")).Caption = dr("Caption")
            Next

            'GridView1.Columns.Clear()
            'Dim tempcolumn As TemplateField
            'Dim bouncol As BoundField
            Dim objcol As DataColumn
            'bouncol = New BoundField
            'bouncol.HeaderText = "S.No."
            'GridView1.Columns.Add(bouncol)
            For Each objcol In cols
                'If objcol.ColumnName = "Agents" Then
                '    tempcolumn = New TemplateField
                '    Dim tmpagcol As New TemplateAgentName
                '    tempcolumn.HeaderText = "Agents"
                '    tmpagcol.DataImageField = "AgentStatus"
                '    tmpagcol.DataTextField = objcol.ColumnName
                '    tempcolumn.ItemStyle.HorizontalAlign = HorizontalAlign.Left
                '    tempcolumn.ItemTemplate = tmpagcol
                '    GridView1.Columns.Add(tempcolumn)
                'ElseIf objcol.ColumnName.ToLower = "column1" Then
                '    bouncol = New BoundField
                '    bouncol.HeaderText = CboGroup.SelectedItem.Text
                '    bouncol.DataField = objcol.ColumnName


                '    GridView1.Columns.Add(bouncol)
                If objcol.ColumnName.Contains("Question") Then
                    If objcol.Caption <> objcol.ColumnName Then
                        objcol.ColumnName = objcol.Caption
                        'bouncol = New BoundField
                        'bouncol.HeaderText = objcol.Caption
                        'bouncol.DataField = objcol.ColumnName
                        'dt1.Columns.Add(bouncol)
                        'Else
                        '    dt.Columns.Remove(objcol)
                    End If
                    'Else
                    '    If objcol.ColumnName <> "Agentstatus" Then
                    '        bouncol = New BoundField
                    '        bouncol.HeaderText = objcol.ColumnName
                    '        bouncol.DataField = objcol.ColumnName
                    '        GridView1.Columns.Add(bouncol)
                    '    End If
                End If
            Next

        Catch ex As Exception
            Throw ex
        End Try
    End Sub
    'Dim i As Integer = 1
    'Protected Sub GridView1_RowDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles GridView1.RowDataBound
    '    If e.Row.RowType = DataControlRowType.DataRow Then
    '        e.Row.Cells(0).Text = i
    '        i += 1
    '    End If
    'End Sub
#End Region
#Region "Events"
    Protected Sub cboCampaigns_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboCampaigns.SelectedIndexChanged
        CampaignID = cboCampaigns.SelectedValue
        If cboCampaigns.SelectedItem.Text = "HPS" Then
            CboPeriod.SelectedValue = 3
        End If
        fillgrid()
        getsearch()
    End Sub
    Protected Sub CboPeriod_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles CboPeriod.SelectedIndexChanged
        If CboPeriod.SelectedValue = 10 Then
            txtFrom.Visible = True
            lblAnd.Visible = True
            txtTo.Visible = True
            fillgrid()
        Else
            txtFrom.Visible = False
            lblAnd.Visible = False
            txtTo.Visible = False
            fillgrid()
        End If
    End Sub
    Protected Sub ImageButton1_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton1.Click
        If cboCampaigns.SelectedItem.Text = "HPS" Then
            CboPeriod.SelectedValue = 3
        End If
        fillgrid()
        'GridViewExportUtil.Export(lblReportName.Text & "-" & LblError.Text & ".xls", Me.GridView1)
        Dim gv As New GridView
        gv.DataSource = dt
        gv.DataBind()
        GridViewExportUtil.Export(lblReportName.Text & ".xls", gv)

        '  GridViewExportUtil.Export2Excel(Environment.GetFolderPath(Environment.SpecialFolder.UserProfile) & "\Downloads\" & lblReportName.Text & DateAndTime.Now.ToString("dd-MMM-yyyyHHmm") & ".xlsx", lblReportName.Text, dt)

    End Sub
    Protected Sub imgmail_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles imgmail.Click
        fillgrid()
        Dim db As New DBAccess("report")
        Dim str As String = "update tbl_Data_SendMail set sendmail=1 where campaignid='" & cboCampaigns.SelectedValue & "'"
        db.exeSQL(str)
        db = Nothing
    End Sub
    Protected Sub btnFilter_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnFilter.Click
        If cboCampaigns.SelectedItem.Text = "HPS" Then
            CboPeriod.SelectedValue = 3
        End If
        fillgrid()

    End Sub
    Protected Sub btnRefresh_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnRefresh.Click
        If cboCampaigns.SelectedItem.Text = "HPS" Then
            CboPeriod.SelectedValue = 3
        End If
        fillgrid()
    End Sub
#End Region
#Region "Support Functions"
    Private Function IntegerToDateString(ByVal d As Integer) As String
        Return d.ToString.Substring(0, 4) & "-" & d.ToString.Substring(4, 2) & "-" & d.ToString.Substring(6, 2)
    End Function
    Public Function TimeString(ByVal Seconds As Long) As String

        'if verbose = false, returns
        'something like
        '02:22.08
        'if true, returns
        '2 hours, 22 minutes, and 8 seconds

        Dim lHrs As Long
        Dim lMinutes As Long
        Dim lSeconds As Long

        lSeconds = Seconds

        lHrs = Int(lSeconds / 3600)
        lMinutes = (Int(lSeconds / 60)) - (lHrs * 60)
        lSeconds = Int(lSeconds Mod 60)

        If lSeconds = 60 Then
            lMinutes = lMinutes + 1
            lSeconds = 0
        End If

        If lMinutes = 60 Then
            lMinutes = 0
            lHrs = lHrs + 1
        End If

        TimeString = lHrs.ToString("####00") & ":" &
        lMinutes.ToString("00") & ":" &
         lSeconds.ToString("00")

    End Function
    Private Sub ExportToexcel()
        Dim tw As New IO.StringWriter()
        Dim hw As New System.Web.UI.HtmlTextWriter(tw)
        'Dim frm As HtmlForm = New HtmlForm()
        Response.ContentType = "application/vnd.ms-excel"
        Response.AddHeader("content-disposition", "attachment;filename=" & lblReportName.Text & "-" & LblError.Text & ".xls")
        Response.Charset = ""
        EnableViewState = False
        'Controls.Add(frm)
        GridView1.RenderControl(hw)
        Response.Write(tw.ToString())
        Response.End()
    End Sub
    Private Sub sendmail()
        Dim db As New DBAccess("report")
        Dim dtcampaign As DataTable = db.ReturnTable("select * from tbl_Data_SendMail where campaignid='" & cboCampaigns.SelectedValue & "'", , False)
        db = Nothing
        If dtcampaign.Rows.Count > 0 Then
            imgmail.Visible = True
        Else
            imgmail.Visible = False
        End If
    End Sub
#End Region

    Protected Sub imgfav_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles imgfav.Click
        Common.AddToFav(AgentID, "Transaction Data")
        SuccessMessage("Report has been added to your favourite list")
        fillgrid()
    End Sub
#Region "Utility"

    Private Sub AlertMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMFail"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub

    Private Sub SuccessMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMSuccess"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub

    'Protected Sub ImageButton1_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton1.Click
    '    'fillgrid()
    '    GridViewExportUtil.Export(lblReportName.CurrentPage & "-" & LblError.Text & ".xls", Me.GdAttendance)
    'End Sub


    Public Overrides Sub VerifyRenderingInServerForm(ByVal Control As Control)

    End Sub

#End Region

    Protected Sub GridView1_DataBinding(sender As Object, e As EventArgs) Handles GridView1.DataBinding

    End Sub

    Protected Sub GridView1_DataBound(sender As Object, e As EventArgs) Handles GridView1.DataBound

    End Sub


    Protected Sub GridView1_PageIndexChanging(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewPageEventArgs) Handles GridView1.PageIndexChanging
        GridView1.PageIndex = e.NewPageIndex
        fillgrid()
    End Sub

    'Protected Sub GridView1_PreRender(ByVal sender As Object, ByVal e As System.EventArgs) Handles GridView1.PreRender
    '    If Not GridView1 Is Nothing Then
    '        If GridView1.HeaderRow Is Nothing Then
    '        Else
    '            GridView1.HeaderRow.TableSection = TableRowSection.TableHeader
    '            'GridView1.FooterRow.TableSection = TableRowSection.TableFooter
    '        End If
    '    End If
    'End Sub

    Protected Sub GridView1_RowDataBound(sender As Object, e As GridViewRowEventArgs) Handles GridView1.RowDataBound
        If CampaignID = 375 Then  'aflac campaign


            If e.Row.RowType = DataControlRowType.DataRow Then
                'Dim itemlen As Integer = e.Row.Cells(0).Text.ToString.Length
                'If itemlen > widestdata Then
                '    widestdata = itemlen
                'End If
                'Me.GridView1.Columns(0).ItemStyle.Width = widestdata * 10
                'Me.GridView1.Columns(0).ItemStyle.Wrap = False




                'e.Row.Cells(0).Style.Add("text-align", "left")
                'footerval(0) = footerval(0) + e.Row.Cells(0).Text
                'footerval(1) = footerval(1) + e.Row.Cells(1).Text
                'footerval(2) = footerval(2) + e.Row.Cells(2).Text
                '   'Released	Approval Queue	QA Released	Quality Audit	AWs	Target

                footerval(4) = footerval(4) + Convert.ToDouble(DataBinder.Eval(e.Row.DataItem, "[Released]"))
                footerval(5) = footerval(5) + Convert.ToDouble(DataBinder.Eval(e.Row.DataItem, "[Approval Queue]"))
                footerval(6) = footerval(6) + Convert.ToDouble(DataBinder.Eval(e.Row.DataItem, "[QA Released]"))
                footerval(7) = footerval(7) + Convert.ToDouble(DataBinder.Eval(e.Row.DataItem, "[Quality Audit]"))
                footerval(8) = footerval(8) + Convert.ToDouble(DataBinder.Eval(e.Row.DataItem, "[AWS]"))






            End If

            If e.Row.RowType = DataControlRowType.Footer Then
                ' e.Row.Cells(0).Attributes.Add("style", "white-space:nowrap")
                e.Row.Cells(0).Text = "Total: "
                'e.Row.Cells(1).Style.Add("text-align", "Center")
                'e.Row.Cells(2).Style.Add("text-align", "Center")
                'e.Row.Cells(3).Style.Add("text-align", "Center")
                'e.Row.Cells(4).Style.Add("text-align", "Center")
                'e.Row.Cells(5).Style.Add("text-align", "Center")

                'e.Row.Cells(0).Text = footerval(0)
                'e.Row.Cells(1).Text = footerval(1)
                'e.Row.Cells(2).Text = footerval(2)
                e.Row.Cells(4).Text = Convert.ToString(footerval(4))
                e.Row.Cells(5).Text = Convert.ToString(footerval(5))
                e.Row.Cells(6).Text = Convert.ToString(footerval(6))
                e.Row.Cells(7).Text = Convert.ToString(footerval(7))
                e.Row.Cells(8).Text = Convert.ToString(footerval(8))





            End If

        End If
    End Sub
End Class