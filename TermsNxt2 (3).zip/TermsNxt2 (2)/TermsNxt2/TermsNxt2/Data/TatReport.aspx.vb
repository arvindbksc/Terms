﻿Imports com.nss.DBAccess
Imports System.Data
Imports System.Text
Partial Class Data_TatReport
    Inherits System.Web.UI.Page
#Region "Properties"

    Property ReportType() As Integer
        Get
            Return ViewState("ReportType")
        End Get
        Set(ByVal value As Integer)
            ViewState("ReportType") = value
        End Set
    End Property
    Property CampaignID() As Integer
        Get
            Return ViewState("CampaignID")
        End Get
        Set(ByVal value As Integer)
            ViewState("CampaignID") = value
        End Set
    End Property

    Property AgentID() As String
        Get
            Return ViewState("AgentID")
        End Get
        Set(ByVal value As String)
            ViewState("AgentID") = value
        End Set
    End Property
#End Region
#Region "Load"
    Private Sub LoadData()
        FillCommonFilters()
        FillProcessCampaigns()
    End Sub
#End Region
#Region "Support function"
    Private Sub FillCommonFilters()
        Dim db As New DBAccess
        Dim dt As DataTable = db.ReturnTable("select * from tbl_Reports_DatePeriods")
        db = Nothing
        Dim dr As DataRow = dt.NewRow
        dr(0) = 10
        dr(1) = "Between"
        dt.Rows.Add(dr)
        CboPeriod.DataTextField = "Caption"
        CboPeriod.DataValueField = "Period"
        CboPeriod.DataSource = dt
        CboPeriod.DataBind()
        'db = New DBAccess
        'dt = db.ReturnTable("Select * from tbl_Reports_GroupBy")
        'db = Nothing
        'CboGroup.DataTextField = "Caption"
        'CboGroup.DataValueField = "ID"
        'CboGroup.DataSource = dt
        'CboGroup.DataBind()


    End Sub
    Private Sub FillProcessCampaigns()
        'Common.FillProcessCampaigns(CboProcess, cboCampaigns, AgentID, CampaignID)
        Dim lstcampaign As New ListItem
        lstcampaign.Value = 275
        lstcampaign.Text = "IBIBO Helpdesk"
        cboCampaigns.Items.Add(lstcampaign)
        'Common.FillCampaigns(cboCampaigns, AgentID, CboProcess.SelectedValue)
    End Sub
    Private Function IntegerToDateString(ByVal d As Integer) As String
        Return d.ToString.Substring(0, 4) & "-" & d.ToString.Substring(4, 2) & "-" & d.ToString.Substring(6, 2)
    End Function
    Private Sub CreateGridColumns(ByVal cols As DataColumnCollection)
        GridView1.Columns.Clear()
        Dim tempcolumn As TemplateField
        Dim bouncol As BoundField
        Dim objcol As DataColumn
        For Each objcol In cols
            If objcol.ColumnName = "Agents" Then
                tempcolumn = New TemplateField
                Dim tmpagcol As New TemplateAgentName
                tempcolumn.HeaderText = "Agents"
                tmpagcol.DataImageField = "AgentStatus"
                tmpagcol.DataTextField = objcol.ColumnName
                tempcolumn.ItemStyle.HorizontalAlign = HorizontalAlign.Left
                tempcolumn.ItemTemplate = tmpagcol
                GridView1.Columns.Add(tempcolumn)
            Else
                If objcol.ColumnName <> "Agentstatus" Then
                    bouncol = New BoundField
                    bouncol.HeaderText = objcol.ColumnName
                    bouncol.DataField = objcol.ColumnName


                    GridView1.Columns.Add(bouncol)
                End If

            End If

        Next
       

    End Sub
    Private Sub ExportToexcel()
        Dim tw As New IO.StringWriter()
        Dim hw As New System.Web.UI.HtmlTextWriter(tw)
        'Dim frm As HtmlForm = New HtmlForm()
        Response.ContentType = "application/vnd.ms-excel"
        Response.AddHeader("content-disposition", "attachment;filename=" & lblReportName.Text & "-" & LblError.Text & ".xls")
        Response.Charset = ""
        EnableViewState = False
        'Controls.Add(frm)
        GridView1.RenderControl(hw)
        Response.Write(tw.ToString())
        Response.End()
    End Sub
#End Region
#Region "Grid Function"
    Private Sub fillgrid()
        Dim db As New DBAccess
        Dim startday As Integer, endday As Integer
        If CboPeriod.SelectedValue = 10 Then
            startday = ucDateFrom.yyyymmdd
            endday = UcDateTo.yyyymmdd
        Else
            db = New DBAccess
            db.slDataAdd("Period", CboPeriod.SelectedValue)
            db.slDataAdd("Campaignid", CampaignID)
            Dim dr As DataRow = db.ReturnRow("usp_GetStart_EndDateForAPeriod", True)
            db = Nothing
            startday = dr(0)
            endday = dr(1)
        End If
        db = New DBAccess("Leads")
        Dim dt As New DataTable
        db.slDataAdd("userid", AgentID)
        db.slDataAdd("startday", startday)
        db.slDataAdd("endDay", endday)
        db.slDataAdd("campaignid", CampaignID)
        dt = db.ReturnTable("usp_GetTat275", , True)
        'db.slDataAdd("groupBy", CboGroup.SelectedValue)
        lblReportName.Text = "TAT Summary "
        LblError.Text = "Between " & IntegerToDateString(startday) & "  and " & IntegerToDateString(endday) & " for " & cboCampaigns.SelectedItem.Text & " campaign"

        db = Nothing
        GridView1.AutoGenerateColumns = False
        CreateGridColumns(dt.Columns)
        GridView1.DataSource = dt
        GridView1.DataBind()
        dt = Nothing
        'ScriptManager.RegisterStartupScript(Me, Me.GetType(), "SortGrid", "$(function(){{$('#" & GridView1.ClientID & "').tablesorter({cancelSelection:true}); }});", True)

    End Sub
    Protected Sub GridView1_RowDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles GridView1.RowDataBound
        If e.Row.RowType = DataControlRowType.DataRow Then
            If e.Row.Cells(8).Text = "No" Then
                e.Row.Cells(8).BackColor = Drawing.Color.Red
            End If
        End If
    End Sub
#End Region
   

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            ReportType = Request.QueryString("ReportType")
            If Session("AgentID") <> "" Then
                CampaignID = Session("CampaignID")
                AgentID = Session("AgentID")
                PanelReports.Controls.Add(Common.GetMenu(Request.Url, AgentID, Request.ApplicationPath))
                LoadData()
                fillgrid()
                UcDateTo.Visible = False
                ucDateFrom.Visible = False
                lblAnd.Visible = False
            End If
        End If
    End Sub
#Region "Event"
    Protected Sub ImageButton1_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton1.Click
        fillgrid()
        GridViewExportUtil.Export(lblReportName.Text & "-" & LblError.Text & ".xls", Me.GridView1)
    End Sub

    Protected Sub btnRefresh_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnRefresh.Click
        fillgrid()
    End Sub
    Protected Sub imgfav_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles imgfav.Click
        Common.AddToFav(AgentID, "IBIBO Helpdesk TAT Report")
        SuccessMessage("Report has been added to your favourite list")
        fillgrid()
    End Sub
    Protected Sub CboPeriod_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles CboPeriod.SelectedIndexChanged
        If CboPeriod.SelectedValue = 10 Then
            ucDateFrom.Visible = True
            UcDateTo.Visible = True
            lblAnd.Visible = True
            fillgrid()
        Else
            ucDateFrom.Visible = False
            UcDateTo.Visible = False
            lblAnd.Visible = False
            fillgrid()
        End If
    End Sub
    Protected Sub ucDateFrom_Changed(ByVal sender As Object, ByVal e As System.EventArgs) Handles ucDateFrom.Changed
        fillgrid()
    End Sub

    Protected Sub UcDateTo_Changed(ByVal sender As Object, ByVal e As System.EventArgs) Handles UcDateTo.Changed
        fillgrid()
    End Sub
#End Region
    
#Region "Utility"

    Private Sub AlertMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMFail"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub

    Private Sub SuccessMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMSuccess"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub

    'Protected Sub ImageButton1_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton1.Click
    '    'fillgrid()
    '    GridViewExportUtil.Export(lblReportName.CurrentPage & "-" & LblError.Text & ".xls", Me.GdAttendance)
    'End Sub


    Public Overrides Sub VerifyRenderingInServerForm(ByVal Control As Control)

    End Sub

#End Region
End Class
