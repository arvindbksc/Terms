﻿Imports com.nss.DBAccess
Imports System.Data
Imports System.Text

Partial Class Data_collectedData1
    Inherits System.Web.UI.Page
    Dim footerval(12) As Integer
    Property ReportType() As Integer
        Get
            Return ViewState("ReportType")
        End Get
        Set(ByVal value As Integer)
            ViewState("ReportType") = value
        End Set
    End Property
    Public ReadOnly Property CampaignID() As Integer
        Get
            Return IIf(cboCampaigns.SelectedValue = "", 0, cboCampaigns.SelectedValue)
        End Get

    End Property
    Private Sub LoadData()
        FillCommonFilters()
        FillProcessCampaigns()
    End Sub

    Private Sub FillCommonFilters()
        Dim db As New DBAccess
        Dim dt As DataTable = db.ReturnTable("select * from tbl_Reports_DatePeriods")
        db = Nothing
        CboPeriod.DataTextField = "Caption"
        CboPeriod.DataValueField = "Period"
        CboPeriod.DataSource = dt
        CboPeriod.DataBind()
        db = New DBAccess
        dt = db.ReturnTable("Select * from tbl_Reports_GroupBy")
        db = Nothing
        CboGroup.DataTextField = "Caption"
        CboGroup.DataValueField = "ID"
        CboGroup.DataSource = dt
        CboGroup.DataBind()


    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then

            ReportType = Request.QueryString("ReportType")
            LoadData()
            fillgrid()
            'ElseIf Me.Master.MasterChanged Then
            '    fillgrid()
            '    Me.Master.MasterChanged = False
        End If
    End Sub

    Private Sub fillgrid()

        For Each obj In footerval
            obj = 0
        Next
        Dim columns As String
        Dim db As New DBAccess
        db.slDataAdd("Period", CboPeriod.SelectedValue)
        db.slDataAdd("Campaignid", CampaignID)

        Dim dr As DataRow = db.ReturnRow("usp_GetStart_EndDateForAPeriod", True)
        db = Nothing
        db = New DBAccess
        Dim dt As DataTable
        If ReportType = 0 Then
            db.slDataAdd("startday", dr(0))
            db.slDataAdd("endDay", dr(1))
            db.slDataAdd("campaignid", CampaignID)
            db.slDataAdd("groupBy", CboGroup.SelectedValue)
            If cboFilterBy.SelectedItem.Text <> "None" And txtFilterValue.Text.Trim <> "" Then
                lblFilter.Text = "Filtered for " & cboFilterBy.SelectedItem.Text & " = " & txtFilterValue.Text
                If cboFilterBy.SelectedValue.Contains("String") Then
                    'db.slDataAdd("Filterby", "'" & cboFilterBy.SelectedItem.Text & "'")
                End If
                db.slDataAdd("Filterby", cboFilterBy.SelectedItem.Text)
                db.slDataAdd("Filterbyvalue", txtFilterValue.Text)
            End If
            dt = db.ReturnTable("usp_CampaignPerformanceTerms2", , True)
            'Dim dtime As Date
            'dtime = dr(0).ToString
            lblReportName.Text = CboGroup.SelectedItem.Text & " wise Performance Summary "
            LblError.Text = "Between " & IntegerToDateString(dr(0)) & "  and " & IntegerToDateString(dr(1)) & " for " & cboCampaigns.SelectedItem.Text & " campaign"
        Else
            columns = "*"
            Dim sqlstr As New StringBuilder
            sqlstr.Append("Select ")
            sqlstr.Append(columns)
            sqlstr.Append(" from tbl_Summary_Performance ")
            sqlstr.Append(" where [day] >= ")
            sqlstr.Append(dr(0))
            sqlstr.Append(" and [day]<= ")
            sqlstr.Append(dr(1))
            dt = db.ReturnTable(sqlstr.ToString)
        End If
        db = Nothing
        GridView1.AutoGenerateColumns = False
        CreateGridColumns(dt.Columns)
        GridView1.DataSource = dt
        GridView1.DataBind()
        'System.Threading.Thread.Sleep(100)
    End Sub
    Private Function IntegerToDateString(ByVal d As Integer) As String
        Return d.ToString.Substring(0, 4) & "-" & d.ToString.Substring(4, 2) & "-" & d.ToString.Substring(6, 2)
    End Function
    Private Sub CreateGridColumns(ByVal cols As DataColumnCollection)
        GridView1.Columns.Clear()
        Dim tempcolumn As TemplateField
        Dim bouncol As BoundField
        Dim objcol As DataColumn
        For Each objcol In cols
            If objcol.ColumnName = "Agents" Then
                tempcolumn = New TemplateField
                Dim tmpagcol As New TemplateAgentName
                tempcolumn.HeaderText = "Agents"
                tmpagcol.DataImageField = "AgentStatus"
                tmpagcol.DataTextField = objcol.ColumnName
                tempcolumn.ItemStyle.HorizontalAlign = HorizontalAlign.Left
                tempcolumn.ItemTemplate = tmpagcol
                GridView1.Columns.Add(tempcolumn)
            Else
                If objcol.ColumnName <> "Agentstatus" Then
                    bouncol = New BoundField
                    bouncol.HeaderText = objcol.ColumnName
                    bouncol.DataField = objcol.ColumnName


                    GridView1.Columns.Add(bouncol)
                End If

            End If

        Next
        'Dim MonthCols As BoundField

        'Dim ctr As Integer

        'For ictr As Integer = 0 To ctr
        '    tempcolumn = New TemplateColumn
        '    Dim tmp As New TemplateField

        '    'tempcolumn.ItemTemplate = 
        '    MonthCols = New BoundField
        '    MonthCols.HeaderText = "Month" & ictr + 1
        '    MonthCols.DataField = ""
        '    GridView1.Columns.Add(MonthCols)
        '    'Next

    End Sub
    Private Sub FillProcessCampaigns()
        Dim db As New DBAccess
        Dim dt As DataTable
        dt = db.ReturnTable("Select * from tbl_Config_Processes")
        Dim dr As DataRow
        dr = dt.NewRow
        dr("ProcessName") = "All"
        dr("ProcessID") = 0
        dt.Rows.Add(dr)
        db = Nothing
        CboProcess.DataTextField = "ProcessName"
        CboProcess.DataValueField = "ProcessID"
        CboProcess.DataSource = dt
        CboProcess.DataBind()
        Dim dbt As New DBAccess()
        'dbt.slDataAdd("empID", UserID)
        Dim dtc As DataTable = dbt.ReturnTable("Select * from tbl_config_Campaigns")
        dbt = Nothing
        dr = dtc.NewRow
        dr("Name") = "All"
        dr("CampaignId") = 0
        dtc.Rows.Add(dr)
        cboCampaigns.DataTextField = "Name"
        cboCampaigns.DataValueField = "CampaignId"
        cboCampaigns.DataSource = dtc
        cboCampaigns.DataBind()


    End Sub

    Protected Sub cboCampaigns_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboCampaigns.SelectedIndexChanged
        fillgrid()
        'Dim helper As GridViewHelper = New GridViewHelper(GridView1)
        'helper.RegisterGroup("Agents", True, True)
        'helper.ApplyGroupSort()
    End Sub

    Protected Sub CboPeriod_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles CboPeriod.SelectedIndexChanged
        fillgrid()
    End Sub

    Public Function TimeString(ByVal Seconds As Long) As String

        'if verbose = false, returns
        'something like
        '02:22.08
        'if true, returns
        '2 hours, 22 minutes, and 8 seconds

        Dim lHrs As Long
        Dim lMinutes As Long
        Dim lSeconds As Long

        lSeconds = Seconds

        lHrs = Int(lSeconds / 3600)
        lMinutes = (Int(lSeconds / 60)) - (lHrs * 60)
        lSeconds = Int(lSeconds Mod 60)

        If lSeconds = 60 Then
            lMinutes = lMinutes + 1
            lSeconds = 0
        End If

        If lMinutes = 60 Then
            lMinutes = 0
            lHrs = lHrs + 1
        End If

        TimeString = lHrs.ToString("####00") & ":" & _
        lMinutes.ToString("00") & ":" & _
         lSeconds.ToString("00")

    End Function

    'Protected Sub GridView1_RowCreated(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles GridView1.RowCreated

    '    If e.Row.RowType = DataControlRowType.DataRow Then

    '        e.Row.Cells(1).Controls.AddAt(0, New Image)
    '    End If

    'End Sub

    Protected Sub GridView1_RowDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles GridView1.RowDataBound
        If e.Row.RowType = DataControlRowType.DataRow Then
            footerval(1) = footerval(1) + e.Row.Cells(1).Text
            footerval(2) = footerval(2) + e.Row.Cells(2).Text
            footerval(3) = footerval(3) + e.Row.Cells(3).Text
            footerval(4) = footerval(4) + e.Row.Cells(4).Text
            footerval(5) = footerval(5) + e.Row.Cells(5).Text
            footerval(6) = footerval(6) + e.Row.Cells(6).Text
            footerval(0) += 1


            e.Row.Cells(2).Text = TimeString(e.Row.Cells(2).Text)
            e.Row.Cells(3).Text = TimeString(e.Row.Cells(3).Text)
            e.Row.Cells(4).Text = TimeString(e.Row.Cells(4).Text)
        ElseIf e.Row.RowType = DataControlRowType.Footer Then
            e.Row.Cells(0).Text = "Total: " & footerval(0)
            e.Row.Cells(1).Text = footerval(1)

            e.Row.Cells(2).Text = TimeString(footerval(2))
            e.Row.Cells(3).Text = TimeString(footerval(3))
            e.Row.Cells(4).Text = TimeString(footerval(4))

            e.Row.Cells(5).Text = footerval(5)
            e.Row.Cells(6).Text = footerval(6)
        End If
    End Sub

    Protected Sub ImageButton1_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton1.Click
        fillgrid()
        GridViewExportUtil.Export(lblReportName.Text & "-" & LblError.Text & ".xls", Me.GridView1)
    End Sub

    Private Sub ExportToexcel()
        Dim tw As New IO.StringWriter()
        Dim hw As New System.Web.UI.HtmlTextWriter(tw)
        'Dim frm As HtmlForm = New HtmlForm()
        Response.ContentType = "application/vnd.ms-excel"
        Response.AddHeader("content-disposition", "attachment;filename=" & lblReportName.Text & "-" & LblError.Text & ".xls")
        Response.Charset = ""
        EnableViewState = False
        'Controls.Add(frm)
        GridView1.RenderControl(hw)
        Response.Write(tw.ToString())
        Response.End()
    End Sub
    Public Overrides Sub VerifyRenderingInServerForm(ByVal Control As Control)

    End Sub


    Protected Sub CboGroup_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles CboGroup.SelectedIndexChanged
        fillgrid()
    End Sub

    Protected Sub btnFilter_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnFilter.Click
        fillgrid()
    End Sub

    Protected Sub btnRefresh_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnRefresh.Click
        fillgrid()
    End Sub
End Class
