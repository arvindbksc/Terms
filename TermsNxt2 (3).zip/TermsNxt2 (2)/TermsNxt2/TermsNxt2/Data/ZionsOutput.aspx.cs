﻿using Microsoft.VisualBasic;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using com.nss.DBAccess;
using System.Data.SqlClient;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Web.Services;
using System.Drawing;
using System.Globalization;
using System.Text.RegularExpressions;
using System.IO;
using System.Net;
using System.Web;

public partial class ZionsOutput : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
               // DatewiseGrid2();
                EmployeeDataGrid();
                EmployeeDataGrid1();
            }
        }
        private void EmployeeDataGrid()
        {
           
            DataTable dt = new DataTable();
            DBAccess db = new DBAccess("CRM");
            dt = db.ReturnTable("usp_Zions1", "", false);
            db = null; 
            try
            {
                GridEmpData.DataSource = dt;
                GridEmpData.DataBind();
            }
            catch (Exception)
            {
                lblmsg.Text = "record not found";
            }                

        }

        private void EmployeeDataGrid1()
        {
            GridDatewise.Visible = false;
            GridViewAPH.Visible = false;
            GridView1.Visible = true;
         
           
            DataTable dt = new DataTable();
            DBAccess db = new DBAccess("CRM");
            dt = db.ReturnTable("select Convert(varchar(10),CONVERT(date,EDate,106),103) TDate,* from tbl_zionsTeamwise", "", false);
            db = null;
            try
            {
                GridView1.DataSource = dt;
                GridView1.DataBind();
            }
            catch (Exception)
            {
                lblmsg.Text = "record not found";
            }                

        }


        private void DatewiseGrid2()
        {
            GridView1.Visible = false;
            GridViewAPH.Visible = false;
            GridDatewise.Visible = true;
                 
            DataTable dt = new DataTable();
            DBAccess db = new DBAccess("CRM");
            dt = db.ReturnTable("usp_DatewiseZionsData", "", false);
            db = null;
            try
            {
                GridDatewise.DataSource = dt;
                GridDatewise.DataBind();
            }
            catch (Exception)
            {
                lblmsg.Text = "record not found";
            }           
        }

        private void EmployeeDatagridAPH()
        {
            GridDatewise.Visible = false;
            GridView1.Visible = false;
            GridViewAPH.Visible = true;

            DataTable dt = new DataTable();
            DBAccess db = new DBAccess("CRM");
            dt = db.ReturnTable("CalculateAPH", "", false);
            db = null;
            try
            {
                GridViewAPH.DataSource = dt;
                GridViewAPH.DataBind();
            }
            catch (Exception)
            {
                lblmsg.Text = "record not found";
            }         
           
        }


        protected void grvMergeHeader_RowCreated(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.Header)
            {
                GridView HeaderGrid = (GridView)sender;
                GridViewRow HeaderGridRow = new GridViewRow(0, 0, DataControlRowType.Header, DataControlRowState.Insert);

                TableCell HeaderCell = new TableCell();
               
                HeaderCell = new TableCell();
                HeaderCell.Text = "AS 19";
                HeaderCell.Attributes.Add("style", "padding:5px; font-weight:bold;background-color: #429ABE; border: solid 1px #525252;color:Black;text - align:center;font - size:medium;font - family: Calibri;");
                HeaderCell.ColumnSpan = 2;
                HeaderGridRow.Cells.Add(HeaderCell);

                HeaderCell = new TableCell();
                HeaderCell.Text = "AS 16";
                HeaderCell.Attributes.Add("style", "padding:5px; font-weight:bold;background-color: #429ABE; border: solid 1px #525252;color:Black;text - align:center;font - size:medium;font - family: Calibri;");
                HeaderCell.ColumnSpan = 2;
                HeaderGridRow.Cells.Add(HeaderCell);

                HeaderCell = new TableCell();
                HeaderCell.Text = "KITTING";
                HeaderCell.Attributes.Add("style", "padding:5px; font-weight:bold;background-color: #429ABE; border: solid 1px #525252;color:Black;text - align:center;font - size:medium;font - family: Calibri;");
                HeaderCell.ColumnSpan = 2;
                HeaderGridRow.Cells.Add(HeaderCell);

                HeaderCell = new TableCell();
                HeaderCell.Text = "ANF";
                HeaderCell.Attributes.Add("style", "padding:5px; font-weight:bold;background-color: #429ABE; border: solid 1px #525252;color:Black;text - align:center;font - size:medium;font - family: Calibri;");
                HeaderCell.ColumnSpan = 2;
                HeaderGridRow.Cells.Add(HeaderCell);  
                GridEmpData.Controls[0].Controls.AddAt(0, HeaderGridRow);   
            }

        }

        protected void grvHeader_RowCreated(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.Header)
            {
                GridView HeaderGrid = (GridView)sender;
                GridViewRow HeaderGridRow = new GridViewRow(0, 0, DataControlRowType.Header, DataControlRowState.Insert);

                TableCell HeaderCell = new TableCell();
                HeaderCell.Text = "TeamWise";
                HeaderCell.Attributes.Add("style", "padding:5px;width:200px; font-weight:bold;background-color: #429ABE; border: solid 1px #525252;color:Black;text - align:center;font - size:medium;font - family: Calibri;");
                HeaderCell.ColumnSpan = 3;
                HeaderGridRow.Cells.Add(HeaderCell);

                HeaderCell = new TableCell();
                HeaderCell.Text = "ASI-19";
              
                HeaderCell.Attributes.Add("style", "padding:5px; font-weight:bold;background-color: #429ABE; border: solid 1px #525252;color:Black;text - align:center;font - size:medium;font - family: Calibri;");
               
                HeaderGridRow.Cells.Add(HeaderCell);

                HeaderCell = new TableCell();
                HeaderCell.Text = "ASI-16";
              
                HeaderCell.Attributes.Add("style", "padding:5px; font-weight:bold;background-color: #429ABE; border: solid 1px #525252;color:Black;text - align:center;font - size:medium;font - family: Calibri;");
               
                HeaderGridRow.Cells.Add(HeaderCell);

                HeaderCell = new TableCell();
                HeaderCell.Text = "KITING";
              
                HeaderCell.Attributes.Add("style", "padding:5px; font-weight:bold;background-color: #429ABE; border: solid 1px #525252;color:Black;text - align:center;font - size:medium;font - family: Calibri;");
               
                HeaderGridRow.Cells.Add(HeaderCell);

                HeaderCell = new TableCell();
                HeaderCell.Text = "ANF";
                
                HeaderCell.Attributes.Add("style", "padding:5px; font-weight:bold;background-color: #429ABE; border: solid 1px #525252;color:Black;text - align:center;font - size:medium;font - family: Calibri;");
                HeaderGridRow.Cells.Add(HeaderCell);


                GridView1.Controls[0].Controls.AddAt(0, HeaderGridRow);

            }
        }


        protected void GridViewAPH_RowCreated(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.Header)
            {
                GridView HeaderGrid = (GridView)sender;
                GridViewRow HeaderGridRow = new GridViewRow(0, 0, DataControlRowType.Header, DataControlRowState.Insert);

                TableCell HeaderCell = new TableCell();
                HeaderCell.Text = "TeamWise";
                HeaderCell.Attributes.Add("style", "padding:5px;width:350px; font-weight:bold;background-color: #429ABE; border: solid 1px #525252;color:Black;text - align:center;font - size:medium;font - family: Calibri;");
                HeaderCell.ColumnSpan = 6;
                HeaderGridRow.Cells.Add(HeaderCell);

                HeaderCell = new TableCell();
                HeaderCell.Text = "AS 19";
                HeaderCell.ColumnSpan = 3;
                HeaderCell.Attributes.Add("style", "padding:5px; font-weight:bold;background-color: #429ABE; border: solid 1px #525252;color:Black;text - align:center;font - size:medium;font - family: Calibri;");

                HeaderGridRow.Cells.Add(HeaderCell);

                HeaderCell = new TableCell();
                HeaderCell.Text = "AS 16";
                HeaderCell.ColumnSpan = 3;
                HeaderCell.Attributes.Add("style", "padding:5px; font-weight:bold;background-color: #429ABE; border: solid 1px #525252;color:Black;text - align:center;font - size:medium;font - family: Calibri;");

                HeaderGridRow.Cells.Add(HeaderCell);

                HeaderCell = new TableCell();
                HeaderCell.Text = "KITTING";
                HeaderCell.ColumnSpan = 3;
                HeaderCell.Attributes.Add("style", "padding:5px; font-weight:bold;background-color: #429ABE; border: solid 1px #525252;color:Black;text - align:center;font - size:medium;font - family: Calibri;");

                HeaderGridRow.Cells.Add(HeaderCell);

                HeaderCell = new TableCell();
                HeaderCell.Text = "ANF";
                HeaderCell.ColumnSpan = 3;
                HeaderCell.Attributes.Add("style", "padding:5px; font-weight:bold;background-color: #429ABE; border: solid 1px #525252;color:Black;text - align:center;font - size:medium;font - family: Calibri;");
                HeaderGridRow.Cells.Add(HeaderCell);


                GridViewAPH.Controls[0].Controls.AddAt(0, HeaderGridRow);

            }
        }
    


        protected void btnSubmit_Click(object sender, EventArgs e) 
       {
            lblerr.Text = "";
          
            DataTable dt5 = new DataTable();
            DBAccess db5 = new DBAccess("CRM");
            db5.slDataAdd("Date1", Text.Text.Trim());
            db5.slDataAdd("Date2", Text2.Text.Trim());
            dt5 = db5.ReturnTable("usp_Zions2","", true);
           
            db5 = null;
         
                    try
                    {
                        lblmsg.Text = "";
                        //con.Open();
                        GridEmpData.DataSource = dt5;
                        GridEmpData.DataBind();
                        if (GridEmpData.Rows[0].Cells[0].Text == "&nbsp;")
                        {
                            lblerr.Text = "Record is empty";
                        }
                    }
                    catch (Exception)
                    {
                        lblmsg.Text = "record not found";
                    }                 
                
           
                    DataTable dt1 = new DataTable();
                    DBAccess db1 = new DBAccess("CRM");
                    db1.slDataAdd("Date1", Text.Text);
                    db1.slDataAdd("Date2", Text2.Text);
                    dt1 = db1.ReturnTable("usp_DatewiseZionsData1", "", true);
            
                    try
                    {
                        lblmsg.Text = "";
                        //con.Open();
                        GridDatewise.DataSource = dt1;
                        GridDatewise.DataBind();
                        if (GridDatewise.Rows[0].Cells[0].Text == "&nbsp;")
                        {
                            lblerr.Text = "Record is empty";
                        }
                    }
                    catch (Exception)
                    {
                        lblmsg.Text = "record not found";
                    }
                 
        
                    DataTable dt2 = new DataTable();
                    DBAccess db2 = new DBAccess("CRM");
                    dt2 = db2.ReturnTable("select Convert(varchar(10),CONVERT(date,EDate,106),103) TDate,* from tbl_zionsTeamwise where Convert(varchar(10),CONVERT(date,EDate,106),111) between '" + Text.Text + "' and '" + Text2.Text + "'", "", false);

                    try
                    {
                        GridView1.DataSource = dt2;
                        GridView1.DataBind();
                    }
                    catch (Exception)
                    {
                        lblmsg.Text = "record not found";
                    }  
            
            //APH Grid Datewise data
                  

                    DataTable dt3 = new DataTable();
                    DBAccess db3 = new DBAccess("CRM");
                    db3.slDataAdd("Date1", Text.Text);
                    db3.slDataAdd("Date2", Text2.Text);
                    dt3 = db3.ReturnTable("usp_CalculateAPHDatewise", "", true);
                    db3 = null;
                    try
                    {
                        GridViewAPH.DataSource = dt3;
                        GridViewAPH.DataBind();
                    }
                    catch (Exception)
                    {
                        lblmsg.Text = "record not found";
                    }         

        }

        protected void ddlFilter_SelectedIndexChanged(object sender, EventArgs e)
        {
           if (ddlFilter.SelectedItem.Text == "Agent")
            {
                EmployeeDataGrid1();
            }
           else if(ddlFilter.SelectedItem.Text== "Date")
            {
                DatewiseGrid2();
            }
           else if (ddlFilter.SelectedItem.Text == "APH")
           {
               EmployeeDatagridAPH();
           }
        }
    }
    