﻿Imports com.nss.DBAccess
Imports System.Data
Partial Class Data_Default
    Inherits System.Web.UI.Page
#Region "Properties"
    Property Campaigntype() As Integer
        Get
            Return ViewState("Campaigntype")
        End Get
        Set(ByVal value As Integer)
            ViewState("Campaigntype") = value
            'Session("ProcessID") = value
        End Set
    End Property
    Property CampaignID() As Integer
        Get
            Return ViewState("CampaignID")
        End Get
        Set(ByVal value As Integer)
            ViewState("CampaignID") = value
        End Set
    End Property
    Property AgentID() As String
        Get
            Return ViewState("AgentID")
        End Get
        Set(ByVal value As String)
            ViewState("AgentID") = value
        End Set
    End Property
#End Region
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            If Session("AgentID") <> "" Then
                CampaignID = Session("CampaignID")
                AgentID = Session("AgentID")
                'Panelmenu.Controls.Add(Common.GetMenu(Request.Url, AgentID,Request.ApplicationPath))
                'FillProcessCampaigns()
                'FillGraph()
                Redirect()
            End If

            'getagentPage()
        End If
    End Sub
    Private Sub Redirect()
        Dim db As New DBAccess
        db.slDataAdd("agentid", AgentID)
        db.slDataAdd("module", 9)
        Dim url As String = db.ReturnValue("usp_getTop1ReportTerm2", True)
        db = Nothing
        Dim page() As String = url.Split("/")
        Response.Redirect(page(1))
    End Sub
    Private Sub FillProcessCampaigns()
        Common.FillProcessCampaigns(CboProcess, cboCampaigns, AgentID, CampaignID)
    End Sub
    Private Sub FillGraph()
        ChartContainerInner.Controls.Clear()
        Dim objLink As HyperLink
        Dim objImg As Image
        For ictr = 0 To 3
            objLink = New HyperLink
            objLink.NavigateUrl = "../Graphs/EnlargedGraph.aspx?type=Trans&KPA=" & ictr + 1 & "&GraphSize=200&CampaignID=" & cboCampaigns.SelectedValue & "&graphtype=" & cboGraphType.SelectedValue & "&period=" & cboChartPeriod.SelectedValue
            objLink.ID = "lnkKPA" & ictr + 1
            objImg = New Image
            objImg.ImageUrl = "../Graphs/thumbgraph.aspx?type=Trans&KPA=" & ictr + 1 & "&GraphSize=200&CampaignID=" & cboCampaigns.SelectedValue & "&graphtype=" & cboGraphType.SelectedValue & "&period=" & cboChartPeriod.SelectedValue
            objImg.ID = "imgKPA" & ictr + 1
            objImg.CssClass = "chart"
            objLink.Controls.Add(objImg)
            ChartContainerInner.Controls.Add(objLink)
        Next

    End Sub
    Private Sub getagentPage()
        Dim db As New DBAccess
        db.slDataAdd("Campaignid", CampaignID)
        db.slDataAdd("userid", AgentID)
        Dim dtcampaigntype As DataTable = db.ReturnTable("usp_getcampaigntype", , True)
        db = Nothing
        If dtcampaigntype.Rows.Count > 1 Then
            Campaigntype = 1
        Else
            Campaigntype = dtcampaigntype.Rows(0).Item(0)
        End If
        'Dim serverpath As String
        'If Request.Url.Host = "localhost" Then
        '    serverpath = HttpContext.Current.Request.ApplicationPath
        'Else
        '    serverpath = "http://termsmonitor.niitsmartserve.com"
        'End If
        If Campaigntype = 11 Then
            Response.Redirect("CallTableFillRate.aspx")
        Else
            Response.Redirect("^Transactiondata")
        End If
    End Sub

    Protected Sub cboCampaigns_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboCampaigns.SelectedIndexChanged
        'Panelmenu.Controls.Add(Common.GetMenu(Request.Url, AgentID,Request.ApplicationPath))
        FillGraph()
    End Sub

    Protected Sub cboGraphType_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboGraphType.SelectedIndexChanged
        'Panelmenu.Controls.Add(Common.GetMenu(Request.Url, AgentID,Request.ApplicationPath))
        FillGraph()
    End Sub

    'Protected Sub cboGroupby_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboGroupby.SelectedIndexChanged
    '    FillGraph()
    'End Sub

    Protected Sub cboChartPeriod_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboChartPeriod.SelectedIndexChanged
        FillGraph()
    End Sub

    Protected Sub btnRefresh_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnRefresh.Click
        FillGraph()
    End Sub
End Class
