﻿Imports com.nss.DBAccess
Imports System.Data
Imports System.Text
Partial Class Data_ClientEsclationReport
    Inherits System.Web.UI.Page
#Region "Properties"

    Property ProcessID() As Integer
        Get
            Return ViewState("ProcessID")
        End Get
        Set(ByVal value As Integer)
            ViewState("ProcessID") = value
            Session("ProcessID") = value
        End Set
    End Property
    Property Campaigntype() As Integer
        Get
            Return ViewState("Campaigntype")
        End Get
        Set(ByVal value As Integer)
            ViewState("Campaigntype") = value
            'Session("ProcessID") = value
        End Set
    End Property
    Property ReportType() As Integer
        Get
            Return ViewState("ReportType")
        End Get
        Set(ByVal value As Integer)
            ViewState("ReportType") = value
        End Set
    End Property
    Property CampaignID() As Integer
        Get
            Return ViewState("CampaignID")
        End Get
        Set(ByVal value As Integer)
            ViewState("CampaignID") = value
        End Set
    End Property

    Property AgentID() As String
        Get
            Return ViewState("AgentID")
        End Get
        Set(ByVal value As String)
            ViewState("AgentID") = value
        End Set
    End Property
#End Region
#Region "Load"
    Private Sub LoadData()
        FillCommonFilters()
        FillProcessCampaigns()
    End Sub
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        HumanMessage.Style.Item("visibility") = "hidden"
        If Not IsPostBack Then
            ReportType = Request.QueryString("ReportType")
            If Session("AgentID") <> "" Then
                CampaignID = Session("CampaignID")
                AgentID = Session("AgentID")
                PanelReports.Controls.Add(Common.GetMenu(Request.Url, AgentID, Request.ApplicationPath))
                LoadData()
                fillgrid()
                UcDateTo.Visible = False
                ucDateFrom.Visible = False
                lblAnd.Visible = False
            End If
        End If
    End Sub
    Private Sub fillgrid()
        Dim db As New DBAccess
        Dim startday As Integer, endday As Integer
        If CboPeriod.SelectedValue = 10 Then
            startday = ucDateFrom.yyyymmdd
            endday = UcDateTo.yyyymmdd
        Else
            db = New DBAccess
            db.slDataAdd("Period", CboPeriod.SelectedValue)
            db.slDataAdd("Campaignid", CampaignID)
            Dim dr As DataRow = db.ReturnRow("usp_GetStart_EndDateForAPeriod", True)
            db = Nothing
            startday = dr(0)
            endday = dr(1)
        End If
        db = New DBAccess
        Dim dt As New DataTable
        db.slDataAdd("userid", AgentID)
        db.slDataAdd("startday", startday)
        db.slDataAdd("endDay", endday)
        db.slDataAdd("campaignid", CampaignID)
        lblFilter.Text = "Filtered for " & cboFilterBy.SelectedItem.Text
        db.slDataAdd("Filterby", cboFilterBy.SelectedValue)
        db.slDataAdd("client", cboclient.SelectedValue)
        dt = db.ReturnTable("usp_GetClinetTransactions", , True)
        lblReportName.Text = "Client Escalation Status Report "
        LblError.Text = "Between " & IntegerToDateString(startday) & "  and " & IntegerToDateString(endday) & " for " & cboCampaigns.SelectedItem.Text & " campaign"
        db = Nothing
        GridView1.AutoGenerateColumns = True
        'If dt.Rows.Count > 0 Then
        'CreateGridColumns(dt.Columns)
        GridView1.DataSource = dt
        GridView1.DataBind()
        'Else
        '    GridView1.DataSource = Nothing
        'End If
        dt = Nothing
        ScriptManager.RegisterStartupScript(Me, Me.GetType(), "SortGrid", "$(function(){{$('#" & GridView1.ClientID & "').tablesorter({cancelSelection:true}); }});", True)
    End Sub
#End Region
#Region "Function"
    Private Sub FillCommonFilters()
        Dim db As New DBAccess
        Dim dt As DataTable = db.ReturnTable("select * from tbl_Reports_DatePeriods", , False)
        db = Nothing
        Dim dr As DataRow = dt.NewRow
        dr(0) = 10
        dr(1) = "Between"
        dt.Rows.Add(dr)
        CboPeriod.DataTextField = "Caption"
        CboPeriod.DataValueField = "Period"
        CboPeriod.DataSource = dt
        CboPeriod.DataBind()
        dt = Nothing
        FillClient()
    End Sub
    Private Sub FillClient()
        Dim db As New DBAccess
        db.slDataAdd("campaignid", CampaignID)
        db.slDataAdd("Questid", 2380029)
        Dim dtclient As DataTable = db.ReturnTable("usp_getQuest_Answer", , True)
        db = Nothing
        cboclient.DataTextField = "Answer"
        cboclient.DataValueField = "Answer"
        cboclient.DataSource = dtclient
        cboclient.DataBind()
        dtclient = Nothing
        Dim lstclient As New ListItem
        lstclient.Value = "NA"
        lstclient.Text = "NA"
        If cboclient.Items.Contains(lstclient) Then
            cboclient.Items.Remove(lstclient)
        End If
        Dim lstclientall As New ListItem
        lstclientall.Value = "%"
        lstclientall.Text = "All"
        cboclient.Items.Insert(0, lstclientall)
    End Sub
    Private Sub FillProcessCampaigns()
        Common.FillProcessCampaigns(CboProcess, cboCampaigns, AgentID, CampaignID)
    End Sub
    Private Function IntegerToDateString(ByVal d As Integer) As String
        Return d.ToString.Substring(0, 4) & "-" & d.ToString.Substring(4, 2) & "-" & d.ToString.Substring(6, 2)
    End Function
    Private Sub CreateGridColumns(ByVal cols As DataColumnCollection)
        Dim db As New DBAccess
        db.slDataAdd("CampaignID", CampaignID)
        Dim dtoutcome As DataTable = db.ReturnTable("usp_ReportQuestDataDescription", , True)
        For Each dr In dtoutcome.Rows
            cols("Question" & dr("ReportSequence")).Caption = dr("Caption")
        Next

        GridView1.Columns.Clear()

        Dim tempcolumn As TemplateField
        Dim bouncol As BoundField
        Dim objcol As DataColumn
        For Each objcol In cols
            If objcol.ColumnName = "Agents" Then
                tempcolumn = New TemplateField
                Dim tmpagcol As New TemplateAgentName
                tempcolumn.HeaderText = "Agents"
                tmpagcol.DataImageField = "AgentStatus"
                tmpagcol.DataTextField = objcol.ColumnName
                tempcolumn.ItemStyle.HorizontalAlign = HorizontalAlign.Left
                tempcolumn.ItemTemplate = tmpagcol
                GridView1.Columns.Add(tempcolumn)
            ElseIf objcol.ColumnName.Contains("Question") Then
                If objcol.Caption <> objcol.ColumnName Then
                    bouncol = New BoundField
                    bouncol.HeaderText = objcol.Caption
                    bouncol.DataField = objcol.ColumnName
                    GridView1.Columns.Add(bouncol)
                End If
            Else
                If objcol.ColumnName <> "Agentstatus" Then
                    bouncol = New BoundField
                    bouncol.HeaderText = objcol.ColumnName
                    bouncol.DataField = objcol.ColumnName
                    GridView1.Columns.Add(bouncol)
                End If
            End If
        Next
    End Sub
    Private Sub ExportToexcel()
        Dim tw As New IO.StringWriter()
        Dim hw As New System.Web.UI.HtmlTextWriter(tw)
        'Dim frm As HtmlForm = New HtmlForm()
        Response.ContentType = "application/vnd.ms-excel"
        Response.AddHeader("content-disposition", "attachment;filename=" & lblReportName.Text & "-" & LblError.Text & ".xls")
        Response.Charset = ""
        EnableViewState = False
        'Controls.Add(frm)
        GridView1.RenderControl(hw)
        Response.Write(tw.ToString())
        Response.End()
    End Sub
#End Region
#Region "Events"
    Protected Sub cboCampaigns_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboCampaigns.SelectedIndexChanged
        CampaignID = cboCampaigns.SelectedValue
        FillClient()
        fillgrid()
    End Sub
    Protected Sub ImageButton1_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton1.Click
        fillgrid()
        GridViewExportUtil.Export(lblReportName.Text & "-" & LblError.Text & ".xls", Me.GridView1)
    End Sub
    Protected Sub btnRefresh_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnRefresh.Click
        fillgrid()
    End Sub
    Protected Sub CboPeriod_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles CboPeriod.SelectedIndexChanged
        If CboPeriod.SelectedValue = 10 Then
            ucDateFrom.Visible = True
            UcDateTo.Visible = True
            lblAnd.Visible = True
            fillgrid()
        Else
            ucDateFrom.Visible = False
            UcDateTo.Visible = False
            lblAnd.Visible = False
            fillgrid()
        End If
    End Sub
    Protected Sub cboFilterBy_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboFilterBy.SelectedIndexChanged
        fillgrid()
    End Sub
    Protected Sub cboclient_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboclient.SelectedIndexChanged
        fillgrid()
    End Sub
    Protected Sub GridView1_PreRender(ByVal sender As Object, ByVal e As System.EventArgs) Handles GridView1.PreRender
        If Not GridView1 Is Nothing Then
            If GridView1.HeaderRow Is Nothing Then
            Else
                GridView1.HeaderRow.TableSection = TableRowSection.TableHeader
                GridView1.FooterRow.TableSection = TableRowSection.TableFooter
            End If
        End If
    End Sub
    Protected Sub imgfav_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles imgfav.Click
        Common.AddToFav(AgentID, "Client Escalation Report")
        SuccessMessage("Report has been added to your favourite list")
        fillgrid()
    End Sub
#End Region
#Region "Utility"

    Private Sub AlertMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMFail"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub

    Private Sub SuccessMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMSuccess"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub

    'Protected Sub ImageButton1_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton1.Click
    '    'fillgrid()
    '    GridViewExportUtil.Export(lblReportName.CurrentPage & "-" & LblError.Text & ".xls", Me.GdAttendance)
    'End Sub


    Public Overrides Sub VerifyRenderingInServerForm(ByVal Control As Control)

    End Sub

#End Region
End Class
