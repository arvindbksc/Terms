﻿Imports com.nss.DBAccess
Imports System.Data
Partial Class Data_CallTableLoginHour
    Inherits System.Web.UI.Page
    Dim ActiveCalltable As Integer
#Region "-- Properties --"
    Property ProcessID() As Integer
        Get
            Return ViewState("ProcessID")
        End Get
        Set(ByVal value As Integer)
            ViewState("ProcessID") = value
            Session("ProcessID") = value
        End Set
    End Property
    Property Agentid() As String
        Get
            Return ViewState("Agentid")
        End Get
        Set(ByVal value As String)
            ViewState("Agentid") = value
        End Set
    End Property
    Property dtCalltable() As DataTable
        Get
            Return ViewState("dtCalltable")
        End Get
        Set(ByVal value As DataTable)
            ViewState("dtCalltable") = value
        End Set
    End Property
    Property CampaignID() As Integer
        Get
            Return ViewState("CampaignID")
        End Get
        Set(ByVal value As Integer)
            ViewState("CampaignID") = value
        End Set
    End Property
    Public Property currentdate() As Date
        Get
            Return ViewState("currentdate")
        End Get
        Set(ByVal value As Date)
            ViewState("currentdate") = value
        End Set
    End Property
    Property dttotal() As DataTable
        Get
            Return ViewState("dttotal")
        End Get
        Set(ByVal value As DataTable)
            ViewState("dttotal") = value
        End Set
    End Property
#End Region
    Dim footerval(23) As Double
    Dim rows As Integer
    Dim col As Integer
    Dim counter As Integer = 0
#Region "-- Load --"
    Private Sub LoadData()
        FillCommonFilters()
        FillProcessCampaigns()
    End Sub
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        HumanMessage.Style.Item("visibility") = "hidden"
        If Not IsPostBack Then
            If Session("AgentID") <> "" Then
                CampaignID = Session("CampaignID")
                Agentid = Session("AgentID")
                PanelReports.Controls.Add(Common.GetMenu(Request.Url, AgentID, Request.ApplicationPath))
                LoadData()
                fillData()
                UcDateTo.Visible = False
                ucDateFrom.Visible = False
                lblAnd.Visible = False
            End If
        End If
    End Sub

    Private Sub FillCommonFilters()
        Dim db As New DBAccess
        Dim dt As DataTable = db.ReturnTable("select * from tbl_Reports_DatePeriods")
        db = Nothing
        Dim dr As DataRow = dt.NewRow
        dr(0) = 10
        dr(1) = "Between"
        dt.Rows.Add(dr)
        CboPeriod.DataTextField = "Caption"
        CboPeriod.DataValueField = "Period"
        CboPeriod.DataSource = dt
        CboPeriod.DataBind()
        
    End Sub
#End Region

#Region "-- Functions --"
    Private Sub fillData()
        Dim db As New DBAccess
        Dim startday As Integer, endday As Integer
        If CboPeriod.SelectedValue = 10 Then
            startday = ucDateFrom.yyyymmdd
            endday = UcDateTo.yyyymmdd
        Else
            db = New DBAccess
            db.slDataAdd("Period", CboPeriod.SelectedValue)
            db.slDataAdd("Campaignid", CampaignID)
            Dim dr As DataRow = db.ReturnRow("usp_GetStart_EndDateForAPeriod", True)
            db = Nothing
            startday = dr(0)
            endday = dr(1)
        End If
        db = New DBAccess
        Dim dt As DataTable
        db.slDataAdd("StartDate", startday)
        db.slDataAdd("EndDate", endday)
        db.slDataAdd("userid", Agentid)
        db.slDataAdd("processid", 9)
        db.slDataAdd("campaignid", cboCampaigns.SelectedValue)
        db.slDataAdd("GroupBy", 0)
        dt = db.ReturnTable("usp_AttendanceHistoryCampaign", , True)
        db = Nothing
        counter = dt.Rows.Count
        'Dim row As DataRow = dt.NewRow
        'row(0) = -1
        'row(1) = "GrandTotal"
        'dt.Rows.Add(row)
        'lblReportName.Text = " Attendance History "
        reptgroupby.DataSource = dt
        reptgroupby.DataBind()

        dt = Nothing
    End Sub
    'Private Sub BindDataList()
    '    Dim db As New DBAccess
    '    Dim startday As Integer, endday As Integer
    '    If CboPeriod.SelectedValue = 10 Then
    '        startday = ucDateFrom.yyyymmdd
    '        endday = UcDateTo.yyyymmdd
    '    Else
    '        db = New DBAccess
    '        db.slDataAdd("Period", CboPeriod.SelectedValue)
    '        db.slDataAdd("Campaignid", CampaignID)
    '        Dim dr As DataRow = db.ReturnRow("usp_GetStart_EndDateForAPeriod", True)
    '        db = Nothing
    '        startday = dr(0)
    '        endday = dr(1)
    '    End If
    '    db = New DBAccess
    '    db.slDataAdd("UserId", Agentid)
    '    db.slDataAdd("Campaignid", CampaignID)
    '    db.slDataAdd("datefrom", startday)
    '    db.slDataAdd("dateto", endday)
    '    db.slDataAdd("ProcessID", ProcessID)
    '    dtCalltable = db.ReturnTable("usp_CalltableWiseLoginHours_Terms2", , True)
    '    db = Nothing
    '    lblReportName.Text = "Calltable wise login hours Between " & IntegerToDateString(startday) & "  and " & IntegerToDateString(endday) & " for " & cboCampaigns.SelectedItem.Text & " campaign"
    '    If dtCalltable.Rows.Count > 0 Then
    '        dlcalltable.DataSource = dtCalltable
    '        dlcalltable.DataBind()
    '    End If
    'End Sub
    Private Sub FillProcessCampaigns()
        Common.FillProcessCampaigns(CboProcess, cboCampaigns, AgentID, CampaignID)
    End Sub
#End Region

#Region "-- Event --"
    Protected Sub btnRefresh_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnRefresh.Click
        fillData()
    End Sub
    Private Function IntegerToDateString(ByVal d As Integer) As String
        Return d.ToString.Substring(0, 4) & "-" & d.ToString.Substring(4, 2) & "-" & d.ToString.Substring(6, 2)
    End Function
    Dim Total_TalkTM, Total_WrapTM, Total_IdealTM, Total_LoginTM, Total_comp As Int64
    Dim Total_TalkPR, Total_WrapPR, Total_IdealPR, Total_LoginPR As Int64

    Dim Gross_TalkTM, Gross_WrapTM, Gross_IdealTM, Gross_LoginTM, Gross_comp As Int64
    Dim Gross_TalkPR, Gross_WrapPR, Gross_IdealPR, Gross_LoginPR As Int64

    Protected Sub dlcalltableItemCreated(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.DataListItemEventArgs)

        If e.Item.ItemType = ListItemType.AlternatingItem Or e.Item.ItemType = ListItemType.Item Then
            Dim hdactivecalltable As HiddenField = CType(e.Item.FindControl("hdactivecalltable"), HiddenField)
            'ActiveCalltable = dtCalltable.Rows(e.Item.ItemIndex).Item("chActive")
            If hdactivecalltable.Value = "1" Then
                Dim activerow As HtmlTableRow = CType(e.Item.FindControl("ActiveCallTable"), HtmlTableRow)
                activerow.BgColor = "LightGreen"
            End If
        End If
    End Sub
    Protected Sub dlcalltableItemDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.DataListItemEventArgs)

        If e.Item.ItemType = ListItemType.Item Or e.Item.ItemType = ListItemType.AlternatingItem Then
            Dim TalkDuration As Label = CType(e.Item.FindControl("lblTalkDuration"), Label)
            Dim TalkPercent As Label = CType(e.Item.FindControl("lblTalkPercent"), Label)
            Dim LoginDuration As Label = CType(e.Item.FindControl("lblLoginHour"), Label)
            Dim LoginPercent As Label = CType(e.Item.FindControl("lblLoginPercent"), Label)
            Dim WrapDuration As Label = CType(e.Item.FindControl("lblWrapDuration"), Label)
            Dim WrapPercent As Label = CType(e.Item.FindControl("lblWrapPercent"), Label)
            Dim IdealDuration As Label = CType(e.Item.FindControl("lblIdealDuration"), Label)
            Dim IdealPercent As Label = CType(e.Item.FindControl("lblIdealPercent"), Label)
            Dim hdactivecalltable As HiddenField = CType(e.Item.FindControl("hdactivecalltable"), HiddenField)
            Dim comp As Label = CType(e.Item.FindControl("lblCompletes"), Label)
            Dim CPH As Label = CType(e.Item.FindControl("lblCPH"), Label)
            Total_TalkTM = Total_TalkTM + TalkDuration.Text
            Total_WrapTM = Total_WrapTM + WrapDuration.Text
            Total_IdealTM = Total_IdealTM + IdealDuration.Text
            Total_LoginTM = Total_LoginTM + LoginDuration.Text
            Total_comp = Total_comp + comp.Text
            CPH.Text = Math.Round((Convert.ToInt64(comp.Text) / (Convert.ToInt64(LoginDuration.Text) / 3600 * 1.0)), 2)
            TalkPercent.Text = Math.Round((TalkDuration.Text * 100) / (LoginDuration.Text * 1.0), 2)
            WrapPercent.Text = Math.Round((WrapDuration.Text * 100) / (LoginDuration.Text * 1.0), 2)
            IdealPercent.Text = Math.Round((IdealDuration.Text * 100) / (LoginDuration.Text * 1.0), 2)
            LoginPercent.Text = Math.Round((LoginDuration.Text * 100) / (LoginPercent.Text * 1.0), 2)
            TalkDuration.Text = Common.TimeString(Convert.ToInt64(TalkDuration.Text))
            WrapDuration.Text = Common.TimeString(Convert.ToInt64(WrapDuration.Text))
            IdealDuration.Text = Common.TimeString(Convert.ToInt64(IdealDuration.Text))
            LoginDuration.Text = Common.TimeString(Convert.ToInt64(LoginDuration.Text))

            Total_TalkPR = Total_TalkPR + TalkPercent.Text
            Total_WrapPR = Total_WrapPR + WrapPercent.Text
            Total_IdealPR = Total_IdealPR + IdealPercent.Text
            Total_LoginPR = Total_LoginPR + LoginPercent.Text
            If hdactivecalltable.Value = "1" Then
                Dim activerow As HtmlTableRow = CType(e.Item.FindControl("ActiveCallTable"), HtmlTableRow)
                activerow.BgColor = "LightGreen"
            End If
        End If
        If e.Item.ItemType = ListItemType.Footer Then
            Dim TotalTalkTime As Label = CType(e.Item.FindControl("lblTotalTalkTime"), Label)
            Dim TotalTalkPercent As Label = CType(e.Item.FindControl("lblTotalTalkPercent"), Label)
            Dim TotalWrapTime As Label = CType(e.Item.FindControl("lblTotalWrapTime"), Label)
            Dim TotalWrapPercent As Label = CType(e.Item.FindControl("lblTotalWarpPercent"), Label)
            Dim TotalIdealTime As Label = CType(e.Item.FindControl("lblTotalIdealTime"), Label)
            Dim TotalIdealPercent As Label = CType(e.Item.FindControl("lblTotalIdealPercent"), Label)
            Dim TotalLoginTime As Label = CType(e.Item.FindControl("lblTotalLoginTime"), Label)
            Dim TotalLoginPercent As Label = CType(e.Item.FindControl("lblTotalLoginPercent"), Label)
            Dim Totalcomplete As Label = CType(e.Item.FindControl("lblTotalComplete"), Label)
            Dim TotalCPH As Label = CType(e.Item.FindControl("lvlTotalCPH"), Label)
            'TotalTalkTime.Text = ""
            TotalTalkPercent.Text = Math.Round((Total_TalkTM * 100) / (Total_LoginTM * 1.0), 2)
            TotalWrapPercent.Text = Math.Round((Total_WrapTM * 100) / (Total_LoginTM * 1.0), 2)
            TotalIdealPercent.Text = Math.Round((Total_IdealTM * 100) / (Total_LoginTM * 1.0), 2)
            TotalLoginPercent.Text = Math.Round((Total_LoginTM * 100) / (Total_LoginTM * 1.0), 2)
            Totalcomplete.Text = Total_comp
            TotalCPH.Text = Math.Round((Total_comp / (Total_LoginTM / 3600 * 1.0)), 2)
            TotalTalkTime.Text = Common.TimeString(Total_TalkTM)
            TotalWrapTime.Text = Common.TimeString(Total_WrapTM)
            TotalIdealTime.Text = Common.TimeString(Total_IdealTM)
            TotalLoginTime.Text = Common.TimeString(Total_LoginTM)

            '---- By Rajendra 2013-06-04

            Gross_TalkTM += Total_TalkTM
            Gross_WrapTM += Total_WrapTM
            Gross_IdealTM += Total_IdealTM
            Gross_LoginTM += Total_LoginTM
            Gross_comp += Total_comp

            If counter = 1 Then
                Dim lblGrossTotal As Label = CType(e.Item.FindControl("lblGrossTotal"), Label)
                Dim lblGrossTalkTime As Label = CType(e.Item.FindControl("lblGrossTalkTime"), Label)
                Dim lblGrossTalkPercent As Label = CType(e.Item.FindControl("lblGrossTalkPercent"), Label)
                Dim lblGrossWrapTime As Label = CType(e.Item.FindControl("lblGrossWrapTime"), Label)
                Dim lblGrossWarpPercent As Label = CType(e.Item.FindControl("lblGrossWarpPercent"), Label)
                Dim lblGrossIdealTime As Label = CType(e.Item.FindControl("lblGrossIdealTime"), Label)
                Dim lblGrossIdealPercent As Label = CType(e.Item.FindControl("lblGrossIdealPercent"), Label)
                Dim lblGrossLoginTime As Label = CType(e.Item.FindControl("lblGrossLoginTime"), Label)
                Dim lblGrossLoginPercent As Label = CType(e.Item.FindControl("lblGrossLoginPercent"), Label)
                Dim lblGrossComplete As Label = CType(e.Item.FindControl("lblGrossComplete"), Label)
                Dim lblGrossCPH As Label = CType(e.Item.FindControl("lblGrossCPH"), Label)
                lblGrossTotal.Text = "Gross Total:"
                lblGrossTalkTime.Text = Common.TimeString(Gross_TalkTM)
                lblGrossTalkPercent.Text = Math.Round((Gross_TalkTM * 100) / (Gross_LoginTM * 1.0), 2)
                lblGrossWrapTime.Text = Common.TimeString(Gross_WrapTM)
                lblGrossWarpPercent.Text = Math.Round((Gross_WrapTM * 100) / (Gross_LoginTM * 1.0), 2)
                lblGrossIdealTime.Text = Common.TimeString(Gross_IdealTM)
                lblGrossIdealPercent.Text = Math.Round((Gross_IdealTM * 100) / (Gross_LoginTM * 1.0), 2)
                lblGrossLoginTime.Text = Common.TimeString(Gross_LoginTM)
                lblGrossLoginPercent.Text = Math.Round((Gross_LoginTM * 100) / (Gross_LoginTM * 1.0), 2)
                lblGrossComplete.Text = Gross_comp
                lblGrossCPH.Text = Math.Round((Gross_comp / (Gross_LoginTM / 3600 * 1.0)), 2)
                '-----------------------------------------
            End If
            Total_TalkTM = 0
            Total_WrapTM = 0
            Total_IdealTM = 0
            Total_LoginTM = 0
            Total_comp = 0
        End If

    End Sub
    Protected Sub cboCampaign_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboCampaigns.SelectedIndexChanged
        CampaignID = cboCampaigns.SelectedValue
        fillData()
    End Sub
    Protected Sub CboProcess_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles CboProcess.SelectedIndexChanged
        ProcessID = CboProcess.SelectedValue
        Common.FillCampaigns(cboCampaigns, Agentid, CboProcess.SelectedValue)
        CampaignID = cboCampaigns.SelectedValue
        fillData()
    End Sub
    Protected Sub CboPeriod_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles CboPeriod.SelectedIndexChanged
        If CboPeriod.SelectedValue = 10 Then
            ucDateFrom.Visible = True
            UcDateTo.Visible = True
            lblAnd.Visible = True
            fillData()
        Else
            ucDateFrom.Visible = False
            UcDateTo.Visible = False
            lblAnd.Visible = False
            fillData()
        End If
    End Sub
    Protected Sub imgfav_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles imgfav.Click
        Common.AddToFav(Agentid, "CallTable LoginHour")
        SuccessMessage("Report has been added to your favourite list")
        LoadData()
        fillData()
    End Sub

    Dim dgdata As DataList
    Dim hasdata As Boolean = False
    Protected Sub reptgroupby_ItemDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.RepeaterItemEventArgs) Handles reptgroupby.ItemDataBound

        Dim lblcampaign As Label = e.Item.FindControl("lblcampaign")
        Dim lblcampid As Label = e.Item.FindControl("lblcampid")

        Dim db As DBAccess
        Dim startday As Integer, endday As Integer
        If CboPeriod.SelectedValue = 10 Then
            startday = ucDateFrom.yyyymmdd
            endday = UcDateTo.yyyymmdd
        Else
            db = New DBAccess
            db.slDataAdd("Period", CboPeriod.SelectedValue)
            db.slDataAdd("Campaignid", CampaignID)
            Dim dr As DataRow = db.ReturnRow("usp_GetStart_EndDateForAPeriod", True)
            db = Nothing
            startday = dr(0)
            endday = dr(1)
        End If

        db = New DBAccess
        Dim dt As DataTable
        db.slDataAdd("userid", Agentid)
        db.slDataAdd("datefrom", startday)
        db.slDataAdd("dateto", endday)
        db.slDataAdd("campaignid", lblcampid.Text)
        'db.slDataAdd("ProcessID", ProcessID)
        dt = db.ReturnTable("usp_CalltableWiseLoginHours_Terms2", , True)
        rows = dt.Rows.Count

        If rows > 0 Then
            hasdata = True
        End If

        dttotal = dt.Clone
        lblReportName.Text = "Calltable wise login hours Between " & IntegerToDateString(startday) & "  and " & IntegerToDateString(endday) & " for " & cboCampaigns.SelectedItem.Text & " campaign"

        db = Nothing
        dgdata = e.Item.FindControl("dlcalltable")
        If hasdata = True Then
            'If lblcampaign.Text <> "GrandTotal" Then
            '    'Dim dgdata1 As GridView = e.Item.FindControl("GridView2")
            AddHandler dgdata.ItemDataBound, AddressOf dlcalltableItemDataBound
            'AddHandler dgdata.ItemCreated, AddressOf dlcalltableItemCreated
            If dt.Rows.Count > 0 Then
                dgdata.DataSource = dt
                dgdata.DataBind()
                counter = counter - 1
            Else
                lblcampaign.Visible = False
                dgdata.Visible = False
            End If
            'End If
        Else
            lblcampaign.Visible = False
            dgdata.Visible = False
        End If
    End Sub
#End Region

#Region "-- Utility --"

    Private Sub AlertMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMFail"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub

    Private Sub SuccessMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMSuccess"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub

    'Protected Sub ImageButton1_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton1.Click
    '    'fillgrid()
    '    GridViewExportUtil.Export(lblReportName.CurrentPage & "-" & LblError.Text & ".xls", Me.GdAttendance)
    'End Sub


    Public Overrides Sub VerifyRenderingInServerForm(ByVal Control As Control)

    End Sub

#End Region
   
End Class
