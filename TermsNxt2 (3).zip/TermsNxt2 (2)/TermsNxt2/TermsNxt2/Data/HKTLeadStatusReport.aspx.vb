﻿Imports com.nss.DBAccess
Imports System.Data
Partial Class HKTLeadStatusReport
    Inherits System.Web.UI.Page
#Region "Properties"

    Property ReportType() As Integer
        Get
            Return ViewState("ReportType")
        End Get
        Set(ByVal value As Integer)
            ViewState("ReportType") = value
        End Set
    End Property
    Property CampaignID() As Integer
        Get
            Return ViewState("CampaignID")
        End Get
        Set(ByVal value As Integer)
            ViewState("CampaignID") = value
        End Set
    End Property

    Property AgentID() As String
        Get
            Return ViewState("AgentID")
        End Get
        Set(ByVal value As String)
            ViewState("AgentID") = value
        End Set
    End Property
#End Region
#Region "Load"
    Private Sub LoadData()
        FillCommonFilters()
        FillProcessCampaigns()
    End Sub
#End Region
#Region "Support function"
    Private Sub FillCommonFilters()
        Dim db As New DBAccess
        Dim dt As DataTable = db.ReturnTable("select * from tbl_Reports_DatePeriods")
        db = Nothing
        Dim dr As DataRow = dt.NewRow
        dr(0) = 10
        dr(1) = "Between"
        dt.Rows.Add(dr)
        CboPeriod.DataTextField = "Caption"
        CboPeriod.DataValueField = "Period"
        CboPeriod.DataSource = dt
        CboPeriod.DataBind()
    End Sub
    Private Sub FillProcessCampaigns()
        Common.FillCampaigns(cboCampaigns, AgentID)
        Dim lstcampaign As New ListItem
        lstcampaign.Value = 0
        lstcampaign.Text = "All"
        If cboCampaigns.Items.Contains(lstcampaign) Then
            cboCampaigns.Items.Remove(lstcampaign)
        End If
    End Sub
    Private Function IntegerToDateString(ByVal d As Integer) As String
        Return d.ToString.Substring(0, 4) & "-" & d.ToString.Substring(4, 2) & "-" & d.ToString.Substring(6, 2)
    End Function
    Private Sub ExportToexcel()
        Dim tw As New IO.StringWriter()
        Dim hw As New System.Web.UI.HtmlTextWriter(tw)
        Response.ContentType = "application/vnd.ms-excel"
        Response.AddHeader("content-disposition", "attachment;filename=" & lblReportName.Text & "-" & LblError.Text & ".xls")
        Response.Charset = ""
        EnableViewState = False
        GridView1.RenderControl(hw)
        Response.Write(tw.ToString())
        Response.End()
    End Sub
#End Region
#Region "Utility"

    Private Sub AlertMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMFail"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub

    Private Sub SuccessMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMSuccess"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub
#End Region
#Region "Grid Function"
    Private Sub fillgrid()

        'Dim db As New DBAccess("CRM")
        'db.slDataAdd("campaignid", CampaignID)
        'Dim obj As Object = db.ReturnValue("usp_getCurrentTime", True)   '''' return 1 or 0
        'db = Nothing

        Dim db As New DBAccess("CRM")
        db.slDataAdd("datefrom", "")
        db.slDataAdd("dateto", "")
        db.slDataAdd("campaignid", cboCampaigns.SelectedValue)
        db.slDataAdd("type", "currenttime") '''' ------change
        Dim obj As Object = db.ReturnValue("usp_getHKTLeadStatusReport", True)
        db = Nothing


        If obj Then
        Else
            LblError.Text = ""
            AlertMessage("You cannot fetch the report in production hours.")
            Exit Sub
        End If
        '-------------------------------------------------------------------------------------
        '-------------------------------------------------------------------------------------
        db = New DBAccess("CRM")
        db.slDataAdd("datefrom", "")
        db.slDataAdd("dateto", "")
        db.slDataAdd("campaignid", cboCampaigns.SelectedValue)
        db.slDataAdd("type", "timeperiod") '''' ------change
        Dim obj2 As Object = db.ReturnValue("usp_getHKTLeadStatusReport", True)
        db = Nothing


        If obj2 Then
        Else
            LblError.Text = ""
            AlertMessage("You cannot fetch the report for less than 3 months.")
            Exit Sub
        End If
        '-------------------------------------------------------------------------------------
        '-------------------------------------------------------------------------------------
        db = New DBAccess
        Dim startday As Integer, endday As Integer
        If CboPeriod.SelectedValue = 10 Then
            startday = ucDateFrom.yyyymmdd
            endday = UcDateTo.yyyymmdd
        Else
            db = New DBAccess
            db.slDataAdd("Period", CboPeriod.SelectedValue)
            db.slDataAdd("Campaignid", CampaignID)
            Dim dr As DataRow = db.ReturnRow("usp_GetStart_EndDateForAPeriod", True)
            db = Nothing
            startday = dr(0)
            endday = dr(1)
        End If
        lblReportName.Text = "HKT Calling Status Report"
        LblError.Text = "Between " & IntegerToDateString(startday) & "  and " & IntegerToDateString(endday) & " for " & cboCampaigns.SelectedItem.Text & " campaign"

        
        Try
            '''''---------------Option1 ------------------------------Start
            'db = New DBAccess("CRM")
            'Dim ds As New DataSet
            'db.slDataAdd("datefrom", startday)
            'db.slDataAdd("dateto", endday)
            'db.slDataAdd("campaignid", cboCampaigns.SelectedValue)
            'db.slDataAdd("type", "extra") '''' ------change

            'ds = db.ReturnDataset("usp_getHKTLeadStatusReport", True)
            'db = Nothing
            'GridView1.AutoGenerateColumns = True
            'ShowDataInGrid(ds)
            ''---------------Option1 -----------------------------End
            '---------------------------------------------------------------------------------
            '---------------------------------------------------------------------------------
            '---------------------------------------------------------------------------------
            ' ''---------------Option2 ----------------------------Start

            db = New DBAccess("CRM")
            db.slDataAdd("datefrom", startday)
            db.slDataAdd("dateto", endday)
            db.slDataAdd("campaignid", cboCampaigns.SelectedValue)
            db.slDataAdd("type", "daterange") '''' ------change
            Dim dtDateRange As DataTable = db.ReturnTable("usp_getHKTLeadStatusReport", , True)
            db = Nothing

            Dim col2 As DataColumn = New DataColumn("Total Leads Uploaded", System.Type.GetType("System.String"))
            dtDateRange.Columns.Add(col2)
            Dim col3 As DataColumn = New DataColumn("Total Leads Called", System.Type.GetType("System.String"))
            dtDateRange.Columns.Add(col3)
            Dim col4 As DataColumn = New DataColumn("Total Leads Not Called", System.Type.GetType("System.String"))
            dtDateRange.Columns.Add(col4)

            db = New DBAccess("CRM")
            db.slDataAdd("datefrom", startday)
            db.slDataAdd("dateto", endday)
            db.slDataAdd("campaignid", cboCampaigns.SelectedValue)
            db.slDataAdd("type", "leadtype") '''' ------change
            Dim dtLeadtype As DataTable = db.ReturnTable("usp_getHKTLeadStatusReport", , True)
            db = Nothing


            Dim arr() As DataRow
            If dtDateRange.Rows.Count > 0 Then
                For m As Integer = 0 To dtDateRange.Rows.Count - 1
                    arr = dtLeadtype.Select("vcleadbatch=" & dtDateRange.Rows(m).Item("day"))
                    If arr.Length > 0 Then

                        dtDateRange.Rows(m).Item("Total Leads Uploaded") = arr.CopyToDataTable.Rows(0)("Total Leads Uploaded")
                        dtDateRange.Rows(m).Item("Total Leads Called") = arr.CopyToDataTable.Rows(0)("Total Leads Called")
                        dtDateRange.Rows(m).Item("Total Leads Not Called") = arr.CopyToDataTable.Rows(0)("Total Leads Uploaded") - arr.CopyToDataTable.Rows(0)("Total Leads Called")
                    Else
                        dtDateRange.Rows(m).Item("Total Leads Uploaded") = 0
                        dtDateRange.Rows(m).Item("Total Leads Called") = 0
                        dtDateRange.Rows(m).Item("Total Leads Not Called") = 0
                    End If

                Next
            End If

            For j As Integer = 1 To 10
                Dim col As DataColumn = New DataColumn("Leads At Attempt Count " & j, System.Type.GetType("System.String"))
                dtDateRange.Columns.Add(col)
            Next

            If dtDateRange.Rows.Count > 0 Then
                For m As Integer = 0 To dtDateRange.Rows.Count - 1
                    db = New DBAccess("CRM")
                    db.slDataAdd("datefrom", dtDateRange.Rows(m).Item("day"))
                    db.slDataAdd("dateto", dtDateRange.Rows(m).Item("day"))   '--same date
                    db.slDataAdd("campaignid", cboCampaigns.SelectedValue)
                    db.slDataAdd("type", "attempt") '''' ------for attempts
                    Dim row As DataRow = db.ReturnRow("usp_getHKTLeadStatusReport", True)
                    db = Nothing

                    dtDateRange.Rows(m).Item("Leads At Attempt Count 1") = row("Leads At Attempt Count 1")
                    dtDateRange.Rows(m).Item("Leads At Attempt Count 2") = row("Leads At Attempt Count 2")
                    dtDateRange.Rows(m).Item("Leads At Attempt Count 3") = row("Leads At Attempt Count 3")
                    dtDateRange.Rows(m).Item("Leads At Attempt Count 4") = row("Leads At Attempt Count 4")
                    dtDateRange.Rows(m).Item("Leads At Attempt Count 5") = row("Leads At Attempt Count 5")

                    dtDateRange.Rows(m).Item("Leads At Attempt Count 6") = row("Leads At Attempt Count 6")
                    dtDateRange.Rows(m).Item("Leads At Attempt Count 7") = row("Leads At Attempt Count 7")
                    dtDateRange.Rows(m).Item("Leads At Attempt Count 8") = row("Leads At Attempt Count 8")
                    dtDateRange.Rows(m).Item("Leads At Attempt Count 9") = row("Leads At Attempt Count 9")
                    dtDateRange.Rows(m).Item("Leads At Attempt Count 10") = row("Leads At Attempt Count 10")

                Next
            End If

            GridView1.DataSource = dtDateRange
            GridView1.DataBind()
            ''---------------Option2 ----------------------------End
        Catch ex As Exception
            GridView1.DataSource = Nothing
            GridView1.DataBind()
        End Try
    End Sub


    Private Sub ShowDataInGrid(ByVal ds As DataSet)
        Dim dr() As DataRow = Nothing
        Try
            Dim dtFinal As DataTable = ds.Tables(0)
            Dim dtAttempts As DataTable = ds.Tables(1)

            If dtAttempts.Rows.Count > 0 Then
                For j As Integer = 0 To dtAttempts.Rows.Count - 1
                    If j = 0 Then  ''''for first row
                        dtAttempts.Rows(j).Item("NumOfAttemptsFinal") = dtAttempts.Rows(j).Item("NumOfAttempts")
                    Else
                        If dtAttempts.Rows(j).Item("CustomerID") = dtAttempts.Rows(j - 1).Item("CustomerID") Then
                            dtAttempts.Rows(j).Item("NumOfAttemptsFinal") = dtAttempts.Rows(j).Item("NumOfAttempts") + dtAttempts.Rows(j - 1).Item("NumOfAttemptsFinal")
                            'Note above formula
                        Else
                            dtAttempts.Rows(j).Item("NumOfAttemptsFinal") = dtAttempts.Rows(j).Item("NumOfAttempts")
                        End If
                    End If
                Next
                ''------------------------------------------------------------------
                ''------------------------------------------------------------------
                For m As Integer = 0 To dtFinal.Rows.Count - 1
                    For n As Integer = 1 To 10
                        dr = Nothing
                        dr = dtAttempts.Select("CalldateTime=" & dtFinal.Rows(m).Item("Date") & " AND " & "NumOfAttemptsFinal=" & n)
                        If dr.Length > 0 Then
                            dtFinal.Rows(m).Item("Leads At Attempt Count " & n) = dtAttempts.Select("CalldateTime=" & dtFinal.Rows(m).Item("Date") & " AND " & "NumOfAttemptsFinal=" & n).CopyToDataTable.Rows.Count
                        Else
                            dtFinal.Rows(m).Item("Leads At Attempt Count " & n) = 0
                        End If
                    Next
                    ' dtFinal.Rows(m).Item("Leads At Attempt Count 1")
                Next

                GridView1.DataSource = dtFinal.Select("", "Date ASC").CopyToDataTable
                GridView1.DataBind()
            End If
        Catch ex As Exception
            GridView1.DataSource = Nothing
            GridView1.DataBind()
        End Try

    End Sub

#End Region

#Region "Event"
    Protected Sub CboPeriod_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles CboPeriod.SelectedIndexChanged
        If CboPeriod.SelectedValue = 10 Then
            ucDateFrom.Visible = True
            UcDateTo.Visible = True
            lblAnd.Visible = True
            fillgrid()
        Else
            ucDateFrom.Visible = False
            UcDateTo.Visible = False
            lblAnd.Visible = False
            fillgrid()
        End If
    End Sub

    Protected Sub ImageButton1_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton1.Click
        fillgrid()
        GridViewExportUtil.Export(lblReportName.Text & "-" & LblError.Text & ".xls", Me.GridView1)
    End Sub

    Protected Sub imgfav_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles imgfav.Click
        Common.AddToFav(AgentID, "HKT Calling Status Report")
        SuccessMessage("Report has been added to your favourite list")
        fillgrid()
    End Sub
    Protected Sub cboCampaigns_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboCampaigns.SelectedIndexChanged
        fillgrid()
    End Sub
    Protected Sub btnRefresh_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnRefresh.Click
        fillgrid()
    End Sub
#End Region
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        HumanMessage.Style.Item("visibility") = "hidden"
        If Not IsPostBack Then
            If Session("AgentID") <> "" Then
                CampaignID = Session("CampaignID")
                AgentID = Session("AgentID")
                PanelReports.Controls.Add(Common.GetMenu(Request.Url, AgentID, Request.ApplicationPath))
                LoadData()
                fillgrid()
                UcDateTo.Visible = False
                ucDateFrom.Visible = False
                lblAnd.Visible = False
            End If
        End If
    End Sub



End Class
