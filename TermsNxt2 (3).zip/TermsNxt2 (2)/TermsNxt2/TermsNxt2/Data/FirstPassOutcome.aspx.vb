﻿Imports com.nss.DBAccess
Imports System.Data
Imports System.Text
Partial Class Data_FirstPassOutcome
    Inherits System.Web.UI.Page
#Region "Properties"

    Property ProcessID() As Integer
        Get
            Return ViewState("ProcessID")
        End Get
        Set(ByVal value As Integer)
            ViewState("ProcessID") = value
            Session("ProcessID") = value
        End Set
    End Property
    Property CampaignID() As Integer
        Get
            Return ViewState("CampaignID")
        End Get
        Set(ByVal value As Integer)
            ViewState("CampaignID") = value
        End Set
    End Property

    Property AgentID() As String
        Get
            Return ViewState("AgentID")
        End Get
        Set(ByVal value As String)
            ViewState("AgentID") = value
        End Set
    End Property
#End Region
    Private Sub LoadData()
        FillProcessCampaigns()
    End Sub
    Private Sub FillProcessCampaigns()
        Common.FillProcesses(CboProcess, AgentID)
        Dim lstprocess As New ListItem
        lstprocess.Value = 0
        lstprocess.Text = "All"
        If CboProcess.Items.Contains(lstprocess) Then
            CboProcess.Items.Remove(lstprocess)
        End If
        Dim db As New DBAccess
        db.slDataAdd("Agentid", AgentID)
        CboProcess.SelectedValue = db.ReturnRow("usp_getAgentProcess", True)(4)
        db = Nothing
        Common.FillCampaigns(cboCampaigns, AgentID, CboProcess.SelectedValue)
    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            If Session("AgentID") <> "" Then
                CampaignID = Session("CampaignID")
                AgentID = Session("AgentID")
                PanelReports.Controls.Add(Common.GetMenu(Request.Url, AgentID, Request.ApplicationPath))
                LoadData()
                FillCallTables()
                fillgrid()
            End If
        End If
    End Sub
    Private Sub fillgrid()

        Dim db As New DBAccess
        Dim startday As Integer, endday As Integer

        db = New DBAccess
        db.slDataAdd("Period", 5)
        db.slDataAdd("Campaignid", cboCampaigns.SelectedValue)
        Dim dr As DataRow = db.ReturnRow("usp_GetStart_EndDateForAPeriod", True)
        db = Nothing
        startday = dr(0)
        endday = dr(1)
        db = New DBAccess
        Dim dt As New DataTable
        If cboCallTable.SelectedValue <> "" Then

            db.slDataAdd("userid", AgentID)
            db.slDataAdd("startday", startday)
            db.slDataAdd("endDay", endday)
            db.slDataAdd("calltable", cboCallTable.SelectedValue)
            db.slDataAdd("campaignid", cboCampaigns.SelectedValue)
            db.slDataAdd("Processid", CboProcess.SelectedValue)
            dt = db.ReturnTable("usp_getFirstPassOutcome", , True)
        End If
       

        lblReportName.Text = "First Pass OutCome Summary"

        db = Nothing
        If dt.Rows.Count > 0 Then
            GridView1.DataSource = dt
            GridView1.DataBind()
        End If
        dt = Nothing
    End Sub
    Private Sub FillCallTables()
        cboCallTable.DataSource = Nothing
        Dim db As New DBAccess
        Dim dtcalltable As DataTable
        db.slDataAdd("userid", AgentID)
        db.slDataAdd("campaignid", cboCampaigns.SelectedValue)
        db.slDataAdd("Processid", CboProcess.SelectedValue)
        dtcalltable = db.ReturnTable("usp_getCallTables", , True)
        db = Nothing
        If dtcalltable.Rows.Count > 0 Then
            cboCallTable.DataTextField = "calltablename"
            cboCallTable.DataValueField = "calltablename"
            cboCallTable.DataSource = dtcalltable
            cboCallTable.DataBind()
        End If
        dtcalltable = Nothing
    End Sub

    Protected Sub CboProcess_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles CboProcess.SelectedIndexChanged
        ProcessID = CboProcess.SelectedValue
        Common.FillCampaigns(cboCampaigns, AgentID, CboProcess.SelectedValue)
        CampaignID = cboCampaigns.SelectedValue
        FillCallTables()
        fillgrid()
    End Sub

    Protected Sub cboCampaigns_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboCampaigns.SelectedIndexChanged
        CampaignID = cboCampaigns.SelectedValue
        FillCallTables()
        fillgrid()
    End Sub

    Protected Sub btnRefresh_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnRefresh.Click
        fillgrid()
    End Sub

    Protected Sub imgfav_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles imgfav.Click
        Common.AddToFav(AgentID, "First Pass OutCome")
        fillgrid()
    End Sub

    Protected Sub cboCallTable_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboCallTable.SelectedIndexChanged
        fillgrid()
    End Sub

    Protected Sub ImageButton1_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton1.Click
        fillgrid()
        GridViewExportUtil.Export(lblReportName.Text & ".xls", GridView1)
    End Sub
End Class
