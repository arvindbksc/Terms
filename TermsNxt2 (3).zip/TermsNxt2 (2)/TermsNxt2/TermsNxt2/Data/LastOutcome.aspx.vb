﻿Imports com.nss.DBAccess
Imports System.Data
Partial Class Data_CallHistoryReport
    Inherits System.Web.UI.Page
#Region "Properties"
    Property AgentID() As String
        Get
            Return ViewState("AgentID")
        End Get
        Set(ByVal value As String)
            ViewState("AgentID") = value
        End Set
    End Property
#End Region

#Region " --- Load ---"
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        HumanMessage.Style.Item("visibility") = "hidden"
        If Not IsPostBack Then
            If Session("AgentID") <> "" Then
                AgentID = Session("AgentID")
                PanelReports.Controls.Add(Common.GetMenu(Request.Url, AgentID, Request.ApplicationPath))
                'raj 1 17082011 Start
                FillCommonFilters()
                UcDateTo.Visible = False
                ucDateFrom.Visible = False
                lblAnd.Visible = False
                'raj 1 17082011 End

                Dim db As New DBAccess
                Dim curdate = db.ReturnValue("select getdate()", False)
                db = Nothing
                ucDateFrom.value = curdate
                UcDateTo.value = curdate
                FillCampaign()
                FillCallTable()
                GetData()
            End If

        End If
    End Sub
#End Region

#Region "---- Functions ----"

    Private Sub FillCampaign()
        Dim db As New DBAccess("CRM")
        Dim dtCampaign As New DataTable
        dtCampaign = db.ReturnTable("select CampaignId,Name from tbl_DHRISTI_CampaignMst where Active=1", False)
        db = Nothing
        Dim row As DataRow = dtCampaign.NewRow
        row.Item(0) = -1
        row.Item(1) = "ALL"
        dtCampaign.Rows.InsertAt(row, 0)
        cboCampaigns.Items.Clear()
        cboCampaigns.DataTextField = "Name"
        cboCampaigns.DataValueField = "CampaignID"
        cboCampaigns.DataSource = dtCampaign
        cboCampaigns.DataBind()
        dtCampaign = Nothing
    End Sub

    Private Sub FillCallTable()
        Dim campid, calltableid As Integer

        'raj 2 17082011 Start
        Dim db As DBAccess
        Dim startday As Integer, endday As Integer
        If CboPeriod.SelectedValue = 10 Then
            startday = ucDateFrom.yyyymmdd
            endday = UcDateTo.yyyymmdd
        Else
            db = New DBAccess("CRM")
            db.slDataAdd("Period", CboPeriod.SelectedValue)
            'db.slDataAdd("Campaignid", CampaignID)
            Dim dr As DataRow = db.ReturnRow("usp_GetStart_EndDateForAPeriod", True)
            db = Nothing
            startday = dr(0)
            endday = dr(1)
        End If
        'raj 2 17082011 End

        If IsPostBack Then
            campid = cboCampaigns.SelectedValue
            If cboCallTable.SelectedValue <> "" Then
                calltableid = cboCallTable.SelectedValue
            End If
        End If

        db = New DBAccess("CRM")
        Dim dtCallTable As DataTable

        'raj 3 17082011 Start
        'If cboCampaigns.SelectedValue = "-1" Or cboCampaigns.SelectedValue = "" Then
        '    dtCallTable = db.ReturnTable("SELECT cl.*,c.Name FROM tbl_DHRISTI_CallTableMst cl inner join tbl_DHRISTI_CampaignMst c on c.CampaignId =cl.CampaignId WHERE convert(varchar,startdate,112) between '" & ucDateFrom.yyyymmdd & "' and '" & ucDateTo.yyyymmdd & "'  ORDER BY cl.CampaignId,CallTableID", , False)
        'Else
        '    dtCallTable = db.ReturnTable("SELECT cl.*,c.Name FROM tbl_DHRISTI_CallTableMst cl inner join tbl_DHRISTI_CampaignMst c on c.CampaignId =cl.CampaignId WHERE convert(varchar,startdate,112) between '" & ucDateFrom.yyyymmdd & "' and '" & ucDateTo.yyyymmdd & "' and cl.campaignid=" & cboCampaigns.SelectedValue & " ORDER BY cl.CampaignId,CallTableID", , False)
        'End If

        If cboCampaigns.SelectedValue = "-1" Or cboCampaigns.SelectedValue = "" Then
            dtCallTable = db.ReturnTable("SELECT cl.*,c.Name FROM tbl_DHRISTI_CallTableMst cl inner join tbl_DHRISTI_CampaignMst c on c.CampaignId =cl.CampaignId WHERE convert(varchar,startdate,112) between '" & startday & "' and '" & endday & "'  ORDER BY cl.CampaignId,CallTableID", , False)
        Else
            dtCallTable = db.ReturnTable("SELECT cl.*,c.Name FROM tbl_DHRISTI_CallTableMst cl inner join tbl_DHRISTI_CampaignMst c on c.CampaignId =cl.CampaignId WHERE convert(varchar,startdate,112) between '" & startday & "' and '" & endday & "' and cl.campaignid=" & cboCampaigns.SelectedValue & " ORDER BY cl.CampaignId,CallTableID", , False)
        End If
        'raj 3 17082011 End

        db = Nothing
        cboCallTable.DataSource = dtCallTable
        cboCallTable.DataTextField = "CallTableName"
        cboCallTable.DataValueField = "CallTableID"
        cboCallTable.DataBind()

        '========= By Rajenda
        'Dim col() As String = {"Name", "CampaignID"}
        'Dim dtCampaign As DataTable = dtCallTable.DefaultView.ToTable(True, col)
        'Dim row As DataRow = dtCampaign.NewRow
        'row.Item(0) = "ALL"
        'row.Item(1) = -1
        'dtCampaign.Rows.InsertAt(row, 0)
        'cboCampaigns.Items.Clear()
        'cboCampaigns.DataTextField = "Name"
        'cboCampaigns.DataValueField = "CampaignID"
        'cboCampaigns.DataSource = dtCampaign
        'cboCampaigns.DataBind()
        If IsPostBack Then
            Try
                cboCampaigns.SelectedValue = campid
                cboCallTable.SelectedValue = calltableid
            Catch ex As Exception

            End Try

        End If
    End Sub
    Dim dtDisposition As DataTable
    Private Sub GetData()
        If cboCallTable.Items.Count > 0 Then
            gvCallHistoryReport.DataSource = Nothing
            Dim db As DBAccess

            db = New DBAccess("report")
            db.slDataAdd("callTableName", cboCallTable.SelectedItem.Text)
            dtDisposition = db.ReturnTable("usp_getCalltablewiseLastdisposition", , True)
            db = Nothing
            dtDisposition.Columns.Remove("CampaignID")
            dtDisposition.Columns.Remove("ID")
            dtDisposition.Columns.Remove("ResultCode")
            dtDisposition.Columns.Remove("AgentID")


            gvCallHistoryReport.DataSource = dtDisposition
            gvCallHistoryReport.DataBind()
        End If
    End Sub

    'raj 4 17082011 Start
    Private Sub FillCommonFilters()
        Dim db As New DBAccess
        Dim dt As DataTable = db.ReturnTable("select * from tbl_Reports_DatePeriods")
        db = Nothing
        Dim dr As DataRow = dt.NewRow
        dr(0) = 10
        dr(1) = "Between"
        dt.Rows.Add(dr)
        CboPeriod.DataTextField = "Caption"
        CboPeriod.DataValueField = "Period"
        CboPeriod.DataSource = dt
        CboPeriod.DataBind()
    End Sub
    'raj 4 17082011 End

#End Region

#Region " ---- Event ----"
    Protected Sub cboCampaigns_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboCampaigns.SelectedIndexChanged
        FillCallTable()
        GetData()
    End Sub
    Protected Sub btnRefresh_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnRefresh.Click
        FillCallTable()
        GetData()
    End Sub
    Protected Sub gvCallHistoryReport_PageIndexChanging(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewPageEventArgs) Handles gvCallHistoryReport.PageIndexChanging
        gvCallHistoryReport.PageIndex = e.NewPageIndex
        GetData()
    End Sub
    Protected Sub ImageButton1_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton1.Click
        GetData()
        Dim gv As New GridView
        gv.DataSource = dtDisposition
        gv.DataBind()
        GridViewExportUtil.Export(lblReportName.Text & ".xls", gv)
    End Sub

    Protected Sub cboCallTable_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboCallTable.SelectedIndexChanged
        GetData()
    End Sub

    'raj 5 17082011 Start
    Protected Sub CboPeriod_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles CboPeriod.SelectedIndexChanged
        'GetData()
        If CboPeriod.SelectedValue = 10 Then
            ucDateFrom.Visible = True
            UcDateTo.Visible = True
            lblAnd.Visible = True
            FillCallTable()
            GetData()
        Else
            ucDateFrom.Visible = False
            UcDateTo.Visible = False
            lblAnd.Visible = False
            FillCallTable()
            GetData()
        End If
    End Sub
    'raj 5 17082011 End
#End Region
#Region "Utility"

    Private Sub AlertMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMFail"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub

    Private Sub SuccessMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMSuccess"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub

    'Protected Sub ImageButton1_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton1.Click
    '    'fillgrid()
    '    GridViewExportUtil.Export(lblReportName.CurrentPage & "-" & LblError.Text & ".xls", Me.GdAttendance)
    'End Sub


    Public Overrides Sub VerifyRenderingInServerForm(ByVal Control As Control)

    End Sub

#End Region

    Protected Sub imgfav_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles imgfav.Click
        Common.AddToFav(AgentID, "Final Outcome Report")
        SuccessMessage("Report has been added to your favourite list")
        GetData()
    End Sub
End Class
