﻿Imports com.nss.DBAccess
Imports System.Data
Imports System.Text

Partial Class Analytics_SurveyRevenue
    Inherits System.Web.UI.Page
    Dim footerval(12) As Decimal
#Region "Properties"

    Property ReportType() As Integer
        Get
            Return ViewState("ReportType")
        End Get
        Set(ByVal value As Integer)
            ViewState("ReportType") = value
        End Set
    End Property
    Property CampaignID() As Integer
        Get
            Return ViewState("CampaignID")
        End Get
        Set(ByVal value As Integer)
            ViewState("CampaignID") = value
        End Set
    End Property

    Property AgentID() As String
        Get
            Return ViewState("AgentID")
        End Get
        Set(ByVal value As String)
            ViewState("AgentID") = value
        End Set
    End Property
#End Region

    Private Sub LoadData()
        FillCommonFilters()
        FillProcessCampaigns()
    End Sub

    Private Sub FillCommonFilters()
        Dim db As New DBAccess
        Dim dt As DataTable = db.ReturnTable("select * from tbl_Reports_DatePeriods")
        db = Nothing
        CboPeriod.DataTextField = "Caption"
        CboPeriod.DataValueField = "Period"
        CboPeriod.DataSource = dt
        CboPeriod.DataBind()
        db = New DBAccess
        dt = db.ReturnTable("Select Caption,ID from tbl_Reports_GroupBy")
        Dim dr As DataRow
        dr = dt.NewRow
        dr(0) = "Questions"
        dr(1) = 5
        dt.Rows.Add(dr)
        db = Nothing
        CboGroup.DataTextField = "Caption"
        CboGroup.DataValueField = "ID"
        CboGroup.DataSource = dt
        CboGroup.DataBind()


    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then

            ReportType = Request.QueryString("ReportType")
            If Session("AgentID") <> "" Then
                CampaignID = Session("CampaignID")
                AgentID = Session("AgentID")
                PanelReports.Controls.Add(Common.GetMenu(Request.Url, AgentID, Request.ApplicationPath))
                LoadData()
                fillgrid()

            End If
        End If
    End Sub

    Private Sub fillgrid()

        For Each obj In footerval
            obj = 0
        Next
        Dim columns As String
        Dim db As New DBAccess
        db.slDataAdd("Period", CboPeriod.SelectedValue)
        db.slDataAdd("Campaignid", CampaignID)

        Dim dr As DataRow = db.ReturnRow("usp_GetStart_EndDateForAPeriod", True)
        db = Nothing
        db = New DBAccess
        Dim dt As DataTable
        If ReportType = 0 Then
            db.slDataAdd("startday", dr(0))
            db.slDataAdd("endDay", dr(1))
            db.slDataAdd("campaignid", CampaignID)
            db.slDataAdd("groupBy", CboGroup.SelectedValue)
            'If cboFilterBy.SelectedItem.Text <> "None" And txtFilterValue.Text.Trim <> "" Then
            '    lblFilter.Text = "Filtered for " & cboFilterBy.SelectedItem.Text & " = " & txtFilterValue.Text
            '    If cboFilterBy.SelectedValue.Contains("String") Then
            '        'db.slDataAdd("Filterby", "'" & cboFilterBy.SelectedItem.Text & "'")
            '    End If
            '    db.slDataAdd("Filterby", cboFilterBy.SelectedItem.Text)
            '    db.slDataAdd("Filterbyvalue", txtFilterValue.Text)
            'End If
            dt = db.ReturnTable("usp_SurveyRevenue_Custom", , True)
            'Dim dtime As Date
            'dtime = dr(0).ToString
            lblReportName.Text = CboGroup.SelectedItem.Text & " wise Revenue Summary "
            LblError.Text = "Between " & IntegerToDateString(dr(0)) & "  and " & IntegerToDateString(dr(1)) & " for " & cboCampaigns.SelectedItem.Text & " campaign"
        Else
            columns = "*"
            Dim sqlstr As New StringBuilder
            sqlstr.Append("Select ")
            sqlstr.Append(columns)
            sqlstr.Append(" from tbl_Summary_Performance ")
            sqlstr.Append(" where [day] >= ")
            sqlstr.Append(dr(0))
            sqlstr.Append(" and [day]<= ")
            sqlstr.Append(dr(1))
            dt = db.ReturnTable(sqlstr.ToString)
        End If
        db = Nothing
        GridView1.AutoGenerateColumns = False
        CreateGridColumns(dt.Columns)
        GridView1.DataSource = dt
        GridView1.DataBind()
        'System.Threading.Thread.Sleep(100)

        db = New DBAccess
        db.slDataAdd("startday", dr(0))
        db.slDataAdd("endDay", dr(1))
        db.slDataAdd("campaignid", CampaignID)
        db.slDataAdd("groupBy", 0)
        dt = db.ReturnTable("usp_CampaignPerformanceTerms2", , True)
        If dt.Rows.Count > 0 Then
            If footerval(1) = 0 Or dt.Rows(0)("Login Duration") = 0 Then
                lblRevenueperHour.Text = "N.A."
            Else
                lblRevenueperHour.Text = Math.Round((footerval(1) / dt.Rows(0)("Login Duration")) * 3600, 2)
            End If
            If footerval(1) = 0 Or dt.Rows(0)("Completes") = 0 Then
                lblRevenueperComplete.Text = "N.A."
            Else
                lblRevenueperComplete.Text = Math.Round((footerval(1) / dt.Rows(0)("Completes")), 2)
            End If
            LblCompletes.Text = dt.Rows(0)("Completes")
            If dt.Rows(0)("Login Duration") = 0 Or dt.Rows(0)("Completes") = 0 Then
                lblCPH.Text = "N.A."
            Else
                lblCPH.Text = Math.Round((dt.Rows(0)("Completes") / dt.Rows(0)("Login Duration")) * 3600, 2)
            End If


        Else
            lblRevenueperHour.Text = "N.A."
            lblRevenueperComplete.Text = "N.A."
            ' lblLoginHrs.Text = "0"
            LblCompletes.Text = "0"
            lblCPH.Text = "N.A."
        End If
    End Sub
    Private Function IntegerToDateString(ByVal d As Integer) As String
        Return d.ToString.Substring(0, 4) & "-" & d.ToString.Substring(4, 2) & "-" & d.ToString.Substring(6, 2)
    End Function
    Private Sub CreateGridColumns(ByVal cols As DataColumnCollection)
        GridView1.Columns.Clear()
        Dim tempcolumn As TemplateField
        Dim bouncol As BoundField
        Dim objcol As DataColumn
        For Each objcol In cols
            If objcol.ColumnName = "Agents" Then
                tempcolumn = New TemplateField
                Dim tmpagcol As New TemplateAgentName
                tempcolumn.HeaderText = "Agents"
                tmpagcol.DataImageField = "AgentStatus"
                tmpagcol.DataTextField = objcol.ColumnName
                tempcolumn.ItemStyle.HorizontalAlign = HorizontalAlign.Left
                tempcolumn.ItemTemplate = tmpagcol
                GridView1.Columns.Add(tempcolumn)
            Else
                If objcol.ColumnName <> "Agentstatus" Then
                    bouncol = New BoundField
                    bouncol.HeaderText = objcol.ColumnName
                    bouncol.DataField = objcol.ColumnName


                    GridView1.Columns.Add(bouncol)
                End If

            End If

        Next
        'Dim MonthCols As BoundField

        'Dim ctr As Integer

        'For ictr As Integer = 0 To ctr
        '    tempcolumn = New TemplateColumn
        '    Dim tmp As New TemplateField

        '    'tempcolumn.ItemTemplate = 
        '    MonthCols = New BoundField
        '    MonthCols.HeaderText = "Month" & ictr + 1
        '    MonthCols.DataField = ""
        '    GridView1.Columns.Add(MonthCols)
        '    'Next

    End Sub
    Private Sub FillProcessCampaigns()
        Common.FillProcessCampaigns(CboProcess, cboCampaigns, AgentID, CampaignID)
    End Sub

    Protected Sub cboCampaigns_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboCampaigns.SelectedIndexChanged
        CampaignID = cboCampaigns.SelectedValue
        fillgrid()
        'Dim helper As GridViewHelper = New GridViewHelper(GridView1)
        'helper.RegisterGroup("Agents", True, True)
        'helper.ApplyGroupSort()
    End Sub

    Protected Sub CboPeriod_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles CboPeriod.SelectedIndexChanged
        fillgrid()
    End Sub


    Protected Sub GridView1_RowDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles GridView1.RowDataBound
        'Try


        'If e.Row.RowType = DataControlRowType.DataRow Then
        '    footerval(1) = footerval(1) + e.Row.Cells(1).Text 'Revenue
        '    footerval(2) = footerval(2) + e.Row.Cells(2).Text 'Positive count
        '    footerval(3) = footerval(3) + e.Row.Cells(3).Text 'Total Response



        '    footerval(0) += 1
        '    If e.Row.Cells(3).Text = 0 Then
        '        e.Row.Cells(4).Text = "N.A"
        '    Else
        '        e.Row.Cells(4).Text = Math.Round((e.Row.Cells(2).Text / e.Row.Cells(3).Text) * 100, 2)
        '    End If

        'ElseIf e.Row.RowType = DataControlRowType.Footer Then
        '    e.Row.Cells(0).Text = "Total: " & Math.Round(footerval(0), 0)
        '    e.Row.Cells(1).Text = Math.Round(footerval(1), 2)

        '    e.Row.Cells(2).Text = Math.Round(footerval(2), 0)
        '    e.Row.Cells(3).Text = Math.Round(footerval(3), 0)
        '    e.Row.Cells(4).Text = Common.TimeString(footerval(4))

        '    If footerval(3) = 0 Then
        '        e.Row.Cells(4).Text = "N.A" 'CPH
        '    Else
        '        e.Row.Cells(4).Text = Math.Round((footerval(2) / footerval(3)) * 100, 2) 'Fill Rate
        '    End If


        'End If
        ''Catch ex As Exception

        ''End Try
    End Sub

    Protected Sub ImageButton1_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton1.Click
        fillgrid()
        GridViewExportUtil.Export(lblReportName.Text & "-" & LblError.Text & ".xls", Me.GridView1)
    End Sub

    Private Sub ExportToexcel()
        Dim tw As New IO.StringWriter()
        Dim hw As New System.Web.UI.HtmlTextWriter(tw)
        'Dim frm As HtmlForm = New HtmlForm()
        Response.ContentType = "application/vnd.ms-excel"
        Response.AddHeader("content-disposition", "attachment;filename=" & lblReportName.Text & "-" & LblError.Text & ".xls")
        Response.Charset = ""
        EnableViewState = False
        'Controls.Add(frm)
        GridView1.RenderControl(hw)
        Response.Write(tw.ToString())
        Response.End()
    End Sub
    Public Overrides Sub VerifyRenderingInServerForm(ByVal Control As Control)

    End Sub


    Protected Sub CboGroup_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles CboGroup.SelectedIndexChanged
        fillgrid()
    End Sub

    Protected Sub btnFilter_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnFilter.Click
        fillgrid()
    End Sub

    Protected Sub btnRefresh_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnRefresh.Click
        fillgrid()
    End Sub
End Class
