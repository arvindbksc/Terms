﻿Imports com.nss.DBAccess
Imports System.Data
Imports System.Text
Partial Class Data_ABCAnalysis
    Inherits System.Web.UI.Page
    Dim footerval(12) As Decimal
#Region "Properties"

    Property ReportType() As Integer
        Get
            Return ViewState("ReportType")
        End Get
        Set(ByVal value As Integer)
            ViewState("ReportType") = value
        End Set
    End Property
    Property CampaignID() As Integer
        Get
            Return ViewState("CampaignID")
        End Get
        Set(ByVal value As Integer)
            ViewState("CampaignID") = value
        End Set
    End Property

    Property AgentID() As String
        Get
            Return ViewState("AgentID")
        End Get
        Set(ByVal value As String)
            ViewState("AgentID") = value
        End Set
    End Property

    Property RPHAvg() As Decimal
        Get
            Return ViewState("RPHavg")
        End Get
        Set(ByVal value As Decimal)
            ViewState("RPHavg") = value
        End Set
    End Property
    Property RPHMax() As Decimal
        Get
            Return ViewState("RPHMax")
        End Get
        Set(ByVal value As Decimal)
            ViewState("RPHMax") = value
        End Set
    End Property
    Property RPHMin() As Decimal
        Get
            Return ViewState("RPHMin")
        End Get
        Set(ByVal value As Decimal)
            ViewState("RPHMin") = value
        End Set
    End Property
#End Region
    Private Sub LoadData()
        FillCommonFilters()
    End Sub
    Private Sub FillCommonFilters()
        Dim db As New DBAccess
        Dim dt As DataTable = db.ReturnTable("select * from tbl_Reports_DatePeriods")
        db = Nothing
        Dim dr As DataRow = dt.NewRow
        dr(0) = 10
        dr(1) = "Between"
        dt.Rows.Add(dr)
        CboPeriod.DataTextField = "Caption"
        CboPeriod.DataValueField = "Period"
        CboPeriod.DataSource = dt
        CboPeriod.DataBind()
        db = New DBAccess
        dt = db.ReturnTable("Select Caption,ID from tbl_Reports_GroupBy")

        dr = dt.NewRow
        dr(0) = "Questions"
        dr(1) = 5
        dt.Rows.Add(dr)
        db = Nothing
    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        HumanMessage.Style.Item("visibility") = "hidden"
        If Not IsPostBack Then
            ReportType = Request.QueryString("ReportType")
            If Session("AgentID") <> "" Then
                CampaignID = Session("CampaignID")
                AgentID = Session("AgentID")
                PanelReports.Controls.Add(Common.GetMenu(Request.Url, AgentID, Request.ApplicationPath))
                LoadData()
                fillgrid()
                ucDatePicker1.Visible = False
                ucDatePicker2.Visible = False
                lblAnd.Visible = False
            End If
        End If
    End Sub
    Private Sub fillgrid()

        For Each obj In footerval
            obj = 0
        Next
        'Dim columns As String
        Dim db As DBAccess
        Dim startday As Integer, endday As Integer
        If CboPeriod.SelectedValue = 10 Then
            startday = ucDatePicker1.yyyymmdd
            endday = ucDatePicker2.yyyymmdd
        Else
            db = New DBAccess
            db.slDataAdd("Period", CboPeriod.SelectedValue)
            db.slDataAdd("Campaignid", CampaignID)
            Dim dr As DataRow = db.ReturnRow("usp_GetStart_EndDateForAPeriod", True)
            db = Nothing
            startday = dr(0)
            endday = dr(1)
        End If


        db = New DBAccess
        Dim dt As DataTable

        db.slDataAdd("startday", startday)
        db.slDataAdd("endDay", endday)
        'db.slDataAdd("campaignid", CampaignID)
        db.slDataAdd("groupBy", 1)
        dt = db.ReturnTable("[usp_ABCAnalysis]", , True)
        lblReportName.Text = "ABC Analysis"
        LblError.Text = "Between " & IntegerToDateString(startday) & "  and " & IntegerToDateString(endday) & " for Orion campaign"
        db = Nothing
        'dt.Columns(0).ColumnName = CboGroup.SelectedItem.Text
        gdabc.AutoGenerateColumns = False
        CreateGridColumns(dt.Columns)
        gdabc.DataSource = dt
        gdabc.DataBind()
        'gdabc.Columns(6).Visible = False
        'gdabc.Columns(0).ItemStyle.Width = 20
    End Sub
    Private Function IntegerToDateString(ByVal d As Integer) As String
        Return d.ToString.Substring(0, 4) & "-" & d.ToString.Substring(4, 2) & "-" & d.ToString.Substring(6, 2)
    End Function

    Private Sub CreateGridColumns(ByVal cols As DataColumnCollection)
        gdabc.Columns.Clear()
        Dim tempcolumn As TemplateField
        Dim bouncol As BoundField
        Dim objcol As DataColumn
        bouncol = New BoundField
        bouncol.HeaderText = "S.No."
        gdabc.Columns.Add(bouncol)
        For Each objcol In cols
            If objcol.ColumnName = "Agents" Then
                tempcolumn = New TemplateField
                Dim tmpagcol As New TemplateAgentName
                tempcolumn.HeaderText = "Agents"
                tmpagcol.DataImageField = "AgentStatus"
                tmpagcol.DataTextField = objcol.ColumnName
                tempcolumn.ItemStyle.HorizontalAlign = HorizontalAlign.Left
                tempcolumn.ItemTemplate = tmpagcol
                gdabc.Columns.Add(tempcolumn)
            Else
                If objcol.ColumnName <> "Agentstatus" Then

                    bouncol = New BoundField
                    bouncol.HeaderText = objcol.ColumnName
                    bouncol.DataField = objcol.ColumnName
                    If objcol.ColumnName = "CPH" Then
                        bouncol.DataFormatString = "{0:n}"
                    End If
                    gdabc.Columns.Add(bouncol)
                End If


            End If


        Next
       

    End Sub
    Protected Sub CboPeriod_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles CboPeriod.SelectedIndexChanged
        If CboPeriod.SelectedValue = 10 Then
            ucDatePicker1.Visible = True
            ucDatePicker2.Visible = True
            lblAnd.Visible = True
            fillgrid()
        Else
            ucDatePicker1.Visible = False
            ucDatePicker2.Visible = False
            lblAnd.Visible = False
            fillgrid()
        End If
    End Sub
    Private Sub ExportToexcel()
        Dim tw As New IO.StringWriter()
        Dim hw As New System.Web.UI.HtmlTextWriter(tw)
        'Dim frm As HtmlForm = New HtmlForm()
        Response.ContentType = "application/vnd.ms-excel"
        Response.AddHeader("content-disposition", "attachment;filename=" & lblReportName.Text & "-" & LblError.Text & ".xls")
        Response.Charset = ""
        EnableViewState = False
        'Controls.Add(frm)
        gdabc.RenderControl(hw)
        Response.Write(tw.ToString())
        Response.End()
    End Sub
    Protected Sub btnRefresh_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnRefresh.Click
        fillgrid()
    End Sub
    Protected Sub ImageButton1_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton1.Click
        fillgrid()
        GridViewExportUtil.Export(lblReportName.Text & "-" & LblError.Text & ".xls", Me.gdabc)
    End Sub
    Dim i As Integer = 1
    Protected Sub gdabc_RowDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles gdabc.RowDataBound
        If e.Row.RowType = DataControlRowType.DataRow Then
            e.Row.Cells(0).Text = i
            i += 1
            If e.Row.Cells(5).Text = "A" Then
                e.Row.Cells(5).BackColor = Drawing.Color.LightGreen
            ElseIf e.Row.Cells(5).Text = "B" Then
                e.Row.Cells(5).BackColor = Drawing.Color.LightYellow
            ElseIf e.Row.Cells(5).Text = "C" Then
                e.Row.Cells(5).BackColor = Drawing.Color.Pink
            ElseIf e.Row.Cells(5).Text = "N" Then
                e.Row.Cells(5).BackColor = Drawing.Color.LightBlue
            End If
        End If
        
    End Sub

    Protected Sub imgfav_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles imgfav.Click
        Common.AddToFav(AgentID, "ABC Analysis")
        SuccessMessage("Report has been added to your favourite list")
        fillgrid()
    End Sub
#Region "Utility"

    Private Sub AlertMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMFail"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub

    Private Sub SuccessMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMSuccess"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub

    'Protected Sub ImageButton1_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton1.Click
    '    'fillgrid()
    '    GridViewExportUtil.Export(lblReportName.CurrentPage & "-" & LblError.Text & ".xls", Me.GdAttendance)
    'End Sub


    Public Overrides Sub VerifyRenderingInServerForm(ByVal Control As Control)

    End Sub

#End Region
End Class
