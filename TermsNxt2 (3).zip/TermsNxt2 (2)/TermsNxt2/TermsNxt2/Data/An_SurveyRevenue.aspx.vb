﻿Imports com.nss.DBAccess
Imports System.Data
Imports System.Text

Partial Class Data_An_SurveyRevenue
    Inherits System.Web.UI.Page
    Dim footerval(12) As Decimal
#Region "Properties"

    Property ReportType() As Integer
        Get
            Return ViewState("ReportType")
        End Get
        Set(ByVal value As Integer)
            ViewState("ReportType") = value
        End Set
    End Property
    Property CampaignID() As Integer
        Get
            Return ViewState("CampaignID")
        End Get
        Set(ByVal value As Integer)
            ViewState("CampaignID") = value
        End Set
    End Property

    Property AgentID() As String
        Get
            Return ViewState("AgentID")
        End Get
        Set(ByVal value As String)
            ViewState("AgentID") = value
        End Set
    End Property

    Property RPHAvg() As Decimal
        Get
            Return ViewState("RPHavg")
        End Get
        Set(ByVal value As Decimal)
            ViewState("RPHavg") = value
        End Set
    End Property
    Property RPHMax() As Decimal
        Get
            Return ViewState("RPHMax")
        End Get
        Set(ByVal value As Decimal)
            ViewState("RPHMax") = value
        End Set
    End Property
    Property RPHMin() As Decimal
        Get
            Return ViewState("RPHMin")
        End Get
        Set(ByVal value As Decimal)
            ViewState("RPHMin") = value
        End Set
    End Property
#End Region

    Private Sub LoadData()
        FillCommonFilters()
        FillProcessCampaigns()
    End Sub

    Private Sub FillCommonFilters()
        Dim db As New DBAccess
        Dim dt As DataTable = db.ReturnTable("select * from tbl_Reports_DatePeriods")
        db = Nothing
        Dim dr As DataRow = dt.NewRow
        dr(0) = 10
        dr(1) = "Between"
        dt.Rows.Add(dr)
        CboPeriod.DataTextField = "Caption"
        CboPeriod.DataValueField = "Period"
        CboPeriod.DataSource = dt
        CboPeriod.DataBind()
        db = New DBAccess
        dt = db.ReturnTable("Select Caption,ID from tbl_Reports_GroupBy")

        dr = dt.NewRow
        dr(0) = "Questions"
        dr(1) = 5
        dt.Rows.Add(dr)
        dr = dt.NewRow
        dr(0) = "PostCode"
        dr(1) = 6
        dt.Rows.Add(dr)
        db = Nothing
        CboGroup.DataTextField = "Caption"
        CboGroup.DataValueField = "ID"
        CboGroup.DataSource = dt
        CboGroup.DataBind()
        Dim ictr As Integer
        'For ictr = 1 To 31
        '    fromday.Items.Add(ictr)
        '    today.Items.Add(ictr)
        'Next
        'For ictr = 1 To 12
        '    frommonth.Items.Add(ictr)
        '    tomonth.Items.Add(ictr)
        'Next
        'For ictr = 2004 To 2011
        '    fromyear.Items.Add(ictr)
        '    toyear.Items.Add(ictr)
        'Next




    End Sub
    Private Sub FillAdvanceFilter()

        'Dim db As New DBAccess
        'Dim dt As DataTable = db.ReturnTable("select  AgentID from tbl_summary_Performance where  campaignid=" & CampaignID & " group by agentid")
        'cboFilterValue.DataTextField = "AgentID"
        'cboFilterValue.DataValueField = "AgentID"
        'cboFilterValue.DataSource = dt
        'cboFilterValue.DataBind()
        'cboFilterValue.SelectedIndex = -1
    End Sub
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then

            ReportType = Request.QueryString("ReportType")
            If Session("AgentID") <> "" Then
                CampaignID = Session("CampaignID")
                AgentID = Session("AgentID")
                PanelReports.Controls.Add(Common.GetMenu(Request.Url, AgentID, Request.ApplicationPath))
                LoadData()
                fillgrid()
                ucDatePicker1.Visible = False
                ucDatePicker2.Visible = False
                lblAnd.Visible = False
            End If
        End If
    End Sub

    Private Sub fillgrid()

        For Each obj In footerval
            obj = 0
        Next
        Dim columns As String
        Dim db As DBAccess
        Dim startday As Integer, endday As Integer
        If CboPeriod.SelectedValue = 10 Then
            startday = ucDatePicker1.yyyymmdd
            endday = ucDatePicker2.yyyymmdd
        Else
            db = New DBAccess
            db.slDataAdd("Period", CboPeriod.SelectedValue)
            db.slDataAdd("Campaignid", CampaignID)
            Dim dr As DataRow = db.ReturnRow("usp_GetStart_EndDateForAPeriod", True)
            db = Nothing
            startday = dr(0)
            endday = dr(1)
        End If


        db = New DBAccess
        Dim dt As DataTable

        db.slDataAdd("startday", startday)
        db.slDataAdd("endDay", endday)
        db.slDataAdd("campaignid", CampaignID)
        db.slDataAdd("groupBy", CboGroup.SelectedValue)
        'If cboFilterBy.SelectedItem.Text <> "None" And cboFilterValue.SelectedIndex >= 0 Then
        '    lblFilter.Text = "Filtered for " & cboFilterBy.SelectedItem.Text & " = " & cboFilterValue.SelectedItem.Text
        '    If cboFilterBy.SelectedValue.Contains("String") Then
        '        'db.slDataAdd("Filterby", "'" & cboFilterBy.SelectedItem.Text & "'")
        '    End If
        '    db.slDataAdd("Filterby", cboFilterBy.SelectedItem.Text)
        '    db.slDataAdd("Filterbyvalue", cboFilterValue.SelectedValue)
        'End If
        dt = db.ReturnTable("[usp_Survey_Analysis_new]", , True)
        'Dim dtime As Date
        'dtime = dr(0).ToString
        lblReportName.Text = CboGroup.SelectedItem.Text & " wise Revenue Summary "
        LblError.Text = "Between " & IntegerToDateString(startday) & "  and " & IntegerToDateString(endday) & " for " & cboCampaigns.SelectedItem.Text & " campaign"
        If CboGroup.SelectedValue = 1 Then
            RPHAvg = dt.Compute("sum(Revenue)/sum([login duration])", "") * 3600
            RPHMax = dt.Compute("max(Rph)", "")
            RPHMin = dt.Compute("min(Rph)", "")
            RPHMax = (RPHMax + RPHAvg) / 2
            RPHMin = (RPHMin + RPHAvg) / 2

        End If

        db = Nothing
        dt.Columns(0).ColumnName = CboGroup.SelectedItem.Text
        GridView1.AutoGenerateColumns = False
        CreateGridColumns(dt.Columns)
        GridView1.DataSource = dt
        GridView1.DataBind()



    End Sub
    Private Function IntegerToDateString(ByVal d As Integer) As String
        Return d.ToString.Substring(0, 4) & "-" & d.ToString.Substring(4, 2) & "-" & d.ToString.Substring(6, 2)
    End Function
    Private Sub CreateGridColumns(ByVal cols As DataColumnCollection)
        GridView1.Columns.Clear()
        Dim tempcolumn As TemplateField
        Dim bouncol As BoundField
        Dim objcol As DataColumn
        For Each objcol In cols
            If objcol.ColumnName = "Agents" Then
                tempcolumn = New TemplateField
                Dim tmpagcol As New TemplateAgentName
                tempcolumn.HeaderText = "Agents"
                tmpagcol.DataImageField = "AgentStatus"
                tmpagcol.DataTextField = objcol.ColumnName
                tempcolumn.ItemStyle.HorizontalAlign = HorizontalAlign.Left
                tempcolumn.ItemTemplate = tmpagcol
                GridView1.Columns.Add(tempcolumn)
            Else
                If objcol.ColumnName <> "Agentstatus" Then
                    
                    bouncol = New BoundField
                    bouncol.HeaderText = objcol.ColumnName
                    bouncol.DataField = objcol.ColumnName
                    If objcol.ColumnName = "CPH" Then
                        bouncol.DataFormatString = "{0:n}"
                    End If
                    GridView1.Columns.Add(bouncol)
                End If


                End If


        Next
        'Dim MonthCols As BoundField

        'Dim ctr As Integer

        'For ictr As Integer = 0 To ctr
        '    tempcolumn = New TemplateColumn
        '    Dim tmp As New TemplateField

        '    'tempcolumn.ItemTemplate = 
        '    MonthCols = New BoundField
        '    MonthCols.HeaderText = "Month" & ictr + 1
        '    MonthCols.DataField = ""
        '    GridView1.Columns.Add(MonthCols)
        '    'Next

    End Sub
    Private Sub FillProcessCampaigns()
        Common.FillProcessCampaigns(CboProcess, cboCampaigns, AgentID, CampaignID)
        CampaignID = cboCampaigns.SelectedValue
        FillAdvanceFilter()
    End Sub

    Protected Sub cboCampaigns_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboCampaigns.SelectedIndexChanged
        CampaignID = cboCampaigns.SelectedValue
        FillAdvanceFilter()
        fillgrid()
        'Dim helper As GridViewHelper = New GridViewHelper(GridView1)
        'helper.RegisterGroup("Agents", True, True)
        'helper.ApplyGroupSort()
    End Sub

    Protected Sub CboPeriod_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles CboPeriod.SelectedIndexChanged
        If CboPeriod.SelectedValue = 10 Then
            ucDatePicker1.Visible = True
            ucDatePicker2.Visible = True
            lblAnd.Visible = True
            fillgrid()
        Else
            ucDatePicker1.Visible = False
            ucDatePicker2.Visible = False
            lblAnd.Visible = False
            fillgrid()
        End If

    End Sub


    Protected Sub GridView1_RowDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles GridView1.RowDataBound
        Try


            If e.Row.RowType = DataControlRowType.DataRow Then
                footerval(0) += 1
                footerval(1) = footerval(1) + e.Row.Cells(1).Text 'Revenue
                footerval(2) = footerval(2) + e.Row.Cells(2).Text 'Positive count
                footerval(3) = footerval(3) + e.Row.Cells(3).Text 'Total Response
                If CboGroup.SelectedValue < 5 Then
                    footerval(4) = footerval(4) + e.Row.Cells(4).Text 'Login duration
                    footerval(5) = footerval(5) + e.Row.Cells(5).Text 'Completes
                End If




                If CboGroup.SelectedValue < 5 Then
                    'Fillrate
                    If e.Row.Cells(3).Text = 0 Then
                        e.Row.Cells(6).Text = "N.A"
                    Else
                        e.Row.Cells(6).Text = Math.Round((e.Row.Cells(2).Text / e.Row.Cells(3).Text) * 100, 2)
                    End If

                    'CPH
                    If e.Row.Cells(4).Text = 0 Then
                        e.Row.Cells(7).Text = "N.A"
                    Else
                        e.Row.Cells(7).Text = Math.Round((e.Row.Cells(5).Text / e.Row.Cells(4).Text) * 3600, 2)
                    End If
                    'RPH
                    If e.Row.Cells(4).Text = 0 Then
                        e.Row.Cells(8).Text = "N.A"
                    Else
                        e.Row.Cells(8).Text = Math.Round((e.Row.Cells(1).Text / e.Row.Cells(4).Text) * 3600.0, 2)
                        If CboGroup.SelectedValue = 1 Then
                            If (e.Row.Cells(8).Text > RPHMax) Then
                                e.Row.Cells(8).BackColor = Drawing.Color.Green
                                e.Row.Cells(8).ForeColor = Drawing.Color.White
                            ElseIf e.Row.Cells(8).Text < RPHMin Then
                                e.Row.Cells(8).BackColor = Drawing.Color.Red
                                e.Row.Cells(8).ForeColor = Drawing.Color.White

                            End If

                            'e.Row.Cells(8).BackColor = IIf(e.Row.Cells(8).Text > RPHMax, Drawing.Color.Green, IIf(e.Row.Cells(8).Text < RPHMin, Drawing.Color.Red, Drawing.Color.White))
                            'e.Row.Cells(8).ForeColor = IIf(e.Row.Cells(8).Text > RPHMax, Drawing.Color.White, IIf(e.Row.Cells(8).Text < RPHMin, Drawing.Color.White, Drawing.Color.Black))

                        End If
                    End If
                    'PPC
                    If e.Row.Cells(5).Text = 0 Then
                        e.Row.Cells(9).Text = "N.A"
                    Else
                        e.Row.Cells(9).Text = Math.Round((e.Row.Cells(1).Text / e.Row.Cells(5).Text), 2)
                    End If
                    e.Row.Cells(4).Text = Common.TimeString(e.Row.Cells(4).Text)
                Else
                    'Fillrate
                    If e.Row.Cells(3).Text = 0 Then
                        e.Row.Cells(4).Text = "N.A"
                    Else
                        e.Row.Cells(4).Text = Math.Round((e.Row.Cells(2).Text / e.Row.Cells(3).Text) * 100, 2)
                    End If
                End If


            ElseIf e.Row.RowType = DataControlRowType.Footer Then
                e.Row.Cells(0).Text = "Total: " & Math.Round(footerval(0), 0)
                e.Row.Cells(1).Text = Math.Round(footerval(1), 2)

                e.Row.Cells(2).Text = Math.Round(footerval(2), 0)
                e.Row.Cells(3).Text = Math.Round(footerval(3), 0)
                If CboGroup.SelectedValue < 5 Then
                    e.Row.Cells(4).Text = Common.TimeString(footerval(4))
                    e.Row.Cells(5).Text = Math.Round(footerval(5), 0)

                    'Fillrate
                    If footerval(3) = 0 Then
                        e.Row.Cells(6).Text = "N.A"
                    Else
                        e.Row.Cells(6).Text = Math.Round((footerval(2) / footerval(3)) * 100, 2) 'Fill Rate
                    End If

                    'CPH
                    If footerval(4) = 0 Then
                        e.Row.Cells(7).Text = "N.A"
                    Else
                        e.Row.Cells(7).Text = Math.Round((e.Row.Cells(5).Text / footerval(4)) * 3600, 2)
                    End If
                    'RPH
                    If footerval(4) = 0 Then
                        e.Row.Cells(8).Text = "N.A"
                    Else
                        e.Row.Cells(8).Text = Math.Round((e.Row.Cells(1).Text / footerval(4)) * 3600.0, 2)
                    End If
                    'PPC
                    If e.Row.Cells(5).Text = 0 Then
                        e.Row.Cells(9).Text = "N.A"
                    Else
                        e.Row.Cells(9).Text = Math.Round((e.Row.Cells(1).Text / e.Row.Cells(5).Text), 2)
                    End If
                Else
                    'Fillrate
                    If footerval(3) = 0 Then
                        e.Row.Cells(4).Text = "N.A"
                    Else
                        e.Row.Cells(4).Text = Math.Round((footerval(2) / footerval(3)) * 100, 2) 'Fill Rate
                    End If
                End If
            End If
        Catch ex As Exception

        End Try
    End Sub

    Protected Sub ImageButton1_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton1.Click
        fillgrid()
        GridViewExportUtil.Export(lblReportName.Text & "-" & LblError.Text & ".xls", Me.GridView1)
    End Sub

    Private Sub ExportToexcel()
        Dim tw As New IO.StringWriter()
        Dim hw As New System.Web.UI.HtmlTextWriter(tw)
        'Dim frm As HtmlForm = New HtmlForm()
        Response.ContentType = "application/vnd.ms-excel"
        Response.AddHeader("content-disposition", "attachment;filename=" & lblReportName.Text & "-" & LblError.Text & ".xls")
        Response.Charset = ""
        EnableViewState = False
        'Controls.Add(frm)
        GridView1.RenderControl(hw)
        Response.Write(tw.ToString())
        Response.End()
    End Sub
    Public Overrides Sub VerifyRenderingInServerForm(ByVal Control As Control)

    End Sub


    Protected Sub CboGroup_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles CboGroup.SelectedIndexChanged
        fillgrid()
    End Sub

    'Protected Sub btnFilter_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnFilter.Click
    '    fillgrid()
    'End Sub

    Protected Sub btnRefresh_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnRefresh.Click
        fillgrid()
    End Sub

    Protected Sub ucDatePicker1_Changed(ByVal sender As Object, ByVal e As System.EventArgs) Handles ucDatePicker1.Changed
        fillgrid()
    End Sub

    Protected Sub ucDatePicker2_Changed(ByVal sender As Object, ByVal e As System.EventArgs) Handles ucDatePicker2.Changed
        fillgrid()
    End Sub
End Class
