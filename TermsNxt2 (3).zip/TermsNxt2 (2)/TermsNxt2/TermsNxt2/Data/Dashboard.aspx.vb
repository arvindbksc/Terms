﻿Imports com.nss.DBAccess
Imports System.Data
Partial Class Dashboard
    Inherits System.Web.UI.Page
    Property CampaignID() As Integer
        Get
            Return Session("CampaignID")
        End Get
        Set(ByVal value As Integer)
            Session("CampaignID") = value
        End Set
    End Property
    
    Property AgentID() As String
        Get
            Return ViewState("AgentID")
        End Get
        Set(ByVal value As String)
            ViewState("AgentID") = value
        End Set
    End Property
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            'If Session("AgentID") <> "" Then
            CampaignID = Session("CampaignID")
            AgentID = Session("AgentID")
            'End If
            FillProcessCampaigns()
            'FillSummary()
            'FillGraph()
            Fillmenu()
        End If


    End Sub
    
    Protected Sub cboCampaigns_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboCampaigns.SelectedIndexChanged
        CampaignID = cboCampaigns.SelectedValue
        'FillSummary()

    End Sub
    Private Sub FillProcessCampaigns()
        Common.FillProcessCampaigns(CboProcess, cboCampaigns, AgentID, CampaignID)

    End Sub

    Private Sub Fillmenu()
       


        

    End Sub
    'Private Sub FillSummary()
    '    Dim db As New DBAccess
    '    db.slDataAdd("CampaignID", CampaignID)
    '    Dim dt As DataTable = db.ReturnTable("usp_DailyDashboardSummary", , True)
    '    If dt.Rows.Count > 0 Then
    '        lblNoofAgents.Text = dt.Rows(0)("loggedin")
    '        lblNoofAgentsonbreak.Text = dt.Rows(0)("onbreak")
    '    Else
    '        lblNoofAgents.Text = "0"
    '        lblNoofAgentsonbreak.Text = "0"
    '    End If
    '    db = Nothing
    '    db = New DBAccess

    '    db.slDataAdd("Period", 0)
    '    db.slDataAdd("Campaignid", CampaignID)

    '    Dim dr As DataRow = db.ReturnRow("usp_GetStart_EndDateForAPeriod", True)
    '    db = Nothing
    '    db = New DBAccess
    '    db.slDataAdd("startday", dr(0))
    '    db.slDataAdd("endDay", dr(1))
    '    db.slDataAdd("campaignid", CampaignID)
    '    db.slDataAdd("groupBy", 3)
    '    dt = db.ReturnTable("usp_CampaignPerformanceTerms2", , True)
    '    If dt.Rows.Count > 0 Then
    '        lblLoginHrs.Text = Common.TimeString(dt.Rows(0)("Login Duration"))
    '        LblCompletes.Text = dt.Rows(0)("Completes")
    '        If dt.Rows(0)("Login Duration") = 0 Or dt.Rows(0)("Completes") = 0 Then
    '            lblCPH.Text = "N.A."
    '        Else
    '            lblCPH.Text = Math.Round((dt.Rows(0)("Completes") / dt.Rows(0)("Login Duration")) * 3600, 2)
    '        End If


    '    Else
    '        lblNoofAgents.Text = "0"
    '        lblNoofAgentsonbreak.Text = "0"
    '        lblLoginHrs.Text = "0"
    '        LblCompletes.Text = "0"
    '        lblCPH.Text = "N.A."
    '    End If
    'End Sub

    'Protected Sub Timer1_Tick(ByVal sender As Object, ByVal e As System.EventArgs) Handles Timer1.Tick
    '    FillSummary()

    'End Sub
End Class
