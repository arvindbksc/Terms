﻿Imports com.nss.DBAccess
Imports System.Data
Imports System.Text
Partial Class Data_OvertimeReport
    Inherits System.Web.UI.Page

    Dim startday As Integer, endday As Integer
    Dim totalLoginHours As Integer, TotalOvertime As Integer

#Region "--- Properties ---"
    Property AgentID() As String
        Get
            Return ViewState("AgentID")
        End Get
        Set(ByVal value As String)
            ViewState("AgentID") = value
        End Set
    End Property
    Property CampaignID() As String
        Get
            Return ViewState("CampaignID")
        End Get
        Set(ByVal value As String)
            ViewState("CampaignID") = value
        End Set
    End Property

    'Property startday() As Integer
    '    Get
    '        Return ViewState("startday")
    '    End Get
    '    Set(ByVal value As Integer)
    '        ViewState("startday") = value
    '    End Set
    'End Property

    'Property endday() As Integer
    '    Get
    '        Return ViewState("endday")
    '    End Get
    '    Set(ByVal value As Integer)
    '        ViewState("endday") = value
    '    End Set
    'End Property

#End Region

#Region "--- Page Load ---"
    Private Sub LoadData()
        FillCommonFilters()
        FillCampaigns()
    End Sub
    Private Sub FillCommonFilters()
        Dim db As New DBAccess
        Dim dt As DataTable = db.ReturnTable("select * from tbl_Reports_DatePeriods")
        db = Nothing

        For j As Integer = dt.Rows.Count - 1 To 0 Step -1
            dt.Rows.RemoveAt(j)
        Next

        Dim dr As DataRow = dt.NewRow
        dr(0) = 21
        dr(1) = "6th Day"
        dt.Rows.Add(dr)

        dr = dt.NewRow
        dr(0) = 22
        dr(1) = "22nd Day"
        dt.Rows.Add(dr)

        dr = dt.NewRow
        dr(0) = 10
        dr(1) = "Between"
        dt.Rows.Add(dr)

        CboPeriod.DataTextField = "Caption"
        CboPeriod.DataValueField = "Period"
        CboPeriod.DataSource = dt
        CboPeriod.DataBind()


        db = New DBAccess
        dt = db.ReturnTable("Select * from tbl_Reports_GroupBy")
        db = Nothing

    End Sub
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        HumanMessage.Style.Item("visibility") = "hidden"
        If Not IsPostBack Then
            If Session("AgentID") <> "" Then
                AgentID = Session("AgentID")
                CampaignID = Session("CampaignID")
                PanelReports.Controls.Add(Common.GetMenu(Request.Url, AgentID, Request.ApplicationPath))
                LoadData()
                fillGrid()
                UcDateTo.Visible = False
                ucDateFrom.Visible = False
                lblAnd.Visible = False
            End If
        End If
    End Sub
#End Region
#Region "--- Function ---"
    Private Sub fillGrid()
        totalLoginHours = 0
        TotalOvertime = 0

        Dim db As New DBAccess
        Dim ds As New DataSet
        Dim st, en As Integer

        If CboPeriod.SelectedValue = 10 Then
            startday = ucDateFrom.yyyymmdd
            endday = UcDateTo.yyyymmdd

            db.slDataAdd("startday", startday)
            db.slDataAdd("endday", endday)
        End If

        db.slDataAdd("CampaignID", cboCampaigns.SelectedValue)
        db.slDataAdd("slotName", CboPeriod.SelectedValue)
        ds = db.ReturnDataset("usp_GetOvertime", True)
        db = Nothing

        GridView1.DataSource = ds.Tables(0)
        GridView1.DataBind()

        st = ds.Tables(1).Rows(0).Item("startday")
        en = ds.Tables(1).Rows(0).Item("endday")
        startday = st
        endday = en

        lblReportName.Text = "Overtime Report Between " & IntegerToDateString(st) & "  and " & IntegerToDateString(en) & " for " & cboCampaigns.SelectedItem.Text & " campaign"
        ScriptManager.RegisterStartupScript(Me, Me.GetType(), "SortGrid", "$(function(){{$('#" & GridView1.ClientID & "').tablesorter({cancelSelection:true}); }});", True)
    End Sub
    Private Sub FillCampaigns()
        'Common.FillCampaigns(cboCampaigns, AgentID, 0, 0)
        Common.FillProcessCampaigns(CboProcess, cboCampaigns, AgentID, CampaignID)
        Dim lstCamp As New ListItem
        lstCamp.Value = 0
        lstCamp.Text = "All"
        If cboCampaigns.Items.Contains(lstCamp) Then
            cboCampaigns.Items.Remove(lstCamp)
        End If
    End Sub
    Private Function IntegerToDateString(ByVal d As Integer) As String
        Return d.ToString.Substring(0, 4) & "-" & d.ToString.Substring(4, 2) & "-" & d.ToString.Substring(6, 2)
    End Function
    Private Sub SummaryMail()
        Dim strMailBody As String = ""

        If GridView1.Rows.Count > 0 Then
            Dim sb As New StringBuilder()
            sb.AppendLine("<table border='1' cellpadding='1' cellspacing='0'>")
            sb.AppendLine("<tr><td><b>Agent Name</b></td><td><b>Total Login Hours</b></td><td><b>Overtime Hours</b></td></tr>")

            For Each row1 As GridViewRow In GridView1.Rows
                If row1.RowType = DataControlRowType.DataRow Then
                    sb.AppendLine("<tr><td>" & row1.Cells(1).Text & "</td><td>" & row1.Cells(2).Text & "</td><td>" & row1.Cells(3).Text & "</td></tr>")
                ElseIf row1.RowType = DataControlRowType.Footer Then
                    sb.AppendLine("<tr><td>" & row1.Cells(1).Text & "</td><td>" & row1.Cells(2).Text & "</td><td>" & row1.Cells(3).Text & "</td></tr>")
                End If
            Next

            sb.AppendLine("<tr><td><b>" & "Total:" & "</b></td><td>" & Common.TimeString(totalLoginHours) & "</td><td>" & Common.TimeString(TotalOvertime) & "</td></tr>")
            'For i As Integer = 0 To GridView1.FooterRow.Cells.Count - 1
            '    sb.AppendLine("<tr><td>" & cl(1).Text & "</td><td>" & cl(2).Text & "</td><td>" & cl(3).Text & "</td></tr>")
            'Next

            sb.AppendLine("</table>")

            strMailBody += "<html xmlns='http://www.w3.org/1999/xhtml'>"
            strMailBody += "<body style='font-family: Verdana; font-size: .8em'>"
            strMailBody = "<html><head><title></title></head><body>"
            strMailBody += "<b>Overtime Report from </b>" & startday.ToString().Substring(6, 2) & "-" & startday.ToString().Substring(4, 2) & "-" & startday.ToString().Substring(0, 4) & " to " & endday.ToString().Substring(6, 2) & "-" & endday.ToString().Substring(4, 2) & "-" & endday.ToString().Substring(0, 4) & "<br/><br/>"

            strMailBody += "<b> Approved By:</b>" & Session("Username") & "(" & Session("AgentID") & ")" & "<br/><br/>"

            strMailBody += sb.ToString
            ' strMailBody += "<br />To see more detailed reports on Terms ® please click <a href='http://termsmonitor.niitsmartserve.com/perfsum/CampaignSummaryVoice.aspx?campaign=0'>here</a> ."

            strMailBody += "<br/><br/><HR />"
            strMailBody += "This is a system generated mail. We request you not to reply to this message.<br/>"
            strMailBody += "This e-mail is confidential and may also be privileged.If you are not the intended recipient, please notify 'helpdesk@coforge.com' "
            strMailBody += "immediately; you should not copy or use it for any purpose,nor disclose its contents to any other person.<br/>"
            strMailBody += "<hr/>"
            strMailBody += "</body></html>"


            Dim db As New DBAccess
            db.slDataAdd("applicationName", "orion overtime")
            Dim drow As DataRow = db.ReturnRow("usp_getApplicationEmails", True)
            db = Nothing


            Dim strTo As String = drow("MailTo").ToString
            Dim strCC As String = drow("MailCC").ToString
            Dim strBCC As String = drow("MailBcc").ToString

            Dim objWSMail As New ServiceReference1.Service1SoapClient
            objWSMail.MailSend(strTo, "Overtime Report", "TermsMonitor@corforgetech.com", "TermsMonitor", strMailBody, "", strCC, strBCC)
            objWSMail = Nothing

        End If

    End Sub
    Private Sub ShooterrorMail(ByVal ex As Exception)
        Dim strMailSubject As String = "Error Overtime Report"
        Dim strBody As String = ""
        strBody = "<FONT face=Tahoma size=2>Hi , <BR><BR> Following error has been encountered: <br><br>"
        strBody &= ex.ToString & "</table>"
        strBody &= "<p>This is a system generated alert. We request you not to reply to this message.<BR><BR><HR>This e-mail is confidential and may also be privileged.<HR></Font></P>"

        Dim objWSMail As New ServiceReference1.Service1SoapClient
        objWSMail.MailSend(System.Configuration.ConfigurationManager.AppSettings("OverTimeTo"), "Overtime Report", "TermsMonitor@corforgetech.com", "TermsMonitor", strBody, "", System.Configuration.ConfigurationManager.AppSettings("OverTimeCC"), System.Configuration.ConfigurationManager.AppSettings("OverTimeBCC"))
        objWSMail = Nothing

    End Sub

#End Region
#Region "--- Event ---"
    Protected Sub btnRefresh_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnRefresh.Click
        fillGrid()
    End Sub
    Protected Sub ImageButton1_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton1.Click
        fillGrid()
        GridViewExportUtil.Export(lblReportName.Text & ".xls", Me.GridView1)
    End Sub
    Protected Sub CboPeriod_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles CboPeriod.SelectedIndexChanged
        If CboPeriod.SelectedValue = 10 Then
            ucDateFrom.Visible = True
            UcDateTo.Visible = True
            lblAnd.Visible = True
        Else
            ucDateFrom.Visible = False
            UcDateTo.Visible = False
            lblAnd.Visible = False
            fillGrid()
        End If
    End Sub
    Protected Sub imgfav_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles imgfav.Click
        Common.AddToFav(AgentID, "Overtime Report")
        SuccessMessage("Report has been added to your favourite list")
        fillGrid()
    End Sub
    Protected Sub cboCampaigns_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboCampaigns.SelectedIndexChanged
        fillGrid()
    End Sub
    Protected Sub GridView1_RowDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles GridView1.RowDataBound
        If e.Row.RowType = DataControlRowType.DataRow Then
            totalLoginHours += e.Row.Cells(2).Text
            e.Row.Cells(2).Text = Common.TimeString(e.Row.Cells(2).Text)

            TotalOvertime += e.Row.Cells(3).Text
            e.Row.Cells(3).Text = Common.TimeString(e.Row.Cells(3).Text)
        End If

        If e.Row.RowType = DataControlRowType.Footer Then
            e.Row.Cells(1).Text = "Total:"
            e.Row.Cells(2).Text = Common.TimeString(totalLoginHours)
            e.Row.Cells(3).Text = Common.TimeString(TotalOvertime)
        End If
    End Sub
    'Protected Sub btnApprove_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnApprove.Click
    '    fillGrid()
    '    If GridView1.Rows.Count > 0 Then
    '        SummaryMail()
    '    Else
    '        AlertMessage("There is no data to approve")
    '    End If
    'End Sub
    Protected Sub UcDateTo_Changed(ByVal sender As Object, ByVal e As System.EventArgs) Handles UcDateTo.Changed
        fillGrid()
    End Sub
    Protected Sub ucDateFrom_Changed(ByVal sender As Object, ByVal e As System.EventArgs) Handles ucDateFrom.Changed
        fillGrid()
    End Sub
#End Region

#Region "--- Utility ---"
    Private Sub AlertMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMFail"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub
    Private Sub SuccessMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMSuccess"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub
#End Region

End Class
