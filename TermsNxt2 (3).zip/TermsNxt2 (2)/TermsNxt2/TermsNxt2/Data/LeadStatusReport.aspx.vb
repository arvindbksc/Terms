﻿Imports com.nss.DBAccess
Imports System.Data
Partial Class Data_LeadStatusReport
    Inherits System.Web.UI.Page
#Region "Properties"

    Property AgentID() As String
        Get
            Return ViewState("AgentID")
        End Get
        Set(ByVal value As String)
            ViewState("AgentID") = value
        End Set
    End Property

    Property startday() As Integer
        Get
            Return ViewState("startday")
        End Get
        Set(ByVal value As Integer)
            ViewState("startday") = value
        End Set
    End Property

    Property endday() As Integer
        Get
            Return ViewState("endday")
        End Get
        Set(ByVal value As Integer)
            ViewState("endday") = value
        End Set
    End Property

#End Region
#Region "Load"
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            If Session("AgentID") <> "" Then
                AgentID = Session("AgentID")
                PanelReports.Controls.Add(Common.GetMenu(Request.Url, AgentID, Request.ApplicationPath))
                'raj 1 17082011 Start
                FillCommonFilters()
                UcDateTo.Visible = False
                ucDateFrom.Visible = False
                lblAnd.Visible = False
                'raj 1 17082011 End

                Dim db As New DBAccess
                Dim curdate = db.ReturnValue("select getdate()", False)
                db = Nothing
                ucDateFrom.value = curdate
                UcDateTo.value = curdate
                FillCampaign()
                FillCallTable()
                GetData()
            End If
            
        End If
    End Sub

    Private Sub FillCampaign()
        Dim db As New DBAccess("CRM")
        Dim dtCampaign As New DataTable
        dtCampaign = db.ReturnTable("select CampaignId,Name from tbl_DHRISTI_CampaignMst where Active=1", False)
        db = Nothing
        Dim row As DataRow = dtCampaign.NewRow
        row.Item(0) = -1
        row.Item(1) = "ALL"
        dtCampaign.Rows.InsertAt(row, 0)
        cboCampaigns.Items.Clear()
        cboCampaigns.DataTextField = "Name"
        cboCampaigns.DataValueField = "CampaignID"
        cboCampaigns.DataSource = dtCampaign
        cboCampaigns.DataBind()
        dtCampaign = Nothing
    End Sub

    Private Sub FillCallTable()
        Dim campid, calltableid As Integer

        'raj 2 17082011 Start
        Dim db As DBAccess
        'Dim startday As Integer, endday As Integer
        If CboPeriod.SelectedValue = 10 Then
            startday = ucDateFrom.yyyymmdd
            endday = UcDateTo.yyyymmdd
        Else
            db = New DBAccess("CRM")
            db.slDataAdd("Period", CboPeriod.SelectedValue)
            'db.slDataAdd("Campaignid", CampaignID)
            Dim dr As DataRow = db.ReturnRow("usp_GetStart_EndDateForAPeriod", True)
            db = Nothing
            startday = dr(0)
            endday = dr(1)
        End If
        'raj 2 17082011 End

        If IsPostBack Then
            campid = cboCampaigns.SelectedValue
            If cboCallTable.SelectedValue <> "" Then
                calltableid = cboCallTable.SelectedValue
            End If
        End If

        db = New DBAccess("CRM")
        Dim dtCallTable As DataTable

        'raj 3 17082011 Start
        If cboCampaigns.SelectedValue = "-1" Or cboCampaigns.SelectedValue = "" Then
            dtCallTable = db.ReturnTable("SELECT cl.*,c.Name FROM tbl_DHRISTI_CallTableMst cl inner join tbl_DHRISTI_CampaignMst c on c.CampaignId =cl.CampaignId WHERE convert(varchar,startdate,112) between '" & startday & "' and '" & endday & "'  ORDER BY cl.CampaignId,CallTableID", , False)
        Else
            dtCallTable = db.ReturnTable("SELECT cl.*,c.Name FROM tbl_DHRISTI_CallTableMst cl inner join tbl_DHRISTI_CampaignMst c on c.CampaignId =cl.CampaignId WHERE convert(varchar,startdate,112) between '" & startday & "' and '" & endday & "' and cl.campaignid=" & cboCampaigns.SelectedValue & " ORDER BY cl.CampaignId,CallTableID", , False)
        End If
        'raj 3 17082011 End
        db = Nothing

        Dim row As DataRow = dtCallTable.NewRow
        row.Item(0) = -1
        row.Item(1) = "ALL"
        dtCallTable.Rows.InsertAt(row, 0)
        cboCallTable.Items.Clear()

        cboCallTable.DataSource = dtCallTable
        cboCallTable.DataTextField = "CallTableName"
        cboCallTable.DataValueField = "CallTableID"
        cboCallTable.DataBind()

        If IsPostBack Then
            Try
                cboCampaigns.SelectedValue = campid
                cboCallTable.SelectedValue = calltableid
            Catch ex As Exception
            End Try
        End If
    End Sub

    Dim dtDisposition As DataTable
    Private Sub GetData()
        If cboCallTable.Items.Count > 0 Then

            gvLeadStatus.DataSource = Nothing
            'Dim startday As Integer, endday As Integer
            'If CboPeriod.SelectedValue = 10 Then
            '    startday = ucDateFrom.yyyymmdd
            '    endday = UcDateTo.yyyymmdd
            'Else
            '    Dim db As New DBAccess("CRM")

            '    db.slDataAdd("Period", CboPeriod.SelectedValue)
            '    'db.slDataAdd("Campaignid", CampaignID)
            '    Dim dr As DataRow = db.ReturnRow("usp_GetStart_EndDateForAPeriod", True)
            '    db = Nothing
            '    startday = dr(0)
            '    endday = dr(1)
            'End If

            Dim db2 As New DBAccess

            If cboCampaigns.SelectedItem.Text.ToUpper <> "ALL" Then
                db2.slDataAdd("CampaignID", cboCampaigns.SelectedItem.Value)
            End If

            If cboCallTable.SelectedItem.Text.ToUpper = "ALL" Then
                db2.slDataAdd("DateFrom", startday)
                db2.slDataAdd("DateTo", endday)
            Else
                db2.slDataAdd("callTableName", cboCallTable.SelectedItem.Text)
            End If

            dtDisposition = db2.ReturnTable("usp_getLeadStatus", , True)

            db2 = Nothing
            gvLeadStatus.DataSource = dtDisposition
            gvLeadStatus.DataBind()
        End If
    End Sub

    'raj 4 17082011 Start
    Private Sub FillCommonFilters()
        Dim db As New DBAccess
        Dim dt As DataTable = db.ReturnTable("select * from tbl_Reports_DatePeriods")
        db = Nothing
        Dim dr As DataRow = dt.NewRow
        dr(0) = 10
        dr(1) = "Between"
        dt.Rows.Add(dr)
        CboPeriod.DataTextField = "Caption"
        CboPeriod.DataValueField = "Period"
        CboPeriod.DataSource = dt
        CboPeriod.DataBind()
    End Sub
    'raj 4 17082011 End

#End Region

#Region "Events"
    Protected Sub cboCampaigns_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboCampaigns.SelectedIndexChanged
        FillCallTable()
        GetData()
    End Sub
    Protected Sub btnRefresh_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnRefresh.Click
        FillCallTable()
        GetData()
    End Sub

    Protected Sub gvLeadStatus_PageIndexChanging(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewPageEventArgs) Handles gvLeadStatus.PageIndexChanging
        gvLeadStatus.PageIndex = e.NewPageIndex
        GetData()
    End Sub
    Protected Sub ImageButton1_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton1.Click
        GetData()
        Dim gv As New GridView
        gv.DataSource = dtDisposition
        gv.DataBind()
        GridViewExportUtil.Export(lblReportName.Text & ".xls", gv)
    End Sub
    Protected Sub cboCallTable_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboCallTable.SelectedIndexChanged
        GetData()
    End Sub

    'raj 5 17082011 Start
    Protected Sub CboPeriod_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles CboPeriod.SelectedIndexChanged
        'GetData()
        If CboPeriod.SelectedValue = 10 Then
            ucDateFrom.Visible = True
            UcDateTo.Visible = True
            lblAnd.Visible = True
            'fillgrid()
            FillCallTable()
            GetData()
        Else
            ucDateFrom.Visible = False
            UcDateTo.Visible = False
            lblAnd.Visible = False
            ' fillgrid()
            FillCallTable()
            GetData()
        End If
    End Sub
    'raj 5 17082011 End

#End Region

    Protected Sub imgfav_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles imgfav.Click
        Common.AddToFav(AgentID, "Lead Status Report Drishti")
        SuccessMessage("Report has been added to your favourite list")
        GetData()
    End Sub
#Region "Utility"

    Private Sub AlertMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMFail"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub

    Private Sub SuccessMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMSuccess"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub

    'Protected Sub ImageButton1_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton1.Click
    '    'fillgrid()
    '    GridViewExportUtil.Export(lblReportName.CurrentPage & "-" & LblError.Text & ".xls", Me.GdAttendance)
    'End Sub


    Public Overrides Sub VerifyRenderingInServerForm(ByVal Control As Control)

    End Sub

#End Region
End Class

