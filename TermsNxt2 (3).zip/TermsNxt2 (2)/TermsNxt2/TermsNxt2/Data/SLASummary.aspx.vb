﻿Imports com.nss.DBAccess
Imports System.Data
Imports System.Text
Partial Class Data_SLASummary
    Inherits System.Web.UI.Page
#Region "Properties"
    Property CampaignID() As Integer
        Get
            Return ViewState("CampaignID")
        End Get
        Set(ByVal value As Integer)
            ViewState("CampaignID") = value
        End Set
    End Property

    Property AgentID() As String
        Get
            Return ViewState("AgentID")
        End Get
        Set(ByVal value As String)
            ViewState("AgentID") = value
        End Set
    End Property
    Property startday() As Integer
        Get
            Return ViewState("startday")
        End Get
        Set(ByVal value As Integer)
            ViewState("startday") = value
        End Set
    End Property
    Property endday() As Integer
        Get
            Return ViewState("endday")
        End Get
        Set(ByVal value As Integer)
            ViewState("endday") = value
        End Set
    End Property
    Property PrevDay() As String
        Get
            Return ViewState("PrevDay")
        End Get
        Set(ByVal value As String)
            ViewState("PrevDay") = value
        End Set
    End Property
    Property campaignname() As String
        Get
            Return ViewState("campaignname")
        End Get
        Set(ByVal value As String)
            ViewState("campaignname") = value
        End Set
    End Property
#End Region
    Dim dtsummary, dtsummary1, dtsummaryTarget As DataTable
    Public sb As New StringBuilder()
    Private Sub createsummarytable()
        dtsummary1 = New DataTable
        dtsummary1.Columns.Add("Campaignid")
        dtsummary1.Columns.Add("Process")
        dtsummary1.Columns.Add("Serviceid")
        dtsummary1.Columns.Add("Service")
        dtsummary1.Columns.Add("Efficiencyid")
        dtsummary1.Columns.Add("Efficiency")
        dtsummary1.Columns.Add("QualityId")
        dtsummary1.Columns.Add("Quality")
        'dtsummary1.Columns.Add("AbsenteeismId")
        dtsummary1.Columns.Add("Absenteeism")
        dtsummary1.Columns.Add("Overall")
    End Sub
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        HumanMessage.Style.Item("visibility") = "hidden"
        If Not IsPostBack Then
            If Session("AgentID") <> "" Then
                AgentID = Session("AgentID")
                PanelReports.Controls.Add(Common.GetMenu(Request.Url, AgentID, Request.ApplicationPath))
                ucDateFrom.value = DateTime.Now.AddDays(-1)
                createsummarytable()
                getSLASummary()
            End If
        End If
    End Sub
    Private Sub getSLASummary()
        Try
            Dim db As New DBAccess("report")
            'Dim prevday As Integer
            Dim Dayname, currentday As String
            Dim flag As Boolean

            'db = New DBAccess

            PrevDay = ucDateFrom.yyyymmdd 'db.ReturnValue("select dateadd(dd,-1,getdate())", False)
            Dayname = db.ReturnValue("select DATENAME(DW,getdate()-1)", False)
            currentday = db.ReturnValue("select DATENAME(DW,getdate())", False)
            db = Nothing
            db = New DBAccess("crm")
            'If currentday = "Monday" Then
            db.slDataAdd("Period", 4)
            db.slDataAdd("Campaignid", 0)
            'Else
            '    db.slDataAdd("Period", 2)
            '    db.slDataAdd("Campaignid", 0)
            'End If

            Dim dr As DataRow = db.ReturnRow("usp_GetStart_EndDateForAPeriod", True)
            db = Nothing
            startday = dr(0)
            endday = dr(1)

            db = New DBAccess("CRM")
            Dim dtcampaign As New DataTable
            dtcampaign = db.ReturnTable("usp_getSLACampaigns", , True)
            db = Nothing

            Dim dtsummaryTarget As New DataTable
            Dim dtcheck As DataTable
            For Each row As DataRow In dtcampaign.Rows
                flag = False
                campaignid = row("campaignid")
                campaignname = row("CampaignName")

                db = New DBAccess("CRM")
                db.slDataAdd("day", ucDateFrom.yyyymmdd)
                db.slDataAdd("CampaignID", campaignid)
                db.slDataAdd("mtddayfrom", startday)
                db.slDataAdd("mtddayto", endday)
                dtcheck = db.ReturnTable("usp_getSLASummary", , True)
                db = Nothing
                'For Each dr1 As DataRow In dtcheck.Rows
                If dtcheck.Rows.Count > 0 Then
                    Dim summaryrow As DataRow = dtsummary1.NewRow
                    summaryrow("Campaignid") = CampaignID
                    summaryrow("Process") = campaignname
                    For Each row1 As DataRow In dtcheck.Rows
                        If row1("parameter") = "Service" Then
                            flag = True
                            Exit For
                        End If
                    Next
                    If flag = True Then
                        summaryrow("Serviceid") = dtcheck.Select("parameter='Service'")(0)(0)
                        summaryrow("Service") = dtcheck.Select("parameter='Service'")(0)(2)
                    End If
                    flag = False
                    For Each row1 As DataRow In dtcheck.Rows
                        If row1("parameter") = "Efficiency" Then
                            flag = True
                            Exit For
                        End If
                    Next
                    If flag = True Then
                        summaryrow("Efficiencyid") = dtcheck.Select("parameter='Efficiency'")(0)(0)
                        summaryrow("Efficiency") = dtcheck.Select("parameter='Efficiency'")(0)(2)
                    End If
                    flag = False
                    For Each row1 As DataRow In dtcheck.Rows
                        If row1("parameter") = "Quality" Then
                            flag = True
                            Exit For
                        End If
                    Next
                    If flag = True Then
                        summaryrow("Qualityid") = dtcheck.Select("parameter='Quality'")(0)(0)
                        summaryrow("Quality") = dtcheck.Select("parameter='Quality'")(0)(2)
                    End If
                    flag = False
                    For Each row1 As DataRow In dtcheck.Rows
                        If row1("parameter") = "Absenteeism" Then
                            flag = True
                            Exit For
                        End If
                    Next
                    If flag = True Then
                        summaryrow("Absenteeism") = dtcheck.Select("parameter='Absenteeism'")(0)(2)
                    End If
                    flag = False
                    For Each row1 As DataRow In dtcheck.Rows
                        If row1("parameter") = "Overall" Then
                            flag = True
                            Exit For
                        End If
                    Next
                    If flag = True Then
                        summaryrow("Overall") = dtcheck.Select("parameter='Overall'")(0)(2)
                    End If
                    flag = False

                    'Next               
                    'configmail()
                    dtsummary1.Rows.Add(summaryrow)
                End If
            Next
            If dtsummary1.Rows.Count > 0 Then
                GridView1.DataSource = dtsummary1
                GridView1.DataBind()
            End If
        Catch ex As Exception
            MsgBox(ex.ToString())
        End Try
    End Sub
#Region "grid ops"
    Dim columcount As Integer = 0

    'Protected Sub GridView1_RowCommand(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewCommandEventArgs) Handles GridView1.RowCommand
    '    sb.AppendLine("<table border='1' width='90%' style='border: 1px solid; border-collapse: collapse; font-family: Verdana; font-size: .8em'>")
    '    Dim gvr As GridViewRow
    '    Dim hdcampaignid As Integer
    '    Dim db As New DBAccess("crm")
    '    db.slDataAdd("DateFrom", ucDateFrom.yyyymmdd)
    '    Dim dbtarget As New DBAccess("crm")
    '    If e.CommandName = "getservice" Then
    '        Dim lnk As LinkButton = CType(e.CommandSource, LinkButton)
    '        gvr = CType(lnk.NamingContainer, GridViewRow)
    '        hdcampaignid = GridView1.DataKeys(gvr.RowIndex).Value
    '        db.slDataAdd("CampaignID", hdcampaignid)
    '        db.slDataAdd("SLACategoryid", e.CommandArgument)
    '        db.slDataAdd("mtddayfrom", startday)
    '        db.slDataAdd("mtddayto", endday)
    '        dbtarget.slDataAdd("CampaignID", hdcampaignid)
    '        dbtarget.slDataAdd("SLACategoryid", e.CommandArgument)
    '        dbtarget.slDataAdd("mtddayfrom", startday)
    '        dbtarget.slDataAdd("mtddayto", endday)
    '    ElseIf e.CommandName = "getefficiency" Then
    '        Dim lnk As LinkButton = CType(e.CommandSource, LinkButton)
    '        gvr = CType(lnk.NamingContainer, GridViewRow)
    '        hdcampaignid = GridView1.DataKeys(gvr.RowIndex).Value
    '        db.slDataAdd("CampaignID", hdcampaignid)
    '        db.slDataAdd("SLACategoryid", e.CommandArgument)
    '        db.slDataAdd("mtddayfrom", startday)
    '        db.slDataAdd("mtddayto", endday)
    '        dbtarget.slDataAdd("CampaignID", hdcampaignid)
    '        dbtarget.slDataAdd("SLACategoryid", e.CommandArgument)
    '        dbtarget.slDataAdd("mtddayfrom", startday)
    '        dbtarget.slDataAdd("mtddayto", endday)
    '    ElseIf e.CommandName = "getquality" Then
    '        Dim lnk As LinkButton = CType(e.CommandSource, LinkButton)
    '        gvr = CType(lnk.NamingContainer, GridViewRow)
    '        hdcampaignid = GridView1.DataKeys(gvr.RowIndex).Value
    '        db.slDataAdd("CampaignID", hdcampaignid)
    '        db.slDataAdd("SLACategoryid", e.CommandArgument)
    '        db.slDataAdd("mtddayfrom", startday)
    '        db.slDataAdd("mtddayto", endday)
    '        dbtarget.slDataAdd("CampaignID", hdcampaignid)
    '        dbtarget.slDataAdd("SLACategoryid", e.CommandArgument)
    '        dbtarget.slDataAdd("mtddayfrom", startday)
    '        dbtarget.slDataAdd("mtddayto", endday)
    '    ElseIf e.CommandName = "getoverall" Then
    '        pnlslasummary.Attributes.Add("style", "width:600px")
    '        Dim lnk As LinkButton = CType(e.CommandSource, LinkButton)
    '        gvr = CType(lnk.NamingContainer, GridViewRow)
    '        hdcampaignid = GridView1.DataKeys(gvr.RowIndex).Value
    '        db.slDataAdd("CampaignID", hdcampaignid)
    '        db.slDataAdd("SLACategoryid", e.CommandArgument)
    '        db.slDataAdd("mtddayfrom", startday)
    '        db.slDataAdd("mtddayto", endday)
    '        dbtarget.slDataAdd("CampaignID", hdcampaignid)
    '        dbtarget.slDataAdd("SLACategoryid", e.CommandArgument)
    '        dbtarget.slDataAdd("mtddayfrom", startday)
    '        dbtarget.slDataAdd("mtddayto", endday)
    '    End If
    '    Dim dtsummary As DataTable = db.ReturnTable("usp_getSLASummaryDetail", , True)
    '    db = Nothing


    '    dtsummaryTarget = dbtarget.ReturnTable("usp_getSLASummaryTarget", , True)
    '    dbtarget = Nothing
    '    If dtsummary.Rows.Count > 0 Then
    '        sb.AppendLine("<tr><td style='color:white; background-color:#632523; width:150px'>Targets</td>")
    '        If dtsummaryTarget.Rows.Count > 0 Then
    '            For a As Integer = 0 To dtsummaryTarget.Columns.Count - 1
    '                Dim dbtargetformat As New DBAccess("CRM")
    '                Dim targetformat As String
    '                targetformat = dbtargetformat.ReturnValue("select inputformat from tbl_config_SLAMst where SLACaption='" & dtsummaryTarget.Columns(a).ColumnName & "'", False)
    '                dbtargetformat = Nothing
    '                If targetformat Is Nothing Or targetformat = "" Then
    '                    sb.AppendLine("<td style='color:#000000; background-color:#DCE6F1'>" & dtsummaryTarget.Rows(0)(a) & "</td>")
    '                Else
    '                    If targetformat.ToLower = "time" Then
    '                        sb.AppendLine("<td style='color:#000000; background-color:#DCE6F1'>" & TimeString(dtsummaryTarget.Rows(0)(a)) & "</td>")
    '                    Else
    '                        sb.AppendLine("<td style='color:#000000; background-color:#DCE6F1'>" & dtsummaryTarget.Rows(0)(a) & "</td>")
    '                    End If
    '                End If
    '            Next
    '            ' Next
    '        Else
    '            For a As Integer = 0 To dtsummaryTarget.Columns.Count - 1
    '                sb.AppendLine("<td style='color:#000000; background-color:#DCE6F1'>&nbsp;</td>")
    '            Next
    '        End If
    '        sb.Append("</tr><tr bgcolor='#76933C'><td>&nbsp;</td>")
    '        For i As Integer = 0 To dtsummary.Columns.Count - 1
    '            sb.AppendLine("<td>" & dtsummary.Columns(i).ColumnName & "</td>")
    '        Next
    '        sb.Append("</tr>")
    '    End If
    '    If dtsummary.Rows.Count > 0 Then
    '        For Each row1 As DataRow In dtsummary.Rows
    '            sb.Append("<tr><td>&nbsp;</td>")
    '            For j As Integer = 0 To dtsummary.Columns.Count - 1
    '                'If j > 0 Then
    '                If dtsummaryTarget.Rows.Count > 0 Then
    '                    Dim dbhigh As New DBAccess("crm")
    '                    Dim Highisbetter As Boolean
    '                    Dim slaformat As String
    '                    Dim dtsummaryvalue As DataTable

    '                    dtsummaryvalue = dbhigh.ReturnTable("select HigherIsBetter,inputformat from tbl_config_SLAMst where SLACaption='" & dtsummary.Columns(j).ColumnName & "'", , False)
    '                    dbhigh = Nothing
    '                    If dtsummaryvalue.Rows.Count > 0 Then
    '                        Highisbetter = dtsummaryvalue.Rows(0)(0)
    '                        slaformat = dtsummaryvalue.Rows(0)(1)

    '                        If dtsummaryTarget.Rows(0)(j) <> "" Then
    '                            If slaformat.ToLower = "time" Then
    '                                If Convert.ToDouble(dtsummaryTarget.Rows(0)(j)) > Convert.ToDouble(row1(j)) And Highisbetter = True Then
    '                                    sb.AppendLine("<td style='color:white; background-color:#FF0000'>" & TimeString(row1(j)) & "</td>")
    '                                ElseIf Convert.ToDouble(dtsummaryTarget.Rows(0)(j)) < Convert.ToDouble(row1(j)) And Highisbetter = False Then
    '                                    sb.AppendLine("<td style='color:white; background-color:#FF0000'>" & TimeString(row1(j)) & "</td>")
    '                                Else
    '                                    sb.AppendLine("<td>" & TimeString(row1(j)) & "</td>")
    '                                End If
    '                            Else
    '                                If Convert.ToDouble(dtsummaryTarget.Rows(0)(j)) > Convert.ToDouble(row1(j)) And Highisbetter = True Then
    '                                    sb.AppendLine("<td style='color:white; background-color:#FF0000'>" & row1(j) & "</td>")
    '                                ElseIf Convert.ToDouble(dtsummaryTarget.Rows(0)(j)) < Convert.ToDouble(row1(j)) And Highisbetter = False Then
    '                                    sb.AppendLine("<td style='color:white; background-color:#FF0000'>" & row1(j) & "</td>")
    '                                Else
    '                                    sb.AppendLine("<td>" & row1(j) & "</td>")
    '                                End If
    '                            End If
    '                        Else
    '                            sb.AppendLine("<td>" & row1(j) & "</td>")
    '                        End If
    '                    ElseIf e.CommandArgument = 3 Then
    '                        Highisbetter = True
    '                        If Convert.ToDouble(dtsummaryTarget.Rows(0)(j)) > Convert.ToDouble(row1(j)) And Highisbetter = True Then
    '                            sb.AppendLine("<td style='color:white; background-color:#FF0000'>" & row1(j) & "</td>")
    '                        ElseIf Convert.ToDouble(dtsummaryTarget.Rows(0)(j)) < Convert.ToDouble(row1(j)) And Highisbetter = False Then
    '                            sb.AppendLine("<td style='color:white; background-color:#FF0000'>" & row1(j) & "</td>")
    '                        Else
    '                            sb.AppendLine("<td>" & row1(j) & "</td>")
    '                        End If
    '                    ElseIf e.CommandArgument = 0 And (dtsummary.Columns(j).ColumnName = "NFAR" Or dtsummary.Columns(j).ColumnName = "FAR") Then
    '                        Highisbetter = True
    '                        If Convert.ToDouble(dtsummaryTarget.Rows(0)(j)) > Convert.ToDouble(row1(j)) And Highisbetter = True Then
    '                            sb.AppendLine("<td style='color:white; background-color:#FF0000'>" & row1(j) & "</td>")
    '                        ElseIf Convert.ToDouble(dtsummaryTarget.Rows(0)(j)) < Convert.ToDouble(row1(j)) And Highisbetter = False Then
    '                            sb.AppendLine("<td style='color:white; background-color:#FF0000'>" & row1(j) & "</td>")
    '                        Else
    '                            sb.AppendLine("<td>" & row1(j) & "</td>")
    '                        End If
    '                    Else
    '                        sb.AppendLine("<td>" & row1(j) & "</td>")
    '                    End If
    '                    'Else
    '                    '    sb.AppendLine("<td>" & row1(j) & "</td>")
    '                    'End If

    '                Else
    '                    sb.AppendLine("<td>" & row1(j) & "</td>")
    '                End If
    '            Next
    '            sb.Append("</tr>")
    '        Next
    '    End If
    '    sb.AppendLine("</table>")
    '    'GridView2.DataSource = dt
    '    'GridView2.DataBind()
    '    Dim str As String
    '    str = "$('#DialogBackground').height($(document).height()-10);$('#DialogBackground').width($(window).width());$('#DialogBackground').css('visibility','visible');$('#pnlslasummary').css('visibility','visible');" & _
    '    " $('#pnlslasummary').css('left',($(window).width() - $('#pnlslasummary').width())/2); "
    '    ScriptManager.RegisterStartupScript(Page, Page.GetType(), "Movedialog", str, True)
    'End Sub
    Protected Sub GridView1_RowDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles GridView1.RowDataBound

        If e.Row.RowType = DataControlRowType.Header Then
            columcount = e.Row.Cells.Count
        End If
        If e.Row.RowType = DataControlRowType.DataRow Then

            Dim overall As HyperLink = e.Row.FindControl("lnkOverall")
            Dim service As HyperLink = e.Row.FindControl("lnkservice")
            Dim Efficiency As HyperLink = e.Row.FindControl("lnkEfficiency")
            Dim Quality As HyperLink = e.Row.FindControl("lnkQuality")
            Dim Absenteeism As HyperLink = e.Row.FindControl("lnkAbsenteeism")
            If Not overall.Text = "" Then
                If overall.Text < 100.0 Then
                    e.Row.Cells(5).BackColor = Drawing.Color.Red
                    overall.ForeColor = Drawing.Color.White
                Else
                    e.Row.Cells(5).BackColor = Drawing.Color.Green
                    overall.ForeColor = Drawing.Color.White
                End If
            End If
            If Not service.Text = "" Then
                If service.Text < 100.0 Then
                    e.Row.Cells(1).BackColor = Drawing.Color.Red
                    service.ForeColor = Drawing.Color.White
                Else
                    e.Row.Cells(1).BackColor = Drawing.Color.Green
                    service.ForeColor = Drawing.Color.White
                End If
            End If
            If Not Efficiency.Text = "" Then
                If Efficiency.Text < 100.0 Then
                    e.Row.Cells(2).BackColor = Drawing.Color.Red
                    Efficiency.ForeColor = Drawing.Color.White
                Else
                    e.Row.Cells(2).BackColor = Drawing.Color.Green
                    Efficiency.ForeColor = Drawing.Color.White
                End If
            End If
            If Not Quality.Text = "" Then
                If Quality.Text < 100.0 Then
                    e.Row.Cells(3).BackColor = Drawing.Color.Red
                    Quality.ForeColor = Drawing.Color.White
                Else
                    e.Row.Cells(3).BackColor = Drawing.Color.Green
                    Quality.ForeColor = Drawing.Color.White
                End If
            End If
            If Not Absenteeism.Text = "" Then
                Dim dbabsent As New DBAccess("CRM")
                Dim str As String = ""
                str = "select Target from [tbl_Data_DailyCampaignSLA_Data] where MStId in"
                str += "(select MAX(mstid) as mstid from tbl_Data_DailyCampaignSLA_Mst A inner join [tbl_Data_DailyCampaignSLA_Data] B "
                str += "on A.ID=B.mstid and A.CampaignId='" & GridView1.DataKeys(e.Row.RowIndex).Value & "' inner join [tbl_config_SLAMst] SLAMST on B.SLAID=SLAMST.SLAID and SLAMST.IsSLA=1 "
                str += "where A.campaignid ='" & GridView1.DataKeys(e.Row.RowIndex).Value & "' and isnull(Target,'')<>'' and B.SLAID=4 group by B.SLAID ) and SLAID=4"
                Dim absenttarget As Double = dbabsent.ReturnValue(str, False)
                dbabsent = Nothing
                If Absenteeism.Text > absenttarget Then
                    e.Row.Cells(4).BackColor = Drawing.Color.Red
                    Absenteeism.ForeColor = Drawing.Color.White
                Else
                    e.Row.Cells(4).BackColor = Drawing.Color.Green
                    Absenteeism.ForeColor = Drawing.Color.White
                End If
            End If
            If service.Text <> "" Then
                service.Text += " %"
            End If
            If Efficiency.Text <> "" Then
                Efficiency.Text += " %"
            End If
            If Quality.Text <> "" Then
                Quality.Text += " %"
            End If
            If overall.Text <> "" Then
                overall.Text += " %"
            End If
            If Absenteeism.Text <> "" Then
                Absenteeism.Text += " %"
            End If
            'If e.Row.Cells(4).Text <> "&nbsp;" And e.Row.Cells(4).Text <> "" Then
            '    e.Row.Cells(4).Text += " %"
            'End If
        End If
    End Sub
#End Region
    Private Function TimeString(ByVal Seconds As Long) As String

        'if verbose = false, returns
        'something like
        '02:22.08
        'if true, returns
        '2 hours, 22 minutes, and 8 seconds

        Dim lHrs As Long
        Dim lMinutes As Long
        Dim lSeconds As Long

        lSeconds = Seconds

        lHrs = Int(lSeconds / 3600)
        lMinutes = (Int(lSeconds / 60)) - (lHrs * 60)
        lSeconds = Int(lSeconds Mod 60)

        If lSeconds = 60 Then
            lMinutes = lMinutes + 1
            lSeconds = 0
        End If

        If lMinutes = 60 Then
            lMinutes = 0
            lHrs = lHrs + 1
        End If

        TimeString = lHrs.ToString("####00") & ":" & _
        lMinutes.ToString("00") & ":" & _
         lSeconds.ToString("00")

    End Function
    'Protected Sub imgclose_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles imgclose.Click
    '    Dim str As String
    '    str = "$('#DialogBackground').height($(document).height()-10);$('#DialogBackground').width($(window).width());$('#DialogBackground').css('visibility','hidden');$('#pnlslasummary').css('visibility','hidden');" & _
    '    " $('#pnlslasummary').css('left',($(window).width() - $('#pnlslasummary').width())/2); "
    '    ScriptManager.RegisterStartupScript(Page, Page.GetType(), "Movedialog", str, True)
    'End Sub
    'Private Sub configmail()



    'End Sub

    Protected Sub btnRefresh_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnRefresh.Click
        createsummarytable()
        getSLASummary()
    End Sub

    Protected Sub ucDateFrom_Changed(ByVal sender As Object, ByVal e As System.EventArgs) Handles ucDateFrom.Changed
        If validdate() Then
            createsummarytable()
            getSLASummary()
        Else
            AlertMessage("Date not in valid range")
            ucDateFrom.value = DateTime.Now.AddDays(-1)
            createsummarytable()
            getSLASummary()
        End If
        
    End Sub

    Protected Sub imgfav_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles imgfav.Click
        Common.AddToFav(AgentID, "SLA Summary")
        SuccessMessage("Report has been added to your favourite list")
        createsummarytable()
        getSLASummary()
    End Sub
#Region "Utility"

    Private Sub AlertMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMFail"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub

    Private Sub SuccessMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMSuccess"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub
#End Region
    Private Function validdate() As Boolean
        Dim db As New DBAccess("CRM")
        Dim dr As DataRow = db.ReturnRow("SELECT convert(varchar,getdate(),112) as currentdate  FROM [tbl_LastFreezedDate]")
        db = Nothing
        If ucDateFrom.yyyymmdd >= dr("currentDate") Then
            Return False
        End If
        'If selecteddate > CurrentDate Or selecteddate < MinDate Then
        '    Return False
        'End If
        Return True
    End Function
End Class
