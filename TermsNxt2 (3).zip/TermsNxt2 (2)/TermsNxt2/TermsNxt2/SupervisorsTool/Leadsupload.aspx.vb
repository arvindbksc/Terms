﻿Imports com.nss.DBAccess
Imports System.Data
Imports System.EventArgs
Imports System.Data.OleDb
Imports System.Data.SqlClient
Imports System.IO

Partial Class SupervisorsTool_Leadsupload
    Inherits System.Web.UI.Page
    Dim previousCat As String = ""
    Dim firstRow As Int16 = -1
#Region "===== PROPERTIES ========"

    Property SupervisorID() As String
        Get
            Return ViewState("SupervisorID")
        End Get
        Set(ByVal value As String)
            ViewState("SupervisorID") = value
        End Set
    End Property
    Property UserID() As String
        Get
            Return ViewState("UserID")
        End Get
        Set(ByVal value As String)
            ViewState("UserID") = value
        End Set
    End Property
    Property LanID() As String
        Get
            Return ViewState("LanID")
        End Get
        Set(ByVal value As String)
            ViewState("LanID") = value
        End Set
    End Property
    Property CampaignID() As String
        Get
            Return ViewState("CampaignID")
        End Get
        Set(ByVal value As String)
            ViewState("CampaignID") = value
        End Set
    End Property
    Property ProcessID() As Integer
        Get
            Return ViewState("ProcessID")
        End Get
        Set(ByVal value As Integer)
            ViewState("ProcessID") = value
            Session("ProcessID") = value
        End Set
    End Property
    Property AgentID() As String
        Get
            Return ViewState("AgentID")
        End Get
        Set(ByVal value As String)
            ViewState("AgentID") = value
        End Set
    End Property

#End Region
#Region "====== LOAD ======="
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        HumanMessage.Style.Item("visibility") = "hidden"
        If Not IsPostBack Then
            AgentID = Session("AgentID")
            CampaignID = Session("CampaignID")
            PanelReports.Controls.Add(Common.GetMenu(Request.Url, AgentID, Request.ApplicationPath))
            SupervisorID = Session("UserID")
            UserID = Session("UserID")
            ProcessID = Session("ProcessID")
            FillCampaigns()
            ' AllProcess(CboSupervisor.SelectedValue.Trim)
        End If
    End Sub



    Private Sub AllProcess(ByVal AgentId As String)
        'GetProcess()
        Try
            Dim dtlan As DataTable
            Dim dblan As New DBAccess("CRM")
            dblan.slDataAdd("AgentId", AgentId)
            dtlan = dblan.ReturnTable("usp_getAgentdetails", , True)
            If dtlan.Rows.Count > 0 Then
                LanID = dtlan.Rows(0).Item("lanId")
                dblan = Nothing
            End If
            Dim db As New DBAccess("CRM")
            Dim dt As New DataTable
            db.slDataAdd("Agentid", AgentId)
            dt = db.ReturnTable("usp_getUserProcess", , True)
            db = Nothing

        Catch ex As Exception
            AlertMessage("LAN-ID is not updated.")

        End Try
    End Sub
#End Region
#Region "======== EVENT =========="

    Private Sub FillCampaigns()
        'Common.FillCampaigns(cboCampaigns, AgentID, 0, 0)
        Common.FillProcessCampaigns(CboProcess, cboCampaigns, AgentID, CampaignID)
        Dim lstCamp As New ListItem
        lstCamp.Value = 0
        lstCamp.Text = "All"
        If cboCampaigns.Items.Contains(lstCamp) Then
            cboCampaigns.Items.Remove(lstCamp)
        End If
    End Sub
    Protected Sub ClearGrid()
        Try

            lblexcelName.Text = ""
            grvExcelData.DataSource = Nothing
            grvExcelData.DataBind()

        Catch ex As Exception
            AlertMessage("Error in ClearGrid. description :" & ex.Message)
        End Try
    End Sub

    Dim cmd As OleDbCommand
    Dim da As OleDbDataAdapter
    Dim ds As DataSet
    Protected Sub btnUpload_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnUpload.Click

        Dim filename As String = ""
        Dim filePath As String = ""

        filename = Path.GetFileName(FileUpload1.PostedFile.FileName.ToString())
        filePath = Server.MapPath("~\\myupload\\")

        Try

            ClearGrid()



            If (FileUpload1.HasFile) Then
                Dim connString As String = ""
                Dim strFileType As String = Path.GetExtension(FileUpload1.FileName).ToLower()

                'FileUpload1.SaveAs(Server.MapPath("~\\myupload\\" & FileUpload1.FileName))
                If (strFileType.Trim() = ".xls" Or strFileType.Trim() = ".xlsx") Then


                    FileUpload1.SaveAs(filePath + Path.GetFileName(filename))
                    'Dim filename As String = FileUpload1.FileName
                    lblexcelName.Text = filename
                    ' Dim path_1 As String = Server.MapPath("~\\myupload\\" & FileUpload1.PostedFile.FileName)
                    'Connection String to Excel Workbook
                    If strFileType.Trim() = ".xls" Then
                        connString = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" & filePath + Path.GetFileName(filename) & ";Extended Properties=""Excel 8.0;HDR=Yes;IMEX=2"""
                    ElseIf strFileType.Trim() = ".xlsx" Then
                        connString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" & filePath + Path.GetFileName(filename) & ";Extended Properties=""Excel 12.0;HDR=Yes;"""
                    End If
                    Dim query As String = "select Bclass,	Reference	,DocumentType,	JobId,	ReceiveddateTime from [sheet1$]"
                    Dim conexcel As New OleDbConnection(connString)
                    'If conexcel.State = ConnectionState.Closed Then
                    '    conexcel.Open()
                    'End If
                    cmd = New OleDbCommand(query, conexcel)
                    da = New OleDbDataAdapter(cmd)
                    ds = New DataSet()
                    da.Fill(ds, "tbl1")

                    ds.Tables("tbl1").Columns.Add("CustomerID", Type.GetType("System.Int32"))
                    ds.Tables("tbl1").Columns.Add("LeadBatch", Type.GetType("System.String"))
                    ds.Tables("tbl1").Columns.Add("uploadedby", Type.GetType("System.String"))
                    ds.Tables("tbl1").Columns.Add("CreationTime", Type.GetType("System.DateTime"))
                    ds.Tables("tbl1").Columns.Add("IsExpired", Type.GetType("System.Boolean"))
                    ds.Tables("tbl1").Columns.Add("AssignedTo", Type.GetType("System.String"))
                    ds.Tables("tbl1").Columns.Add("ReceivedDateTime", Type.GetType("System.DateTime"))
                    ds.Tables("tbl1").Columns.Add("Ques1590006", Type.GetType("System.String"))
                    ds.Tables("tbl1").Columns.Add("Ques1590001", Type.GetType("System.String"))
                    ds.Tables("tbl1").Columns.Add("Ques1590007", Type.GetType("System.String"))
                    ds.Tables("tbl1").Columns.Add("AllocationTime", Type.GetType("System.DateTime"))
                    ds.Tables("tbl1").Columns.Add("DialState", Type.GetType("System.Int16"))
                    ds.Tables("tbl1").Columns.Add("IsDeleted", Type.GetType("System.Boolean"))
                    ds.Tables("tbl1").Columns.Add("LastResultCode", Type.GetType("System.Int32"))
                    ds.Tables("tbl1").Columns.Add("LastResult", Type.GetType("System.Int32"))
                    ds.Tables("tbl1").Columns.Add("LastTransDateTime", Type.GetType("System.Int32"))
                    ds.Tables("tbl1").Columns.Add("LastTransId", Type.GetType("System.Int32"))
                    ds.Tables("tbl1").Columns.Add("LastAgent", Type.GetType("System.String"))



                    Dim db1 As New DBAccess("Leads_IP")
                    Dim leadbatch As String
                    db1.slDataAdd("processID", cboCampaigns.SelectedValue)
                    leadbatch = db1.ReturnValue("usp_GetLeadbatch", True)
                    For i As Integer = 0 To ds.Tables("tbl1").Rows.Count - 1
                        ds.Tables("tbl1").Rows(i).Item("leadbatch") = leadbatch
                        ds.Tables("tbl1").Rows(i).Item("uploadedby") = AgentID
                        ds.Tables("tbl1").Rows(i).Item("CreationTime") = System.DateTime.Now
                        ds.Tables("tbl1").Rows(i).Item("IsExpired") = False
                        ds.Tables("tbl1").Rows(i).Item("AssignedTo") = System.String.Empty
                        ds.Tables("tbl1").Rows(i).Item("ReceivedDateTime") = System.DateTime.Now
                        ds.Tables("tbl1").Rows(i).Item("Ques1590006") = System.String.Empty
                        ds.Tables("tbl1").Rows(i).Item("Ques1590001") = System.String.Empty
                        ds.Tables("tbl1").Rows(i).Item("Ques1590007") = System.String.Empty
                        ds.Tables("tbl1").Rows(i).Item("DialState") = 0
                        ds.Tables("tbl1").Rows(i).Item("IsDeleted") = False
                        ds.Tables("tbl1").Rows(i).Item("CustomerID") = 0
                    Next

                    grvExcelData.DataSource = ds.Tables("tbl1")
                    grvExcelData.DataBind()
                    da.Dispose()
                    conexcel.Close()
                    conexcel.Dispose()
                    'File.Delete(Server.MapPath("~\\myupload\\" & FileUpload1.PostedFile.FileName))
                    File.Delete(filePath + Path.GetFileName(filename))

                    btnsave.Visible = True
                Else

                End If
            End If

        Catch ex As Exception
            AlertMessage("Error in btnUpload_Click. description :" & ex.Message)
        End Try
        ' End If
    End Sub
    
    Protected Sub btnsave_Click(sender As Object, e As EventArgs) Handles btnsave.Click
        Try

            Dim db1 As New DBAccess("Leads_IP")
            Dim bulkCopy As SqlBulkCopy = New SqlBulkCopy(db1.ReturnConnection)

            'Bclass	Reference	DocumentType	JobId	ReceiveddateTime	LeadBatch	uploadedby
            Dim mapping0 As New SqlBulkCopyColumnMapping("CustomerID", "CustomerID")
            Dim mapping1 As New SqlBulkCopyColumnMapping("Bclass", "Bclass")
            Dim mapping2 As New SqlBulkCopyColumnMapping("Reference", "Reference")
            Dim mapping3 As New SqlBulkCopyColumnMapping("DocumentType", "DocumentType")
            Dim mapping4 As New SqlBulkCopyColumnMapping("uploadedby", "uploadedby")
            Dim mapping5 As New SqlBulkCopyColumnMapping("CreationTime", "CreationTime")
            Dim mapping6 As New SqlBulkCopyColumnMapping("IsExpired", "IsExpired")
            Dim mapping7 As New SqlBulkCopyColumnMapping("AssignedTo", "AssignedTo")

            Dim mapping8 As New SqlBulkCopyColumnMapping("Leadbatch", "Leadbatch")
            Dim mapping9 As New SqlBulkCopyColumnMapping("ReceivedDateTime", "ReceivedDateTime")
            Dim mapping10 As New SqlBulkCopyColumnMapping("Ques1590006", "Ques1590006")
            Dim mapping11 As New SqlBulkCopyColumnMapping("Ques1590001", "Ques1590001")
            Dim mapping12 As New SqlBulkCopyColumnMapping("Ques1590007", "Ques1590007")
            Dim mapping13 As New SqlBulkCopyColumnMapping("AllocationTime", "AllocationTime")
            Dim mapping14 As New SqlBulkCopyColumnMapping("DialState", "DialState")
            Dim mapping15 As New SqlBulkCopyColumnMapping("IsDeleted", "IsDeleted")
            Dim mapping16 As New SqlBulkCopyColumnMapping("LastResultCode", "LastResultCode")
            Dim mapping17 As New SqlBulkCopyColumnMapping("LastResult", "LastResult")
            Dim mapping18 As New SqlBulkCopyColumnMapping("LastTransDateTime", "LastTransDateTime")
            Dim mapping19 As New SqlBulkCopyColumnMapping("LastTransId", "LastTransId")
            Dim mapping20 As New SqlBulkCopyColumnMapping("LastAgent", "LastAgent")





            'Define dataColumn and DataType for tbl_leadmaster159
            Dim db As New DBAccess("Leads_IP")
            Dim dt, dt1 As New DataTable
            dt1.Columns.Add("columnname")
            dt1.Columns.Add("columntype")
            dt = db.ReturnTable("Select * from tbl_LeadMaster" & cboCampaigns.SelectedValue & " where 1=2", , False)
            For Each col As DataColumn In dt.Columns
                Dim row1 As DataRow = dt1.Rows.Add
                row1.Item("columnname") = col.ColumnName.ToString
                row1.Item("columntype") = col.DataType.ToString

            Next

            'Assign values in dt column from GridView
            '  For Each cell As TableCell In grvExcelData.HeaderRow.Cells
            For Each row As GridViewRow In grvExcelData.Rows
                dt.Rows.Add()

                'Bclass	Reference	DocumentType	JobId	ReceiveddateTime	CustomerID	LeadBatch	uploadedby	CreationTime	IsExpired	AssignedTo	ReceivedDateTime	Ques1590006	Ques1590001	Ques1590007	AllocationTime	DialState	IsDeleted	LastResultCode	LastResult	LastTransDateTime	LastTransId	LastAgent
                dt.Rows(row.RowIndex)("Bclass") = row.Cells(0).Text
                dt.Rows(row.RowIndex)("Reference") = row.Cells(1).Text
                dt.Rows(row.RowIndex)("DocumentType") = row.Cells(2).Text
                dt.Rows(row.RowIndex)("JobId") = row.Cells(3).Text
                dt.Rows(row.RowIndex)("ReceiveddateTime") = row.Cells(4).Text
                dt.Rows(row.RowIndex)("LeadBatch") = row.Cells(6).Text
                dt.Rows(row.RowIndex)("uploadedby") = row.Cells(7).Text
                dt.Rows(row.RowIndex)("CreationTime") = row.Cells(8).Text
                dt.Rows(row.RowIndex)("IsExpired") = False
                dt.Rows(row.RowIndex)("AssignedTo") = row.Cells(10).Text.Trim.Replace("&nbsp;", "")
                dt.Rows(row.RowIndex)("ReceivedDateTime") = row.Cells(11).Text
                dt.Rows(row.RowIndex)("Ques1590006") = row.Cells(0).Text 'row.Cells(12).Text.Trim.Replace("&nbsp;", "NULL")
                dt.Rows(row.RowIndex)("Ques1590001") = row.Cells(1).Text 'row.Cells(13).Text.Trim.Replace("&nbsp;", "NULL")
                dt.Rows(row.RowIndex)("Ques1590007") = row.Cells(2).Text 'row.Cells(14).Text.Trim.Replace("&nbsp;", "NULL")
                dt.Rows(row.RowIndex)("DialState") = row.Cells(16).Text
                dt.Rows(row.RowIndex)("IsDeleted") = False
               

            Next



            'Bclass	Reference	DocumentType	JobId	ReceiveddateTime

            'Source and Destination Column Mapping 
            bulkCopy.DestinationTableName = "tbl_LeadMaster" & cboCampaigns.SelectedValue

            bulkCopy.ColumnMappings.Add(mapping0)
            bulkCopy.ColumnMappings.Add(mapping1)
            bulkCopy.ColumnMappings.Add(mapping2)
            bulkCopy.ColumnMappings.Add(mapping3)
            bulkCopy.ColumnMappings.Add(mapping4)
            bulkCopy.ColumnMappings.Add(mapping5)
            bulkCopy.ColumnMappings.Add(mapping6)
            bulkCopy.ColumnMappings.Add(mapping7)
            bulkCopy.ColumnMappings.Add(mapping8)
            bulkCopy.ColumnMappings.Add(mapping9)
            bulkCopy.ColumnMappings.Add(mapping10)
            bulkCopy.ColumnMappings.Add(mapping11)
            bulkCopy.ColumnMappings.Add(mapping12)
            bulkCopy.ColumnMappings.Add(mapping13)
            bulkCopy.ColumnMappings.Add(mapping14)
            bulkCopy.ColumnMappings.Add(mapping15)
            bulkCopy.ColumnMappings.Add(mapping16)
            bulkCopy.ColumnMappings.Add(mapping17)
            bulkCopy.ColumnMappings.Add(mapping18)
            bulkCopy.ColumnMappings.Add(mapping19)
            bulkCopy.ColumnMappings.Add(mapping20)

            bulkCopy.ColumnMappings.Clear()
            For Each myCol In dt.Columns
                bulkCopy.ColumnMappings.Add(myCol.ColumnName.Trim(), myCol.ColumnName.Trim())
            Next

            bulkCopy.WriteToServer(dt)


            SuccessMessage("uploaded " & grvExcelData.Rows.Count & " out of " & grvExcelData.Rows.Count & " rows.")

        Catch ex As Exception
            AlertMessage("Error in btnsave_Click. description :" & ex.Message)
        End Try
    End Sub
    '    Protected Sub btnSubmit_Click(sender As Object, e As EventArgs) Handles btnSubmit.Click
    '        Dim FilePath As String = ""
    '        FilePath = Server.MapPath(FileUpload1.PostedFile.FileName)
    '        strFileName = FileUpload1.PostedFile.FileName.Substring(FileUpload1.PostedFile.FileName.LastIndexOf("\") + 1)
    '        strFileExtention = FileUpload1.PostedFile.FileName.Substring(FileUpload1.PostedFile.FileName.LastIndexOf(".") + 1)
    '        If FileUpload1.HasFile Then
    '            ImportDataFromExcel(FilePath)
    '            ' FetchDatafromFile(FilePath)
    '            '  UploadToDatabase()
    '        End If
    '    End Sub

    '    Public Sub ImportDataFromExcel(excelFilePath As String)
    '        'declare variables - edit these based on your particular situation
    '        Dim ssqltable As String = "tbl_Leadmaster" & CampaignID
    '        ' make sure your sheet name is correct, here sheet name is sheet1, so you can change your sheet name if have    different
    '        Dim mexceldataquery As String = "select Bclass,	Reference	,DocumentType,	JobId,	ReceiveddateTime from [sheet1$]"

    '        'create our connection strings
    '        'Dim sexcelconnectionstring As String = (Convert.ToString("provider=microsoft.jet.oledb.4.0;data source=") & excelFilePath) + ";extended properties=" + """excel 8.0;hdr=yes;"""

    '        Dim conn As New OleDbConnection
    '        Dim cmd As OleDbCommand

    '        If strFileExtention = "xls" Then
    '            conn = New OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0; Data Source=" & excelFilePath & ";Extended Properties=""Excel 8.0;HDR=Yes;IMEX=1""")
    '            cmd = New OleDbCommand("Select * from [sheet1$]")
    '        ElseIf strFileExtention = "txt" Then
    '            conn = New OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0; Data Source=" & strPath & ";Extended Properties=""text;HDR=Yes;FMT=TabDelimited""")
    '            cmd = New OleDbCommand("Select * from [" & strFileName & "]")
    '        ElseIf strFileExtention = "xlsx" Then
    '            conn = New OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0; Data Source=" & excelFilePath & ";Extended Properties=""Excel 12.0;HDR=Yes;""")
    '            cmd = New OleDbCommand("Select * from [Sheet1$]")
    '        Else
    '            conn = New OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0; Data Source=" & strPath & ";Extended Properties=""text;HDR=Yes;FMT=Delimited""")
    '            cmd = New OleDbCommand("Select * from [" & strFileName & "]")
    '        End If



    '        Try
    '            conn.Open()
    '        Catch ex As Exception
    '            MsgBox("Please check the file format!")
    '            Exit Sub
    '        End Try

    '        dt = New DataTable
    '        ds = New DataSet
    '        Try
    '            'Dim type As System.Type
    '            cmd.Connection = conn
    '            Dim da As New OleDbDataAdapter(cmd)
    '            da.Fill(dt)
    '            da.Fill(ds, "tbl1")
    '            Dim db As New DBAccess("Leads_IP")
    '            ds.Tables("tbl1").Columns.Add("LeadBatch", Type.GetType("System.String"))
    '            ds.Tables("tbl1").Columns.Add("uploadedby", Type.GetType("System.String"))
    '            Dim db1 As New DBAccess("Leads_IP")
    '            Dim leadbatch As String
    '            'db1.slDataAdd("camp", camp)
    '            db1.slDataAdd("processID", CampaignID)
    '            leadbatch = db1.ReturnValue("usp_GetLeadbatch", True)
    '            For i As Integer = 0 To ds.Tables("tbl1").Rows.Count - 1
    '                ds.Tables("tbl1").Rows(i).Item("leadbatch") = leadbatch
    '                ds.Tables("tbl1").Rows(i).Item("uploadedby") = AgentID
    '                'ds.Tables("tbl1").Rows(i).Item("Priority") = Priority
    '                'If Not IsDBNull(ds.Tables("tbl1").Rows(i).Item("Mobile")) Then
    '                '    ds.Tables("tbl1").Rows(i).Item("Mobile") = Replace(ds.Tables("tbl1").Rows(i).Item("Mobile"), " ", "")
    '                'End If
    '                'If Not IsDBNull(ds.Tables("tbl1").Rows(i).Item("Telephone")) Then
    '                '    ds.Tables("tbl1").Rows(i).Item("Telephone") = Replace(ds.Tables("tbl1").Rows(i).Item("Telephone"), " ", "")
    '                'End If                  
    '            Next

    '            dgleadsupload.DataSource = ds.Tables("tbl1")
    '            dgleadsupload.DataBind()




    '            'Leads Upload Data
    '            Dim ssqlconn As String = System.Configuration.ConfigurationManager.AppSettings("connCRM")

    '            ' ''execute a query to erase any previous data from our destination table
    '            ''Dim sclearsql As String = Convert.ToString("delete from ") & ssqltable
    '            ''Dim sqlconn As New SqlConnection(ssqlconnectionstring)
    '            ''Dim sqlcmd As New SqlCommand(sclearsql, sqlconn)
    '            ''sqlconn.Open()
    '            ''sqlcmd.ExecuteNonQuery()
    '            ''sqlconn.Close()


    '            'series of commands to bulk copy data from the excel file into our sql table
    '            Dim oledbconn As New OleDbConnection(ssqlconn)
    '            Dim oledbcmd As New OleDbCommand(mexceldataquery, oledbconn)
    '            oledbconn.Open()


    '            Dim dr As OleDbDataReader = oledbcmd.ExecuteReader()
    '            Dim bulkcopy As New SqlBulkCopy(ssqlconn)
    '            bulkcopy.DestinationTableName = ssqltable
    '            While dr.Read()
    '                bulkcopy.WriteToServer(dr)
    '            End While
    '            dr.Close()
    '            oledbconn.Close()
    '            Label1.Text = "File imported into sql server."

    '        Catch ex As Exception
    '            Throw ex
    '        End Try
    '    End Sub

    '    Dim dt As DataTable
    '    Dim ds As DataSet
    '    Dim strPath As String
    '    Private leadscount As Long = 0
    '    Public strFileName, strFileExtention, ShowScriptFlag As String

    '    Private Sub FetchDatafromFile(fileapth As String)
    '        Dim conn As New OleDbConnection
    '        Dim cmd As OleDbCommand

    '        If strFileExtention = "xls" Then
    '            conn = New OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0; Data Source=" & fileapth & ";Extended Properties=""Excel 8.0;HDR=Yes;IMEX=1""")
    '            cmd = New OleDbCommand("Select * from [sheet1$]")
    '        ElseIf strFileExtention = "txt" Then
    '            conn = New OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0; Data Source=" & strPath & ";Extended Properties=""text;HDR=Yes;FMT=TabDelimited""")
    '            cmd = New OleDbCommand("Select * from [" & strFileName & "]")
    '        ElseIf strFileExtention = "xlsx" Then
    '            conn = New OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0; Data Source=" & fileapth & ";Extended Properties=""Excel 12.0;HDR=Yes;""")
    '            cmd = New OleDbCommand("Select * from [Sheet1$]")
    '        Else
    '            conn = New OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0; Data Source=" & strPath & ";Extended Properties=""text;HDR=Yes;FMT=Delimited""")
    '            cmd = New OleDbCommand("Select * from [" & strFileName & "]")
    '        End If
    '        Try
    '            conn.Open()
    '        Catch ex As Exception
    '            MsgBox("Please check the file format!")
    '            Exit Sub
    '        End Try

    '        dt = New DataTable
    '        ds = New DataSet
    '        Try
    '            'Dim type As System.Type
    '            cmd.Connection = conn
    '            Dim da As New OleDbDataAdapter(cmd)
    '            da.Fill(dt)
    '            da.Fill(ds, "tbl1")
    '            Dim db As New DBAccess("Leads_IP")
    '            ds.Tables("tbl1").Columns.Add("LeadBatch", Type.GetType("System.String"))
    '            ds.Tables("tbl1").Columns.Add("uploadedby", Type.GetType("System.String"))
    '            Dim db1 As New DBAccess("Leads_IP")
    '            Dim leadbatch As String
    '            'db1.slDataAdd("camp", camp)
    '            db1.slDataAdd("processID", CampaignID)
    '            leadbatch = db1.ReturnValue("usp_GetLeadbatch", True)
    '            For i As Integer = 0 To ds.Tables("tbl1").Rows.Count - 1
    '                ds.Tables("tbl1").Rows(i).Item("leadbatch") = leadbatch
    '                ds.Tables("tbl1").Rows(i).Item("uploadedby") = AgentID
    '                'ds.Tables("tbl1").Rows(i).Item("Priority") = Priority
    '                'If Not IsDBNull(ds.Tables("tbl1").Rows(i).Item("Mobile")) Then
    '                '    ds.Tables("tbl1").Rows(i).Item("Mobile") = Replace(ds.Tables("tbl1").Rows(i).Item("Mobile"), " ", "")
    '                'End If
    '                'If Not IsDBNull(ds.Tables("tbl1").Rows(i).Item("Telephone")) Then
    '                '    ds.Tables("tbl1").Rows(i).Item("Telephone") = Replace(ds.Tables("tbl1").Rows(i).Item("Telephone"), " ", "")
    '                'End If                  
    '            Next

    '            dgleadsupload.DataSource = ds.Tables("tbl1")
    '            dgleadsupload.DataBind()
    '        Catch ex As Exception
    '            MsgBox("Import Failed!", MsgBoxStyle.Critical)
    '            'FetchDatafromFile = False
    '#If DEBUG Then
    '            MsgBox(ex.ToString)
    '#End If
    '        Finally
    '            conn.Close()
    '        End Try
    '    End Sub


    'Private Sub UploadToDatabase()
    '    'Dim leadscount As Integer
    '    Dim comment As String = ""
    '    Dim err As Boolean
    '    'Dim cr As New com.nss.nis.crypt
    '    Dim db1 As New DBAccess("Leads_IP")

    '    Dim row As New dgleadsupload
    '    leadscount = ds.Tables("tbl1").Rows.Count

    '    Try
    '        '           
    '        Dim bulkCopy As SqlBulkCopy = New SqlBulkCopy(db1.ReturnConnection)
    '        bulkCopy.DestinationTableName = "tbl_leadmaster" & CampaignID

    '        For Each row In gd1.Rows
    '            If row.Cells(1).Value.ToString <> "Ignore" Then
    '                bulkCopy.ColumnMappings.Add(row.Cells(0).Value.ToString, row.Cells(1).Value.ToString)
    '            End If
    '        Next
    '        ' bulkCopy.ColumnMappings.Add("LeadBatch", "LeadBatch")
    '        ' bulkCopy.ColumnMappings.Add("uploadedby", "uploadedby")
    '        If isexpire = True Then
    '            Dim dbexpire As New DBAccess("Leads_IP")
    '            strsql = "update tbl_leadmaster" & CampaignID & " set IsExpired=1"
    '            strsql += " from tbl_leadmaster" & CampaignID & " A where A.IsExpired =0"
    '            If Me.query <> "" Then
    '                strsql += " and " + Query
    '            End If
    '            dbexpire.exeSQL(strsql)
    '        End If
    '        bulkCopy.WriteToServer(ds.CreateDataReader)

    '    Catch ex As Exception
    '        err = True
    '        MsgBox(ex.ToString)
    '    Finally
    '        'db = Nothing
    '        db1 = Nothing
    '    End Try

    '    If err Then
    '        SuccessMessage("Import Failed,Please notify software support with file name information.")
    '    Else
    '        SuccessMessage("uploaded " & leadscount & " out of " & Pro & " rows.")
    '    End If
    'End Sub

#End Region
#Region "======= FUNCTIONS ========="



#End Region
#Region "===== UTILITY ====="

    Private Sub AlertMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMFail"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub

    Private Sub SuccessMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMSuccess"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub

#End Region
#Region "===== POP UP ===="
    Private Sub OpenPopUp()
        Dim str As String
        str = "$('#DialogBackground').height($(document).height()-10);$('#DialogBackground').width($(window).width());$('#DialogBackground').css('visibility','visible');$('#PanelResetPWD').css('visibility','visible');" & _
        " $('#PanelResetPWD').css('left',($(window).width() - $('#PanelResetPWD').width())/2); "
        ScriptManager.RegisterStartupScript(Page, Page.GetType(), "Movedialog", str, True)
    End Sub
    'Protected Sub btnEmail_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnEmail.Click
    '    Dim db As New com.nss.DBAccess.DBAccess("CRM")
    '    Dim dt As New DataTable
    '    If txtSupEmail.Text <> "" Or txtSupEmail.Text <> Nothing Then
    '        dt = db.ReturnTable("select * from tbl_Config_SupervisorsEmail where AgentID='" & AgentID & "'", False)
    '        If dt.Rows.Count = 0 Then
    '            db.slDataAdd("Agentid", AgentID)
    '            db.slDataAdd("Emailid", txtSupEmail.Text.Trim)
    '            db.InsertinTable("tbl_Config_SupervisorsEmail")
    '        End If
    '        db = Nothing

    '    End If
    'End Sub
    'Protected Sub btnClose_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnClose.Click

    'End Sub

#End Region
    'Public Event TreeNodeCheckChanged As TreeNodeEventHandler

    'Protected Sub TreeView1_TreeNodeCheckChanged(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.TreeNodeEventArgs) Handles TreeView1.TreeNodeCheckChanged
    '    Dim rptID As Int16 = e.Node.Value
    '    Dim rptname As String = e.Node.Text
    '    ReportAccess(rptID, rptname, AgentID)
    'End Sub
    'Protected Sub LinksTreeView_CheckChanged(ByVal sender As Object, ByVal e As TreeNodeEventArgs)
    '    Dim rptID As Int16 = e.Node.Value
    '    Dim rptname As String = e.Node.Text
    '    ReportAccess(rptID, rptname, AgentID)
    'End Sub

End Class
