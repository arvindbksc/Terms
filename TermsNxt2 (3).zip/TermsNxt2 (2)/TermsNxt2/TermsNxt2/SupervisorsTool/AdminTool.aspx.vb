﻿Imports com.nss.DBAccess
Imports System.Data
Imports System.EventArgs
Imports System.Data.OleDb
Imports System.Data.SqlClient
Imports System.IO

Partial Class SupervisorsTool_AdminTool
    Inherits System.Web.UI.Page
    Dim previousCat As String = ""
    Dim firstRow As Int16 = -1
    Public dtsettings As DataTable
#Region "===== PROPERTIES ========"

    Property SupervisorID() As String
        Get
            Return ViewState("SupervisorID")
        End Get
        Set(ByVal value As String)
            ViewState("SupervisorID") = value
        End Set
    End Property
    Property UserID() As String
        Get
            Return ViewState("UserID")
        End Get
        Set(ByVal value As String)
            ViewState("UserID") = value
        End Set
    End Property
    Property LanID() As String
        Get
            Return ViewState("LanID")
        End Get
        Set(ByVal value As String)
            ViewState("LanID") = value
        End Set
    End Property
    Property CampaignID() As String
        Get
            Return ViewState("CampaignID")
        End Get
        Set(ByVal value As String)
            ViewState("CampaignID") = value
        End Set
    End Property
    Property ProcessID() As Integer
        Get
            Return ViewState("ProcessID")
        End Get
        Set(ByVal value As Integer)
            ViewState("ProcessID") = value
            Session("ProcessID") = value
        End Set
    End Property
    Property AgentID() As String
        Get
            Return ViewState("AgentID")
        End Get
        Set(ByVal value As String)
            ViewState("AgentID") = value
        End Set
    End Property

#End Region
#Region "====== LOAD ======="
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        HumanMessage.Style.Item("visibility") = "hidden"
        If Not IsPostBack Then
            AgentID = Session("AgentID")
            CampaignID = Session("CampaignID")
            PanelReports.Controls.Add(Common.GetMenu(Request.Url, AgentID, Request.ApplicationPath))
            SupervisorID = Session("UserID")
            UserID = Session("UserID")
            ProcessID = Session("ProcessID")
            FillCampaigns()
            GetCampaignSetting()
            If CampaignID = "159" Then
                AgentID = "NSS41739" 'Jyoti Sharma atrium
            ElseIf CampaignID = "341" Then
                AgentID = "NSS50215"  'k.Gandhan LoveHoliday 341
            End If

            FillTree()
            '  RefreshNodes(TreeView1)
            ' AllProcess(CboSupervisor.SelectedValue.Trim)
        End If
    End Sub

    Private Sub FillTree()


        TreeView1.Nodes.Clear()
        Dim db As New DBAccess("CRM_IP")
        Dim dt As New DataTable
        ds = New DataSet
        db.slDataAdd("empID", AgentID)
        dt = db.ReturnTable("usp_MyHierarchy_20190618", , True)
        ds.Tables.Add(dt)
        db = Nothing

        If dt.Rows.Count = 0 Then Return
        PopulateNodes(dt, TreeView1)
     


    End Sub

  


    Private Sub PopulateNodes(ByVal dt As DataTable, ByVal myTV As TreeView)
        Dim tn As New TreeNode()

        ' Add Child Nodes
        Dim tn_current_child As TreeNode
        Dim tn_current_group As TreeNode
        Dim currentnode As TreeNode

        tn_current_child = AddNode(tn, dt.Rows(0).Item("campaignName").ToString(), dt.Rows(0).Item("campaignID").ToString(), tn.Value)
        tn_current_group = AddNode(tn_current_child, dt.Rows(0).Item("GroupName").ToString(), dt.Rows(0).Item("groupID").ToString(), tn.Value)



        For i As Integer = 0 To dt.Rows.Count - 1
            'For Each r As DataRow In dt.Rows

            tn.Text = dt.Rows(i).Item("campaignName").ToString()
            tn.Value = dt.Rows(i).Item("CampaignID").ToString()


            If tn_current_child.Text <> dt.Rows(i).Item("campaignName").ToString() Then
                tn_current_child = AddNode(tn, dt.Rows(i).Item("campaignName").ToString(), dt.Rows(i).Item("campaignID").ToString(), tn.Value)
                tn_current_group = AddNode(tn_current_child, dt.Rows(i).Item("GroupName").ToString(), dt.Rows(i).Item("groupID").ToString(), tn.Value)

            End If
            If tn_current_group.Text <> dt.Rows(i).Item("GroupName").ToString() Then
                tn_current_group = AddNode(tn_current_child, dt.Rows(i).Item("GroupName").ToString(), dt.Rows(i).Item("groupID").ToString(), tn.Value)

            End If

            currentnode = AddNode(tn_current_group, dt.Rows(i).Item("agentName").ToString(), dt.Rows(i).Item("AgentID").ToString(), tn.Value)

        Next
        myTV.Nodes.Add(tn)


    End Sub


    Dim dtStatus As DataTable


    Private Function AddNode(ByVal parentnode As Object, Txt As String, val As String, currentcampaign As String) As TreeNode
        Static BreakCounterCampaign As Integer, BreakCounter As Integer
        Dim db As New DBAccess("CRM")
        db.slDataAdd("campaignID", currentcampaign)
        dtStatus = db.ReturnTable("usp_GetAgentStatus", , True)
        db = Nothing
        Dim drAr() As DataRow = dtStatus.Select("agentid = '" & val & "'")

        Dim tn As New TreeNode
        tn.Text = Txt
        tn.Value = val
        If drAr.Length = 0 Then
            tn.ImageUrl = "../images/Admintool/3-NotLoggedin.png"
            tn.ToolTip = "Is Not Logged In"
        ElseIf drAr(0)("Status") = 1 Then
            BreakCounter = BreakCounter + 1
            BreakCounterCampaign = BreakCounterCampaign + 1
            tn.ImageUrl = "../images/Admintool/2-Break.png"

            If IsDBNull(drAr(0)("BreakDescription")) Then
                tn.ToolTip = "Is on Break from " & drAr(0)("timestamp") & " and Break type is Normal Break"
            Else
                tn.ToolTip = "Is on Break from " & drAr(0)("timestamp") & " and Break type is " & drAr(0)("BreakDescription")
            End If


        ElseIf drAr(0)("Status") = 21 Then
            tn.ImageUrl = "../images/Admintool/4-NotReady.png"
            tn.ToolTip = "Is on " & drAr(0)("Description") & " from " & drAr(0)("timestamp")
        Else
            tn.ImageUrl = "../images/Admintool/1-OnTransaction.png"
            tn.ToolTip = "Is on " & drAr(0)("Description") & " from " & drAr(0)("timestamp")
        End If

        parentnode.ChildNodes.Add(tn)

        Return tn
    End Function

    Public Sub Select_Change(ByVal sender As Object, ByVal e As System.EventArgs)

        ' lblMessage.Text = "You selected: " + TreeView1.SelectedNode.Text
        'lblMessage.Text = "You selected: " + "<html id='b1' oncontextmenu = 'return showmenuie5(event)'>" + TreeView1.SelectedNode.Text + "</html>"
        AlertMessage("You selected: " + "<html id='b1' oncontextmenu = 'return showmenuie5(event)'>" + TreeView1.SelectedNode.Text + "</html>")

    End Sub
    Public Sub LogOut_Click(ByVal sender As Object, ByVal e As System.EventArgs)
        ' lblMessage.Text = "New Node Click"
        'If TreeView1.SelectedNode.Level = 2 Then
        ' If MsgBox("Do you want to logout '" & TreeView1.SelectedNode.Text & "'?", MsgBoxStyle.Question + MsgBoxStyle.YesNo, "Logout") = MsgBoxResult.Yes Then
        ' AlertMessage("Do you want to logout." + TreeView1.SelectedNode.Text + "??")
        Dim db As New DBAccess("CRM")
        db.slDataAdd("CampaignId", cboCampaigns.SelectedValue)
        db.slDataAdd("AgentId", TreeView1.SelectedNode.Value)
        db.slDataAdd("isBreak", 0)
        db.slDataAdd("logout", 1) 'Logging out
        db.Executeproc("usp_UpdateAgentLog")
        db = Nothing
        SuccessMessage(TreeView1.SelectedNode.Text + " Logout Successfully")

        'End If
        'End If
    End Sub



    Private Sub GetCampaignSetting()
        Dim db As New DBAccess("CRM_IP")
        db.slDataAdd("campaignid", CampaignID)
        dtsettings = db.ReturnTable("usp_GetCampaignSettings", , True)
        db = Nothing
    End Sub

    Private Sub AllProcess(ByVal AgentId As String)
        'GetProcess()
        Try
            Dim dtlan As DataTable
            Dim dblan As New DBAccess("CRM")
            dblan.slDataAdd("AgentId", AgentId)
            dtlan = dblan.ReturnTable("usp_getAgentdetails", , True)
            If dtlan.Rows.Count > 0 Then
                LanID = dtlan.Rows(0).Item("lanId")
                dblan = Nothing
            End If
            Dim db As New DBAccess("CRM")
            Dim dt As New DataTable
            db.slDataAdd("Agentid", AgentId)
            dt = db.ReturnTable("usp_getUserProcess", , True)
            db = Nothing

        Catch ex As Exception
            AlertMessage("LAN-ID is not updated.")

        End Try
    End Sub
#End Region
#Region "======== EVENT =========="

    Private Sub FillCampaigns()
        'Common.FillCampaigns(cboCampaigns, AgentID, 0, 0)
        Common.FillProcessCampaigns(CboProcess, cboCampaigns, AgentID, CampaignID)
        Dim lstCamp As New ListItem
        lstCamp.Value = 0
        lstCamp.Text = "All"
        If cboCampaigns.Items.Contains(lstCamp) Then
            cboCampaigns.Items.Remove(lstCamp)
        End If
    End Sub
    Protected Sub ClearTree()
        Try


            TreeView1.DataSource = Nothing
            TreeView1.DataBind()

        Catch ex As Exception
            AlertMessage("Error in ClearGrid. description :" & ex.Message)
        End Try
    End Sub

    Dim cmd As OleDbCommand
    Dim da As OleDbDataAdapter
    Dim ds As DataSet



#End Region
#Region "======= FUNCTIONS ========="



#End Region
#Region "===== UTILITY ====="

    Private Sub AlertMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMFail"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub

    Private Sub SuccessMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMSuccess"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub

#End Region
#Region "===== POP UP ===="
    Private Sub OpenPopUp()
        Dim str As String
        str = "$('#DialogBackground').height($(document).height()-10);$('#DialogBackground').width($(window).width());$('#DialogBackground').css('visibility','visible');$('#PanelResetPWD').css('visibility','visible');" & _
        " $('#PanelResetPWD').css('left',($(window).width() - $('#PanelResetPWD').width())/2); "
        ScriptManager.RegisterStartupScript(Page, Page.GetType(), "Movedialog", str, True)
    End Sub
    'Protected Sub btnEmail_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnEmail.Click
    '    Dim db As New com.nss.DBAccess.DBAccess("CRM")
    '    Dim dt As New DataTable
    '    If txtSupEmail.Text <> "" Or txtSupEmail.Text <> Nothing Then
    '        dt = db.ReturnTable("select * from tbl_Config_SupervisorsEmail where AgentID='" & AgentID & "'", False)
    '        If dt.Rows.Count = 0 Then
    '            db.slDataAdd("Agentid", AgentID)
    '            db.slDataAdd("Emailid", txtSupEmail.Text.Trim)
    '            db.InsertinTable("tbl_Config_SupervisorsEmail")
    '        End If
    '        db = Nothing

    '    End If
    'End Sub
    'Protected Sub btnClose_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnClose.Click

    'End Sub

#End Region
    'Public Event TreeNodeCheckChanged As TreeNodeEventHandler

    'Protected Sub TreeView1_TreeNodeCheckChanged(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.TreeNodeEventArgs) Handles TreeView1.TreeNodeCheckChanged
    '    Dim rptID As Int16 = e.Node.Value
    '    Dim rptname As String = e.Node.Text
    '    ReportAccess(rptID, rptname, AgentID)
    'End Sub
    'Protected Sub LinksTreeView_CheckChanged(ByVal sender As Object, ByVal e As TreeNodeEventArgs)
    '    Dim rptID As Int16 = e.Node.Value
    '    Dim rptname As String = e.Node.Text
    '    ReportAccess(rptID, rptname, AgentID)
    'End Sub

End Class
