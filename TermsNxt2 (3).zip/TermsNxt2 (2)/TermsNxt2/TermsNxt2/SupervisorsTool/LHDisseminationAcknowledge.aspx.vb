﻿Imports com.nss.DBAccess
Imports System.Data
Imports System.Data.SqlClient
Imports System.Web.UI.WebControls
Imports System.Web.UI.WebControls.GridView
Imports System.Windows.Forms
Imports System.Globalization
Imports System.IO

Partial Class Staffing_SupervisorsTool_LHDisseminationAcknowledge
    Inherits System.Web.UI.Page

    'Public Overridable Property AllowPaging As Boolean
#Region "--- Properties ---"

    Property DissemId() As String
        Get
            Return ViewState("DissemId")
        End Get
        Set(ByVal value As String)
            ViewState("DissemId") = value
        End Set
    End Property
    Property CurrentDate() As Date
        Get
            Return ViewState("CurrentDate")
        End Get
        Set(ByVal value As Date)
            ViewState("CurrentDate") = value
        End Set
    End Property
    Property SupervisorID() As String
        Get
            Return ViewState("SupervisorID")
        End Get
        Set(ByVal value As String)
            ViewState("SupervisorID") = value
        End Set
    End Property
    Property UserID() As String
        Get
            Return ViewState("UserID")
        End Get
        Set(ByVal value As String)
            ViewState("UserID") = value
        End Set
    End Property
    Property AgentID() As String
        Get
            Return ViewState("AgentID")
        End Get
        Set(ByVal value As String)
            ViewState("AgentID") = value
        End Set
    End Property
    Property UserName() As String
        Get
            Return ViewState("username")
        End Get
        Set(ByVal value As String)
            ViewState("username") = value
        End Set
    End Property
    Property ProcessID() As Integer
        Get
            Return ViewState("ProcessID")
        End Get
        Set(ByVal value As Integer)
            ViewState("ProcessID") = value
            Session("ProcessID") = value
        End Set
    End Property

    Property YYYY() As Integer
        Get
            Return ViewState("YYYY")
        End Get
        Set(ByVal value As Integer)
            ViewState("YYYY") = value
        End Set
    End Property

    Property MM() As Integer
        Get
            Return ViewState("MM")
        End Get
        Set(ByVal value As Integer)
            ViewState("MM") = value
        End Set
    End Property

    Property DD() As Integer
        Get
            Return ViewState("DD")
        End Get
        Set(ByVal value As Integer)
            ViewState("DD") = value
        End Set
    End Property

#End Region
    Dim provider As CultureInfo = CultureInfo.InvariantCulture

#Region "--- Load ---"
    Private Sub PopulateProcessDropdown()
        Try
            Dim db As New DBAccess("Report")
            Dim dr As DataRow = db.ReturnRow("SELECT GetDate() AS CurrentDate", False)
            CurrentDate = dr("currentDate")

            
            ' db = Nothing
            'Common.FillProcesses(cboProcess, AgentID, 121)

            Common.FillProcesses(cboProcess, AgentID)
            db.slDataAdd("Agentid", AgentID)
            cboProcess.SelectedValue = db.ReturnRow("usp_getAgentProcess", True)(4)
            db = Nothing


            Dim lstprocess As New ListItem
            lstprocess.Value = 0
            lstprocess.Text = "All"
            If cboProcess.Items.Contains(lstprocess) Then
                cboProcess.Items.Remove(lstprocess)
            End If
            ' Dim db As New DBAccess
                       'Common.FillCampaigns(cboCampaigns, AgentID, cboProcess.SelectedValue)
        Catch ex As Exception
            AlertMessage("Error in PopulateProcessDropdown. description :- " & ex.Message)
        End Try
    End Sub

    Private Sub PopulateGridView()
        'Try

        '    btnSave.Visible = False
        '    btnCancel.Visible = False
        '    gvRotDataDetail.DataSource = Nothing
        '    gvRotDataDetail.DataBind()

        '    Dim db As New DBAccess("report")
        '    'Dim db As New DBAccess("CRM")
        '    db.slDataAdd("ProcessId", cboProcess.SelectedValue)
        '    db.slDataAdd("PipId", 0)
        '    db.slDataAdd("YYYY", YYYY)
        '    db.slDataAdd("MM", MM)
        '    Dim dataset As DataSet = db.ReturnDataset("[GET_WSR_PIPLIST]", True)
        '    db = Nothing

        '    If (dataset IsNot Nothing) Then
        '        If dataset.Tables.Count > 0 Then
        '            If dataset.Tables(0).Rows.Count > 0 Then

        '                btnSave.Visible = True
        '                btnCancel.Visible = True

        '                Dim dtPipData As DataTable = dataset.Tables(0)
        '                gvRotDataDetail.DataSource = dtPipData
        '                gvRotDataDetail.DataBind()

        '                CheckPIPStatus()
        '            End If
        '        End If
        '    End If

        '    If cboProcess.SelectedValue <> 9 Then
        '        btnSave.Visible = True
        '        btnCancel.Visible = True
        '    End If

        'Catch ex As Exception
        '    AlertMessage("Error in PopulateGridView. description :- " & ex.Message)
        'End Try
    End Sub

    Private Sub CheckPIPStatus()
        Try
            lblMessage.Text = String.Empty
            Dim dtPipData As DataTable = Common.GetValues("[GET_WSR_PIPPROCESSING_STATUS]", cboProcess.SelectedValue, True, 0, YYYY, MM)
            If (dtPipData IsNot Nothing) Then
                If (dtPipData.Rows.Count > 0) Then
                    If (Convert.ToBoolean(dtPipData.Rows(0)("isLocked")) = True) Then
                        lblMessage.Text = "PIP data for this week has been locked. Cannot update now"

                        btnCancel.Visible = False
                        btnSave.Visible = False

                        For Each row In gvRotDataDetail.Rows
                            Dim btn1 As WebControls.Button = CType(row.FindControl("btnAddAgent"), WebControls.Button)
                            Dim btn2 As WebControls.ImageButton = CType(row.FindControl("imgDelete"), WebControls.ImageButton)
                            Dim btn3 As WebControls.ImageButton = CType(row.FindControl("imgEdit"), WebControls.ImageButton)
                            If (btn1 IsNot Nothing) Then
                                btn1.Visible = False
                            End If

                            If (btn2 IsNot Nothing) Then
                                btn2.Visible = False
                            End If

                            If (btn3 IsNot Nothing) Then
                                btn3.Visible = False
                            End If
                        Next
                    End If
                End If
            End If
        Catch ex As Exception
            AlertMessage("Error in CheckPIPStatus. description :- " & ex.Message)
        End Try
    End Sub

    Private Sub PopulateAgents()
        Try
            Dim dt As DataTable = Common.GetValues("[usp_ActivityProcessAgents]", cboProcess.SelectedValue)
            ddpAgent.DataSource = dt
            ddpAgent.DataTextField = "AgentName"
            ddpAgent.DataValueField = "AgentId"
            ddpAgent.DataBind()
        Catch ex As Exception
            AlertMessage("Error in PopulateAgents. description :- " & ex.Message)
        End Try
    End Sub

    Private Sub PopulatePipLevels()
        Try
            Dim dt As DataTable = Common.GetValues("[GET_WSR_PIPLEVELLIST]", cboProcess.SelectedValue)
            ddpNewLevel.DataSource = dt
            ddpNewLevel.DataTextField = "LevelDescription"
            ddpNewLevel.DataValueField = "LevelId"
            ddpNewLevel.DataBind()
        Catch ex As Exception
            AlertMessage("Error in PopulatePipLevels. description :- " & ex.Message)
        End Try
    End Sub

    Private Sub PopulatePipStatus()
        Try
            Dim dt As DataTable = Common.GetValues("[GET_WSR_PIPSTATUSLIST]", cboProcess.SelectedValue, False)
            ddpNewStatus.DataSource = dt
            ddpNewStatus.DataTextField = "StatusDescription"
            ddpNewStatus.DataValueField = "StatusId"
            ddpNewStatus.DataBind()
        Catch ex As Exception
            AlertMessage("Error in PopulatePipStatus. description :- " & ex.Message)
        End Try
    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Try
            Dim der As String = "ere"

            'If Request("__EVENTTARGET") = "btnSubmitReason" Then
            '    SetPIP(cboProcess.SelectedValue(), 0, Convert.ToString(Request("__EVENTARGUMENT")), 0, 0, 0, hdnRemarks1.Value, " ", AgentID, 1, 0)
            'End If

            lblMessage.Text = String.Empty
            HumanMessage.Style.Item("visibility") = "hidden"
            If Not Me.IsPostBack Then
                'btnAddAgent.Visible = False
                btnCancel.Visible = False
                btnSave.Visible = False
                'btnSavePIP.Visible = False
                'btnSubmitPIP.Visible = False

                AgentID = Session("Agentid")
                YYYY = Date.Now.Year
                MM = Date.Now.Month
                DD = Date.Now.Day


                'PopulateProcessDropdown()
                ' PopulateAgents()
                'PopulatePipLevels()
                'PopulatePipStatus()

                lblReportName.CurrentPage = " LH Disseminate Acknowledgement  "

                PopulateDissiminateGrid("True", 121, AgentID)

            End If
        Catch ex As Exception
            AlertMessage("Error in Page_Load. description :- " & ex.Message)
        End Try
    End Sub

    'Protected Sub btnUpload_Click(ByVal sender As Object, ByVal e As ImageClickEventArgs) Handles btnUpLoad.Click


    '    Dim FileName As String = String.Empty
    '    Dim FileSize As String = String.Empty
    '    Dim extension As String = String.Empty
    '    Dim FilePath As String = String.Empty

    '    If (FileUpload1.HasFile) Then

    '        Dim contentType As String = FileUpload1.PostedFile.ContentType
    '        extension = Path.GetExtension(FileUpload1.FileName)

    '        FileName = Path.GetFileName(FileUpload1.PostedFile.FileName)
    '        FileSize = FileName.Length.ToString() + " Bytes"
    '        FileUpload1.PostedFile.SaveAs(Server.MapPath("~/myupload/" + FileName.Trim()))
    '        FilePath = "~/myupload/" + FileName.Trim().ToString()



    '        Using fs As Stream = FileUpload1.PostedFile.InputStream
    '            Using br As BinaryReader = New BinaryReader(fs)

    '                Dim bytes As Byte() = br.ReadBytes(Convert.ToInt32(fs.Length))

    '                Dim db As New DBAccess("Disseminate")

    '                db.slDataAdd("Name", FileName)
    '                db.slDataAdd("ContentType", contentType)
    '                db.slDataAdd("Data", bytes)
    '                db.slDataAdd("DissemID", DissemId)
    '                db.Executeproc("[usp_Save_Disseminate_Form_Attachments]")
    '                db = Nothing

    '                If System.IO.File.Exists(FilePath) Then
    '                    System.IO.File.Delete(FilePath)
    '                End If


    '            End Using


    '        End Using


    '    Else

    '        '  Label1.Text = "No File Uploaded"





    '    End If

    '    ' Response.Redirect(Request.Url.AbsoluteUri)
    'End Sub


    Private Sub OpenPopUp()
        ' lblEmpId.Text = txtOthers.Text.Trim
        Dim str As String
        str = "$('#DialogBackground').height($(document).height()-10);$('#DialogBackground').width($(window).width());$('#DialogBackground').css('visibility','visible');$('#PnlAttachFormAdd').css('visibility','visible'); $('#PnlAttachFormAdd').css('left',($(window).width() - $('#PnlAttachFormAdd').width())/2); "
        ScriptManager.RegisterStartupScript(Page, Page.GetType(), "Movedialog", str, True)
    End Sub


    Private Sub PopulateDissiminateGrid(ByVal bflag As Boolean, SelectedProcessID As String, AgentID As String)
        Dim db As New DBAccess("Disseminate")
        Try
            Dim dt As DataTable = New DataTable
            db.slDataAdd("Flag", bflag)
            db.slDataAdd("ProcessId", SelectedProcessID)
            db.slDataAdd("AgentId", AgentID)
            dt = db.ReturnTable("usp_Get_Data_Dissiminate_Acks", , True)
            db = Nothing
            gvRotDataDetail.DataSource = dt
            gvRotDataDetail.DataBind()

        Catch ex As Exception
            Throw ex
        End Try
    End Sub

#End Region
    Dim dt As DataTable

#Region "--- Events ---"
    Protected Sub DownloadFile(ByVal ID As Integer)


        Try
            Dim fileName As String = "", contentType As String = ""
            Dim bytes As Byte()
            Dim db As New DBAccess("Disseminate")
            Dim dt As DataTable
            db.slDataAdd("Id", ID)
            dt = db.ReturnTable("[usp_Get_Disseminate_Form_Attachment]", "", True)
            db = Nothing
            If dt.Rows.Count > 0 Then
                bytes = DirectCast(dt.Rows.Item(0)("Data"), Byte())
                contentType = dt.Rows.Item(0)("ContentType").ToString()
                fileName = dt.Rows.Item(0)("Name").ToString()
            End If
            Response.Clear()
            Response.Buffer = True
            Response.Charset = ""
            Response.Cache.SetCacheability(HttpCacheability.NoCache)
            Response.ContentType = contentType
            Response.AppendHeader("Content-Disposition", "attachment; filename=" + fileName)
            Response.BinaryWrite(bytes)
            Response.Flush()
            Response.End()
        Catch ex As Exception
            AlertMessage(ex.Message)
        End Try

    End Sub

    Protected Sub gvRotDataDetail_RowCommand(sender As Object, e As GridViewCommandEventArgs) Handles gvRotDataDetail.RowCommand
        If e.CommandName.ToLower = "attachs" Then

            Dim index As Integer = Convert.ToInt32(e.CommandArgument)
            DissemId = CType(gvRotDataDetail.Rows(index).FindControl("ltrlID"), Literal).Text


            Dim db As New DBAccess("Disseminate")




            Dim dt1 As New DataTable
            db.slDataAdd("DissemID", DissemId)
            dt1 = db.ReturnTable("[usp_Get_Disseminate_Form_Attachments]", , True)


            If dt1.Rows.Count > 0 Then


                GridView2.DataSource = dt1
                GridView2.DataBind()




            End If

            OpenPopUp()
        End If
    End Sub

    'Protected Sub btnSavePIP_Click(sender As Object, e As EventArgs) Handles btnSavePIP.Click
    '    Try

    '        For Each row In gvRotDataDetail.Rows

    '            Dim db As New DBAccess("report")
    '            'Dim db As New DBAccess("CRM")
    '            db.slDataAdd("ProcessId", cboProcess.SelectedValue())
    '            db.slDataAdd("YYYY", YYYY)
    '            db.slDataAdd("MM", MM)
    '            db.slDataAdd("PIPId", -1)
    '            db.slDataAdd("AgentId", CType(row.FindControl("ltrlAgentID"), WebControls.Label).Text)
    '            db.slDataAdd("PIPIssue", CType(row.FindControl("ltrlIssuePIP"), WebControls.Label).Text)
    '            db.slDataAdd("PIPLevel", CType(row.FindControl("ltrlLevelId"), WebControls.Label).Text)
    '            db.slDataAdd("PIPStatus", CType(row.FindControl("ltrlStatusId"), WebControls.Label).Text)
    '            db.slDataAdd("PIPReason", CType(row.FindControl("ltrlReason"), Literal).Text)
    '            db.slDataAdd("PIPStartDate", Convert.ToDateTime(CType(row.FindControl("ltrlStartDate"), Literal).Text))
    '            db.slDataAdd("PIPFilledBy", AgentID)
    '            db.slDataAdd("PIPDeleted", 0)
    '            db.slDataAdd("UPDATEFLAG", 0)

    '            dt = db.ReturnTable("[SET_WSR_AGENTPIP]", , True)
    '            db = Nothing
    '        Next
    '        SuccessMessage(String.Format("PIP for the period of {0} - {1} has been saved successfully.", Convert.ToString(MM), Convert.ToString(YYYY)))
    '        PopulateGridView()

    '    Catch ex As Exception
    '        AlertMessage("Error in btnSavePIP_Click. description :- " & ex.Message)
    '    End Try
    'End Sub

    'Protected Sub btnSubmitPIP_Click(sender As Object, e As EventArgs) Handles btnSubmitPIP.Click
    '    Try
    '        Dim db As New DBAccess("report")
    '        'Dim db As New DBAccess("CRM")
    '        db.slDataAdd("ProcessId", cboProcess.SelectedValue())
    '        db.slDataAdd("YYYY", YYYY)
    '        db.slDataAdd("MM", MM)
    '        db.slDataAdd("ISLOCKED", 1)
    '        db.slDataAdd("UpdateBy", AgentID)

    '        Dim dt As DataTable = db.ReturnTable("[SET_WSR_PIPPROCESSING_STATUS]", , True)
    '        db = Nothing

    '        If (dt IsNot Nothing) Then
    '            Select Case (dt.Rows(0)("MESSAGE_TYPE"))
    '                Case "S"
    '                    SuccessMessage(dt.Rows(0)("MESSAGE"))

    '                    Dim _agentsToWhomPipIssued = String.Empty
    '                    Dim _agentsWhosPipCleared = String.Empty
    '                    Dim _agentsObservation = String.Empty

    '                    For Each row As GridViewRow In gvRotDataDetail.Rows
    '                        Dim status As String = CType(row.FindControl("lblStatusDesriptionHidden"), WebControls.Label).Text

    '                        If status.ToLower().Contains("open") Then
    '                            _agentsToWhomPipIssued += "," + CType(row.FindControl("ltrlAgent"), WebControls.Literal).Text
    '                        ElseIf status.ToLower().Contains("close") Then
    '                            _agentsWhosPipCleared += "," + CType(row.FindControl("ltrlAgent"), WebControls.Literal).Text
    '                        ElseIf status.ToLower().Contains("observation") Then
    '                            _agentsObservation += "," + CType(row.FindControl("ltrlAgent"), WebControls.Literal).Text
    '                        End If
    '                    Next

    '                    Dim monthName = IIf(MM = 1, "January", IIf(MM = 2, "February", IIf(MM = 3, "March", IIf(MM = 4, "April", IIf(MM = 5, "May", IIf(MM = 6, "June", IIf(MM = 7, "July", IIf(MM = 8, "August", IIf(MM = 9, "September", IIf(MM = 10, "October", IIf(MM = 11, "November", IIf(MM = 12, "December", MM.ToString()))))))))))))

    '                    If _agentsToWhomPipIssued.Length > 0 Then
    '                        _agentsToWhomPipIssued = _agentsToWhomPipIssued.Substring(1)
    '                        If _agentsToWhomPipIssued.Length > 0 Then
    '                            sendPIPIssuedMailToHR(cboProcess.SelectedItem.Text, monthName, Date.Now.ToShortDateString(), AgentID, _agentsToWhomPipIssued)
    '                        End If
    '                    End If

    '                    If _agentsWhosPipCleared.Length > 0 Then
    '                        _agentsWhosPipCleared = _agentsWhosPipCleared.Substring(1)
    '                        If _agentsWhosPipCleared.Length > 0 Then
    '                            sendPIPClearedMailToHR(cboProcess.SelectedItem.Text, Date.Now.ToShortDateString(), _agentsWhosPipCleared)
    '                        End If
    '                    End If


    '                    If _agentsObservation.Length > 0 Then
    '                        _agentsObservation = _agentsObservation.Substring(1)
    '                        If _agentsObservation.Length > 0 Then
    '                            sendPIPObservation(cboProcess.SelectedItem.Text, Date.Now.ToShortDateString(), _agentsObservation)
    '                        End If
    '                    End If


    '                    PopulateGridView()
    '                Case "E"
    '                    AlertMessage(dt.Rows(0)("MESSAGE"))
    '            End Select
    '        End If

    '    Catch ex As Exception
    '        AlertMessage("Error in btnSubmitPIP_Click. description :- " & ex.Message)
    '    End Try
    'End Sub

    Protected Sub gvRotDataDetail_RowDeleting(sender As Object, e As GridViewDeleteEventArgs) Handles gvRotDataDetail.RowDeleting
        Try
            Dim Index As Integer = Convert.ToInt32(e.RowIndex)
            ' SetPIP(cboProcess.SelectedValue(), 0, Convert.ToString(CType(gvRotDataDetail.Rows(Index).FindControl("ltrlAgentID"), WebControls.Label).Text), 0, 0, 0, hdnRemarks1.Value, " ", AgentID, 1, 0)
            'for test
            '  PopulateGridView()

            PopulateDissiminateGrid("True", cboProcess.SelectedValue, AgentID)


        Catch ex As Exception
            AlertMessage("Error in gvRotDataDetail_RowDeleting. description :- " & ex.Message)
        End Try
    End Sub

    Protected Sub gvRotDataDetail_RowDataBound(sender As Object, e As GridViewRowEventArgs) Handles gvRotDataDetail.RowDataBound
        Try
            If e.Row.RowType = DataControlRowType.DataRow Then

                Dim rawData As String = CType(e.Row.FindControl("lblAcknowledgedDate"), System.Web.UI.WebControls.Label).Text

                If Not (rawData = "") Then
                    ' Dim btn2 As WebControls.ImageButton = CType(e.Row.FindControl("imgDelete"), WebControls.ImageButton)
                    Dim btn3 As WebControls.ImageButton = CType(e.Row.FindControl("imgEdit"), WebControls.ImageButton)

                    If (btn3 IsNot Nothing) Then
                        btn3.Visible = False
                    End If

                End If

                'Dim rawData As Boolean = CType(e.Row.FindControl("ltrID"), System.Web.UI.WebControls.Literal).Text
                'If (rawData = True) Then
                '    Dim btn2 As WebControls.ImageButton = CType(e.Row.FindControl("imgDelete"), WebControls.ImageButton)
                '    Dim btn3 As WebControls.ImageButton = CType(e.Row.FindControl("imgEdit"), WebControls.ImageButton)
                '    If (btn2 IsNot Nothing) Then
                '        btn2.Visible = False
                '    End If

                '    If (btn3 IsNot Nothing) Then
                '        btn3.Visible = False
                '    End If

                'End If
            End If

        Catch ex As Exception
            AlertMessage("Error in gvRotDataDetail_RowDataBound. description :- " & ex.Message)
        End Try
    End Sub

    Protected Sub gvRotDataDetail_RowEditing(sender As Object, e As GridViewEditEventArgs) Handles gvRotDataDetail.RowEditing
        Try


            'btnSave.Text = "Update"

            Dim index As Integer = Convert.ToInt32(e.NewEditIndex)
            Dim iId As Integer = CType(gvRotDataDetail.Rows(index).FindControl("ltrlID"), Literal).Text
            Dim sAgentId As String = CType(gvRotDataDetail.Rows(index).FindControl("ltrlAgentID"), Literal).Text


            Dim db As New DBAccess("Disseminate")
            db.slDataAdd("ID", iId)
            db.slDataAdd("AgentId", sAgentId)
            db.Executeproc("usp_UpdateDisseminateAgentStatus")
            PopulateDissiminateGrid("True", cboProcess.SelectedValue, AgentID)

            'ddpAgent.SelectedValue = CType(gvRotDataDetail.Rows(index).FindControl("ltrlAgentID"), WebControls.Label).Text
            'ddpIssuePIP.SelectedValue = CType(gvRotDataDetail.Rows(index).FindControl("ltrlIssuePIP"), WebControls.Label).Text
            'ddpNewLevel.SelectedValue = CType(gvRotDataDetail.Rows(index).FindControl("ltrlLevelId"), WebControls.Label).Text
            'ddpNewStatus.SelectedValue = CType(gvRotDataDetail.Rows(index).FindControl("ltrlStatusId"), WebControls.Label).Text
            'txtPIPReason.Text = CType(gvRotDataDetail.Rows(index).FindControl("ltrlReason"), Literal).Text
            'ucPIPStartDate.value = Convert.ToDateTime(CType(gvRotDataDetail.Rows(index).FindControl("ltrlStartDate"), Literal).Text)
            'OpenDialog()
        Catch ex As Exception
            AlertMessage("Error in gvRotDataDetail_RowEditing. description :- " & ex.Message)
        End Try

    End Sub

    Protected Sub cboProcess_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboProcess.SelectedIndexChanged
        Try
            ProcessID = cboProcess.SelectedValue()
            PopulateGridView()

            PopulateDissiminateGrid("True", cboProcess.SelectedValue, AgentID)
            PopulateAgents()
            PopulatePipLevels()
            PopulatePipStatus()

        Catch ex As Exception
            AlertMessage("Error in cboProcess_SelectedIndexChanged. description :- " & ex.Message)
        End Try
    End Sub

    'Protected Sub btnAddAgent_Click(sender As Object, e As EventArgs) Handles btnAddAgent.Click
    '    Try
    '        btnSave.Text = "Save"
    '        btnSave.CommandArgument = ""
    '        txtPIPReason.Text = ""
    '        ucPIPStartDate.value = Now.Date()
    '        OpenDialog()
    '    Catch ex As Exception
    '        AlertMessage("Error in btnAddAgent_Click. description :- " & ex.Message)
    '    End Try
    'End Sub

    Protected Sub btnSave_Click(sender As Object, e As EventArgs) Handles btnSave.Click
        Try
            Dim pipId As Integer = -1
            Dim pipUpdateFlag As Integer = 0
            If (btnSave.Text = "Update") Then
                pipId = Convert.ToInt32(btnSave.CommandArgument)
                pipUpdateFlag = 1
            End If

            SetPIP(cboProcess.SelectedValue(), pipId, ddpAgent.SelectedValue, ddpIssuePIP.SelectedValue, ddpNewLevel.SelectedValue, ddpNewStatus.Text, txtPIPReason.Text, ucPIPStartDate.yyyymmdd, AgentID, 0, pipUpdateFlag)

        Catch ex As Exception
            AlertMessage("Error in btnSave_Click. description :- " & ex.Message)
        End Try
    End Sub

    Protected Sub ucPIPStartDate_Changed(ByVal sender As Object, ByVal e As System.EventArgs) Handles ucPIPStartDate.Changed
        OpenDialog()
    End Sub
#End Region

#Region "--- Utility ---"
    Private Sub AlertMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMFail"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub

    Private Sub SuccessMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMSuccess"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub

    Private Sub OpenDialog()
        Dim str As String
        str = "$('#DialogBackground').height($(document).height()-2);$('#DialogBackground').width($(window).width());$('#DialogBackground').css('visibility','visible');$('#PanelIDPForm').css('visibility','visible'); $('#PanelIDPForm').css('left',($(window).width() - $('#PanelIDPForm').width())/2); "
        ScriptManager.RegisterStartupScript(Page, Page.GetType(), "Movedialog", str, True)
    End Sub


    Private Sub SetPIP(ByVal process As Integer, ByVal pipid As Integer, ByVal agent As String, ByVal pipissue As Integer, ByVal piplevel As Integer, ByVal pipstatus As Integer, ByVal pipreason As String, ByVal pipstartdate As String, ByVal pipfilledby As String, ByVal pipdeleted As Integer, ByVal pipupdateflag As Integer)
        Try
            Dim db As New DBAccess("report")
            'Dim db As New DBAccess("CRM")
            db.slDataAdd("ProcessId", process)
            db.slDataAdd("YYYY", YYYY)
            db.slDataAdd("MM", MM)
            db.slDataAdd("PIPId", pipid)
            db.slDataAdd("AgentId", agent)
            db.slDataAdd("PIPIssue", pipissue)
            db.slDataAdd("PIPLevel", piplevel)
            db.slDataAdd("PIPStatus", pipstatus)
            db.slDataAdd("PIPReason", pipreason)
            db.slDataAdd("PIPStartDate", pipstartdate)
            db.slDataAdd("PIPFilledBy", pipfilledby)
            db.slDataAdd("PIPDeleted", pipdeleted)
            db.slDataAdd("UPDATEFLAG", pipupdateflag)

            dt = db.ReturnTable("[SET_WSR_AGENTPIP]", , True)
            db = Nothing

            If (dt IsNot Nothing) Then
                Select Case (dt.Rows(0)("MESSAGE_TYPE"))
                    Case "S"
                        SuccessMessage(dt.Rows(0)("MESSAGE"))
                        PopulateGridView()
                    Case "E"
                        AlertMessage(dt.Rows(0)("MESSAGE"))
                End Select
            End If

        Catch ex As Exception
            AlertMessage("Error in SetPIP. description :- " & ex.Message)
        End Try
    End Sub
#End Region

#Region "--- Functions---"
    Private Function sendPIPIssuedMailToHR(ByVal processName As String, ByVal monthName As String, ByVal issuedDate As String, ByVal byWhom As String, ByVal agentsCSV As String) As Boolean
        Try
            'Dim objWSMail As New ServiceReference2.MailSoapClient
            Dim objWSMail As New MailSendServiceXX.Service1SoapClient
            'As New MailSendServiceXX.Service1SoapClient
            Dim strFrom As String = System.Configuration.ConfigurationManager.AppSettings("FROM")
            Dim MailSubject As String = "PIP Issued (" & processName & ")"
            Dim strMailBody As String = ""
            Dim _index As Integer = 1

            Dim AgentName As New StringBuilder
            'For Each agent In agentsCSV.Split(",")
            '    AgentName.Append(Convert.ToString(_index) & "). " & agent & ".")
            '    AgentName.Append("</ br>")
            '    _index = _index + 1
            'Next


            strMailBody += "<html xmlns='http://www.w3.org/1999/xhtml'>"
            strMailBody += "<body style='font-family: Verdana; font-size: .8em'>"
            strMailBody += "Hope you doing well !!:<br />"
            strMailBody += "Please login into Terms and Submit the list of agents who are in PIP.:<br /><br />"
            strMailBody += "Submission required as soon as possible :<br />"
            strMailBody += "List of Employees who will be in PIP  :<br /> <br />"
            strMailBody += "<table border='1' width='90%' style='border: 1px solid; border-collapse: collapse; font-family: Verdana; font-size: .8em'>"
            strMailBody += "<tr bgcolor='#B8CCE4'>"
            strMailBody += "<td align='center'><b>Month</b></td>"
            strMailBody += "<td align='center'><b>Issued On</b></td>"
            strMailBody += "<td align='center'><b>By Whom</b></td>"
            strMailBody += "<td align='center'><b>Process</b></td>"
            strMailBody += "</tr>"
            strMailBody += "<tr >"
            strMailBody += "<td align='center'>" & monthName & "</td>"
            strMailBody += "<td align='center'>" & issuedDate & "</td>"
            strMailBody += "<td align='center'>" & byWhom & "</td>"
            strMailBody += "<td align='center'>" & processName & "</td>"
            strMailBody += "</tr>"
            strMailBody += "</table>"
            strMailBody += "<table border='1' width='90%' style='border: 1px solid; border-collapse: collapse; font-family: Verdana; font-size: .8em'>"
            strMailBody += "<tr  bgcolor='#B8CCE4'> "
            strMailBody += "<td align='center'><b>Agent  Detail Info</b></td>"
            strMailBody += "</tr>"
            strMailBody += "<tr>"
            For Each agent In agentsCSV.Split(",")
                AgentName.Append(Convert.ToString(_index) & "). " & agent & ".")
                AgentName.Append("</ br>")

                _index = _index + 1
            Next
            strMailBody += "<td align='center'>" & AgentName.ToString() & "</td>"
            strMailBody += "</tr>"
            strMailBody += "</table>"

            strMailBody += "<br /><br />"

            strMailBody += "<p>"
            strMailBody += "Thank You."
            strMailBody += "</p>"



            strMailBody += "</body>"
            strMailBody += "</html>"



            'strMailBody.Append("Hi")
            'strMailBody.Append("</ br>")

            'strMailBody.Append(" Hope you doing well !")
            'strMailBody.Append("</ br>")
            'strMailBody.Append("Please login into Terms and Submit the list of agents who are in PIP.")
            'strMailBody.Append("</ br>")
            'strMailBody.Append("Submission required as soon as possible")
            'strMailBody.Append("</ br>")
            'strMailBody.Append("Thank you for your time.")
            'strMailBody.Append("</ br>")

            'strMailBody.Append("</ br>")
            'strMailBody.Append("</ br>")
            'strMailBody.Append("List of Employees who will be in PIP for the Month of " & monthName & " issued on " & issuedDate & " by Mr." & byWhom & " for " & processName & " process.")
            'strMailBody.Append("</ br>")
            'For Each agent In agentsCSV.Split(",")
            '    strMailBody.Append(Convert.ToString(_index) & "). " & agent & ".")
            '    strMailBody.Append("</ br>")
            '    _index = _index + 1
            'Next
            'strMailBody.Append("</ br>")
            'strMailBody.Append("</ br>")


            'strMailBody.Append("Thank you.")



            ' objWSMail.MailSend("jaspreet.1.singh@niit-tech.com", strMailBody.ToString(), Nothing, "developers@niit-tech.com", "", "<" & strFrom & ">", MailSubject)
            ' objWSMail.MailSend(strTo, MailBody, "", strCC, strBcc, strFrom, Subject)
            ' objWSMail.MailSend(System.Configuration.ConfigurationManager.AppSettings("WSR_PIP_ProcessManager"), strMailBody.ToString(), "", "", "rajkumar.sharma@niit-tech.com", "<" & strFrom & ">", MailSubject)

            ''Live One
            objWSMail.MailSendNewTech(System.Configuration.ConfigurationManager.AppSettings("WSR_PIP_ProcessManager"), MailSubject, "PIP Issue <" & strFrom & ">", "", strMailBody.ToString(), "", "", System.Configuration.ConfigurationManager.AppSettings("BCC"), "") '' Final

            objWSMail = Nothing

            Return True
        Catch ex As Exception
            AlertMessage("Error in sendPIPIssuedMailToHR. description :- " & ex.Message)
            Return False
        End Try
    End Function

    Private Function sendPIPClearedMailToHR(ByVal processName As String, ByVal clearedDate As String, ByVal agentsCSV As String) As Boolean
        Try
            Dim objWSMail As New MailSendServiceXX.Service1SoapClient
            Dim strFrom As String = System.Configuration.ConfigurationManager.AppSettings("FROM")
            Dim MailSubject As String = "PIP Cleared (" & processName & ")"
            Dim strMailBody As String = ""
            Dim _index As Integer = 1

            Dim AgentName As New StringBuilder

            strMailBody += "<html xmlns='http://www.w3.org/1999/xhtml'>"
            strMailBody += "<body style='font-family: Verdana; font-size: .8em'>"
            strMailBody += "Hope you doing well !!:<br />"
            strMailBody += "List of Employees who have cleared PIP on  :<br /> <br />"
            strMailBody += "<table border='1' width='90%' style='border: 1px solid; border-collapse: collapse; font-family: Verdana; font-size: .8em'>"
            strMailBody += "<tr bgcolor='#B8CCE4'>"
            strMailBody += "<td align='center'><b>Cleared On</b></td>"
            strMailBody += "<td align='center'><b>Process</b></td>"
            strMailBody += "</tr>"
            strMailBody += "<tr >"
            strMailBody += "<td align='center'>" & clearedDate & "</td>"
            strMailBody += "<td align='center'>" & processName & "</td>"
            strMailBody += "</tr>"
            strMailBody += "</table>"

            strMailBody += "<table border='1' width='90%' style='border: 1px solid; border-collapse: collapse; font-family: Verdana; font-size: .8em'>"
            strMailBody += "<tr  bgcolor='#B8CCE4'> "
            strMailBody += "<td align='center'><b>Agent  Detail Info</b></td>"
            strMailBody += "</tr>"
            strMailBody += "<tr>"
            For Each agent In agentsCSV.Split(",")
                AgentName.Append(Convert.ToString(_index) & "). " & agent & ".")
                AgentName.Append("</ br>")

                _index = _index + 1
            Next
            strMailBody += "<td align='center'>" & AgentName.ToString() & "</td>"
            strMailBody += "</tr>"
            strMailBody += "</table>"

            strMailBody += "<br /><br />"

            strMailBody += "<p>"
            strMailBody += "Thank You."
            strMailBody += "</p>"



            strMailBody += "</body>"
            strMailBody += "</html>"


            'strMailBody.Append("Hi,")
            'strMailBody.Append("</ br>")
            'strMailBody.Append("</ br>")
            'strMailBody.Append("List of Employees who have cleared PIP on " & clearedDate & ".")
            'strMailBody.Append("</ br>")
            'For Each agent In agentsCSV.Split(",")
            '    strMailBody.Append(Convert.ToString(_index) & "). " & agent & ".")
            '    strMailBody.Append("</ br>")
            '    _index = _index + 1
            'Next
            'strMailBody.Append("</ br>")
            'strMailBody.Append("</ br>")
            'strMailBody.Append("Thank you.")
            'objWSMail.MailSend(System.Configuration.ConfigurationManager.AppSettings("WSR_PIP_HR"), strMailBody.ToString(), "", "", "rajkumar.sharma@niit-tech.com", "<" & strFrom & ">", MailSubject)

            objWSMail.MailSendNewTech(System.Configuration.ConfigurationManager.AppSettings("WSR_PIP_HR"), MailSubject, "PIP Issue <" & strFrom & ">", "", strMailBody.ToString(), "", "", System.Configuration.ConfigurationManager.AppSettings("BCC"), "") '' Final

            objWSMail = Nothing

            Return True
        Catch ex As Exception
            AlertMessage("Error in sendPIPClearedMailToHR. description :- " & ex.Message)
            Return False
        End Try
    End Function

    Private Function sendPIPObservation(ByVal processName As String, ByVal clearedDate As String, ByVal agentsCSV As String) As Boolean
        Try
            Dim objWSMail As New MailSendServiceXX.Service1SoapClient
            Dim strFrom As String = System.Configuration.ConfigurationManager.AppSettings("FROM")
            Dim MailSubject As String = "PIP Observation (" & processName & ")"
            Dim strMailBody As String = ""
            Dim _index As Integer = 1


            strMailBody += "<html xmlns='http://www.w3.org/1999/xhtml'>"
            strMailBody += "<body style='font-family: Verdana; font-size: .8em'>"
            strMailBody += "Hope you doing well !!:<br />"
            strMailBody += "List of Employees under Observation for PIP on  :<br /> <br />"
            strMailBody += "<table border='1' width='90%' style='border: 1px solid; border-collapse: collapse; font-family: Verdana; font-size: .8em'>"
            strMailBody += "<tr bgcolor='#B8CCE4'>"
            strMailBody += "<td align='center'><b>Cleared On</b></td>"
            strMailBody += "<td align='center'><b>Process</b></td>"
            strMailBody += "</tr>"
            strMailBody += "<tr >"
            strMailBody += "<td align='center'>" & clearedDate & "</td>"
            strMailBody += "<td align='center'>" & processName & "</td>"
            strMailBody += "</tr>"
            strMailBody += "</table>"

            strMailBody += "<br /><br />"

            strMailBody += "<p>"
            strMailBody += "Thank You."
            strMailBody += "</p>"



            strMailBody += "</body>"
            strMailBody += "</html>"



            'strMailBody.Append("Hi,")
            'strMailBody.Append("</ br>")
            'strMailBody.Append("</ br>")
            'strMailBody.Append("List of Employees under Observation for PIP on " & clearedDate & ".")
            'strMailBody.Append("</ br>")
            'For Each agent In agentsCSV.Split(",")
            '    strMailBody.Append(Convert.ToString(_index) & "). " & agent & ".")
            '    strMailBody.Append("</ br>")
            '    _index = _index + 1
            'Next
            'strMailBody.Append("</ br>")
            'strMailBody.Append("</ br>")
            'strMailBody.Append("Thank you.")
            '            objWSMail.MailSend(System.Configuration.ConfigurationManager.AppSettings("WSR_PIP_ProcessManager"), strMailBody.ToString(), "", "", "rajkumar.sharma@niit-tech.com", "<" & strFrom & ">", MailSubject)

            objWSMail.MailSendNewTech(System.Configuration.ConfigurationManager.AppSettings("WSR_PIP_ProcessManager"), MailSubject, "PIP Issue <" & strFrom & ">", "", strMailBody.ToString(), "", "", System.Configuration.ConfigurationManager.AppSettings("BCC"), "") '' Final

            objWSMail = Nothing

            Return True
        Catch ex As Exception
            AlertMessage("Error in sendPIPObservation. description :- " & ex.Message)
            Return False
        End Try
    End Function

#End Region

    Protected Sub GridView2_RowCommand(sender As Object, e As GridViewCommandEventArgs) Handles GridView2.RowCommand
        Try
            If e.CommandName.ToLower = "download" Then
                Dim index As Integer = Convert.ToInt32(e.CommandArgument)
                'DissemId = CType(GridView2.Rows(index).FindControl("lblForm_Id"), Literal).Text

                ' Dim db As DBAccess = New DBAccess("Disseminate")

                DownloadFile(index)



            End If
        Catch ex As Exception
            AlertMessage(ex.Message)
        End Try
    End Sub
End Class
