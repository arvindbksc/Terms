﻿
Partial Class SupervisorTool_Default
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Dim serverpath As String
        If Request.Url.Host = "localhost" Then
            serverpath = HttpContext.Current.Request.ApplicationPath
        Else
            ' serverpath = "http://termsmonitor.niitsmartserve.com"
            'serverpath = "http://TMhelpdesk.niit-tech.com"
            serverpath = System.Configuration.ConfigurationManager.AppSettings("LiveServerPath")

        End If
        Response.Redirect(serverpath & "/PwdReset.aspx")
    End Sub
End Class
