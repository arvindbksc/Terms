﻿Imports com.nss.DBAccess
Imports System.Data
Imports System.EventArgs
Imports System.IO

Partial Class Staffing_SupervisorsTool_LHDisseminationUpdate
    Inherits System.Web.UI.Page
    Dim previousCat As String = ""
    Dim firstRow As Int16 = -1
#Region "===== PROPERTIES ========"

    Property DissemId() As String
        Get
            Return ViewState("DissemId")
        End Get
        Set(ByVal value As String)
            ViewState("DissemId") = value
        End Set
    End Property


    Property SupervisorID() As String
        Get
            Return ViewState("SupervisorID")
        End Get
        Set(ByVal value As String)
            ViewState("SupervisorID") = value
        End Set
    End Property
    Property UserID() As String
        Get
            Return ViewState("UserID")
        End Get
        Set(ByVal value As String)
            ViewState("UserID") = value
        End Set
    End Property
    Property LanID() As String
        Get
            Return ViewState("LanID")
        End Get
        Set(ByVal value As String)
            ViewState("LanID") = value
        End Set
    End Property
    Property CampaignID() As Integer
        Get
            Return 0 'ViewState("CampaignID")
        End Get
        Set(ByVal value As Integer)
            'ViewState("CampaignID") = value
            'Session("CampaignID") = value
        End Set
    End Property

    Property CampaignID2() As Integer
        Get
            Return ViewState("CampaignID2")
        End Get
        Set(ByVal value As Integer)
            ViewState("CampaignID2") = value
            'Session("CampaignID") = value
        End Set
    End Property
    Property ProcessID() As Integer
        Get
            Return ViewState("ProcessID")
        End Get
        Set(ByVal value As Integer)
            ViewState("ProcessID") = value
            Session("ProcessID") = value
        End Set
    End Property
    Property AgentID() As String
        Get
            Return ViewState("AgentID")
        End Get
        Set(ByVal value As String)
            ViewState("AgentID") = value
        End Set
    End Property

    Property SelectedWorkType() As String
        Get
            Return ViewState("SelectedWorkType")
        End Get
        Set(ByVal value As String)
            ViewState("SelectedWorkType") = value
        End Set
    End Property

    Property MailTo() As String
        Get
            Return ViewState("MailTo")
        End Get
        Set(ByVal value As String)
            ViewState("MailTo") = value
        End Set
    End Property

    Property MailTo2() As String
        Get
            Return ViewState("MailTo2")
        End Get
        Set(ByVal value As String)
            ViewState("MailTo2") = value
        End Set
    End Property
    Property MailCC() As String
        Get
            Return ViewState("MailCC")
        End Get
        Set(ByVal value As String)
            ViewState("MailCC") = value
        End Set
    End Property

    Property MailCC2() As String
        Get
            Return ViewState("MailCC2")
        End Get
        Set(ByVal value As String)
            ViewState("MailCC2") = value
        End Set
    End Property
    Property MailUniqueCC() As String
        Get
            Return ViewState("MailUniqueCC")
        End Get
        Set(ByVal value As String)
            ViewState("MailUniqueCC") = value
        End Set
    End Property

    Property MailUniqueCC2() As String
        Get
            Return ViewState("MailUniqueCC2")
        End Get
        Set(ByVal value As String)
            ViewState("MailUniqueCC2") = value
        End Set
    End Property

    Public Property dtFillData() As DataTable
        Get
            Return ViewState("dtFillData")
        End Get
        Set(ByVal value As DataTable)
            ViewState("dtFillData") = value
        End Set
    End Property

#End Region

#Region "====== LOAD ======="
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        HumanMessage.Style.Item("visibility") = "hidden"
        If Not IsPostBack Then
            AgentID = Session("AgentID")
            PanelReports.Controls.Add(Common.GetMenu(Request.Url, AgentID, Request.ApplicationPath))
            SupervisorID = Session("UserID")
            UserID = Session("UserID")
            ProcessID = Session("ProcessID")
            CampaignID = Session("CampaignID")
            ' lblAssignedworkType.Text = "List of Assigned Worktypes"
            lblworkType.Text = "List of WorkTypes"
            FillAgents()
            GetWorkTypeLH(341)
            'GetAssignedWorkTypeLH(341)
            gvDissiminate.DataSource = Nothing
            gvDissiminate.DataBind()
            GetSupervisorsbasedonWorkType(SelectedWorkType)
            ' ViewState("postbackTrue") = False

            'Else
            '    ViewState("postbackTrue") = True
            PopulateDissiminateData("True", 121)
            lblreportname.CurrentPage = "LH Disseminate Update  "
        End If
    End Sub
    Dim dtdissimnateF As DataTable

    Private Sub FillAgents()
        Try
            Dim db As New DBAccess("CRM")
            db.slDataAdd("Campaignid", 341)
            Dim dtSupervisor As New DataTable
            dtSupervisor = db.ReturnTable("usp_GetAllAgents", , True)
            db = Nothing
            ' lblReportName.CurrentPage = "Access Management"
            If dtSupervisor.Rows.Count > 0 Then
                Dim finalName As DataColumn = New DataColumn
                With finalName
                    .DataType = System.Type.GetType("System.String")
                    .ColumnName = "AN"
                    .Expression = "AgentName + ' [' + AgentId + ']'"
                End With
                With dtSupervisor.Columns
                    .Add(finalName)
                End With
                dtSupervisor.AcceptChanges()
                'CboAgents.DataSource = dtSupervisor
                'CboAgents.DataTextField = "AN"
                'CboAgents.DataValueField = "AgentId"
                'CboAgents.DataBind()
                'CboAgents.Items.Insert(dtSupervisor.Rows.Count, "Others")
            End If
            dtSupervisor = Nothing
        Catch ex As Exception
            Throw ex
        End Try
    End Sub


    Private Sub FillDissiminateGridNew()

        gvDissiminate.DataSource = Nothing
        gvDissiminate.DataBind()
        gvDissiminate.Controls.Clear() 'rajkumar 20Mar2016 Added
        gvDissiminate.Columns.Clear() 'rajkumar 20Mar2016 Added

        dtdissimnateF = dtDissiminate.Copy  'dtFillData is retrieved from WeekWiseLatestRoster() '22Mar2016


        'Dim tfieldCheckbox As New TemplateField()
        ''  tfieldCheckbox.HeaderText = "Select"
        'gvDissiminate.Columns.Add(tfieldCheckbox)

        'Dim bField0 As New BoundField
        'bField0.HeaderText = "AgentID"
        'bField0.DataField = "AgentID"
        'GridView1.Columns.Add(bField0)
        'dtdissimnateF.Columns.Add("AgentID")
        'Dim bField As New BoundField
        'bField.HeaderText = "AgentName"
        'bField.DataField = "AgentName"
        'GridView1.Columns.Add(bField)
        'dtdissimnateF.Columns.Add("AgentName")



        'TW.WorkTypedesc, p.ProcessId,[ProcessName],b.[AgentName] as [SupervisorName],Upper(a.supervisorid) as supervisorid ,Upper(a.[AgentID]) as [AgentID],a.[AgentName]  ,AR.Role as Designation

        dtdissimnateF.AcceptChanges()
        gvDissiminate.DataSource = Nothing
        gvDissiminate.DataSource = dtdissimnateF
        gvDissiminate.DataBind()

    End Sub
    Protected Sub btnRefresh_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnRefresh.Click
        gvDissiminate.DataSource = Nothing
        gvDissiminate.DataBind()
        GetSupervisorsbasedonWorkType(SelectedWorkType)
    End Sub

    Protected Sub gvDissiminate_RowDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles gvDissiminate.RowDataBound

        Dim StaffId As String = ""



        If (e.Row.RowType = DataControlRowType.DataRow) Then
            For Each gvRow As GridViewRow In gvDissiminate.Rows

                Dim chkSelect As CheckBox = CType(gvRow.FindControl("cbxIsselected"), CheckBox)
                If chkSelect.Checked = True Then
                    '                flagFilled = True
                    StaffId = gvRow.Cells(1).Text

                End If

                'Dim cb As CheckBox = gvDissiminate.Rows(RowCounter).Cells(0).FindControl("IsSelected")
                'If cb IsNot Nothing And cb.Checked = True Then
                '    'Code to pull data from GridViewID and compare to DB
                '    'Code to Update MySQL Database
                '    '  RowCounter = +1

                'End If
            Next
        End If


        'If (e.Row.RowType = DataControlRowType.DataRow) Then

        '    StaffId = e.Row.Cells(0).Text.Trim

        '    ' string[] approvers = ApproverName.Split(';');
        '    '  If (approvers.Count() > 1) Then
        '    '{
        '    '    ((Label)e.Row.Cells[2].FindControl("lblANgrd")).Text = "";

        '    '    int i = 0;
        '    '    foreach (var item in approvers)

        '    Dim ckb As CheckBox = New CheckBox()
        '    ckb.Text = StaffId
        '    ckb.ID = "ckb" & StaffId.ToString()
        '    ckb.Checked = True
        '    e.Row.Cells(0).Controls.Add(ckb)


        'End If









        'If e.Row.RowType = DataControlRowType.DataRow Then

        '    ' Dim drdata As DataRow = dtDissiminate.Select("AgentID='" & e.Row.Cells(0).Text.Trim & "'")(0)  'rajkumar 21Mar2016 Done for Checkbox
        '    'Dim drShift As DataRowNew Joinee Added

        '    Dim checkbox As New CheckBox()
        '    checkbox.ID = "chkChecked1"
        '    '  AddHandler checkbox.CheckedChanged, AddressOf CheckedChaged
        '    checkbox.AutoPostBack = False

        '    checkbox.Checked = ViewState("checkboxGridviewState")
        '    If ViewState("postbackTrue") = False Then ' 26Mar2016that is when loaded for first time then checkd=True
        '        checkbox.Checked = True
        '    End If

        '    e.Row.Cells(0).Controls.Add(checkbox)

        'End If

        'If e.Row.RowType = DataControlRowType.Header Then
        '    Dim checkbox As New CheckBox()
        '    checkbox.ID = "chkChecked1"
        '    AddHandler checkbox.CheckedChanged, AddressOf MainFilter_CheckedChanged
        '    checkbox.AutoPostBack = True
        '    checkbox.EnableViewState = True

        '    checkbox.Checked = ViewState("checkboxGridviewState")
        '    If ViewState("postbackTrue") = False Then ' 26Mar2016that is when loaded for first time then checkd=True
        '        checkbox.Checked = True
        '    End If

        '    e.Row.Cells(0).Controls.Add(checkbox) 'rajkumar 21Mar2016 Done for Checkbox
        'End If

        '  ViewState("dynamicGrid") = True


    End Sub
    'Dim sSelectedWorkType As String = ""
    Protected Sub chbxlstWorktype_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs)
        For i As Integer = 0 To chbxlstWorktype.Items.Count - 1
            If (chbxlstWorktype.Items(i).Selected) Then
                SelectedWorkType += chbxlstWorktype.Items(i).Value + ","
            End If
        Next
        'SelectedWorkType = SelectedWorkType.Substring(0, Len(SelectedWorkType) - 1)
        'string name = "";
        'for (int i = 0; i < CheckBoxList1.Items.Count; i++)
        '{
        '    if (CheckBoxList1.Items[i].Selected)
        '    {
        '        name += CheckBoxList1.Items[i].Text + ",";
        '    }
        '}
        'TextBox1.Text = name;
    End Sub
    Protected Sub MainFilter_CheckedChanged(ByVal sender As Object, ByVal e As System.EventArgs)
        ' FillWeekRoster_CombineAll() 'rajkumar 21Mar2016 Added
        '   FillWeekRoster_CombineAll_2222() 'rajkumar 21Mar2016 Added

        Dim chk As CheckBox = CType(sender, CheckBox)
        ViewState("checkboxGridviewState") = chk.Checked ''that is true or false

        For j As Integer = 0 To gvDissiminate.Rows.Count - 1
            CType(gvDissiminate.Rows(j).FindControl("chkChecked1"), CheckBox).Checked = chk.Checked
        Next
    End Sub


    Private Sub GetAllSupervisors()
        Dim db As New DBAccess("CRM")
        Dim dt As New DataTable
        dt = db.ReturnTable("usp_GetAllSupervisors", , True)
        db = Nothing
        lblreportname.CurrentPage = "LH Worktype Access"
        If dt.Rows.Count > 0 Then
            Dim finalName As DataColumn = New DataColumn
            With finalName
                .DataType = System.Type.GetType("System.String")
                .ColumnName = "AN"
                .Expression = "AgentName + ' [' + AgentId + ']'"
            End With
            With dt.Columns
                .Add(finalName)
            End With
            dt.AcceptChanges()
        End If
        dt = Nothing
    End Sub

    'Private Sub GetAssignedWorkTypeLH(ByVal CampaignId As String)
    '    Try
    '        Dim db As New DBAccess("CRM")
    '        Dim dt As New DataTable
    '        db.slDataAdd("Campaignid", CampaignId)
    '        dt = db.ReturnTable("[usp_getWorktypeLH]", , True)
    '        db = Nothing
    '        chbxlstAssignedWorktype.DataSource = dt

    '        'Dim dr As DataRow
    '        'dr = dt.NewRow
    '        'dr("WorktypeDesc") = "All"
    '        'dr("WorktypeId") = 0
    '        'dt.Rows.Add(dr)
    '        'db = Nothing


    '        chbxlstAssignedWorktype.DataTextField = "WorktypeDesc"
    '        chbxlstAssignedWorktype.DataValueField = "WorktypeId"
    '        chbxlstAssignedWorktype.DataBind()

    '        If ProcessID <> -1 Then
    '            chbxlstAssignedWorktype.Items.FindByValue(ProcessID).Selected = True

    '        End If

    '    Catch ex As Exception
    '        'gvDissiminate.Enabled = False

    '    End Try
    'End Sub

    Private Sub GetWorkTypeLH(ByVal CampaignId As String)
        Try
            Dim db As New DBAccess("CRM")
            Dim dt As New DataTable
            db.slDataAdd("Campaignid", CampaignId)
            dt = db.ReturnTable("[usp_getWorktypeLH]", , True)
            db = Nothing
            chbxlstWorktype.DataSource = dt

            'Dim dr As DataRow
            'dr = dt.NewRow
            'dr("WorktypeDesc") = "All"
            'dr("WorktypeId") = 0
            'dt.Rows.Add(dr)
            'db = Nothing


            chbxlstWorktype.DataTextField = "WorktypeDesc"
            chbxlstWorktype.DataValueField = "WorktypeId"
            chbxlstWorktype.DataBind()

            If ProcessID <> -1 Then
                chbxlstWorktype.Items.FindByValue(ProcessID).Selected = True

            End If

        Catch ex As Exception
            'gvDissiminate.Enabled = False

        End Try
    End Sub

    Dim dtDissiminate As DataTable
    Private Sub GetSupervisorsbasedonWorkType(WorkTypeID As String)
        'GetProcess()
        Try


            dtDissiminate = New DataTable
            Dim db As New DBAccess("Disseminate")
            ' db.slDataAdd("ProcessId", ProcessID)
            db.slDataAdd("WorkTypeID", WorkTypeID.Substring(0, Len(WorkTypeID) - 1))
            dtDissiminate = db.ReturnTable("usp_getSupervisorsbasedWorktype", , True)
            gvDissiminate.DataSource = dtDissiminate
            gvDissiminate.DataBind()
            db = Nothing


        Catch ex As Exception

            'gvDissiminate.Enabled = False

        End Try
    End Sub
#End Region

#Region "======== EVENT =========="


    Protected Sub chkCanAmend_CheckedChanged(ByVal sender As Object, ByVal e As System.EventArgs)
        Dim chk As CheckBox = CType(sender, CheckBox)
        Dim gvr As GridViewRow = CType(chk.NamingContainer, GridViewRow)
        If (gvr IsNot Nothing) Then
            Dim cmpID As Integer = gvDissiminate.DataKeys(gvr.RowIndex)("CampaignID").ToString
            Dim CmpName As String = gvDissiminate.DataKeys(gvr.RowIndex)("Name").ToString
            Dim ChkVal As Integer = Convert.ToInt32(chk.Checked)
            AmendmentAccess(cmpID, CmpName, LanID, ChkVal)
        End If
    End Sub



#End Region

#Region "======= FUNCTIONS ========="

    Private Sub QuestAnsMaps_UserRights(ByVal CmpaignID As Integer, ByVal QuestID As Integer, ByVal AnsID As Integer, ByVal Worktype As String, ByVal AgentId As String)
        Dim db As New DBAccess
        Dim rptAccess As Boolean
        rptAccess = db.ReturnValue("SELECT Count(*) FROM tbl_Config_QuestAnsMaps_UserRights WHERE AgentID='" & AgentId.ToUpper & "' and CampaignID =" & CampaignID & " and QuestID =" & QuestID & " and AnsID =" & AnsID & "", False)
        db = Nothing
        Dim db1 As New DBAccess
        If rptAccess = False Then
            db1.slDataAdd("CmpaignID", CampaignID)
            db1.slDataAdd("QuestID", QuestID)
            db1.slDataAdd("AnsID", AnsID)
            db1.slDataAdd("AgentID", AgentId)
            db1.InsertinTable("tbl_Config_QuestAnsMaps_UserRights")
            SuccessMessage(" [ " & Worktype & " ] " & " Worktype Access has been Given ")
        Else
            Dim strQuery = "DELETE FROM Tbl_Report_UserRights WHERE AgentID='" & AgentId & "' and CampaignID =" & CampaignID & " and QuestID =" & QuestID & " and AnsID =" & AnsID & ""
            db1.ReturnValue(strQuery)
            SuccessMessage(" [ " & Worktype & " ] " & " Worktype Access has been Removed")
        End If
        db1 = Nothing
    End Sub
    Private Sub ProcessAccess(ByVal cmpId As Integer, ByVal cmpName As String, ByVal processID As Integer, ByVal AgentId As String)
        Dim db As New DBAccess("CRM")
        Dim dbCmp As New DBAccess("CRM")
        Dim ChkCmpId As Boolean
        ChkCmpId = dbCmp.ReturnValue("SELECT Count(*) FROM Tbl_data_UserRights WHERE AgentID='" & AgentId & "' and CampaignID=" & cmpId & "", False)
        dbCmp = Nothing
        If ChkCmpId = False Then
            db.slDataAdd("CampaignID", cmpId)
            db.slDataAdd("ProcessID", processID)
            db.slDataAdd("AgentID", AgentId)
            db.slDataAdd("CanUpdate", 0)
            db.slDataAdd("CanUpload", 0)
            db.slDataAdd("IsSupervisor", 0)
            db.slDataAdd("IsManager", 0)
            db.slDataAdd("CanSeeReports", 0)
            db.slDataAdd("CanSeeRecordings", 0)
            db.InsertinTable("Tbl_data_UserRights")
            SuccessMessage(" [ " & cmpName & " ] " & " Process Access has been Given ")
        Else
            db.ReturnValue("DELETE FROM Tbl_data_UserRights WHERE AgentID='" & AgentId & "' AND CampaignID= " & cmpId & "", False)
            SuccessMessage(" [ " & cmpName & " ] " & " Process Access has been Removed")
        End If
        db = Nothing
    End Sub



    Private Sub AmendmentAccess(ByVal cmpId As Integer, ByVal cmpName As String, ByVal UserName As String, ByVal CheckedVal As Integer)
        Dim dbDate As New DBAccess("CRM")
        Dim GrantDate As DateTime = dbDate.ReturnValue("Select GetDate()", False)
        dbDate = Nothing
        Dim db As New DBAccess("CRM")
        Dim AmendAccess As Boolean
        AmendAccess = db.ReturnValue("SELECT count(*) FROM tbl_AdminRights WHERE camp_id=" & cmpId & " AND [user]='" & UserName & "'", False)
        db = Nothing
        Dim dbAmend = New DBAccess("CRM")
        If AmendAccess = False Then
            dbAmend.slDataAdd("Process", cmpName)
            dbAmend.slDataAdd("User", UserName)
            dbAmend.slDataAdd("Active", 1)
            dbAmend.slDataAdd("GrantedBy", UserID)
            dbAmend.slDataAdd("GrantedOn", GrantDate)
            dbAmend.slDataAdd("IsSuperVisor", 0)
            dbAmend.slDataAdd("btUpdate", 1)
            dbAmend.slDataAdd("camp_id", cmpId)
            dbAmend.InsertinTable("tbl_AdminRights")
            SuccessMessage("Amendment Tool Access has been given")
        Else
            dbAmend.slDataAdd("Active", CheckedVal)
            dbAmend.UpdateinTable("tbl_AdminRights", "camp_id=" & cmpId & " AND [user]='" & UserName & "'")
            SuccessMessage("Amendment Tool Access has been Removed")
        End If
        dbAmend = Nothing

    End Sub

#End Region


#Region "===== UTILITY ====="

    Private Sub AlertMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMFail"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub

    Private Sub SuccessMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMSuccess"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub

#End Region


    Public Function GetUnique(ByVal sStringToUse As String, Optional ByVal sSeperator As String = ",", Optional ByVal LimitWords As Integer = 0) As String
        Dim sStrings() As String
        Dim sToRet As String = ""
        sStrings = sStringToUse.Split(sSeperator)
        Dim i As Integer = 0
        For Each s As String In sStrings
            Dim sTrimed As String = s.Trim()
            If Not (LimitWords < 1 OrElse i < LimitWords) Then Exit For
            If sToRet.IndexOf(sTrimed, StringComparison.CurrentCultureIgnoreCase) < 0 Then
                i += 1
                sToRet &= sTrimed & ","
            End If
        Next
        If sToRet.Length > 0 Then
            Return sToRet.ToString().Substring(0, sToRet.Length - 1)
        Else
            Return ""
        End If
    End Function

    Protected Sub btnSave_Click(sender As Object, e As EventArgs) Handles btnSave.Click

        Dim db As New DBAccess("CRM") ' Live

        Try

            db = New DBAccess("CRM")
            Dim dt As New DataTable

            Dim strSelectAgentIDWithName As String = ""
            Dim strSelectAgentID As String = ""
            Dim strSelectworkTypeID As String = ""
            Dim strSelectAgentAckStatus As String = ""

            'For Each row As GridViewRow In GridView1.Rows
            '    'Get the HobbyId from the DataKey property.
            '    Dim hobbyId As Integer = Convert.ToInt32(GridView1.DataKeys(row.RowIndex).Values(0))

            '    'Get the checked value of the CheckBox.
            '    Dim isSelected As Boolean = TryCast(row.FindControl("chkSelect"), CheckBox).Checked

            '    'Save to database.
            '    cmd.Parameters.Clear()
            '    cmd.Parameters.AddWithValue("@HobbyId", hobbyId)
            '    cmd.Parameters.AddWithValue("@IsSelected", isSelected)
            '    cmd.ExecuteNonQuery()
            'Next


            Dim CC As String = ""
            Dim CCUnique As String = ""
            Dim Too As String = ""

            Dim RowCounter As Integer = 0

            For Each row As GridViewRow In gvDissiminate.Rows

                'Get the checked value of the CheckBox.
                Dim isSelected As Boolean = TryCast(row.FindControl("cbxIsselected"), CheckBox).Checked

                If isSelected = True Then
                    Dim AIDs As String = Convert.ToString(gvDissiminate.DataKeys(row.RowIndex).Values(0))

                    db = New DBAccess("CRM")
                    db.slDataAdd("AgentId", AIDs)
                    dt = db.ReturnTable("usp_SupervisorEmails6", , True)
                    db = Nothing
                    CC = dt.Rows(0).Item("MailCC")
                    Too = dt.Rows(0).Item("MailTO")
                    '  MailUniqueCC = GetUnique(CC)
                    MailCC = MailCC + "," + CC
                    MailTo = MailTo + "," + Too
                    MailTo = MailTo.Replace(",,", ",")
                    MailCC = MailCC.Replace(",,", ",")
                    ' MailTo = MailTo.Substring(1)
                    'MailCC = MailCC.Substring(1)
                    ' MailUniqueCC = MailUniqueCC + "," + MailUniqueCC


                    strSelectAgentIDWithName = strSelectAgentIDWithName + "," + AIDs + "(" + Too.Substring(0, InStr(Too, "@") - 1) + ")"

                    'strSelectAgentIDWithName = strSelectAgentIDWithName + "(" + Too.Substring(0, InStr(Too, "@") - 1) + ")" + "," + AIDs + "(" + Too.Substring(0, InStr(Too, "@") - 1) + ")"
                    ' strSelectAgentIDWithName = strSelectAgentIDWithName + "," + AIDs + "(" + Too.Substring(0, InStr(Too, "@") - 1) + ")"
                    strSelectAgentID = strSelectAgentID + "," + AIDs
                    strSelectAgentAckStatus = strSelectAgentAckStatus + "-P"
                    strSelectAgentAckStatus = strSelectAgentAckStatus + "," + AIDs

                    Dim WtypeId As String = TryCast(row.FindControl("hdworkTypeID"), HiddenField).Value
                    ' CType(e.Row.Cells(1).FindControl("hfReportID"), HiddenField).Value)
                    strSelectworkTypeID = strSelectworkTypeID + "," + WtypeId

                End If
            Next
            MailTo = MailTo.Substring(1)
            MailCC = MailCC.Substring(1, Len(MailCC) - 1)
            MailUniqueCC = GetUnique(MailCC)

            strSelectAgentAckStatus = strSelectAgentAckStatus.Substring(3) + "-P"
            strSelectAgentID = strSelectAgentID.Substring(1)
            '  -P,NSS00109951-P,NSS62782-P,NSS00108340-P,NSS71279-P,NSS57118
            '  ,NSS00109951,NSS62782,NSS00108340,NSS71279,NSS57118

            If IsSave(strSelectworkTypeID, strSelectAgentID, strSelectAgentIDWithName.Substring(1), strSelectAgentID, strSelectAgentAckStatus) = True Then





                'db.slDataAdd("AgentId", strSelectAgentID.Substring(1, 8))
                'dt = db.ReturnTable("usp_SupervisorEmails6", , True)
                'db = Nothing
                'strCC = dt.Rows(0).Item("MailCC")
                'strTo = dt.Rows(0).Item("MailTO")

                'Dim strCCUnique As String = ""
                'strCCUnique = GetUnique(strCC)





            End If

            SuccessMessage("Disseminate Update  have been saved  selected Supervisors successfully !")

        Catch ex As Exception
            AlertMessage(ex.ToString)
            Exit Sub
        End Try
    End Sub

    Private Function IsSave(selWorkTypeIDs As String, selagentIDs As String, selagentIdswithName As String, selSupIds As String, selAckstatus As String) As Boolean

        Dim db As DBAccess
        Try

            ' If Validation() = True Then

            db = New DBAccess("Disseminate")


            db.slDataAdd("WorkType_IDs", selWorkTypeIDs)
            db.slDataAdd("Agent_Ids", selagentIDs)
            db.slDataAdd("Agent_Ids_Name", selagentIdswithName)
            db.slDataAdd("Sup_Ids", selSupIds)
            db.slDataAdd("UpdateBy", AgentID)
            db.slDataAdd("UpdateDesc", tbxDesc.Text)
            db.slDataAdd("WorkTypeUpdate", tbxworktypeUpdate.Text)
            db.slDataAdd("UpdateDescDetail", tbxDescDetail.Text)
            db.slDataAdd("UpdateReceiveDatetime", Convert.ToDateTime(txtFrom.Text))
            db.slDataAdd("AcknowledgmentDate", DBNull.Value.ToString())
            db.slDataAdd("Attachment_Id", 0)
            db.slDataAdd("AcknowledgmentStatus", 0)
            db.slDataAdd("AgentAcknowledgmentStatus", selAckstatus)
            db.slDataAdd("UpdateDate", DateAndTime.Now.ToString())
            db.slDataAdd("Flag", "True")
            db.Executeproc("usp_Insert_Data_Dissiminate")
            db = Nothing
            PopulateDissiminateData("True", 121)
            Return True
            'End If
        Catch ex As Exception
            'AlertMessage(ex.Message)
            Return False
        End Try

    End Function


    Private Sub PopulateDissiminateData(ByVal bflag As Boolean, ProcessID As String)
        Dim db As New DBAccess("Disseminate")
        Try
            Dim dt As DataTable = New DataTable
            db.slDataAdd("Flag", bflag)
            db.slDataAdd("ProcessId", ProcessID)
            dt = db.ReturnTable("usp_Get_Data_Dissiminate_1", , True)
            db = Nothing
            GridView1.DataSource = dt
            GridView1.DataBind()

        Catch ex As Exception
            Throw ex
        End Try
    End Sub

#Region "===== POP UP ===="


    Protected Sub btnUpload_Click(ByVal sender As Object, ByVal e As ImageClickEventArgs) Handles btnUpLoad.Click


        Dim FileName As String = String.Empty
        Dim FileSize As String = String.Empty
        Dim extension As String = String.Empty
        Dim FilePath As String = String.Empty

        If (FileUpload1.HasFile) Then

            Dim contentType As String = FileUpload1.PostedFile.ContentType
            extension = Path.GetExtension(FileUpload1.FileName)

            FileName = Path.GetFileName(FileUpload1.PostedFile.FileName)
            FileSize = FileName.Length.ToString() + " Bytes"
            FileUpload1.PostedFile.SaveAs(Server.MapPath("~/myupload/" + FileName.Trim()))
            FilePath = "~/myupload/" + FileName.Trim().ToString()



            Using fs As Stream = FileUpload1.PostedFile.InputStream
                Using br As BinaryReader = New BinaryReader(fs)

                    Dim bytes As Byte() = br.ReadBytes(Convert.ToInt32(fs.Length))

                    Dim db As New DBAccess("Disseminate")

                    db.slDataAdd("Name", FileName)
                    db.slDataAdd("ContentType", contentType)
                    db.slDataAdd("Data", bytes)
                    db.slDataAdd("DissemID", DissemId)
                    db.Executeproc("[usp_Save_Disseminate_Form_Attachments]")
                    db = Nothing

                    If System.IO.File.Exists(FilePath) Then
                        System.IO.File.Delete(FilePath)
                    End If


                End Using


            End Using


        Else

            Label1.Text = "No File Uploaded"





        End If

        ' Response.Redirect(Request.Url.AbsoluteUri)
    End Sub


    Private Sub OpenPopUp()
        ' lblEmpId.Text = txtOthers.Text.Trim
        Dim str As String
        str = "$('#DialogBackground').height($(document).height()-10);$('#DialogBackground').width($(window).width());$('#DialogBackground').css('visibility','visible');$('#PnlAttachFormAdd').css('visibility','visible'); $('#PnlAttachFormAdd').css('left',($(window).width() - $('#PnlAttachFormAdd').width())/2); "
        ScriptManager.RegisterStartupScript(Page, Page.GetType(), "Movedialog", str, True)
    End Sub



#End Region

    Protected Sub GridView1_RowCommand(sender As Object, e As GridViewCommandEventArgs) Handles GridView1.RowCommand
        If e.CommandName.ToLower = "delete" Then

            Dim index As Integer = Convert.ToInt32(e.CommandArgument)
            Dim iID As Integer = CType(GridView1.Rows(index).FindControl("ltrlID"), Literal).Text

            Dim db As DBAccess = New DBAccess("Disseminate")
            db.slDataAdd("ID", iID)
            db.slDataAdd("Flag", "False")
            db.Executeproc("usp_Deactivate_Disseminate")
            db = Nothing
            PopulateDissiminateData("True", 121)

            '   GetUYSTrackerData(dpSelectDate.yyyymmdd)

        ElseIf e.CommandName.ToLower = "upload2" Then

            Dim index As Integer = Convert.ToInt32(e.CommandArgument)
            DissemId = CType(GridView1.Rows(index).FindControl("ltrlID"), Literal).Text


            Dim db As New DBAccess("Disseminate")




            Dim dt1 As New DataTable
            db.slDataAdd("DissemID", DissemId)
            dt1 = db.ReturnTable("[usp_Get_Disseminate_Form_Attachments]", , True)


            If dt1.Rows.Count > 0 Then


                GridView2.DataSource = dt1
                GridView2.DataBind()




            End If
            OpenPopUp()

        ElseIf e.CommandName.ToLower = "sendupdate" Then

            Dim index As Integer = Convert.ToInt32(e.CommandArgument)
            Dim iID As Integer = CType(GridView1.Rows(index).FindControl("ltrlID"), Literal).Text
            Dim UpdatedescFrom As String = CType(GridView1.Rows(index).FindControl("lblUpdateDesc"), Label).Text
            Dim UpdatedescDetail As String = CType(GridView1.Rows(index).FindControl("lblUpdateDescDetail"), Label).Text
            Dim WorktypeUpdate As String = CType(GridView1.Rows(index).FindControl("LblworkTypeupdate"), Label).Text
            Dim AgentIds As String = CType(GridView1.Rows(index).FindControl("Aids"), HiddenField).Value

            ' Split string based on comma
            Dim AIDs As String() = AgentIds.Split(New Char() {","c})

            ' Use For Each loop over words and display them
            Dim db As New DBAccess("CRM")
            Dim dt As New DataTable
            Dim BCC As String
            Dim CC As String
            Dim Too As String
            Dim AID As String
            For Each AID In AIDs
                'Console.WriteLine(word)


                db = New DBAccess("CRM")
                db.slDataAdd("AgentId", AID)
                dt = db.ReturnTable("usp_SupervisorEmails22", , True)
                db = Nothing
                BCC = dt.Rows(0).Item("MailBCC")
                CC = dt.Rows(0).Item("MailCC")
                Too = dt.Rows(0).Item("MailTO")


                Dim dbclient As New DBAccess("CRM")
                Dim dt2 As New DataTable
                dt2 = dbclient.ReturnTable("select campaignid from crm.dbo.tbl_agentMaster where Agentid='" & AID & " '", True)
                CampaignID2 = dt2.Rows(0).Item("campaignid")
                dbclient = Nothing
                dt2 = Nothing

                If CampaignID2 = 36 Then
                    MailTo2 = MailTo2 + "," + CC + "," + System.Configuration.ConfigurationManager.AppSettings("KPACC")
                End If

                '  MailUniqueCC = GetUnique(CC)
                MailTo2 = MailTo2 + "," + CC
                MailCC2 = MailCC2 + "," + Too
                MailTo2 = MailTo2.Replace(",,", ",")
                MailCC2 = MailCC2.Replace(",,", ",")
            Next



            MailTo2 = MailTo2.Substring(1)
            MailCC2 = MailCC2.Substring(1, Len(MailCC2) - 1)
            MailUniqueCC2 = GetUnique(MailCC2)

            Dim strFrom As String = System.Configuration.ConfigurationManager.AppSettings("FROM")
            Dim MailSubject As String = "Update Dated" & "_" & DateAndTime.Now.ToString("dd-MMM-yyyyHHmm") & "_" & WorktypeUpdate.Trim()
            Dim strMailBody As String = ""
            strMailBody += "<html xmlns='http://www.w3.org/1999/xhtml'>"
            strMailBody += "<body style='font-family: Verdana; font-size: .8em'>"
            strMailBody += " Hi There,:<br /><br />"

            strMailBody += " Hope Everything going well:<br /><br />"
            strMailBody += " We are writing to you  following updates was receievd from " & UpdatedescFrom.Trim() & "<br /><br />" & UpdatedescDetail.Trim() & "<br /><br />"
            strMailBody += " Please read the update and acknowledge it by clicking on below link :<br /><br />"

            strMailBody += " https://termsmonitor.coforge.com/SupervisorsTool/%5ELHDisseminationAcknowledge :<br /><br />"

            'strMailBody += "<table border='1' width='90%' style='border: 1px solid; border-collapse: collapse; font-family: Verdana; font-size: .8em'>"
            'strMailBody += "<tr bgcolor='#B8CCE4'>"
            'strMailBody += "<td align='center'><b>Emp. Code</b></td>"
            'strMailBody += "<td align='center'><b>Emp. Name</b></td>"
            'strMailBody += "<td align='center'><b>Designation</b></td>"
            'strMailBody += "<td align='center'><b>Process</b></td>"
            'strMailBody += "<td align='center'><b>D.O.J</b></td>"
            'strMailBody += "<td align='center'><b>Supervisor</b></td>"
            'strMailBody += "<td align='center'><b>Added By</b></td>"
            'strMailBody += "</tr>"
            'strMailBody += "<tr >"
            'strMailBody += "<td align='center'>" & txtPrefix.Text.Trim & txtEmpID.Text.Trim & "</td>"
            'strMailBody += "<td align='center'>" & txtFirstName.Text.Trim & " " & txtLastName.Text.Trim & "</td>"
            'strMailBody += "<td align='center'>" & cmbRole.SelectedItem.Text.Trim & "</td>"
            'strMailBody += "<td align='center'>" & cmbProcess.SelectedItem.Text.Trim & "</td>"
            'strMailBody += "<td align='center'>" & txtDate.Text.Trim & "</td>"
            'strMailBody += "<td align='center'>" & cmbSupervisor.SelectedItem.Text.Trim & "</td>"
            'strMailBody += "<td align='center'>" & UserName & "</td>"
            'strMailBody += "</tr>"
            'strMailBody += "</table>"


            strMailBody += "<br /><br />"

            strMailBody += "Thank you !!"



            strMailBody += "</body>"
            strMailBody += "</html>"

            ''Live One
            Common.SMTPSendMail(MailTo2, MailSubject, "New Update Received  <" & strFrom & ">", strMailBody, MailUniqueCC2, System.Configuration.ConfigurationManager.AppSettings("WSR_PIP_ProcessManager"))

        End If

    End Sub

    Protected Sub GridView1_RowDataBound(sender As Object, e As GridViewRowEventArgs) Handles GridView1.RowDataBound
        Try
            If e.Row.RowType = DataControlRowType.DataRow Then


                Dim iId As Integer = CType(e.Row.FindControl("ltrlID"), System.Web.UI.WebControls.Literal).Text
                Dim ddl1 As WebControls.DropDownList = CType(e.Row.FindControl("ddlCurrentAgentStatus"), WebControls.DropDownList)

                If (ddl1 IsNot Nothing) Then

                    Dim db As New DBAccess("Disseminate")
                    Dim dt As DataTable
                    db.slDataAdd("ID", iId)
                    dt = db.ReturnTable("[usp_Get_Data_Dissiminate_Acks_Status]", , True)
                    Dim dr As DataRow
                    dr = dt.NewRow
                    dr("Status") = "--"
                    dr("Status") = "0"
                    dt.Rows.Add(dr)
                    db = Nothing
                    db = Nothing
                    ddl1.DataTextField = "Status"
                    ddl1.DataValueField = "Status"
                    ddl1.DataSource = dt
                    ddl1.DataBind()
                    ddl1.Items.FindByValue(0).Selected = True


                End If

                Dim ddl2 As WebControls.DropDownList = CType(e.Row.FindControl("ddlAgentIdsWithName"), WebControls.DropDownList)
                If (ddl2 IsNot Nothing) Then
                    Dim db As New DBAccess("Disseminate")
                    Dim dt2 As DataTable
                    db.slDataAdd("ID", iId)
                    dt2 = db.ReturnTable("[usp_Get_Data_Dissiminate_AgentIDs_Name]", , True)
                    db = Nothing
                    Dim Names As String() = dt2.Rows(0)(0).ToString().Split(New Char() {","c})
                    Dim dt3 As New DataTable
                    dt3.Columns.Add("agent_ids_name", GetType(String))
                    ' Loop through result strings with For Each.
                    For Each Name As String In Names

                        Dim dr As DataRow
                        dr = dt3.NewRow
                        dr("agent_ids_name") = Name
                        dt3.Rows.Add(dr)
                       

                    Next
                    ddl2.DataTextField = "agent_ids_name"
                    ddl2.DataValueField = "agent_ids_name"

                    ddl2.DataSource = dt3
                    ddl2.DataBind()
                  
                End If


                Dim ddl3 As WebControls.DropDownList = CType(e.Row.FindControl("ddlAgentAcknowledgmentStatus"), WebControls.DropDownList)
                If (ddl3 IsNot Nothing) Then
                    Dim db As New DBAccess("Disseminate")
                    Dim dt2 As DataTable
                    db.slDataAdd("ID", iId)
                    dt2 = db.ReturnTable("[usp_Get_Data_Dissiminate_AgentAckStatus]", , True)
                    db = Nothing
                    Dim Names As String() = dt2.Rows(0)(0).ToString().Split(New Char() {","c})
                    Dim dt3 As New DataTable
                    dt3.Columns.Add("AgentAckStatus", GetType(String))
                    ' Loop through result strings with For Each.
                    For Each Name As String In Names

                        Dim dr As DataRow
                        dr = dt3.NewRow
                        dr("AgentAckStatus") = Name
                        dt3.Rows.Add(dr)


                    Next
                    ddl3.DataTextField = "AgentAckStatus"
                    ddl3.DataValueField = "AgentAckStatus"

                    ddl3.DataSource = dt3
                    ddl3.DataBind()

                End If






                'Dim rawData As String = CType(e.Row.FindControl("lblAcknowledgedDate"), System.Web.UI.WebControls.Label).Text

                'If Not (rawData = "") Then
                '    ' Dim btn2 As WebControls.ImageButton = CType(e.Row.FindControl("imgDelete"), WebControls.ImageButton)
                '    Dim btn3 As WebControls.ImageButton = CType(e.Row.FindControl("imgEdit"), WebControls.ImageButton)

                '    If (btn3 IsNot Nothing) Then
                '        btn3.Visible = False
                '    End If

                'End If

                'Dim rawData As Boolean = CType(e.Row.FindControl("ltrID"), System.Web.UI.WebControls.Literal).Text
                'If (rawData = True) Then
                '    Dim btn2 As WebControls.ImageButton = CType(e.Row.FindControl("imgDelete"), WebControls.ImageButton)
                '    Dim btn3 As WebControls.ImageButton = CType(e.Row.FindControl("imgEdit"), WebControls.ImageButton)
                '    If (btn2 IsNot Nothing) Then
                '        btn2.Visible = False
                '    End If

                '    If (btn3 IsNot Nothing) Then
                '        btn3.Visible = False
                '    End If

                'End If
            End If

        Catch ex As Exception
            AlertMessage("Error in gvRotDataDetail_RowDataBound. description :- " & ex.Message)
        End Try
    End Sub

    Protected Sub GridView1_RowDeleting(sender As Object, e As GridViewDeleteEventArgs) Handles GridView1.RowDeleting

    End Sub
    'Public Event TreeNodeCheckChanged As TreeNodeEventHandler

    'Protected Sub TreeView1_TreeNodeCheckChanged(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.TreeNodeEventArgs) Handles TreeView1.TreeNodeCheckChanged
    '    Dim rptID As Int16 = e.Node.Value
    '    Dim rptname As String = e.Node.Text
    '    ReportAccess(rptID, rptname, AgentID)
    'End Sub
    'Protected Sub LinksTreeView_CheckChanged(ByVal sender As Object, ByVal e As TreeNodeEventArgs)
    '    Dim rptID As Int16 = e.Node.Value
    '    Dim rptname As String = e.Node.Text
    '    ReportAccess(rptID, rptname, AgentID)
    'End Sub

    Protected Sub GridView1_RowEditing(sender As Object, e As GridViewEditEventArgs) Handles GridView1.RowEditing


    End Sub

    Protected Sub DownloadFile(ByVal ID As Integer)


        Try
            Dim fileName As String = "", contentType As String = ""
            Dim bytes As Byte()
            Dim db As New DBAccess("Disseminate")
            Dim dt As DataTable
            db.slDataAdd("Id", ID)
            dt = db.ReturnTable("[usp_Get_Disseminate_Form_Attachment]", "", True)
            db = Nothing
            If dt.Rows.Count > 0 Then
                bytes = DirectCast(dt.Rows.Item(0)("Data"), Byte())
                contentType = dt.Rows.Item(0)("ContentType").ToString()
                fileName = dt.Rows.Item(0)("Name").ToString()
            End If
            Response.Clear()
            Response.Buffer = True
            Response.Charset = ""
            Response.Cache.SetCacheability(HttpCacheability.NoCache)
            Response.ContentType = contentType
            Response.AppendHeader("Content-Disposition", "attachment; filename=" + fileName)
            Response.BinaryWrite(bytes)
            Response.Flush()
            Response.End()
        Catch ex As Exception
            AlertMessage(ex.Message)
        End Try

    End Sub
    Protected Sub GridView2_RowCommand(sender As Object, e As GridViewCommandEventArgs) Handles GridView2.RowCommand
        Try
            If e.CommandName.ToLower = "download" Then
                Dim index As Integer = Convert.ToInt32(e.CommandArgument)

                DownloadFile(index)



            End If
        Catch ex As Exception
            AlertMessage(ex.Message)
        End Try
    End Sub
End Class
