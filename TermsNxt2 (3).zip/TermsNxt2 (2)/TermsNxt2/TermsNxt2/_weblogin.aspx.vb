﻿
Imports System.DirectoryServices
Imports System.IO
Imports System.Security.Cryptography


Imports LibFolder.TermsNxt2

Public Class _weblogin
        Inherits System.Web.UI.Page
        Private m_UserId As String
        Private DomainName As String = System.Net.NetworkInformation.IPGlobalProperties.GetIPGlobalProperties().DomainName

        Property Agentid() As String
            Get
                Return ViewState("AgentId")
            End Get
            Set(ByVal value As String)
                ViewState("AgentId") = value
            End Set
        End Property

        'Private Sub FillCaptcha()
        '    Try


        '        Dim random As Random = New Random()
        '        Dim combination As String = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz"

        '        Dim captcha As StringBuilder = New StringBuilder()


        '        For i As Integer = 0 To 6
        '            captcha.Append(combination(random.Next(combination.Length)))
        '            Session("captcha") = captcha.ToString()
        '            imgCaptcha.ImageUrl = "GenerateCaptcha.aspx?" + DateTime.Now.Ticks.ToString()
        '        Next

        '       catch  ex As Exception

        '        Throw ex
        '    End Try

        'End Sub
        Protected Sub btnLogin_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnLogin.Click
            PanelError.Visible = False
            Agentid = txtUserID.Text.Trim
            If CheckPassword() Then
            Else

                com.nss.DBAccess.DBAccess.process = "Report"
                Dim db As New com.nss.DBAccess.DBAccess
                db.slDataAdd("userid", txtUserID.Text.Trim)
                db.slDataAdd("password", RC4.Encrypt(txtUserID.Text.Trim, txtPassword.Text.Trim))
                'db.slDataAdd("password", RC5.Decrypt(txtUserID.Text.Trim, txtPassword.Text.Trim))
                Dim dr As System.Data.DataRow = db.ReturnRow("usp_IsUserValid", True)
                'Dim dr As System.Data.DataRow = db.ReturnRow("select Agentid,AgentName,campaignid from tbl_agentmaster where lanid='" & txtUserID.Text & "'")
                db = Nothing
                If dr Is Nothing Then
                    lblerror.Text = "The username or password you entered is incorrect."
                    PanelError.Visible = True
                    Return
                End If


                '@Restrict LH Amadeus User
                'Dim strAmadeus As String = ""
                'Dim bln As Boolean
                'strAmadeus = System.Configuration.ConfigurationManager.AppSettings("Amadeuslst")
                'If Not dr Is Nothing Then
                '    bln = strAmadeus.Contains(dr("AgentID"))
                'End If
                'If bln = True Then
                '    lblerror.Text = "Amadeus User is not authorised to Use Web Tracker."
                '    PanelError.Visible = True
                '    Return
                'End If


                '@Captcha Image
                'If (Me.Session("Text") IsNot Nothing) Then
                '    ' If (txtimgcode.Text = Session("Text").ToString()) Then

                '    Session("Lanid") = HttpUtility.HtmlEncode(txtUserID.Text.Trim)
                '    Session("CampaignID") = dr("campaignid")
                '    Session("AgentID") = dr("AgentID")
                '    Session("UserID") = dr("AgentID")
                '    Session("username") = dr("AgentName")
                '    Session("IsVerifier") = dr("btVerifier")
                '    FormsAuthentication.RedirectFromLoginPage(Session("AgentID"), False)
                'Else

                '    lblerror.Text = "image code is not valid."
                '    PanelError.Visible = True
                '    Return
                '    'End If
                'End If

                '@Without Captcha Image
                Session("Lanid") = HttpUtility.HtmlEncode(txtUserID.Text.Trim)
                Session("CampaignID") = dr("campaignid")
                Session("AgentID") = dr("AgentID")
                Session("UserID") = dr("AgentID")
                Session("username") = dr("AgentName")
                Session("IsVerifier") = dr("btVerifier")
                '  FormsAuthentication.RedirectFromLoginPage(Session("AgentID"), False)
                Response.Redirect("~/Data/^Sitemap")
            End If
        End Sub

        ' // Function to generate random string with Random class.
        Private Function GenerateRandomCode() As String
            Dim r As New Random()
            Dim s As String = ""


            For j As Integer = 0 To 5
                Dim i As Integer = r.Next(3)
                Dim ch As Integer
                Select Case (i)
                    Case 1
                        ch = r.Next(0, 9)
                        s = s + ch.ToString()
                    Case 2
                        ch = r.Next(65, 90)
                        s = s + Convert.ToChar(ch).ToString()

                    Case 3
                        ch = r.Next(97, 122)
                        s = s + Convert.ToChar(ch).ToString()

                    Case Else
                        ch = r.Next(97, 122)
                        s = s + Convert.ToChar(ch).ToString()

                End Select

                r.NextDouble()
                r.Next(100, 1999)

            Next

            'If j >= 5 AndAlso j <= 8 Then
            '    Continue For
            'End If


            Return s
        End Function




        'Public Sub ImageRefresh()

        '    Dim di As New System.IO.DirectoryInfo(Server.MapPath("~/Images/"))

        '    For Each fi As FileInfo In di.GetFiles()
        '        fi.Delete()
        '    Next

        '    ' // Create a random code and store it in the Session object.
        '    Session("CaptchaImageText") = GenerateRandomCode()


        '    ' // Create a CAPTCHA image using the text stored in the Session object.
        '    Dim ci As RandomImage
        '    ci = New RandomImage(Me.Session("CaptchaImageText").ToString(), 300, 75)

        '    Me.Response.Clear()
        '    Me.Response.ContentType = "image/jpeg"

        '    ci.Image.Save(Server.MapPath("~\Images\Test.jpg"), ImageFormat.Jpeg)
        '    ci.Dispose()
        '    Me.Response.End()

        'End Sub

        Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        'HumanMessage.Style.Item("visibility") = "hidden"
        'If Not IsPostBack Then
        '    If Request.QueryString("web") = "true" Then Return
        '    If RedirectToWinAuth() Then
        '        Return
        '    End If
        'End If


        'If Not IsPostBack Then
        '    Dim UC As New UserControl
        '    Dim imgUC As New System.Web.UI.WebControls.Image
        '    UC = Page.FindControl("~/_assets/usrcontrol/Cimage.ascx")
        '    imgUC = UC.FindControl("Image1")
        '    imgUC.ImageUrl = "Test.jpg"
        'End If


        'If Not IsPostBack Then
        'FillCaptcha()
        'End if


    End Sub

    Public Function Authenticate() As Boolean
            'Dim str As String = My.User.CurrentPrincipal.Identity.Name
            'If str.Contains("\") Then
            '    str = str.Substring(str.LastIndexOf("\") + 1)
            'End If

            If Session("UserID") Is Nothing Then

                ' If Session("Lanid") = "" Then
                Session("Lanid") = Mid(Request.ServerVariables("LOGON_USER"), InStr(Request.ServerVariables("LOGON_USER"), "\") + 1, Len(Request.ServerVariables("LOGON_USER")))
                ' Session("Lanid") = Environment.UserName

                'End If
                com.nss.DBAccess.DBAccess.process = "Report"
                Dim db As New com.nss.DBAccess.DBAccess
                'Dim dr As System.Data.DataRow = db.ReturnRow("select Agentid,AgentName,campaignid,btVerifier from tbl_agentmaster where lanid='" & Session("Lanid") & "' and active=1")
                If Session("Lanid") = "" Then
                    Session("Lanid") = "&&"
                End If
                db.slDataAdd("UserId", Session("Lanid"))
                ' db.slDataAdd("LanUser", Session("LanUser"))
                Dim dr As System.Data.DataRow = db.ReturnRow("usp_CheckTermsUser", True)
                db = Nothing

                If Not dr Is Nothing Then
                    Session("AgentID") = dr("AgentID")
                    Session("Campaignid") = dr("Campaignid")
                    Session("username") = dr("AgentName")
                    Session("UserID") = dr("AgentID")
                    Response.Write(Session("username"))
                    Response.Write(Session("Lanid"))
                    Return True
                Else
                    Return False
                End If
            End If

        End Function

        Private Function RedirectToWinAuth(Optional ByVal strInternal As String = "internal") As Boolean
            If strInternal = "external" Then
                '@original
                'To Return authenticate true and redirect to another page sitemap.aspx 
                'Response.Redirect(Request.RawUrl.Replace("weblogin", "winauth/winlogin"))

                If Authenticate() Then
                    'FormsAuthentication.RedirectFromLoginPage(Session("AgentID"), False)
                    Return True
                End If
            End If

            'Dim serverpath As String
            'If Request.Url.Host = "localhost" Then
            '    serverpath = HttpContext.Current.Request.ApplicationPath
            'Else
            '    ' serverpath = "http://termfeedback.niit-tech.com"
            '    serverpath = System.Configuration.ConfigurationManager.AppSettings("LiveServerPath")

            'End If

            RedirectToWinAuth = True
            Dim str As String
            Dim s As New System.Configuration.AppSettingsReader
            str = s.GetValue("Internal", System.Type.GetType("System.String"))
            If Regex.IsMatch(Request.UserHostAddress.ToString, str) Then
                Response.Redirect(Request.RawUrl.Replace("weblogin", "winauth/winlogin"))
                Return True
            Else
                RedirectToWinAuth = False
                Return False
            End If

        End Function



        Private Function AuthorizeThisUser(ByVal strUserID As String, strPwd As String) As Boolean

            Dim returnvalue As Boolean
            Try
                Dim dirEntry As System.DirectoryServices.DirectoryEntry
                Dim dirSearcher As System.DirectoryServices.DirectorySearcher
                dirEntry = New System.DirectoryServices.DirectoryEntry("LDAP://" & DomainName)

                dirEntry.AuthenticationType = AuthenticationTypes.Secure
                dirEntry.Username = strUserID
                dirEntry.Password = strPwd
                dirSearcher = New System.DirectoryServices.DirectorySearcher(dirEntry)

                If strUserID <> "" Then

                    dirSearcher.Filter = "(samAccountName=" & strUserID & ")"

                End If

                Dim DirectorySearchCollection As SearchResultCollection = dirSearcher.FindAll()
                If DirectorySearchCollection.Count = 0 Then 'return false if user isn't found

                    returnvalue = False

                Else

                    returnvalue = True

                End If

            Catch ex As Exception
                'Throw ex
                lblerror.Text = ex.Message '"The username or password you entered is incorrect for Window AD Authentication"
                PanelError.Visible = True
                Return False

            End Try


            Return returnvalue

        End Function

        Private Sub OpenDialog()
            Dim str As String
            str = "$('#DialogBackground').height($(document).height()-2);$('#DialogBackground').width($(window).width());$('#DialogBackground').css('visibility','visible');$('#PnlWinAuth').css('visibility','visible'); $('#PnlWinAuth').css('left',($(window).width() - $('#PnlWinAuth').width())/2); "
            ScriptManager.RegisterStartupScript(Page, Page.GetType(), "Movedialog", str, True)
        End Sub

        Protected Sub LinkButton1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles LinkButton1.Click

            'If RedirectToWinAuth("external") Then
            '    Return
            'End If


            m_UserId = Mid(Request.ServerVariables("LOGON_USER"), InStr(Request.ServerVariables("LOGON_USER"), "\") + 1, Len(Request.ServerVariables("LOGON_USER")))
            OpenDialog()
            tbxWinauthUserID.Text = m_UserId


        End Sub

        Protected Sub btnWinAuth_Click(sender As Object, e As EventArgs) Handles btnWinAuth.Click


            com.nss.DBAccess.DBAccess.process = "Report"
            Dim db As New com.nss.DBAccess.DBAccess
            db.slDataAdd("userid", tbxWinauthUserID.Text.Trim)

            Dim dr As System.Data.DataRow = db.ReturnRow("usp_IsUserValid2", True)

            db = Nothing
            If dr Is Nothing Then
                lblerror.Text = "The username  is not Existing On Terms.Please Call or Mail for Creation "
                PanelError.Visible = True
                Return
            End If

            If Not dr Is Nothing Then
                If ((tbxWinauthUserID.Text.Trim <> "") And (tbxwinauthPwd.Text.Trim <> "")) Then

                    If AuthorizeThisUser(tbxWinauthUserID.Text.Trim, tbxwinauthPwd.Text.Trim) Then

                        PanelError.Visible = False
                        lblerror.Text = ""

                        Session("Lanid") = HttpUtility.HtmlEncode(tbxWinauthUserID.Text.Trim)
                        Session("CampaignID") = dr("campaignid")
                        Session("AgentID") = dr("AgentID")
                        Session("UserID") = dr("AgentID")
                        Session("username") = dr("AgentName")
                        Session("IsVerifier") = dr("btVerifier")
                    'FormsAuthentication.RedirectFromLoginPage(Session("AgentID"), False)
                    Response.Redirect("~/Data/^Sitemap")

                Else
                        lblerror.Text = "The username or password you entered is incorrect for Window AD Authentication"
                        PanelError.Visible = True
                        Return
                        ' AlertMessage("The username or password you entered is incorrect for WinAuth")
                        'Dim msg As String = ""
                        'msg = "The username or password you entered is incorrect for WinAuth"
                        'ScriptManager.RegisterStartupScript(Me, Me.[GetType](), "message", "<script language='javascript'>alert('" + msg.Replace("'", "\'") + "');</script>", False)

                    End If
                Else


                    lblerror.Text = "The username or password you entered is incorrect for Window AD Authentication"
                    PanelError.Visible = True
                    Return

                End If


            End If

        End Sub

#Region " Change Password "
        Private Function CheckPassword() As Boolean
            Dim db As New com.nss.DBAccess.DBAccess("CRM")
            Dim strQuery As String
            If Agentid <> "" Then
                strQuery = "Select ISNULL(PassExpired,0) FROM dbo.tbl_AgentMaster where LanID='" & Agentid & "'"
            End If
            Dim returnvalue = db.ReturnValue(strQuery, False)
            db = Nothing
            If returnvalue = True Then
                Dim str As String
                str = "$('#DialogBackground').height($(document).height()-10);$('#DialogBackground').width($(window).width());$('#DialogBackground').css('visibility','visible');$('#PanelResetPWD').css('visibility','visible');" &
            " $('#PanelResetPWD').css('left',($(window).width() - $('#PanelResetPWD').width())/2); "
                ScriptManager.RegisterStartupScript(Page, Page.GetType(), "Movedialog", str, True)
                Return True
            Else
                Return False
            End If
        End Function
        Private Function Valid() As Boolean
            Dim returnvalue As Boolean
            If txtPass1.Text.Trim = txtPass2.Text.Trim Then returnvalue = True Else returnvalue = False
            If txtPass1.Text.Length >= 8 Then returnvalue = True Else returnvalue = False
            Return returnvalue
        End Function
        Protected Sub btnOK_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnOK.Click
            If Valid() Then
                Dim db As New com.nss.DBAccess.DBAccess("CRM")
                db.slDataAdd("userid", Agentid)
                db.slDataAdd("password", RC4.Encrypt(Agentid, txtPass1.Text.Trim))
                db.slDataAdd("oldpassword", RC4.Encrypt(Agentid, txtOldPass.Text.Trim))
                Dim dr As System.Data.DataRow = db.ReturnRow("usp_ChangePassword", True)
                db = Nothing
                If dr(0) < 1 Then
                    AlertMessage("Old password  incorrect.")
                    Return
                Else
                    SuccessMessage("Password Changed.")
                End If
            End If
        End Sub
#End Region

#Region " Utility "
        Private Sub AlertMessage(ByVal msg As String)
            lblHumanMessage.Text = msg
            HumanMessage.CssClass = "HMFail"
            HumanMessage.Style.Item("visibility") = "visible"
        End Sub

        Private Sub SuccessMessage(ByVal msg As String)
            lblHumanMessage.Text = msg
            HumanMessage.CssClass = "HMSuccess"
            HumanMessage.Style.Item("visibility") = "visible"
        End Sub
#End Region


        'Protected Sub btnRefresh_Click(sender As Object, e As EventArgs) Handles btnRefresh.Click
        '    FillCaptcha()
        'End Sub

    End Class
