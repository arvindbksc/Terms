﻿using Microsoft.VisualBasic;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using com.nss.DBAccess;
using System.Data.SqlClient;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Web.Services;
using System.Drawing;
using System.Globalization;
using System.Text.RegularExpressions;
using System.IO;
using System.Net;
using System.Web;

public partial class LicenseExpiryReports_ClientRenewalReport : System.Web.UI.Page
{
     string filename = string.Empty;
     string Attachment { get; set; }
    
    protected void Page_Load(object sender, EventArgs e)
    {
        HumanMessage.Style["visibility"] = "hidden";
        HumanMessage.Visible = false;
        if (!this.IsPostBack)
        {

            this.getuser();
          
            GetGridView();
            lblReportName.CurrentPage = "License Renewal Report";
           
            //HumanMessage.Style["visibility"] = "hidden";
            //HumanMessage.Visible = false;

        }
       // ScriptManager.GetCurrent(this.Page).RegisterPostBackControl(this.LinkButton1);
    }
    public void getuser()
    {
        if (Session["UserID"] == null)
        {
            if (User.Identity.Name.ToString().Contains("NSS\\"))
            {
                Session["Lanid"] = User.Identity.Name.ToString().Replace("NSS\\", "");
            }
            else
            {
                Session["Lanid"] = User.Identity.Name;
            }
            //if (string.IsNullOrEmpty(Session["Lanid"].ToString()))
            //{
            //    Session["Lanid"] = Convert.ToString()(Mid(Request.ServerVariables["LOGON_USER"], Strings.InStr(Request.ServerVariables["LOGON_USER"], "\\") + 1, Strings.Len(Request.ServerVariables("LOGON_USER"))));
            //}

            com.nss.DBAccess.DBAccess db = new com.nss.DBAccess.DBAccess();
            //Dim dr As System.Data.DataRow = db.ReturnRow("select Agentid,AgentName,campaignid,btVerifier from tbl_agentmaster where lanid='" & Session["Lanid"] & "' and active=1")
            db.slDataAdd("UserId", Session["Lanid"]);
            System.Data.DataRow dr = db.ReturnRow("usp_CheckTermsUser", true);
            db = null;
            if (dr == null)
            {
                Response.Write("There is some problem in authenticating your credentials. Please make sure you are authorized to use this website.");
                return;
            }
            Session["CampaignID"] = dr["campaignid"];
            Session["AgentID"] = dr["AgentID"];
            Session["UserID"] = dr["AgentID"];
            Session["username"] = dr["AgentName"];
            Session["IsVerifier"] = dr["btVerifier"];
            Response.Write(Session["username"]);
            Response.Write(Session["Lanid"]);
        }

        {

            HumanMessage.Style["visibility"] = "hidden";
            HumanMessage.Visible = false;
            if (!this.IsPostBack)
            {
                this.GetGridView();
                lblReportName.CurrentPage = "Client License Master";


            }

        }
    }
     


#region "---Events ---"

    protected void btnSave_Click(object sender, EventArgs e)
    {


        string type = "";

        try
        {
          
          
             if ((btnSave.Text == "Save"))
            {
                type = "ADD_RENEWDATE";
                lblHeader.Text = "RENEW LICENSE";
               //string str = Hid1.Value.ToString();
                SaveClientRenewDetailed(type, Hid1.Value);
            }


            GetGridView();



        }
        catch (Exception Ex)
        { }

    }

    public void SaveClientRenewDetailed(string Type, string ID)
    {
        try
        {

            DBAccess db = new DBAccess("CRM");
            DataTable dt = new DataTable();
            //Id = Hid1.Value;
       
            db.slDataAdd("ID", "");
            db.slDataAdd("DetailID", ID);
            db.slDataAdd("Type", Type);
            db.slDataAdd("IsActive", 1);
            db.slDataAdd("CreatedBy", Session["UserID"]);
            db.slDataAdd("CreatedDatetime", DateTime.Now);
            db.slDataAdd("UpdatedBy", "");
            db.slDataAdd("UpdatedDatetime", "");
            db.slDataAdd("Remarks", TxtRemarks.Text);
            db.slDataAdd("Remarks1", "");
            db.slDataAdd("Remarksint ", 0);
            db.slDataAdd("ClientID ", lblCID.Text);
            db.slDataAdd("RenewDate ", lblRdate.Text);
            db.slDataAdd("Attachment", hdnattach.Value);
            dt = db.ReturnTable("CMF_GET_ClientLicenseRenewal", "", true);

            db = null;
                if ((dt != null))
                {
                    switch ((dt.Rows[0]["MESSAGE_TYPE"].ToString()))
                    {
                        case "S":
                            SuccessMessage(dt.Rows[0]["MESSAGE"].ToString());
                            break;

                        case "E":
                            AlertMessage(dt.Rows[0]["MESSAGE"].ToString());
                            break;
                    }
                }
            
        }
        catch (Exception ex)
        {
            SuccessMessage(ex.ToString());
        }
    }

    protected void LinkButton1_Click(object args, EventArgs e)
    {
        
        try
        {
            string filePath = (args as LinkButton).CommandArgument;

            Response.ContentType = ContentType;
            Response.AppendHeader("Content-Disposition", "attachment; filename=" + Path.GetFileName(filePath));
            Response.WriteFile(filePath);
            Response.Flush();
            Response.End();
            //HttpContext.Current.ApplicationInstance.CompleteRequest();
        }
        catch (Exception ex)
        {
            AlertMessage(ex.ToString());
        }
      
        
    }

    private void GetGridView()
    {
        DBAccess db = new DBAccess("CRM");
        DataTable dt = default(DataTable);
        try
        {
          
            db.slDataAdd("ID", "");
            db.slDataAdd("Type", "SELECT");
            db.slDataAdd("IsActive", 1);
            db.slDataAdd("CreatedBy", "");
            db.slDataAdd("CreatedDatetime", DateTime.Now);
            db.slDataAdd("UpdatedBy", "");
            db.slDataAdd("UpdatedDatetime", "");
            db.slDataAdd("Remarks", "");
            db.slDataAdd("Remarks1", "");
            db.slDataAdd("Remarksint", 0);
            db.slDataAdd("RenewDate", "");
    

            dt = db.ReturnTable("CMF_GET_ClientLicenseRenewal", "", true);
            db = null;
            gdData.DataSource = dt;
            gdData.DataBind();
            if (dt.Rows.Count < 0)
            {
                AlertMessage("No Record Found!");
                
            }
            

        }
        catch (Exception ex)
        {
            //AlertMessage(ex.ToString);
        }
    }

    private void GetData(string ID)
    {
        DBAccess db = new DBAccess("CRM");
        DataTable dt = default(DataTable);
        try
        {
          
            db.slDataAdd("ID", ID);
            db.slDataAdd("Type", "SELECT_RENEW_DATA");
            db.slDataAdd("IsActive", "");
            db.slDataAdd("CreatedBy", Session["UserID"]);
            db.slDataAdd("CreatedDatetime", DateTime.Now);
            db.slDataAdd("UpdatedBy", "");
            db.slDataAdd("UpdatedDatetime", "");
            db.slDataAdd("Remarks", "");
            db.slDataAdd("Remarks1", "");
            db.slDataAdd("Remarksint ", 0);
            db.slDataAdd("RenewDate", "");
    


            dt = db.ReturnTable("CMF_GET_ClientLicenseRenewal", "", true);

            lblclient.Text = dt.Rows[0]["ClientName"].ToString();
            lblsc.Text = dt.Rows[0]["SourceCountry"].ToString();
            lblrc.Text = dt.Rows[0]["ReciepietCountry"].ToString();
            lbllkey.Text = dt.Rows[0]["LicenseNo"].ToString();
            lblRdate.Text = dt.Rows[0]["RenewDate"].ToString();
            //clientID = int.Parse(dt.Rows[0]["ClientID"].ToString());
            lblCID.Text = dt.Rows[0]["ClientID"].ToString();
            lblattachtext.Text = dt.Rows[0]["Attachment"].ToString();
            

        }
        catch (Exception ex)
        {
            //AlertMessage(ex.ToString);
        }
    }
    private void Reset()
    {
        try
        {


            TxtRemarks.Text = "";


        }
        catch (Exception ex)
        {
            AlertMessage(ex.Message);
        }
    }

    private bool Validation()
    {
        bool flag = true;

        
        
        if (string.IsNullOrEmpty(TxtRemarks.Text))
        {
            lblIsValidInput.Visible = true;
            lblIsValidInput.Text = "Please Enter Remarks";
            flag = false;
            TxtRemarks.BorderColor = System.Drawing.Color.Red;
            OpenDialog();
            return flag;
        }
        //else if (!Regex.IsMatch(TxtRemarks.Text,"^[a-zA-Z0-9]*$"))
        //{
        //    lblIsValidInput.Visible = true;
        //    lblIsValidInput.Text = "Please Enter Alphanumeric characters";
        //    flag = false;
        //    TxtRemarks.BorderColor = System.Drawing.Color.Red;
        //    OpenDialog();
        //    return flag;
        //}
        else
        {
            lblIsValidInput.Visible = false;
            TxtRemarks.BorderColor = System.Drawing.Color.Black;

        }


        return flag;
    }
   

  
    

    protected void OnPageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        gdData.PageIndex = e.NewPageIndex;
        gdData.DataBind();
        GetGridView();
    }

    
    #endregion


#region "---utility ---"
    private void AlertMessage(string msg)
    {
        lblHumanMessage.Text = msg;
        HumanMessage.CssClass = "HMFail";
        HumanMessage.Visible = true;
        lblHumanMessage.Visible = true;
        HumanMessage.Style["visibility"] = "visible";
        // HumanMessage.Style.Item("visibility") = "visible";

    }

    private void SuccessMessage(string msg)
    {
        lblHumanMessage.Text = msg;
        HumanMessage.CssClass = "HMSuccess";
        HumanMessage.Visible = true;
        lblHumanMessage.Visible = true;
        HumanMessage.Style["visibility"] = "visible";
        //HumanMessage.Item["visibility"].tostring() = "visible";

    }

    protected void HumanMsgbtn_Click(object sender, EventArgs e)
    {
        // HumanMessage.Style["visibility"].ToString() = "";
        HumanMessage.Visible = false;
        lblHumanMessage.Text = "";
        HumanMessage.Style["visibility"] = "";

    }

   #endregion


    private void OpenDialog()
    {
        string str = null;
        str = "$('#DialogBackground').height($(document).height()-5);$('#DialogBackground').width($(window).width());$('#DialogBackground').css('visibility','visible');$('#PanelIDPForm').css('visibility','visible');" + " $('#PanelIDPForm').css('left',($(window).width() - $('#PanelIDPForm').width())/2); ";
        ScriptManager.RegisterStartupScript(Page, Page.GetType(), "Movedialog", str, true);
    }




#region "---Grid Events ---"
    protected void gdData_RowEditing(object sender, GridViewEditEventArgs e)
    {
        btnSave.Text = "Update";
        int index = Convert.ToInt32(e.NewEditIndex);
        hdnPanelRoleprocessMapid.Value = ((System.Web.UI.WebControls.HiddenField)gdData.Rows[index].FindControl("hdnID")).Value;
        string ID = hdnPanelRoleprocessMapid.Value;
        GetData(ID);
        OpenDialog();
    }

    protected void gdData_RowCommand(object sender, GridViewCommandEventArgs e)
    {

        try
        {
            if (e.CommandName.ToLower() == "edit")
            {
                btnSave.Text = "Update";
                lblHeader.Text = "UPDATE CLIENT LICENSE RENEW DETAILS"; 
                OpenDialog();
               
            }


            else if (e.CommandName == "Download")
            {
                
            }
            else if (e.CommandName == "Renew")
            {
                int index = Convert.ToInt32(e.CommandArgument);
                GridViewRow grd = gdData.Rows[index];
                string Id = (grd.FindControl("ID")).ToString();                      
                GetData(Id);
                OpenDialog();
            }
        }
        catch (Exception ex)
        {
            AlertMessage(ex.Message);
        }

    }

    protected void ImgRenew_Click(object sender, EventArgs e)
    {
        ImageButton Imgbtn = (ImageButton)sender;
        GridViewRow gdrow = (GridViewRow)Imgbtn.NamingContainer;        
        Hid1.Value = gdData.DataKeys[gdrow.RowIndex].Values[0].ToString();
        string ID = Hid1.Value;
        GetData(ID);
        OpenDialog();

    }

  
    #endregion


    protected void btnUpload_Click(object sender, EventArgs e)
    {
        string filename = "";
        string filepath = "";

        //filename = fileUpload1.FileName.ToString();
        filename = Path.GetFileName(fileUpload1.PostedFile.FileName);
        // filepath = "~\\myupload\\" + filename;//works fine
        filepath = "..\\myupload\\" + filename;
        string strpath = System.IO.Path.GetExtension(filename);


        if (fileUpload1.HasFile)
        {
            if (strpath == ".jpg" || strpath == ".jpeg" || strpath == ".gif" || strpath == ".png" || strpath == ".pdf")
            {
                fileUpload1.SaveAs(Server.MapPath(filepath));
            }
            else
            {
                ScriptManager.RegisterStartupScript(this, this.GetType(), "script", "alert('Select only jpg, jpeg,gif, pdf format!!');", true);
            }
            
            
            //AlertMessage("File uploaded sucessfully.");
            
            //return;
        }
        OpenDialog();
        //PanelIDPForm.Visible = true;
       
        Attachment = filepath.ToString();
        hdnattach.Value = Attachment;
        lblattachtext.Text = hdnattach.Value;
            


    }
}