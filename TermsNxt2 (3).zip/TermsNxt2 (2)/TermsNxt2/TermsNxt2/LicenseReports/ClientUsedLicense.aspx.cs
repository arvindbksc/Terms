﻿using Microsoft.VisualBasic;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using com.nss.DBAccess;
using System.Data.SqlClient;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Web.Services;
using System.Drawing;
using System.Globalization;
using System.Text.RegularExpressions;
using System.IO;
using System.Net;
using System.Web;
using com.nss.DBAccess;

public partial class LicenseExpiryReports_ClientUsedLicense : System.Web.UI.Page
{
    DataTable dt = new DataTable();
    DBAccess db = new DBAccess("CRM");
    string Attachment { get; set; }

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {

            this.getuser();
            lblReportName.CurrentPage = "License Used Report";
            BindClientName();
            PanlSearch.Visible = true;
            //GrdDeviceIdsDetails();
            //OpenDialog();
        }

    }

    public void getuser()
    {
        if (Session["UserID"] != null)
        {
            if (User.Identity.Name.ToString().ToUpper().Contains("NSS\\"))
            {
                Session["Lanid"] = User.Identity.Name.ToString().Replace("NSS\\", "");
            }

            else if (User.Identity.Name.ToString().ToUpper().Contains("INNIIT-TECH\\"))
            {
                Session["Lanid"] = User.Identity.Name.ToString().ToUpper().Contains("INNIIT-TECH\\");
            }

            else
            {
                Session["Lanid"] = User.Identity.Name;
            }
            //if (string.IsNullOrEmpty(Session["Lanid"].ToString()))
            //{
            //    Session["Lanid"] = Convert.ToString()(Mid(Request.ServerVariables["LOGON_USER"], Strings.InStr(Request.ServerVariables["LOGON_USER"], "\\") + 1, Strings.Len(Request.ServerVariables("LOGON_USER"))));
            //}

            DBAccess db = new DBAccess("report");
            //Dim dr As System.Data.DataRow = db.ReturnRow("select Agentid,AgentName,campaignid,btVerifier from tbl_agentmaster where lanid='" & Session["Lanid"] & "' and active=1")
            //db.slDataAdd("UserId", Session["Lanid"]);
            db.slDataAdd("UserId", "mohini");
            System.Data.DataRow dr = db.ReturnRow("usp_CheckTermsUser", true);
            db = null;
            if (dr == null)
            {
                Response.Write("There is some problem in authenticating your credentials. Please make sure you are authorized to use this website.");
                return;
            }
            Session["CampaignID"] = dr["campaignid"];
            Session["AgentID"] = dr["AgentID"];
            Session["UserID"] = dr["AgentID"];
            Session["username"] = dr["AgentName"];
            Session["IsVerifier"] = dr["btVerifier"];

        }

        {

            //HumanMessage.Style["visibility"] = "hidden";
            // HumanMessage.Visible = false;
            if (!this.IsPostBack)
            {

                lblReportName.CurrentPage = "Client License Detail Report";


            }

        }
    }
    protected void BtnSubmit_Click(object sender, EventArgs e)
    {
        gridview();
        GrdDeviceIdsDetails();
    }

    public void gridview()
    {
        try
        {
            db.slDataAdd("LicenseNo", txtLicenseSearch.Text);//First Grid
            db.slDataAdd("Type", "Select");
            //db.slDataAdd("ID", ID);   
            dt = db.ReturnTable("CMT_GET_CLIENT_DUMMY", "", true);
            if (dt.Rows.Count > 0)
            {
                panlgrdUsedLicense.Visible = true;
                grdUsedLicense.Visible = true;
                grdUsedLicense.DataSource = dt;
                grdUsedLicense.DataBind();
                //GrdDeviceIdsDetails();
                //btnNew.Visible = true;
            }
            else
            {
                panlgrdUsedLicense.Visible = false;
                grdUsedLicense.Visible = false;

            }
        }
        catch (Exception ex)
        {
            SuccessMessage(ex.ToString());
        }
    }

    public void GrdDeviceIdsDetails()
    {
        try
        {
            //db.slDataAdd("LicenseNo", txtLicenseSearch.Text);
            db.slDataAdd("Type", "SelectUsedRecord");
            //db.slDataAdd("ID", ID);   
            dt = db.ReturnTable("CMT_GET_CLIENT_DUMMY", "", true);
            db = null;
            if (dt.Rows.Count > 0)
            {
                panlgrdDeviceIds.Visible = true;
                grdDeviceIds.Visible = true;
                grdDeviceIds.DataSource = dt;
                grdDeviceIds.DataBind();
                //btnNew.Visible = true;
            }
            else
            {
                panlgrdDeviceIds.Visible = false;
                grdDeviceIds.Visible = false;

            }
        }
        catch (Exception ex)
        {

        }
    }

    private void SuccessMessage(string msg)
    {
        lblHumanMessage.Text = msg;
        HumanMessage.CssClass = "HMSuccess";
        HumanMessage.Visible = true;
        lblHumanMessage.Visible = true;
        HumanMessage.Style["visibility"] = "visible";
        //HumanMessage.Item["visibility"].tostring() = "visible";

    }

    private void AlertMessage(string msg)
    {
        lblHumanMessage.Text = msg;
        HumanMessage.CssClass = "HMFail";
        HumanMessage.Visible = true;
        lblHumanMessage.Visible = true;
        HumanMessage.Style["visibility"] = "visible";
    }


    protected void HumanMsgbtn_Click(object sender, EventArgs e)
    {
       
        HumanMessage.Visible = false;
        lblHumanMessage.Text = "";
        HumanMessage.Style["visibility"] = "";

    }


    private void OpenDialog()
    {
        string str = null;
        str = "$('#DialogBackground').height($(document).height()-5);$('#DialogBackground').width($(window).width());$('#DialogBackground').css('visibility','visible'); "
               + " $('#PanelIDPForm').css('visibility','visible');" + " $('#PanelIDPForm').css('left',($(window).width() - $('#PanelIDPForm').width())/2); ";
        ScriptManager.RegisterStartupScript(Page, Page.GetType(), "Movedialog", str, true);
    }


    private void BindClientName()
    {
        try
        {
            DataTable dt = new DataTable();
            DBAccess db = new DBAccess("CRM");
            db.slDataAdd("Type", "DDL_CLIENTNAME");
            dt = db.ReturnTable("CMF_GET_ClientLicenseDetail", "", true);
            db = null;
            ddlClientname.DataTextField = "ClientName";
            ddlClientname.DataValueField = "ID";
            ddlClientname.DataSource = dt;
            ddlClientname.DataBind();
            ddlClientname.Items.Insert(0, new ListItem("--Select--", "0"));
            ddlClientname.SelectedIndex = 0;

        }
        catch (Exception ex)
        {
            throw ex;
        }


    }

    public void getData(string ID)
    {
        try
        {
            db.slDataAdd("Type", "SelectRecord");
            db.slDataAdd("ID", HidID.Value);
            dt = db.ReturnTable("CMT_GET_CLIENT_DUMMY", "", true);
            if (dt.Rows.Count > 0)
            {
                ddlClientname.SelectedValue = dt.Rows[0]["CLIENTID"].ToString();
                TxtProcess.Text = dt.Rows[0]["Process"].ToString();
                TxtLicensKey.Text = dt.Rows[0]["LicenseNo"].ToString();
                TxtDeveloper.Text = dt.Rows[0]["Developer"].ToString();
                txtSystemName.Text = dt.Rows[0]["SystemName"].ToString();
                lblattach.Text = dt.Rows[0]["Attachment"].ToString();
                HdExpiryDate.Value = dt.Rows[0]["ExpiryDate"].ToString();
                //txtDeviceID.Text = dt.Rows[0][""].ToString();
                HdAttach.Value = lblattach.Text;

            }
        }

        catch (Exception ex)
        {
        }
    }



    protected void ImgEdit_Click(object sender, ImageClickEventArgs e)
    {
        ImageButton lbk = (ImageButton)sender;
        GridViewRow grd = (GridViewRow)lbk.NamingContainer;
        int index = grd.RowIndex;
        HidID.Value = grdUsedLicense.DataKeys[Convert.ToInt32(index)].Values[0].ToString();
        getData(HidID.Value);
        OpenDialog();


    }
    //protected void grdUsedLicense_RowCommand(object sender, GridViewCommandEventArgs e)
    //{
    //    lblHeader.Text = "License Used Report";
    //    btnSave.Text = "Save";
    //    OpenDialog();
    //}
    protected void btnSave_Click(object sender, EventArgs e)
    {
        try
        {

            db.slDataAdd("Type", "Insert");
            db.slDataAdd("ClientLicense_Id", HidID.Value);
            db.slDataAdd("ClientId", ddlClientname.SelectedValue);
            db.slDataAdd("DeveloperName", TxtDeveloper.Text);
            db.slDataAdd("DeviceId", txtDeviceID.Text);
            db.slDataAdd("ExpiryDate", HdExpiryDate.Value);
            db.slDataAdd("SystemName", txtSystemName.Text);
            db.slDataAdd("LicenseNo", TxtLicensKey.Text);
            db.slDataAdd("Attachment", HdAttach.Value);
            db.slDataAdd("ClientName", ddlClientname.SelectedItem.Text);

            dt = db.ReturnTable("CMT_GET_CLIENT_DUMMY", "", true);
            if (dt != null)
            {
                //ScriptManager.RegisterStartupScript(this, GetType(), "showalert", "alert('Device Id Detail Inserted Successfully!!');", true);
                switch ((dt.Rows[0]["MESSAGE_TYPE"].ToString()))
                {
                    case "S":
                        SuccessMessage(dt.Rows[0]["MESSAGE"].ToString());
                        break;

                    case "E":
                        AlertMessage(dt.Rows[0]["MESSAGE"].ToString());
                        break;
                }
            }
            //else
            //{
            //    ScriptManager.RegisterStartupScript(this, GetType(), "showalert", "alert('Device Id Detail Inserted Successfully!!');", true);

            //}
            GrdDeviceIdsDetails();
            //PanlSearch.Visible = false;
            //panlgrdUsedLicense.Visible = false;
        }
        catch (Exception ex)
        {

        }
    }
    protected void btnUpload_Click(object sender, EventArgs e)
    {
        string filename = "";
        string filepath = "";

        
        // filepath = "~\\myupload\\" + filename;//works fine
        filename = Path.GetFileName(fileUpload1.PostedFile.FileName);
        filepath = "~\\myupload\\" + filename;
        string strpath = System.IO.Path.GetExtension(filename);
        




        if (fileUpload1.HasFile)
        {
            if (strpath == ".jpg" || strpath == ".jpeg" || strpath == ".gif" || strpath == ".png" || strpath == ".pdf")
            {

                fileUpload1.SaveAs(Server.MapPath(filepath));
            }
            else
            {
                ScriptManager.RegisterStartupScript(this, this.GetType(), "script", "alert('Select only jpg, jpeg,gif, pdf format!!');", true);
            }
           
           
            // AlertMessage("File uploaded sucessfully.");
        }
        //PanelIDPForm.Visible = true;
        OpenDialog();
        Attachment = filepath.ToString();
        HdAttach.Value = Attachment;
        lblattach.Text = HdAttach.Value;
        //HiddenField attach =((System.Web.UI.WebCont
    }

    public void Reset()
    {
        ddlClientname.SelectedValue = "0";
        TxtDeveloper.Text = "";
        txtDeviceID.Text = "";
        TxtLicensKey.Text = "";
        TxtProcess.Text = "";
        txtSystemName.Text = "";
        HdAttach.Value = "";
    }
    protected void btnNew_Click(object sender, EventArgs e)
    {
        Reset();
        OpenDialog();
    }

    protected void grdUsedLicense_RowDataBound(object sender, GridViewRowEventArgs e)
    {

    }
    //protected void grdDeviceIds_RowDataBound(object sender, GridViewRowEventArgs e)
    //{
        //ImageButton imgbtn = (ImageButton)e.Row.FindControl("ImgEdit");
        //Label lblDeviceId = (Label)e.Row.FindControl("lblDeviceId");

        //if (e.Row.RowType == DataControlRowType.DataRow)
        //{
        //    if (lblDeviceId.Text != null && lblDeviceId.Text != "")
        //    {
        //        imgbtn.Enabled = true;
        //    }
        //    else
        //    {
        //        imgbtn.Enabled = false;
        //    }

       // }
    }

