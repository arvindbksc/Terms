﻿using Microsoft.VisualBasic;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using com.nss.DBAccess;
using System.Data.SqlClient;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Web;


public partial class LicenseReports_LicenseSummary : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["UserID"] == null)
        {
            if (User.Identity.Name.ToString().Contains("NSS\\"))
            {
                Session["Lanid"] = User.Identity.Name.ToString().Replace("NSS\\", "");
            }
            else
            {
                Session["Lanid"] = User.Identity.Name;
            }
            com.nss.DBAccess.DBAccess db = new com.nss.DBAccess.DBAccess();
            db.slDataAdd("UserId", Session["Lanid"]);
            System.Data.DataRow dr = db.ReturnRow("usp_CheckTermsUser", true);
            db = null;
            if (dr == null)
            {
                Response.Write("There is some problem in authenticating your credentials. Please make sure you are authorized to use this website.");
                return;
            }
            Session["CampaignID"] = dr["campaignid"];
            Session["AgentID"] = dr["AgentID"];
            Session["UserID"] = dr["AgentID"];
            Session["username"] = dr["AgentName"];
            Session["IsVerifier"] = dr["btVerifier"];
            Response.Write(Session["username"]);
            Response.Write(Session["Lanid"]);
        }
        if (!IsPostBack)
        {
           
            BindAllRecord();
            BindTotalUsage();
            txtFromDate.Text = DateTime.Now.ToString("dd-MM-yyyy");
            txtTodate.Text = DateTime.Now.ToString("dd-MM-yyyy");
            lblReportName.CurrentPage = "Summary Report";          

        }
    }


    public void BindTotalUsage()
    {
        try
        {
            DBAccess db = new DBAccess("CRM");
            DataTable dt = new DataTable();
            db.slDataAdd("Filter", "Total");
            dt = db.ReturnTable("Usp_Rpa_Reporting", "", true);
            if (dt.Rows.Count > 0)
            {
                txtAvailable.Text = dt.Rows[0]["Available"].ToString();
                txtInUse.Text = dt.Rows[0]["InUse"].ToString();
                lblAvailable.Visible = true;
                txtAvailable.Visible = true;
                lblInUse.Visible = true;
                txtInUse.Visible = true;
            }
            else
            {
                lblAvailable.Visible = true;
                txtAvailable.Visible = true;
                lblInUse.Visible = true;
                txtInUse.Visible = true;
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
       
    }

   

    public void BindAllRecord()
    {
        try 
        {
            DataTable dt = new DataTable();
            DBAccess db = new DBAccess("CRM");
            DataSet ds = new DataSet();
            db.slDataAdd("Filter", "AllMainRecord");
            ds = db.ReturnDataset("Usp_Rpa_Reporting", true);
            if (ds.Tables[0].Rows.Count > 0)
            {
                PanlEmployeeGrid.Visible = true;
                PanlCount.Visible = true;
                gdData.Visible = true;
                gdData.DataSource = ds;
                gdData.DataBind();

            }
            else
            {
                PanlEmployeeGrid.Visible = false;
                gdData.Visible = false;
                PanlCount.Visible = false;

            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }


    protected void ddlFilter_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlFilter.SelectedValue == "1")
        {
            PanlReqId.Visible = true;
            PanlClient.Visible = false;
            PanlLicenseKey.Visible = false;
            PanlDate.Visible = false;
        }
        else if (ddlFilter.SelectedValue == "2")
        {
            PanlReqId.Visible = false;
            PanlClient.Visible = true;
            PanlLicenseKey.Visible = false;
            PanlDate.Visible = false;
        }
        else if (ddlFilter.SelectedValue == "3")
        {
            PanlDate.Visible = false;
            PanlLicenseKey.Visible = true;
            PanlReqId.Visible = false;
            PanlClient.Visible = false;


        }
        else if (ddlFilter.SelectedValue == "4")
        {
            PanlDate.Visible = true;
            PanlLicenseKey.Visible = false;
            PanlClient.Visible = false;
            PanlReqId.Visible = false;

        }
        else if (ddlFilter.SelectedValue == "5")
        {
            PanlDate.Visible = true;
            PanlLicenseKey.Visible = false;
            PanlReqId.Visible = false;
            PanlClient.Visible = false;

        }
    }

     protected void BtnSearch_Click(object sender, EventArgs e)
    {
        if (ddlFilter.SelectedValue == "0")
        {
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Select Filter To Search Accordingly!!')", true); 
        }
        else if (ddlFilter.SelectedValue == "1")
        {
            if (txtByReqId.Text == "")
            {
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Please Enter Request ID!!')", true);
            }
            else
            {
                BindClientWise(txtpanlLicenseKey.Text, txtClientName.Text, txtFromDate.Text, txtTodate.Text, txtByReqId.Text);
            }
 
        }
        else if (ddlFilter.SelectedValue == "2")
        {
            if (txtByClient.Text == "")
            {
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Please Enter Client Name!!')", true);
            }
            else 
            {
                BindClientWise(txtpanlLicenseKey.Text, txtClientName.Text, txtFromDate.Text, txtTodate.Text, txtByReqId.Text);
            }
 
        }
        else if (ddlFilter.SelectedValue == "3")
        {
            if (txtpanlLicenseKey.Text == "")
            {
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Please Enter The License Key!!')", true);
            }
            else
            {
                BindClientWise(txtpanlLicenseKey.Text, txtClientName.Text, txtFromDate.Text, txtTodate.Text, txtByReqId.Text);
            }
        }
        else if (ddlFilter.SelectedValue == "4" || ddlFilter.SelectedValue == "5")
        {
            if (txtClientName.Text == "")
            {
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Please Enter The ClientName!!')", true);
            }
            else
            {
                BindClientWise(txtpanlLicenseKey.Text, txtClientName.Text, txtFromDate.Text, txtTodate.Text, txtByReqId.Text);
            }
        }

        else
        {
            BindClientWise(txtpanlLicenseKey.Text, txtClientName.Text, txtFromDate.Text, txtTodate.Text, txtByReqId.Text);
        }
        
    }

    [System.Web.Script.Services.ScriptMethod()]
    [System.Web.Services.WebMethod]
    public static List<string> GetCompletionList(string prefixText, int count)
    {
        return BindAutoFill(prefixText, "ClientName");
    }
    [System.Web.Script.Services.ScriptMethod()]
    [System.Web.Services.WebMethod]
    public static List<string> GetLicenseCompletionList(string prefixText, int count)
    {

        return BindAutoFillLicenseKey(prefixText, "LicenseKey");
    }

    [System.Web.Script.Services.ScriptMethod()]
    [System.Web.Services.WebMethod]
    public static List<string> GetRequestCompletionList(string prefixText, int count)
    {
        return BindAutoFillRequestID(prefixText, "RequestID");
    }

    //Get Agent Names And Agent Id in TextBox for Search
    public static List<string> BindAutoFill(string ClientName, string UserCode)
    {

        DBAccess db = new DBAccess("CRM");
        DataSet ds = new DataSet();
        List<string> listDesc = new List<string>();
        db.slDataAdd("Filter", "AllClientNames");
        db.slDataAdd("LicenseKey", "");
        db.slDataAdd("ClientName", ClientName);
        db.slDataAdd("FromDate", "");
        db.slDataAdd("ToDate", "");
        db.slDataAdd("RequestID", "");
        db.slDataAdd("Id", "");
        ds = db.ReturnDataset("Usp_Rpa_Reporting", true);
        DataRowCollection drc;
        if (ds.Tables[0].Rows.Count > 0)
        {
            drc = ds.Tables[0].Rows;
            foreach (DataRow dr in drc)
            {
                listDesc.Add(dr[0].ToString());


            }

            return listDesc;
        }
        else
        {
            listDesc.Add("");
            return listDesc;
        }
    }

    public static List<string> BindAutoFillLicenseKey(string LicenseKey, string UserCode)
    {

        DBAccess db = new DBAccess("CRM");
        DataSet ds = new DataSet();
        List<string> listDesc = new List<string>();
        db.slDataAdd("Filter", "AllLicenseKeys");
        db.slDataAdd("LicenseKey", LicenseKey);
        db.slDataAdd("ClientName", "");
        db.slDataAdd("FromDate", "");
        db.slDataAdd("ToDate", "");
        db.slDataAdd("RequestID", "");
        db.slDataAdd("Id", "");
        ds = db.ReturnDataset("Usp_Rpa_Reporting", true);
        DataRowCollection drc;
        if (ds.Tables[0].Rows.Count > 0)
        {
            drc = ds.Tables[0].Rows;
            foreach (DataRow dr in drc)
            {
                listDesc.Add(dr[0].ToString());


            }

            return listDesc;
        }
        else
        {
            listDesc.Add("");
            return listDesc;
        }
    }

    public static List<string> BindAutoFillRequestID(string RequestID, string UserCode)
    {

        DBAccess db = new DBAccess("CRM");
        DataSet ds = new DataSet();
        List<string> listDesc = new List<string>();
        db.slDataAdd("Filter", "AllRequestID");
        db.slDataAdd("LicenseKey", "");
        db.slDataAdd("ClientName", "");
        db.slDataAdd("FromDate", "");
        db.slDataAdd("ToDate", "");
        db.slDataAdd("RequestID", RequestID);
        db.slDataAdd("Id", "");
        ds = db.ReturnDataset("Usp_Rpa_Reporting", true);
        DataRowCollection drc;
        if (ds.Tables[0].Rows.Count > 0)
        {
            drc = ds.Tables[0].Rows;
            foreach (DataRow dr in drc)
            {
                listDesc.Add(dr[0].ToString());


            }

            return listDesc;
        }
        else
        {
            listDesc.Add("");
            return listDesc;
        }
    }

   

    public void BindClientWise(string LicenseKey, string ClientName, string FromDate, string ToDate, string RequestID)
    {
        try
        {
            DataTable dt = new DataTable();
            DBAccess db = new DBAccess("CRM");
            DataSet ds = new DataSet();            
            string FromDate1 = (DateTime.ParseExact(FromDate, "dd-MM-yyyy", System.Globalization.CultureInfo.InvariantCulture)).ToString("yyyy-MM-dd");
            string ToDate1 = (DateTime.ParseExact(ToDate, "dd-MM-yyyy", System.Globalization.CultureInfo.InvariantCulture)).ToString("yyyy-MM-dd");

            if (ddlFilter.SelectedValue == "1")
            {
                db.slDataAdd("Filter", "RequestID");
                db.slDataAdd("RequestID", txtByReqId.Text);
            }
            else if (ddlFilter.SelectedValue == "2")
            {
                db.slDataAdd("Filter", "ClientName");
                db.slDataAdd("ClientName", txtByClient.Text);
            }
            else if (ddlFilter.SelectedValue == "3")
            {
                db.slDataAdd("Filter", "LicenseKey");
                db.slDataAdd("LicenseKey", LicenseKey);

            }
            else if (ddlFilter.SelectedValue == "4")
            {
                db.slDataAdd("Filter", "ProcurementDate");
                db.slDataAdd("Clientname", ClientName);
                db.slDataAdd("FromDate", FromDate1);
                db.slDataAdd("ToDate", ToDate1);

            }
            else if (ddlFilter.SelectedValue == "5")
            {
                db.slDataAdd("Filter", "Renewdate");
                db.slDataAdd("Clientname", ClientName);
                db.slDataAdd("FromDate", FromDate1);
                db.slDataAdd("ToDate", ToDate1);
                db.slDataAdd("Id", "");

            }

            ds = db.ReturnDataset("Usp_Rpa_Reporting", true);
            if (ds.Tables[0].Rows.Count > 0)
            {

                gdData.Visible = true;
                gdData.DataSource = ds;
                gdData.DataBind();
            }
            else
            {
                gdData.Visible = false;

            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
       
    }

    protected void gdData_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        try
        {
            gdData.PageIndex = e.NewPageIndex;
            gdData.DataBind();
            BindAllRecord();
        }
        catch (Exception ex)
        {
            throw ex;
        }
        
    }
}