﻿
using Microsoft.VisualBasic;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using com.nss.DBAccess;
using System.Data.SqlClient;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Web.Services;
using System.Drawing;

public partial class LicenseExpiryReports_DetailedClientReport : System.Web.UI.Page
{
    DataTable dt = default(DataTable);
    protected void Page_Load(object sender, EventArgs e)
    {


        if (!this.IsPostBack)
        {

            this.getuser();
            BindClientName();
            //GetGridView();
            lblReportName.CurrentPage = "License Detailed Report";
            //HumanMessage.Style["visibility"] = "hidden";
            //HumanMessage.Visible = false;

        }


    }
    #region "---Bind Events ---"
    public void getuser()
    {
        if (Session["UserID"] == null)
        {
            if (User.Identity.Name.ToString().Contains("NSS\\"))
            {
                Session["Lanid"] = User.Identity.Name.ToString().Replace("NSS\\", "");
            }
            else
            {
                Session["Lanid"] = User.Identity.Name;
            }
            //if (string.IsNullOrEmpty(Session["Lanid"].ToString()))
            //{
            //    Session["Lanid"] = Convert.ToString()(Mid(Request.ServerVariables["LOGON_USER"], Strings.InStr(Request.ServerVariables["LOGON_USER"], "\\") + 1, Strings.Len(Request.ServerVariables("LOGON_USER"))));
            //}

            com.nss.DBAccess.DBAccess db = new com.nss.DBAccess.DBAccess();
            //Dim dr As System.Data.DataRow = db.ReturnRow("select Agentid,AgentName,campaignid,btVerifier from tbl_agentmaster where lanid='" & Session["Lanid"] & "' and active=1")
            db.slDataAdd("UserId", Session["Lanid"]);
            System.Data.DataRow dr = db.ReturnRow("usp_CheckTermsUser", true);
            db = null;
            if (dr == null)
            {
                Response.Write("There is some problem in authenticating your credentials. Please make sure you are authorized to use this website.");
                return;
            }
            Session["CampaignID"] = dr["campaignid"];
            Session["AgentID"] = dr["AgentID"];
            Session["UserID"] = dr["AgentID"];
            Session["username"] = dr["AgentName"];
            Session["IsVerifier"] = dr["btVerifier"];

        }

        {

            HumanMessage.Style["visibility"] = "hidden";
            HumanMessage.Visible = false;
            if (!this.IsPostBack)
            {

                lblReportName.CurrentPage = "Client License Detail Report";


            }

        }
    }

    private void BindClientName()
    {
        try
        {
            DataTable dt = new DataTable();
            DBAccess db = new DBAccess("CRM");
            db.slDataAdd("Type", "DDL_CLIENTNAME");
            dt = db.ReturnTable("CMF_GET_ClientLicenseDetail", "", true);
            db = null;
            ddlClientname.DataTextField = "ClientName";
            ddlClientname.DataValueField = "Id";
            ddlClientname.DataSource = dt;
            ddlClientname.DataBind();
            ddlClientname.Items.Insert(0, new ListItem("--select--", "0"));
            ddlClientname.SelectedIndex = 0;

        }
        catch (Exception ex)
        {
            throw ex;
        }


    }


    #endregion
    protected void BtnSubmit_Click(object sender, EventArgs e)
    {
        GetGridView();
    }
    private void GetGridView()
    {
        DBAccess db = new DBAccess("CRM");

        try
        {
            db.slDataAdd("ClientName", ddlClientname.SelectedItem.Value);
            //db.slDataAdd("ID", "");
            db.slDataAdd("Type", "SELECTDATA_CLIENTWISE");
            db.slDataAdd("IsActive", 1);
            //db.slDataAdd("CreatedBy", "");
            //db.slDataAdd("CreatedDatetime", DateTime.Now);
            //db.slDataAdd("UpdatedBy", "");
            //db.slDataAdd("UpdatedDatetime", "");
            //db.slDataAdd("Remarks", "");
            //db.slDataAdd("Remarks1", "");
            //db.slDataAdd("Remarksint ", 0);

            dt = db.ReturnTable("CMF_GET_ClientLicenseDetail", "", true);
            db = null;
            gdData.DataSource = dt;
            gdData.DataBind();

            if (dt.Rows.Count < 0)
            {
                AlertMessage("No Data Found!");
            }


        }
        catch (Exception ex)
        {
            //AlertMessage(ex.ToString);
        }
    }


    #region "--- Utility ---"
    private void AlertMessage(string msg)
    {
        lblHumanMessage.Text = msg;
        HumanMessage.CssClass = "HMFail";
        HumanMessage.Visible = true;
        lblHumanMessage.Visible = true;
        HumanMessage.Style["visibility"] = "visible";
        // HumanMessage.Style.Item("visibility") = "visible";

    }

    private void SuccessMessage(string msg)
    {
        lblHumanMessage.Text = msg;
        HumanMessage.CssClass = "HMSuccess";
        HumanMessage.Visible = true;
        lblHumanMessage.Visible = true;
        HumanMessage.Style["visibility"] = "visible";
        //HumanMessage.Item["visibility"].tostring() = "visible";

    }

    protected void HumanMsgbtn_Click(object sender, EventArgs e)
    {
        // HumanMessage.Style["visibility"].ToString() = "";
        HumanMessage.Visible = false;
        lblHumanMessage.Text = "";
        HumanMessage.Style["visibility"] = "";

    }

    #endregion

    protected void OnPageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        gdData.PageIndex = e.NewPageIndex;
        gdData.DataBind();
        GetGridView();
    }
    protected void gdData_RowDataBound(object sender, GridViewRowEventArgs e)
    {
      

        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            DataRowView drv = (DataRowView)e.Row.DataItem;

            if (e.Row.Cells.Count > 0 && e.Row.Cells[0] != null && e.Row.Cells[0].Controls.Count > 0)
            {

                //DateTime ProcStartDate = Convert.ToDateTime(drv["ProcurementDate"]);
                //DateTime ProcEndDate = ProcStartDate.AddYears(1);
                //DateTime ExpiryDate = Convert.ToDateTime(drv["ExpiryDate"]);

                //if (ExpiryDate >= ProcStartDate && ExpiryDate <= ProcEndDate)
                //{ //e.Row.Cells[7].BackColor = Color.Red;//for making a particular cell coloured
                //  //e.Row.Cells[7].Font.Bold = true;//for making a particular cell coloured
                //    e.Row.BackColor = Color.LightGoldenrodYellow;//for making entire row coloured
                //    e.Row.Font.Bold = true;//for making a entire row cell coloured
                  
                //  //e.Row.Attributes.Add("onmouseover", "this.originalstyle=this.style.backgroundColor;this.style.backgroundColor='#EEFFAA'");
                //  //e.Row.Attributes.Add("onmouseover", "alert('License Soon to expire!');");
                //  e.Row.Attributes.Add("onmouseover", e.Row.Cells[7].ToolTip = "License soon to expire!");
                //  e.Row.Attributes.Add("onmouseout", "this.style.backgroundColor=this.originalstyle;");
                //}
                //else { e.Row.Cells[7].BackColor = Color.Green;
                //e.Row.Cells[7].Font.Bold = true;



                //License Expire on the 

                DateTime ProcStartDate = Convert.ToDateTime(drv["ProcurementDate"]);
                DateTime ProcEndDate = ProcStartDate.AddYears(1);
                DateTime ExpiryDate = Convert.ToDateTime(drv["ExpiryDate"]);
               
                DateTime CurrentDate=DateTime.Now;
                DateTime CurrentDateexpires = CurrentDate.AddDays(30);
                DateTime CurrentDateexpires1 = CurrentDateexpires.Date;
                //for testing the scenario
                //DateTime ExpiryDate1 = Convert.ToDateTime("2017/09/14 12:00:00");
                //DateTime ExpiryDate2 = ExpiryDate1.Date;
                if ((ExpiryDate.Date > CurrentDate.Date) && (ExpiryDate.Date < CurrentDateexpires.Date))
                { //e.Row.Cells[7].BackColor = Color.Red;//for making a particular cell coloured
                    //e.Row.Cells[7].Font.Bold = true;//for making a particular cell coloured
                    e.Row.BackColor = Color.LightGoldenrodYellow;//for making entire row coloured
                    e.Row.Font.Bold = true;//for making a entire row cell coloured

                    //e.Row.Attributes.Add("onmouseover", "this.originalstyle=this.style.backgroundColor;this.style.backgroundColor='#EEFFAA'");
                    //e.Row.Attributes.Add("onmouseover", "alert('License Soon to expire!');");
                    e.Row.Attributes.Add("onmouseover", e.Row.Cells[7].ToolTip = "License soon to expire!");
                    e.Row.Attributes.Add("onmouseout", "this.style.backgroundColor=this.originalstyle;");
                }
                else
                {
                    e.Row.Cells[7].BackColor = Color.GreenYellow;
                    e.Row.Cells[7].Font.Bold = true;

                }

                
                 
                    }

            }
        }

      
    }
