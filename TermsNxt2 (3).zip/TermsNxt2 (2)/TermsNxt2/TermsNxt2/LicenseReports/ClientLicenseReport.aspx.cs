﻿using Microsoft.VisualBasic;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using com.nss.DBAccess;
using System.Data.SqlClient;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Net.Mail;
using System.IO;

public partial class LicenseExpiryReports_ClientLicenseReport : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["UserID"] == null)
        {
            if (User.Identity.Name.ToString().Contains("NSS\\"))
            {
                Session["Lanid"] = User.Identity.Name.ToString().Replace("NSS\\", "");
            }
            else
            {
                Session["Lanid"] = User.Identity.Name;
            }
            com.nss.DBAccess.DBAccess db = new com.nss.DBAccess.DBAccess();
            db.slDataAdd("UserId", Session["Lanid"]);
            System.Data.DataRow dr = db.ReturnRow("usp_CheckTermsUser", true);
            db = null;
            if (dr == null)
            {
                Response.Write("There is some problem in authenticating your credentials. Please make sure you are authorized to use this website.");
                return;
            }
            Session["CampaignID"] = dr["campaignid"];
            Session["AgentID"] = dr["AgentID"];
            Session["UserID"] = dr["AgentID"];
            Session["username"] = dr["AgentName"];
            Session["IsVerifier"] = dr["btVerifier"];
            Response.Write(Session["username"]);
            Response.Write(Session["Lanid"]);
        }
        HumanMessage.Style["visibility"] = "hidden";
        HumanMessage.Visible = false;
        if (!IsPostBack)
        {
            //BindClientName();
            BindLicenseType();
            BindCostPriceType();
            BindLicenseStatus();
            BindAllRecord();
            //txtProcDate.Text = DateTime.Now.ToString("dd-MM-yyyy");
            //txtExpiryDate.Text = DateTime.Now.ToString("dd-MM-yyyy");
            //txtHandoverDate.Text = DateTime.Now.ToString("dd-MM-yyyy");
            //txtRenewDate.Text = DateTime.Now.ToString("dd-MM-yyyy");
            //txtInvoiceDate.Text = DateTime.Now.ToString("dd-MM-yyyy");
            //txtPODate.Text = DateTime.Now.ToString("dd-MM-yyyy");
            txtFromDate.Text = DateTime.Now.ToString("dd-MM-yyyy");
            txtTodate.Text = DateTime.Now.ToString("dd-MM-yyyy");
            lblReportName.CurrentPage = "Maintenance Report";

        }

    }

    [System.Web.Script.Services.ScriptMethod()]
    [System.Web.Services.WebMethod]
    public static List<string> GetCompletionList(string prefixText, int count)
    {
        return BindAutoFill(prefixText, "ClientName");
    }
    [System.Web.Script.Services.ScriptMethod()]
    [System.Web.Services.WebMethod]
    public static List<string> GetLicenseCompletionList(string prefixText, int count)
    {

        return BindAutoFillLicenseKey(prefixText, "LicenseKey");
    }

    [System.Web.Script.Services.ScriptMethod()]
    [System.Web.Services.WebMethod]
    public static List<string> GetRequestCompletionList(string prefixText, int count)
    {
        return BindAutoFillRequestID(prefixText, "RequestID");
    }

    //Get Agent Names And Agent Id in TextBox for Search
    public static List<string> BindAutoFill(string ClientName, string UserCode)
    {

        DBAccess db = new DBAccess("CRM");
        DataSet ds = new DataSet();
        List<string> listDesc = new List<string>();
        db.slDataAdd("Filter", "AllClientNames");
        db.slDataAdd("LicenseKey", "");
        db.slDataAdd("ClientName", ClientName);
        db.slDataAdd("FromDate", "");
        db.slDataAdd("ToDate", "");
        db.slDataAdd("RequestID", "");
        db.slDataAdd("Id", "");
        ds = db.ReturnDataset("Usp_Rpa_Reporting", true);
        DataRowCollection drc;
        if (ds.Tables[0].Rows.Count > 0)
        {
            drc = ds.Tables[0].Rows;
            foreach (DataRow dr in drc)
            {
                listDesc.Add(dr[0].ToString());


            }

            return listDesc;
        }
        else
        {
            listDesc.Add("");
            return listDesc;
        }
    }

    public static List<string> BindAutoFillLicenseKey(string LicenseKey, string UserCode)
    {

        DBAccess db = new DBAccess("CRM");
        DataSet ds = new DataSet();
        List<string> listDesc = new List<string>();
        db.slDataAdd("Filter", "AllLicenseKeys");
        db.slDataAdd("LicenseKey", LicenseKey);
        db.slDataAdd("ClientName", "");
        db.slDataAdd("FromDate", "");
        db.slDataAdd("ToDate", "");
        db.slDataAdd("RequestID", "");
        db.slDataAdd("Id", "");
        ds = db.ReturnDataset("Usp_Rpa_Reporting", true);
        DataRowCollection drc;
        if (ds.Tables[0].Rows.Count > 0)
        {
            drc = ds.Tables[0].Rows;
            foreach (DataRow dr in drc)
            {
                listDesc.Add(dr[0].ToString());


            }

            return listDesc;
        }
        else
        {
            listDesc.Add("");
            return listDesc;
        }
    }

    public static List<string> BindAutoFillRequestID(string RequestID, string UserCode)
    {

        DBAccess db = new DBAccess("CRM");
        DataSet ds = new DataSet();
        List<string> listDesc = new List<string>();
        db.slDataAdd("Filter", "AllRequestID");
        db.slDataAdd("LicenseKey", "");
        db.slDataAdd("ClientName", "");
        db.slDataAdd("FromDate", "");
        db.slDataAdd("ToDate", "");
        db.slDataAdd("RequestID", RequestID);
        db.slDataAdd("Id", "");
        ds = db.ReturnDataset("Usp_Rpa_Reporting", true);
        DataRowCollection drc;
        if (ds.Tables[0].Rows.Count > 0)
        {
            drc = ds.Tables[0].Rows;
            foreach (DataRow dr in drc)
            {
                listDesc.Add(dr[0].ToString());


            }

            return listDesc;
        }
        else
        {
            listDesc.Add("");                                                                                                                                                                     
            return listDesc;
        }
    }
    protected void BtnSearch_Click(object sender, EventArgs e)
    {
        if (ddlFilter.SelectedValue == "0")
        {
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Select Filter To Search Accordingly!!')", true);
 
        }
        else if (ddlFilter.SelectedValue == "1")
        {
            if (txtByReqId.Text == "")
            {
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Please Enter Request ID!!')", true);
            }
            else
            {
                BindClientWise(txtpanlLicenseKey.Text, txtClientName.Text, txtFromDate.Text, txtTodate.Text, txtByReqId.Text);
            }
 
        }
        else if (ddlFilter.SelectedValue == "2")
        {
            if (txtByClient.Text == "")
            {
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Please Enter Client Name!!')", true);
            }
            else 
            {
                BindClientWise(txtpanlLicenseKey.Text, txtClientName.Text, txtFromDate.Text, txtTodate.Text, txtByReqId.Text);
            }
 
        }
        else if (ddlFilter.SelectedValue == "3")
        {
            if (txtpanlLicenseKey.Text == "")
            {
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Please Enter The License Key!!')", true);
            }
            else
            {
                BindClientWise(txtpanlLicenseKey.Text, txtClientName.Text, txtFromDate.Text, txtTodate.Text, txtByReqId.Text);
            }
        }
        else if (ddlFilter.SelectedValue == "4" || ddlFilter.SelectedValue == "5")
        {
            if (txtClientName.Text == "")
            {
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Please Enter The ClientName!!')", true);
            }
            else
            {
                BindClientWise(txtpanlLicenseKey.Text, txtClientName.Text, txtFromDate.Text, txtTodate.Text, txtByReqId.Text);
            }
        }

        else
        {
            //BindClientWise(txtpanlLicenseKey.Text, txtClientName.Text, txtFromDate.Text, txtTodate.Text, txtByReqId.Text);
        }
        
    }

    public void BindClientWise(string LicenseKey,string ClientName,string FromDate,string ToDate,string RequestID)
    {
        DataTable dt = new DataTable();
        DBAccess db = new DBAccess("CRM");
        DataSet ds = new DataSet();
        //FromDate = txtProcDate.Text;
        string FromDate1 = (DateTime.ParseExact(FromDate, "dd-MM-yyyy", System.Globalization.CultureInfo.InvariantCulture)).ToString("yyyy-MM-dd");
        string ToDate1 = (DateTime.ParseExact(ToDate, "dd-MM-yyyy", System.Globalization.CultureInfo.InvariantCulture)).ToString("yyyy-MM-dd");

        //string Filter = ddlFilter.SelectedValue;
        //db.slDataAdd("Filter", "Select");
        if (ddlFilter.SelectedValue == "1")
        {
            db.slDataAdd("Filter", "RequestID");
            db.slDataAdd("RequestID", txtByReqId.Text);
        }
        else if (ddlFilter.SelectedValue == "2")
        {
            db.slDataAdd("Filter", "ClientName");
            db.slDataAdd("ClientName", txtByClient.Text);
        }
        else if (ddlFilter.SelectedValue == "3")
        {
            db.slDataAdd("Filter", "LicenseKey");
            db.slDataAdd("LicenseKey", LicenseKey);
            //db.slDataAdd("Clientname", "");
            //db.slDataAdd("FromDate", "");
            //db.slDataAdd("ToDate", "");
            //db.slDataAdd("Id", "");

        }
        else if (ddlFilter.SelectedValue == "4")
        {
            db.slDataAdd("Filter", "ProcurementDate");
            //db.slDataAdd("LicenseKey", "");
            db.slDataAdd("Clientname", ClientName);
            db.slDataAdd("FromDate", FromDate1);
            db.slDataAdd("ToDate", ToDate1);
            //db.slDataAdd("RequestID", "");
           
        }
        else if (ddlFilter.SelectedValue == "5")
        {
            db.slDataAdd("Filter", "Renewdate");
           // db.slDataAdd("LicenseKey", "");
            db.slDataAdd("Clientname", ClientName);
            db.slDataAdd("FromDate", FromDate1);
            db.slDataAdd("ToDate", ToDate1);
            db.slDataAdd("Id", "");
            
        }
        
        ds = db.ReturnDataset("Usp_Rpa_Reporting", true);
        if (ds.Tables[0].Rows.Count > 0)
        {
            lblmsg.Visible = false;
            gdData.Visible = true;
            gdData.DataSource = ds;
            gdData.DataBind();
            BtnAddNew.Visible = true;
        }
        else
        {
            gdData.Visible = false;
            lblmsg.Visible = true;
            lblmsg.Font.Bold = true;
            BtnAddNew.Visible = false;
            lblmsg.Text = "**No Records Found";
        }
        //MultiView1.ActiveViewIndex = 0;
    }

    //protected void gdData_RowCommand(object sender, GridViewCommandEventArgs e)
    //{
    //    if (e.CommandName.ToLower() == ("EditRecord").ToLower())
    //    { 
    //        int index = Convert.ToInt32(e.CommandArgument);
    //       // gdData.AllowPaging = false;
    //        //BindAllRecord();
    //        HdnRPAID.Value = ((HiddenField)gdData.Rows[index].FindControl("hdnID")).Value;
    //        GetData(HdnRPAID.Value);
    //        //BindClientWise(txtpanlLicenseKey.Text, txtClientName.Text, txtFromDate.Text, txtTodate.Text, txtByReqId.Text);
    //        //txtRemarks.Text = "";
    //        //UpdateRecord(HdnRPAID.Value);           

    //    }
    //    else if (e.CommandName.ToLower() == ("DeleteRecord").ToLower())
    //    {
    //        int index = Convert.ToInt32(e.CommandArgument);
    //        HdnRPAID.Value = ((HiddenField)gdData.Rows[index].FindControl("hdnID")).Value;
    //        Deleterecord(HdnRPAID.Value);
    //        PanlClient.Visible = false;
    //        PanlDate.Visible = false;
    //        PanlLicenseKey.Visible = false;
    //        PanlReqId.Visible = false;
            
    //        ScriptManager.RegisterStartupScript(Page, Page.GetType(), "Movedialog", "SaveLabel();", true);
    //        //BindClientWise(txtpanlLicenseKey.Text, txtClientName.Text, txtFromDate.Text, txtTodate.Text, txtByReqId.Text);
    //        lblmsg.Visible = false;
    //       // Response.Redirect("~/LicenseExpiryReports/ClientLicenseReport.aspx");
    //        BindAllRecord();
    //    }
    //   // BindAllRecord();

       
        
    //}

    protected void ImgEdit_Click(object sender, ImageClickEventArgs e)
    {
        ImageButton Img = (ImageButton)sender;
        GridViewRow row = (GridViewRow)Img.NamingContainer;
        HdnRPAID.Value = ((HiddenField)row.FindControl("hdnID")).Value;
        GetData(HdnRPAID.Value);
        //txtCount.Text = "";
        //txtRemarks.Text = "";
        //BindAllRecord();
       
    }

    protected void ImgDelete_Click(object sender, ImageClickEventArgs e)
    {
        
        ImageButton Img = (ImageButton)sender;
        GridViewRow row = (GridViewRow)Img.NamingContainer;
        HdnRPAID.Value = ((HiddenField)row.FindControl("hdnID")).Value;
        Deleterecord(HdnRPAID.Value);
        PanlClient.Visible = false;
        PanlDate.Visible = false;
        PanlLicenseKey.Visible = false;
        PanlReqId.Visible = false;
       
        
    }

    protected void gdData_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        gdData.PageIndex = e.NewPageIndex;
        gdData.DataBind();
        BindAllRecord();
    }


   

    public void BindLicenseType()
    {
        try
        {
            DataTable dt = new DataTable();
            DBAccess db = new DBAccess("CRM");
            db.slDataAdd("Type", "DDL_LICENSETYPE");
            dt = db.ReturnTable("usp_RpaLicenseDetails", "", true);
            db = null;
            ddlLicenseType.DataTextField = "LicenseType";
            ddlLicenseType.DataValueField = "ID";
            ddlLicenseType.DataSource = dt;
            ddlLicenseType.DataBind();
            ddlLicenseType.Items.Insert(0, new ListItem("--Select--", "0"));
            ddlLicenseType.SelectedIndex = 0;

        }
        catch (Exception ex)
        {
            throw ex;
        }


    }

    public void BindCostPriceType()
    {
        try
        {
            DataTable dt = new DataTable();
            DBAccess db = new DBAccess("CRM");
            db.slDataAdd("Type", "DDLCostType");
            dt = db.ReturnTable("usp_RpaLicenseDetails", "", true);
            db = null;
            ddlCostType.DataTextField = "PriceType";
            ddlCostType.DataValueField = "Id";
            ddlCostType.DataSource = dt;
            ddlCostType.DataBind();
            ddlCostType.Items.Insert(0, new ListItem("--Select--", "0"));
            ddlCostType.SelectedIndex = 0;

        }
        catch (Exception ex)
        {
            throw ex;
        }


    }

    public void BindLicenseStatus()
    {
        try
        {
            DataTable dt = new DataTable();
            DBAccess db = new DBAccess("CRM");
            db.slDataAdd("Type", "DDL_LICENSE_STATUS");
            dt = db.ReturnTable("usp_RpaLicenseDetails", "", true);
            db = null;
            ddlStatus.DataTextField = "License_Status_Desc";
            ddlStatus.DataValueField = "License_Satuts_Id";
            ddlStatus.DataSource = dt;
            ddlStatus.DataBind();
            //ddlStatus.Items.Insert(0, new ListItem("--Select--", "0"));
            //ddlStatus.SelectedIndex = 0;

        }
        catch (Exception ex)
        {
            throw ex;
        }


    }

    public void BindAllRecord()
    {
        DataTable dt = new DataTable();
        DBAccess db = new DBAccess("CRM");
        DataSet ds = new DataSet();
        db.slDataAdd("Filter", "AllMainRecord");
        ds = db.ReturnDataset("Usp_Rpa_Reporting", true);
        if (ds.Tables[0].Rows.Count > 0)
        {

            gdData.Visible = true;
            gdData.DataSource = ds;
            gdData.DataBind();
            BtnAddNew.Visible = true;
        }
        else
        {
            gdData.Visible = false;
              BtnAddNew.Visible = false;

        }

    }

    protected void ddlFilter_SelectedIndexChanged(object sender, EventArgs e)
    {

        txtByReqId.Text = "";
        txtByClient.Text = "";
        txtLicenseKey.Text = "";
        txtClientName.Text = "";
        txtFromDate.Text = DateTime.Now.ToString("dd-MM-yyyy");
        txtTodate.Text = DateTime.Now.ToString("dd-MM-yyyy");
        if (ddlFilter.SelectedValue == "1")
        {
            PanlReqId.Visible = true;
            PanlLicenseKey.Visible = false;
            PanlClient.Visible = false;
            PanlDate.Visible = false;
           
        }
        else if(ddlFilter.SelectedValue == "2")
        {
            PanlReqId.Visible = false;
            PanlClient.Visible = true;
            PanlLicenseKey.Visible = false;
            PanlDate.Visible = false;
          
        }
        else if (ddlFilter.SelectedValue == "3")
        {
            PanlDate.Visible = false;
            PanlLicenseKey.Visible = true;
            PanlReqId.Visible = false;
            PanlClient.Visible = false;
            
           
        }
        else if (ddlFilter.SelectedValue == "4")
        {
            PanlDate.Visible = true;
            PanlLicenseKey.Visible = false;
            PanlClient.Visible = false;
            PanlReqId.Visible = false;
          
        }
        else if (ddlFilter.SelectedValue == "5")
        {
            PanlDate.Visible = true;
            PanlLicenseKey.Visible = false;
            PanlReqId.Visible = false;
            PanlClient.Visible = false;
            
        }
        
    }

    public void GetData(string Id)
    {
        try
        {
            DataTable dt = new DataTable();
            DBAccess db = new DBAccess("CRM");
            db.slDataAdd("Type", "Getdata");
            db.slDataAdd("Id", Id);
            dt = db.ReturnTable("usp_RpaLicenseDetails", "", true);
            if (dt.Rows.Count > 0)
            {
                txtClientName2.Text = dt.Rows[0]["ClientName"].ToString();
                txtLicenseCount.Text = dt.Rows[0]["LicenseCount"].ToString();
                HdnLicenseCount.Value = txtLicenseCount.Text;
                txtLicenseKey.Text = dt.Rows[0]["LicenseKey"].ToString();
                HdnLicenseKey.Value = txtLicenseKey.Text;
                txtProcDate.Text = Convert.ToDateTime(dt.Rows[0]["ProcurementDate"]).ToString("dd-MM-yyyy");
                HdnProcDate.Value = txtProcDate.Text;
                txtExpiryDate.Text = Convert.ToDateTime(dt.Rows[0]["ExpiryDate"]).ToString("dd-MM-yyyy");
                HdnExpiryDate.Value = txtExpiryDate.Text;
                txtHandoverDate.Text = Convert.ToDateTime(dt.Rows[0]["HandOverDate"]).ToString("dd-MM-yyyy");
                HdnHandOverDate.Value = txtHandoverDate.Text;
                txtRate.Text = dt.Rows[0]["Rate"].ToString();
                HdnRate.Value = txtRate.Text;
                txtValue.Text = dt.Rows[0]["Value"].ToString();
                HdnValue.Value = txtValue.Text;
                txtInvoiceDate.Text = Convert.ToDateTime(dt.Rows[0]["InvoiceDate"]).ToString("dd-MM-yyyy");
                HdnInvoiceDate.Value = txtInvoiceDate.Text;
                txtInvoiceNo.Text = dt.Rows[0]["InvoiceNo"].ToString();
                HdnInvoiceNo.Value = txtInvoiceNo.Text;
                txtPODate.Text = Convert.ToDateTime(dt.Rows[0]["PODate"]).ToString("dd-MM-yyyy");
                HdnPODate.Value = txtPODate.Text;
                txtPO.Text = dt.Rows[0]["PONo"].ToString();
                HdnPONo.Value = txtPO.Text;
                txtAppliedAt.Text = dt.Rows[0]["AppliedAt"].ToString();
                HdnAppliedAt.Value = txtAppliedAt.Text;
                txtBillToCompny.Text = dt.Rows[0]["BillTo"].ToString();
                HdnBillTo.Value = txtBillToCompny.Text;
                txtSPOCEmail.Text = dt.Rows[0]["SPOCEmailId"].ToString();
                HdnSpocMailId.Value = txtSPOCEmail.Text;
                txtOwnerEmailId.Text = dt.Rows[0]["OwnerEmailId"].ToString();
                HdnOwnerMailId.Value = txtOwnerEmailId.Text;
                ddlCostType.SelectedValue = dt.Rows[0]["CostTypeId"].ToString();
                HdnCostType.Value = ddlCostType.SelectedValue;
                ddlLicenseType.SelectedValue = dt.Rows[0]["LicenseTypeId"].ToString();
                HdnLicenseTypeId.Value = ddlLicenseType.SelectedValue;
                ddlStatus.SelectedValue = dt.Rows[0]["Status"].ToString();
                if (ddlStatus.SelectedItem.Text == "Available")
                {
                    lblAvailable.Visible = true;
                    lblInUse.Visible = false;
                    lblExpired.Visible = false;
                }
                else if (ddlStatus.SelectedItem.Text == "In Use")
                {
                    lblAvailable.Visible = false;
                    lblInUse.Visible = true;
                    lblExpired.Visible = false;
                }
                else if (ddlStatus.SelectedItem.Text == "Expired")
                {
                    lblAvailable.Visible = false;
                    lblInUse.Visible = false;
                    lblExpired.Visible = true;
                }
                HdnStatus.Value = ddlStatus.SelectedValue;
                HdnLicenseFile.Value = dt.Rows[0]["Attachment"].ToString();
                lblAttachment.Text = HdnLicenseFile.Value;
                txtRemarks.Text = dt.Rows[0]["Remarks"].ToString();
 
            }

            popup.Show();

        }
        catch (Exception ex)
        {
 
        }
    }

    protected void btnUpdate_Click(object sender, EventArgs e)
    {
        try
        {
            UpdateRecord(HdnRPAID.Value);
            ScriptManager.RegisterStartupScript(Page, Page.GetType(), "Movedialog", "SaveLabel();", true);

           
        }
        catch (Exception ex)
        {

        }

    }

    public void UpdateRecord(string Id)
    {
        try
        {

            if (HdnLicenseCount.Value != txtLicenseCount.Text || HdnCostType.Value != ddlCostType.SelectedValue || HdnExpiryDate.Value != txtExpiryDate.Text ||
                 HdnRate.Value != txtRate.Text || HdnValue.Value != txtValue.Text || HdnInvoiceNo.Value != txtInvoiceNo.Text || HdnProcDate.Value != txtProcDate.Text
                 || HdnHandOverDate.Value != txtHandoverDate.Text || HdnInvoiceDate.Value != txtInvoiceDate.Text || HdnPODate.Value != txtPODate.Text || 
                 HdnStatus.Value != ddlStatus.SelectedValue || HdnPONo.Value != txtPO.Text || HdnSpocMailId.Value != txtSPOCEmail.Text || 
                 HdnOwnerMailId.Value != txtOwnerEmailId.Text || txtRemarks.Text != "")
            {
                string txtsProcDate = txtProcDate.Text;
                string procdate = (DateTime.ParseExact(txtsProcDate, "dd-MM-yyyy", System.Globalization.CultureInfo.InvariantCulture)).ToString("yyyy-MM-dd");

                string txtsHandoverDate = txtHandoverDate.Text;
                string HandoverDate = (DateTime.ParseExact(txtsHandoverDate, "dd-MM-yyyy", System.Globalization.CultureInfo.InvariantCulture)).ToString("yyyy-MM-dd");

                string txtsExpiryDate = txtExpiryDate.Text;
                string ExpiryDate = (DateTime.ParseExact(txtsExpiryDate, "dd-MM-yyyy", System.Globalization.CultureInfo.InvariantCulture)).ToString("yyyy-MM-dd");

                string txtsRenewDate = txtExpiryDate.Text;
                string RenewDate = (DateTime.ParseExact(txtsRenewDate, "dd-MM-yyyy", System.Globalization.CultureInfo.InvariantCulture)).ToString("yyyy-MM-dd");

                string txtsInvoiceDate = txtInvoiceDate.Text;
                string InvoiceDate = (DateTime.ParseExact(txtsInvoiceDate, "dd-MM-yyyy", System.Globalization.CultureInfo.InvariantCulture)).ToString("yyyy-MM-dd");

                string txtsPODate = txtPODate.Text;
                string PODate = (DateTime.ParseExact(txtsPODate, "dd-MM-yyyy", System.Globalization.CultureInfo.InvariantCulture)).ToString("yyyy-MM-dd");
                DataTable dt = new DataTable();
                DBAccess db = new DBAccess("CRM");
                int AvailableCount = 0;
                int InUseCount = 0;
                int ExpiredCount = 0;
                int LicenseCount = 0;
               

                db.slDataAdd("Type", "UpdateRecord");
                db.slDataAdd("Id", HdnRPAID.Value);
                db.slDataAdd("ClientName", txtClientName2.Text);
                db.slDataAdd("LicenseCount", txtLicenseCount.Text);
                db.slDataAdd("LicenseTypeId", ddlLicenseType.SelectedValue);
                db.slDataAdd("CostTypeId", ddlCostType.SelectedValue);
                db.slDataAdd("LicenseKey", txtLicenseKey.Text);
                if (ddlStatus.SelectedItem.Text == "InUse")
                {
                   
                        LicenseCount = Convert.ToInt32(txtLicenseCount.Text);
                        InUseCount = Convert.ToInt32(txtCount.Text);
                        AvailableCount = LicenseCount - InUseCount;
                        //txtLicenseCount.Text = AvailableCount.ToString();
                        db.slDataAdd("AvailableCount", AvailableCount.ToString());
                        db.slDataAdd("InUseCount", InUseCount.ToString());
                        db.slDataAdd("ExpiredCount", ExpiredCount);
                   

                }
                else if (ddlStatus.SelectedItem.Text == "Expired")
                {
                    LicenseCount = Convert.ToInt32(txtLicenseCount.Text);
                    ExpiredCount = LicenseCount;
                    AvailableCount = LicenseCount - ExpiredCount;
                    db.slDataAdd("AvailableCount", AvailableCount.ToString());
                    db.slDataAdd("InUseCount", InUseCount.ToString());
                    db.slDataAdd("ExpiredCount", LicenseCount.ToString());

                }      
               
                db.slDataAdd("AppliedAt", txtAppliedAt.Text);
                db.slDataAdd("BillTo", txtAppliedAt.Text);
                db.slDataAdd("ProcurementDate", procdate);
                db.slDataAdd("HandOverDate", HandoverDate);
                db.slDataAdd("ExpiryDate", ExpiryDate);
                db.slDataAdd("RenewDate", RenewDate);
                db.slDataAdd("Rate", txtRate.Text);
                db.slDataAdd("Value", txtValue.Text);
                db.slDataAdd("InvoiceNo", txtInvoiceNo.Text);
                db.slDataAdd("InvoiceDate", InvoiceDate);
                db.slDataAdd("PONo", txtPO.Text);
                db.slDataAdd("PODate", PODate);
                db.slDataAdd("SPOCEmailId", txtSPOCEmail.Text);
                db.slDataAdd("OwnerEmailId", txtOwnerEmailId.Text);
                db.slDataAdd("Attachment", HdnLicenseFile.Value);
                db.slDataAdd("OtherAttachment", "");
                db.slDataAdd("Remarks", txtRemarks.Text);
                db.slDataAdd("Status", ddlStatus.SelectedValue);
                db.slDataAdd("IsActive", "");
                db.slDataAdd("CreatedBy", "");
                db.slDataAdd("CreatedDate", "");
                db.slDataAdd("UpdatedBy", Session["AgentID"].ToString());
                db.slDataAdd("UpdatedDate", DateTime.Now.ToString());
                db.slDataAdd("LastUpdated", DateTime.Now.ToString());
                dt = db.ReturnTable("usp_RpaLicenseDetails", "", true);
                if ((dt != null))
                {
                    switch ((dt.Rows[0]["MESSAGE_TYPE"].ToString()))
                    {
                        case "S":
                            SuccessMessage(dt.Rows[0]["MESSAGE"].ToString());
                            // Reset();

                            break;
                        case "E":
                            AlertMessage(dt.Rows[0]["MESSAGE"].ToString());
                            break;
                    }
                    //Reset();

                    if (txtpanlLicenseKey.Text != "" || txtClientName.Text != "" || txtByClient.Text != "" || txtByReqId.Text != "")
                    {
                        BindClientWise(txtpanlLicenseKey.Text, txtClientName.Text, txtFromDate.Text, txtTodate.Text, txtByReqId.Text);
                    }
                    else
                    {
                        BindAllRecord();
                    }
                }
            }
            else
            {
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('This Record already Exist Or You have not Change the Hand Over Date!')", true);
            }

        }
        catch (Exception ex)
        {

        }

    }

    protected void txtRate_TextChanged(object sender, EventArgs e)
    {
        if (txtLicenseCount.Text != "" && txtRate.Text != "")
        {

            decimal rate = Convert.ToDecimal(txtRate.Text);
            //decimal value = Convert.ToDecimal(txtValue.Text.Trim());
            int licensecount = Convert.ToInt32(txtLicenseCount.Text);
            txtRate.Text = rate.ToString();
            rate = rate * licensecount;
            txtValue.Text = rate.ToString();

        }
        else
        {
            ScriptManager.RegisterStartupScript(this, this.GetType(), "script", "alert('Please Enter License Count To Calculate Value Of Rate!!');", true);
        }
        popup.Show();
    }

    protected void txtLicenseCount_TextChanged(object sender, EventArgs e)
    {
        if (txtLicenseCount.Text != "" && txtRate.Text != "")
        {
            int licensecount = Convert.ToInt32(txtLicenseCount.Text);
            decimal rate = Convert.ToDecimal(txtRate.Text);
            txtRate.Text = rate.ToString();
            rate = rate * licensecount;
            txtValue.Text = rate.ToString();
        }
        else
        {
            ScriptManager.RegisterStartupScript(this, this.GetType(), "script", "alert('Please Enter License Count To Calculate Value Of Rate!!');", true);
        }
        popup.Show();
    }

    


    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Reset();
        
    }

    public void Deleterecord(string Id)
    {
        try
        {
            //ScriptManager.RegisterStartupScript(Page, Page.GetType(), "Movedialog", "SaveLabel();", true);
            DBAccess db = new DBAccess("CRM");
            DataTable dt = new DataTable();
            List<string> listDesc = new List<string>();
            db.slDataAdd("Filter", "Delete");
            db.slDataAdd("LicenseKey", "");
            db.slDataAdd("ClientName", "");
            db.slDataAdd("FromDate", "");
            db.slDataAdd("ToDate", "");
            db.slDataAdd("RequestID", HdnRPAID.Value);
            dt = db.ReturnTable("Usp_Rpa_Reporting", "", true);
            if (dt.Rows.Count > 0)
            {
                switch ((dt.Rows[0]["MESSAGE_TYPE"].ToString()))
                {
                    case "S":

                        SuccessMessage(dt.Rows[0]["MESSAGE"].ToString());
                        // Reset();

                        break;
                    case "E":
                        AlertMessage(dt.Rows[0]["MESSAGE"].ToString());
                        break;
                }
            }
        }
        catch (Exception ex)
        {
 
        }
        if (txtpanlLicenseKey.Text != "" || txtClientName.Text != "" || txtByClient.Text != "" || txtByReqId.Text != "")
        {
            BindClientWise(txtpanlLicenseKey.Text, txtClientName.Text, txtFromDate.Text, txtTodate.Text, txtByReqId.Text);
        }
        else
        {
            BindAllRecord();
        }
        //BindClientWise(txtpanlLicenseKey.Text, txtClientName.Text, txtFromDate.Text, txtTodate.Text, txtByReqId.Text);
        //BindAllRecord();
       
    }
    

    protected void BtnAddNew_Click(object sender, EventArgs e)
    {
        //MultiView1.ActiveViewIndex = 1;
        Response.Redirect("~/LicenseReports/NewLicense.aspx");
    }
   
    
    protected void HumanMsgBtn_Click(object sender, EventArgs e)
    {
        HumanMessage.Visible = false;
        lblHumanMessage.Text = "";
        HumanMessage.Style["visibility"] = "";
    }

    public void Reset()
    {
        txtAppliedAt.Text = "";
        txtBillToCompny.Text = "";
        txtClientName2.Text = "";
        txtInvoiceNo.Text = "";
        txtLicenseCount.Text = "";
        txtLicenseKey.Text = "";
        txtPO.Text = "";
        txtSPOCEmail.Text = "";
        txtOwnerEmailId.Text = "";
        txtRate.Text = "";
        txtValue.Text = "";
        ddlCostType.SelectedValue = "0";
        ddlLicenseType.SelectedValue = "0";
        lblAttachment.Text = "";
        txtLicenseCount.Text = "";
        txtProcDate.Text = "";        
        txtExpiryDate.Text = "";
        txtInvoiceDate.Text = "";
        txtHandoverDate.Text = "";
        txtPODate.Text = "";
       


    }

    private void AlertMessage(string msg)
    {
        lblHumanMessage.Text = msg;
        HumanMessage.CssClass = "HMFail";
        HumanMessage.Visible = true;
        lblHumanMessage.Visible = true;
        HumanMessage.Style["visibility"] = "visible";
        // HumanMessage.Style.Item("visibility") = "visible";

    }

    private void SuccessMessage(string msg)
    {
        lblHumanMessage.Text = msg;
        HumanMessage.CssClass = "HMSuccess";
        HumanMessage.Visible = true;
        lblHumanMessage.Visible = true;
        HumanMessage.Style["visibility"] = "visible";
        //HumanMessage.Item["visibility"].tostring() = "visible";

    }

   
    protected void BtnUpload_Click(object sender, EventArgs e)
    {
        try
        {
            string filename = "";
            string filePath = "";

            filename = Path.GetFileName(fileUpload.PostedFile.FileName.ToString());
            filePath = Server.MapPath("~\\myupload\\");

            if (fileUpload.HasFile)
            {

                if (!Directory.Exists(filePath))
                {
                    Directory.CreateDirectory(filePath);
                }

                filePath = filePath + filename;                               

                string strPath = System.IO.Path.GetExtension(filePath);


                if (strPath == ".docx" || strPath == ".pdf" || strPath == ".zip")
                {

                    fileUpload.SaveAs(filePath + Path.GetFileName(filename));
                    HdnLicenseFile.Value = filePath.ToString();
                    lblAttachment.Text = filename;

                   // ScriptManager.RegisterStartupScript(this, this.GetType(), "script", "alert('File has been Saved Successfully!!');", true);
                }
              
                else
                {
                    ScriptManager.RegisterStartupScript(this, this.GetType(), "script", "alert('Select only .jpg, .jpeg, .gif, .pdf format!!');", true);
                }
            }
            else
            {
                ScriptManager.RegisterStartupScript(this, this.GetType(), "script", "alert('There is no File!!');", true);
            }
            popup.Show();
        }

        catch (Exception ex)
        {

        }
    }

    protected void txtProcDate_TextChanged(object sender, EventArgs e)
    {
        if (txtProcDate.Text != "")
        {
            DateTime procdate = DateTime.ParseExact(txtProcDate.Text, "dd-MM-yyyy", System.Globalization.CultureInfo.InvariantCulture);

            txtExpiryDate.Text = procdate.AddYears(1).ToString("dd-MM-yyyy");
            //txtHandoverDate.Text = txtProcDate.Text;
            //txtInvoiceDate.Text = txtProcDate.Text;
            //txtPODate.Text = txtProcDate.Text;
            //txtRenewDate.Text = procdate.AddYears(1).ToString("dd-MM-yyyy");
        }

        popup.Show();
    }

    protected void ddlStatus_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlStatus.SelectedItem.Text == "Available")
        {
            lblAvailable.Visible = true;
            lblInUse.Visible = false;
            lblExpired.Visible = false;
        }
        else if (ddlStatus.SelectedItem.Text == "InUse")
        {
            lblAvailable.Visible = false;
            lblInUse.Visible = true;
            lblExpired.Visible = false;
        }
        else if (ddlStatus.SelectedItem.Text == "Expired")
        {
            lblAvailable.Visible = false;
            lblInUse.Visible = false;
            lblExpired.Visible = true;
        }

        popup.Show();
    }

    //protected void LinkAttachment_Click(object args, EventArgs e)
    //{
    //    try
    //    {
    //        string filePath = (args as LinkButton).CommandArgument;

    //        Response.ContentType = ContentType;
    //        Response.AppendHeader("Content-Disposition", "attachment; filename=" + Path.GetFileName(filePath));
    //        Response.WriteFile(filePath);
    //        Response.Flush();
    //        Response.End();
    //    }
    //    catch (Exception ex)
    //    {
 
    //    }
    //}
}