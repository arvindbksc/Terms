﻿
using Microsoft.VisualBasic;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using com.nss.DBAccess;
using System.Data.SqlClient;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Web.Services;
using System.Drawing;
using System.Globalization;
using System.Text.RegularExpressions;
using System.IO;
using System.Net;
using System.Web;
using com.nss.DBAccess;
using System.Net.Mail;


public partial class LicenseExpiryReports_ClientDetailedLicenseReport : System.Web.UI.Page
{
    string filename = string.Empty;
    string Attachment { get; set; }
    string ID { get; set; }
    HiddenField Attachment_curr { get; set; }
    string ToAdd,subject,msgbox;
    int days { get; set; }
    int days1 { get; set; }
    int days2 { get; set; }     
    protected void Page_Load(object sender, EventArgs e)
    {
        HumanMessage.Style["visibility"] = "hidden";
        HumanMessage.Visible = false;
        if (!this.IsPostBack)
        {
            //SendMail();
            //ScheduleSendmail();
            this.getuser();
            BindSourceState();
            BindReciepientState();
            BindClientName();
            BindLicenseType();
            GetGridView();
            lblReportName.CurrentPage = "License Detailed Report";
            
            //HumanMessage.Style["visibility"] = "hidden";
            //HumanMessage.Visible = false;
           
        }
       

    
        
    }

   

    #region "---Bind Events ---"
    public void getuser()
    {
        if (Session["UserID"] == null)
        {
            if (User.Identity.Name.ToString().Contains("NSS\\"))
            {
                Session["Lanid"] = User.Identity.Name.ToString().Replace("NSS\\", "");
            }
            else
            {
                Session["Lanid"] = User.Identity.Name;
            }
            //if (string.IsNullOrEmpty(Session["Lanid"].ToString()))
            //{
            //    Session["Lanid"] = Convert.ToString()(Mid(Request.ServerVariables["LOGON_USER"], Strings.InStr(Request.ServerVariables["LOGON_USER"], "\\") + 1, Strings.Len(Request.ServerVariables("LOGON_USER"))));
            //}

            DBAccess db = new DBAccess("report");
            //Dim dr As System.Data.DataRow = db.ReturnRow("select Agentid,AgentName,campaignid,btVerifier from tbl_agentmaster where lanid='" & Session["Lanid"] & "' and active=1")
            db.slDataAdd("UserId", Session["Lanid"]);
            System.Data.DataRow dr = db.ReturnRow("usp_CheckTermsUser", true);
            db = null;
            if (dr == null)
            {
                Response.Write("There is some problem in authenticating your credentials. Please make sure you are authorized to use this website.");
                return;
            }
            Session["CampaignID"] = dr["campaignid"];
            Session["AgentID"] = dr["AgentID"];
            Session["UserID"] = dr["AgentID"];
            Session["username"] = dr["AgentName"];
            Session["IsVerifier"] = dr["btVerifier"];
            Response.Write(Session["username"]);
            Response.Write(Session["Lanid"]);
        }

        {

            HumanMessage.Style["visibility"] = "hidden";
            HumanMessage.Visible = false;
            if (!this.IsPostBack)
            {
                this.GetGridView();
                lblReportName.CurrentPage = "Client License Master";


            }

        }
    }

    private void BindSourceState()
   {
	try 
    {
		DataTable dt = new DataTable();
        DBAccess db = new DBAccess("CRM");
        db.slDataAdd("Type", "DDL_COUNTRY");
        dt = db.ReturnTable("CMF_GET_ClientLicenseDetail","" , true);
        db = null;
        ddlSource.DataTextField = "CountryName";
        ddlSource.DataValueField = "ID";
        ddlSource.DataSource = dt;
        ddlSource.DataBind();
        ddlSource.Items.Insert(0, new ListItem("--Select--", "0"));
        ddlSource.SelectedIndex = 0;
      
	} catch (Exception ex) {
		throw ex;
	}


}

    private void BindReciepientState()
    {
        try
        {
            DataTable dt = new DataTable();
            DBAccess db = new DBAccess("CRM");
            db.slDataAdd("Type", "DDL_COUNTRY");
            dt = db.ReturnTable("CMF_GET_ClientLicenseDetail", "", true);
            db = null;
            ddlRec.DataTextField = "CountryName";
            ddlRec.DataValueField = "ID";
            ddlRec.DataSource = dt;
            ddlRec.DataBind();
            ddlRec.Items.Insert(0, new ListItem("--Select--", "0"));
            ddlRec.SelectedIndex = 0;
            
        }
        catch (Exception ex)
        {
            throw ex;
        }


    }

    private void BindClientName()
    {
        try
        {
            DataTable dt = new DataTable();
            DBAccess db = new DBAccess("CRM");
            db.slDataAdd("Type", "DDL_CLIENTNAME");
            dt = db.ReturnTable("CMF_GET_ClientLicenseDetail", "", true);
            db = null;
            ddlClientname.DataTextField = "ClientName";
            ddlClientname.DataValueField = "ID";
            ddlClientname.DataSource = dt;
            ddlClientname.DataBind();
            ddlClientname.Items.Insert(0, new ListItem("--Select--", "0"));
            ddlClientname.SelectedIndex = 0;

        }
        catch (Exception ex)
        {
            throw ex;
        }


    }

    private void BindLicenseType()
    {
        try
        {
            DataTable dt = new DataTable();
            DBAccess db = new DBAccess("CRM");
            db.slDataAdd("Type", "DDL_LICENSETYPE");
            dt = db.ReturnTable("CMF_GET_ClientLicenseDetail", "", true);
            db = null;
            ddlLicenseType.DataTextField = "LicenseType";
            ddlLicenseType.DataValueField = "ID";
            ddlLicenseType.DataSource = dt;
            ddlLicenseType.DataBind();
            ddlLicenseType.Items.Insert(0, new ListItem("--Select--", "0"));
            ddlLicenseType.SelectedIndex = 0;

        }
        catch (Exception ex)
        {
            throw ex;
        }


    }


    #endregion

    #region "--- Events ---"

    protected void btnSave_Click(object sender, EventArgs e)
    {


        string type = "";
        
        try
        {
            if ((btnSave.Text == "Save"))
            {
                type = "INSERT";

                SaveClientDetailed(type,"0");
                //GetGridView();

            }
            else if ((btnSave.Text == "Update"))
            {
                type = "UPDATE";
                lblHeader.Text = "UPDATE CLIENT LICENSE";
                SaveClientDetailed(type, hdnPanelRoleprocessMapid.Value);
            }


            GetGridView();


            
        }
        catch (Exception Ex)
        { }

    }


   
    public void SaveClientDetailed(string Type, string ID)
   {
       
       //System.DateTime Expdate = System.DateTime.Parse(UcDatePicker1.Text).AddYears(1);
       //string Expdate1 = Expdate.ToString("yyyy-MM-dd");
       //Expdate1 =  //Expdate.ToString("yyyymmdd");

       //string FromDate = string.Empty;
       //string ToDate = string.Empty;
       //DateTime CDate1 = Convert.ToDateTime(txtFDate.Text);
       //FromDate = CDate1.ToString("yyyy-MM-dd");
        //System.DateTime date1 = default(System.DateTime);
        //System.DateTime date2 = default(System.DateTime);
        //date1 = System.DateTime.Parse(UcDatePicker1.Text);
        //date2 = System.DateTime.Parse(UcDatePicker2.Text);

        try
        {
            

            DBAccess db = new DBAccess("CRM");
            DataTable dt = default(DataTable);
            db.slDataAdd("ClientName", ddlClientname.SelectedValue);
            db.slDataAdd("LNo", TxtKey.Text);
            db.slDataAdd("ID", ID);
         
            db.slDataAdd("Type", Type);
            db.slDataAdd("IsActive", 1);           
            db.slDataAdd("Remarks", TxtRemarks.Text);
            db.slDataAdd("Remarks1", "");
            db.slDataAdd("Remarksint ", 0);
            //db.slDataAdd("UpdatedBy", "");
           // db.slDataAdd("UpdatedDatetime", "");
            db.slDataAdd("LType", ddlLicenseType.SelectedValue);
            db.slDataAdd("LCount", TxtLic.Text);
            db.slDataAdd("PDate", UcDatePicker1.yyyymmdd);
            db.slDataAdd("AppliedDate", UcDatePicker2.yyyymmdd);
            db.slDataAdd("Attachment", hdnattach.Value);
            db.slDataAdd("SourceCountry", ddlSource.SelectedItem.Value);
            db.slDataAdd("RecCountry",ddlRec.SelectedItem.Value);
            db.slDataAdd("SysName", TxtSystem.Text);
            db.slDataAdd("AppliedAt", TxtApp.Text);
            //db.slDataAdd("RDate", UcDatePicker3.yyyymmdd);
            db.slDataAdd("Dev", TxtDev.Text);
            db.slDataAdd("Process", TxtProc.Text);
            db.slDataAdd("EmailId", TxtEmailId.Text);
            //db.slDataAdd("Expirydate", Expdate1);
            if (Type == "UPDATE")
            {                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         
                db.slDataAdd("UpdatedBy", Session["UserID"]);
                db.slDataAdd("UpdatedDatetime", DateTime.Now);
            }
            else
            {
                db.slDataAdd("CreatedBy", Session["UserID"]);
                db.slDataAdd("CreatedDatetime", DateTime.Now);
            }
           

            dt = db.ReturnTable("CMF_GET_ClientLicenseDetail", "", true);
            db = null;
            if ((dt != null))
            {
                switch ((dt.Rows[0]["MESSAGE_TYPE"].ToString()))
                {
                    case "S":
                        SuccessMessage(dt.Rows[0]["MESSAGE"].ToString());
                        break;

                    case "E":
                        AlertMessage(dt.Rows[0]["MESSAGE"].ToString());
                        break;
                }
            }
        }
        catch (Exception ex)
        {
            SuccessMessage(ex.ToString());
        }
    }

    private void GetGridView()
    {
        DBAccess db = new DBAccess("CRM");
        DataTable dt = default(DataTable);
        try
        {
            //db.slDataAdd("ClientName", "");
            //db.slDataAdd("ID", "");
            db.slDataAdd("Type", "SELECT");
            //db.slDataAdd("IsActive", 1);
            //db.slDataAdd("CreatedBy", "");
            //db.slDataAdd("CreatedDatetime", DateTime.Now);
            //db.slDataAdd("UpdatedBy", "");
            //db.slDataAdd("UpdatedDatetime", "");
            //db.slDataAdd("Remarks", "");
            //db.slDataAdd("Remarks1", "");
            //db.slDataAdd("Remarksint ", 0);

            dt = db.ReturnTable("CMF_GET_ClientLicenseDetail", "", true);
            db = null;
            gdData.DataSource = dt;
            gdData.DataBind();
            if (dt.Rows.Count > 0)
            {
                btnAddFirst.Visible = false;
            }
            else
            {
                btnAddFirst.Visible = true;
            }

        }
        catch (Exception ex)
        {
            //AlertMessage(ex.ToString);
        }
    }

    private void GetData(string ID)
    {
        DBAccess db = new DBAccess("CRM");
        DataTable dt = default(DataTable);
        try
        {
            
            db.slDataAdd("ID", ID);
            db.slDataAdd("Type", "SELECTDATA");

            dt = db.ReturnTable("CMF_GET_ClientLicenseDetail", "", true);
            //ddlSource.SelectedItem.Value = dt.Rows[0]["SourceCountryID"].ToString();
            DataTable dt1 = new DataTable();
            dt1.Columns.Add(new DataColumn("SourceCountry", typeof(System.String)));
            dt1.Columns.Add(new DataColumn("SourceCountryID", typeof(System.Int32)));

            DataRow newSelRow1 = dt1.NewRow();
            newSelRow1["SourceCountry"] = dt.Rows[0]["SourceCountry"].ToString();
            newSelRow1["SourceCountryID"] = dt.Rows[0]["SourceCountryID"].ToString();
            dt1.Rows.Add(newSelRow1);

     



            ddlSource.DataTextField = dt1.Rows[0]["SourceCountry"].ToString();
            ddlSource.DataValueField = dt1.Rows[0]["SourceCountryID"].ToString();
            ddlSource.DataSource = dt1;
            ddlSource.DataBind();
            ddlSource.SelectedIndex = ddlSource.Items.IndexOf(ddlSource.Items.FindByText(dt1.Rows[0]["SourceCountryID"].ToString()));


            //ddlRec.SelectedItem.Value = dt.Rows[0]["ReciepietCountryID"].ToString();
            //ddlClientname.SelectedItem.Value= dt.Rows[0]["ClientID"].ToString();
            ddlClientname.SelectedValue = dt.Rows[0]["ClientName"].ToString();
           
            //if (dt.Rows[0]["LicenseTypeID"].ToString() == "1")

            //    ddlLicenseType.SelectedItem.Text = "Designer";
            //else
            //    ddlLicenseType.SelectedItem.Text = "Runtime";



            TxtKey.Text = dt.Rows[0]["LicenseNo"].ToString();
            TxtLic.Text = dt.Rows[0]["LicenseCount"].ToString();
            TxtProc.Text = dt.Rows[0]["Process"].ToString();
            TxtDev.Text = dt.Rows[0]["Developer"].ToString();
            UcDatePicker1.value = Convert.ToDateTime(dt.Rows[0]["ProcurementDate"].ToString());
            UcDatePicker2.value = Convert.ToDateTime(dt.Rows[0]["AppliedDate"].ToString());
           // UcDatePicker3.value = Convert.ToDateTime(dt.Rows[0]["RenewDate"].ToString());
            TxtApp.Text = dt.Rows[0]["AppliedAt"].ToString();
            TxtSystem.Text = dt.Rows[0]["SystemName"].ToString();
            TxtRemarks.Text = dt.Rows[0]["Remarks"].ToString();
            Session["UserID"] =dt.Rows[0]["CreatedBy"].ToString();
            Session["CreatedDatetime"]=dt.Rows[0]["CreatedDateTime"].ToString();
            Attachment_curr.Value = dt.Rows[0]["Attachment"].ToString();
            //hdnattach.Value = dt.Rows[0]["Attachment"].ToString();


        }
        catch (Exception ex)
        {
            //AlertMessage(ex.ToString);
        }
    }
    private void Reset()
    {
        try
        {
           

            ddlSource.SelectedValue = "0";
            ddlRec.SelectedValue = "0";
            ddlClientname.SelectedValue = "0";
            ddlLicenseType.SelectedValue = "0";
          
            TxtKey.Text = "";
            TxtLic.Text = "";
            TxtProc.Text = "";
            TxtDev.Text = "";
            //UcDatePicker3.value = DateTime.Now;
            UcDatePicker1.value = DateTime.Now;
            UcDatePicker2.value = DateTime.Now;
            TxtApp.Text = "";
            TxtSystem.Text = "";
            TxtRemarks.Text = "";


        }
        catch (Exception ex)
        {
            AlertMessage(ex.Message);
        }
    }

    private bool Validation()
    {
        bool flag = true;

        if ((ddlSource.SelectedValue == "0") && (ddlSource.SelectedItem.Text == "--Select--"))
        {
            lblIsValidInput.Visible = true;
            lblIsValidInput.Text = "Please select Source Country";
            flag = false;
            ddlSource.BorderColor = System.Drawing.Color.Red;
            OpenDialog();
            return flag;
        }
        else
        {
            lblIsValidInput.Visible = false;
            ddlSource.BorderColor = System.Drawing.Color.Black;

        }


        if ((ddlRec.SelectedValue == "0") && (ddlRec.SelectedItem.Text == "--Select--"))
        {
            lblIsValidInput.Visible = true;
            lblIsValidInput.Text = "Please select Reciepient Country";
            flag = false;
            ddlRec.BorderColor = System.Drawing.Color.Red;
            OpenDialog();
            return flag;
        }
        else
        {
            lblIsValidInput.Visible = false;
            ddlRec.BorderColor = System.Drawing.Color.Black;

        }

        if ((ddlClientname.SelectedValue == "0") && (ddlClientname.SelectedItem.Text == "--Select--"))
        {
            lblIsValidInput.Visible = true;
            lblIsValidInput.Text = "Please select Client Name";
            flag = false;
            ddlClientname.BorderColor = System.Drawing.Color.Red;
            OpenDialog();
            return flag;
        }
        else
        {
            lblIsValidInput.Visible = false;
            ddlClientname.BorderColor = System.Drawing.Color.Black;
          
        }



        if (string.IsNullOrEmpty(TxtKey.Text))
        {
            lblIsValidInput.Visible = true;
            lblIsValidInput.Text = "Please Enter License Key";
            flag = false;
            TxtKey.BorderColor = System.Drawing.Color.Red;
            OpenDialog(); 
            return flag;
        }
        //else if (!Regex.IsMatch("[^0-9]",TxtKey.Text))
        //{
        //    lblIsValidInput.Visible = true;
        //    lblIsValidInput.Text = "Please Enter Numeric Nos";
        //    flag = false;
        //    TxtKey.BorderColor = System.Drawing.Color.Red;
        //    OpenDialog();
        //    return flag;
        //}
        else
        {
            lblIsValidInput.Visible = false;
            TxtKey.BorderColor = System.Drawing.Color.Black;

        }


        if (string.IsNullOrEmpty(TxtLic.Text))
        {
            lblIsValidInput.Visible = true;
            lblIsValidInput.Text = "Please Enter License Count";
            flag = false;
            TxtLic.BorderColor = System.Drawing.Color.Red;
            OpenDialog();
            return flag;
        }
        //else if (!Regex.IsMatch(TxtLic.Text,"[^0-9]"))
        //{
        //    lblIsValidInput.Visible = true;
        //    lblIsValidInput.Text = "Please Enter Numeric Nos";
        //    flag = false;
        //    TxtLic.BorderColor = System.Drawing.Color.Red;
        //    OpenDialog();
        //    return flag;
        //}

        else
        {
            lblIsValidInput.Visible = false;
            TxtLic.BorderColor = System.Drawing.Color.Black;

        }


        if (string.IsNullOrEmpty(TxtApp.Text))
        {
            lblIsValidInput.Visible = true;
            lblIsValidInput.Text = "Please Enter Applied At";
            flag = false;
            TxtApp.BorderColor = System.Drawing.Color.Red;
            OpenDialog();
            return flag;
        }
        //else if (!Regex.IsMatch(TxtApp.Text,"^[a-zA-Z0-9]*$"))
        //{
        //    lblIsValidInput.Visible = true;
        //    lblIsValidInput.Text = "Please Enter Alphanumeric characters";
        //    flag = false;
        //    TxtApp.BorderColor = System.Drawing.Color.Red;
        //    OpenDialog();
        //    return flag;
        //}
        else
        {
            lblIsValidInput.Visible = false;
            TxtApp.BorderColor = System.Drawing.Color.Black;
            OpenDialog();
        }

        if (string.IsNullOrEmpty(TxtSystem.Text))
        {
            lblIsValidInput.Visible = true;
            lblIsValidInput.Text = "Please Enter System Name";
            flag = false;
            TxtSystem.BorderColor = System.Drawing.Color.Red;
            OpenDialog();
            return flag;
        }
        //else if (!Regex.IsMatch(TxtSystem.Text,"^[a-zA-Z0-9]*$"))
        //{
        //    lblIsValidInput.Visible = true;
        //    lblIsValidInput.Text = "Please Enter Alphanumeric characters";
        //    flag = false;
        //    TxtSystem.BorderColor = System.Drawing.Color.Red;
        //    OpenDialog();
        //    return flag;
        //}
        else
        {
            lblIsValidInput.Visible = false;
            TxtSystem.BorderColor = System.Drawing.Color.Black;
            OpenDialog();
        }



        if ((ddlLicenseType.SelectedValue == "0") && (ddlLicenseType.SelectedItem.Text == "--Select--"))
        {
            lblIsValidInput.Visible = true;
            lblIsValidInput.Text = "Please select License Type";
            flag = false;
            ddlLicenseType.BorderColor = System.Drawing.Color.Red;
            OpenDialog();
            return flag;
        }
        else
        {
            lblIsValidInput.Visible = false;
            ddlLicenseType.BorderColor = System.Drawing.Color.Black;
            OpenDialog();
        }

       
        if (string.IsNullOrEmpty(TxtDev.Text))
        {
            lblIsValidInput.Visible = true;
            lblIsValidInput.Text = "Please Enter Developer";
            flag = false;
            TxtDev.BorderColor = System.Drawing.Color.Red;
            OpenDialog();
            return flag;
        }
        //else if (!Regex.IsMatch(TxtDev.Text,"^[a-zA-Z0-9]*$"))
        //{
        //    lblIsValidInput.Visible = true;
        //    lblIsValidInput.Text = "Please Enter Alphanumeric characters";
        //    flag = false;
        //    TxtDev.BorderColor = System.Drawing.Color.Red;
        //    OpenDialog();
        //    return flag;
        //}
        else
        {
            lblIsValidInput.Visible = false;
            TxtDev.BorderColor = System.Drawing.Color.Black;
            OpenDialog();
        }

        if (string.IsNullOrEmpty(TxtProc.Text))
        {
            lblIsValidInput.Visible = true;
            lblIsValidInput.Text = "Please Enter Process";
            flag = false;
            TxtProc.BorderColor = System.Drawing.Color.Red;
            OpenDialog();
            return flag;
        }
        //else if (!Regex.IsMatch(TxtProc.Text, "^[a-zA-Z0-9]*$"))
        //{
        //    lblIsValidInput.Visible = true;
        //    lblIsValidInput.Text = "Please Enter Alphanumeric characters";
        //    flag = false;
        //    TxtProc.BorderColor = System.Drawing.Color.Red;
        //    OpenDialog();
        //    return flag;
        //}
        else
        {
            lblIsValidInput.Visible = false;
            TxtProc.BorderColor = System.Drawing.Color.Black;

        }

      
          
        if (string.IsNullOrEmpty(TxtRemarks.Text))
        {
            lblIsValidInput.Visible = true;
            lblIsValidInput.Text = "Please Enter Remarks";
            flag = false;
            TxtRemarks.BorderColor = System.Drawing.Color.Red;
            OpenDialog();
            return flag;
        }
        //else if (!Regex.IsMatch(TxtRemarks.Text,"^[a-zA-Z0-9]*$"))
        //{
        //    lblIsValidInput.Visible = true;
        //    lblIsValidInput.Text = "Please Enter Alphanumeric characters";
        //    flag = false;
        //    TxtRemarks.BorderColor = System.Drawing.Color.Red;
        //    OpenDialog();
        //    return flag;
        //}
        else
        {
            lblIsValidInput.Visible = false;
            TxtRemarks.BorderColor = System.Drawing.Color.Black;

        }

     
        return flag;
    }
    private bool validdate(DateTime selecteddate)
    {
        System.DateTime date1 = default(System.DateTime);
        System.DateTime date2 = default(System.DateTime);
        date1 = System.DateTime.Parse(UcDatePicker1.Text);
        date2 = System.DateTime.Parse(UcDatePicker2.Text);
        if ((DateTime.Compare(date1, date2) > 0))
        {
            return false;
        }
        else
        {
            return true;
        }
    }


    protected void UcDatePicker1_Changed(object sender, System.EventArgs e)
    {
        try
        {
            DateTime selectedDate = Convert.ToDateTime(UcDatePicker1.Text);
            //DateTime previousDate = DateTime.Now.Date.AddDays(-5);
            if ((selectedDate > DateTime.Now.Date))
            {
                lblIsValidInput.Visible = true;
                lblIsValidInput.Text = "Procurement Date cannot be greater than Today's Date";
                UcDatePicker1.value = DateTime.Now.Date;
                OpenDialog();
                return;
            }
            //else if (!validdate(UcDatePicker1.value))
            //{
            //    lblIsValidInput.Visible = true;
            //    lblIsValidInput.Text = "Date not in valid range";
            //    UcDatePicker1.value = DateTime.Now.Date;
            //   // CalculateDays();
            //    return;
            //}
            else
            {
                lblIsValidInput.Visible = false;
                OpenDialog();
            }
        }
        catch (Exception ex)
        {
            AlertMessage(ex.Message);
        }

    }

    protected void UcDatePicker2_Changed(object sender, System.EventArgs e)
    {
        try
        {
            DateTime selectedDate = Convert.ToDateTime(UcDatePicker2.Text);

            if ((selectedDate > DateTime.Now.Date))
            {
                lblIsValidInput.Visible = true;
                lblIsValidInput.Text = "Applied Date cannot be greater than Today's Date";
                UcDatePicker2.value = DateTime.Now.Date;
                OpenDialog();
                return;
            }

            else
            {
                lblIsValidInput.Visible = false;
                OpenDialog();
            }
        }
        catch (Exception ex)
        {
            AlertMessage(ex.Message);
        }

    }

    //protected void UcDatePicker3_Changed(object sender, System.EventArgs e)
    //{
    //    try
    //    {
    //        DateTime selectedDate = Convert.ToDateTime(UcDatePicker3.Text);

    //        if ((selectedDate > DateTime.Now.Date))
    //        {
    //            lblIsValidInput.Visible = true;
    //            lblIsValidInput.Text = "Renew Date cannot be greater than Today's Date";
    //            UcDatePicker3.value = DateTime.Now.Date;
    //            OpenDialog();
    //            return;
    //        }

    //        else
    //        {
    //            lblIsValidInput.Visible = false; 
    //            OpenDialog();
    //        }
    //    }
    //    catch (Exception ex)
    //    {
    //        AlertMessage(ex.Message);
    //    }

    //}

    protected void AddNew_Click(object sender, EventArgs e)
    {
        try
        {

            
            Reset();
            OpenDialog();
          
        }
        catch (Exception ex)
        { }



    }

    protected void OnPageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        gdData.PageIndex = e.NewPageIndex;
        gdData.DataBind();
        GetGridView();
    }

    protected void btnAddFirst_Click(object sender, EventArgs e)
    {
        btnSave.Text = "Save";
        lblHeader.Text = "ADD DETAILED CLIENT LICENSE DATA";
        OpenDialog();

    }

    #endregion


    #region "--- Utility ---"
    private void AlertMessage(string msg)
    {
        lblHumanMessage.Text = msg;
        HumanMessage.CssClass = "HMFail";
        HumanMessage.Visible = true;
        lblHumanMessage.Visible = true;
        HumanMessage.Style["visibility"] = "visible";
        // HumanMessage.Style.Item("visibility") = "visible";

    }

    private void SuccessMessage(string msg)
    {
        lblHumanMessage.Text = msg;
        HumanMessage.CssClass = "HMSuccess";
        HumanMessage.Visible = true;
        lblHumanMessage.Visible = true;
        HumanMessage.Style["visibility"] = "visible";
        //HumanMessage.Item["visibility"].tostring() = "visible";

    }

    protected void HumanMsgbtn_Click(object sender, EventArgs e)
    {
        // HumanMessage.Style["visibility"].ToString() = "";
        HumanMessage.Visible = false;
        lblHumanMessage.Text = "";
        HumanMessage.Style["visibility"] = "";
        
    }

    #endregion


    private void OpenDialog()
    {
        string str = null;
        str = "$('#DialogBackground').height($(document).height()-5);$('#DialogBackground').width($(window).width());$('#DialogBackground').css('visibility','visible');$('#PanelIDPForm').css('visibility','visible');" + " $('#PanelIDPForm').css('left',($(window).width() - $('#PanelIDPForm').width())/2); ";
        ScriptManager.RegisterStartupScript(Page, Page.GetType(), "Movedialog", str, true);
    }



    #region "---Grid Events ---"
    protected void gdData_RowEditing(object sender, GridViewEditEventArgs e)
    {
        //btnSave.Text = "Update";
        //int index = Convert.ToInt32(e.NewEditIndex);
        //hdnPanelRoleprocessMapid.Value = ((System.Web.UI.WebControls.HiddenField)gdData.Rows[index].FindControl("hdnID")).Value;
        //string ID = hdnPanelRoleprocessMapid.Value;
        //GetData(ID);
        //OpenDialog(
        

        int index = Convert.ToInt32(e.NewEditIndex);
        hdnPanelRoleprocessMapid.Value = ((System.Web.UI.WebControls.HiddenField)gdData.Rows[index].FindControl("hdnID")).Value;
        string ID = hdnPanelRoleprocessMapid.Value;
        //ID = ((System.Web.UI.WebControls.HiddenField)gdData.Rows[index].FindControl("hdnID")).Value;
        UcDatePicker1.value = Convert.ToDateTime(((Label)gdData.Rows[index].FindControl("lblprocdate")).Text);
        UcDatePicker2.value = Convert.ToDateTime(((Label)gdData.Rows[index].FindControl("lblappdate")).Text);
        //UcDatePicker3.value = Convert.todatetime(((label)gdData.rows[index].FindControl("lblren")).text);
        ddlSource.SelectedValue = ((Label)gdData.Rows[index].FindControl("lblsourceID")).Text;
        ddlRec.SelectedValue = ((Label)gdData.Rows[index].FindControl("lblrecID")).Text;
        ddlClientname.SelectedValue = ((Label)gdData.Rows[index].FindControl("lblCID")).Text;
        ddlLicenseType.SelectedValue = ((Label)gdData.Rows[index].FindControl("lbllictypeID")).Text;
        //ddlClientname.SelectedValue = ((Label)gdData.Rows[index].FindControl("lblCID")).Text;
        TxtKey.Text = ((Label)gdData.Rows[index].FindControl("lblLNO")).Text;
        TxtLic.Text = ((Label)gdData.Rows[index].FindControl("lblliccount")).Text;
        TxtApp.Text = ((Label)gdData.Rows[index].FindControl("lblappliedat")).Text;
        TxtSystem.Text = ((Label)gdData.Rows[index].FindControl("lblsys")).Text;
        TxtDev.Text = ((Label)gdData.Rows[index].FindControl("lbldev")).Text;
        TxtProc.Text = ((Label)gdData.Rows[index].FindControl("lblprocess")).Text;
        TxtRemarks.Text = ((Label)gdData.Rows[index].FindControl("lblremark")).Text;
        TxtEmailId.Text = ((Label)gdData.Rows[index].FindControl("lblEmailId")).Text;
        //ddlLicenseType.SelectedValue = ((Label)gdData.Rows[index].FindControl("lbllictype")).Text;
        Label attach = (Label)gdData.Rows[index].FindControl("lblattach");
        lblattachtext.Text = attach.Text;
        hdnattach.Value = attach.Text;
       
         
       
        OpenDialog();
    }



    public void DeleteLicense(string Id)
    {
        try
        {
            DBAccess db = new DBAccess("CRM");
            DataTable dt = default(DataTable);
            db.slDataAdd("ID", Id);
            db.slDataAdd("Type", "DELETE");
            dt = db.ReturnTable("CMF_GET_ClientLicenseDetail", "", true);
            db = null;
            if ((dt != null))
            {
                switch ((dt.Rows[0]["MESSAGE_TYPE"].ToString()))
                {
                    case "S":
                        SuccessMessage(dt.Rows[0]["MESSAGE"].ToString());
                        GetGridView();
                        break;
                    case "E":
                        AlertMessage(dt.Rows[0]["MESSAGE"].ToString());
                        break;
                }
            }

        }
        catch (Exception ex)
        {
        }
    }
   
    protected void gdData_RowCommand(object sender, GridViewCommandEventArgs e)
    {
         
        try
        {
            if (e.CommandName.ToLower() == "edit")
            {
                btnSave.Text = "Update";
                lblHeader.Text = "UPDATE CLIENT LICENSE DETAILS";

           
            }

            else if (e.CommandName.ToLower() == "addnew")
            {
                btnSave.Text = "save";
                lblHeader.Text = "ADD CLIENT LICENSE DETAILS";
                Reset();
                OpenDialog();



            }

           
            //else if (e.CommandName == "Download")
            //{
            //    //Response.Clear();
            //    //Response.ContentType = "application/octect-stream";
            //    //Response.AppendHeader("content-disposition", "attachment;filename" + e.CommandArgument);
            //    //Response.TransmitFile(Server.MapPath("~/myupload/") + e.CommandArgument);
            //    //Response.End();
            //    //string strURL = txtFileName.Text;
            //    WebClient req = new WebClient();
            //    HttpResponse response = HttpContext.Current.Response;
            //    response.Clear();
            //    response.ClearContent();
            //    response.ClearHeaders();
            //    response.Buffer = true;
            //    //string Filename = "~\\myupload\\sampleimagegear.txt";

            //    response.AddHeader("Content-Disposition", "attachment;filename=\"" + Server.MapPath(e.CommandArgument.ToString()) + "\"");
            //    byte[] data = req.DownloadData(Server.MapPath(e.CommandArgument.ToString()));
            //    response.BinaryWrite(data);

            //    //response.Flush();
            //    response.End();
            //    //HttpContext.Current.ApplicationInstance.CompleteRequest();
                
            //}


        }
        catch (Exception ex)
        {
            AlertMessage(ex.Message);
        }

    }

    protected void gdData_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        try
        {
            DBAccess db = new DBAccess("CRM");

            db.slDataAdd("ID", ((HiddenField)gdData.Rows[e.RowIndex].FindControl("hdnID")).Value);
            db.slDataAdd("Type", "DELETE");
            db.Executeproc("CMF_GET_ClientLicenseDetail");
            db = null;
            GetGridView();
            
        }
        catch (Exception ex)
        {
            AlertMessage(ex.Message);
        }

    }

    #endregion

  
    // This button click event is used to download files from gridview
    //protected void lnkDownload_Click(object sender, EventArgs e)
    //{
    //    //LinkButton lnkbtn = sender as LinkButton;
    //    //GridViewRow gvrow = lnkbtn.NamingContainer as GridViewRow;
    //    //string filePath = hdnattach.Value;//gdData.DataKeys[gvrow.RowIndex].Value.ToString();

    //    //string filename = "kkkkkk.txt";
    //    //Response.ContentType = "image/jpg";
    //    //Response.AddHeader("Content-Disposition", "attachment;filename=" + filename);
    //    //Response.TransmitFile(Server.MapPath("~/myupload/" + filename));
    //    //Response.End();

    //    WebClient req = new WebClient();
    //    HttpResponse response = HttpContext.Current.Response;
    //    response.Clear();
    //    response.ClearContent();
    //    response.ClearHeaders();
    //    response.Buffer = true;
    //    //string Filename = "~\\myupload\\sampleimagegear.txt";
    //    string fienamae = HttpContext.Current.Server.MapPath("~/myupload/sampleimagegear.txt");
    //   // string fienamae ="@C:\\Users\\sakshi.sharma\\Documents\\Visual Studio 2012\\Projects\\Support\\Support\\Terms2.0\\myupload\\sampleimagegear.txt";
    //    response.AddHeader("Content-Disposition", "attachment;filename=\"" + fienamae + "\"");
    //    byte[] data = req.DownloadData(fienamae);
    //    response.BinaryWrite(data);

    //    //response.Flush();
    //    response.End();
    //}

    protected void btnUpload_Click(object sender, EventArgs e)
    {
        string filename = "";
        string filepath = "";

        //filename = fileUpload1.FileName.ToString();
        filename = Path.GetFileName(fileUpload1.PostedFile.FileName);
        // filepath = "~\\myupload\\" + filename;//works fine
        filepath = "..\\myupload\\" + filename;
        string strpath = System.IO.Path.GetExtension(filename);




        if (fileUpload1.HasFile)
        {
            if (strpath == ".jpg" || strpath == ".jpeg" || strpath == ".gif" || strpath == ".png" || strpath == ".pdf")
            {
                
                fileUpload1.SaveAs(Server.MapPath(filepath));
            }
            else
            {
                ScriptManager.RegisterStartupScript(this, this.GetType(), "script", "alert('Select only .jpg, .jpeg, .gif, .pdf format!!');", true);
            }
            
           // AlertMessage("File uploaded sucessfully.");
        }
        //PanelIDPForm.Visible = true;
        OpenDialog();
        Attachment = filepath.ToString();
        hdnattach.Value = Attachment;
        lblattachtext.Text = hdnattach.Value;
        //HiddenField attach =((System.Web.UI.WebControls.HiddenField)gdData.Rows[index].FindControl("hdnattach")).Value;
       
        

       // int index = Convert.ToInt32(e.NewEditIndex);

    }

    protected void lnkDownload_Click(object sender, EventArgs e)
    {
        hdnattach.Value = Attachment;
        DownloadFil(hdnattach.Value);
    }
   
 
     public static void DownloadFil(string fuldFilNavn)
    {
        HttpContext context = HttpContext.Current;
        context.Response.ClearHeaders();
        context.Response.ClearContent();
        string filNavn = Uri.EscapeDataString(Path.GetFileName(fuldFilNavn)).Replace("+", "%20");
        context.Response.AppendHeader("Content-Disposition", "attachment;filename*=utf-8''" + filNavn);
        context.Response.AppendHeader("Last-Modified", File.GetLastWriteTimeUtc(fuldFilNavn).ToString("R"));
        context.Response.ContentType = "application/octet-stream";
        context.Response.AppendHeader("Content-Length", new FileInfo(fuldFilNavn).Length.ToString());
        context.Response.TransmitFile(fuldFilNavn);
        context.Response.End();
    }

     protected void LinkButton1_Click(object args, EventArgs e)
     {

         try
         {
             string filePath = (args as LinkButton).CommandArgument;

             Response.ContentType = ContentType;
             Response.AppendHeader("Content-Disposition", "attachment; filename=" + Path.GetFileName(filePath));
             Response.WriteFile(filePath);
             Response.Flush();
             Response.End();
             //HttpContext.Current.ApplicationInstance.CompleteRequest();
         }
         catch (Exception ex)
         {
             AlertMessage(ex.ToString());
         }


     }

     public void getName()
     {
 
     }


     private void ScheduleSendmail()
     {
         try
         {
             string EmailId = "";
              //System.DateTime Expdate = 
             DateTime TodayDate = DateTime.Now;
             DateTime Expdate_months = Convert.ToDateTime(TodayDate.AddMonths(2).ToString("yyyy-MM-dd"));
             DateTime ExpireDays = Convert.ToDateTime(TodayDate.AddDays(15).ToString("yyyy-MM-dd"));
             DateTime ExpireDays1 = Convert.ToDateTime(TodayDate.AddDays(7).ToString("yyyy-MM-dd"));
             days = Convert.ToInt32((Expdate_months - TodayDate).TotalDays);
             days1 = Convert.ToInt32((ExpireDays - TodayDate).TotalDays);
             days2 = Convert.ToInt32((ExpireDays1 - TodayDate).TotalDays);
            // string xdays = DateTime.Now.AddDays
            //  Expdate1 =  Expdate.ToString("yyyymmdd");
             DBAccess db = new DBAccess("CRM");
             DataTable dt = default(DataTable);
             db.slDataAdd("Type", "SendMail");

             if (days >= 60)
             {                 
                 db.slDataAdd("ExpiryDate", Expdate_months.ToString("yyyy-MM-dd"));
                 //dt = db.ReturnTable("CMF_GET_ClientLicenseDetail", "", true);
                
 
             }
             else if (days1 >= 15)
             {
                 db.slDataAdd("ExpiryDate", ExpireDays.ToString("yyyy-MM-dd"));
                 
             }
             else if (days2 >= 7)
             {
                 db.slDataAdd("ExpiryDate", ExpireDays.ToString("yyyy-MM-dd"));
 
             }
             dt = db.ReturnTable("CMF_GET_ClientLicenseDetail", "", true);
             foreach (DataRow row in dt.Rows)
             {
                 EmailId = row["mailid"].ToString();
                 SendMail();
             }
         }
         catch (Exception ex)
         {
 
         }

     
     }

     public void SendMail()
     {
         try
         {

             MailMessage msg = new MailMessage();
             msg.From = new MailAddress("arvind.kumar@coforge.com");
             string[] ToMuliId = ToAdd.Split(',');
             foreach (string MuliId in ToMuliId)
             {
                 msg.To.Add(new MailAddress(MuliId));
             }
             //foreach (string ToEMailId in mailId)
             //{
                  //adding multiple TO Email Id
             //}
             //msg.To.Add("mohinigalhotra@gmail.com");
             if (days >= 60)
             {
                 msg.Body = string.Format("Your UiPath License will get Expire in 60 Days. <br/> Thanks,<br/>Business Innnovation Group");
                 //mm.Body = string.Format("<b>Happy Birthday </b>{0}<br /><br />Many happy returns of the day.", name);
             }
             else if (days1 >= 15)
             {
                 msg.Body = string.Format("Your UiPath License will get Expire in 15 Days. <br/> Thanks,<br/>Business Innnovation Group");
             }
             else if (days2 >= 7)
             {
                 msg.Body = string.Format("Your UiPath License will get Expire in 7 Days. <br/> Thanks,<br />Business Innnovation Group");
             }
             msg.IsBodyHtml = true;
             msg.Subject = "License Expire";
             SmtpClient smt = new SmtpClient("smtp.office365.com");
             smt.Port = 587;
             smt.Credentials = new NetworkCredential("arvind.kumar@coforge.com", "Business@23");
             smt.EnableSsl = true;
             smt.Send(msg);
             //string script = "<script>alert('Mail Sent Successfully');self.close();</script>";
             //this.ClientScript.RegisterClientScriptBlock(this.GetType(), "sendMail", script);
         }
             
         catch (Exception ex)
         {
 
         }
        




     }

     
}