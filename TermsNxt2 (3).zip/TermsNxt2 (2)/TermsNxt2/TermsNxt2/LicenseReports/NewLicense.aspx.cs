﻿using Microsoft.VisualBasic;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using com.nss.DBAccess;
using System.Data.SqlClient;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Net.Mail;
using System.IO;

public partial class LicenseExpiryReports_NewLicense : System.Web.UI.Page
{
    //decimal rate { get; set; }
    //decimal value { get; set; }

    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["UserID"] == null)
        {
            if (User.Identity.Name.ToString().Contains("NSS\\"))
            {
                Session["Lanid"] = User.Identity.Name.ToString().Replace("NSS\\", "");
            }
            else
            {
                Session["Lanid"] = User.Identity.Name;
            }
            com.nss.DBAccess.DBAccess db = new com.nss.DBAccess.DBAccess();
            db.slDataAdd("UserId", Session["Lanid"]);
            System.Data.DataRow dr = db.ReturnRow("usp_CheckTermsUser", true);
            db = null;
            if (dr == null)
            {
                Response.Write("There is some problem in authenticating your credentials. Please make sure you are authorized to use this website.");
                return;
            }
            Session["CampaignID"] = dr["campaignid"];
            Session["AgentID"] = dr["AgentID"];
            Session["UserID"] = dr["AgentID"];
            Session["username"] = dr["AgentName"];
            Session["IsVerifier"] = dr["btVerifier"];
            Response.Write(Session["username"]);
            Response.Write(Session["Lanid"]);
        }
        HumanMessage.Style["visibility"] = "hidden";
        HumanMessage.Visible = false;

       
        if (!IsPostBack)
        {
            lblReportName.CurrentPage = "Add New License";            
            BindLicenseType();
            BindCostPriceType();
            txtProcDate.Text = DateTime.Now.ToString("dd-MM-yyyy");
            txtExpiryDate.Text = DateTime.Now.AddYears(1).ToString("dd-MM-yyyy");
            txtHandoverDate.Text = DateTime.Now.ToString("dd-MM-yyyy");            
            txtInvoiceDate.Text = DateTime.Now.ToString("dd-MM-yyyy");
            txtPODate.Text = DateTime.Now.ToString("dd-MM-yyyy");
        }
    }

    public void BindLicenseType()
    {
        try
        {
            DataTable dt = new DataTable();
            DBAccess db = new DBAccess("CRM");
            db.slDataAdd("Type", "DDL_LICENSETYPE");
            dt = db.ReturnTable("usp_RpaLicenseDetails", "", true);
            db = null;
            ddlLicenseType.DataTextField = "LicenseType";
            ddlLicenseType.DataValueField = "ID";
            ddlLicenseType.DataSource = dt;
            ddlLicenseType.DataBind();
            ddlLicenseType.Items.Insert(0, new ListItem("--Select--", "0"));
            ddlLicenseType.SelectedIndex = 0;
        }
        catch (Exception ex)
        {
            throw ex;
        }

    }

    public void BindCostPriceType()
    {
        try
        {
            DataTable dt = new DataTable();
            DBAccess db = new DBAccess("CRM");
            db.slDataAdd("Type", "DDLCostType");
            dt = db.ReturnTable("usp_RpaLicenseDetails", "", true);
            db = null;
            ddlCostType.DataTextField = "PriceType";
            ddlCostType.DataValueField = "Id";
            ddlCostType.DataSource = dt;
            ddlCostType.DataBind();
            ddlCostType.Items.Insert(0, new ListItem("--Select--", "0"));
            ddlCostType.SelectedIndex = 0;
        }
        catch (Exception ex)
        {
            throw ex;
        }


    }

    public void LicenseEntry()
    {
        DataTable dt = new DataTable();
        DBAccess db = new DBAccess("CRM");
        
        try
        {
             if(txtClientName.Text == "")
            {
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Client Name Should Not Be Blank!')", true);
            }
            else if (ddlLicenseType.SelectedValue == "0")
            {
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Select License Type!')", true);
            }
             else if (txtLicenseKey.Text == "")
             {
                 
                 ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('License Key should not be Blank!')", true);
             }
             else if (txtLicenseCount.Text == "")
             {
                 ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('License Count should not be Blank!')", true);
             }
             else if (txtProcDate.Text == "")
             {
                 ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Applied At should not be Blank!')", true);
             }
             else if (txtAppliedAt.Text == "")
             {
                 ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Applied At should not be Blank!')", true);
             }
             else if (txtHandoverDate.Text == "")
             {
                 ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('HandoverDate should not be Blank!')", true);
             }
             else if (ddlCostType.SelectedValue == "0")
             {
                 ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Select a Cost Type!')", true);
             }
             else if (txtExpiryDate.Text == "")
             {
                 ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('ExpiryDate should not be Blank!')", true);
             }            
             else if (txtRate.Text == "")
             {
                 ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Rate should not be Blank!')", true);
             }
             else if (txtValue.Text == "")
             {
                 ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('value Amount should not be Blank!')", true);
             }
             else if (txtInvoiceNo.Text == "")
             {
                 ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('InvoiceNo should not be Blank!')", true);
             }
             else if (txtInvoiceDate.Text == "")
             {
                 ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Invoice Date should not be Blank!')", true);
             }
             else if (txtPO.Text == "")
             {
                 ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('PO No. should not be Blank!')", true);
             }
             else if (txtPODate.Text == "")
             {
                 ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('PO Date should not be Blank!')", true);
             }
             else if (txtBillToCompny.Text == "")
             {
                 ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Bill To should not be Blank!')", true);
             }
             else if (txtOwnerEmailId.Text == "" && txtSPOCEmail.Text == "")
             {
                 ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Email should not be Blank!')", true);
             }

             else
             {
                 HDNProcDate.Value = txtProcDate.Text;
                 string procdate = (DateTime.ParseExact(HDNProcDate.Value, "dd-MM-yyyy", System.Globalization.CultureInfo.InvariantCulture)).ToString("yyyy-MM-dd");
                 
                 HdnhandOverDate.Value = txtHandoverDate.Text;
                 string HandoverDate = (DateTime.ParseExact(HdnhandOverDate.Value, "dd-MM-yyyy", System.Globalization.CultureInfo.InvariantCulture)).ToString("yyyy-MM-dd");
                 
                 HdnExpirydate.Value = txtExpiryDate.Text;
                 string ExpiryDate = (DateTime.ParseExact(HdnExpirydate.Value, "dd-MM-yyyy", System.Globalization.CultureInfo.InvariantCulture)).ToString("yyyy-MM-dd");

                 HdnRenewDtae.Value = txtExpiryDate.Text;
                 string RenewDate = (DateTime.ParseExact(HdnRenewDtae.Value, "dd-MM-yyyy", System.Globalization.CultureInfo.InvariantCulture)).ToString("yyyy-MM-dd");

                 HdnInvoiceDate.Value = txtInvoiceDate.Text;
                 string InvoiceDate = (DateTime.ParseExact(HdnInvoiceDate.Value, "dd-MM-yyyy", System.Globalization.CultureInfo.InvariantCulture)).ToString("yyyy-MM-dd");

                 HdnPODate.Value = txtPODate.Text;
                 string PODate = (DateTime.ParseExact(HdnPODate.Value, "dd-MM-yyyy", System.Globalization.CultureInfo.InvariantCulture)).ToString("yyyy-MM-dd");

                 string xDate = DateTime.Now.ToString("dd-MM-yyyy");
                 string CurrDate = (DateTime.ParseExact(xDate, "dd-MM-yyyy", System.Globalization.CultureInfo.InvariantCulture)).ToString("yyyy-MM-dd");

                 int ActiveStatus;
                              

                 db.slDataAdd("Type", "Insert");
                 db.slDataAdd("ClientName", txtClientName.Text);
                 db.slDataAdd("LicenseCount", txtLicenseCount.Text);
                 db.slDataAdd("LicenseTypeId", ddlLicenseType.SelectedValue);
                 db.slDataAdd("CostTypeId", ddlCostType.SelectedValue);
                 db.slDataAdd("LicenseKey", txtLicenseKey.Text);
                 db.slDataAdd("AppliedAt", txtAppliedAt.Text);
                 db.slDataAdd("BillTo", txtAppliedAt.Text);
                 db.slDataAdd("ProcurementDate", procdate);
                 db.slDataAdd("HandOverDate", HandoverDate);
                 db.slDataAdd("ExpiryDate", ExpiryDate);
                 db.slDataAdd("RenewDate", RenewDate);
                 db.slDataAdd("Rate", txtRate.Text);
                 db.slDataAdd("Value", txtValue.Text);
                 db.slDataAdd("InvoiceNo", txtInvoiceNo.Text);
                 db.slDataAdd("InvoiceDate", InvoiceDate);
                 db.slDataAdd("PONo", txtPO.Text);
                 db.slDataAdd("PODate", PODate);
                 db.slDataAdd("SPOCEmailId", txtSPOCEmail.Text);
                 db.slDataAdd("OwnerEmailId", txtOwnerEmailId.Text);
                 db.slDataAdd("Attachment", HdLicenseFile.Value);                
                 db.slDataAdd("OtherAttachment", "");
                 db.slDataAdd("Remarks", "");
                 if (DateTime.Parse(ExpiryDate) > DateTime.Parse(CurrDate))
                 {
                     ActiveStatus = 1;
                     db.slDataAdd("AvailableCount", txtLicenseCount.Text);
                     db.slDataAdd("InUseCount", "");
                     db.slDataAdd("ExpiredCount", "");
                     db.slDataAdd("Status", "1");
                     db.slDataAdd("IsActive", ActiveStatus);
                 }
                 else
                 {
                     ActiveStatus = 0;
                    int LicenseCount = Convert.ToInt32(txtLicenseCount.Text);
                    int ExpiredCount = LicenseCount;
                    int AvailableCount = LicenseCount - ExpiredCount;

                    db.slDataAdd("AvailableCount", AvailableCount);
                    db.slDataAdd("InUseCount", AvailableCount);
                    db.slDataAdd("ExpiredCount", ExpiredCount);
                    db.slDataAdd("Status", "3");
                    db.slDataAdd("IsActive", ActiveStatus);
                 }     
            
                 db.slDataAdd("CreatedBy", Session["AgentID"].ToString());
                 db.slDataAdd("CreatedDate", DateTime.Now.ToString("yyyy-MM-dd"));
                 db.slDataAdd("UpdatedBy", "");
                 db.slDataAdd("UpdatedDate", "");
                 db.slDataAdd("LastUpdated", "");
                 dt = db.ReturnTable("usp_RpaLicenseDetails", "", true);
                
                 if ((dt != null))
                 {
                     switch ((dt.Rows[0]["MESSAGE_TYPE"].ToString()))
                     {
                         case "S":
                             SuccessMessage(dt.Rows[0]["MESSAGE"].ToString());
                             break;
                         case "E":
                             AlertMessage(dt.Rows[0]["MESSAGE"].ToString());
                             break;
                     }
                     Reset();
                 }
             }
        }
        catch (Exception ex)
        {
            throw ex;
        } 
    }


    public void Reset()
    {
        txtAppliedAt.Text = "";
        txtBillToCompny.Text = "";
        txtClientName.Text = "";
        txtInvoiceNo.Text = "";
        txtLicenseCount.Text = "";
        txtLicenseKey.Text = "";
        txtPO.Text = "";
        txtSPOCEmail.Text = "";
        txtOwnerEmailId.Text = "";
        txtRate.Text = "";
        txtValue.Text = "";
        ddlCostType.SelectedValue = "0";
        ddlLicenseType.SelectedValue = "0";
        lblPOAttachment.Text = "";
        txtProcDate.Text = DateTime.Now.ToString("dd-MM-yyyy");
        txtExpiryDate.Text = DateTime.Now.AddYears(1).ToString("dd-MM-yyyy");
        txtHandoverDate.Text = DateTime.Now.ToString("dd-MM-yyyy");
        //txtRenewDate.Text = DateTime.Now.AddYears(1).ToString("dd-MM-yyyy");
        txtInvoiceDate.Text = DateTime.Now.ToString("dd-MM-yyyy");
        txtPODate.Text = DateTime.Now.ToString("dd-MM-yyyy");

    }

    private void AlertMessage(string msg)
    {
        lblHumanMessage.Text = msg;
        HumanMessage.CssClass = "HMFail";
        HumanMessage.Visible = true;
        lblHumanMessage.Visible = true;
        HumanMessage.Style["visibility"] = "visible";        

    }

    private void SuccessMessage(string msg)
    {
        lblHumanMessage.Text = msg;
        HumanMessage.CssClass = "HMSuccess";
        HumanMessage.Visible = true;
        lblHumanMessage.Visible = true;
        HumanMessage.Style["visibility"] = "visible";

    }

    protected void btnSave_Click(object sender, EventArgs e)
    {
        try
        {
            LicenseEntry();      
            ScriptManager.RegisterStartupScript(Page, Page.GetType(), "Movedialog", "SaveLabel();", true);
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    protected void btnReset_Click(object sender, EventArgs e)
    {
        try
        {
            Reset();
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    protected void BtnUpload_Click(object sender, EventArgs e)
    {

        try
        {
            string filename = "";
            string filePath = "";

             filename = Path.GetFileName(POfileUpload.PostedFile.FileName.ToString());            
             filePath = Server.MapPath("~\\myupload\\");
            

            if (POfileUpload.HasFile)
            {
                if (!Directory.Exists(filePath))
                {
                    Directory.CreateDirectory(filePath);
                }
                filePath = filePath + filename;
                string strPath = System.IO.Path.GetExtension(filePath);

                if (strPath == ".docx" || strPath == ".pdf" || strPath == ".zip")
                {

                    POfileUpload.SaveAs(filePath + Path.GetFileName(filename));
                    HdLicenseFile.Value = filePath.ToString();
                    lblPOAttachment.Text = filename;
                }
                else
                {
                    ScriptManager.RegisterStartupScript(this, this.GetType(), "script", "alert('Select only .docx,.pdf,.zip format!!');", true);
                }
            }
            else
            {
                ScriptManager.RegisterStartupScript(this, this.GetType(), "script", "alert('There is no File!!');", true);
            }



        }

        catch (Exception ex)
        {
            throw ex;
        }




    }
    protected void HumanMsgBtn_Click(object sender, EventArgs e)
    {
        HumanMessage.Visible = false;
        lblHumanMessage.Text = "";
        HumanMessage.Style["visibility"] = "";
    }

    protected void txtProcDate_TextChanged(object sender, EventArgs e)
    {
        try
        {
            if (txtProcDate.Text != "")
            {
                DateTime procdate = DateTime.ParseExact(txtProcDate.Text, "dd-MM-yyyy", System.Globalization.CultureInfo.InvariantCulture);

                txtExpiryDate.Text = procdate.AddYears(1).ToString("dd-MM-yyyy");

            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
                   
    }



    protected void txtRate_TextChanged(object sender, EventArgs e)
    {
        try
        {
            if (txtLicenseCount.Text != "" && txtRate.Text != "")
            {

                decimal rate = Convert.ToDecimal(txtRate.Text);
                int licensecount = Convert.ToInt32(txtLicenseCount.Text);
                txtRate.Text = rate.ToString();
                rate = rate * licensecount;
                txtValue.Text = rate.ToString();
            }
            else
            {
                ScriptManager.RegisterStartupScript(this, this.GetType(), "script", "alert('Please Enter License Count To Calculate Value Of Rate!!');", true);
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
     

    }

    protected void txtLicenseCount_TextChanged(object sender, EventArgs e)
    {
        try
        {
            if (txtLicenseCount.Text != "" && txtRate.Text != "")
            {
                int licensecount = Convert.ToInt32(txtLicenseCount.Text);
                decimal rate = Convert.ToDecimal(txtRate.Text);
                txtRate.Text = rate.ToString();
                rate = rate * licensecount;
                txtValue.Text = rate.ToString();
            }
            else
            {
                ScriptManager.RegisterStartupScript(this, this.GetType(), "script", "alert('Please Enter License Count To Calculate Value Of Rate!!');", true);
            }
        }
        catch (Exception ex)
        {
            throw ex;       
        }
    }
}