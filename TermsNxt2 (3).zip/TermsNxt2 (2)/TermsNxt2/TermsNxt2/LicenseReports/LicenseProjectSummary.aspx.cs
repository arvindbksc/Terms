﻿using Microsoft.VisualBasic;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using com.nss.DBAccess;
using System.Data.SqlClient;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Net.Mail;
using System.IO;
using System.Web.Script.Serialization;
using System.Web;

public partial class LicenseReports_LicenseProjectSummary : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["UserID"] == null)
        {
            if (User.Identity.Name.ToString().Contains("NSS\\"))
            {
                Session["Lanid"] = User.Identity.Name.ToString().Replace("NSS\\", "");
            }
            else
            {
                Session["Lanid"] = User.Identity.Name;
            }
            DBAccess db = new DBAccess();
            db.slDataAdd("UserId", Session["Lanid"]);
            System.Data.DataRow dr = db.ReturnRow("usp_CheckTermsUser", true);
            db = null;
            if (dr == null)
            {
                Response.Write("There is some problem in authenticating your credentials. Please make sure you are authorized to use this website.");
                return;
            }
            Session["CampaignID"] = dr["campaignid"];
            Session["AgentID"] = dr["AgentID"];
            Session["UserID"] = dr["AgentID"];
            Session["username"] = dr["AgentName"];
            Session["IsVerifier"] = dr["btVerifier"];
            Response.Write(Session["username"]);
            Response.Write(Session["Lanid"]);
        }

        HumanMessage.Style["visibility"] = "hidden";
        HumanMessage.Visible = false;
        if (!IsPostBack)
        {
            lblReportName.CurrentPage = "Project Summary";
        }
    }

    [System.Web.Script.Services.ScriptMethod(UseHttpGet = true)]
    [System.Web.Services.WebMethod(EnableSession = true)]
    public static string ProjectSummary()
    {
        DataTable dt = new DataTable();
        DBAccess db = new DBAccess("CRM");
        DataSet ds = new DataSet();
        db.slDataAdd("Filter", "ProjectSummary");
        dt = db.ReturnTable("Usp_Rpa_Reporting", "", true);
        //HttpContext.Current.Session["ClientName"] = ClientName;
        JavaScriptSerializer serializer = new JavaScriptSerializer();
        List<Dictionary<string, object>> rows = new List<Dictionary<string, object>>();
        Dictionary<string, object> row;

        foreach (DataRow dr in dt.Rows)
        {
            row = new Dictionary<string, object>();
            foreach (DataColumn col in dt.Columns)
            {
                row.Add(col.ColumnName, dr[col]);
            }
            rows.Add(row);
        }

        string str = serializer.Serialize(rows);
        return str;
    }

    [System.Web.Script.Services.ScriptMethod(UseHttpGet = true)]
    [System.Web.Services.WebMethod(EnableSession = true)]
    public static string ViewDetails(string Status,string ClientName)
    {
        DataTable dt = new DataTable();
        DBAccess db = new DBAccess("CRM");
        db.slDataAdd("", "");
        dt = db.ReturnTable("", "", true);

        JavaScriptSerializer serializer = new JavaScriptSerializer();
        List<Dictionary<string, object>> rows = new List<Dictionary<string, object>>();
        Dictionary<string, object> row;

        foreach (DataRow dr in dt.Rows)
        {
            row = new Dictionary<string, object>();
            foreach (DataColumn col in dt.Columns)
            {
                row.Add(col.ColumnName, dr[col]);
            }
            rows.Add(row);
        }

        string str = serializer.Serialize(rows);
        return str;
    }
}