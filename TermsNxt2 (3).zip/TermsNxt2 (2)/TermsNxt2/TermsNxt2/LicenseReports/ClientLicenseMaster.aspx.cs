﻿
using Microsoft.VisualBasic;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using com.nss.DBAccess;
using System.Data.SqlClient;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Web.Services;
public partial class LicenseExpiryReports_ClientLicenseMaster : System.Web.UI.Page
{

    #region "--- Properties ---"
    public System.DateTime CurrentDate { get; set; }
    public string UserID { get; set; }
    public string AgentID { get; set; }
    public string UserName { get; set; }


    #endregion

    string Clientnameglobal;


    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["UserID"] == null)
        {
            if (User.Identity.Name.ToString().Contains("NSS\\"))
            {
                Session["Lanid"] = User.Identity.Name.ToString().Replace("NSS\\", "");
            }
            else
            {
                Session["Lanid"] = User.Identity.Name;
            }
            //if (string.IsNullOrEmpty(Session["Lanid"].ToString()))
            //{
            //    Session["Lanid"] = Convert.ToString()(Mid(Request.ServerVariables["LOGON_USER"], Strings.InStr(Request.ServerVariables["LOGON_USER"], "\\") + 1, Strings.Len(Request.ServerVariables("LOGON_USER"))));
            //}

            com.nss.DBAccess.DBAccess db = new com.nss.DBAccess.DBAccess();
            //Dim dr As System.Data.DataRow = db.ReturnRow("select Agentid,AgentName,campaignid,btVerifier from tbl_agentmaster where lanid='" & Session["Lanid"] & "' and active=1")
            db.slDataAdd("UserId", Session["Lanid"]);
            System.Data.DataRow dr = db.ReturnRow("usp_CheckTermsUser", true);
            db = null;
            if (dr == null)
            {
                Response.Write("There is some problem in authenticating your credentials. Please make sure you are authorized to use this website.");
                return;
            }
            Session["CampaignID"] = dr["campaignid"];
            Session["AgentID"] = dr["AgentID"];
            Session["UserID"] = dr["AgentID"];
            Session["username"] = dr["AgentName"];
            Session["IsVerifier"] = dr["btVerifier"];
            Response.Write(Session["username"]);
            Response.Write(Session["Lanid"]);
        }

        {

            HumanMessage.Style["visibility"] = "hidden";
            HumanMessage.Visible = false;
            if (!this.IsPostBack)
            {
                this.GetGridView();
                lblReportName.CurrentPage = "Client License Master";


            }

        }
    }


  

    #region "--- Functions ---"
 

    protected void btnSave_Click(object sender, EventArgs e)
    {


        string type = "";
        //string ClientName = TxtClientName.Text;
        //string Remarks = TxtRemark.Text;
        //string Active = ddlActive.SelectedItem.Value;
        try
        {
            if ((btnSave.Text == "save"))
            {
                type = "INSERT";
                lblHeader.Text = "ADD NEW CLIENT LICENSE";
                SaveClient(type, "0");
            }
            else if ((btnSave.Text == "Update"))
            {
                type = "UPDATE";
                //lblHeader.Text = "UPDATE CLIENT LICENSE";
                //string str = hdnPanelRoleprocessMapid.Value.ToString();
                SaveClient(type, hdnPanelRoleprocessMapid.Value.ToString());
            }


            GetGridView();
        }
        catch (Exception Ex)
        { }

    }

    public void SaveClient(string Type, string Id)
    {
        try
        {

            DBAccess db = new DBAccess("CRM");
            DataTable dt = default(DataTable); 
            db.slDataAdd("Type", Type);
            db.slDataAdd("ID", Id);
            db.slDataAdd("ClientName", TxtClientName.Text);
            //db.slDataAdd("ClientCode","");
            db.slDataAdd("IsActive", ddlActive.SelectedValue);            
            //db.slDataAdd("CreatedDatetime", DateTime.Now.ToString("yyyy-MM-dd"));
            //db.slDataAdd("UpdatedBy", "");
            //db.slDataAdd("UpdatedDatetime", "");
            db.slDataAdd("Remark1", TxtRemark.Text);
            db.slDataAdd("Remark2", TxtRemark1.Text);
            db.slDataAdd("ClientCode", txtClientCode.Text);
            if (Type == "UPDATE")
            {
                db.slDataAdd("UpdatedBy", Session["UserID"]);
            }
            else
            {
                db.slDataAdd("CreatedBy", Session["UserID"]);
            }
            //sdb.slDataAdd("Remarksint ", 0);


            dt = db.ReturnTable("CMF_GET_ClientLicenseMaster", "", true);
            db = null;
            if ((dt != null))
            {
                switch ((dt.Rows[0]["MESSAGE_TYPE"].ToString()))
                {
                    case "S":
                        SuccessMessage(dt.Rows[0]["MESSAGE"].ToString());
                        break;

                    case "E":
                        AlertMessage(dt.Rows[0]["MESSAGE"].ToString());
                        break;
                }
            }
        }
        catch (Exception ex)
        {
            SuccessMessage(ex.ToString());
        }
    }

    private void GetData(string ID)
    {
        DBAccess db = new DBAccess("CRM");
        DataTable dt = default(DataTable);
        try
        {           
            db.slDataAdd("ID", ID);
            db.slDataAdd("Type", "SELECTDATA");       
            dt = db.ReturnTable("CMF_GET_ClientLicenseMaster", "", true);
            TxtClientName.Text = dt.Rows[0]["ClientName"].ToString();
            TxtRemark.Text = dt.Rows[0]["Remark1"].ToString();
            TxtRemark1.Text = dt.Rows[0]["Remark2"].ToString();
            txtClientCode.Text = dt.Rows[0]["ClientCode"].ToString();
            //TxtEmailId1.Text = dt.Rows[0]["EmailId"].ToString();
            ddlActive.SelectedValue = dt.Rows[0]["IsActive"].ToString();

        }
        catch (Exception ex)
        {
            //AlertMessage(ex.ToString);
        }
    }

    private void GetGridView()
    {
        DBAccess db = new DBAccess("CRM");
        DataTable dt = default(DataTable);
        try
        {
            //db.slDataAdd("ClientName", "");
            //db.slDataAdd("ID", "");
            db.slDataAdd("Type", "SELECT");
            //db.slDataAdd("IsActive", 1);
            //db.slDataAdd("CreatedBy", Session["UserID"]);
            //db.slDataAdd("CreatedDatetime", DateTime.Now);
            //db.slDataAdd("UpdatedBy", "");
            //db.slDataAdd("UpdatedDatetime", "");
            //db.slDataAdd("Remarks", "");
            //db.slDataAdd("Remarks1", "");
            //db.slDataAdd("Remarksint ", 0);

            dt = db.ReturnTable("CMF_GET_ClientLicenseMaster", "", true);
            db = null;
            gdData.DataSource = dt;
            gdData.DataBind();
            if (dt.Rows.Count > 0)
            {
                btnAddFirst.Visible = false;
            }
            else
            {
                btnAddFirst.Visible = true;
            }

        }
        catch (Exception ex)
        {
            //AlertMessage(ex.ToString);
        }
    }

    public void OpenDialog()
    {

        try
        {
            string str = null;
            str = "$('#DialogBackground').height($(document).height()-5);$('#DialogBackground').width($(window).width());$('#DialogBackground').css('visibility','visible');$('#PanelIDPForm').css('visibility','visible');" + " $('#PanelIDPForm').css('left',($(window).width() - $('#PanelIDPForm').width())/2); ";
            ScriptManager.RegisterClientScriptBlock(Page, typeof(System.Web.UI.Page), "redirect", str, true);
        }
        catch (Exception ex)
        { }

    }

    protected void btnAddFirst_Click(object sender, EventArgs e)
    {
        btnSave.Text = "save";
        OpenDialog();

    }

    public void DeleteLicense(string Id)
    {
        try
        {
            DBAccess db = new DBAccess("CRM");
            DataTable dt = default(DataTable);
            db.slDataAdd("ID", Id);
            db.slDataAdd("Type", "DELETE");
            dt = db.ReturnTable("CMF_GET_ClientLicenseMaster", "", true);
            db = null;
            if ((dt != null))
            {
                switch ((dt.Rows[0]["MESSAGE_TYPE"].ToString()))
                {
                    case "S":
                        SuccessMessage(dt.Rows[0]["MESSAGE"].ToString());
                        GetGridView();
                        break;
                    case "E":
                        AlertMessage(dt.Rows[0]["MESSAGE"].ToString());
                        break;
                }
            }

        }
        catch (Exception ex)
        {
        }
    }

    protected void AddNew_Click(object sender, EventArgs e)
    {
        try
        {

            //string txtClientName = "";
            string txtRemarks = "";
            GridViewRow gvRow = (GridViewRow)((System.Web.UI.Control)sender).Parent.Parent;
            int index = gvRow.RowIndex;
            TxtClientName.Text = (gvRow.FindControl("TxtCNameFooter2") as System.Web.UI.WebControls.TextBox).Text;
            TxtRemark.Text = (gvRow.FindControl("TxtRemarks1") as System.Web.UI.WebControls.TextBox).Text;
            txtClientCode.Text = (gvRow.FindControl("TxtClientCode") as System.Web.UI.WebControls.TextBox).Text;
            
            //TxtEmailId1.Text = (gvRow.FindControl("TxtEmailId") as System.Web.UI.WebControls.TextBox).Text;
            SaveClient("INSERT", "0");
            GetGridView();
        }
        catch (Exception ex)
        { }



    }

    protected void OnPageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        gdData.PageIndex = e.NewPageIndex;
        gdData.DataBind();
        GetGridView();
    }


    #endregion


    #region "--- Utility ---"
    private void AlertMessage(string msg)
    {
        lblHumanMessage.Text = msg;
        HumanMessage.CssClass = "HMFail";
        HumanMessage.Visible = true;
        lblHumanMessage.Visible = true;
        HumanMessage.Style["visibility"] = "visible";
        // HumanMessage.Style.Item("visibility") = "visible";

    }

    private void SuccessMessage(string msg)
    {
        lblHumanMessage.Text = msg;
        HumanMessage.CssClass = "HMSuccess";
        HumanMessage.Visible = true;
        lblHumanMessage.Visible = true;
        HumanMessage.Style["visibility"] = "visible";
        //HumanMessage.Item["visibility"].tostring() = "visible";

    }

    protected void HumanMsgbtn_Click(object sender, EventArgs e)
    {
        // HumanMessage.Style["visibility"].ToString() = "";
        HumanMessage.Visible = false;
        lblHumanMessage.Text = "";
        HumanMessage.Style["visibility"] = "";

    }

    #endregion




    #region "---Grid Events ---"


    protected void gdData_RowEditing(object sender, GridViewEditEventArgs e)
    {
        btnSave.Text = "Update";
        if (btnSave.Text == "Update")
        {
            lblHeader.Text = "UPDATE CLIENT LICENSE";
        }
        int index = Convert.ToInt32(e.NewEditIndex);
        hdnPanelRoleprocessMapid.Value = ((System.Web.UI.WebControls.HiddenField)gdData.Rows[index].FindControl("hdnID")).Value;
        string ID = hdnPanelRoleprocessMapid.Value;
        GetData(ID);
       
        OpenDialog();

    }

    protected void gdData_RowCommand(object sender, System.Web.UI.WebControls.GridViewCommandEventArgs e)
    {

        string ID;
        try
        {
            if (e.CommandName.ToLower() == "edit")
            {
                btnSave.Text = "Update";
                lblHeader.Text = "UPDATE CLIENT LICENSE";
                int index = Convert.ToInt32(e.CommandArgument);
                ID = ((HiddenField)gdData.Rows[index].FindControl("hdnID")).Value;
                TxtClientName.Text = ((Label)gdData.Rows[index].FindControl("lblCName")).Text;
                TxtRemark.Text = ((Label)gdData.Rows[index].FindControl("lblRemarks1")).Text;
                txtClientCode.Text = ((Label)gdData.Rows[index].FindControl("lblClntCode")).Text;
               // TxtEmailId1.Text = ((Label)gdData.Rows[index].FindControl("lblEmailId")).Text;

                OpenDialog();
            }

            if (e.CommandName.ToLower() == "addnew")
            {
                btnSave.Text = "Save";
                OpenDialog();
            }

            if (e.CommandName.ToLower() == "Delete")
            {



            }
        }
        catch (Exception ex)
        {
            AlertMessage(ex.Message);
        }

    }

    protected void gdData_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        DBAccess db = new DBAccess("CRM");

        string hdnID = ((HiddenField)gdData.Rows[e.RowIndex].FindControl("hdnID")).Value.ToString();
        DeleteLicense(hdnID);

    }
    #endregion
}
