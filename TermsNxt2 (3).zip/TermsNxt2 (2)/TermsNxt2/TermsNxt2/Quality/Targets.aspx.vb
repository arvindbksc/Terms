﻿Imports com.nss.DBAccess
Imports System.Data

Partial Class Quality_Targets
    Inherits System.Web.UI.Page
#Region "---------Properties"
    Property dtBindTargets() As DataTable
        Get
            Return ViewState("_dtBindTargets")
        End Get
        Set(ByVal value As DataTable)
            ViewState("_dtBindTargets") = value
        End Set
    End Property

    Property dtTarget() As DataTable
        Get
            Return ViewState("_dtTarget")
        End Get
        Set(ByVal value As DataTable)
            ViewState("_dtTarget") = value
        End Set
    End Property

    Property AgentID() As String
        Get
            Return ViewState("AgentID")
        End Get
        Set(ByVal value As String)
            ViewState("AgentID") = value
        End Set
    End Property
#End Region

#Region "Load/Initialisation"
    Private Sub FillMonthYear()
        For ictr = 1 To 12
            cboMonth.Items.Add(New ListItem(MonthName(ictr), ictr))
        Next

        cboMonth.SelectedIndex = cboMonth.Items.IndexOf(cboMonth.Items.FindByValue(DateTime.Now.Month))
        For ictr = DateTime.Now.Year To 2017 Step -1
            cboYear.Items.Add(New ListItem(ictr, ictr))
        Next
        cboYear.SelectedIndex = cboYear.Items.IndexOf(cboYear.Items.FindByValue(DateTime.Now.Year))
    End Sub
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Try
            LblErrormsg.Text = ""
            HideSuccessMessage("")
            If Not IsPostBack Then
                AgentID = Session("AgentID")
                BindProcess()
                FillMonthYear()
                InitialiseGrid()
            End If
        Catch ex As Exception
            'lblErrorMsg.Text = ex.Message
            AlertMessage(ex.Message)
        End Try
    End Sub

    Private Sub BindProcess()
        Try
            Dim db As New DBAccess
            Dim dt As New DataTable
            db.slDataAdd("Agentid", AgentID)
            dt = db.ReturnTable("usp_MyCampaigns", , True)
            db = Nothing

            cboCampaigns.DataTextField = "Name"
            cboCampaigns.DataValueField = "CampaignId"
            cboCampaigns.DataSource = dt
            cboCampaigns.DataBind()
        Catch ex As Exception
            'lblErrorMsg.Text = ex.Message
            AlertMessage(ex.Message)
        End Try
    End Sub

    Private Sub InitialiseGrid()
        Try
            lblreportname.CurrentPage = "KPI's Target for " & cboCampaigns.SelectedItem.Text
            HideSuccessMessage("")
            'Dim db As New DBAccess("Amail1dev1")
            Dim db As New DBAccess
            Dim query As String = ""
            query &= " SELECT ISNULL(CONVERT(VARCHAR(50),M.KPI),'') AS 'KPI', ISNULL(CONVERT(VARCHAR(10),N.Target),'') AS 'Target'  FROM tbl_Config_QualityKPI M LEFT OUTER JOIN  "
            query &= " (SELECT * FROM 	tbl_Data_QualityTargets WHERE CampaignID = '" & cboCampaigns.SelectedValue & "' And [Month] = '" & cboMonth.SelectedValue & "' And [Year] = '" & cboYear.SelectedValue & "'"
            query &= " )N ON M.KPI=N.KPI  "

            dtTarget = db.ReturnTable(query)
            db = Nothing

            If Not dtTarget Is Nothing Then
                If dtTarget.Rows.Count > 0 Then
                    gvTarget.DataSource = dtTarget
                    gvTarget.DataBind()

                    ' gvTarget.EditIndex = -1

                    For i As Integer = 0 To dtTarget.Rows.Count - 1
                        If dtTarget.Rows(i).Item("Target") = "" Then
                            CType(gvTarget.Rows(i).FindControl("lnkedit"), LinkButton).Text = "Insert"
                            'If Not CType(gvTarget.Rows(i).FindControl("txtTarget"), TextBox) Is Nothing Then
                            '    CType(gvTarget.Rows(i).FindControl("txtTarget"), TextBox).Visible = False
                            'End If
                        End If
                    Next
                Else
                    gvTarget.DataSource = Nothing
                    gvTarget.DataBind()
                End If
            End If
            
           
        Catch ex As Exception
            'LblErrormsg.Text = ex.Message
            AlertMessage(ex.Message)
        End Try
    End Sub
#End Region

#Region "Commands"

    Protected Sub gvTarget_RowCancelingEdit(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewCancelEditEventArgs) Handles gvTarget.RowCancelingEdit
        Try
            HideSuccessMessage("")
            gvTarget.EditIndex = -1
            InitialiseGrid()
            Dim update, Cancel, edit As LinkButton
            update = gvTarget.Rows(e.RowIndex).FindControl("lnkupdate")
            Cancel = gvTarget.Rows(e.RowIndex).FindControl("lnkcancel")
            edit = gvTarget.Rows(e.RowIndex).FindControl("lnkedit")
            update.Visible = False
            Cancel.Visible = False
            edit.Visible = True
        Catch ex As Exception
            'LblErrormsg.Text = ex.Message
            AlertMessage(ex.Message)
        End Try
    End Sub

    'Protected Sub gvTarget_RowDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles gvTarget.RowDataBound

    '    If e.Row.RowType = DataControlRowType.DataRow Then
    '        If Not (e.Row.FindControl("lblTarget")) Is Nothing Then
    '            If CType(e.Row.FindControl("lblTarget"), Label).Text = "" Then
    '                CType(e.Row.FindControl("lnkedit"), LinkButton).Text = "Insert"
    '            Else
    '                CType(e.Row.FindControl("lnkedit"), LinkButton).Text = "Edit"
    '            End If
    '        End If

    '    End If
    'End Sub

    Protected Sub gvTarget_RowEditing(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewEditEventArgs) Handles gvTarget.RowEditing
        Try
            If Validation() = True Then
                HideSuccessMessage("")
                gvTarget.EditIndex = e.NewEditIndex
                InitialiseGrid()

                Dim update, Cancel, Edit As LinkButton
                update = gvTarget.Rows(e.NewEditIndex).FindControl("lnkupdate")
                Cancel = gvTarget.Rows(e.NewEditIndex).FindControl("lnkcancel")
                Edit = gvTarget.Rows(e.NewEditIndex).FindControl("lnkedit")

                update.Visible = True
                Cancel.Visible = True
                Edit.Visible = False

            End If

        Catch ex As Exception
            'lblErrorMsg.Text = ex.Message
            AlertMessage(ex.Message)
        End Try
    End Sub

    Protected Sub gvTarget_RowUpdating(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewUpdateEventArgs) Handles gvTarget.RowUpdating
        Try
            If Validation() = True Then

                Dim update, Cancel, Edit As LinkButton
                'InitialiseGrid()
                update = gvTarget.Rows(e.RowIndex).FindControl("lnkupdate")
                Cancel = gvTarget.Rows(e.RowIndex).FindControl("lnkcancel")
                Edit = gvTarget.Rows(e.RowIndex).FindControl("lnkedit")
                Dim txt1 As TextBox
                Dim lbl_KPI As Label

                txt1 = gvTarget.Rows(e.RowIndex).FindControl("txtTarget")
                If ValidateControls(txt1.Text) Then

                    lbl_KPI = gvTarget.Rows(e.RowIndex).FindControl("lblKPI")
                    'Dim db As New DBAccess("Amail1dev1")
                    Dim db As New DBAccess

                    db.slDataAdd("CampaignID", cboCampaigns.SelectedValue)
                    db.slDataAdd("Month", CboMonth.SelectedValue)
                    db.slDataAdd("Year", CboYear.SelectedValue)
                    db.slDataAdd("KPI", lbl_KPI.Text)
                    db.slDataAdd("Target", txt1.Text)
                    db.Executeproc("usp_UpdateQualityTargets")
                    db = Nothing


                    gvTarget.EditIndex = -1
                    InitialiseGrid()

                    update.Visible = False
                    Cancel.Visible = False
                    Edit.Visible = True
                    SuccessMessage(lbl_KPI.Text)
                End If
            End If
        Catch ex As Exception
            'lblErrorMsg.Text = ex.Message
            AlertMessage(ex.Message)
        End Try
    End Sub

    Protected Sub cboCampaigns_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboCampaigns.SelectedIndexChanged
        gvTarget.EditIndex = -1
        InitialiseGrid()
    End Sub

    Protected Sub CboMonth_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboMonth.SelectedIndexChanged
        gvTarget.EditIndex = -1
        InitialiseGrid()
    End Sub

    Protected Sub CboYear_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboYear.SelectedIndexChanged
        gvTarget.EditIndex = -1
        InitialiseGrid()
    End Sub
    'Protected Sub ImageButton1_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton1.Click
    '    InitialiseGrid()
    '    GridViewExportUtil.Export(lblreportname.CurrentPage & ".xls", Me.gvTarget)
    'End Sub
#End Region

#Region "Validation"
    Private Function Validation() As Boolean
        ' If CboProcess.SelectedItem.Value = "" Or CboMonth.SelectedValue = 0 Or CboYear.SelectedValue = 0 Or CboKPI.SelectedValue = "0" Then
        If cboCampaigns.SelectedItem.Value = "" Or CboMonth.SelectedValue = 0 Or CboYear.SelectedValue = 0 Then
            'lblErrorMsg.Text = "Please select all criterias."
            AlertMessage("Please select all criterias.")
            Return False
        Else
            Return True
        End If
    End Function

    Private Function ValidateControls(ByVal TargetText As String) As Boolean

        If cboCampaigns.SelectedItem.Value = "" Or CboMonth.SelectedValue = 0 Or CboYear.SelectedValue = 0 Then
            'lblErrorMsg.Text = "Please select all criterias."
            AlertMessage("Please select all criterias.")
            Return False
        ElseIf TargetText = "" Then
            'lblErrorMsg.Text = "Please enter only decimal values for the Target."
            AlertMessage("Please enter only decimal values for the Target.")
            Return False

        ElseIf Not TargetText = "" Then
            If Not IsNumeric(TargetText) Then
                'lblErrorMsg.Text = "Please enter only decimal values for the Target."
                AlertMessage("Please enter only decimal values for the Target.")
                Return False
            End If
        End If

        Return True

    End Function
#End Region

#Region "Utilities"
    Private Sub SuccessMessage(ByVal msg As String)
        lblHumanMessage.Text = msg & " saved successfully."
        HumanMessage.CssClass = "HMSuccess"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub
    Private Sub HideSuccessMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMSuccess"
        HumanMessage.Style.Item("visibility") = "Hidden"
    End Sub

    Private Sub AlertMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMFail"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub
    Private Sub ExportToexcel()
        Dim tw As New IO.StringWriter()
        Dim hw As New System.Web.UI.HtmlTextWriter(tw)
        'Dim frm As HtmlForm = New HtmlForm()
        Response.ContentType = "application/vnd.ms-excel"
        Response.AddHeader("content-disposition", "attachment;filename=" & lblreportname.CurrentPage & ".xls")
        Response.Charset = ""
        EnableViewState = False
        'Controls.Add(frm)
        gvTarget.RenderControl(hw)
        Response.Write(tw.ToString())
        Response.End()
    End Sub
#End Region

#Region "Unused Code"
    'Protected Sub gvTarget_RowCommand(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewCommandEventArgs) Handles gvTarget.RowCommand
    '    If e.CommandName = "Add" Then
    '        If CType(gvTarget.FooterRow.FindControl("txtTarget"), TextBox).Text.Trim = "" Then
    '            Return
    '        End If

    '        If Validation() = False Then
    '            Return
    '        End If

    '        If ValidateControls(CType(gvTarget.FooterRow.FindControl("txtTarget"), TextBox).Text) = False Then
    '            CType(gvTarget.FooterRow.FindControl("txtTarget"), TextBox).Text = ""
    '            Return
    '        End If

    '        'Dim dt As New DataTable
    '        If dtBindTargets Is Nothing Then
    '            'dtBindTargets.Columns.Add("Target", System.Type.GetType("System.String"))
    '        Else
    '            dtBindTargets.Clear()
    '        End If

    '        Dim dtrow As DataRow
    '        Dim row As GridViewRow

    '        For Each row In gvTarget.Rows
    '            If row.RowType = DataControlRowType.DataRow Then
    '                If CType(row.FindControl("lblTarget"), Label).Text <> "No Target Defined" Then
    '                    dtrow = dtBindTargets.NewRow
    '                    dtrow("Target") = CType(row.FindControl("lblTarget"), Label).Text
    '                    dtBindTargets.Rows.Add(dtrow)
    '                End If
    '            End If
    '        Next

    '        If dtBindTargets.Rows.Count = 0 Then
    '            dtrow = dtBindTargets.NewRow
    '            dtrow("Target") = CType(gvTarget.FooterRow.FindControl("txtTarget"), TextBox).Text
    '            dtBindTargets.Rows.Add(dtrow)
    '        Else
    '            CType(gvTarget.FooterRow.FindControl("txtTarget"), TextBox).Text = ""
    '            Return
    '        End If

    '        BindTargetGrid()

    '    ElseIf e.CommandName = "Delete" Then
    '        Dim currentRow As GridViewRow = CType(e.CommandSource, ImageButton).NamingContainer
    '        dtBindTargets.Rows.RemoveAt(currentRow.RowIndex)
    '        BindTargetGrid()
    '    End If
    'End Sub

    'Private Sub BindData_Grid()
    '    If dtTarget.Rows.Count > 0 Then
    '        gvTarget.DataSource = dtTarget
    '        gvTarget.DataBind()
    '    Else
    '        gvTarget.DataSource = Nothing
    '        gvTarget.DataBind()
    '    End If
    'End Sub

    Private Sub BindTargetGrid()
        Dim row As DataRow
        If dtBindTargets.Rows.Count = 0 Then
            row = dtBindTargets.NewRow
            row(0) = "No Target Defined"
            dtBindTargets.Rows.Add(row)
        End If

        If dtBindTargets.Rows.Count > 0 Then
            gvTarget.DataSource = dtBindTargets
            gvTarget.DataBind()
        Else
            gvTarget.DataSource = Nothing
            gvTarget.DataBind()
        End If
    End Sub

    Private Sub ClearData()
        cboCampaigns.SelectedIndex = 0
        'CboKPI.SelectedIndex = 0
        CboMonth.SelectedIndex = 0
        CboYear.SelectedIndex = 0
    End Sub
    Private Sub ClearGrid()
        If dtBindTargets.Rows.Count > 0 Then
            dtBindTargets.Clear()
        End If
        BindTargetGrid()
    End Sub

    '#Region "Save"
    '    'Protected Sub btnSave_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnSave.Click
    '    '    If Validation() = True Then
    '    '        SaveKPI()
    '    '    End If
    '    'End Sub

    '    Private Sub SaveKPI()
    '        Try
    '            If gvTarget.Rows.Count > 0 Then
    '                For Each row In gvTarget.Rows
    '                    If row.RowType = DataControlRowType.DataRow Then
    '                        If CType(row.FindControl("lblTarget"), Label).Text <> "No Target Defined" And CType(row.FindControl("lblTarget"), Label).Text <> "" Then

    '                            Dim TargetValue As String = CType(row.FindControl("lblTarget"), Label).Text
    '                            'If CboProcess.SelectedItem.Value <> "" And CboMonth.SelectedValue <> 0 And CboYear.SelectedValue <> 0 And CboKPI.SelectedValue <> "0" Then
    '                            If CboProcess.SelectedItem.Value <> "" And CboMonth.SelectedValue <> 0 And CboYear.SelectedValue <> 0 Then

    '                                Dim db As New DBAccess("Amail1dev1")
    '                                db.slDataAdd("CampaignID", CboProcess.SelectedValue)
    '                                db.slDataAdd("Month", CboMonth.SelectedValue)
    '                                db.slDataAdd("Year", CboYear.SelectedValue)
    '                                'db.slDataAdd("KPI", CboKPI.SelectedItem.Text)
    '                                db.slDataAdd("Target", TargetValue)
    '                                db.Executeproc("usp_UpdateQualityTargets")
    '                                db = Nothing

    '                                ClearGrid()
    '                                ClearData()
    '                                lblErrorMsg.Text = "KPI has been updated successfully."

    '                            Else
    '                                lblErrorMsg.Text = "All fields are Mandatory."
    '                            End If
    '                        Else
    '                            lblErrorMsg.Text = "Please add Target."
    '                            Exit Sub

    '                        End If
    '                    End If
    '                Next
    '            End If
    '        Catch ex As Exception
    '            lblErrorMsg.Text = ex.ToString
    '        End Try
    '    End Sub

    '#End Region\

    Private Sub GetData()
        Try
            ' If CboProcess.SelectedItem.Value <> "" And CboMonth.SelectedValue <> 0 And CboYear.SelectedValue <> 0 And CboKPI.SelectedValue <> "0" Then
            If cboCampaigns.SelectedItem.Value <> "" And CboMonth.SelectedValue <> 0 And CboYear.SelectedValue <> 0 Then
                'Dim db As New DBAccess("Amail1dev1")
                Dim db As New DBAccess
                'dtBindTargets = db.ReturnTable("SELECT convert(varchar(20),Target) AS Target FROM tbl_Data_QualityTargets WHERE CampaignID=" & CboProcess.SelectedValue & " and [Month]=" & CboMonth.SelectedValue & " and [Year]=" & CboYear.SelectedValue & " and KPI= '" & CboKPI.SelectedValue & "'")
                dtBindTargets = db.ReturnTable("SELECT convert(varchar(20),Target) AS Target FROM tbl_Data_QualityTargets WHERE CampaignID=" & cboCampaigns.SelectedValue & " and [Month]=" & CboMonth.SelectedValue & " and [Year]=" & CboYear.SelectedValue)
                db = Nothing

                BindTargetGrid()
            End If
        Catch ex As Exception
            lblErrorMsg.Text = ex.ToString
        End Try
    End Sub

#End Region

End Class
