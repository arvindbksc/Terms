﻿Imports com.nss.DBAccess
Imports System.Data
Imports System.Data.SqlClient
Partial Class Quality_QuestionwiseErrorCount
    Inherits System.Web.UI.Page
#Region "Properties"
    Property CampaignID() As Integer
        Get
            Return ViewState("CampaignID")
        End Get
        Set(ByVal value As Integer)
            ViewState("CampaignID") = value
        End Set
    End Property

    Property AgentID() As String
        Get
            Return ViewState("AgentID")
        End Get
        Set(ByVal value As String)
            ViewState("AgentID") = value
        End Set
    End Property
#End Region
    Private Sub Getdata()

        Try
            ' Dim db As New DBAccess("qualitynew")
            Dim db As New DBAccess
            db.slDataAdd("DateFrom", Request.QueryString.Item("datefrom"))
            db.slDataAdd("DateTo", Request.QueryString.Item("dateTo"))
            db.slDataAdd("Campaignid", Request.QueryString("campid"))
            db.slDataAdd("QEID", Request.QueryString("QEID"))
            db.slDataAdd("CallType", Request.QueryString("CallType"))
            db.slDataAdd("cmfid", Request.QueryString("cmfid"))
            db.slDataAdd("ErrorType", Request.QueryString("ErrorType"))
            db.slDataAdd("Agentid", Request.QueryString("agentid"))
            Dim dt As DataTable = db.ReturnTable("usp_QMQuestionWiseErrorCount_New", , True)
            db = Nothing

            'Dim db1 As New DBAccess("qualitynew")
            Dim db1 As New DBAccess
            db1.slDataAdd("DateFrom", Request.QueryString.Item("datefrom"))
            db1.slDataAdd("DateTo", Request.QueryString.Item("dateTo"))
            db1.slDataAdd("Campaignid", Request.QueryString("campid"))
            db1.slDataAdd("QEID", Request.QueryString("QEID"))
            db1.slDataAdd("cmfid", Request.QueryString("cmfid"))
            db1.slDataAdd("CallType", Request.QueryString("CallType"))
            db1.slDataAdd("ErrorType", Request.QueryString("ErrorType"))
            db1.slDataAdd("Agentid", Request.QueryString("agentid"))
            Dim totalerror As Integer = 0
            totalerror = db1.ReturnValue("usp_QMQuestionWiseTotalErrorCount_New", True) 'IIf(IsDBNull(db1.ReturnValue("usp_QMQuestionWiseTotalErrorCount", True)), 0, db.ReturnValue("usp_QMQuestionWiseTotalErrorCount", True))
            dt.Rows.Add("Total", totalerror, "")
            dtgMain.DataSource = dt
            dtgMain.DataBind()
            db = Nothing
            For Each row As GridViewRow In dtgMain.Rows
                If row.RowType = DataControlRowType.DataRow Then
                    If row.Cells(row.Cells.Count - 1).Text = "F" Then
                        row.Cells(0).ForeColor = Drawing.Color.Red
                        row.Cells(1).ForeColor = Drawing.Color.Red
                        row.Cells(2).ForeColor = Drawing.Color.Red
                        row.Cells(row.Cells.Count - 1).Text = ""
                    End If
                    If row.RowIndex < dtgMain.Rows.Count - 1 Then
                        row.Cells(0).Text = row.RowIndex + 1
                    End If

                    If row.Cells(2).Text <> 0 Then
                        If row.RowIndex < dtgMain.Rows.Count - 1 Then
                            Dim text, t As New Label
                            text.BorderStyle = BorderStyle.None
                            If row.Cells(2).ForeColor = Drawing.Color.Red Then
                                text.BackColor = Drawing.Color.Red
                            Else
                                text.BackColor = Drawing.Color.Gray
                            End If
                            text.Width = Math.Round(row.Cells(2).Text / totalerror, 2) * 100
                            row.Cells(3).Controls.Add(text)
                            t.BorderStyle = BorderStyle.None
                            t.Enabled = False
                            t.Text = Math.Round(row.Cells(2).Text / totalerror, 2) * 100 & "%"
                            row.Cells(3).Controls.Add(t)
                        End If
                    Else
                        row.Cells(row.Cells.Count - 1).Text = ""
                    End If
                End If
            Next
        Catch ex As Exception
            lblError.Text = ex.ToString.ToString
        End Try
    End Sub
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            If Session("AgentID") <> "" Then
                CampaignID = Session("CampaignID")
                AgentID = Session("AgentID")
                If Not Request.QueryString("campid") Is Nothing Then
                    Getdata()
                End If
            End If
        End If
        PanelReports.Controls.Add(Common.GetMenu(Request.Url, AgentID, Request.ApplicationPath))
    End Sub

    Protected Sub dtgMain_RowCreated(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles dtgMain.RowCreated
        If e.Row.RowType = DataControlRowType.Header Then
            e.Row.Cells(3).Text = "Graphical View"
        End If
    End Sub

    'Protected Sub ImageButton1_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton1.Click
    '    Getdata()
    '    GridViewExportUtil.Export(lblSheetID.Text & "-" & lblerror.Text & ".xls", Me.dtgMain)
    'End Sub
End Class
