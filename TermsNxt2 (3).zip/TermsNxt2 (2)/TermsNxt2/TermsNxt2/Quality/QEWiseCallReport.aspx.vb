﻿Imports com.nss.DBAccess
Imports System.Data
Partial Class Quality_QEWiseCallReport
    Inherits System.Web.UI.Page
    Shared dt As DataTable
#Region "Properties"

    Property ProcessID() As Integer
        Get
            Return ViewState("ProcessID")
        End Get
        Set(ByVal value As Integer)
            ViewState("ProcessID") = value
            Session("ProcessID") = value
        End Set
    End Property
    Property Campaigntype() As Integer
        Get
            Return ViewState("Campaigntype")
        End Get
        Set(ByVal value As Integer)
            ViewState("Campaigntype") = value
            'Session("ProcessID") = value
        End Set
    End Property
    Property ReportType() As Integer
        Get
            Return ViewState("ReportType")
        End Get
        Set(ByVal value As Integer)
            ViewState("ReportType") = value
        End Set
    End Property
    Property CampaignID() As Integer
        Get
            Return ViewState("CampaignID")
        End Get
        Set(ByVal value As Integer)
            ViewState("CampaignID") = value
        End Set
    End Property

    Property AgentID() As String
        Get
            Return ViewState("AgentID")
        End Get
        Set(ByVal value As String)
            ViewState("AgentID") = value
        End Set
    End Property
#End Region
#Region "Load Data"
    Private Sub LoadData()
        FillCommonFilters()
        getdataintable()
        PopulateCampaigns()
        GetQEName()
    End Sub
#End Region
#Region "Load Functions"
    Private Sub FillCommonFilters()
        Dim db As New DBAccess
        Dim dt As DataTable = db.ReturnTable("select * from tbl_Reports_DatePeriods")
        db = Nothing
        Dim dr As DataRow = dt.NewRow
        dr(0) = 10
        dr(1) = "Between"
        dt.Rows.Add(dr)
        CboPeriod.DataTextField = "Caption"
        CboPeriod.DataValueField = "Period"
        CboPeriod.DataSource = dt
        CboPeriod.DataBind()
    End Sub
    Private Sub PopulateCampaigns()
        Try
            LblError.Visible = False
            Dim value As String
            value = cboCampaigns.SelectedValue
            Dim dtcamp As DataTable = dt.DefaultView.ToTable(True, New String() {"CampaignID", "Campaign Name"})
            cboCampaigns.DataSource = dtcamp
            cboCampaigns.DataValueField = "CampaignID"
            cboCampaigns.DataTextField = "Campaign Name"
            cboCampaigns.DataBind()
            Dim l As New ListItem
            l.Text = "ALL"
            l.Value = "0"
            cboCampaigns.Items.Insert(0, l)
            dtcamp = Nothing
            If value <> "" Then
                cboCampaigns.Items.FindByValue(value).Selected = True
            End If

        Catch ex As Exception
            LblError.Visible = True
            LblError.Text = ex.Message.ToString
        End Try
    End Sub
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        HumanMessage.Style.Item("visibility") = "hidden"
        If Not IsPostBack Then
            If Session("AgentID") <> "" Then
                CampaignID = Session("CampaignID")
                AgentID = Session("AgentID")
                PanelReports.Controls.Add(Common.GetMenu(Request.Url, AgentID, Request.ApplicationPath))
                LoadData()
                UcDateTo.Visible = False
                ucDateFrom.Visible = False
                lblAnd.Visible = False
            End If
        End If
    End Sub
    
    Private Sub getdataintable()
        dt = New DataTable
        Dim db As New DBAccess
        Dim startday As Integer, endday As Integer
        If CboPeriod.SelectedValue = 10 Then
            startday = ucDateFrom.yyyymmdd
            endday = UcDateTo.yyyymmdd
        Else
            db = New DBAccess
            db.slDataAdd("Period", CboPeriod.SelectedValue)
            db.slDataAdd("Campaignid", CampaignID)
            Dim dr As DataRow = db.ReturnRow("usp_GetStart_EndDateForAPeriod", True)
            db = Nothing
            startday = dr(0)
            endday = dr(1)
        End If
        Dim daywise As Integer
        If chkDayWise.Checked Then
            daywise = 1
        Else
            daywise = 0
        End If
        ' db = New DBAccess("qualitynew")
        db = New DBAccess
        db.slDataAdd("DateFrom", startday)
        db.slDataAdd("DateTo", endday)
        db.slDataAdd("Campaignid", cboCampaigns.SelectedValue)
        db.slDataAdd("inQAId", DdlQEName.SelectedValue)
        db.slDataAdd("daywise", daywise)
        'db.slDataAdd("inQAId", IIf(DdlQEName.SelectedValue.Trim = "", "%", Trim(DdlQEName.SelectedValue)))
        dt = db.ReturnTable("usp_QMgetQCScoreQEwise_new", , True)
        If dt.Rows.Count > 0 Then
            dtgMain.DataSource = dt
            dtgMain.DataBind()
            db = Nothing
        End If
        lblReportName.Text = "QE Wise Evaluated Report Between " & IntegerToDateString(startday) & "  and " & IntegerToDateString(endday)


       
    End Sub
    Private Sub GetQEName()
        Try
            lblError.Visible = False
            Dim value As String
            value = DdlQEName.SelectedValue
            Dim dtfiltered As DataTable
            If cboCampaigns.SelectedValue = "0" Then
                dtfiltered = dt.DefaultView.ToTable(True, New String() {"QEID", "QE Name"})
            Else
                Dim d As DataRow() = dt.Select("CampaignID=" & cboCampaigns.SelectedValue)
                Dim data1 As DataTable = dt.Clone
                For Each dr1 As DataRow In d
                    data1.ImportRow(dr1)
                Next
                dtfiltered = data1.DefaultView.ToTable(True, New String() {"QEID", "QE Name"})
                data1 = Nothing
            End If
            DdlQEName.DataTextField = "QE Name"
            DdlQEName.DataValueField = "QEID"
            DdlQEName.DataSource = dtfiltered
            DdlQEName.DataBind()
            Dim item As New ListItem
            item.Text = "All"
            item.Value = "%"
            DdlQEName.Items.Insert(0, item)
            dtfiltered = Nothing
            If value <> "" Then
                DdlQEName.Items.FindByValue(value).Selected = True
            End If
        Catch ex As Exception
            AlertMessage(ex.ToString)
            'lblError.Visible = True
        End Try
    End Sub
#End Region
#Region "Event"
    Protected Sub cboCampaigns_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboCampaigns.SelectedIndexChanged
        getdataintable()
        PopulateCampaigns()
        GetQEName()
    End Sub
    Protected Sub DdlQEName_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles DdlQEName.SelectedIndexChanged
        getdataintable()
        PopulateCampaigns()
        GetQEName()
    End Sub
    Protected Sub btnRefresh_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnRefresh.Click
        getdataintable()
        PopulateCampaigns()
        GetQEName()
    End Sub
    Protected Sub chkDayWise_CheckedChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles chkDayWise.CheckedChanged
        getdataintable()
        PopulateCampaigns()
        GetQEName()
    End Sub
    Protected Sub CboPeriod_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles CboPeriod.SelectedIndexChanged
        If CboPeriod.SelectedValue = 10 Then
            ucDateFrom.Visible = True
            UcDateTo.Visible = True
            lblAnd.Visible = True
            getdataintable()
            PopulateCampaigns()
            GetQEName()
        Else
            ucDateFrom.Visible = False
            UcDateTo.Visible = False
            lblAnd.Visible = False
            getdataintable()
            PopulateCampaigns()
            GetQEName()
        End If
    End Sub
    Protected Sub ImageButton1_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton1.Click
        getdataintable()
        PopulateCampaigns()
        GetQEName()
        GridViewExportUtil.Export(lblReportName.Text & "-" & LblError.Text & ".xls", Me.dtgMain)
    End Sub
    Protected Sub imgfav_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles imgfav.Click
        Common.AddToFav(AgentID, "QEWise Call Evaluated Report")
        SuccessMessage("Report has been added to your favourite list")
        getdataintable()
        PopulateCampaigns()
        GetQEName()
    End Sub
#End Region
#Region "Grid ops"
    Dim callmonitored, nonfatelerrorcount, fatelerrorcount, nonfatelqcount, TotalParamWiseScore, CollectedParamWiseScore, clientcallmonitored, Clientnonfatalerror, Clientfatalerror, Clientnonfatalqcount, ClientTotalParamWiseScore, ClientCollectedParamWiseScore As Integer
    Protected Sub dtgMain_RowDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles dtgMain.RowDataBound
        If e.Row.RowType = DataControlRowType.DataRow Then
            If chkDayWise.Checked Then
                nonfatelqcount += e.Row.Cells(5).Text
                callmonitored += e.Row.Cells(6).Text
                nonfatelerrorcount += e.Row.Cells(7).Text
                fatelerrorcount += e.Row.Cells(8).Text
                TotalParamWiseScore = TotalParamWiseScore + e.Row.Cells(11).Text
                CollectedParamWiseScore = CollectedParamWiseScore + e.Row.Cells(12).Text
                clientcallmonitored += e.Row.Cells(14).Text
                Clientnonfatalerror += e.Row.Cells(15).Text
                Clientfatalerror += e.Row.Cells(16).Text
                Clientnonfatalqcount += e.Row.Cells(17).Text
                ClientTotalParamWiseScore += e.Row.Cells(20).Text
                ClientCollectedParamWiseScore += e.Row.Cells(21).Text
            Else
                nonfatelqcount += e.Row.Cells(4).Text
                callmonitored += e.Row.Cells(5).Text
                nonfatelerrorcount += e.Row.Cells(6).Text
                fatelerrorcount += e.Row.Cells(7).Text
                TotalParamWiseScore = TotalParamWiseScore + e.Row.Cells(10).Text
                CollectedParamWiseScore = CollectedParamWiseScore + e.Row.Cells(11).Text
                clientcallmonitored += e.Row.Cells(13).Text
                Clientnonfatalerror += e.Row.Cells(14).Text
                Clientfatalerror += e.Row.Cells(15).Text
                Clientnonfatalqcount += e.Row.Cells(16).Text
                ClientTotalParamWiseScore += e.Row.Cells(19).Text
                ClientCollectedParamWiseScore += e.Row.Cells(20).Text
            End If
        ElseIf e.Row.RowType = DataControlRowType.Footer Then
            If chkDayWise.Checked Then
                e.Row.Cells(0).Text = "Total:-"
                e.Row.Cells(5).Text = nonfatelqcount
                e.Row.Cells(6).Text = callmonitored
                e.Row.Cells(7).Text = nonfatelerrorcount
                e.Row.Cells(8).Text = fatelerrorcount
                e.Row.Cells(9).Text = 100 - Math.Round(((nonfatelerrorcount) * 100 / nonfatelqcount), 2)
                e.Row.Cells(10).Text = 100 - Math.Round(((fatelerrorcount * 100) / callmonitored), 2)
                e.Row.Cells(11).Text = TotalParamWiseScore
                e.Row.Cells(12).Text = CollectedParamWiseScore
                e.Row.Cells(13).Text = Math.Round(((CollectedParamWiseScore / TotalParamWiseScore) * 100), 2)
                e.Row.Cells(14).Text = clientcallmonitored
                e.Row.Cells(15).Text = Clientnonfatalerror
                e.Row.Cells(16).Text = Clientfatalerror
                e.Row.Cells(17).Text = Clientnonfatalqcount
                e.Row.Cells(18).Text = 100 - Math.Round(((Clientnonfatalerror) * 100 / Clientnonfatalqcount), 2)
                e.Row.Cells(19).Text = 100 - Math.Round(((Clientfatalerror * 100) / clientcallmonitored), 2)
                e.Row.Cells(20).Text = ClientTotalParamWiseScore
                e.Row.Cells(21).Text = ClientCollectedParamWiseScore
                e.Row.Cells(22).Text = Math.Round(((ClientCollectedParamWiseScore / ClientTotalParamWiseScore) * 100), 2)
            Else
                e.Row.Cells(0).Text = "Total:-"
                e.Row.Cells(4).Text = nonfatelqcount
                e.Row.Cells(5).Text = callmonitored
                e.Row.Cells(6).Text = nonfatelerrorcount
                e.Row.Cells(7).Text = fatelerrorcount
                e.Row.Cells(8).Text = 100 - Math.Round(((nonfatelerrorcount) * 100 / nonfatelqcount), 2)
                e.Row.Cells(9).Text = 100 - Math.Round(((fatelerrorcount * 100) / callmonitored), 2)
                e.Row.Cells(10).Text = TotalParamWiseScore
                e.Row.Cells(11).Text = CollectedParamWiseScore
                e.Row.Cells(12).Text = Math.Round(((CollectedParamWiseScore / TotalParamWiseScore) * 100), 2)
                e.Row.Cells(13).Text = clientcallmonitored
                e.Row.Cells(14).Text = Clientnonfatalerror
                e.Row.Cells(15).Text = Clientfatalerror
                e.Row.Cells(16).Text = Clientnonfatalqcount
                e.Row.Cells(17).Text = 100 - Math.Round(((Clientnonfatalerror) * 100 / Clientnonfatalqcount), 2)
                e.Row.Cells(18).Text = 100 - Math.Round(((Clientfatalerror * 100) / clientcallmonitored), 2)
                e.Row.Cells(19).Text = ClientTotalParamWiseScore
                e.Row.Cells(20).Text = ClientCollectedParamWiseScore
                e.Row.Cells(21).Text = Math.Round(((ClientCollectedParamWiseScore / ClientTotalParamWiseScore) * 100), 2)
            End If
        End If
        If chkDayWise.Checked Then
            e.Row.Cells(8).ForeColor = Drawing.Color.Red
            e.Row.Cells(10).ForeColor = Drawing.Color.Red
            e.Row.Cells(2).Visible = False
            e.Row.Cells(4).Visible = False
            e.Row.Cells(5).Visible = False
            e.Row.Cells(11).Visible = False
            e.Row.Cells(12).Visible = False
            e.Row.Cells(17).Visible = False
            e.Row.Cells(18).Visible = False
            e.Row.Cells(20).Visible = False
            e.Row.Cells(21).Visible = False
        Else
            e.Row.Cells(7).ForeColor = Drawing.Color.Red
            e.Row.Cells(9).ForeColor = Drawing.Color.Red
            e.Row.Cells(1).Visible = False
            e.Row.Cells(3).Visible = False
            e.Row.Cells(4).Visible = False
            e.Row.Cells(10).Visible = False
            e.Row.Cells(11).Visible = False
            e.Row.Cells(16).Visible = False
            e.Row.Cells(19).Visible = False
            e.Row.Cells(20).Visible = False
        End If
    End Sub
#End Region
#Region "Support Functions"
    Private Function IntegerToDateString(ByVal d As Integer) As String
        Return d.ToString.Substring(0, 4) & "-" & d.ToString.Substring(4, 2) & "-" & d.ToString.Substring(6, 2)
    End Function
#End Region
#Region "Utility"

    Private Sub AlertMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMFail"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub

    Private Sub SuccessMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMSuccess"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub

    'Protected Sub ImageButton1_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton1.Click
    '    'fillgrid()
    '    GridViewExportUtil.Export(lblReportName.CurrentPage & "-" & LblError.Text & ".xls", Me.GdAttendance)
    'End Sub


    Public Overrides Sub VerifyRenderingInServerForm(ByVal Control As Control)

    End Sub

#End Region
End Class
