﻿Imports com.nss.DBAccess
Imports System.Data
Imports System.Data.SqlClient
Partial Class Quality_ListTransactions
    Inherits System.Web.UI.Page
#Region "Properties"
    Property HasQuestion() As Boolean
        Get
            Return ViewState("HasQuestion")
        End Get
        Set(ByVal value As Boolean)
            ViewState("HasQuestion") = value
        End Set
    End Property
    Property LoginUserID() As String
        Get
            Return ViewState("LoginUserID")
        End Get
        Set(ByVal value As String)
            ViewState("LoginUserID") = value
        End Set
    End Property
    Property LoginUserName() As String
        Get
            Return ViewState("LoginUserName")
        End Get
        Set(ByVal value As String)
            ViewState("LoginUserName") = value
        End Set
    End Property
    Property StandAloneCMF() As Boolean
        Get
            Return ViewState("StandAloneCMF")
        End Get
        Set(ByVal value As Boolean)
            ViewState("StandAloneCMF") = value
        End Set
    End Property
    Property ProcessID() As Integer
        Get
            Return ViewState("ProcessID")
        End Get
        Set(ByVal value As Integer)
            ViewState("ProcessID") = value
            Session("ProcessID") = value
        End Set
    End Property
    Property Campaigntype() As Integer
        Get
            Return ViewState("Campaigntype")
        End Get
        Set(ByVal value As Integer)
            ViewState("Campaigntype") = value
            'Session("ProcessID") = value
        End Set
    End Property
    Property ReportType() As Integer
        Get
            Return ViewState("ReportType")
        End Get
        Set(ByVal value As Integer)
            ViewState("ReportType") = value
        End Set
    End Property
    Property CampaignID() As Integer
        Get
            Return ViewState("CampaignID")
        End Get
        Set(ByVal value As Integer)
            ViewState("CampaignID") = value
        End Set
    End Property

    Property AgentID() As String
        Get
            Return ViewState("AgentID")
        End Get
        Set(ByVal value As String)
            ViewState("AgentID") = value
        End Set
    End Property

    Property BookingID() As String
        Get
            Return ViewState("BookingID")
        End Get
        Set(ByVal value As String)
            ViewState("BookingID") = value
        End Set
    End Property
    Property UserID() As String
        Get
            Return ViewState("UserID")
        End Get
        Set(ByVal value As String)
            ViewState("UserID") = value
        End Set
    End Property
#End Region

#Region "Load Functions"
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        HumanMessage.Style.Item("visibility") = "hidden"
        If Not IsPostBack Then
            If Session("AgentID") <> "" Then
                Try
                    CampaignID = Session("CampaignID")
                    UserID = Session("AgentID")
                    'LoadData()

                    'Dim req As String = ""
                    'Dim req2 As String = ""
                    'req = Request.Url.ToString()
                    'req2 = req.Replace("Listtransaction.aspx", "^Listtransaction.aspx")


                    PanelReports.Controls.Add(Common.GetMenu(Request.Url, UserID, Request.ApplicationPath))
                    PopulateCampaigns()
                    If ddlCampaigns.SelectedValue <> 32 Then
                        PopulateAgents()
                    End If
                    If ddlCampaigns.SelectedValue = 32 Then
                        PopulateBclass()
                    End If


                    'PopulateSavedAgents()

                    PopulateOutcomes()
                    SetUserFilters()
                    addQuestion()
                    SetStandAloneCMF()

                    manupulatecol_Other()


                Catch ex As Exception
                    'com.nss.webException.Log(ex)
                End Try
            End If
        Else
            Session("AgentID") = UserID
        End If

    End Sub

    Private Sub PopulateSavedAgents()
        Try
            ddlfilter.Items.Clear()
            Dim db As New DBAccess("CRM")
            Dim dt As DataTable = db.ReturnTable("Select  tm.agentid as agentid ,tm.AgentName as [Agent Name] from Tbl_UserFilters tuf join tbl_AgentMaster tm  on tuf.AgentID = tm.AgentID   and tm.active = 1 and tuf.userid = '" & UserID & "' ")

            'Dim dt As DataTable = db.ReturnTable("usp_GetAgentsOfTheProcess", "", True)
            ddlfilter.DataSource = Nothing
            ddlfilter.DataTextField = "Agent Name"
            ddlfilter.DataValueField = "agentid"
            ddlfilter.DataSource = dt
            ddlfilter.DataBind()
            ' ddlfilter.SelectedIndex = 0
            db = Nothing
            dt = Nothing
        Catch ex As Exception
            'AlertMessage(ex.Message.ToString)
            lblError.Visible = True
            lblError.Text = ex.Message.ToString
        End Try
    End Sub
    Private Sub SetUserFilters()
        Dim filterfailed As Boolean
        Dim db As New DBAccess("qualitynew")
        Dim dr As DataRow = db.ReturnRow("Select * from Tbl_UserFilters where userid='" & UserID & "'")
        db = Nothing
        If dr Is Nothing Then
            filterfailed = True

        Else
            Try
                DdlDay.Items.FindByValue(dr("Date").ToString.Substring(6, 2)).Selected = True
                DdlMonths.Items.FindByValue(dr("Date").ToString.Substring(4, 2)).Selected = True
                DdlYears.Items.FindByValue(dr("Date").ToString.Substring(0, 4)).Selected = True
                ddlCampaigns.ClearSelection()
                ddlCampaigns.Items.FindByValue(dr("campaignid")).Selected = True
                '@test
                'ddlfilter.ClearSelection()
                'ddlfilter.Items.FindByValue(dr("AgentID")).Selected = True
                PopulateOutcomes()
                If Not IsDBNull(dr("Outcome")) Then
                    If dr("Outcome") <> 0 Then
                        DdlOutcome.ClearSelection()
                        DdlOutcome.Items.FindByValue(dr("Outcome")).Selected = True
                    End If
                End If
            Catch ex As Exception
                filterfailed = True
            End Try

        End If
        If filterfailed Then
            IntializeFilters()
        End If
    End Sub
    Private Sub IntializeFilters()
        Dim db As New DBAccess("qualitynew")
        db.exeSQL("delete from Tbl_UserFilters where userid='" & UserID & "'")
        db = Nothing
        DdlDay.Items.FindByText(Today.Day.ToString).Selected = True
        DdlMonths.Items.FindByValue(Today.Month.ToString.PadLeft(2, "0")).Selected = True
        DdlYears.Items.FindByText(Today.Year.ToString).Selected = True
        PopulateOutcomes()
    End Sub
    Private Sub SetStandAloneCMF()
        Dim db As New DBAccess("crm")
        If db.ReturnValue("select isnull(crm,1) from tbl_config_campaigns where campaignid=" & ddlCampaigns.SelectedValue, False) = False Then
            StandAloneCMF = True
            ddlfilter.Visible = True
        Else
            StandAloneCMF = False
        End If
        db = Nothing
    End Sub
    Private Sub PopulateOutcomes()
        Dim db As New DBAccess("crm")
        db.slDataAdd("campaign_id", ddlCampaigns.SelectedValue)
        Dim dt As DataTable = db.ReturnTable("usp_GetCMFDisposition", , True)
        DdlOutcome.DataSource = dt
        DdlOutcome.DataTextField = "Caption"
        DdlOutcome.DataValueField = "Code"
        DdlOutcome.DataBind()
        DdlOutcome.Items.Insert(0, "")
        db = Nothing
    End Sub
    Private Sub PopulateCampaigns()
        Try
            Dim db2 As New DBAccess("crm")
            db2.slDataAdd("agentid", UserID)
            Dim dt As DataTable = db2.ReturnTable("usp_GetAgentDetails", "", True)
            db2 = Nothing
            LoginUserID = dt.Rows(0).Item("Agentid")
            LoginUserName = dt.Rows(0).Item("AgentName")
            Dim db As New DBAccess("crm")
            db.slDataAdd("Agentid", LoginUserID)
            ddlCampaigns.DataSource = db.ReturnTable("usp_MyCampaigns", , True)
            ddlCampaigns.DataValueField = "campaignid"
            ddlCampaigns.DataTextField = "name"
            ddlCampaigns.DataBind()
            'ddlCampaigns.Items.Insert(0, "")
            btnGetTransactions.Enabled = ddlCampaigns.Items.Count > 0
            dt = Nothing
            db = Nothing
        Catch ex As Exception
            'AlertMessage(ex.Message.ToString)
            lblError.Visible = True
            lblError.Text = ex.Message.ToString
        End Try
    End Sub
    Dim dtQuestions As DataTable
    Private Sub addQuestion()
        Dim dbwk As New DBAccess("crm")
        dbwk.slDataAdd("Campaignid", ddlCampaigns.SelectedValue)
        dtQuestions = dbwk.ReturnTable("usp_getQuestion", , True)
        dbwk = Nothing
        HasQuestion = IIf(dtQuestions.Rows.Count > 0, True, False)
        If HasQuestion Then
            ddlfilter.DataSource = Nothing
            ddlfilter.DataSource = dtQuestions.DefaultView
            ddlfilter.DataTextField = "Caption"
            ddlfilter.DataValueField = "QuestId"
            ddlfilter.DataBind()
            ddlfilter.Items.Insert(0, "")
        End If
        'Return HasWorktype
    End Sub
    Private Sub PopulateAgents()
        Try
            Dim db As New DBAccess("CRM")
            db.slDataAdd("campaignid", ddlCampaigns.SelectedValue)
            Dim dt As DataTable = db.ReturnTable("usp_GetAgentsOfTheProcess", "", True)
            ddlfilter.DataSource = Nothing
            ddlfilter.DataTextField = "Agent Name"
            ddlfilter.DataValueField = "agentid"
            ddlfilter.DataSource = dt
            ddlfilter.DataBind()
            db = Nothing
            dt = Nothing
        Catch ex As Exception
            'AlertMessage(ex.Message.ToString)
            lblError.Visible = True
            lblError.Text = ex.Message.ToString
        End Try
    End Sub


    ''' <summary>
    ''' TTC -379
    ''' </summary>
    ''' <remarks></remarks>

    Private Sub manupulatecol_379()
        If StandAloneCMF Then
            rdlFilter.Items.Clear()
            rdlFilter.Items.Add("AgentID")
            rdlFilter.Items(0).Selected = True
            PopulateAgents()
        Else

            rdlFilter.Items.Clear()
            rdlFilter.Items.Add("LeadID")
            rdlFilter.Items.Add("BookingID")
            rdlFilter.Items.Add("AgentID")
            rdlFilter.Items.Add("Question")
            rdlFilter.Items.Add("All Filled CMF")
            rdlFilter.Items.Add("My Filled CMF")
            rdlFilter.Items.Add("Show ALL")

            End If

            If rdlFilter.SelectedIndex <> -1 Then
                If rdlFilter.SelectedItem.Text <> "My Filled CMF" And rdlFilter.SelectedItem.Text <> "All Filled CMF" Then
                    dtgMain.Columns.RemoveAt(dtgMain.Columns.Count - 2)
                End If
            End If
    End Sub

    Private Sub PopulateBclass()
        Try
            Dim db As New DBAccess("CRM")
            Dim dt As DataTable = db.ReturnTable("usp_GetBclassTheProcess", "", True)
            ddlfilter.DataSource = Nothing
            ddlfilter.DataTextField = "Name"
            ddlfilter.DataValueField = "ID"
            ddlfilter.DataSource = dt
            ddlfilter.DataBind()
            db = Nothing
            dt = Nothing
        Catch ex As Exception
            'AlertMessage(ex.Message.ToString)
            lblError.Visible = True
            lblError.Text = ex.Message.ToString
        End Try
    End Sub

    Private Sub manupulatecol_Other()
        If StandAloneCMF Then
            rdlFilter.Items.Clear()
            rdlFilter.Items.Add("AgentID")
            rdlFilter.Items(0).Selected = True
            If ddlCampaigns.SelectedValue <> 32 Then
                PopulateAgents()
            End If
            If ddlCampaigns.SelectedValue = 32 Then
                PopulateBclass()
            End If

        Else
            If rdlFilter.Items.Count <= 1 Then
                rdlFilter.Items.Clear()
                rdlFilter.Items.Add("LeadID")
                rdlFilter.Items.Add("Telephone")
                rdlFilter.Items.Add("AgentID")
                rdlFilter.Items.Add("Question")
                rdlFilter.Items.Add("Building No")
                rdlFilter.Items.Add("Class")
                rdlFilter.Items.Add("All Filled CMF")
                rdlFilter.Items.Add("My Filled CMF")
                rdlFilter.Items.Add("Show ALL")
            End If
        End If

            'If dtQuestions.Select("Caption=" Then
            '    dtgMain.Columns.RemoveAt(2)
        'End If

        If ddlCampaigns.SelectedValue = 32 Then
            If rdlFilter.Items.FindByValue("Building No") Is Nothing Then
                rdlFilter.Items.Insert(1, "Building No")
            End If
            
        Else
            rdlFilter.Items.Remove(rdlFilter.Items.FindByValue("Building No"))
            dtgMain.Columns.RemoveAt(2)
        End If

        'If ddlCampaigns.SelectedValue = 32 Then
        '    If rdlFilter.Items.FindByValue("BClass") Is Nothing Then
        '        rdlFilter.Items.Insert(1, "BClass")
        '    End If

        'Else
        '    rdlFilter.Items.Remove(rdlFilter.Items.FindByValue("BClass"))
        '    dtgMain.Columns.RemoveAt(2)
        'End If


     
        

        'for 379-TTC
        If ddlCampaigns.SelectedValue = 379 Then
           
            If rdlFilter.Items.FindByValue("BookingID") Is Nothing Then
                rdlFilter.Items.Insert(1, "BookingID")
            End If

        Else
            rdlFilter.Items.Remove(rdlFilter.Items.FindByValue("BookingID"))
            dtgMain.Columns.RemoveAt(3)

        End If



            If rdlFilter.SelectedIndex <> -1 Then
                If rdlFilter.SelectedItem.Text <> "My Filled CMF" And rdlFilter.SelectedItem.Text <> "All Filled CMF" Then
                    dtgMain.Columns.RemoveAt(dtgMain.Columns.Count - 2)
                End If
            End If
    End Sub

    Private Sub filledtrans()
        Try
            Dim TransDate As String
            TransDate = DdlYears.SelectedValue + DdlMonths.SelectedValue + DdlDay.SelectedValue
            Dim db As New DBAccess("crm")
            db.slDataAdd("campaignid", ddlCampaigns.SelectedValue)
            db.slDataAdd("TransactionDate", TransDate)
            If rdlFilter.SelectedItem.Text = "My Filled CMF" Then
                db.slDataAdd("qeid", LoginUserID)
            End If
            Dim dt As DataTable = db.ReturnTable("usp_GetCMFTransactions_Filled_New", , True)
            dtgMain.DataSource = dt
            dtgMain.DataBind()
            db = Nothing
            dt = Nothing
        Catch ex As Exception
            'AlertMessage(ex.Message.ToString)
            lblError.Visible = True
            lblError.Text = ex.Message.ToString
        End Try
    End Sub
    Private Sub GetTransactions()

        Dim TransDate As String
        TransDate = DdlYears.SelectedValue + DdlMonths.SelectedValue + DdlDay.SelectedValue
        If ddlCampaigns.SelectedValue = "" Then
            'AlertMessage("Please select a campaign")
            lblError.Text = "Please select a campaign"
            lblError.Visible = True
            Return
            Exit Sub
        End If

        If ddlCampaigns.SelectedValue = "" And TransDate = "" And DdlOutcome.SelectedValue = "" Then
            'AlertMessage("Please fill in atleast one criteria to proceed.")
            lblError.Text = "Please fill in atleast one criteria to proceed."
            lblError.Visible = True
            Exit Sub
        End If
        If rdlFilter.SelectedItem.Text = "Question" Then
            If ddlfilter.SelectedValue Is Nothing Or ddlfilter.SelectedValue = "" Or txtfilter.Text.Trim = "" Then
                'AlertMessage("Please select the question and fill in the answer to proceed.")
                lblError.Text = "Please select the question and fill in the answer to proceed."
                lblError.Visible = True
                Exit Sub
            End If
        End If
        Try
            Try
                Dim dbFilter As New DBAccess("qualitynew")

                dbFilter.slDataAdd("UserID", UserID)
                dbFilter.slDataAdd("campaignID", ddlCampaigns.SelectedValue)
                dbFilter.slDataAdd("Date", TransDate)
                dbFilter.slDataAdd("ResultCode", DdlOutcome.SelectedValue)
                'dbFilter.slDataAdd("CustomerID", txtLeadID.Text)
                'dbFilter.slDataAdd("AgentID", txtagentid.Text)
                dbFilter.Executeproc("usp_SaveFilters1")
                dbFilter = Nothing

            Catch ex As Exception
                'AlertMessage(ex.ToString)
                lblError.Text = ex.ToString.ToString
                lblError.Visible = True
            End Try
            Dim db As New DBAccess("report")
            If rdlFilter.SelectedItem.Text = "LeadID" Then
            ElseIf rdlFilter.SelectedItem.Text = "Telephone" Then
            ElseIf rdlFilter.SelectedItem.Text = "Building No" Then
                db.slDataAdd("bldno", IIf(txtfilter.Text.Trim = "", "%", Trim(txtfilter.Text)))

            ElseIf rdlFilter.SelectedItem.Text = "Class" Then
                db.slDataAdd("Class", IIf(txtfilter.Text.Trim = "", "%", Trim(txtfilter.Text)))

            ElseIf rdlFilter.SelectedItem.Text = "All Filled CMF" Then

            ElseIf rdlFilter.SelectedItem.Text = "Show ALL" Then
            ElseIf rdlFilter.SelectedItem.Text = "Question" Then
                db.slDataAdd("QuestId", IIf(ddlfilter.SelectedValue.Trim = "", 0, Trim(ddlfilter.SelectedValue)))
                db.slDataAdd("AnsText", IIf(txtfilter.Text.Trim = "", "%", Trim(txtfilter.Text)))
            ElseIf rdlFilter.SelectedItem.Text = "AgentID" Then
                db.slDataAdd("agentid", IIf(ddlfilter.SelectedValue.Trim = "", "%", Trim(ddlfilter.SelectedValue)))
            End If
            db.slDataAdd("Camp", IIf(ddlCampaigns.SelectedValue.Trim = "", "%", Trim(ddlCampaigns.SelectedValue)))
            db.slDataAdd("TransactionDate", IIf(TransDate.Trim = "", "%", TransDate.Trim))
            db.slDataAdd("ResultCode", IIf(DdlOutcome.SelectedValue.Trim = "", "%", Trim(DdlOutcome.SelectedValue)))
            'db.slDataAdd("leadid", IIf(txtLeadID.Text.Trim = "", "%", Trim(txtLeadID.Text)))
            'db.slDataAdd("agentid", IIf(txtagentid.Text.Trim = "", "%", Trim(txtagentid.Text)))
            'If ddlCampaigns.SelectedValue = 32 Then
            '    db.slDataAdd("bldno", IIf(Txtbldgnos.Text.Trim = "", "%", Trim(Txtbldgnos.Text)))
            'End If
            'If HasWorktype Then
            'db.slDataAdd("worktype", IIf(ddlworktype.SelectedValue.Trim = "", "%", Trim(ddlworktype.SelectedValue)))
            'End If
            ' Dim dt As DataTable = db.ReturnTable("usp_GetCMFTransactions_terms2", , True)
            Dim dt As DataTable

            'for 379-TTC
            If ddlCampaigns.SelectedValue = 379 Then
                If rdlFilter.SelectedItem.Text = "BookingID" Then
                    db.slDataAdd("AgentID", "%")
                    db.slDataAdd("BookingID", IIf(txtfilter.Text.Trim = "", "%", Trim(txtfilter.Text)))
                End If
                dt = db.ReturnTable("usp_GetCMFTransactions_new_379", , True)
            Else
                dt = db.ReturnTable("usp_GetCMFTransactions_new", , True)
                dtgMain.Columns.RemoveAt(3)
            End If

            ' Dim dt As DataTable = db.ReturnTable("usp_GetCMFTransactions_new", , True)
            dtgMain.DataSource = dt
            dtgMain.DataBind()
            db = Nothing
        Catch ex As Exception
            'AlertMessage(ex.ToString)
            lblError.Text = ex.ToString.ToString
            lblError.Visible = True
        End Try
    End Sub
    Private Sub populategrid()

            manupulatecol_Other()


        If rdlFilter.SelectedItem Is Nothing Then
            lblError.Text = "Please select a criteria"
            lblError.Visible = True
            Return
        Else
            lblError.Visible = False
        End If
        If rdlFilter.SelectedItem.Text = "LeadID" Then
            If txtfilter.Text = "" Or txtfilter.Text Is Nothing Then
                'AlertMessage("Please fill LID")
                lblError.Text = "Please fill LID"
                lblError.Visible = True
            Else
                If IsNumeric(txtfilter.Text) Then
                    'Response.Redirect("~/Quality/TransactionDetail.aspx?lid=" & txtfilter.Text & "&campid=" & ddlCampaigns.SelectedValue & "&LoginUserID=" & LoginUserID & "&LoginUserName=" & LoginUserName)
                    Response.Redirect("~/Quality/^TransactionDetail?lid=" & txtfilter.Text & "&campid=" & ddlCampaigns.SelectedValue & "&LoginUserID=" & LoginUserID & "&LoginUserName=" & LoginUserName)

                    Exit Sub
                Else
                    'AlertMessage("Please fill LID in numeric format")
                    lblError.Text = "Please fill LID in numeric format"
                    lblError.Visible = True
                End If
            End If
        ElseIf rdlFilter.SelectedItem.Text = "Telephone" Then
            If txtfilter.Text = "" Or txtfilter.Text Is Nothing Then
                'AlertMessage("Please fill telephone")
                lblError.Text = "Please fill telephone"
                lblError.Visible = True
            Else
                If IsNumeric(txtfilter.Text) Then
                    Dim db As New DBAccess("crm")
                    Dim dtd As DataTable

                    dtd = db.ReturnTable("select top 1 customerid,id from tbl_Data_Transactions where campaignid=" & ddlCampaigns.SelectedValue & " and dialednumber='" & txtfilter.Text & "' order by id desc", False)
                    db = Nothing
                    If dtd.Rows.Count > 0 Then
                        'Response.Redirect("~/Quality/TransactionDetail.aspx?lid=" & dtd.Rows(0).Item("customerid") & "&campid=" & ddlCampaigns.SelectedValue & "&LoginUserID=" & LoginUserID & "&LoginUserName=" & LoginUserName & "&Transid=" & dtd.Rows(0).Item("id"))
                        Response.Redirect("~/Quality/^TransactionDetail?lid=" & dtd.Rows(0).Item("customerid") & "&campid=" & ddlCampaigns.SelectedValue & "&LoginUserID=" & LoginUserID & "&LoginUserName=" & LoginUserName & "&Transid=" & dtd.Rows(0).Item("id"))

                    Else
                        'AlertMessage("Telephone does not exist")
                        lblError.Text = "Telephone does not exist"
                        lblError.Visible = True
                    End If
                    Exit Sub
                Else
                    'AlertMessage("Please fill Telephone in correct format")
                    lblError.Text = "Please fill Telephone in correct format"
                    lblError.Visible = True
                End If
            End If
        ElseIf rdlFilter.SelectedItem.Text = "All Filled CMF" Then
            filledtrans()
        ElseIf rdlFilter.SelectedItem.Text = "My Filled CMF" Then
            filledtrans()
        ElseIf rdlFilter.SelectedItem.Text = "Building No" Then
            GetTransactions()
        ElseIf rdlFilter.SelectedItem.Text = "Class" Then
            GetTransactions()
        ElseIf rdlFilter.SelectedItem.Text = "BookingID" Then
            GetTransactions()
        ElseIf rdlFilter.SelectedItem.Text = "Show ALL" Then
            GetTransactions()
        ElseIf rdlFilter.SelectedItem.Text = "Question" Then
            GetTransactions()
        ElseIf rdlFilter.SelectedItem.Text = "AgentID" Then
            GetTransactions()
        Else
            'AlertMessage("Please select a criteria")
            lblError.Text = "Please select a criteria"
            lblError.Visible = True
        End If
    End Sub
#End Region
#Region "Events"
    Protected Sub ddlCampaigns_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ddlCampaigns.SelectedIndexChanged
        'lblError.Visible = False
        SetStandAloneCMF()
        PopulateOutcomes()
        addQuestion()

        manupulatecol_Other()
      
        rdlFilter.ClearSelection()
        txtfilter.Visible = False
        ddlfilter.Visible = False
    End Sub
    'Protected Sub btnClose_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnClose.Click
    '    Response.Redirect("../Shared/index2.asp")
    'End Sub
    Protected Sub dtgMain_PageIndexChanging(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewPageEventArgs) Handles dtgMain.PageIndexChanging
        dtgMain.PageIndex = e.NewPageIndex
        populategrid()
        'e.NewPageIndex += 1
    End Sub
    Protected Sub rdlFilter_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles rdlFilter.SelectedIndexChanged
        If rdlFilter.SelectedItem.Text = "LeadID" Or rdlFilter.SelectedItem.Text = "Telephone" Or rdlFilter.SelectedItem.Text = "Building No" Or rdlFilter.SelectedItem.Text = "BookingID" Then
            txtfilter.Visible = True
            ddlfilter.Visible = False
        ElseIf rdlFilter.SelectedItem.Text = "All Filled CMF" Or rdlFilter.SelectedItem.Text = "Show ALL" Then
            txtfilter.Visible = False
            ddlfilter.Visible = False
        ElseIf rdlFilter.SelectedItem.Text = "Question" Then
            addQuestion()
            txtfilter.Visible = True
            ddlfilter.Visible = True
        ElseIf rdlFilter.SelectedItem.Text = "AgentID" Then
            txtfilter.Visible = False
            ddlfilter.Visible = True
            PopulateAgents()
        ElseIf rdlFilter.SelectedItem.Text = "Class" Then
            txtfilter.Visible = False
            ddlfilter.Visible = True
            PopulateBclass()

        Else
            txtfilter.Visible = False
            ddlfilter.Visible = False
        End If
    End Sub
    Protected Sub btnGetTransactions_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnGetTransactions.Click
        Dim TransDate As String
        TransDate = DdlYears.SelectedValue + DdlMonths.SelectedValue + DdlDay.SelectedValue
        If StandAloneCMF Then
            Dim db As New DBAccess("qualitynew")
            db.slDataAdd("CampId", ddlCampaigns.SelectedValue)
            Dim dt As DataTable = db.ReturnTable("usp_QualityGetCMFList_new", , True)
            db = Nothing
            If rdlFilter.SelectedItem.Text <> "AgentID" And ddlfilter.SelectedValue.Trim = "" Then
                'AlertMessage("Please select a Agent")
                lblError.Text = "Please select a Agent"
                lblError.Visible = True
                Return
            Else
                Dim dbFilter As New DBAccess("qualitynew")
                dbFilter.slDataAdd("UserID", UserID)
                dbFilter.slDataAdd("campaignID", ddlCampaigns.SelectedValue)
                dbFilter.slDataAdd("AgentID", ddlfilter.SelectedValue.Trim)
                dbFilter.slDataAdd("Date", TransDate)
                dbFilter.Executeproc("usp_SaveFilters1")
                dbFilter = Nothing
                If dt.Rows.Count > 1 Then
                    Session("Return") = "^ListTransactions"
                    'Response.Redirect("~/Quality/TransactionDetail.aspx?StandAloneCMF=1&stage=No&lid=-1&campid=" & ddlCampaigns.SelectedValue & "&agentid=" & ddlfilter.SelectedValue.Trim & "&TransDate=" & TransDate & "&TransID=-1&CMFID=0&SheetID=0&Telephone=" & "&LoginUserID=" & LoginUserID & "&LoginUserName=" & LoginUserName)
                    Response.Redirect("~/Quality/^TransactionDetail?StandAloneCMF=1&stage=No&lid=-1&campid=" & ddlCampaigns.SelectedValue & "&agentid=" & ddlfilter.SelectedValue.Trim & "&TransDate=" & TransDate & "&TransID=-1&CMFID=0&SheetID=0&Telephone=" & "&LoginUserID=" & LoginUserID & "&LoginUserName=" & LoginUserName)

                ElseIf dt.Rows.Count = 0 Then
                    lblError.Text = "There is no CMF defined for this campaign"
                    lblError.Visible = True
                    Return
                Else
                    Session("Return") = "^ListTransactions"
                    ' Response.Redirect("~/Quality/NewCMF.aspx?StandAloneCMF=1&stage=N&lid=-1&campid=" & ddlCampaigns.SelectedValue & "&agentid=" & ddlfilter.SelectedValue.Trim & "&TransDate=" & TransDate & "&TransID=-1&CMFID=" & dt.Rows(0).Item("CMFId") & "&SheetID=0&Telephone=" & "&LoginUserID=" & LoginUserID & "&LoginUserName=" & LoginUserName)
                    Response.Redirect("~/Quality/CMFform.aspx?StandAloneCMF=1&stage=N&lid=-1&campid=" & ddlCampaigns.SelectedValue & "&agentid=" & ddlfilter.SelectedValue.Trim & "&TransDate=" & TransDate & "&TransID=-1&CMFID=" & dt.Rows(0).Item("CMFId") & "&SheetID=0&Telephone=" & "&LoginUserID=" & LoginUserID & "&LoginUserName=" & LoginUserName)
                End If

            End If

        Else
            'lblError.Visible = False
            btnGetTransactions.Enabled = False
            btnGetTransactions.Focus()
            populategrid()
            btnGetTransactions.Enabled = True
        End If

    End Sub
    Protected Sub imgfav_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles imgfav.Click
        Common.AddToFav(UserID, "List Transaction")
        'Response.Write("<script type = 'text/javascript'>alert('Report has been added to your favourite list')</script>")
        SuccessMessage("Report has been added to your favourite list")
        SetStandAloneCMF()
        PopulateOutcomes()
        addQuestion()

        manupulatecol_Other()
        
    End Sub
#End Region
#Region "Utility"

    Private Sub AlertMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMFail"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub

    Private Sub SuccessMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMSuccess"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub

    'Protected Sub ImageButton1_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton1.Click
    '    'fillgrid()
    '    GridViewExportUtil.Export(lblReportName.CurrentPage & "-" & LblError.Text & ".xls", Me.GdAttendance)
    'End Sub


    Public Overrides Sub VerifyRenderingInServerForm(ByVal Control As Control)

    End Sub

#End Region


End Class
