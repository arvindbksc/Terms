﻿Imports System.Data
Imports com.nss.DBAccess
Imports System.Data.SqlClient
Imports System.Drawing
Partial Class Quality_NewCMF
    Inherits System.Web.UI.Page
#Region "Properties"
    Property SheetID() As Integer
        Get
            Return ViewState("SheetID")
        End Get
        Set(ByVal value As Integer)
            ViewState("SheetID") = value
        End Set
    End Property
    Property CustomerID() As Integer
        Get
            Return ViewState("CustomerID")
        End Get
        Set(ByVal value As Integer)
            ViewState("CustomerID") = value
        End Set
    End Property
    Property TransID() As Integer
        Get
            Return ViewState("TransID")
        End Get
        Set(ByVal value As Integer)
            ViewState("TransID") = value
        End Set
    End Property
    Property CMFID() As Integer
        Get
            Return ViewState("CMFID")
        End Get
        Set(ByVal value As Integer)
            ViewState("CMFID") = value
        End Set
    End Property
    Property CampaignID() As Integer
        Get
            Return ViewState("CampaignID")
        End Get
        Set(ByVal value As Integer)
            ViewState("CampaignID") = value
        End Set
    End Property
    Property MainCatID() As Integer
        Get
            Return ViewState("MainCatID")
        End Get
        Set(ByVal value As Integer)
            ViewState("MainCatID") = value
        End Set
    End Property
    Property SubCatID() As Integer
        Get
            Return ViewState("SubCatID")
        End Get
        Set(ByVal value As Integer)
            ViewState("SubCatID") = value
        End Set
    End Property
    Property LoginUserID() As String
        Get
            Return ViewState("LoginUserID")
        End Get
        Set(ByVal value As String)
            ViewState("LoginUserID") = value
        End Set
    End Property
    Property LoginUserName() As String
        Get
            Return ViewState("LoginUserName")
        End Get
        Set(ByVal value As String)
            ViewState("LoginUserName") = value
        End Set
    End Property
    Property AgentID() As String
        Get
            Return ViewState("AgentID")
        End Get
        Set(ByVal value As String)
            ViewState("AgentID") = value
        End Set
    End Property
    'Property UserID() As String
    '    Get
    '        Return ViewState("UserID")
    '    End Get
    '    Set(ByVal value As String)
    '        ViewState("UserID") = value
    '    End Set
    'End Property

    Property TransIDQuality() As String
        Get
            Return ViewState("TransIDQuality")
        End Get
        Set(ByVal value As String)
            ViewState("TransIDQuality") = value
        End Set
    End Property
#End Region
#Region "Load Function"
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            'UserID = Session("AgentID")
            CustomerID = Request.QueryString("lid")
            TransID = Request.QueryString("transid")
            CMFID = Request.QueryString("CMFID")
            lblcmfid.Text = IIf(CustomerID = -1, "", CustomerID)
            CampaignID = Request.QueryString("campid")
            SheetID = Request.QueryString("sheetid")
            LoginUserID = Request.QueryString("LoginUserID")
            LoginUserName = Request.QueryString("LoginUserName")
            PanelReports.Controls.Add(Common.GetMenu(Request.Url, LoginUserID, Request.ApplicationPath))
            
            ''------------------------------------------------------------------
            ' Added to insert data in tbl_Data_Transactions (12-12-12) - Gaurav
            If (Request.QueryString("stage") = "N") Then
                Dim db As New DBAccess("CRM")
                db.slDataAdd("lid", CustomerID)
                db.slDataAdd("QAAgentId", LoginUserID)
                db.slDataAdd("DialedNumber", "")
                db.slDataAdd("CampaignID", CampaignID)
                db.slDataAdd("CallTable", "")
                TransIDQuality = db.ReturnValue("usp_InsertTransaction_Quality", True)
            End If
            ''------------------------------------------------------------------
            txtcomments.Text = "Positives :-" & vbNewLine & "Occurred :-" & vbNewLine & "VNA :-" & vbNewLine & "Soft Skills / Sales Skills :-" & vbNewLine & "Product / Compliance :-" & vbNewLine & "Areas of Improvement :-" & vbNewLine & "Suggestions / POA :-" & vbNewLine & "Others :-"
            GetTMTLName()
            GetCampaignName()
            GetCallType()
            GetErrorType()
            PopulateCMF()
        Else
            'Session("AgentID") = UserID
        End If

        If Request.QueryString("StandaloneCMF") = 1 Then
            btnSave.Enabled = False
        End If
    End Sub
#End Region
    
#Region "Generate CMF Sheet"
    Private Sub PopulateCMF()
        Dim db As New DBAccess("qualitynew")
        db.slDataAdd("campid", CampaignID)
        db.slDataAdd("CMFID", CMFID)
        If (Request.QueryString("Stage") = "M" Or Request.QueryString("Stage") = "F") Then
            db.slDataAdd("sheetID", SheetID)
        End If
        Dim dt As DataTable = db.ReturnTable("usp_QualityGetMainCategory_New", , True)
        maincat.DataSource = dt
        maincat.DataBind()
        lblevldate.Text = Now.ToString
        db = Nothing
        If (Request.QueryString("Stage") = "M" Or Request.QueryString("Stage") = "F") Then
            db = New DBAccess("qualitynew")
            db.slDataAdd("customerid", CustomerID)
            db.slDataAdd("campid", CampaignID)
            db.slDataAdd("TransID", TransID)
            db.slDataAdd("paramid", "0")
            db.slDataAdd("Sheetid", SheetID)
            dt = db.ReturnTable("usp_QualityGetDataForLead_final_New2", "option", True)
            If dt.Rows.Count > 0 Then
                SheetID = dt.Rows(0).Item("sheetid")
                lblSheetID.Text = "CMF Sheet " & SheetID
                lblSheetID.Visible = True
                lblevldate.Text = dt.Rows(0).Item("EvaluationDate")
                lblQEName.Text = dt.Rows(0).Item("QEName")
                lblTransDate.Text = dt.Rows(0).Item("Date")
                txtAHT.Text = IIf(IsDBNull(dt.Rows(0).Item("AHT")), "", dt.Rows(0).Item("AHT"))
                CBReferClient.Checked = IIf(IsDBNull(dt.Rows(0).Item("ClientSheet")), "False", dt.Rows(0).Item("ClientSheet"))
            Else
                lblSheetID.Visible = False
            End If
            db = Nothing
            db = New DBAccess("crm")
            db.slDataAdd("Lanid", "")
            db.slDataAdd("agentid", dt.Rows(0).Item("SupervisorID"))
            Dim dr As DataRow = db.ReturnRow("usp_GetAgentDetails", True)
            If dr Is Nothing Then
                lblTL.Text = ""
            Else
                lblTL.Text = IIf(dr Is Nothing, "", dr("AgentName")) & "(" & dt.Rows(0).Item("SupervisorID") & ")"
            End If

            dt = Nothing
            db = Nothing
        End If
        If Request.QueryString("Stage") = "F" Then
            db = New DBAccess("qualitynew")
            db.slDataAdd("SheetID", SheetID)
            Dim dr As DataRow = db.ReturnRow("usp_QualityGetSheetQCScore", True)
            PnlScore.Visible = True
            lblFatalError.Text = dr.Item("FatalErrorCount")
            lblFatalErrorpercent.Text = dr.Item("FAR%")
            lblNonFatalError.Text = dr.Item("NonFatalErrorCount")
            lblNonFatalErrorpercent.Text = dr.Item("NFAR%")
            LblParamwisescore.Text = dr.Item("ParameterWiseScore%")
            GridViewExportUtil.PrintPreview(PanelCMF)
            btnSave.Visible = False
            btnfreez.Visible = False
            btnPrint.Visible = True
        End If
    End Sub
    Protected Sub maincat_ItemDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.RepeaterItemEventArgs) Handles maincat.ItemDataBound
        Dim db As New DBAccess("qualitynew")
        Dim lblcatid1 As Label = e.Item.FindControl("lblcatid")
        Dim ds As New DataSet
        Dim subcat As DataTable
        db.slDataAdd("campid", CampaignID)
        db.slDataAdd("CMFID", CMFID)
        db.slDataAdd("mcid", lblcatid1.Text)
        If (Request.QueryString("Stage") = "M" Or Request.QueryString("Stage") = "F") Then
            db.slDataAdd("sheetID", SheetID)
        End If
        MainCatID = lblcatid1.Text
        subcat = db.ReturnTable("usp_QualityGetSubCategory", "subcat", True)
        ds.Tables.Add(subcat)
        Dim dtlst1 As Repeater = e.Item.FindControl("subcat")
        AddHandler dtlst1.ItemDataBound, AddressOf subcat_ItemDataBound
        dtlst1.DataSource = ds
        dtlst1.DataBind()
    End Sub
    Protected Sub subcat_ItemDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.RepeaterItemEventArgs)
        Dim lblcatid1 As Label = e.Item.FindControl("lblcatid1")
        Dim lblsubcatid1 As Label = e.Item.FindControl("lblsubcatid")
        Dim db As New DBAccess("qualitynew")
        db.slDataAdd("campid", Request.QueryString("campid"))
        db.slDataAdd("mcid", lblcatid1.Text)
        db.slDataAdd("CMFID", CMFID)
        db.slDataAdd("scid", lblsubcatid1.Text)
        SubCatID = lblsubcatid1.Text
        MainCatID = lblcatid1.Text
        If (Request.QueryString("Stage") = "M" Or Request.QueryString("Stage") = "F") Then
            db.slDataAdd("sheetID", SheetID)
        End If
        Dim dtq As DataTable = db.ReturnTable("usp_QualityGetParameters", "Parameter", True)
        db = Nothing
        Dim dtlst2 As DataList = e.Item.FindControl("dtlst")
        Dim pcount As Label = e.Item.FindControl("parameterCount")
        pcount.Text = dtq.Rows.Count
        AddHandler dtlst2.ItemDataBound, AddressOf dtlist_ItemDataBound
        dtlst2.DataSource = dtq
        dtlst2.DataBind()
        Dim ddoptions As DropDownList = e.Item.FindControl("ddlOptions")
        If Request.QueryString("Stage") = "F" Then
            ddoptions.Items.Clear()
        End If
    End Sub
    Protected Sub dtlist_ItemDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.DataListItemEventArgs)
        Dim ddoptions As DropDownList = e.Item.FindControl("ddParamOption")
        Dim lblparamid As Label = e.Item.FindControl("lblParamid")
        Dim lblparamtype As Label = e.Item.FindControl("lblparamtype")
        Dim lblparam As Label = e.Item.FindControl("lblparam")
        If lblparamtype.Text = "F" Then
            lblparam.ForeColor = Color.Red
        End If
        Dim db As New DBAccess("qualitynew")
        Dim dt As New DataTable()
        db.slDataAdd("paramid", lblparamid.Text)
        dt = db.ReturnTable("usp_QualityGetParameteroptions", "option", True)
        ddoptions.DataSource = dt
        ddoptions.DataTextField = "OptionText"
        ddoptions.DataValueField = "Optid"
        ddoptions.DataBind()
        db = Nothing
        dt = Nothing
        If (Request.QueryString("Stage") = "M" Or Request.QueryString("Stage") = "F") Then
            Dim db1 As New DBAccess("qualitynew")
            db1.slDataAdd("customerid", Request.QueryString("lid"))
            db1.slDataAdd("campid", Request.QueryString("campid"))
            db1.slDataAdd("TransID", Request.QueryString("transid"))
            db1.slDataAdd("paramid", lblparamid.Text)
            db1.slDataAdd("mcid", MainCatID)
            db1.slDataAdd("scid", SubCatID)
            db1.slDataAdd("Sheetid", Request.QueryString("Sheetid"))
            dt = db1.ReturnTable("usp_QualityGetDataForLead_final_New2", "option", True)
            For Each i As ListItem In ddoptions.Items
                If i.Value = dt.Rows(0).Item("OptID") Then
                    i.Selected = True
                End If
            Next
            db1 = Nothing
            dt = Nothing
        End If
    End Sub

    Public Sub GetTMTLName()
        Dim db As New DBAccess("crm")
        Dim db1 As New DBAccess("crm")
        Dim dr As DataRow
        Try
            If Request.QueryString("Stage") = "N" Then
                db.slDataAdd("agentid", Request.QueryString("agentid"))
                db.slDataAdd("app_id", Request.QueryString("campid"))
                db.slDataAdd("TransID", Request.QueryString("transid"))
                dr = db.ReturnRow("usp_GetTMTLName", True)
                lblTMName.Text = IIf(dr Is Nothing, "", dr("AgentName"))
                If dr Is Nothing Then
                    lblTL.Text = ""
                ElseIf IsDBNull(dr("SupervisorName")) Then
                    lblTL.Text = ""
                Else
                    lblTL.Text = IIf(dr Is Nothing, "", dr("SupervisorName")) & "(" & dr("SupervisorID") & ")"
                End If

                lblQEName.Text = LoginUserName
                If Request.QueryString("StandAloneCMF") = 1 Then
                    lblTransDate.Text = Request.QueryString("TransDate")
                Else
                    lblTransDate.Text = db1.ReturnValue("select dateadd(ss,totalduration,startdatetime) as transdate  from tbl_Data_Transactions where id=" & TransID, False)
                End If
                Dim span As TimeSpan = New TimeSpan(TimeSpan.TicksPerSecond * Request.QueryString("duration"))
                txtAHT.Text = span.Hours.ToString("00") + ":" + span.Minutes.ToString("00") + ":" + span.Seconds.ToString("00")


            Else
                db.slDataAdd("Lanid", "")
                db.slDataAdd("agentid", Request.QueryString("agentid"))
                dr = db.ReturnRow("usp_GetAgentDetails", True)
                lblTMName.Text = IIf(dr Is Nothing, "", dr("AgentName"))

            End If
        Catch ex As Exception
            lblerror.Text = ex.ToString
            lblerror.Visible = True
        Finally
            db = Nothing
        End Try

    End Sub
    Private Sub GetCampaignName()
        Dim db As New DBAccess("crm")
        Dim dr As DataRow
        Try
            db.slDataAdd("campid", Request.QueryString("campid"))
            dr = db.ReturnRow("usp_GetCampName", True)
            lblProcess.Text = dr("Alias")
        Catch ex As Exception
            lblerror.Text = ex.ToString
            lblerror.Visible = True
        Finally
            db = Nothing
        End Try
    End Sub
    Private Sub GetCallType()
        Dim db As New DBAccess("qualitynew")
        Dim dt As DataTable
        Try
            db.slDataAdd("campid", Request.QueryString("campid"))
            dt = db.ReturnTable("usp_GetCallType", , True)
            dtcalltype.DataSource = dt
            dtcalltype.DataTextField = "vcCallType"
            dtcalltype.DataValueField = "inCallTypeId"
            dtcalltype.DataBind()
            If (Request.QueryString("Stage") = "M" Or Request.QueryString("Stage") = "F") Then
                db.slDataAdd("customerid", Request.QueryString("lid"))
                db.slDataAdd("TransID", Request.QueryString("transid"))
                db.slDataAdd("campid", Request.QueryString("campid"))
                db.slDataAdd("Sheetid", Request.QueryString("Sheetid"))
                db.slDataAdd("paramid", "0")
                dt = db.ReturnTable("usp_QualityGetDataForLead_final_New2", "option", True)
                For Each i As ListItem In dtcalltype.Items
                    If i.Text = dt.Rows(0).Item("CallType") Then
                        i.Selected = True
                    End If
                Next
            End If
        Catch ex As Exception
            lblerror.Text = ex.ToString
            lblerror.Visible = True
        Finally
            db = Nothing
        End Try
    End Sub
    Private Sub GetErrorType()
        Dim db As New DBAccess("qualitynew")
        Dim dt As DataTable
        Try
            db.slDataAdd("campid", Request.QueryString("campid"))
            dt = db.ReturnTable("usp_GetErrorType", , True)
            dterrortype.DataSource = dt
            dterrortype.DataTextField = "vcErrorType"
            dterrortype.DataValueField = "inErrorTypeId"
            dterrortype.DataBind()
            txtPhone.Text = IIf(IsDBNull(Request.QueryString("Telephone")), "", Request.QueryString("Telephone"))
            If (Request.QueryString("Stage") = "M" Or Request.QueryString("Stage") = "F") Then
                db = New DBAccess("qualitynew")
                db.slDataAdd("customerid", Request.QueryString("lid"))
                db.slDataAdd("campid", Request.QueryString("campid"))
                db.slDataAdd("TransID", Request.QueryString("transid"))
                db.slDataAdd("paramid", "0")
                db.slDataAdd("Sheetid", Request.QueryString("Sheetid"))
                dt = db.ReturnTable("usp_QualityGetDataForLead_final_New2", "option", True)

                For Each i As ListItem In dterrortype.Items
                    If i.Text = dt.Rows(0).Item("UDF1") Then
                        i.Selected = True
                    End If
                Next

                For Each i As ListItem In ddRating.Items
                    If i.Value = IIf(dt.Rows(0).Item("FinalRating") = -1, "N/A", dt.Rows(0).Item("FinalRating")) Then
                        i.Selected = True
                    End If
                Next
                txtRntNo.Text = dt.Rows(0).Item("UDF2")
                txtPhone.Text = dt.Rows(0).Item("UDF3")
                txtcomments.Text = dt.Rows(0).Item("comments")
                txtComplaints.Text = dt.Rows(0).Item("EndUserCompliant")
                SheetID = dt.Rows(0).Item("sheetid")
            End If
        Catch ex As Exception
            lblerror.Text = ex.ToString
            lblerror.Visible = False
        Finally
            db = Nothing
        End Try
    End Sub

#End Region
#Region "Events"
    Protected Sub btnClose_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnClose.Click
        If (Request.QueryString("stage") = "N") Then
            '--------------------------------------------------------------
            ' Added to Delete Transaction (Quality) (12-12-12) - Gaurav
            UpdateTransaction("delete")
            '--------------------------------------------------------------
        End If
        Response.Redirect(Request.QueryString("Return"))
    End Sub

    Protected Sub btnSave_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnSave.Click
        If txtPhone.Text = "" And txtRntNo.Text = "" Then
            lblNiceid.Text = "Nice ID/RNT Number should not be blank."
            lblPhone.Text = "Phone number should not be blank."
            lblNiceid.Visible = True
            lblPhone.Visible = True
            Return
        End If

        If txtRntNo.Text = "" Then
            lblNiceid.Text = "Nice ID/RNT Number should not be blank."
            lblNiceid.Visible = True
            Return
        Else
            lblNiceid.Visible = False
        End If
        If txtPhone.Text = "" Then
            lblPhone.Text = "Phone number should not be blank."
            lblPhone.Visible = True
            Return
        Else
            lblPhone.Visible = False
        End If
        Dim db As New DBAccess("qualitynew")
        Try
            db.BeginTrans()
            db.slDataAdd("process", lblProcess.Text.Trim)
            db.slDataAdd("campid", Request.QueryString("campid"))
            db.slDataAdd("qeid", LoginUserID)
            db.slDataAdd("markedby", LoginUserName)
            db.slDataAdd("AgentID", Request.QueryString("agentid"))
            db.slDataAdd("CustomerID", Request.QueryString("lid"))
            db.slDataAdd("TransID", Request.QueryString("TransID"))
            db.slDataAdd("CMFID", CMFID)
            If dtcalltype.Items.Count > 0 Then
                db.slDataAdd("inCallType", dtcalltype.SelectedItem.Text.Trim)
            Else
                db.slDataAdd("inCallType", "")
            End If
            db.slDataAdd("Comments", txtcomments.Text.Trim)
            If dterrortype.Items.Count > 0 Then
                db.slDataAdd("inErrorType", dterrortype.SelectedItem.Text.Trim)
            Else
                db.slDataAdd("inErrorType", "")
            End If
            db.slDataAdd("vcNiceID", txtRntNo.Text.Trim)
            db.slDataAdd("vcPhoneNo", txtPhone.Text.Trim)
            db.slDataAdd("finalrating", ddRating.SelectedValue)
            db.slDataAdd("Endusercomp", txtComplaints.Text.Trim)
            db.slDataAdd("btfreez", 0)
            If lblTL.Text.Trim = "" Then
                db.slDataAdd("SupervisorID", "")
            Else
                db.slDataAdd("SupervisorID", lblTL.Text.Trim.Substring(lblTL.Text.Trim.LastIndexOf("(")).Replace("(", "").Replace(")", ""))
            End If
            db.slDataAdd("AHT", txtAHT.Text.Trim)
            db.slDataAdd("ClientSheet", CBReferClient.Checked)
            If (Request.QueryString("Stage") = "M") Then
                db.slDataAdd("sheetid", SheetID)
                db.Executeproc("usp_QualityUpdateQMSheetMst")
            Else
                If Request.QueryString("StandAloneCMF") = 1 Then
                    db.slDataAdd("StandaloneCMF", Request.QueryString("StandAloneCMF"))
                    db.slDataAdd("Transactiondate", Request.QueryString("TransDate"))
                End If
                SheetID = db.ReturnValue("usp_QualityInsertQMSheetMst", True)
            End If
            'insert SheetData data
            For Each ctrl As Control In maincat.Controls
                Dim lblcatid1 As Label = ctrl.FindControl("lblcatid")
                Dim rpitem As RepeaterItem = ctrl.FindControl("lblsubcatid")
                For Each rpitem In ctrl.FindControl("subcat").Controls
                    Dim lblsubcatid1 As Label = rpitem.FindControl("lblsubcatid")
                    For Each lstitem As DataListItem In rpitem.FindControl("dtlst").Controls
                        Dim lblparamid As Label = lstitem.FindControl("lblParamid")
                        Dim ddoptions As DropDownList = lstitem.FindControl("ddParamOption")
                        db.slDataAdd("sheetid", SheetID)
                        db.slDataAdd("campid", Request.QueryString("campid"))
                        db.slDataAdd("paramid", lblparamid.Text)
                        db.slDataAdd("optid", ddoptions.SelectedValue)
                        db.slDataAdd("mcid", lblcatid1.Text)
                        db.slDataAdd("CMFID", CMFID)
                        db.slDataAdd("scid", lblsubcatid1.Text)
                        If (Request.QueryString("Stage") = "M") Then
                            db.Executeproc("usp_QualityUpdateSheetData")
                        Else
                            db.Executeproc("usp_QualityInsertSheetData")
                        End If
                    Next
                Next
            Next
            db.slDataAdd("Sheetid", SheetID)
            db.ExecuteprocSC("usp_QualitySaveSheetQCScore")
            db.CommitTrans()
            If (Request.QueryString("stage") = "N") Then
                '--------------------------------------------------------------
                ' Added to Save Transaction (12-12-12) - Gaurav
                UpdateTransaction("update")
                '--------------------------------------------------------------
            End If
            If (Request.QueryString("Stage") = "M") Then
                Response.Write("CMF has been modified")
            Else
                Response.Write("CMF has been saved")
            End If

        Catch ex As Exception
            lblerror.Text = ex.ToString
            lblerror.Visible = True
            db.RollBackTrans()
        Finally
            db = Nothing
        End Try
        Response.Redirect("~/Quality/^ListTransactions")
    End Sub
    
    Protected Sub btnfreez_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnfreez.Click
        If txtPhone.Text = "" And txtRntNo.Text = "" Then
            lblNiceid.Text = "Nice ID/RNT Number should not be blank."
            lblPhone.Text = "Phone number should not be blank."
            lblNiceid.Visible = True
            lblPhone.Visible = True
            Return
        End If

        If txtRntNo.Text = "" Then
            lblNiceid.Text = "Nice ID/RNT Number should not be blank."
            lblNiceid.Visible = True
            Return
        Else
            lblNiceid.Visible = False
        End If
        If txtPhone.Text = "" Then
            lblPhone.Text = "Phone number should not be blank."
            lblPhone.Visible = True
            Return
        Else
            lblPhone.Visible = False
        End If
        Dim db As New DBAccess("qualitynew")
        Try
            db.BeginTrans()
            db.slDataAdd("process", lblProcess.Text.Trim)
            db.slDataAdd("campid", Request.QueryString("campid"))
            db.slDataAdd("qeid", LoginUserID)
            db.slDataAdd("markedby", LoginUserName)
            db.slDataAdd("AgentID", Request.QueryString("agentid"))
            db.slDataAdd("CustomerID", Request.QueryString("lid"))
            db.slDataAdd("TransID", Request.QueryString("TransID"))
            db.slDataAdd("CMFID", CMFID)
            If dtcalltype.Items.Count > 0 Then
                db.slDataAdd("inCallType", dtcalltype.SelectedItem.Text.Trim)
            Else
                db.slDataAdd("inCallType", "")
            End If
            db.slDataAdd("Comments", txtcomments.Text.Trim)
            If dterrortype.Items.Count > 0 Then
                db.slDataAdd("inErrorType", dterrortype.SelectedItem.Text.Trim)
            Else
                db.slDataAdd("inErrorType", "")
            End If
            db.slDataAdd("vcNiceID", txtRntNo.Text.Trim)
            db.slDataAdd("vcPhoneNo", txtPhone.Text.Trim)
            db.slDataAdd("finalrating", ddRating.SelectedValue)
            db.slDataAdd("btfreez", 1)
            db.slDataAdd("Endusercomp", txtComplaints.Text.Trim)
            If lblTL.Text.Trim = "" Then
                db.slDataAdd("SupervisorID", "")
            Else
                db.slDataAdd("SupervisorID", lblTL.Text.Trim.Substring(lblTL.Text.Trim.LastIndexOf("(")).Replace("(", "").Replace(")", ""))
            End If
            db.slDataAdd("AHT", txtAHT.Text.Trim)
            db.slDataAdd("ClientSheet", CBReferClient.Checked)
            If (Request.QueryString("Stage") = "M" Or Request.QueryString("Stage") = "F") Then
                db.slDataAdd("sheetid", SheetID) 'sheetid1)
                db.Executeproc("usp_QualityUpdateQMSheetMst")
            Else
                If Request.QueryString("StandAloneCMF") = 1 Then
                    db.slDataAdd("StandaloneCMF", Request.QueryString("StandAloneCMF"))
                    db.slDataAdd("Transactiondate", Request.QueryString("TransDate"))
                End If
                SheetID = db.ReturnValue("usp_QualityInsertQMSheetMst", True)
            End If
            'insert SheetData data
            For Each ctrl As Control In maincat.Controls
                Dim lblcatid1 As Label = ctrl.FindControl("lblcatid")
                Dim rpitem As RepeaterItem = ctrl.FindControl("lblsubcatid")
                For Each rpitem In ctrl.FindControl("subcat").Controls
                    Dim lblsubcatid1 As Label = rpitem.FindControl("lblsubcatid")
                    For Each lstitem As DataListItem In rpitem.FindControl("dtlst").Controls
                        Dim lblparamid As Label = lstitem.FindControl("lblParamid")
                        Dim ddoptions As DropDownList = lstitem.FindControl("ddParamOption")
                        db.slDataAdd("sheetid", SheetID)
                        db.slDataAdd("campid", Request.QueryString("campid"))
                        db.slDataAdd("paramid", lblparamid.Text)
                        db.slDataAdd("optid", ddoptions.SelectedValue)
                        db.slDataAdd("mcid", lblcatid1.Text)
                        db.slDataAdd("CMFID", CMFID)
                        db.slDataAdd("scid", lblsubcatid1.Text)
                        ddoptions.Enabled = False
                        If (Request.QueryString("Stage") = "M" Or Request.QueryString("Stage") = "F") Then
                            db.Executeproc("usp_QualityUpdateSheetData")
                        Else
                            db.Executeproc("usp_QualityInsertSheetData")
                        End If
                    Next
                Next
            Next
            db.slDataAdd("Sheetid", SheetID)
            db.ExecuteprocSC("usp_QualitySaveSheetQCScore")
            db.CommitTrans()

            If (Request.QueryString("stage") = "N") Then
                '--------------------------------------------------------------
                ' Added to Save Transaction (12-12-12) - Gaurav
                UpdateTransaction("update")
                '--------------------------------------------------------------
            End If
        Catch ex As Exception
            lblerror.Text = ex.ToString
            lblerror.Visible = True
            db.RollBackTrans()
            Return
        Finally
            db = Nothing
        End Try
        Response.Redirect("~/Quality/NewCMF.aspx?stage=F&lid=" & Request.QueryString("lid") & "&campid=" & Request.QueryString("campid") & "&agentid=" & Request.QueryString("agentid") & "&TransID=" & Request.QueryString("TransID") & "&CMFID=" & CMFID & "&SheetID=" & SheetID & "&Return=^ListTransactions" & "&LoginUserID=" & LoginUserID & "&LoginUserName=" & LoginUserName)

    End Sub
    Private Sub UpdateTransaction(ByVal val As String)
        Dim dbQuality As New DBAccess("CRM")
        dbQuality.slDataAdd("LID", CustomerID)
        dbQuality.slDataAdd("QAAgentId", LoginUserID)
        dbQuality.slDataAdd("DialedNumber", "")
        dbQuality.slDataAdd("CampaignID", CampaignID)
        dbQuality.slDataAdd("CallTable", "")
        dbQuality.slDataAdd("ToInsert", 0)
        TransIDQuality = dbQuality.ReturnValue("usp_InsertTransaction_Quality", True)
        dbQuality = Nothing
        If TransIDQuality <> "0" Then
            If val = "update" Then
                Dim db As New DBAccess("CRM")
                db.slDataAdd("ID", TransIDQuality)
                db.slDataAdd("CustomerID", CustomerID)
                db.slDataAdd("ResultCode", -2)
                db.slDataAdd("CampaignID", CampaignID)
                db.Executeproc("usp_DisposeACall")
                db = Nothing
            End If
            If val = "delete" Then
                Dim dbcancel As New DBAccess("CRM")
                dbcancel.slDataAdd("Transid", TransIDQuality)
                dbcancel.Executeproc("usp_deleteTransaction")
                dbcancel = Nothing
            End If
        End If
    End Sub
#End Region
End Class
