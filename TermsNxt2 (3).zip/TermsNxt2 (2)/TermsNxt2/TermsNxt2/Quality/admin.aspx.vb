﻿
Partial Class Quality_admin
    Inherits System.Web.UI.Page

End Class
