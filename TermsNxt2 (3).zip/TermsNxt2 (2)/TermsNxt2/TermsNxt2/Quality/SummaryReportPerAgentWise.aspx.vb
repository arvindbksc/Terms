﻿Imports System.Data
Imports com.nss.DBAccess
Imports System.Data.SqlClient
Partial Class Quality_SummaryReportPerAgentWise
    Inherits System.Web.UI.Page
    Private datefrom As String
    Private dateto As String
    Private campid As Integer
    Private QEID As String
    Private calltype As String
    Private errortype As String
    Private cmfid As String
#Region "Properties"
    Property CampaignID() As Integer
        Get
            Return ViewState("CampaignID")
        End Get
        Set(ByVal value As Integer)
            ViewState("CampaignID") = value
        End Set
    End Property

    Property AgentID() As String
        Get
            Return ViewState("AgentID")
        End Get
        Set(ByVal value As String)
            ViewState("AgentID") = value
        End Set
    End Property
#End Region
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        lblcampaign1.Text = Request.QueryString("Agentid")
        lblcampaign1.Text = Request.QueryString("AgentName")
        campid = Request.QueryString("campid")
        hypererrorcount.NavigateUrl = "~/Quality/QuestionwiseErrorCount.aspx?QEID=" & Request.QueryString("QEID") & "&cmfid=" & Request.QueryString("cmfid") & "&calltype=" & Request.QueryString("calltype") & "&errortype=" & Request.QueryString("errortype") & "&agentid=" & Request.QueryString("agentid") & "&campid=" & Request.QueryString("campid") & "&DateFrom=" & Request.QueryString("DateFrom") & "&DateTo=" & Request.QueryString("DateTo")
        If Not IsPostBack Then
            CampaignID = Session("CampaignID")
            AgentID = Session("AgentID")
            PanelReports.Controls.Add(Common.GetMenu(Request.Url, AgentID, Request.ApplicationPath))
            If campid = 32 Then
                PopulateCMF_32()
            Else
                PopulateCMF()
            End If

        Else
            Session("AgentID") = AgentID
        End If

    End Sub
    Protected Sub ImageButton1_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton1.Click
        If campid = 32 Then
            PopulateCMF_32()
        Else
            PopulateCMF()
        End If
        'GridViewExportUtil.Export(lblReportName.Text & "-" & LblError.Text & ".xls", Me.GridView1)
        Dim gv As New GridView
        gv.DataSource = dtnew
        gv.DataBind()
        GridViewExportUtil.Export("QualitySummaryReportPerAgentWise" & ".xls", gv)
    End Sub

    Protected Sub filldata() Handles SubSummaryReportFilters1.firedata
        If campid = 32 Then
            Populatedata_32()
        Else
            Populatedata()
        End If

        hypererrorcount.NavigateUrl = "~/Quality/QuestionwiseErrorCount.aspx?QEID=" & SubSummaryReportFilters1.Qe & "&calltype=" & SubSummaryReportFilters1.calltype & "&cmfid=" & SubSummaryReportFilters1.cmfid & "&errortype=" & SubSummaryReportFilters1.Errortype & "&agentid=" & Request.QueryString("agentid") & "&campid=" & Request.QueryString("campid") & "&DateFrom=" & SubSummaryReportFilters1.DateFrom & "&DateTo=" & SubSummaryReportFilters1.DateTO
    End Sub
    Dim dtnew As DataTable
    Private Sub PopulateCMF()
        datefrom = Request.QueryString("DateFrom")
        dateto = Request.QueryString("DateTo")
        campid = Request.QueryString("campid")
        QEID = Request.QueryString("QEID")
        calltype = Request.QueryString("calltype")
        errortype = Request.QueryString("errortype")
        cmfid = Request.QueryString("cmfid")
        Dim finaltable As New DataTable
        Try
            'lblcampaign1.NavigateUrl = "~/SummaryReportPerTeamWise.aspx?QEID=" & Request.QueryString("QEID") & "&cmfid=" & Request.QueryString("cmfid") & "&calltype=" & Request.QueryString("calltype") & "&errortype=" & Request.QueryString("errortype") & "&campid=" & Request.QueryString("campid") & "&SupervisorID=%&DateFrom=" & Request.QueryString("DateFrom") & "&DateTo=" & Request.QueryString("DateTo")
            Dim dt1 As DataTable
            ' Dim db1 As New DBAccess("qualitynew")
            Dim db1 As New DBAccess
            db1.slDataAdd("DateFrom", Request.QueryString("DateFrom"))
            db1.slDataAdd("DateTo", Request.QueryString("DateTo"))
            db1.slDataAdd("Agentid", Request.QueryString("Agentid"))
            db1.slDataAdd("SupervisorID", Request.QueryString("SupervisorID"))
            db1.slDataAdd("camp", Request.QueryString("campid"))
            db1.slDataAdd("inQAId", Request.QueryString("QEID"))
            db1.slDataAdd("inCallType", Request.QueryString("calltype"))
            db1.slDataAdd("inErrorType", Request.QueryString("errortype"))
            db1.slDataAdd("cmfid", Request.QueryString("cmfid"))
            dt1 = db1.ReturnTable("usp_QualityReport4QCScore_new", , True)
            db1 = Nothing
            Dim dt As DataTable

            ' Dim db As New DBAccess("qualitynew")
            Dim db As New DBAccess
            db.slDataAdd("DateFrom", Request.QueryString("DateFrom"))
            db.slDataAdd("DateTo", Request.QueryString("DateTo"))
            db.slDataAdd("camp", Request.QueryString("campid"))
            db.slDataAdd("Agentid", Request.QueryString("Agentid"))
            db.slDataAdd("SupervisorID", Request.QueryString("SupervisorID"))
            db.slDataAdd("inQAId", Request.QueryString("QEID"))
            db.slDataAdd("inCallType", Request.QueryString("calltype"))
            db.slDataAdd("inErrorType", Request.QueryString("errortype"))
            db.slDataAdd("cmfid", Request.QueryString("cmfid"))
            dt = db.ReturnTable("usp_QualitySummaryReport4_new", , True)
            db = Nothing

            dtnew = New DataTable

            dtnew.Columns.Add("SheetID")
            dtnew.Columns.Add("SheetDate")
            dtnew.Columns.Add("customerid")
            dtnew.Columns.Add("transid")
            dtnew.Columns.Add("cmfid")
            'For Creating Columns
            Dim dtsubcat As DataTable = dt.DefaultView.ToTable(True, New String() {"maincat", "subcat"})
            For i As Integer = 0 To dtsubcat.Rows.Count - 1
                dtnew.Columns.Add(i)
            Next
            For Each col As DataColumn In dt1.Columns
                If col.ColumnName = "SheetID" Or col.ColumnName = "SheetDate" Or col.ColumnName = "customerid" Or col.ColumnName = "transid" Or col.ColumnName = "cmfid" Then
                Else
                    dtnew.Columns.Add(col.ColumnName)
                End If
            Next
            'For Creating Rows
            For i As Integer = 0 To dt1.Rows.Count + 1
                Dim dr As DataRow = dtnew.NewRow
                dtnew.Rows.Add(dr)
            Next
            'For Adding Categories and Sub Categories Headers
            For j As Integer = 0 To dtsubcat.Rows.Count - 1
                For i As Integer = 0 To dtsubcat.Rows.Count - 1
                    dtnew.Rows(0).Item(i + 5) = dtsubcat.Rows(i).Item(0)
                    dtnew.Rows(1).Item(i + 5) = dtsubcat.Rows(i).Item(1)
                Next
            Next
            'For Adding Header
            dtnew.Columns.Remove("ParameterWiseScore%")
            dtnew.Columns.Add("ParameterWiseScore%")
            dtnew.Columns.Remove("ClientCallsMonitored")
            dtnew.Columns.Add("ClientCallsMonitored")
            dtnew.Columns.Remove("ClientNonFatalErrorCount")
            dtnew.Columns.Add("ClientNonFatalErrorCount")
            dtnew.Columns.Remove("ClientFatalErrorCount")
            dtnew.Columns.Add("ClientFatalErrorCount")
            dtnew.Columns.Remove("ClientNFAR%")
            dtnew.Columns.Add("ClientNFAR%")
            dtnew.Columns.Remove("ClientFAR%")
            dtnew.Columns.Add("ClientFAR%")
            dtnew.Columns.Remove("ClientParameterWiseScore%")
            dtnew.Columns.Add("ClientParameterWiseScore%")
            dtnew.Columns.Add("ViewClientSheet")
            dtnew.Rows(0).Item("SheetID") = "Sheet ID"
            dtnew.Rows(0).Item("SheetDate") = "Sheet Date"
            dtnew.Rows(0).Item("customerid") = "Customer ID"
            dtnew.Rows(0).Item("transid") = "Transaction ID"
            dtnew.Rows(0).Item("cmfid") = "CMF ID"
            'dtnew.Rows(0).Item("callsmonitored") = "Calls Monitored"
            dtnew.Rows(0).Item("callsmonitored") = "Monitored"
            dtnew.Rows(0).Item("NonFatalErrorCount") = "Non Fatal Error Count"
            dtnew.Rows(0).Item("FatalErrorCount") = "Fatal Error Count"
            dtnew.Rows(0).Item("NFAR%") = "NFAR%"
            dtnew.Rows(0).Item("FAR%") = "FAR%"
            dtnew.Rows(0).Item("TotalParamWiseScore") = "TotalParamWiseScore"
            dtnew.Rows(0).Item("CollectedParamWiseScore") = "CollectedParamWiseScore"
            dtnew.Rows(0).Item("ParameterWiseScore%") = "OverAll Score%"
            'For Client
            dtnew.Rows(0).Item("ClientCallsMonitored") = "Client Monitored"
            dtnew.Rows(0).Item("ClientNonFatalErrorCount") = "Client Non Fatal Error Count"
            dtnew.Rows(0).Item("ClientFatalErrorCount") = "Client Fatal Error Count"
            dtnew.Rows(0).Item("ClientNonFatalQCount") = "ClientNonFatalQCount"
            dtnew.Rows(0).Item("ClientNFAR%") = "Client NFAR%"
            dtnew.Rows(0).Item("ClientFAR%") = "Client FAR%"
            dtnew.Rows(0).Item("ClientTotalParamWiseScore") = "Client TotalParamWiseScore"
            dtnew.Rows(0).Item("ClientCollectedParamWiseScore") = "Client CollectedParamWiseScore"
            dtnew.Rows(0).Item("ClientParameterWiseScore%") = "Client OverAll Score%"
            'For Adding Data for under Categories and Sub Categories and other Headers
            For row As Integer = 0 To dt1.Rows.Count - 1
                Dim data() As DataRow = dt.Select("SheetID='" & dt1.Rows(row)("SheetID") & "'")
                For i As Integer = 0 To data.Length - 1
                    For c As Integer = 5 To dtnew.Columns.Count - 1
                        If Not IsDBNull(dtnew.Rows(0).Item(c)) And Not IsDBNull(dtnew.Rows(1).Item(c)) Then
                            If data(i).Item("maincat") = dtnew.Rows(0).Item(c) And data(i).Item("subcat") = dtnew.Rows(1).Item(c) Then
                                dtnew.Rows(row + 2).Item(c) = data(i).Item("TotalErrorCount")
                            End If
                        End If
                    Next
                Next
                dtnew.Rows(row + 2).Item("SheetID") = dt1.Rows(row).Item("SheetID") '"Sheetid=" & dt1.Rows(row).Item("SheetID") & "&lid=" & dt1.Rows(row).Item("customerid") & "&transid=" & dt1.Rows(row).Item("Transid") & "&CMFID=" & dt1.Rows(row).Item("cmfid") & "&Agentid=" & Request.QueryString("Agentid")
                dtnew.Rows(row + 2).Item("SheetDate") = dt1.Rows(row).Item("SheetDate")
                dtnew.Rows(row + 2).Item("Customerid") = dt1.Rows(row).Item("customerid")
                dtnew.Rows(row + 2).Item("Transid") = dt1.Rows(row).Item("Transid")
                dtnew.Rows(row + 2).Item("CMFID") = dt1.Rows(row).Item("cmfid")
                dtnew.Rows(row + 2).Item("callsmonitored") = dt1.Rows(row).Item("callsmonitored")
                dtnew.Rows(row + 2).Item("NonFatalErrorCount") = dt1.Rows(row).Item("NonFatalErrorCount")
                dtnew.Rows(row + 2).Item("FatalErrorCount") = dt1.Rows(row).Item("FatalErrorCount")
                dtnew.Rows(row + 2).Item("NFAR%") = dt1.Rows(row).Item("NFAR%")
                dtnew.Rows(row + 2).Item("FAR%") = dt1.Rows(row).Item("FAR%")
                dtnew.Rows(row + 2).Item("TotalParamWiseScore") = dt1.Rows(row).Item("TotalParamWiseScore")
                dtnew.Rows(row + 2).Item("CollectedParamWiseScore") = dt1.Rows(row).Item("CollectedParamWiseScore")
                dtnew.Rows(row + 2).Item("ParameterWiseScore%") = dt1.Rows(row).Item("ParameterWiseScore%")
                'For Client
                dtnew.Rows(row + 2).Item("ClientCallsMonitored") = dt1.Rows(row).Item("ClientCallsMonitored")
                dtnew.Rows(row + 2).Item("ClientNonFatalErrorCount") = dt1.Rows(row).Item("ClientNonFatalErrorCount")
                dtnew.Rows(row + 2).Item("ClientFatalErrorCount") = dt1.Rows(row).Item("ClientFatalErrorCount")
                dtnew.Rows(row + 2).Item("ClientNonFatalQCount") = dt1.Rows(row).Item("ClientNonFatalQCount")
                dtnew.Rows(row + 2).Item("ClientNFAR%") = dt1.Rows(row).Item("ClientNFAR%")
                dtnew.Rows(row + 2).Item("ClientFAR%") = dt1.Rows(row).Item("ClientFAR%")
                dtnew.Rows(row + 2).Item("ClientTotalParamWiseScore") = dt1.Rows(row).Item("ClientTotalParamWiseScore")
                dtnew.Rows(row + 2).Item("ClientCollectedParamWiseScore") = dt1.Rows(row).Item("ClientCollectedParamWiseScore")
                dtnew.Rows(row + 2).Item("ClientParameterWiseScore%") = dt1.Rows(row).Item("ClientParameterWiseScore%")

            Next
            campaigndata.DataSource = dtnew
            campaigndata.DataBind()

            'campaigndata.Columns()
        Catch ex As Exception
            lblerror.Text = ex.ToString
            lblerror.Visible = True
        End Try
    End Sub

    Private Sub PopulateCMF_32()
        datefrom = Request.QueryString("DateFrom")
        dateto = Request.QueryString("DateTo")
        campid = Request.QueryString("campid")
        QEID = Request.QueryString("QEID")
        calltype = Request.QueryString("calltype")
        errortype = Request.QueryString("errortype")
        cmfid = Request.QueryString("cmfid")
        Dim finaltable As New DataTable
        Try
            'lblcampaign1.NavigateUrl = "~/SummaryReportPerTeamWise.aspx?QEID=" & Request.QueryString("QEID") & "&cmfid=" & Request.QueryString("cmfid") & "&calltype=" & Request.QueryString("calltype") & "&errortype=" & Request.QueryString("errortype") & "&campid=" & Request.QueryString("campid") & "&SupervisorID=%&DateFrom=" & Request.QueryString("DateFrom") & "&DateTo=" & Request.QueryString("DateTo")
            Dim dt1 As DataTable
            ' Dim db1 As New DBAccess("qualitynew")
            Dim db1 As New DBAccess
            db1.slDataAdd("DateFrom", Request.QueryString("DateFrom"))
            db1.slDataAdd("DateTo", Request.QueryString("DateTo"))
            db1.slDataAdd("Agentid", Request.QueryString("Agentid"))
            db1.slDataAdd("SupervisorID", Request.QueryString("SupervisorID"))
            db1.slDataAdd("camp", Request.QueryString("campid"))
            db1.slDataAdd("inQAId", Request.QueryString("QEID"))
            db1.slDataAdd("inCallType", Request.QueryString("calltype"))
            db1.slDataAdd("inErrorType", Request.QueryString("errortype"))
            db1.slDataAdd("cmfid", Request.QueryString("cmfid"))
            dt1 = db1.ReturnTable("usp_QualityReport4QCScore_new", , True)
            db1 = Nothing
            Dim dt As DataTable

            ' Dim db As New DBAccess("qualitynew")
            Dim db As New DBAccess
            db.slDataAdd("DateFrom", Request.QueryString("DateFrom"))
            db.slDataAdd("DateTo", Request.QueryString("DateTo"))
            db.slDataAdd("camp", Request.QueryString("campid"))
            db.slDataAdd("Agentid", Request.QueryString("Agentid"))
            db.slDataAdd("SupervisorID", Request.QueryString("SupervisorID"))
            db.slDataAdd("inQAId", Request.QueryString("QEID"))
            db.slDataAdd("inCallType", Request.QueryString("calltype"))
            db.slDataAdd("inErrorType", Request.QueryString("errortype"))
            db.slDataAdd("cmfid", Request.QueryString("cmfid"))
            dt = db.ReturnTable("usp_QualitySummaryReport4_new", , True)
            db = Nothing

            dtnew = New DataTable

            dtnew.Columns.Add("SheetID")
            dtnew.Columns.Add("SheetDate")
            dtnew.Columns.Add("customerid")
            dtnew.Columns.Add("transid")
            dtnew.Columns.Add("cmfid")
            dtnew.Columns.Add("BuildingNo_Class")


            'For Creating Columns
            Dim dtsubcat As DataTable = dt.DefaultView.ToTable(True, New String() {"maincat", "subcat"})
            For i As Integer = 0 To dtsubcat.Rows.Count - 1
                dtnew.Columns.Add(i)
            Next
            For Each col As DataColumn In dt1.Columns
                If col.ColumnName = "SheetID" Or col.ColumnName = "SheetDate" Or col.ColumnName = "customerid" Or col.ColumnName = "transid" Or col.ColumnName = "cmfid" Or col.ColumnName = "BuildingNo_Class" Then
                Else
                    dtnew.Columns.Add(col.ColumnName)
                End If
            Next
            'For Creating Rows
            For i As Integer = 0 To dt1.Rows.Count + 1
                Dim dr As DataRow = dtnew.NewRow
                dtnew.Rows.Add(dr)
            Next
            'For Adding Categories and Sub Categories Headers
            Dim st As String
            For j As Integer = 0 To dtsubcat.Rows.Count - 1
                For i As Integer = 0 To dtsubcat.Rows.Count - 1
                    dtnew.Rows(0).Item(i + 5) = dtsubcat.Rows(i).Item(0)
                    If dtsubcat.Rows(i).Item(1) = "General Information Error (%)" Then
                        st = "[Building \ Class]"
                    Else
                        st = dtsubcat.Rows(i).Item(1)
                    End If
                    dtnew.Rows(1).Item(i + 5) = st
                Next
            Next
            'For Adding Header
            dtnew.Columns.Remove("ParameterWiseScore%")
            dtnew.Columns.Add("ParameterWiseScore%")
            dtnew.Columns.Remove("ClientCallsMonitored")
            dtnew.Columns.Add("ClientCallsMonitored")
            dtnew.Columns.Remove("ClientNonFatalErrorCount")
            dtnew.Columns.Add("ClientNonFatalErrorCount")
            dtnew.Columns.Remove("ClientFatalErrorCount")
            dtnew.Columns.Add("ClientFatalErrorCount")
            dtnew.Columns.Remove("ClientNFAR%")
            dtnew.Columns.Add("ClientNFAR%")
            dtnew.Columns.Remove("ClientFAR%")
            dtnew.Columns.Add("ClientFAR%")
            dtnew.Columns.Remove("ClientParameterWiseScore%")
            dtnew.Columns.Add("ClientParameterWiseScore%")
            dtnew.Columns.Add("ViewClientSheet")
            dtnew.Rows(0).Item("SheetID") = "Sheet ID"
            dtnew.Rows(0).Item("SheetDate") = "Sheet Date"
            dtnew.Rows(0).Item("customerid") = "Customer ID"

            dtnew.Rows(0).Item("BuildingNo_Class") = "Building No /Class"
            'dtnew.Rows(0).Item("class") = "Class"

            dtnew.Rows(0).Item("transid") = "Transaction ID"
            dtnew.Rows(0).Item("cmfid") = "CMF ID"
        'dtnew.Rows(0).Item("callsmonitored") = "Calls Monitored"
            dtnew.Rows(0).Item("callsmonitored") = "Monitored"
            dtnew.Rows(0).Item("NonFatalErrorCount") = "Non Fatal Error Count"
            dtnew.Rows(0).Item("FatalErrorCount") = "Fatal Error Count"
            dtnew.Rows(0).Item("NFAR%") = "NFAR%"
            dtnew.Rows(0).Item("FAR%") = "FAR%"
            dtnew.Rows(0).Item("TotalParamWiseScore") = "TotalParamWiseScore"
            dtnew.Rows(0).Item("CollectedParamWiseScore") = "CollectedParamWiseScore"
            dtnew.Rows(0).Item("ParameterWiseScore%") = "OverAll Score%"
        'For Client
            dtnew.Rows(0).Item("ClientCallsMonitored") = "Client Monitored"
            dtnew.Rows(0).Item("ClientNonFatalErrorCount") = "Client Non Fatal Error Count"
            dtnew.Rows(0).Item("ClientFatalErrorCount") = "Client Fatal Error Count"
            dtnew.Rows(0).Item("ClientNonFatalQCount") = "ClientNonFatalQCount"
            dtnew.Rows(0).Item("ClientNFAR%") = "Client NFAR%"
            dtnew.Rows(0).Item("ClientFAR%") = "Client FAR%"
            dtnew.Rows(0).Item("ClientTotalParamWiseScore") = "Client TotalParamWiseScore"
            dtnew.Rows(0).Item("ClientCollectedParamWiseScore") = "Client CollectedParamWiseScore"
            dtnew.Rows(0).Item("ClientParameterWiseScore%") = "Client OverAll Score%"
        'For Adding Data for under Categories and Sub Categories and other Headers
            For row As Integer = 0 To dt1.Rows.Count - 1
        Dim data() As DataRow = dt.Select("SheetID='" & dt1.Rows(row)("SheetID") & "'")
                For i As Integer = 0 To data.Length - 1
                    For c As Integer = 5 To dtnew.Columns.Count - 1
                        If Not IsDBNull(dtnew.Rows(0).Item(c)) And Not IsDBNull(dtnew.Rows(1).Item(c)) Then
                            If data(i).Item("maincat") = dtnew.Rows(0).Item(c) And data(i).Item("subcat") = dtnew.Rows(1).Item(c) Then
                                dtnew.Rows(row + 2).Item(c) = data(i).Item("TotalErrorCount")
                            End If
                        End If
                    Next
                Next
                dtnew.Rows(row + 2).Item("SheetID") = dt1.Rows(row).Item("SheetID") '"Sheetid=" & dt1.Rows(row).Item("SheetID") & "&lid=" & dt1.Rows(row).Item("customerid") & "&transid=" & dt1.Rows(row).Item("Transid") & "&CMFID=" & dt1.Rows(row).Item("cmfid") & "&Agentid=" & Request.QueryString("Agentid")
                dtnew.Rows(row + 2).Item("SheetDate") = dt1.Rows(row).Item("SheetDate")
                dtnew.Rows(row + 2).Item("Customerid") = dt1.Rows(row).Item("customerid")

                'dtnew.Rows(row + 1).Item("BuildingNo_Class") = ""
                dtnew.Rows(row + 2).Item("BuildingNo_Class") = dt1.Rows(row).Item("BuildingNo") + " \ " + dt1.Rows(row).Item("Class")
                'dtnew.Rows(row + 2).Item("Class") = dt1.Rows(row).Item("Class")

                dtnew.Rows(row + 2).Item("Transid") = dt1.Rows(row).Item("Transid")
                dtnew.Rows(row + 2).Item("CMFID") = dt1.Rows(row).Item("cmfid")
                dtnew.Rows(row + 2).Item("callsmonitored") = dt1.Rows(row).Item("callsmonitored")
                dtnew.Rows(row + 2).Item("NonFatalErrorCount") = dt1.Rows(row).Item("NonFatalErrorCount")
                dtnew.Rows(row + 2).Item("FatalErrorCount") = dt1.Rows(row).Item("FatalErrorCount")
                dtnew.Rows(row + 2).Item("NFAR%") = dt1.Rows(row).Item("NFAR%")
                dtnew.Rows(row + 2).Item("FAR%") = dt1.Rows(row).Item("FAR%")
                dtnew.Rows(row + 2).Item("TotalParamWiseScore") = dt1.Rows(row).Item("TotalParamWiseScore")
                dtnew.Rows(row + 2).Item("CollectedParamWiseScore") = dt1.Rows(row).Item("CollectedParamWiseScore")
                dtnew.Rows(row + 2).Item("ParameterWiseScore%") = dt1.Rows(row).Item("ParameterWiseScore%")
        'For Client
                dtnew.Rows(row + 2).Item("ClientCallsMonitored") = dt1.Rows(row).Item("ClientCallsMonitored")
                dtnew.Rows(row + 2).Item("ClientNonFatalErrorCount") = dt1.Rows(row).Item("ClientNonFatalErrorCount")
                dtnew.Rows(row + 2).Item("ClientFatalErrorCount") = dt1.Rows(row).Item("ClientFatalErrorCount")
                dtnew.Rows(row + 2).Item("ClientNonFatalQCount") = dt1.Rows(row).Item("ClientNonFatalQCount")
                dtnew.Rows(row + 2).Item("ClientNFAR%") = dt1.Rows(row).Item("ClientNFAR%")
                dtnew.Rows(row + 2).Item("ClientFAR%") = dt1.Rows(row).Item("ClientFAR%")
                dtnew.Rows(row + 2).Item("ClientTotalParamWiseScore") = dt1.Rows(row).Item("ClientTotalParamWiseScore")
                dtnew.Rows(row + 2).Item("ClientCollectedParamWiseScore") = dt1.Rows(row).Item("ClientCollectedParamWiseScore")
                dtnew.Rows(row + 2).Item("ClientParameterWiseScore%") = dt1.Rows(row).Item("ClientParameterWiseScore%")

            Next
            campaigndata.DataSource = dtnew
            campaigndata.DataBind()

        'campaigndata.Columns()
        Catch ex As Exception
            lblerror.Text = ex.ToString
            lblerror.Visible = True
        End Try
    End Sub

    Private Sub Populatedata_32()

        datefrom = SubSummaryReportFilters1.DateFrom
        dateto = SubSummaryReportFilters1.DateTO
        campid = Request.QueryString("campid")
        QEID = SubSummaryReportFilters1.Qe
        calltype = SubSummaryReportFilters1.calltype
        errortype = SubSummaryReportFilters1.Errortype
        cmfid = SubSummaryReportFilters1.cmfid
        Dim finaltable As New DataTable
        Try
            'lblcampaign1.NavigateUrl = "~/SummaryReportPerTeamWise.aspx?QEID=" & Request.QueryString("QEID") & "&cmfid=" & Request.QueryString("cmfid") & "&calltype=" & Request.QueryString("calltype") & "&errortype=" & Request.QueryString("errortype") & "&campid=" & Request.QueryString("campid") & "&SupervisorID=%&DateFrom=" & Request.QueryString("DateFrom") & "&DateTo=" & Request.QueryString("DateTo")
            Dim dt1 As DataTable
            'Dim db1 As New DBAccess("qualitynew")
            Dim db1 As New DBAccess

            db1.slDataAdd("DateFrom", SubSummaryReportFilters1.DateFrom)
            db1.slDataAdd("DateTo", SubSummaryReportFilters1.DateTO)
            db1.slDataAdd("Agentid", Request.QueryString("Agentid"))
            db1.slDataAdd("SupervisorID", Request.QueryString("SupervisorID"))
            db1.slDataAdd("camp", Request.QueryString("campid"))
            db1.slDataAdd("inQAId", SubSummaryReportFilters1.Qe)
            db1.slDataAdd("inCallType", SubSummaryReportFilters1.calltype)
            db1.slDataAdd("inErrorType", SubSummaryReportFilters1.Errortype)
            db1.slDataAdd("cmfid", SubSummaryReportFilters1.cmfid)
            dt1 = db1.ReturnTable("usp_QualityReport4QCScore_new", , True)
            db1 = Nothing
            Dim dt As DataTable

            ' Dim db As New DBAccess("qualitynew")
            Dim db As New DBAccess
            db.slDataAdd("DateFrom", SubSummaryReportFilters1.DateFrom)
            db.slDataAdd("DateTo", SubSummaryReportFilters1.DateTO)
            db.slDataAdd("camp", Request.QueryString("campid"))
            db.slDataAdd("Agentid", Request.QueryString("Agentid"))
            db.slDataAdd("SupervisorID", Request.QueryString("SupervisorID"))
            db.slDataAdd("inQAId", SubSummaryReportFilters1.Qe)
            db.slDataAdd("inCallType", SubSummaryReportFilters1.calltype)
            db.slDataAdd("inErrorType", SubSummaryReportFilters1.Errortype)
            db.slDataAdd("cmfid", SubSummaryReportFilters1.cmfid)
            dt = db.ReturnTable("usp_QualitySummaryReport4_new", , True)
            db = Nothing

            Dim dtnew As New DataTable

            dtnew.Columns.Add("SheetID")
            dtnew.Columns.Add("SheetDate")
            dtnew.Columns.Add("customerid")
            dtnew.Columns.Add("transid")
            dtnew.Columns.Add("cmfid")
            'dtnew.Columns.Add("BuildingNo_Class")
            'dtnew.Columns.Add("Class")
            'For Creating Columns
            Dim dtsubcat As DataTable = dt.DefaultView.ToTable(True, New String() {"maincat", "subcat"})
            For i As Integer = 0 To dtsubcat.Rows.Count - 1
                dtnew.Columns.Add(i)
            Next
            For Each col As DataColumn In dt1.Columns
                If col.ColumnName = "SheetID" Or col.ColumnName = "SheetDate" Or col.ColumnName = "customerid" Or col.ColumnName = "transid" Or col.ColumnName = "cmfid" Then
                Else
                    dtnew.Columns.Add(col.ColumnName)
                End If
            Next
            'For Creating Rows
            For i As Integer = 0 To dt1.Rows.Count + 1
                Dim dr As DataRow = dtnew.NewRow
                dtnew.Rows.Add(dr)
            Next
            'For Adding Categories and Sub Categories Headers
            For j As Integer = 0 To dtsubcat.Rows.Count - 1
                For i As Integer = 0 To dtsubcat.Rows.Count - 1
                    dtnew.Rows(0).Item(i + 5) = dtsubcat.Rows(i).Item(0)
                    dtnew.Rows(1).Item(i + 5) = dtsubcat.Rows(i).Item(1)
                Next
            Next
            'For Adding Header
            dtnew.Columns.Remove("ParameterWiseScore%")
            dtnew.Columns.Add("ParameterWiseScore%")
            dtnew.Columns.Remove("ClientCallsMonitored")
            dtnew.Columns.Add("ClientCallsMonitored")
            dtnew.Columns.Remove("ClientNonFatalErrorCount")
            dtnew.Columns.Add("ClientNonFatalErrorCount")
            dtnew.Columns.Remove("ClientFatalErrorCount")
            dtnew.Columns.Add("ClientFatalErrorCount")
            dtnew.Columns.Remove("ClientNFAR%")
            dtnew.Columns.Add("ClientNFAR%")
            dtnew.Columns.Remove("ClientFAR%")
            dtnew.Columns.Add("ClientFAR%")
            dtnew.Columns.Remove("ClientParameterWiseScore%")
            dtnew.Columns.Add("ClientParameterWiseScore%")
            dtnew.Columns.Add("ViewClientSheet")
            dtnew.Rows(0).Item("SheetID") = "Sheet ID"
            dtnew.Rows(0).Item("SheetDate") = "Sheet Date"
            dtnew.Rows(0).Item("customerid") = "Customer ID"

            'dtnew.Rows(0).Item("BuildingNo") = "Building No \ Class"
            'dtnew.Rows(0).Item("Class") = "Class"

            dtnew.Rows(0).Item("transid") = "Transaction ID"
            dtnew.Rows(0).Item("cmfid") = "CMF ID"
            'dtnew.Rows(0).Item("callsmonitored") = "Calls Monitored"
            dtnew.Rows(0).Item("callsmonitored") = "Monitored"
            dtnew.Rows(0).Item("NonFatalErrorCount") = "Non Fatal Error Count"
            dtnew.Rows(0).Item("FatalErrorCount") = "Fatal Error Count"
            dtnew.Rows(0).Item("NFAR%") = "NFAR%"
            dtnew.Rows(0).Item("FAR%") = "FAR%"
            dtnew.Rows(0).Item("TotalParamWiseScore") = "TotalParamWiseScore"
            dtnew.Rows(0).Item("CollectedParamWiseScore") = "CollectedParamWiseScore"
            dtnew.Rows(0).Item("ParameterWiseScore%") = "OverAll Score%"
            'For Client
            dtnew.Rows(0).Item("ClientCallsMonitored") = "Client Monitored"
            dtnew.Rows(0).Item("ClientNonFatalErrorCount") = "Client Non Fatal Error Count"
            dtnew.Rows(0).Item("ClientFatalErrorCount") = "Client Fatal Error Count"
            dtnew.Rows(0).Item("ClientNonFatalQCount") = "ClientNonFatalQCount"
            dtnew.Rows(0).Item("ClientNFAR%") = "Client NFAR%"
            dtnew.Rows(0).Item("ClientFAR%") = "Client FAR%"
            dtnew.Rows(0).Item("ClientTotalParamWiseScore") = "Client TotalParamWiseScore"
            dtnew.Rows(0).Item("ClientCollectedParamWiseScore") = "Client CollectedParamWiseScore"
            dtnew.Rows(0).Item("ClientParameterWiseScore%") = "Client OverAll Score%"
            'For Adding Data for under Categories and Sub Categories and other Headers
            For row As Integer = 0 To dt1.Rows.Count - 1
                Dim data() As DataRow = dt.Select("SheetID='" & dt1.Rows(row)("SheetID") & "'")
                For i As Integer = 0 To data.Length - 1
                    For c As Integer = 5 To dtnew.Columns.Count - 1
                        If Not IsDBNull(dtnew.Rows(0).Item(c)) And Not IsDBNull(dtnew.Rows(1).Item(c)) Then
                            If data(i).Item("maincat") = dtnew.Rows(0).Item(c) And data(i).Item("subcat") = dtnew.Rows(1).Item(c) Then
                                dtnew.Rows(row + 2).Item(c) = data(i).Item("TotalErrorCount")
                            End If
                        End If
                    Next
                Next
                dtnew.Rows(row + 2).Item("SheetID") = dt1.Rows(row).Item("SheetID") '"Sheetid=" & dt1.Rows(row).Item("SheetID") & "&lid=" & dt1.Rows(row).Item("customerid") & "&transid=" & dt1.Rows(row).Item("Transid") & "&CMFID=" & dt1.Rows(row).Item("cmfid") & "&Agentid=" & Request.QueryString("Agentid")
                dtnew.Rows(row + 2).Item("SheetDate") = dt1.Rows(row).Item("SheetDate")
                dtnew.Rows(row + 2).Item("Customerid") = dt1.Rows(row).Item("customerid")

                '  dtnew.Rows(row + 2).Item("BuildingNo_Class") = dt1.Rows(row).Item("BuildingNo") + " \ " + dt1.Rows(row).Item("Class")
                'dtnew.Rows(row + 2).Item("Class") = dt1.Rows(row).Item("Class")

                dtnew.Rows(row + 2).Item("Transid") = dt1.Rows(row).Item("Transid")
                dtnew.Rows(row + 2).Item("CMFID") = dt1.Rows(row).Item("cmfid")
                dtnew.Rows(row + 2).Item("callsmonitored") = dt1.Rows(row).Item("callsmonitored")
                dtnew.Rows(row + 2).Item("NonFatalErrorCount") = dt1.Rows(row).Item("NonFatalErrorCount")
                dtnew.Rows(row + 2).Item("FatalErrorCount") = dt1.Rows(row).Item("FatalErrorCount")
                dtnew.Rows(row + 2).Item("NFAR%") = dt1.Rows(row).Item("NFAR%")
                dtnew.Rows(row + 2).Item("FAR%") = dt1.Rows(row).Item("FAR%")
                dtnew.Rows(row + 2).Item("TotalParamWiseScore") = dt1.Rows(row).Item("TotalParamWiseScore")
                dtnew.Rows(row + 2).Item("CollectedParamWiseScore") = dt1.Rows(row).Item("CollectedParamWiseScore")
                dtnew.Rows(row + 2).Item("ParameterWiseScore%") = dt1.Rows(row).Item("ParameterWiseScore%")
                'For Client
                dtnew.Rows(row + 2).Item("ClientCallsMonitored") = dt1.Rows(row).Item("ClientCallsMonitored")
                dtnew.Rows(row + 2).Item("ClientNonFatalErrorCount") = dt1.Rows(row).Item("ClientNonFatalErrorCount")
                dtnew.Rows(row + 2).Item("ClientFatalErrorCount") = dt1.Rows(row).Item("ClientFatalErrorCount")
                dtnew.Rows(row + 2).Item("ClientNonFatalQCount") = dt1.Rows(row).Item("ClientNonFatalQCount")
                dtnew.Rows(row + 2).Item("ClientNFAR%") = dt1.Rows(row).Item("ClientNFAR%")
                dtnew.Rows(row + 2).Item("ClientFAR%") = dt1.Rows(row).Item("ClientFAR%")
                dtnew.Rows(row + 2).Item("ClientTotalParamWiseScore") = dt1.Rows(row).Item("ClientTotalParamWiseScore")
                dtnew.Rows(row + 2).Item("ClientCollectedParamWiseScore") = dt1.Rows(row).Item("ClientCollectedParamWiseScore")
                dtnew.Rows(row + 2).Item("ClientParameterWiseScore%") = dt1.Rows(row).Item("ClientParameterWiseScore%")

            Next
            campaigndata.DataSource = dtnew
            campaigndata.DataBind()

        Catch ex As Exception
            lblerror.Text = ex.ToString
            lblerror.Visible = True
        End Try
    End Sub

        Private Sub Populatedata()

            datefrom = SubSummaryReportFilters1.DateFrom
            dateto = SubSummaryReportFilters1.DateTO
            campid = Request.QueryString("campid")
            QEID = SubSummaryReportFilters1.Qe
            calltype = SubSummaryReportFilters1.calltype
            errortype = SubSummaryReportFilters1.Errortype
            cmfid = SubSummaryReportFilters1.cmfid
            Dim finaltable As New DataTable
            Try
                'lblcampaign1.NavigateUrl = "~/SummaryReportPerTeamWise.aspx?QEID=" & Request.QueryString("QEID") & "&cmfid=" & Request.QueryString("cmfid") & "&calltype=" & Request.QueryString("calltype") & "&errortype=" & Request.QueryString("errortype") & "&campid=" & Request.QueryString("campid") & "&SupervisorID=%&DateFrom=" & Request.QueryString("DateFrom") & "&DateTo=" & Request.QueryString("DateTo")
                Dim dt1 As DataTable
                'Dim db1 As New DBAccess("qualitynew")
                Dim db1 As New DBAccess

                db1.slDataAdd("DateFrom", SubSummaryReportFilters1.DateFrom)
                db1.slDataAdd("DateTo", SubSummaryReportFilters1.DateTO)
                db1.slDataAdd("Agentid", Request.QueryString("Agentid"))
                db1.slDataAdd("SupervisorID", Request.QueryString("SupervisorID"))
                db1.slDataAdd("camp", Request.QueryString("campid"))
                db1.slDataAdd("inQAId", SubSummaryReportFilters1.Qe)
                db1.slDataAdd("inCallType", SubSummaryReportFilters1.calltype)
                db1.slDataAdd("inErrorType", SubSummaryReportFilters1.Errortype)
                db1.slDataAdd("cmfid", SubSummaryReportFilters1.cmfid)
                dt1 = db1.ReturnTable("usp_QualityReport4QCScore_new", , True)
                db1 = Nothing
                Dim dt As DataTable

                ' Dim db As New DBAccess("qualitynew")
                Dim db As New DBAccess
                db.slDataAdd("DateFrom", SubSummaryReportFilters1.DateFrom)
                db.slDataAdd("DateTo", SubSummaryReportFilters1.DateTO)
                db.slDataAdd("camp", Request.QueryString("campid"))
                db.slDataAdd("Agentid", Request.QueryString("Agentid"))
                db.slDataAdd("SupervisorID", Request.QueryString("SupervisorID"))
                db.slDataAdd("inQAId", SubSummaryReportFilters1.Qe)
                db.slDataAdd("inCallType", SubSummaryReportFilters1.calltype)
                db.slDataAdd("inErrorType", SubSummaryReportFilters1.Errortype)
                db.slDataAdd("cmfid", SubSummaryReportFilters1.cmfid)
                dt = db.ReturnTable("usp_QualitySummaryReport4_new", , True)
                db = Nothing

                Dim dtnew As New DataTable

                dtnew.Columns.Add("SheetID")
                dtnew.Columns.Add("SheetDate")
                dtnew.Columns.Add("customerid")
                dtnew.Columns.Add("transid")
                dtnew.Columns.Add("cmfid")
                'For Creating Columns
                Dim dtsubcat As DataTable = dt.DefaultView.ToTable(True, New String() {"maincat", "subcat"})
                For i As Integer = 0 To dtsubcat.Rows.Count - 1
                    dtnew.Columns.Add(i)
                Next
                For Each col As DataColumn In dt1.Columns
                    If col.ColumnName = "SheetID" Or col.ColumnName = "SheetDate" Or col.ColumnName = "customerid" Or col.ColumnName = "transid" Or col.ColumnName = "cmfid" Then
                    Else
                        dtnew.Columns.Add(col.ColumnName)
                    End If
                Next
                'For Creating Rows
                For i As Integer = 0 To dt1.Rows.Count + 1
                    Dim dr As DataRow = dtnew.NewRow
                    dtnew.Rows.Add(dr)
                Next
                'For Adding Categories and Sub Categories Headers
                For j As Integer = 0 To dtsubcat.Rows.Count - 1
                    For i As Integer = 0 To dtsubcat.Rows.Count - 1
                        dtnew.Rows(0).Item(i + 5) = dtsubcat.Rows(i).Item(0)
                        dtnew.Rows(1).Item(i + 5) = dtsubcat.Rows(i).Item(1)
                    Next
                Next
                'For Adding Header
                dtnew.Columns.Remove("ParameterWiseScore%")
                dtnew.Columns.Add("ParameterWiseScore%")
                dtnew.Columns.Remove("ClientCallsMonitored")
                dtnew.Columns.Add("ClientCallsMonitored")
                dtnew.Columns.Remove("ClientNonFatalErrorCount")
                dtnew.Columns.Add("ClientNonFatalErrorCount")
                dtnew.Columns.Remove("ClientFatalErrorCount")
                dtnew.Columns.Add("ClientFatalErrorCount")
                dtnew.Columns.Remove("ClientNFAR%")
                dtnew.Columns.Add("ClientNFAR%")
                dtnew.Columns.Remove("ClientFAR%")
                dtnew.Columns.Add("ClientFAR%")
                dtnew.Columns.Remove("ClientParameterWiseScore%")
                dtnew.Columns.Add("ClientParameterWiseScore%")
                dtnew.Columns.Add("ViewClientSheet")
                dtnew.Rows(0).Item("SheetID") = "Sheet ID"
                dtnew.Rows(0).Item("SheetDate") = "Sheet Date"
                dtnew.Rows(0).Item("customerid") = "Customer ID"
                dtnew.Rows(0).Item("transid") = "Transaction ID"
                dtnew.Rows(0).Item("cmfid") = "CMF ID"
                'dtnew.Rows(0).Item("callsmonitored") = "Calls Monitored"
                dtnew.Rows(0).Item("callsmonitored") = "Monitored"
                dtnew.Rows(0).Item("NonFatalErrorCount") = "Non Fatal Error Count"
                dtnew.Rows(0).Item("FatalErrorCount") = "Fatal Error Count"
                dtnew.Rows(0).Item("NFAR%") = "NFAR%"
                dtnew.Rows(0).Item("FAR%") = "FAR%"
                dtnew.Rows(0).Item("TotalParamWiseScore") = "TotalParamWiseScore"
                dtnew.Rows(0).Item("CollectedParamWiseScore") = "CollectedParamWiseScore"
                dtnew.Rows(0).Item("ParameterWiseScore%") = "OverAll Score%"
                'For Client
                dtnew.Rows(0).Item("ClientCallsMonitored") = "Client Monitored"
                dtnew.Rows(0).Item("ClientNonFatalErrorCount") = "Client Non Fatal Error Count"
                dtnew.Rows(0).Item("ClientFatalErrorCount") = "Client Fatal Error Count"
                dtnew.Rows(0).Item("ClientNonFatalQCount") = "ClientNonFatalQCount"
                dtnew.Rows(0).Item("ClientNFAR%") = "Client NFAR%"
                dtnew.Rows(0).Item("ClientFAR%") = "Client FAR%"
                dtnew.Rows(0).Item("ClientTotalParamWiseScore") = "Client TotalParamWiseScore"
                dtnew.Rows(0).Item("ClientCollectedParamWiseScore") = "Client CollectedParamWiseScore"
                dtnew.Rows(0).Item("ClientParameterWiseScore%") = "Client OverAll Score%"
                'For Adding Data for under Categories and Sub Categories and other Headers
                For row As Integer = 0 To dt1.Rows.Count - 1
                    Dim data() As DataRow = dt.Select("SheetID='" & dt1.Rows(row)("SheetID") & "'")
                    For i As Integer = 0 To data.Length - 1
                        For c As Integer = 5 To dtnew.Columns.Count - 1
                            If Not IsDBNull(dtnew.Rows(0).Item(c)) And Not IsDBNull(dtnew.Rows(1).Item(c)) Then
                                If data(i).Item("maincat") = dtnew.Rows(0).Item(c) And data(i).Item("subcat") = dtnew.Rows(1).Item(c) Then
                                    dtnew.Rows(row + 2).Item(c) = data(i).Item("TotalErrorCount")
                                End If
                            End If
                        Next
                    Next
                    dtnew.Rows(row + 2).Item("SheetID") = dt1.Rows(row).Item("SheetID") '"Sheetid=" & dt1.Rows(row).Item("SheetID") & "&lid=" & dt1.Rows(row).Item("customerid") & "&transid=" & dt1.Rows(row).Item("Transid") & "&CMFID=" & dt1.Rows(row).Item("cmfid") & "&Agentid=" & Request.QueryString("Agentid")
                    dtnew.Rows(row + 2).Item("SheetDate") = dt1.Rows(row).Item("SheetDate")
                    dtnew.Rows(row + 2).Item("Customerid") = dt1.Rows(row).Item("customerid")
                    dtnew.Rows(row + 2).Item("Transid") = dt1.Rows(row).Item("Transid")
                    dtnew.Rows(row + 2).Item("CMFID") = dt1.Rows(row).Item("cmfid")
                    dtnew.Rows(row + 2).Item("callsmonitored") = dt1.Rows(row).Item("callsmonitored")
                    dtnew.Rows(row + 2).Item("NonFatalErrorCount") = dt1.Rows(row).Item("NonFatalErrorCount")
                    dtnew.Rows(row + 2).Item("FatalErrorCount") = dt1.Rows(row).Item("FatalErrorCount")
                    dtnew.Rows(row + 2).Item("NFAR%") = dt1.Rows(row).Item("NFAR%")
                    dtnew.Rows(row + 2).Item("FAR%") = dt1.Rows(row).Item("FAR%")
                    dtnew.Rows(row + 2).Item("TotalParamWiseScore") = dt1.Rows(row).Item("TotalParamWiseScore")
                    dtnew.Rows(row + 2).Item("CollectedParamWiseScore") = dt1.Rows(row).Item("CollectedParamWiseScore")
                    dtnew.Rows(row + 2).Item("ParameterWiseScore%") = dt1.Rows(row).Item("ParameterWiseScore%")
                    'For Client
                    dtnew.Rows(row + 2).Item("ClientCallsMonitored") = dt1.Rows(row).Item("ClientCallsMonitored")
                    dtnew.Rows(row + 2).Item("ClientNonFatalErrorCount") = dt1.Rows(row).Item("ClientNonFatalErrorCount")
                    dtnew.Rows(row + 2).Item("ClientFatalErrorCount") = dt1.Rows(row).Item("ClientFatalErrorCount")
                    dtnew.Rows(row + 2).Item("ClientNonFatalQCount") = dt1.Rows(row).Item("ClientNonFatalQCount")
                    dtnew.Rows(row + 2).Item("ClientNFAR%") = dt1.Rows(row).Item("ClientNFAR%")
                    dtnew.Rows(row + 2).Item("ClientFAR%") = dt1.Rows(row).Item("ClientFAR%")
                    dtnew.Rows(row + 2).Item("ClientTotalParamWiseScore") = dt1.Rows(row).Item("ClientTotalParamWiseScore")
                    dtnew.Rows(row + 2).Item("ClientCollectedParamWiseScore") = dt1.Rows(row).Item("ClientCollectedParamWiseScore")
                    dtnew.Rows(row + 2).Item("ClientParameterWiseScore%") = dt1.Rows(row).Item("ClientParameterWiseScore%")

                Next
                campaigndata.DataSource = dtnew
                campaigndata.DataBind()

            Catch ex As Exception
                lblerror.Text = ex.ToString
                lblerror.Visible = True
            End Try
        End Sub
        Protected Sub dgdata_RowDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles campaigndata.RowDataBound
            Try
                Dim dgdata As GridView = sender
                Dim cell As TableCell
                'e.Row.Cells(5).Visible = False
                'e.Row.Cells(6).Visible = False
                'e.Row.Cells(7).Visible = False
                'e.Row.Cells(8).Visible = False
                If e.Row.RowType = DataControlRowType.DataRow Then
                    If e.Row.RowIndex = 0 Then
                        Dim previouscelltext As String = "", currentcelltext As String = ""
                        Dim startcolumn As Integer = -1, ctr As Integer = 0, ctrcolspan As Integer = 1
                    For Each cell In e.Row.Cells

                        If previouscelltext = cell.Text Then
                            If startcolumn = -1 Then
                                startcolumn = ctr - 1
                            End If
                            ctrcolspan += 1
                            cell.Visible = False
                        Else
                            If startcolumn <> -1 Then
                                e.Row.Cells(startcolumn).ColumnSpan = ctrcolspan
                            End If
                            startcolumn = -1
                            ctrcolspan = 1
                        End If
                        ctr += 1
                        previouscelltext = cell.Text
                        
                    Next
                        If startcolumn <> -1 Then
                            e.Row.Cells(startcolumn).ColumnSpan = ctrcolspan
                        End If
                        e.Row.Cells(0).Text = "SL No."
                    ElseIf e.Row.RowIndex = 1 Then
                        'e.Row.Cells(e.Row.Cells.Count - 2).ForeColor = Drawing.Color.Red
                        'e.Row.Cells(e.Row.Cells.Count - 4).ForeColor = Drawing.Color.Red

                    ElseIf e.Row.RowIndex >= 2 Then
                        e.Row.Font.Bold = False
                        'e.Row.Cells(e.Row.Cells.Count - 2).ForeColor = Drawing.Color.Red
                        If e.Row.Cells(e.Row.Cells.Count - 7).Text > 0 Then
                            Dim hyp As New HyperLink
                            hyp.NavigateUrl = "~/Quality/ClientCMF.aspx?Sheetid=" & e.Row.Cells(0).Text & "&lid=" & e.Row.Cells(2).Text & "&transid=" & e.Row.Cells(3).Text & "&CMFID=" & e.Row.Cells(4).Text & "&Agentid=" & Request.QueryString("Agentid") & "&Stage=CF&campid=" & Request.QueryString("campid")
                            hyp.Text = "View Client Sheet"
                            e.Row.Cells(e.Row.Cells.Count - 1).Controls.Add(hyp)

                        End If
                        Dim hy As New HyperLink
                        hy.Text = e.Row.Cells(1).Text
                        'hy.NavigateUrl = "~/NewCMF.aspx?QEID=" & Request.QueryString("QEID") & "&SupervisorID=" & Request.QueryString("SupervisorID") & "&cmfid=" & Request.QueryString("cmfid") & "&calltype=" & Request.QueryString("calltype") & "&errortype=" & Request.QueryString("errortype") & "&campid=" & Request.QueryString("campid") & "&Agentid=" & e.Row.Cells(0).Text & "&DateFrom=" & Request.QueryString("DateFrom") & "&DateTo=" & Request.QueryString("DateTo")
                        'hy.NavigateUrl = "~/NewCMF.aspx?" & e.Row.Cells(0).Text.Replace("amp;", "") & "&Stage=F&lid=" & e.Row.Cells(5).Text & "&transid=" & e.Row.Cells(6).Text & "&CMFID=" & e.Row.Cells(7).Text & "&Agentid=" & e.Row.Cells(8).Text & "&campid=" & Request.QueryString("campid")
                        'Session("Return") = "~/Quality/SummaryReportPerAgentWise.aspx?QEID=" & QEID & "&cmfid=" & cmfid & "&calltype=" & calltype & "&errortype=" & errortype & "&campid=" & Request.QueryString("campid") & "&SupervisorID=" & Request.QueryString("SupervisorID") & "&Agentid=" & Request.QueryString("Agentid") & "&AgentName=" & Request.QueryString("AgentName") & "&DateFrom=" & datefrom & "&DateTo=" & dateto
                        '   hy.NavigateUrl = "~/Quality/NewCMF.aspx?Sheetid=" & e.Row.Cells(0).Text & "&lid=" & e.Row.Cells(2).Text & "&transid=" & e.Row.Cells(3).Text & "&CMFID=" & e.Row.Cells(4).Text & "&Agentid=" & Request.QueryString("Agentid") & "&Stage=F&campid=" & Request.QueryString("campid")
                        hy.NavigateUrl = "~/Quality/CMFform.aspx?Sheetid=" & e.Row.Cells(0).Text & "&lid=" & e.Row.Cells(2).Text & "&transid=" & e.Row.Cells(3).Text & "&CMFID=" & e.Row.Cells(4).Text & "&BackCMFID=" & Request.QueryString("CMFID") & "&Agentid=" & Request.QueryString("Agentid") & "&Stage=F&Return=Report&campid=" & Request.QueryString("campid") & "&calltype=" & calltype & "&errortype=" & errortype & "&DateFrom=" & datefrom & "&DateTo=" & dateto & "&LoginUserID=" & AgentID & "&LoginUserName=" & Session("UserName") & "&QEID=" & QEID & "&SupervisorID=" & Request.QueryString("SupervisorID")

                        'hy.NavigateUrl = "~/NewCMF.aspx?QEID=" & Request.QueryString("QEID") & "&calltype=" & Request.QueryString("calltype") & "&errortype=" & Request.QueryString("errortype") & "&stage=F&campid=" & CampaignID & "&SheetiD=" & e.Row.Cells(0).Text & "&Stage=F"
                        e.Row.Cells(1).Controls.Add(hy)
                        e.Row.Cells(0).Text = e.Row.RowIndex - 1
                    End If
                    e.Row.Cells(e.Row.Cells.Count - 18).Visible = False
                    e.Row.Cells(e.Row.Cells.Count - 17).Visible = False
                    e.Row.Cells(e.Row.Cells.Count - 16).Visible = False
                    e.Row.Cells(e.Row.Cells.Count - 15).Visible = False
                    e.Row.Cells(e.Row.Cells.Count - 14).Visible = False
                    e.Row.Cells(e.Row.Cells.Count - 11).ForeColor = Drawing.Color.Red
                    e.Row.Cells(e.Row.Cells.Count - 9).ForeColor = Drawing.Color.Red
                    e.Row.Cells(e.Row.Cells.Count - 3).ForeColor = Drawing.Color.Red
                    e.Row.Cells(e.Row.Cells.Count - 5).ForeColor = Drawing.Color.Red
                End If
            Catch ex As Exception
                lblerror.Text = ex.ToString
                lblerror.Visible = True
            End Try
        End Sub
    End Class
