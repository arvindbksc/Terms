﻿Imports com.nss.DBAccess
Imports System.Data
Partial Class Quality_QuizResults
    Inherits System.Web.UI.Page
    Dim dt As New DataTable
    Public dtData As New DataTable
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            BindProcess()
            FillMonthYear()
            Initiate()
        End If
    End Sub

#Region "Load Data"
    Private Sub BindProcess()
        lblMsg.Text = ""
        Dim db As New DBAccess
        dt = New DataTable
        'dt = db.ReturnTable("SELECT A.Name,A.CampaignID  FROM tbl_Config_Campaigns  A INNER join  tbl_Data_UserRights B ON A.CampaignID=B.CampaignID and A.Active=1 where B.AgentId='" & Session("AgentID") & "'", False)
        db.slDataAdd("Agentid", Session("AgentID"))
        dt = db.ReturnTable("[usp_MyCampaigns]", , True)
        db = Nothing
        cboCampaigns.DataTextField = "Name"
        cboCampaigns.DataValueField = "CampaignId"
        cboCampaigns.DataSource = dt
        cboCampaigns.DataBind()
    End Sub
    Private Sub FillMonthYear()
        For ictr = 1 To 12
            cboMonth.Items.Add(New ListItem(MonthName(ictr), ictr))
        Next

        cboMonth.SelectedIndex = cboMonth.Items.IndexOf(cboMonth.Items.FindByValue(DateTime.Now.Month))
        For ictr = DateTime.Now.Year To 2017 Step -1
            cboYear.Items.Add(New ListItem(ictr, ictr))
        Next
        cboYear.SelectedIndex = cboYear.Items.IndexOf(cboYear.Items.FindByValue(DateTime.Now.Year))
    End Sub
#End Region

#Region "Initiate"
    Private Sub Initiate()
        Dim dt As New DataTable
        dt = BindExistingData()
        If dt.Rows.Count <= 0 Then
            Dim dtrow As DataRow
            GridView1.EditIndex = -1
            
            dtrow = dt.NewRow
            dtrow("CampaignID") = 0
            dtrow("Month") = 0
            dtrow("Year") = 0
            dtrow("TotalTM") = 0
            dtrow("TotalAppearedTM") = 0
            dtrow("TotalPassedTM") = 0
            dtrow("TotalFailed") = 0
            dtrow("PassingMarks") = 0
            dtrow("TMPassed") = 0
            dtrow("TMAppearedRetest") = 0
            dtrow("TMPassedRetest") = 0
            dtrow("TMChanged") = 0
            dt.Rows.Add(dtrow)
        End If
        'gdAddQuizResult.DataSource = dt
        'gdAddQuizResult.DataBind()
        GridView1.DataSource = dt
        GridView1.DataBind()
        lblreportname.CurrentPage = "Quiz result for " & cboCampaigns.SelectedItem.Text
        If dt.Rows(0)(0).ToString = "0" Then
            Dim txt1, txt2, txt3, txt4, txt5, txt6, txt7, txt8, txt9 As TextBox, lbl1, lbl2, lbl3, lbl4, lbl5, lbl6, lbl7, lbl8, lbl9 As Label
            txt1 = GridView1.Rows(0).FindControl("txtTotalTM")
            txt2 = GridView1.Rows(0).FindControl("txtTotalAppearedTM")
            txt3 = GridView1.Rows(0).FindControl("txtTotalPassedTM")
            txt4 = GridView1.Rows(0).FindControl("txtTotalFailed")
            txt5 = GridView1.Rows(0).FindControl("txtPassingMarks")
            txt6 = GridView1.Rows(0).FindControl("txtTMPassed")
            txt7 = GridView1.Rows(0).FindControl("txtTMAppearedRetest")
            txt8 = GridView1.Rows(0).FindControl("txtTMPassedRetest")
            txt9 = GridView1.Rows(0).FindControl("txtTMChanged")
            txt1.Visible = True
            txt2.Visible = True
            txt3.Visible = True
            txt4.Visible = True
            txt5.Visible = True
            txt6.Visible = True
            txt7.Visible = True
            txt8.Visible = True
            txt9.Visible = True

            txt1.Text = ""
            txt2.Text = ""
            txt3.Text = ""
            txt4.Text = ""
            txt5.Text = ""
            txt6.Text = ""
            txt7.Text = ""
            txt8.Text = ""
            txt9.Text = ""
            txt1.Focus()

            lbl1 = GridView1.Rows(0).FindControl("lblTotalTM")
            lbl2 = GridView1.Rows(0).FindControl("lblTotalAppearedTM")
            lbl3 = GridView1.Rows(0).FindControl("lblTotalPassedTM")
            lbl4 = GridView1.Rows(0).FindControl("lblTotalFailed")
            lbl5 = GridView1.Rows(0).FindControl("lblPassingMarks")
            lbl6 = GridView1.Rows(0).FindControl("lblTMPassed")
            lbl7 = GridView1.Rows(0).FindControl("lblTMAppearedRetest")
            lbl8 = GridView1.Rows(0).FindControl("lblTMPassedRetest")
            lbl9 = GridView1.Rows(0).FindControl("lblTMChanged")
            If lbl1 Is Nothing Then
            Else
                lbl1.Visible = False
            End If
            If lbl2 Is Nothing Then
            Else
                lbl2.Visible = False
            End If
            If lbl3 Is Nothing Then
            Else
                lbl3.Visible = False
            End If
            If lbl4 Is Nothing Then
            Else
                lbl4.Visible = False
            End If
            If lbl5 Is Nothing Then
            Else
                lbl5.Visible = False
            End If
            If lbl6 Is Nothing Then
            Else
                lbl6.Visible = False
            End If
            If lbl7 Is Nothing Then
            Else
                lbl7.Visible = False
            End If
            If lbl8 Is Nothing Then
            Else
                lbl8.Visible = False
            End If
            If lbl9 Is Nothing Then
            Else
                lbl9.Visible = False
            End If

            Dim Save, Cancel, Edit As LinkButton
            Save = GridView1.Rows(0).FindControl("lnkSave")
            Cancel = GridView1.Rows(0).FindControl("lnkcancel")
            Edit = GridView1.Rows(0).FindControl("lnkedit")
            Save.Visible = True
            Edit.Visible = False
        End If
    End Sub
#End Region

#Region " CODE NOT IN USE "
    'Private Sub AddinGrid()
    '    Dim dt As New DataTable
    '    dt.Columns.Add("Campaign", System.Type.GetType("System.String"))
    '    dt.Columns.Add("Month", System.Type.GetType("System.String"))
    '    dt.Columns.Add("Year", System.Type.GetType("System.String"))
    '    dt.Columns.Add("TotalTM", System.Type.GetType("System.String"))
    '    dt.Columns.Add("TotalAppearedTM", System.Type.GetType("System.String"))
    '    dt.Columns.Add("TotalPassedTM", System.Type.GetType("System.String"))
    '    dt.Columns.Add("TotalFailed", System.Type.GetType("System.String"))
    '    dt.Columns.Add("PassingMarks", System.Type.GetType("System.String"))
    '    dt.Columns.Add("TMPassed", System.Type.GetType("System.String"))
    '    dt.Columns.Add("TMAppearedRetest", System.Type.GetType("System.String"))
    '    dt.Columns.Add("TMPassedRetest", System.Type.GetType("System.String"))
    '    dt.Columns.Add("TMChanged", System.Type.GetType("System.String"))
    '    Dim dtrow As DataRow
    '    Dim row As GridViewRow

    '    For Each row In gdAddQuizResult.Rows
    '        If row.RowType = DataControlRowType.DataRow Then
    '            dtrow = dt.NewRow
    '            If CType(row.FindControl("lblCampaign"), Label).Text <> "No Data" Then
    '                dtrow("Campaign") = CType(row.FindControl("lblCampaign"), Label).Text
    '                dtrow("Month") = CType(row.FindControl("lblMonth"), Label).Text
    '                dtrow("Year") = CType(row.FindControl("lblYear"), Label).Text
    '                dtrow("TotalTM") = CType(row.FindControl("lblTotalTM"), Label).Text
    '                dtrow("TotalAppearedTM") = CType(row.FindControl("lblTotalAppearedTM"), Label).Text
    '                dtrow("TotalPassedTM") = CType(row.FindControl("lblTotalPassedTM"), Label).Text
    '                dtrow("TotalFailed") = CType(row.FindControl("lblTotalFailed"), Label).Text
    '                dtrow("PassingMarks") = CType(row.FindControl("lblPassingMarks"), Label).Text
    '                dtrow("TMPassed") = CType(row.FindControl("lblTMPassed"), Label).Text
    '                dtrow("TMAppearedRetest") = CType(row.FindControl("lblTMAppearedRetest"), Label).Text
    '                dtrow("TMPassedRetest") = CType(row.FindControl("lblTMPassedRetest"), Label).Text
    '                dtrow("TMChanged") = CType(row.FindControl("lblTMChanged"), Label).Text
    '                dt.Rows.Add(dtrow)
    '            End If
    '        End If
    '    Next
    '    dtrow = dt.NewRow
    '    dtrow("Campaign") = cboCampaigns.SelectedValue
    '    dtrow("Month") = cboMonth.SelectedValue
    '    dtrow("Year") = cboYear.SelectedValue
    '    dtrow("TotalTM") = CType(gdAddQuizResult.FooterRow.FindControl("txtTotalTM"), TextBox).Text
    '    dtrow("TotalAppearedTM") = CType(gdAddQuizResult.FooterRow.FindControl("txtTotalAppearedTM"), TextBox).Text
    '    dtrow("TotalPassedTM") = CType(gdAddQuizResult.FooterRow.FindControl("txtTotalPassedTM"), TextBox).Text
    '    dtrow("TotalFailed") = CType(gdAddQuizResult.FooterRow.FindControl("txtTotalFailed"), TextBox).Text
    '    dtrow("PassingMarks") = CType(gdAddQuizResult.FooterRow.FindControl("txtPassingMarks"), TextBox).Text
    '    dtrow("TMPassed") = CType(gdAddQuizResult.FooterRow.FindControl("txtTMPassed"), TextBox).Text
    '    dtrow("TMAppearedRetest") = CType(gdAddQuizResult.FooterRow.FindControl("txtTMAppearedRetest"), TextBox).Text
    '    dtrow("TMPassedRetest") = CType(gdAddQuizResult.FooterRow.FindControl("txtTMPassedRetest"), TextBox).Text
    '    dtrow("TMChanged") = CType(gdAddQuizResult.FooterRow.FindControl("txtTMChanged"), TextBox).Text
    '    dt.Rows.Add(dtrow)
    '    'gdAddQuizResult.DataSource = dt
    '    'gdAddQuizResult.DataBind()
    '    GridView1.DataSource = dt
    '    GridView1.DataBind()
    'End Sub
#End Region

#Region " CODE NOT IN USE "
    'Protected Sub gdAddQuizResult_RowCommand(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewCommandEventArgs) Handles gdAddQuizResult.RowCommand
    '    If e.CommandName = "Add" Then
    '        If cboCampaigns.SelectedIndex <= 0 Or cboMonth.SelectedIndex <= 0 Or cboYear.SelectedIndex <= 0 Or CType(gdAddQuizResult.FooterRow.FindControl("txtTotalTM"), TextBox).Text.Trim = "" Or CType(gdAddQuizResult.FooterRow.FindControl("txtTotalAppearedTM"), TextBox).Text.Trim = "" Or CType(gdAddQuizResult.FooterRow.FindControl("txtTotalPassedTM"), TextBox).Text.Trim = "" Or CType(gdAddQuizResult.FooterRow.FindControl("txtTotalFailed"), TextBox).Text.Trim = "" Or CType(gdAddQuizResult.FooterRow.FindControl("txtPassingMarks"), TextBox).Text.Trim = "" Or CType(gdAddQuizResult.FooterRow.FindControl("txtTMPassed"), TextBox).Text.Trim = "" Or CType(gdAddQuizResult.FooterRow.FindControl("txtTMAppearedRetest"), TextBox).Text.Trim = "" Or CType(gdAddQuizResult.FooterRow.FindControl("txtTMPassedRetest"), TextBox).Text.Trim = "" Or CType(gdAddQuizResult.FooterRow.FindControl("txtTMChanged"), TextBox).Text.Trim = "" Then
    '            Return
    '        End If
    '        Dim flag As Boolean
    '        Dim dtDatatoChk As New DataTable
    '        dtDatatoChk = BindExistingData()

    '        flag = chkData(dtDatatoChk)
    '        If flag = True Then
    '            lblMsg.Text = "Value already exists in Database !"
    '        Else
    '            flag = chkDatafromGrid()
    '            If flag = True Then
    '                lblMsg.Text = "Value already added below !"
    '            Else
    '                AddinGrid()
    '                'lblMsg.Text = ""
    '            End If
    '        End If
    '    End If
    'End Sub
#End Region


    Private Function BindExistingData() As DataTable
        dtData = New DataTable
        'Dim hTable As New Hashtable()
        Dim Campaign As Integer
        If cboCampaigns.SelectedIndex <= 0 Then
            Campaign = 0
        Else
            Campaign = cboCampaigns.SelectedValue
        End If
        Dim db As New DBAccess
        dtData = db.ReturnTable("SELECT [CampaignID],[Month],[Year],[TotalTM],[TotalAppearedTM] ,[TotalPassedTM]," _
                                & " [TotalFailed],[PassingMarks],[TMPassed],[TMAppearedRetest],[TMPassedRetest]," _
                                & "[TMChanged] FROM [CRMdata].[dbo].[tbl_Data_QuizResults] WHERE [CampaignID] = " _
                                & Campaign & " AND [Month] = " & cboMonth.SelectedValue & " AND [Year] = " _
                                & cboYear.SelectedValue, False)
        db = Nothing
        Return dtData
    End Function

#Region "******************** ChkData ( NOT IN USE )********************"
    'Private Function chkData(ByVal dtData As DataTable) As Boolean
    '    Dim i As Int16 = 0
    '    Dim strMonth As String
    '    Dim flag As Boolean = False
    '    For i = 0 To dtData.Rows.Count - 1

    '        If Convert.ToInt16(Len(dtData.Rows(i)(1).ToString)) < 2 Then
    '            strMonth = "0" & dtData.Rows(i)(1).ToString
    '        Else
    '            strMonth = dtData.Rows(i)(1).ToString
    '        End If
    '        If dtData.Rows(i)(0).ToString = cboCampaigns.SelectedValue.ToString And strMonth = cboMonth.SelectedValue.ToString And dtData.Rows(i)(2).ToString = cboYear.SelectedValue.ToString Then
    '            flag = True
    '            Exit For
    '        Else
    '            flag = False
    '        End If
    '    Next
    '    dtData = New DataTable
    '    Return flag
    'End Function
#End Region

#Region "******************** chkDatafromGrid (NOT IN USE) ********************"
    'Private Function chkDatafromGrid() As Boolean
    '    If gdAddQuizResult.Rows.Count <= 0 Then
    '        Return False
    '    Else
    '        Dim flag As Boolean = False
    '        Dim dt As New DataTable
    '        dt.Columns.Add("Campaign", System.Type.GetType("System.String"))
    '        dt.Columns.Add("Month", System.Type.GetType("System.String"))
    '        dt.Columns.Add("Year", System.Type.GetType("System.String"))

    '        Dim dtrow As DataRow
    '        Dim row As GridViewRow

    '        For Each row In gdAddQuizResult.Rows
    '            If row.RowType = DataControlRowType.DataRow Then
    '                If CType(row.FindControl("lblCampaign"), Label).Text <> "No Data" Then
    '                    dtrow = dt.NewRow
    '                    dtrow("Campaign") = CType(row.FindControl("lblCampaign"), Label).Text
    '                    dtrow("Month") = CType(row.FindControl("lblMonth"), Label).Text
    '                    dtrow("Year") = CType(row.FindControl("lblYear"), Label).Text
    '                    dt.Rows.Add(dtrow)
    '                End If
    '            End If
    '        Next
    '        flag = chkData(dt)
    '        Return flag
    '    End If
    'End Function
#End Region

#Region "******************** gdAddQuizResult_RowDeleting (NOT IN USE) ********************"
    'Protected Sub gdAddQuizResult_RowDeleting(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewDeleteEventArgs) Handles gdAddQuizResult.RowDeleting
    '    Dim dt As New DataTable
    '    dt.Columns.Add("Campaign", System.Type.GetType("System.String"))
    '    dt.Columns.Add("Month", System.Type.GetType("System.String"))
    '    dt.Columns.Add("Year", System.Type.GetType("System.String"))
    '    dt.Columns.Add("TotalTM", System.Type.GetType("System.String"))
    '    dt.Columns.Add("TotalAppearedTM", System.Type.GetType("System.String"))
    '    dt.Columns.Add("TotalPassedTM", System.Type.GetType("System.String"))
    '    dt.Columns.Add("TotalFailed", System.Type.GetType("System.String"))
    '    dt.Columns.Add("PassingMarks", System.Type.GetType("System.String"))
    '    dt.Columns.Add("TMPassed", System.Type.GetType("System.String"))
    '    dt.Columns.Add("TMAppearedRetest", System.Type.GetType("System.String"))
    '    dt.Columns.Add("TMPassedRetest", System.Type.GetType("System.String"))
    '    dt.Columns.Add("TMChanged", System.Type.GetType("System.String"))
    '    Dim dtrow As DataRow
    '    Dim row As GridViewRow

    '    For Each row In gdAddQuizResult.Rows
    '        If row.RowType = DataControlRowType.DataRow Then
    '            If row.RowIndex <> e.RowIndex Then
    '                dtrow = dt.NewRow
    '                If CType(row.FindControl("lblCampaign"), Label).Text <> "No Data" Then
    '                    dtrow("Campaign") = CType(row.FindControl("lblCampaign"), Label).Text
    '                    dtrow("Month") = CType(row.FindControl("lblMonth"), Label).Text
    '                    dtrow("Year") = CType(row.FindControl("lblYear"), Label).Text
    '                    dtrow("TotalTM") = CType(row.FindControl("lblTotalTM"), Label).Text
    '                    dtrow("TotalAppearedTM") = CType(row.FindControl("lblTotalAppearedTM"), Label).Text
    '                    dtrow("TotalPassedTM") = CType(row.FindControl("lblTotalPassedTM"), Label).Text
    '                    dtrow("TotalFailed") = CType(row.FindControl("lblTotalFailed"), Label).Text
    '                    dtrow("PassingMarks") = CType(row.FindControl("lblPassingMarks"), Label).Text
    '                    dtrow("TMPassed") = CType(row.FindControl("lblTMPassed"), Label).Text
    '                    dtrow("TMAppearedRetest") = CType(row.FindControl("lblTMAppearedRetest"), Label).Text
    '                    dtrow("TMPassedRetest") = CType(row.FindControl("lblTMPassedRetest"), Label).Text
    '                    dtrow("TMChanged") = CType(row.FindControl("lblTMChanged"), Label).Text
    '                    dt.Rows.Add(dtrow)
    '                End If
    '            End If
    '        End If
    '    Next
    '    If dt.Rows.Count <= 0 Then
    '        Initiate()
    '    End If
    '    gdAddQuizResult.DataSource = dt
    '    gdAddQuizResult.DataBind()
    'End Sub
#End Region


    Protected Sub cboCampaigns_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboCampaigns.SelectedIndexChanged
        lblMsg.Text = ""
        Initiate()
    End Sub

    Protected Sub cboMonth_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboMonth.SelectedIndexChanged
        lblMsg.Text = ""
        Initiate()
    End Sub

    Protected Sub cboYear_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboYear.SelectedIndexChanged
        lblMsg.Text = ""
        Initiate()
    End Sub
    Protected Sub GridView1_RowEditing(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewEditEventArgs) Handles GridView1.RowEditing
        GridView1.EditIndex = e.NewEditIndex
        Initiate()
        Dim Save, Cancel, Edit As LinkButton
        Save = GridView1.Rows(e.NewEditIndex).FindControl("lnkSave")
        Cancel = GridView1.Rows(e.NewEditIndex).FindControl("lnkcancel")
        Edit = GridView1.Rows(e.NewEditIndex).FindControl("lnkedit")
        Save.Visible = True
        Cancel.Visible = True
        Edit.Visible = False
    End Sub

    Protected Sub GridView1_RowUpdating(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewUpdateEventArgs) Handles GridView1.RowUpdating
        Dim Save, Cancel, edit As LinkButton

        Save = GridView1.Rows(e.RowIndex).FindControl("lnkSave")
        Cancel = GridView1.Rows(e.RowIndex).FindControl("lnkcancel")
        edit = GridView1.Rows(e.RowIndex).FindControl("lnkedit")

        Dim txt1, txt2, txt3, txt4, txt5, txt6, txt7, txt8, txt9 As TextBox

        txt1 = GridView1.Rows(0).FindControl("txtTotalTM")
        txt2 = GridView1.Rows(0).FindControl("txtTotalAppearedTM")
        txt3 = GridView1.Rows(0).FindControl("txtTotalPassedTM")
        txt4 = GridView1.Rows(0).FindControl("txtTotalFailed")
        txt5 = GridView1.Rows(0).FindControl("txtPassingMarks")
        txt6 = GridView1.Rows(0).FindControl("txtTMPassed")
        txt7 = GridView1.Rows(0).FindControl("txtTMAppearedRetest")
        txt8 = GridView1.Rows(0).FindControl("txtTMPassedRetest")
        txt9 = GridView1.Rows(0).FindControl("txtTMChanged")
        If _ValidateInput(txt1.Text, txt2.Text, txt3.Text, txt4.Text, txt5.Text, txt6.Text, txt7.Text, txt8.Text, txt9.Text) Then
            Call InsertUpdateQuizResults(txt1.Text, txt2.Text, txt3.Text, txt4.Text, txt5.Text, txt6.Text, txt7.Text, txt8.Text, txt9.Text)
            GridView1.EditIndex = -1
            Initiate()
            Save.Visible = False
            Cancel.Visible = False
            edit.Visible = True
        End If

    End Sub

#Region "***************************_  InsertUpdateQuizResults()  _***************************"
    Private Sub InsertUpdateQuizResults(ByVal TotalTM As String, ByVal TotalAppearedTM As String, ByVal TotalPassedTM As String, ByVal TotalFailed As String, ByVal PassingMarks As String, ByVal TMPassed As String, ByVal TMAppearedRetest As String, ByVal TMPassedRetest As String, ByVal TMChanged As String)
        Dim db As New DBAccess
        Dim Cancel As LinkButton
        Cancel = GridView1.Rows(0).FindControl("lnkcancel")
        If Cancel.Visible <> True Then
            db.slDataAdd("CampaignID", cboCampaigns.SelectedValue)
            db.slDataAdd("Month", cboMonth.SelectedValue)
            db.slDataAdd("Year", cboYear.SelectedValue)
            db.slDataAdd("TotalTM", TotalTM)
            db.slDataAdd("TotalAppearedTM", TotalAppearedTM)
            db.slDataAdd("TotalPassedTM", TotalPassedTM)
            db.slDataAdd("TotalFailed", TotalFailed)
            db.slDataAdd("PassingMarks", PassingMarks)
            db.slDataAdd("TMPassed", TMPassed)
            db.slDataAdd("TMAppearedRetest", TMAppearedRetest)
            db.slDataAdd("TMPassedRetest", TMPassedRetest)
            db.slDataAdd("TMChanged", TMChanged)
            db.InsertinTable("tbl_Data_QuizResults")
            SuccessMessage("Quiz Results have been saved successfully.")
        Else
            db.slDataAdd("TotalTM", TotalTM)
            db.slDataAdd("TotalAppearedTM", TotalAppearedTM)
            db.slDataAdd("TotalPassedTM", TotalPassedTM)
            db.slDataAdd("TotalFailed", TotalFailed)
            db.slDataAdd("PassingMarks", PassingMarks)
            db.slDataAdd("TMPassed", TMPassed)
            db.slDataAdd("TMAppearedRetest", TMAppearedRetest)
            db.slDataAdd("TMPassedRetest", TMPassedRetest)
            db.slDataAdd("TMChanged", TMChanged)
            db.UpdateinTable("tbl_Data_QuizResults", "CampaignID = " & cboCampaigns.SelectedValue & "AND Month = " & cboMonth.SelectedValue & " AND Year = " & cboYear.SelectedValue)
            SuccessMessage("Quiz Results have been Updated successfully.")
        End If
        db = Nothing
    End Sub
#End Region

#Region "***Validate Input***"
    Private Function _ValidateInput(ByVal TotalTM As String, ByVal TotalAppearedTM As String, ByVal TotalPassedTM As String, ByVal TotalFailed As String, ByVal PassingMarks As String, ByVal TMPassed As String, ByVal TMAppearedRetest As String, ByVal TMPassedRetest As String, ByVal TMChanged As String) As Boolean
       
        If Not TotalTM = "" Then
            If Not IsNumeric(TotalTM) Then
                lblMsg.Text = "Please enter numeric data for Total TM"
                Return False
            End If
        Else
            lblMsg.Text = "Total TM can not be blank"
            Return False
        End If
        If Not TotalAppearedTM = "" Then
            If Not IsNumeric(TotalAppearedTM) Then
                lblMsg.Text = "Please enter numeric data for Total Appeared TM"
                Return False
            End If
        Else
            lblMsg.Text = "Total Appeared TM can not be blank"
            Return False
        End If
        If Not TotalPassedTM = "" Then
            If Not IsNumeric(TotalPassedTM) Then
                lblMsg.Text = "Please enter numeric data for Total Passed TM"
                Return False
            End If
        Else
            lblMsg.Text = "Total Passed TM can not be blank"
            Return False
        End If
        If Not TotalFailed = "" Then
            If Not IsNumeric(TotalFailed) Then
                lblMsg.Text = "Please enter numeric data for Total Failed TM"
                Return False
            End If
        Else
            lblMsg.Text = "Total Failed TM can not be blank"
            Return False
        End If
        If Not PassingMarks = "" Then
            If Not IsNumeric(PassingMarks) Then
                lblMsg.Text = "Please enter numeric data for Passing Marks"
                Return False
            End If
        Else
            lblMsg.Text = "Passing Marks can not be blank"
            Return False
        End If
        If Not TMPassed = "" Then
            If Not IsNumeric(TMPassed) Then
                lblMsg.Text = "Please enter numeric data for TM Passed"
                Return False
            End If
        Else
            lblMsg.Text = "TM Passed can not be blank"
            Return False
        End If
        If Not TMAppearedRetest = "" Then
            If Not IsNumeric(TMAppearedRetest) Then
                lblMsg.Text = "Please enter numeric data for TM Appeared Retest"
                Return False
            End If
        Else
            lblMsg.Text = "TM Appeared Retest can not be blank"
            Return False
        End If
        If Not TMPassedRetest = "" Then
            If Not IsNumeric(TMPassedRetest) Then
                lblMsg.Text = "Please enter numeric data for TM Passed Retest"
                Return False
            End If
        Else
            lblMsg.Text = "TM Passed Retest can not be blank"
            Return False
        End If
        If Not TMChanged = "" Then
            If Not IsNumeric(TMChanged) Then
                lblMsg.Text = "Please enter numeric data for TM Changed"
                Return False
            End If
        Else
            lblMsg.Text = "TM Changed can not be blank"
            Return False
        End If
        lblMsg.Text = ""
        Return True
    End Function
#End Region

    Protected Sub GridView1_RowCancelingEdit(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewCancelEditEventArgs) Handles GridView1.RowCancelingEdit
        GridView1.EditIndex = -1
        Initiate()
        Dim Save, Cancel, edit As LinkButton
        Save = GridView1.Rows(e.RowIndex).FindControl("lnkSave")
        Cancel = GridView1.Rows(e.RowIndex).FindControl("lnkcancel")
        edit = GridView1.Rows(e.RowIndex).FindControl("lnkedit")
        Save.Visible = False
        Cancel.Visible = False
        edit.Visible = True
    End Sub
#Region "Utilities"
    Private Sub SuccessMessage(ByVal msg As String)
        lblHumanMessage.Text = msg & " saved successfully."
        HumanMessage.CssClass = "HMSuccess"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub
    Private Sub ExportToexcel()
        Dim tw As New IO.StringWriter()
        Dim hw As New System.Web.UI.HtmlTextWriter(tw)
        'Dim frm As HtmlForm = New HtmlForm()
        Response.ContentType = "application/vnd.ms-excel"
        Response.AddHeader("content-disposition", "attachment;filename=" & lblreportname.CurrentPage & ".xls")
        Response.Charset = ""
        EnableViewState = False
        'Controls.Add(frm)
        GridView1.RenderControl(hw)
        Response.Write(tw.ToString())
        Response.End()
    End Sub
#End Region

    Protected Sub btnRefresh_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnRefresh.Click
        Initiate()
    End Sub
End Class
