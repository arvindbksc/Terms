﻿Imports com.nss.DBAccess
Imports System.Data
Imports System.Data.SqlClient
Partial Class Quality_TeamwiseErrorCount
    Inherits System.Web.UI.Page
#Region "Properties"
    Property CampaignID() As Integer
        Get
            Return ViewState("CampaignID")
        End Get
        Set(ByVal value As Integer)
            ViewState("CampaignID") = value
        End Set
    End Property

    Property AgentID() As String
        Get
            Return ViewState("AgentID")
        End Get
        Set(ByVal value As String)
            ViewState("AgentID") = value
        End Set
    End Property
#End Region
    Private Sub Getdata()

        Try
            ' Dim db As New DBAccess("qualitynew")
            Dim db As New DBAccess("CRM")
            db.slDataAdd("DateFrom", Request.QueryString.Item("datefrom"))
            db.slDataAdd("DateTo", Request.QueryString.Item("dateTo"))
            db.slDataAdd("Campaignid", Request.QueryString("campid"))
            db.slDataAdd("QEID", Request.QueryString("QEID"))
            db.slDataAdd("CallType", Request.QueryString("CallType"))
            db.slDataAdd("cmfid", Request.QueryString("cmfid"))
            db.slDataAdd("ErrorType", Request.QueryString("ErrorType"))
            db.slDataAdd("Agentid", Request.QueryString("agentid"))
            Dim dt As DataTable = db.ReturnTable("usp_TMWiseErrorCount_New", , True)
            db = Nothing
            dtgMain.DataSource = dt
            dtgMain.DataBind()


            Dim db2 As New DBAccess("CRM")
            db2.slDataAdd("DateFrom", Request.QueryString.Item("datefrom"))
            db2.slDataAdd("DateTo", Request.QueryString.Item("dateTo"))
            db2.slDataAdd("Campaignid", Request.QueryString("campid"))
            db2.slDataAdd("QEID", Request.QueryString("QEID"))
            db2.slDataAdd("CallType", Request.QueryString("CallType"))
            db2.slDataAdd("cmfid", Request.QueryString("cmfid"))
            db2.slDataAdd("ErrorType", Request.QueryString("ErrorType"))
            db2.slDataAdd("Agentid", Request.QueryString("agentid"))
            Dim dt2 As DataTable = db2.ReturnTable("usp_TMWiseMonitoredCount_New", , True)
            db2 = Nothing
            dtgMain2.DataSource = dt2
            dtgMain2.DataBind()


            
        Catch ex As Exception
            lblError.Text = ex.ToString.ToString
        End Try
    End Sub
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            If Session("AgentID") <> "" Then
                CampaignID = Session("CampaignID")
                AgentID = Session("AgentID")
                If Not Request.QueryString("campid") Is Nothing Then
                    Getdata()
                End If
            End If
        End If
        PanelReports.Controls.Add(Common.GetMenu(Request.Url, AgentID, Request.ApplicationPath))
    End Sub

    'Protected Sub dtgMain_RowCreated(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles dtgMain.RowCreated
    '    If e.Row.RowType = DataControlRowType.Header Then
    '        e.Row.Cells(3).Text = "Graphical View"
    '    End If
    'End Sub

    'Protected Sub ImageButton1_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton1.Click
    '    Getdata()
    '    GridViewExportUtil.Export(lblSheetID.Text & "-" & lblerror.Text & ".xls", Me.dtgMain)
    'End Sub

    Protected Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click
        Response.Redirect("~/Quality/^MainSummary")
    End Sub
End Class
