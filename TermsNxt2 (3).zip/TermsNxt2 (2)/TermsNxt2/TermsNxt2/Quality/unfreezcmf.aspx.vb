﻿Imports com.nss.DBAccess
Imports System.Data
Imports System.Data.SqlClient
Partial Class Quality_unfreezcmf
    Inherits System.Web.UI.Page
#Region "Properties"
    Property HasQuestion() As Boolean
        Get
            Return ViewState("HasQuestion")
        End Get
        Set(ByVal value As Boolean)
            ViewState("HasQuestion") = value
        End Set
    End Property
    Property LoginUserID() As String
        Get
            Return ViewState("LoginUserID")
        End Get
        Set(ByVal value As String)
            ViewState("LoginUserID") = value
        End Set
    End Property
    Property LoginUserName() As String
        Get
            Return ViewState("LoginUserName")
        End Get
        Set(ByVal value As String)
            ViewState("LoginUserName") = value
        End Set
    End Property
    Property StandAloneCMF() As Boolean
        Get
            Return ViewState("StandAloneCMF")
        End Get
        Set(ByVal value As Boolean)
            ViewState("StandAloneCMF") = value
        End Set
    End Property
    Property ProcessID() As Integer
        Get
            Return ViewState("ProcessID")
        End Get
        Set(ByVal value As Integer)
            ViewState("ProcessID") = value
            Session("ProcessID") = value
        End Set
    End Property
    Property Campaigntype() As Integer
        Get
            Return ViewState("Campaigntype")
        End Get
        Set(ByVal value As Integer)
            ViewState("Campaigntype") = value
            'Session("ProcessID") = value
        End Set
    End Property
    Property ReportType() As Integer
        Get
            Return ViewState("ReportType")
        End Get
        Set(ByVal value As Integer)
            ViewState("ReportType") = value
        End Set
    End Property
    Property CampaignID() As Integer
        Get
            Return ViewState("CampaignID")
        End Get
        Set(ByVal value As Integer)
            ViewState("CampaignID") = value
        End Set
    End Property

    Property AgentID() As String
        Get
            Return ViewState("AgentID")
        End Get
        Set(ByVal value As String)
            ViewState("AgentID") = value
        End Set
    End Property
    Property UserID() As String
        Get
            Return ViewState("UserID")
        End Get
        Set(ByVal value As String)
            ViewState("UserID") = value
        End Set
    End Property
#End Region
    Dim transid, customerid, cmfid, sheetid As Integer

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Try
            'If Not IsPostBack Then
            UserID = Session("AgentID")
            Dim db As New DBAccess("qualitynew")
            transid = Request.QueryString("transid")
            customerid = Request.QueryString("lid")
            ProcessID = Request.QueryString("campid")
            cmfid = Request.QueryString("cmfid")
            sheetid = Request.QueryString("sheetid")
            AgentID = Request.QueryString("agentid")
            If Request.QueryString("type") = "F" Then
                Dim strsql As String
                'strsql = "update tbl_QualitySheet set btfreez=0 where sheetid='" & sheetid & "'"
                strsql = "update tbl_Quality_Data_SheetMst set btfreez=0 where sheetid='" & sheetid & "'"   'new Quality
                db.exeSQL(strsql)
                db = Nothing
                insertintolog("CMFSheet has been Unfreezed")
                'Response.Redirect("~/Quality/transactiondetail.aspx?stage=M&agentid=" & AgentID & "&transid=" & transid & "&lid=" & customerid & "&campid=" & ProcessID & "&cmfid=" & cmfid & "&sheetid=" & sheetid)
                Response.Redirect("~/Quality/^TransactionDetail?stage=M&agentid=" & AgentID & "&transid=" & transid & "&lid=" & customerid & "&campid=" & ProcessID & "&cmfid=" & cmfid & "&sheetid=" & sheetid)
            End If
            ' End If

        Catch ex As Exception
            lblerror.Text = ex.ToString
            lblerror.Visible = True
        End Try
    End Sub
    Private Sub insertintolog(ByVal comment As String)
        Try
            Dim dblog As New DBAccess("qualitynew")
            dblog.slDataAdd("process", Request.QueryString("campid"))
            dblog.slDataAdd("Transid", Request.QueryString("transid"))
            dblog.slDataAdd("customerid", Request.QueryString("lid"))
            dblog.slDataAdd("User", UserID)
            dblog.slDataAdd("comment", Request.QueryString("sheetid") & " " & comment)
            dblog.slDataAdd("Type", "UnfreezCMF")
            dblog.InsertinTable("tbl_CMFDeletionLog")
            dblog = Nothing
        Catch ex As Exception
            lblerror.Text = ex.ToString
            lblerror.Visible = True
        End Try
    End Sub

    Protected Sub btsave_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btsave.Click
        Try
            If Request.QueryString("type") = "D" Then
                If txtreason.Text.Trim <> "" Then
                    Dim db As New DBAccess("qualitynew")
                    db.slDataAdd("sheetid", sheetid)
                    db.slDataAdd("deletedby", UserID)
                    db.slDataAdd("reason", txtreason.Text)
                    db.Executeproc("usp_deleteQualitySheet_new")
                    db = Nothing
                    insertintolog("CMFSheet has been Deleted")
                    Response.Redirect("~/Quality/^TransactionDetail?stage=M&agentid=" & AgentID & "&transid=" & transid & "&lid=" & customerid & "&campid=" & ProcessID & "&cmfid=" & cmfid & "&sheetid=" & sheetid)
                Else
                    lblerror.Text = "Please Enter Reason"
                    lblerror.Visible = True
                End If
            End If

        Catch ex As Exception
            lblerror.Text = ex.ToString
            lblerror.Visible = True
        End Try
    End Sub
End Class
