﻿Imports com.nss.DBAccess
Imports System.Data
Imports System.Text
Partial Class Quality_UploadedPIPRepository
    Inherits System.Web.UI.Page

    Dim startday As Integer, endday As Integer

#Region "--- Properties ---"
    Property AgentID() As String
        Get
            Return ViewState("AgentID")
        End Get
        Set(ByVal value As String)
            ViewState("AgentID") = value
        End Set
    End Property
    Property CampaignID() As String
        Get
            Return ViewState("CampaignID")
        End Get
        Set(ByVal value As String)
            ViewState("CampaignID") = value
        End Set
    End Property
#End Region

#Region "--- Page Load ---"

    Private Sub LoadData()
        Try

            FillCommonFilters()
            FillProcess()

        Catch ex As Exception
            Throw ex
        End Try
    End Sub

    Private Sub FillCommonFilters()
        Try
            Dim db As New DBAccess
            Dim dt As DataTable = db.ReturnTable("select * from tbl_Reports_DatePeriods")
            db = Nothing
            Dim dr As DataRow = dt.NewRow
            dr(0) = 10
            dr(1) = "Between"
            dt.Rows.Add(dr)
            ddlPeriod.DataTextField = "Caption"
            ddlPeriod.DataValueField = "Period"
            ddlPeriod.DataSource = dt
            ddlPeriod.DataBind()
            db = New DBAccess
            dt = db.ReturnTable("Select * from tbl_Reports_GroupBy")
            db = Nothing
        Catch ex As Exception
            Throw ex
        End Try
    End Sub

    Private Sub FillProcess()
        Try
            Common.FillProcesses(cboProcess, AgentID)
            Dim db As New DBAccess
            db.slDataAdd("Agentid", AgentID)
            cboProcess.SelectedValue = db.ReturnRow("usp_getAgentProcess", True)(4)
            db = Nothing
        Catch ex As Exception
            Throw ex
        End Try
    End Sub

    Private Sub FillCampaigns()
        'Common.FillCampaigns(cboCampaigns, AgentID, 0, 0)
        Common.FillProcessCampaigns(CboProcess, cboCampaigns, AgentID, CampaignID)
        Dim lstCamp As New ListItem
        lstCamp.Value = 0
        lstCamp.Text = "All"
        If cboCampaigns.Items.Contains(lstCamp) Then
            cboCampaigns.Items.Remove(lstCamp)
        End If
    End Sub


    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        HumanMessage.Style.Item("visibility") = "hidden"
        Try
            If Not IsPostBack Then
                If Session("AgentID") <> "" Then
                    AgentID = Session("AgentID")
                    CampaignID = Session("CampaignID")
                    PanelReports.Controls.Add(Common.GetMenu(Request.Url, AgentID, Request.ApplicationPath))
                    FillCampaigns()
                    LoadData()
                    fillGrid()
                    UcDateTo.Visible = False
                    ucDateFrom.Visible = False
                    lblAnd.Visible = False
                End If
            End If

        Catch ex As Exception
            AlertMessage(ex.Message)
        End Try
    End Sub

#End Region

#Region "--- Function ---"
    Private Sub fillGrid()
        Try
            Dim db As DBAccess
            Dim dtGetData As New DataTable

            If ddlPeriod.SelectedValue = 10 Then
                startday = ucDateFrom.yyyymmdd
                endday = UcDateTo.yyyymmdd
            Else
                db = New DBAccess("CRM")
                db.slDataAdd("Period", ddlPeriod.SelectedValue)
                db.slDataAdd("ProcessID", cboProcess.SelectedValue)
                Dim dr As DataRow = db.ReturnRow("usp_GetStart_EndDateForAPeriod_Process", True)
                db = Nothing
                startday = dr(0)
                endday = dr(1)
            End If

            db = New DBAccess("CRM")
            db.slDataAdd("CampaignId", cboCampaigns.SelectedItem.Text)
            db.slDataAdd("DateFrom", startday)
            db.slDataAdd("DateTo", endday)
            dtGetData = db.ReturnTable("USP_GET_UploadedPIPReport", , True)
            db = Nothing
            gvProcessingReport.DataSource = dtGetData
            gvProcessingReport.DataBind()
            lblReportName.CurrentPage = "Uploaded PIP Report Between " & IntegerToDateString(startday) & "  and " & IntegerToDateString(endday) & " for " & cboProcess.SelectedItem.Text & " process"

        Catch ex As Exception
            Throw ex
        End Try

        ScriptManager.RegisterStartupScript(Me, Me.GetType(), "SortGrid", "$(function(){{$('#" & gvProcessingReport.ClientID & "').tablesorter({cancelSelection:true}); }});", True)
    End Sub

    Private Function IntegerToDateString(ByVal d As Integer) As String
        Return d.ToString.Substring(0, 4) & "-" & d.ToString.Substring(4, 2) & "-" & d.ToString.Substring(6, 2)
    End Function

#End Region
#Region "--- Event ---"
    Protected Sub btnRefresh_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnRefresh.Click
        Try
            fillGrid()
        Catch ex As Exception
            AlertMessage(ex.Message)
        End Try
    End Sub

    Protected Sub ddlPeriod_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ddlPeriod.SelectedIndexChanged
        Try
            If ddlPeriod.SelectedValue = 10 Then
                ucDateFrom.Visible = True
                UcDateTo.Visible = True
                lblAnd.Visible = True
            Else
                ucDateFrom.Visible = False
                UcDateTo.Visible = False
                lblAnd.Visible = False
                fillGrid()
            End If
        Catch ex As Exception
            AlertMessage(ex.Message)
        End Try

    End Sub


    Protected Sub CboProcess_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboProcess.SelectedIndexChanged
        Try
            fillGrid()
        Catch ex As Exception
            AlertMessage(ex.Message)
        End Try
    End Sub

    Protected Sub btnExcel_Click(sender As Object, e As ImageClickEventArgs) Handles btnExcel.Click
        Try
            GridViewExportUtil.Export(lblReportName.CurrentPage & ".xls", Me.gvProcessingReport)
        Catch ex As Exception
            AlertMessage(ex.Message)
        End Try
    End Sub

    Protected Sub btnFavourite_Click(sender As Object, e As ImageClickEventArgs) Handles btnFavourite.Click
        Try
            Common.AddToFav(AgentID, "Total Processing Report")
            SuccessMessage("Report has been added to your favourite list")
        Catch ex As Exception
            AlertMessage(ex.Message)
        End Try
    End Sub

#End Region

#Region "--- Utility ---"

    Private Sub AlertMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMFail"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub

    Private Sub SuccessMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMSuccess"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub

    Public Overrides Sub VerifyRenderingInServerForm(ByVal Control As Control)

    End Sub

#End Region
End Class
