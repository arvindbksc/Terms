﻿Imports com.nss.DBAccess
Imports System.Data
Imports System.Data.SqlClient
Partial Class Quality_TransactionDetail
    Inherits System.Web.UI.Page
    Public transcount1 As Integer
    Public i As Integer
#Region "Properties"
    Property CampaignID() As Integer
        Get
            Return ViewState("CampaignID")
        End Get
        Set(ByVal value As Integer)
            ViewState("CampaignID") = value
        End Set
    End Property

    Property CustomerID() As Integer
        Get
            Return ViewState("CustomerID")
        End Get
        Set(ByVal value As Integer)
            ViewState("CustomerID") = value
        End Set
    End Property

    Property LoginUserID() As String
        Get
            Return ViewState("LoginUserID")
        End Get
        Set(ByVal value As String)
            ViewState("LoginUserID") = value
        End Set
    End Property

    Property LoginUserName() As String
        Get
            Return ViewState("LoginUserName")
        End Get
        Set(ByVal value As String)
            ViewState("LoginUserName") = value
        End Set
    End Property
    Property LoginUserLanId() As String
        Get
            Return ViewState("LoginUserLanId")
        End Get
        Set(ByVal value As String)
            ViewState("LoginUserLanId") = value
        End Set
    End Property
    Property AgentID() As String
        Get
            Return ViewState("AgentID")
        End Get
        Set(ByVal value As String)
            ViewState("AgentID") = value
        End Set
    End Property
    Property UserID() As String
        Get
            Return ViewState("UserID")
        End Get
        Set(ByVal value As String)
            ViewState("UserID") = value
        End Set
    End Property
#End Region
#Region "Load Function"
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        ' HumanMessage.Style.Item("visibility") = "hidden"
        If Not IsPostBack Then
            CustomerID = Request.QueryString("lid")
            CampaignID = Request.QueryString("campid")
            UserID = Session("AgentID")
            '  PanelReports.Controls.Add(Common.GetMenu(Request.Url, UserID, Request.ApplicationPath))
            '@test
            'Dim req As String = ""
            'Dim req2 As String = ""
            'req = Request.Url.ToString()
            'req2 = req.Replace("TransactionDetail.aspx", "^TransactionDetail")
            ' PanelReports.Controls.Add(Common.GetMenu(New Uri(req2), UserID, Request.ApplicationPath))

            PanelReports.Controls.Add(Common.GetMenu(Request.Url, UserID, Request.ApplicationPath))
            If fillCmfList() Then
                filldata()
            Else
                filldata()
            End If
        Else
            Session("AgentID") = UserID

            ''Dim req As String = ""
            ''Dim req2 As String = ""
            ''req = Request.Url.ToString()
            ''req2 = req.Replace("TransactionDetail.aspx", "^TransactionDetail")


            PanelReports.Controls.Add(Common.GetMenu(Request.Url, UserID, Request.ApplicationPath))
        End If

    End Sub
    Private Function fillCmfList() As Boolean
        Dim db As New DBAccess("qualitynew")
        db.slDataAdd("CampId", CampaignID)
        ' Dim dt As DataTable = db.ReturnTable("usp_QualityGetCMFList", , True)
        Dim dt As DataTable = db.ReturnTable("usp_QualityGetCMFList_new", , True)
        If dt.Rows.Count < 1 Then
            Return False
        End If
        db = Nothing
        ddlCMFList.DataSource = dt
        ddlCMFList.DataTextField = "Name"
        ddlCMFList.DataValueField = "CMFId"
        ddlCMFList.SelectedIndex = -1
        ddlCMFList.DataBind()
        Return True
    End Function
    Private Sub filldata()
        Dim db2 As New DBAccess("crm")
        db2.slDataAdd("agentid", UserID)
        Dim dt1 As DataTable = db2.ReturnTable("usp_GetAgentDetails", "", True)
        db2 = Nothing
        'LoginUserLanId = Session("UserLoginID")
        LoginUserID = dt1.Rows(0).Item("Agentid")
        LoginUserName = dt1.Rows(0).Item("AgentName")
        Dim db As New DBAccess("crm")
        db.slDataAdd("Leadid", CustomerID)
        db.slDataAdd("CampId", CampaignID)
        If Request.QueryString("transid") <> "" Then
            db.slDataAdd("TransId", Request.QueryString("transid"))
        End If
        Dim dt As DataTable = db.ReturnTable("usp_GetCMFLeadDetails", , True)
        db = Nothing
        rept1.DataSource = dt
        rept1.DataBind()
        If dt.Rows.Count = 0 And Request.QueryString("stage") = "No" Then
            btnGetTransactions.Visible = True
        End If
    End Sub
    Private Sub PLAYRECORDING(ByVal transid As String)
        Try
            ''''' ' Dim RM As New RecordingManagerWS.SGRecordingManagerWSService ''''Rajkumar 02-Aug-2016  Commented
            'Dim RM As New RecordingManagerWS3.SGRecordingManagerWSService   ''''''''Rajkumar 12-Apr-2017  Commented
            'RM.Proxy = System.Net.WebRequest.GetSystemWebProxy 'System.Net.WebProxy.GetDefaultProxy ''''''''Rajkumar 12-Apr-2017  Commented
            'If RM.Proxy.IsBypassed(New System.Uri(RM.Url)) Then ''''''''Rajkumar 12-Apr-2017  Commented
            '    '' '' ''Response.Write("Bypassed") 
            '    '' '' ''Response.End()
            'Else
            '    RM.Proxy.Credentials = System.Net.CredentialCache.DefaultCredentials ''''''''Rajkumar 12-Apr-2017  Commented
            'End If

            Dim str As String = "A"
            Dim num As Integer = 0
            Dim recordid As String = ""
            recordid = FindRecordid(transid)
            Dim varURL1 As String = recordid  ''rajkumar 12-Apr-2017 ADDED

            If recordid = "" Then
                Dim okMessage As String = "..No Recording Found.."
                Dim javaScript As String = String.Format("alert('{0}');", okMessage)
                Dim scriptKey As String = "SomeNewScript"
                Me.Page.ClientScript.RegisterStartupScript(Me.GetType(), scriptKey, javaScript, True)

                'rajkumar 19-June-2017
                Dim okMessage2 As String = ".No Recording Found...."
                Dim javaScript2 As String = String.Format("alert('{0}');", okMessage2)
                Dim scriptKey2 As String = "SomeNewScript"
                Me.Page.ClientScript.RegisterStartupScript(Me.GetType(), scriptKey2, javaScript2, True)

            Else
                ' str = RM.getRecordingURL(1, recordid, 1, 1, str, num) ''''Rajkumar 02-Aug-2016  Commented
                'Dim WSFetchURL As New RecordingFetchURL.Service1 ''''''rajkumar 12-Apr-2017 commented
                'str = WSFetchURL.getRecordingURL(recordid) '''''rajkumar 12-Apr-2017 commented

                ' str = TextBox1.Text
                Dim urlstr As String
                'Dim urlstr As String = str.Substring(str.IndexOf("voice="))
                'urlstr = urlstr.Replace("&locale=en_US", "")
                'urlstr = urlstr.Replace("voice=", "")

                '' urlstr = "http://172.17.52.137/Recordings/170404/170404202742O032.mp3"
                '' urlstr = "http://" & System.Configuration.ConfigurationManager.AppSettings("CubeServerIP").ToString & "/Recordings/" & varURL1.Substring(0, 6) & "/" & varURL1 & ".mp3"

                urlstr = "http://172.17.52.137" & "/Recordings/" & varURL1.Substring(0, 6) & "/" & varURL1 & ".mp3"


                Dim script As String = "window.open('" & urlstr & "','');"
                If (Not ClientScript.IsClientScriptBlockRegistered("NewWindow")) Then
                    Me.Page.ClientScript.RegisterStartupScript(Me.GetType(), "NewWindow", script, True)
                End If

                'Response.Redirect(urlstr)
            End If
            'or window.open
        Catch ex As Exception
            Response.Write("<script type = 'text/javascript'>alert('no recording found......');</script>")
            Response.Write("<script type = 'text/javascript'>alert(' " & ex.Message & "');</script>")

            ' AlertMessage("No Recording Found")
            'Dim okMessage1 As String = "No Recording Found"
            ' Dim javaScript1 As String = String.Format("alert('{0}')", okMessage1)
            ' Dim scriptKey1 As String = "SomeNewScript"
            'Me.Page.ClientScript.RegisterStartupScript(
            ' Me.Page.ClientScript.RegisterStartupScript(Me.GetType(), scriptKey1, javaScript1, True)
        End Try
    End Sub
    Private Function FindRecordid(ByVal transid As String) As String
        Try

            Dim varRecording As String = ""

            'Dim RID As New RecordID.Service1   ''''rajkumar 12-Apr-2017  Commented
            'Return RID.RecordID(transid)''''rajkumar 12-Apr-2017  Commented

            Dim db As New DBAccess("CRM")
            db.slDataAdd("TransId", transid)
            'Dim dtRec As DataTable = db.ReturnTable("usp_getrecordingId", , True)
            Dim dtRec As DataTable = db.ReturnTable("usp_getrecordingId2", , True)
            db = Nothing
            '' Return dtRec

            If dtRec.Rows.Count > 0 Then
                varRecording = dtRec.Rows(0).Item("recording_id").ToString()
            End If

            Return varRecording

        Catch ex As Exception
            Response.Write("<script type = 'text/javascript'>alert(' " & "Err :" & ex.Message & "');</script>")
        End Try

    End Function
#End Region
#Region "Events"
    Protected Sub btnClose_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnClose.Click
        Response.Redirect("~/Quality/^ListTransactions")
    End Sub
    Protected Sub btnGetTransactions_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnGetTransactions.Click
        If Request.QueryString("stage") = "No" Then
            'Session("Return") = "ListTransactions.aspx"
            ' Response.Redirect("~/Quality/NewCMF.aspx?StandAloneCMF=1&stage=N&lid=-1&campid=" & Request.QueryString("campid") & "&TransDate=" & Request.QueryString("TransDate") & "&agentid=" & Request.QueryString("agentid") & "&TransID=-1&CMFID=" & ddlCMFList.SelectedValue & "&SheetID=0&Telephone=" & "&LoginUserID=" & LoginUserID & "&LoginUserName=" & LoginUserName)
            '@PIP Phase 1 tested for 159 Atrium
            If CampaignID = 298 Then '298 Fly dubai
                Response.Redirect("~/Quality/CMFformNew.aspx?StandAloneCMF=1&stage=N&lid=-1&campid=" & Request.QueryString("campid") & "&TransDate=" & Request.QueryString("TransDate") & "&agentid=" & Request.QueryString("agentid") & "&TransID=-1&CMFID=" & ddlCMFList.SelectedValue & "&SheetID=0&Telephone=" & "&LoginUserID=" & LoginUserID & "&LoginUserName=" & LoginUserName & "&Return=^ListTransactions")
            Else
                Response.Redirect("~/Quality/CMFform.aspx?StandAloneCMF=1&stage=N&lid=-1&campid=" & Request.QueryString("campid") & "&TransDate=" & Request.QueryString("TransDate") & "&agentid=" & Request.QueryString("agentid") & "&TransID=-1&CMFID=" & ddlCMFList.SelectedValue & "&SheetID=0&Telephone=" & "&LoginUserID=" & LoginUserID & "&LoginUserName=" & LoginUserName & "&Return=^ListTransactions")
            End If

        Else
            filldata()
        End If
    End Sub
    Protected Sub ddlCMFList_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ddlCMFList.SelectedIndexChanged
        filldata()
    End Sub
    Protected Sub rept1_ItemCommand(ByVal source As Object, ByVal e As System.Web.UI.WebControls.RepeaterCommandEventArgs) Handles rept1.ItemCommand
        If e.CommandName = "getanswers" Then
            Dim lbl As Label = e.Item.FindControl("lbltransid")
            Dim dganswers As GridView = e.Item.FindControl("dganswers")
            Dim db As New DBAccess("crm")
            db.slDataAdd("transid", lbl.Text)
            Dim dt As DataTable = db.ReturnTable("usp_GetCMFTransactionDetails", , True)
            db = Nothing

            db = New DBAccess("crm")
            db.slDataAdd("CustomerID", CustomerID)
            db.slDataAdd("CampaignID", CampaignID)
            Dim drComments As DataRow = db.ReturnRow("usp_getCommentsOnTransaction", True)
            db = Nothing
            'Rajkumar 26May2011 start
            If Not IsDBNull(drComments.Item(0)) Then
                If drComments.Item(0).ToString.Trim <> "" Then
                    Dim rowComment As DataRow = dt.NewRow
                    rowComment.Item(0) = "Comments"
                    rowComment.Item(1) = drComments.Item(0)
                    dt.Rows.Add(rowComment)
                End If
            End If
            'Rajkumar 26May2011 end

            dganswers.DataSource = dt
            dganswers.DataBind()
        End If

        If e.CommandName = "getrecording" Then
            Dim lbl As Label = e.Item.FindControl("lbltransid")
            PLAYRECORDING(lbl.Text)
        End If
    End Sub
    Protected Sub rept1_ItemDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.RepeaterItemEventArgs) Handles rept1.ItemDataBound
        Dim lbl As Label = e.Item.FindControl("lbltransid")
        Dim lblcmfid As Label = e.Item.FindControl("lblCMFID")
        Dim lblagentid As Label = e.Item.FindControl("lblagentid")
        Dim lbltelephone As Label = e.Item.FindControl("lbltelephone")
        Dim lblendtime As Label = e.Item.FindControl("lbldate")
        Dim lbldate As Label = e.Item.FindControl("lblendtime")
        Dim RecordingAvailable As Label = e.Item.FindControl("LblRecordingAvailable")
        Dim hyper As HyperLink = e.Item.FindControl("HlFillCMF")
        Dim hlUnfreez As HyperLink = e.Item.FindControl("hlUnfreez")
        Dim hldelete As HyperLink = e.Item.FindControl("Hldelete")
        Dim playrecording As ImageButton = e.Item.FindControl("btngetrecording")
        'Dim notfound As ImageButton = e.Item.FindControl("btnnotfound")
        If Request.QueryString("transid") = lbl.Text Then
            lbl.BackColor = Drawing.Color.LightGray
            'Dim table As HtmlTable = CType(e.Item.FindControl("tblrep"), HtmlTable)
            'table.Attributes.Add("border", "1")
        End If
        Dim duration As Integer = DateDiff(DateInterval.Second, Convert.ToDateTime(lblendtime.Text), Convert.ToDateTime(lbldate.Text))
        Dim sheetid As Integer = 0
        Dim db1 As New DBAccess("qualitynew")
        Dim dt1 As DataTable
        ' dt1 = db1.ReturnTable("SELECT sheetid,[btFreez],cmfid,[Date] FROM [tbl_QualitySheet] where [CampaignID]=" & Request.QueryString("campid") & " and [CustomerID]=" & Request.QueryString("lid") & " and TransID=" & lbl.Text, , False)
        dt1 = db1.ReturnTable(" SELECT sheetid,[btFreez],cmfid,Transdate as [date] FROM [tbl_Quality_Data_SheetMst] where isdeleted=0 and [CampaignID]=" & Request.QueryString("campid") & " and [CustomerID]=" & Request.QueryString("lid") & " and TransID=" & lbl.Text, , False)
        db1 = Nothing
        Dim stage As String = ""
        If dt1.Rows.Count > 0 Then
            sheetid = dt1.Rows(0).Item("sheetid")
            lblcmfid.Text = dt1.Rows(0).Item("cmfid")
            If (dt1.Rows(0).Item("btFreez")) Then
                hyper.Text = "Show CMF"
                hyper.ImageUrl = "~/_assets/img/Show CMF.png"
                stage = "F"
                If DateDiff(DateInterval.Day, dt1.Rows(0).Item("Date"), Now.Date, Microsoft.VisualBasic.FirstDayOfWeek.Monday, FirstWeekOfYear.Jan1) <= 31 Then
                    hlUnfreez.Visible = True
                    Dim dbcheck As New DBAccess("qualitynew")
                    'TODO:!!put right in page load and then check here from variable###
                    If dbcheck.ReturnValue("SELECT * FROM [tbl_CMFDeletionRights] where [CampaignID]=" & Request.QueryString("campid") & " and [CanDelete] =1 and Agentid ='" & UserID & "'", False) <> Nothing Then
                        hldelete.Visible = True
                    End If
                    dbcheck = Nothing
                End If
            Else
                hyper.Text = "Modify CMF"
                hyper.ImageUrl = "~/_assets/img/modify.png"
                stage = "M"
            End If
        Else
            hyper.Text = "Fill CMF"
            hyper.ImageUrl = "~/_assets/img/fill.png"
            lblcmfid.Text = ddlCMFList.SelectedValue
            stage = "N"
        End If
        If RecordingAvailable.Text Then
            playrecording.Visible = True
        Else
            playrecording.Visible = False
        End If
        'Session("Return") = "ListTransactions.aspx"
        '@PIP Phase 1
        If CampaignID = 298 Then

            hlUnfreez.NavigateUrl = "~/Quality/UnFreezCmf.aspx?stage=" & stage & "&lid=" & Request.QueryString("lid") & "&campid=" & Request.QueryString("campid") & "&agentid=" & lblagentid.Text & "&TransID=" & lbl.Text & "&CMFID=" & lblcmfid.Text & "&SheetID=" & sheetid & "&Type=F"
            hldelete.NavigateUrl = "~/Quality/UnFreezCmf.aspx?stage=" & stage & "&lid=" & Request.QueryString("lid") & "&campid=" & Request.QueryString("campid") & "&agentid=" & lblagentid.Text & "&TransID=" & lbl.Text & "&CMFID=" & lblcmfid.Text & "&SheetID=" & sheetid & "&Type=D"
            ' hyper.NavigateUrl = "~/Quality/NewCMF.aspx?StandAloneCMF=0&stage=" & stage & "&lid=" & Request.QueryString("lid") & "&campid=" & Request.QueryString("campid") & "&agentid=" & lblagentid.Text & "&TransID=" & lbl.Text & "&CMFID=" & lblcmfid.Text & "&SheetID=" & sheetid & "&Telephone=" & lbltelephone.Text & "&LoginUserID=" & LoginUserID & "&LoginUserName=" & LoginUserName & "&duration=" & duration
            hyper.NavigateUrl = "~/Quality/CMFformNew.aspx?StandAloneCMF=0&stage=" & stage & "&lid=" & Request.QueryString("lid") & "&campid=" & Request.QueryString("campid") & "&agentid=" & lblagentid.Text & "&TransID=" & lbl.Text & "&CMFID=" & lblcmfid.Text & "&SheetID=" & sheetid & "&Telephone=" & lbltelephone.Text & "&LoginUserID=" & LoginUserID & "&LoginUserName=" & LoginUserName & "&duration=" & duration & "&Return=^ListTransactions"

        Else
            hlUnfreez.NavigateUrl = "~/Quality/UnFreezCmf.aspx?stage=" & stage & "&lid=" & Request.QueryString("lid") & "&campid=" & Request.QueryString("campid") & "&agentid=" & lblagentid.Text & "&TransID=" & lbl.Text & "&CMFID=" & lblcmfid.Text & "&SheetID=" & sheetid & "&Type=F"
            hldelete.NavigateUrl = "~/Quality/UnFreezCmf.aspx?stage=" & stage & "&lid=" & Request.QueryString("lid") & "&campid=" & Request.QueryString("campid") & "&agentid=" & lblagentid.Text & "&TransID=" & lbl.Text & "&CMFID=" & lblcmfid.Text & "&SheetID=" & sheetid & "&Type=D"
            ' hyper.NavigateUrl = "~/Quality/NewCMF.aspx?StandAloneCMF=0&stage=" & stage & "&lid=" & Request.QueryString("lid") & "&campid=" & Request.QueryString("campid") & "&agentid=" & lblagentid.Text & "&TransID=" & lbl.Text & "&CMFID=" & lblcmfid.Text & "&SheetID=" & sheetid & "&Telephone=" & lbltelephone.Text & "&LoginUserID=" & LoginUserID & "&LoginUserName=" & LoginUserName & "&duration=" & duration
            hyper.NavigateUrl = "~/Quality/CMFform.aspx?StandAloneCMF=0&stage=" & stage & "&lid=" & Request.QueryString("lid") & "&campid=" & Request.QueryString("campid") & "&agentid=" & lblagentid.Text & "&TransID=" & lbl.Text & "&CMFID=" & lblcmfid.Text & "&SheetID=" & sheetid & "&Telephone=" & lbltelephone.Text & "&LoginUserID=" & LoginUserID & "&LoginUserName=" & LoginUserName & "&duration=" & duration & "&Return=^ListTransactions"

        End If
        

    End Sub
#End Region

End Class
