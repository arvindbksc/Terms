﻿Imports System.Data
Imports com.nss.DBAccess
Imports System.Data.SqlClient
Partial Class Quality_MainSummary
    Inherits System.Web.UI.Page

#Region "Properties"

    Property CampaignID() As Integer
        Get
            Return ViewState("CampaignID")
        End Get
        Set(ByVal value As Integer)
            ViewState("CampaignID") = value
        End Set
    End Property

    Property AgentID() As String
        Get
            Return ViewState("AgentID")
        End Get
        Set(ByVal value As String)
            ViewState("AgentID") = value
        End Set
    End Property

    Property calltype() As String
        Get
            Return ViewState("Calltype")
        End Get

        Set(ByVal value As String)
            ViewState("Calltype") = value
        End Set

    End Property
    Property Errortype() As String
        Get
            Return ViewState("Errortype")
        End Get

        Set(ByVal value As String)
            ViewState("Errortype") = value
        End Set
    End Property
    Property Qe() As String
        Get
            Return ViewState("Qe")
        End Get
        Set(ByVal value As String)
            ViewState("Qe") = value
        End Set

    End Property
    Property cmfid() As String
        Get
            Return ViewState("cmfid")
        End Get
        Set(ByVal value As String)
            ViewState("cmfid") = value
        End Set
    End Property

    Property DateFrom() As String
        Get
            Return ViewState("DateFrom")
        End Get
        Set(ByVal value As String)
            ViewState("DateFrom") = value
        End Set
    End Property

    Property DateTO() As String
        Get
            Return ViewState("DateTO")
        End Get
        Set(ByVal value As String)
            ViewState("DateTO") = value
        End Set
    End Property

#End Region

#Region "==========================Events"
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Try
            If Not IsPostBack Then
                AgentID = Session("AgentID")
                PopulateCampaigns()

                getUserFilters()

                getQE()
                getcalltype()
                getErrorType()
                getCMFList()
                ' getUserFilters()
                retrieveWholeData()

            Else
                Session("AgentID") = AgentID
            End If

            PanelReports.Controls.Add(Common.GetMenu(Request.Url, AgentID, Request.ApplicationPath))
        Catch ex As Exception
            lblError.Text = ex.Message
        End Try
    End Sub

    Protected Sub btnGetTransactions_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnGetTransactions.Click
        Try
            AgentID = Session("AgentID")
            saveUserFilters()
            'getUserFilters()

            getQE()
            getcalltype()
            getErrorType()
            getCMFList()

            getUserFilters()

            retrieveWholeData()
        Catch ex As Exception
            lblError.Text = ex.Message
        End Try
    End Sub

    Protected Sub imgfav_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles imgfav.Click
        Common.AddToFav(AgentID, "QEwise CMF Count")
        Response.Write("<script type = 'text/javascript'>alert('Report has been added to your favourite list')</script>")
        'SuccessMessage("Report has been added to your favourite list")
        retrieveWholeData()
    End Sub

    Protected Sub ddlQE_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles DdlQE.SelectedIndexChanged
        Try
            AgentID = Session("AgentID")
            Qe = DdlQE.SelectedValue
            saveUserFilters()
            retrieveWholeData()
        Catch ex As Exception
            lblError.Text = ex.Message
        End Try
    End Sub

    Protected Sub ddlcmf_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ddlcmf.SelectedIndexChanged
        Try
            AgentID = Session("AgentID")
            cmfid = ddlcmf.SelectedValue
            saveUserFilters()
            retrieveWholeData()
        Catch ex As Exception
            lblError.Text = ex.Message
        End Try
    End Sub

    Protected Sub ddlCallType_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles DdlCallType.SelectedIndexChanged
        Try
            AgentID = Session("AgentID")
            calltype = DdlCallType.SelectedValue
            saveUserFilters()
            retrieveWholeData()
        Catch ex As Exception
            lblError.Text = ex.Message
        End Try
    End Sub

    Protected Sub ddlErrorType_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ddlErrorType.SelectedIndexChanged
        Try
            AgentID = Session("AgentID")
            Errortype = ddlErrorType.SelectedValue
            saveUserFilters()
            retrieveWholeData()
        Catch ex As Exception
            lblError.Text = ex.Message
        End Try
    End Sub

    Protected Sub ddlCampaigns_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ddlCampaigns.SelectedIndexChanged
        Try
            AgentID = Session("AgentID")
            CampaignID = ddlCampaigns.SelectedValue
            saveUserFilters()
            'getUserFilters()

            getQE()
            getcalltype()
            getErrorType()
            getCMFList()

            getUserFilters()
            retrieveWholeData()
        Catch ex As Exception
            lblError.Text = ex.Message
        End Try
    End Sub

#End Region


#Region "===========Support Functions"

    Protected Sub retrieveWholeData()
        Try
            lblError.Visible = False
            ' Dim db As New DBAccess("qualitynew")
            Dim db As New DBAccess

            db.slDataAdd("DateFrom", DateFrom)
            db.slDataAdd("DateTo", DateTO)
            db.slDataAdd("inQAId", Qe)
            db.slDataAdd("inCallType", calltype)
            db.slDataAdd("inErrorType", Errortype)
            db.slDataAdd("cmfid", cmfid)
            db.slDataAdd("CampaignID", CampaignID)

            Dim dtcamp As DataTable = db.ReturnTable("usp_QualityGetCMFCounts_new", , True)
            db = Nothing
            dtgMain.DataSource = dtcamp
            dtgMain.DataBind()
        Catch ex As Exception
            lblError.Text = ex.Message
        End Try
    End Sub

    ' Private Sub getUserFilters(ByVal FilterName As String)
    Private Sub getUserFilters()
        Dim db As New DBAccess("qualitynew")
        Dim dr As DataRow = db.ReturnRow("Select * from Tbl_UserFilters where userid='" & Session("AgentID") & "'")
        db = Nothing

        Try
            If Not dr Is Nothing Then

                If Not IsDBNull(dr("campaignID")) Then
                    CampaignID = dr("campaignID")
                    ddlCampaigns.ClearSelection()
                    ddlCampaigns.SelectedValue = CampaignID
                Else
                    CampaignID = ddlCampaigns.SelectedValue
                End If

                If Not IsDBNull(dr("DateFrom")) Then
                    DateFrom = dr("DateFrom")

                    'DdlYears.ClearSelection()
                    'DdlYears.Items.FindByValue(dr("DateFrom").ToString.Substring(0, 4)).Selected = True
                    DdlYears.SelectedValue = dr("DateFrom").ToString.Substring(0, 4)
                    'DdlMonths.ClearSelection()
                    'DdlMonths.Items.FindByValue(dr("DateFrom").ToString.Substring(4, 2)).Selected = True
                    DdlMonths.SelectedValue = dr("DateFrom").ToString.Substring(4, 2)
                    'DdlDay.ClearSelection()
                    'DdlDay.Items.FindByValue(dr("DateFrom").ToString.Substring(6, 2)).Selected = True
                    DdlDay.SelectedValue = dr("DateFrom").ToString.Substring(6, 2)
                Else
                    db = New DBAccess("CRM")
                    Dim dr2 As DataRow = db.ReturnRow("SELECT CONVERT(VARCHAR,GETDATE(),112) AS [DatePeriod] ")
                    db = Nothing

                    DateFrom = dr2("DatePeriod").ToString 'To set for viewState
                    'DateTO = dr2("DatePeriod").ToString

                    'DdlYears.ClearSelection()
                    'DdlYears.Items.FindByValue(dr2("DatePeriod").ToString.Substring(0, 4)).Selected = True
                    'DdlMonths.ClearSelection()
                    'DdlMonths.Items.FindByValue(dr2("DatePeriod").ToString.Substring(4, 2)).Selected = True
                    'DdlDay.ClearSelection()
                    'DdlDay.Items.FindByValue(dr2("DatePeriod").ToString.Substring(6, 2)).Selected = True
                    DdlYears.SelectedValue = dr("DatePeriod").ToString.Substring(0, 4)
                    DdlMonths.SelectedValue = dr("DatePeriod").ToString.Substring(4, 2)
                    DdlDay.SelectedValue = dr("DatePeriod").ToString.Substring(6, 2)
                End If

                If Not IsDBNull(dr("DateTo")) Then
                    DateTO = dr("DateTo")

                    'Ddlyear1.ClearSelection()
                    'Ddlyear1.Items.FindByValue(dr("DateTo").ToString.Substring(0, 4)).Selected = True
                    'Ddlmonth1.ClearSelection()
                    'Ddlmonth1.Items.FindByValue(dr("DateTo").ToString.Substring(4, 2)).Selected = True
                    'Ddlday1.ClearSelection()
                    'Ddlday1.Items.FindByValue(dr("DateTo").ToString.Substring(6, 2)).Selected = True
                    Ddlyear1.SelectedValue = dr("DateTo").ToString.Substring(0, 4)
                    Ddlmonth1.SelectedValue = dr("DateTo").ToString.Substring(4, 2)
                    Ddlday1.SelectedValue = dr("DateTo").ToString.Substring(6, 2)

                Else
                    db = New DBAccess("CRM")
                    Dim dr2 As DataRow = db.ReturnRow("SELECT CONVERT(VARCHAR,GETDATE(),112) AS [DatePeriod] ")
                    db = Nothing

                    DateTO = dr2("DatePeriod").ToString

                    'Ddlyear1.ClearSelection()
                    'Ddlyear1.Items.FindByValue(dr2("DatePeriod").ToString.Substring(0, 4)).Selected = True
                    'Ddlmonth1.ClearSelection()
                    'Ddlmonth1.Items.FindByValue(dr2("DatePeriod").ToString.Substring(4, 2)).Selected = True
                    'Ddlday1.ClearSelection()
                    'Ddlday1.Items.FindByValue(dr2("DatePeriod").ToString.Substring(6, 2)).Selected = True

                    Ddlyear1.SelectedValue = dr("DatePeriod").ToString.Substring(0, 4)
                    Ddlmonth1.SelectedValue = dr("DatePeriod").ToString.Substring(4, 2)
                    Ddlday1.SelectedValue = dr("DatePeriod").ToString.Substring(6, 2)
                End If

                If Not IsDBNull(dr("QEID")) Then
                    'DdlQE.ClearSelection()
                    Qe = dr("QEID")
                    DdlQE.ClearSelection()
                    DdlQE.Items.FindByValue(dr("QEID")).Selected = True
                Else
                    Qe = "%"
                End If

                If Not IsDBNull(dr("CallType")) Then
                    'DdlCallType.ClearSelection()
                    calltype = dr("CallType")
                    DdlCallType.ClearSelection()
                    DdlCallType.Items.FindByValue(dr("CallType")).Selected = True
                Else
                    calltype = "%"
                End If

                If Not IsDBNull(dr("ErrorType")) Then
                    ' ddlErrorType.ClearSelection()
                    Errortype = dr("ErrorType")
                    ddlErrorType.ClearSelection()
                    ddlErrorType.Items.FindByValue(dr("ErrorType")).Selected = True
                Else
                    Errortype = "%"
                End If

                If Not IsDBNull(dr("cmfid")) Then
                    cmfid = dr("cmfid")
                    ' ddlcmf.ClearSelection()
                    ddlcmf.ClearSelection()
                    ddlcmf.Items.FindByValue(dr("cmfid")).Selected = True
                Else
                    cmfid = 0
                End If


            Else 'if dr is nothing

                db = New DBAccess("CRM")
                Dim dr2 As DataRow = db.ReturnRow("SELECT CONVERT(VARCHAR,GETDATE(),112) AS [DatePeriod] ")
                db = Nothing

                DateFrom = dr2("DatePeriod").ToString 'To set for viewState
                DateTO = dr2("DatePeriod").ToString


                'DdlYears.ClearSelection()
                'DdlYears.Items.FindByValue(dr2("DatePeriod").ToString.Substring(0, 4)).Selected = True
                'DdlMonths.ClearSelection()
                'DdlMonths.Items.FindByValue(dr2("DatePeriod").ToString.Substring(4, 2)).Selected = True
                'DdlDay.ClearSelection()
                'DdlDay.Items.FindByValue(dr2("DatePeriod").ToString.Substring(6, 2)).Selected = True

                'Ddlyear1.ClearSelection()
                'Ddlyear1.Items.FindByValue(dr2("DatePeriod").ToString.Substring(0, 4)).Selected = True
                'Ddlmonth1.ClearSelection()
                'Ddlmonth1.Items.FindByValue(dr2("DatePeriod").ToString.Substring(4, 2)).Selected = True
                'Ddlday1.ClearSelection()
                'Ddlday1.Items.FindByValue(dr2("DatePeriod").ToString.Substring(6, 2)).Selected = True

                DdlYears.SelectedValue = dr("DatePeriod").ToString.Substring(0, 4)
                DdlMonths.SelectedValue = dr("DatePeriod").ToString.Substring(4, 2)
                DdlDay.SelectedValue = dr("DatePeriod").ToString.Substring(6, 2)

                Ddlyear1.SelectedValue = dr("DatePeriod").ToString.Substring(0, 4)
                Ddlmonth1.SelectedValue = dr("DatePeriod").ToString.Substring(4, 2)
                Ddlday1.SelectedValue = dr("DatePeriod").ToString.Substring(6, 2)
            End If

        Catch ex As Exception
            lblError.Text = ex.Message
        End Try
    End Sub



    Private Sub saveUserFilters()
        Try
            DateFrom = DdlYears.SelectedValue.ToString & DdlMonths.SelectedValue.ToString.PadLeft(2, "0") & DdlDay.SelectedValue.ToString.PadLeft(2, "0")
            DateTO = Ddlyear1.SelectedValue.ToString & Ddlmonth1.SelectedValue.ToString.PadLeft(2, "0") & Ddlday1.SelectedValue.ToString.PadLeft(2, "0")
            CampaignID = ddlCampaigns.SelectedValue
            Qe = DdlQE.SelectedValue
            cmfid = ddlcmf.SelectedValue
            calltype = DdlCallType.SelectedValue
            Errortype = ddlErrorType.SelectedValue


            Dim dbFilter As New DBAccess("qualitynew")
            If dbFilter.ReturnValue("select count(*) from Tbl_UserFilters where UserId='" & Session("AgentID") & "'", False) = 0 Then
                dbFilter.slDataAdd("UserId", Session("AgentID"))
                dbFilter.slDataAdd("Campaignid", CampaignID)
                dbFilter.slDataAdd("Date", DateFrom)
                dbFilter.slDataAdd("outcome", 0)
                dbFilter.slDataAdd("customerid", 0)
                dbFilter.InsertinTable("Tbl_UserFilters")
            End If

            dbFilter.slDataAdd("QEID", Qe)
            dbFilter.slDataAdd("CallType", calltype)
            dbFilter.slDataAdd("ErrorType", Errortype)
            dbFilter.slDataAdd("cmfid", cmfid)
            dbFilter.slDataAdd("datefrom", DateFrom)
            dbFilter.slDataAdd("dateto", DateTO)
            dbFilter.slDataAdd("Campaignid", CampaignID)
            dbFilter.UpdateinTable("Tbl_UserFilters", "UserId='" & AgentID & "'")
            'dbFilter.UpdateinTable("Tbl_UserFilters", "UserId='NSS44648'")
            dbFilter = Nothing
            '  MsgBox("AgentID IS =" & Session("AgentID"))
        Catch ex As Exception
            lblError.Text = ex.Message
        End Try

    End Sub

    Private Sub getcalltype()
        Try
            'Dim db As New DBAccess("qualitynew")
            Dim db As New DBAccess
            db.slDataAdd("DateFrom", DateFrom)
            db.slDataAdd("DateTo", DateTO)
            db.slDataAdd("Filter", "CallType")
            db.slDataAdd("campaignID", CampaignID)

            Dim dt As DataTable = db.ReturnTable("usp_QualityCMFCounts_Filter_new", , True)
            db = Nothing
            DdlCallType.DataTextField = "calltype"
            DdlCallType.DataValueField = "calltype"
            DdlCallType.DataSource = dt
            DdlCallType.DataBind()
            Dim item As New ListItem
            item.Text = "All"
            item.Value = "%"
            DdlCallType.Items.Insert(0, item)
            dt = Nothing
        Catch ex As Exception
            lblError.Text = ex.Message
        End Try
    End Sub

    Private Sub getErrorType()
        Try
            ' Dim db As New DBAccess("qualitynew")
            Dim db As New DBAccess

            db.slDataAdd("DateFrom", DateFrom)
            db.slDataAdd("DateTo", DateTO)
            db.slDataAdd("Filter", "ErrorType")
            db.slDataAdd("campaignID", CampaignID)

            Dim dt As DataTable = db.ReturnTable("usp_QualityCMFCounts_Filter_new", , True)
            db = Nothing
            ddlErrorType.DataTextField = "ErrorType"
            ddlErrorType.DataValueField = "ErrorType"
            ddlErrorType.DataSource = dt
            ddlErrorType.DataBind()
            Dim item As New ListItem
            item.Text = "All"
            item.Value = "%"
            ddlErrorType.Items.Insert(0, item)
            dt = Nothing
        Catch ex As Exception
            lblError.Text = ex.Message
        End Try
    End Sub

    Private Sub getQE()
        Try
            ' Dim fromDate, todate As String
            ' Dim db As New DBAccess("qualitynew")
            Dim db As New DBAccess

            db.slDataAdd("DateFrom", DateFrom)
            db.slDataAdd("DateTo", DateTO)
            db.slDataAdd("Filter", "QE")
            db.slDataAdd("campaignID", CampaignID)

            Dim dt As DataTable = db.ReturnTable("usp_QualityCMFCounts_Filter_new", , True)
            db = Nothing
            DdlQE.DataTextField = "QEName"
            DdlQE.DataValueField = "QEID"
            DdlQE.DataSource = dt
            DdlQE.DataBind()
            Dim item1 As New ListItem
            item1.Text = "All"
            item1.Value = "%"
            DdlQE.Items.Insert(0, item1)
            dt = Nothing
        Catch ex As Exception
            lblError.Text = ex.Message
        End Try
    End Sub

    Private Sub getCMFList()
        Try
            'Dim fromDate, todate As String
            ' Dim db As New DBAccess("qualitynew")
            Dim db As New DBAccess

            db.slDataAdd("DateFrom", DateFrom)
            db.slDataAdd("DateTo", DateTO)
            db.slDataAdd("Filter", "CMFList")
            db.slDataAdd("campaignID", CampaignID)
            Dim dt As DataTable = db.ReturnTable("usp_QualityCMFCounts_Filter_new", , True)
            db = Nothing
            ddlcmf.DataTextField = "CmfName"
            ddlcmf.DataValueField = "cmfid"
            ddlcmf.DataSource = dt
            ddlcmf.DataBind()
            Dim item1 As New ListItem
            item1.Text = "All"
            item1.Value = 0
            ddlcmf.Items.Insert(0, item1)
            dt = Nothing
        Catch ex As Exception
            lblError.Text = ex.Message
        End Try
    End Sub

    Private Sub PopulateCampaigns()
        Dim dt1 As DataTable
        Dim db3 As DBAccess
        Try
            Dim db2 As New DBAccess("crm")
            db2.slDataAdd("Agentid", AgentID)
            dt1 = db2.ReturnTable("usp_GetAgentDetails", "", True)
            db2 = Nothing

            db3 = New DBAccess("crm")
            db3.slDataAdd("Agentid", dt1.Rows(0).Item("Agentid"))
            ddlCampaigns.DataSource = db3.ReturnTable("usp_MyCampaigns", , True)
            ddlCampaigns.DataValueField = "campaignid"
            ddlCampaigns.DataTextField = "name"
            ddlCampaigns.DataBind()
            ' btnGetTransactions.Enabled = ddlCampaigns.Items.Count > 0
        Catch ex As Exception
            lblError.Visible = True
            lblError.Text = ex.Message.ToString
        Finally

            dt1 = Nothing
            db3 = Nothing
        End Try
    End Sub

#End Region


End Class
