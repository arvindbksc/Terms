﻿Imports System.Data
Imports com.nss.DBAccess
Imports System.Data.SqlClient
Partial Class Quality_MainSummary
    Inherits System.Web.UI.Page
#Region "Properties"
    Property SheetID() As Integer
        Get
            Return ViewState("SheetID")
        End Get
        Set(ByVal value As Integer)
            ViewState("SheetID") = value
        End Set
    End Property
    Property CustomerID() As Integer
        Get
            Return ViewState("CustomerID")
        End Get
        Set(ByVal value As Integer)
            ViewState("CustomerID") = value
        End Set
    End Property
    Property TransID() As Integer
        Get
            Return ViewState("TransID")
        End Get
        Set(ByVal value As Integer)
            ViewState("TransID") = value
        End Set
    End Property
    Property CMFID() As Integer
        Get
            Return ViewState("CMFID")
        End Get
        Set(ByVal value As Integer)
            ViewState("CMFID") = value
        End Set
    End Property
    Property CampaignID() As Integer
        Get
            Return ViewState("CampaignID")
        End Get
        Set(ByVal value As Integer)
            ViewState("CampaignID") = value
        End Set
    End Property
    Property MainCatID() As Integer
        Get
            Return ViewState("MainCatID")
        End Get
        Set(ByVal value As Integer)
            ViewState("MainCatID") = value
        End Set
    End Property
    Property SubCatID() As Integer
        Get
            Return ViewState("SubCatID")
        End Get
        Set(ByVal value As Integer)
            ViewState("SubCatID") = value
        End Set
    End Property
    Property LoginUserID() As String
        Get
            Return ViewState("LoginUserID")
        End Get
        Set(ByVal value As String)
            ViewState("LoginUserID") = value
        End Set
    End Property
    Property LoginUserName() As String
        Get
            Return ViewState("LoginUserName")
        End Get
        Set(ByVal value As String)
            ViewState("LoginUserName") = value
        End Set
    End Property
    Property AgentID() As String
        Get
            Return ViewState("AgentID")
        End Get
        Set(ByVal value As String)
            ViewState("AgentID") = value
        End Set
    End Property
#End Region
    Protected Sub filldata() Handles SummaryReportFilters1.firedata
        lblerror.Visible = False
        ' Dim db As New DBAccess("qualitynew")
        Dim db As New DBAccess
        db.slDataAdd("DateFrom", SummaryReportFilters1.DateFrom)
        db.slDataAdd("DateTo", SummaryReportFilters1.DateTO)
        db.slDataAdd("agentid", AgentID)
        db.slDataAdd("inQAId", SummaryReportFilters1.Qe)
        db.slDataAdd("inCallType", SummaryReportFilters1.calltype)
        db.slDataAdd("inErrorType", SummaryReportFilters1.Errortype)
        db.slDataAdd("cmfid", SummaryReportFilters1.cmfid)
        Dim dtcamp As DataTable = db.ReturnTable("usp_QualityGetcampaigns_new", , True)
        db = Nothing
        campaign.DataSource = dtcamp
        campaign.DataBind()
    End Sub
    Protected Sub campaign_ItemDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.RepeaterItemEventArgs) Handles campaign.ItemDataBound
        Dim dt, dt1 As DataTable
        Try
            Dim lblcampid As Label = e.Item.FindControl("lblcampid")
            Dim lblcamp As HyperLink = e.Item.FindControl("lblcampaign1")
            Dim lblerrorcount As HyperLink = e.Item.FindControl("hypererrorcount")
            Dim lblTMWiseErrorcount As HyperLink = e.Item.FindControl("HLTMWiseCount")
            lblcamp.NavigateUrl = "~/Quality/SummaryReportPerCamp.aspx?QEID=" & SummaryReportFilters1.Qe & "&cmfid=" & SummaryReportFilters1.cmfid & "&calltype=" & SummaryReportFilters1.calltype & "&errortype=" & SummaryReportFilters1.Errortype & "&campid=" & lblcampid.Text & "&DateFrom=" & SummaryReportFilters1.DateFrom & "&DateTo=" & SummaryReportFilters1.DateTO & "&campName=" & lblcamp.Text
            lblerrorcount.NavigateUrl = "~/Quality/QuestionwiseErrorCount.aspx?QEID=" & SummaryReportFilters1.Qe & "&cmfid=" & SummaryReportFilters1.cmfid & "&calltype=" & SummaryReportFilters1.calltype & "&errortype=" & SummaryReportFilters1.Errortype & "&agentid=%" & "&campid=" & lblcampid.Text & "&DateFrom=" & SummaryReportFilters1.DateFrom & "&DateTo=" & SummaryReportFilters1.DateTO
            lblTMWiseErrorcount.NavigateUrl = "~/Quality/TeamwiseErrorCount.aspx?QEID=" & SummaryReportFilters1.Qe & "&cmfid=" & SummaryReportFilters1.cmfid & "&calltype=" & SummaryReportFilters1.calltype & "&errortype=" & SummaryReportFilters1.Errortype & "&agentid=%" & "&campid=" & lblcampid.Text & "&DateFrom=" & SummaryReportFilters1.DateFrom & "&DateTo=" & SummaryReportFilters1.DateTO

            'Dim db As New DBAccess("qualitynew")
            Dim db As New DBAccess
            db.slDataAdd("DateFrom", SummaryReportFilters1.DateFrom)
            db.slDataAdd("DateTo", SummaryReportFilters1.DateTO)
            'db.slDataAdd("Lanid", System.Environment.UserName)
            db.slDataAdd("camp", lblcampid.Text)
            db.slDataAdd("inQAId", SummaryReportFilters1.Qe)
            db.slDataAdd("inCallType", SummaryReportFilters1.calltype)
            db.slDataAdd("inErrorType", SummaryReportFilters1.Errortype)
            db.slDataAdd("cmfid", SummaryReportFilters1.cmfid)
            dt = db.ReturnTable("usp_QualitySummaryReport1_new", , True)
            db = Nothing
            Dim dtnew As New DataTable
            For i As Integer = 0 To dt.Rows.Count - 1
                dtnew.Columns.Add(i.ToString)
            Next
            For i As Integer = 0 To dt.Columns.Count - 1
                Dim dr As DataRow = dtnew.NewRow
                dtnew.Rows.Add(dr)
            Next
            For i As Integer = 0 To dt.Columns.Count - 1
                For j As Integer = 0 To dt.Rows.Count - 1
                    dtnew.Rows(i).Item(j) = dt.Rows(j).Item(i).ToString
                Next
            Next

            'Dim db1 As New DBAccess("qualitynew")
            Dim db1 As New DBAccess
            db1.slDataAdd("DateFrom", SummaryReportFilters1.DateFrom)
            db1.slDataAdd("DateTo", SummaryReportFilters1.DateTO)
            'db.slDataAdd("Lanid", System.Environment.UserName)
            db1.slDataAdd("camp", lblcampid.Text)
            db1.slDataAdd("inQAId", SummaryReportFilters1.Qe)
            db1.slDataAdd("inCallType", SummaryReportFilters1.calltype)
            db1.slDataAdd("inErrorType", SummaryReportFilters1.Errortype)
            db1.slDataAdd("cmfid", SummaryReportFilters1.cmfid)
            dt1 = db1.ReturnTable("usp_QualityReport1QCScore_new", , True)
            db1 = Nothing
            'dtnew.Columns.Add("Calls Monitored")
            dtnew.Columns.Add("Monitored")
            dtnew.Columns.Add("Non Fatal Errors")
            dtnew.Columns.Add("Fatal Errors")
            dtnew.Columns.Add("NFAR%")
            dtnew.Columns.Add("FAR%")
            dtnew.Columns.Add("Parameter Wise Score%")
            'dtnew.Columns.Add("Client Calls Monitored")
            dtnew.Columns.Add("Client Monitored")
            dtnew.Columns.Add("Client Non Fatal Errors")
            dtnew.Columns.Add("Client Fatal Errors")
            dtnew.Columns.Add("Client NFAR%")
            dtnew.Columns.Add("Client FAR%")
            dtnew.Columns.Add("Client Parameter Wise Score%")
            'dtnew.Rows(1).Item("Calls Monitored") = "Calls Monitored"
            dtnew.Rows(1).Item("Monitored") = "Monitored"
            dtnew.Rows(1).Item("Non Fatal Errors") = "Non Fatal Errors Count"
            dtnew.Rows(1).Item("Fatal Errors") = "Fatal Sheets Count"
            dtnew.Rows(1).Item("NFAR%") = "NFAR%"
            dtnew.Rows(1).Item("FAR%") = "FAR%"
            dtnew.Rows(1).Item("Parameter Wise Score%") = "OverAll Score%"
            'dtnew.Rows(1).Item("Client Calls Monitored") = "Client Calls Monitored"
            dtnew.Rows(1).Item("Client Monitored") = "Client Monitored"
            dtnew.Rows(1).Item("Client Non Fatal Errors") = "Client Non Fatal Errors Count"
            dtnew.Rows(1).Item("Client Fatal Errors") = "Client Fatal Sheets Count"
            dtnew.Rows(1).Item("Client NFAR%") = "Client NFAR%"
            dtnew.Rows(1).Item("Client FAR%") = "Client FAR%"
            dtnew.Rows(1).Item("Client Parameter Wise Score%") = "Client OverAll Score%"
            'dtnew.Rows(2).Item("Calls Monitored") = dt1.Rows(0).Item("callsmonitored")
            dtnew.Rows(2).Item("Monitored") = dt1.Rows(0).Item("Monitored")
            dtnew.Rows(2).Item("Non Fatal Errors") = dt1.Rows(0).Item("NonFatalErrorCount")
            dtnew.Rows(2).Item("Fatal Errors") = dt1.Rows(0).Item("FatalErrorCount")
            dtnew.Rows(2).Item("NFAR%") = dt1.Rows(0).Item("NFAR%")
            dtnew.Rows(2).Item("FAR%") = dt1.Rows(0).Item("FAR%")
            dtnew.Rows(2).Item("Parameter Wise Score%") = dt1.Rows(0).Item("ParameterWiseScore%")
            'dtnew.Rows(2).Item("Client Calls Monitored") = dt1.Rows(0).Item("ClientCallsMonitored")
            dtnew.Rows(2).Item("Client Monitored") = dt1.Rows(0).Item("ClientMonitored")
            dtnew.Rows(2).Item("Client Non Fatal Errors") = dt1.Rows(0).Item("ClientNonFatalErrorCount")
            dtnew.Rows(2).Item("Client Fatal Errors") = dt1.Rows(0).Item("ClientFatalErrorCount")
            dtnew.Rows(2).Item("Client NFAR%") = dt1.Rows(0).Item("ClientNFAR%")
            dtnew.Rows(2).Item("Client FAR%") = dt1.Rows(0).Item("ClientFAR%")
            dtnew.Rows(2).Item("Client Parameter Wise Score%") = dt1.Rows(0).Item("ClientParameterWiseScore%")
            'For Each col As DataColumn In dt1.Columns
            '    dtnew.Columns.Add(col)
            'Next
            Dim dgdata As GridView = e.Item.FindControl("campaigndata")

            AddHandler dgdata.RowDataBound, AddressOf dgdata_RowCreated
            dgdata.DataSource = dtnew
            dgdata.DataBind()
            db1 = Nothing
        Catch ex As Exception
            lblerror.Text = ex.ToString
            lblerror.Visible = True
        End Try
    End Sub

    Protected Sub btnClose_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnClose.Click
        Response.Redirect("~/Data/^Sitemap")
    End Sub

    Protected Sub dgdata_RowCreated(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs)
        Try
            Dim dgdata As GridView = sender
            Dim cell As TableCell
            If e.Row.RowType = DataControlRowType.DataRow Then
                If e.Row.RowIndex = 0 Then
                    'GroupGridColumnbyrow(GridView1, 1, e.Row.Cells.Count - 1, e.Row.RowIndex, False)
                    'MsgBox(e.Row.Cells(0).Text)
                    Dim previouscelltext As String = "", currentcelltext As String = ""
                    Dim startcolumn As Integer = -1, ctr As Integer = 0, ctrcolspan As Integer = 1
                    For Each cell In e.Row.Cells
                        If previouscelltext = cell.Text Then
                            If startcolumn = -1 Then
                                startcolumn = ctr - 1
                            End If
                            ctrcolspan += 1
                            cell.Visible = False
                        Else
                            If startcolumn <> -1 Then
                                e.Row.Cells(startcolumn).ColumnSpan = ctrcolspan
                            End If
                            startcolumn = -1
                            ctrcolspan = 1
                        End If
                        ctr += 1
                        previouscelltext = cell.Text
                    Next
                    If startcolumn <> -1 Then
                        e.Row.Cells(startcolumn).ColumnSpan = ctrcolspan
                    End If
                ElseIf e.Row.RowIndex = 1 Then
                    e.Row.Cells(e.Row.Cells.Count - 2).ForeColor = Drawing.Color.Red
                    e.Row.Cells(e.Row.Cells.Count - 4).ForeColor = Drawing.Color.Red
                    e.Row.Cells(e.Row.Cells.Count - 8).ForeColor = Drawing.Color.Red
                    e.Row.Cells(e.Row.Cells.Count - 10).ForeColor = Drawing.Color.Red
                ElseIf e.Row.RowIndex = 2 Then
                    e.Row.Font.Bold = False
                    e.Row.Cells(e.Row.Cells.Count - 2).ForeColor = Drawing.Color.Red
                    e.Row.Cells(e.Row.Cells.Count - 4).ForeColor = Drawing.Color.Red
                    e.Row.Cells(e.Row.Cells.Count - 8).ForeColor = Drawing.Color.Red
                    e.Row.Cells(e.Row.Cells.Count - 10).ForeColor = Drawing.Color.Red
                End If

            End If
        Catch ex As Exception
            lblerror.Text = ex.ToString
            lblerror.Visible = True
        End Try

    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            AgentID = Session("AgentID")
            PanelReports.Controls.Add(Common.GetMenu(Request.Url, AgentID, Request.ApplicationPath))
        Else
            Session("AgentID") = AgentID
        End If

    End Sub

    Protected Sub imgfav_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles imgfav.Click
        Common.AddToFav(AgentID, "Quality Summary Report")
        Response.Write("<script type = 'text/javascript'>alert('Report has been added to your favourite list')</script>")
        'SuccessMessage("Report has been added to your favourite list")
        filldata()
    End Sub
    

End Class
