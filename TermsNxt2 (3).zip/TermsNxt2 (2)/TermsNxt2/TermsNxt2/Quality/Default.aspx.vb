﻿Imports com.nss.DBAccess
Imports System.Data

Partial Class Quality_Default
    Inherits System.Web.UI.Page
    Enum ChartItem
        FAR
        NFAR
    End Enum

#Region "Properties"
    
    Property Monthname1() As String
        Get
            Return ViewState("Monthname1")
        End Get
        Set(ByVal value As String)
            ViewState("Monthname1") = value
        End Set
    End Property
    Property Monthname2() As String
        Get
            Return ViewState("Monthname2")
        End Get
        Set(ByVal value As String)
            ViewState("Monthname2") = value
        End Set
    End Property
    Property Monthname3() As String
        Get
            Return ViewState("Monthname3")
        End Get
        Set(ByVal value As String)
            ViewState("Monthname3") = value
        End Set
    End Property
    Property ChartCase() As ChartItem
        Get
            Return ViewState("chartcase")
        End Get
        Set(ByVal value As ChartItem)
            ViewState("chartcase") = value

        End Set
    End Property
    Property CampaignID() As Integer
        Get
            Return ViewState("CampaignID")
        End Get
        Set(ByVal value As Integer)
            ViewState("CampaignID") = value
            Session("CampaignID") = value
        End Set
    End Property
    Property TCallMonitored() As Integer
        Get
            Return ViewState("TCallMonitored")
        End Get
        Set(ByVal value As Integer)
            ViewState("TCallMonitored") = value
            Session("TCallMonitored") = value
        End Set
    End Property
    Property ProcessID() As Integer
        Get
            Return ViewState("ProcessID")
        End Get
        Set(ByVal value As Integer)
            ViewState("ProcessID") = value
            Session("ProcessID") = value
        End Set
    End Property
    Property AgentID() As String
        Get
            Return ViewState("AgentID")
        End Get
        Set(ByVal value As String)
            ViewState("AgentID") = value
        End Set
    End Property
    Property dtsupervisor() As DataTable
        Get
            Return ViewState("dtsupervisor")
        End Get
        Set(ByVal value As DataTable)
            ViewState("dtsupervisor") = value
        End Set
    End Property
    Property StartDate() As String
        Get
            Return ViewState("startdate")
        End Get
        Set(ByVal value As String)
            ViewState("startdate") = value
        End Set
    End Property

    Property EndDate() As String
        Get
            Return ViewState("enddate")
        End Get
        Set(ByVal value As String)
            ViewState("enddate") = value
        End Set
    End Property
   
#End Region

    Dim QE As String
#Region "Data refresh and Graph"
    Private Sub FillGraph()

        If cboQE.SelectedValue = 0 Then
            QE = "%"
        Else
            QE = AgentID
        End If
        getQEEvaluatedcalls()
        ChartContainerInner.Controls.Clear()
        Dim objLink As HyperLink
        Dim objImg As Image
        For ictr = 0 To 3
            objLink = New HyperLink
            objLink.NavigateUrl = "../Graphs/EnlargedGraph.aspx?type=quality&groupby=" & cboChartPeriod.SelectedValue & "&KPA=" & ictr + 1 & "&QE=" & QE & "&GraphSize=200&CampaignID=" & cboCampaigns.SelectedValue & "&period=" & cboChartPeriod.SelectedValue
            objLink.ID = "lnkKPA" & ictr + 1
            objImg = New Image
            objImg.ImageUrl = "../Graphs/thumbgraph.aspx?type=quality&groupby=" & cboChartPeriod.SelectedValue & "&KPA=" & ictr + 1 & "&QE=" & QE & "&GraphSize=200&CampaignID=" & cboCampaigns.SelectedValue & "&period=" & cboChartPeriod.SelectedValue
            objImg.ID = "imgKPA" & ictr + 1
            objImg.CssClass = "chart"
            objLink.Controls.Add(objImg)
            ChartContainerInner.Controls.Add(objLink)
        Next

    End Sub

    Private Sub getQEEvaluatedcalls()
        Dim db As New DBAccess
        db.slDataAdd("Period", cboChartPeriod.SelectedValue)
        db.slDataAdd("Campaignid", CampaignID)
        Dim dr As DataRow = db.ReturnRow("usp_GetStart_EndDateForAPeriod", True)
        db = Nothing
        '  db = New DBAccess("qualitynew")
        db = New DBAccess
        db.slDataAdd("DateFrom", dr(0))
        db.slDataAdd("DateTo", dr(1))
        db.slDataAdd("inQAId", QE)
        db.slDataAdd("campaignid", CampaignID)
        db.slDataAdd("userid", AgentID)
        Dim dt As DataTable = db.ReturnTable("[usp_getQCScoreOnEvaluatedate_New]", , True)
        db = Nothing
        gridview1.DataSource = dt
        gridview1.DataBind()
        dt = Nothing
    End Sub
    
#End Region

#Region "Support functions"
    Private Sub FillProcessCampaigns()
        Common.FillProcessCampaigns(CboProcess, cboCampaigns, AgentID, CampaignID)
    End Sub
    Private Sub FillCommonFilters()
        Dim db As New DBAccess
        Dim dt As DataTable = db.ReturnTable("select * from tbl_Reports_DatePeriods")
        db = Nothing
        cboChartPeriod.DataTextField = "Caption"
        cboChartPeriod.DataValueField = "Period"
        cboChartPeriod.DataSource = dt
        cboChartPeriod.DataBind()
        dt = Nothing
    End Sub
#End Region

#Region "Even Handling"

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        If Not IsPostBack Then
            If Session("AgentID") <> "" Then
                ProcessID = Session("ProcessID")
                CampaignID = Session("CampaignID")
                AgentID = Session("AgentID")
                Panelmenu.Controls.Add(Common.GetMenu(Request.Url, AgentID, Request.ApplicationPath))
                FillProcessCampaigns()
                FillCommonFilters()
                getQEEvaluatedcalls()
                FillGraph()
            End If

        End If
    End Sub
    
    Protected Sub cboCampaigns_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboCampaigns.SelectedIndexChanged
        CampaignID = cboCampaigns.SelectedValue
        FillGraph()
    End Sub

    Protected Sub btnRefresh_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnRefresh.Click
        FillGraph()
    End Sub
    Protected Sub cboChartPeriod_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboChartPeriod.SelectedIndexChanged
        FillGraph()
    End Sub
    Protected Sub cboQE_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboQE.SelectedIndexChanged
        FillGraph()
    End Sub
#End Region
End Class
