﻿Imports com.nss.DBAccess
Imports System.Data
Partial Class Quality_ProcessSummary
    Inherits System.Web.UI.Page
#Region "Properties"

    Property ProcessID() As Integer
        Get
            Return ViewState("ProcessID")
        End Get
        Set(ByVal value As Integer)
            ViewState("ProcessID") = value
            Session("ProcessID") = value
        End Set
    End Property
    Property Campaigntype() As Integer
        Get
            Return ViewState("Campaigntype")
        End Get
        Set(ByVal value As Integer)
            ViewState("Campaigntype") = value
            'Session("ProcessID") = value
        End Set
    End Property
    Property ReportType() As Integer
        Get
            Return ViewState("ReportType")
        End Get
        Set(ByVal value As Integer)
            ViewState("ReportType") = value
        End Set
    End Property
    Property CampaignID() As Integer
        Get
            Return ViewState("CampaignID")
        End Get
        Set(ByVal value As Integer)
            ViewState("CampaignID") = value
        End Set
    End Property

    Property AgentID() As String
        Get
            Return ViewState("AgentID")
        End Get
        Set(ByVal value As String)
            ViewState("AgentID") = value
        End Set
    End Property
#End Region
#Region "Load Data"
    Private Sub LoadData()
        FillCommonFilters()
        PopulateCampaigns()
        getdataintable()
    End Sub
#End Region
#Region "Load Functions"
    Private Sub FillCommonFilters()
        Dim db As New DBAccess
        Dim dt As DataTable = db.ReturnTable("select * from tbl_Reports_DatePeriods")
        db = Nothing
        Dim dr As DataRow = dt.NewRow
        dr(0) = 10
        dr(1) = "Between"
        dt.Rows.Add(dr)
        CboPeriod.DataTextField = "Caption"
        CboPeriod.DataValueField = "Period"
        CboPeriod.DataSource = dt
        CboPeriod.DataBind()
    End Sub
    Private Sub getdataintable()
        Dim db As New DBAccess
        Dim startday As Integer, endday As Integer
        If CboPeriod.SelectedValue = 10 Then
            startday = ucDateFrom.yyyymmdd
            endday = UcDateTo.yyyymmdd
            If startday > endday Then
                AlertMessage("Date range is not correct")
                Return
            End If
        Else
            db = New DBAccess
            db.slDataAdd("Period", CboPeriod.SelectedValue)
            db.slDataAdd("Campaignid", CampaignID)
            Dim dr As DataRow = db.ReturnRow("usp_GetStart_EndDateForAPeriod", True)
            db = Nothing
            startday = dr(0)
            endday = dr(1)
        End If
        Dim dt As New DataTable

        '  db = New DBAccess("qualitynew")
        db = New DBAccess
        db.slDataAdd("DateFrom", startday)
        db.slDataAdd("DateTo", endday)
        db.slDataAdd("Processid", cboprocess.SelectedValue)
        'db.slDataAdd("Agentid", Session("AgentID"))

        dt = db.ReturnTable("usp_QualityProcessSummary_final_new", , True)
        If dt.Rows.Count > 0 Then
            dtgMain.DataSource = dt
            dtgMain.DataBind()
        End If
        lblReportName.Text = "Quality Consolidated QC Score Between " & IntegerToDateString(startday) & "  and " & IntegerToDateString(endday) & " for " & cboprocess.SelectedItem.Text
        db = Nothing
        
    End Sub
    Private Sub PopulateCampaigns()
        Try
            LblError.Visible = False
            Dim db As New DBAccess("report")
            db.slDataAdd("Agentid", Session("AgentID"))
            cboprocess.DataSource = db.ReturnTable("usp_MyProcesses", , True)
            cboprocess.DataValueField = "Processid"
            cboprocess.DataTextField = "ProcessName"
            cboprocess.DataBind()
            'Dim ls As New ListItem
            'ls.Text = "ALL"
            'ls.Value = "0"
            'ddlCampaigns.Items.Insert(0, ls)

        Catch ex As Exception
            AlertMessage(ex.Message.ToString)
        End Try
    End Sub
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        HumanMessage.Style.Item("visibility") = "hidden"
        If Not IsPostBack Then
            If Session("AgentID") <> "" Then
                CampaignID = Session("CampaignID")
                AgentID = Session("AgentID")
                PanelReports.Controls.Add(Common.GetMenu(Request.Url, AgentID, Request.ApplicationPath))
                LoadData()
                UcDateTo.Visible = False
                ucDateFrom.Visible = False
                lblAnd.Visible = False
            Else
                Session("AgentID") = AgentID
            End If
        End If
    End Sub
#End Region
#Region "Event"
    Protected Sub btnRefresh_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnRefresh.Click
        getdataintable()
    End Sub
    Protected Sub imgfav_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles imgfav.Click
        Common.AddToFav(AgentID, "Consolidated QC Score")
        SuccessMessage("Report has been added to your favourite list")
        getdataintable()
    End Sub
    Protected Sub ImageButton1_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton1.Click
        getdataintable()
        GridViewExportUtil.Export(lblReportName.Text & "-" & LblError.Text & ".xls", Me.dtgMain)
    End Sub

    Protected Sub CboPeriod_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles CboPeriod.SelectedIndexChanged
        If CboPeriod.SelectedValue = 10 Then
            ucDateFrom.Visible = True
            UcDateTo.Visible = True
            lblAnd.Visible = True
            getdataintable()
        Else
            ucDateFrom.Visible = False
            UcDateTo.Visible = False
            lblAnd.Visible = False
            getdataintable()
        End If
    End Sub
    Protected Sub cboprocess_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboprocess.SelectedIndexChanged
        getdataintable()
    End Sub
#End Region
#Region "grid ops"
    Dim callmontored, nonfatalerror, fatalsheet, FatalError, FatalQcount, AccuracyRate, nonfatalqcount, TotalParamWiseScore, CollectedParamWiseScore As Integer
    Dim Clientcallmontored, Clientnonfatalerror, ClientfatalSheet, ClientAccuracyRate, ClientFatalError, ClientFatalQcount, Clientnonfatalqcount, ClientTotalParamWiseScore, ClientCollectedParamWiseScore As Integer


    Dim numAgentid As Integer = 0
    Dim numAgentName As Integer = 1
    Dim numCallsMonitored As Integer = 2 'done

    Dim numNonFatalErrorCount As Integer = 3 'done
    Dim numFatalSheetCount As Integer = 4 'done
    Dim numFatalErrorCount As Integer = 5
    Dim numNonFatalQCount As Integer = 6 'done
    Dim numFatalQcount As Integer = 7
    Dim numNonFAR_percent As Integer = 8 'done
    Dim numFAR_percent As Integer = 9 'done
    Dim numTotalParamWiseScore As Integer = 10 'done
    Dim numCollectedParamWiseScore As Integer = 11 'done
    Dim numParameterWiseScore_percent As Integer = 12 'done
    Dim numAccuracyRate As Integer = 13

    Dim numClientCallsMonitored As Integer = 14 'done
    Dim numClientNonFatalErrorCount As Integer = 15 'done
    Dim numClientFatalSheetCount As Integer = 16 'done
    Dim numClientFatalErrorCount As Integer = 17
    Dim numClientNonFatalQCount As Integer = 18 'done
    Dim numClientFatalQcount As Integer = 19
    Dim numClientNFAR_percent As Integer = 20 'done
    Dim numClientFAR_percent As Integer = 21 'done
    Dim numClientTotalParamwiseScore As Integer = 22 'done
    Dim numClientCollectedParamWiseScore As Integer = 23 'done
    Dim numClientParameterWiseScore As Integer = 24 'done
    Dim numClientAccuracyRate As Integer = 25

    Dim footerval(17) As Double
    Protected Sub dtgMain_RowDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles dtgMain.RowDataBound

        If e.Row.RowType = DataControlRowType.DataRow Then

            footerval(0) = footerval(0) + 1 'Total Count



            Clientnonfatalqcount += IIf(e.Row.Cells(numClientNonFatalQCount).Text = "", 0, e.Row.Cells(numClientNonFatalQCount).Text)
            ClientFatalQcount += IIf(e.Row.Cells(numClientFatalQcount).Text = "", 0, e.Row.Cells(numClientFatalQcount).Text)
            ClientTotalParamWiseScore += IIf(e.Row.Cells(numClientTotalParamwiseScore).Text = "", 0, e.Row.Cells(numClientTotalParamwiseScore).Text)
            ClientCollectedParamWiseScore += IIf(e.Row.Cells(numClientCollectedParamWiseScore).Text = "", 0, e.Row.Cells(numClientCollectedParamWiseScore).Text)
            TotalParamWiseScore += IIf(e.Row.Cells(numTotalParamWiseScore).Text = "", 0, e.Row.Cells(numTotalParamWiseScore).Text)
            'AccuracyRate += IIf(e.Row.Cells(numAccuracyRate).Text = "", 0, e.Row.Cells(numAccuracyRate).Text)
            ClientAccuracyRate += IIf(e.Row.Cells(numClientAccuracyRate).Text = "", 0, e.Row.Cells(numClientAccuracyRate).Text)
            CollectedParamWiseScore += IIf(e.Row.Cells(numCollectedParamWiseScore).Text = "", 0, e.Row.Cells(numCollectedParamWiseScore).Text)

            callmontored += IIf(e.Row.Cells(numCallsMonitored).Text = "", 0, e.Row.Cells(numCallsMonitored).Text)
            nonfatalerror += IIf(e.Row.Cells(numNonFatalErrorCount).Text = "", 0, e.Row.Cells(numNonFatalErrorCount).Text)
            fatalsheet += IIf(e.Row.Cells(numFatalSheetCount).Text = "", 0, e.Row.Cells(numFatalSheetCount).Text)




            FatalQcount += IIf(e.Row.Cells(numFatalQcount).Text = "", 0, e.Row.Cells(numFatalQcount).Text)
            FatalError += IIf(e.Row.Cells(numFatalErrorCount).Text = "", 0, e.Row.Cells(numFatalErrorCount).Text)
            nonfatalqcount += IIf(e.Row.Cells(numNonFatalQCount).Text = "", 0, e.Row.Cells(numNonFatalQCount).Text)

            Clientcallmontored += IIf(e.Row.Cells(numClientCallsMonitored).Text = "", 0, e.Row.Cells(numClientCallsMonitored).Text)
            Clientnonfatalerror += IIf(e.Row.Cells(numClientNonFatalErrorCount).Text = "", 0, e.Row.Cells(numClientNonFatalErrorCount).Text)
            ClientfatalSheet += IIf(e.Row.Cells(numClientFatalSheetCount).Text = "", 0, e.Row.Cells(numClientFatalSheetCount).Text)
            ClientFatalError += IIf(e.Row.Cells(numClientFatalErrorCount).Text = "", 0, e.Row.Cells(numClientFatalErrorCount).Text)

            If callmontored = 0 Then
                e.Row.Cells(numFAR_percent).Text = "NaN"
                e.Row.Cells(numNonFAR_percent).Text = "NaN"
                e.Row.Cells(numAccuracyRate).Text = "NaN"
                e.Row.Cells(numParameterWiseScore_percent).Text = "NaN"
            End If

            If Clientcallmontored = 0 Then
                e.Row.Cells(numClientFAR_percent).Text = "NaN"
                e.Row.Cells(numClientNFAR_percent).Text = "NaN"
                e.Row.Cells(numClientAccuracyRate).Text = "NaN"
                e.Row.Cells(numClientParameterWiseScore).Text = "NaN"
            End If

            e.Row.Cells(numClientFatalSheetCount).ForeColor = Drawing.Color.Red
            e.Row.Cells(numClientFAR_percent).ForeColor = Drawing.Color.Red
            e.Row.Cells(numFatalSheetCount).ForeColor = Drawing.Color.Red
            e.Row.Cells(numFAR_percent).ForeColor = Drawing.Color.Red
        End If

        If e.Row.RowType = DataControlRowType.Header Then
            e.Row.Cells(numClientFatalSheetCount).ForeColor = Drawing.Color.Red
            e.Row.Cells(numClientFAR_percent).ForeColor = Drawing.Color.Red
            e.Row.Cells(numFatalSheetCount).ForeColor = Drawing.Color.Red
            e.Row.Cells(numFAR_percent).ForeColor = Drawing.Color.Red
        End If

        If e.Row.RowType = DataControlRowType.Footer Then
            e.Row.Cells(numAgentName).Text = "Total:-"

            e.Row.Font.Bold = True
            e.Row.VerticalAlign = VerticalAlign.Middle
            e.Row.HorizontalAlign = HorizontalAlign.Center
            'e.Row.Cells(1).Text = "Total"
            e.Row.Cells(numClientNonFatalQCount).Text = Clientnonfatalqcount
            e.Row.Cells(numClientFatalQcount).Text = ClientFatalQcount
            e.Row.Cells(numClientTotalParamwiseScore).Text = ClientTotalParamWiseScore
            e.Row.Cells(numClientCollectedParamWiseScore).Text = ClientCollectedParamWiseScore
            e.Row.Cells(numTotalParamWiseScore).Text = TotalParamWiseScore
            'e.Row.Cells(numAccuracyRate).Text = AccuracyRate
            e.Row.Cells(numCollectedParamWiseScore).Text = CollectedParamWiseScore

            e.Row.Cells(numCallsMonitored).Text = callmontored
            e.Row.Cells(numNonFatalErrorCount).Text = nonfatalerror
            e.Row.Cells(numFatalSheetCount).Text = fatalsheet

            e.Row.Cells(numFatalQcount).Text = FatalQcount
            e.Row.Cells(numFatalErrorCount).Text = FatalError
            e.Row.Cells(numNonFatalQCount).Text = nonfatalqcount

            If callmontored = 0 Then
                e.Row.Cells(numNonFAR_percent).Text = ""
                e.Row.Cells(numFAR_percent).Text = ""
                e.Row.Cells(numAccuracyRate).Text = ""
            Else
                '@20231230 keshavji 
                'e.Row.Cells(numNonFAR_percent).Text = 100 - Math.Round(((nonfatalerror) * 100 / nonfatalqcount), 2)
                e.Row.Cells(numNonFAR_percent).Text = 100 - Math.Round(((nonfatalerror) * 100 / callmontored), 2)


                e.Row.Cells(numFAR_percent).Text = 100 - Math.Round(((fatalsheet * 100) / callmontored), 2)
                e.Row.Cells(numAccuracyRate).Text = 100 - Math.Round(((nonfatalerror + FatalError) * 100 / (nonfatalqcount + FatalQcount)), 2)
                
            End If
           
            e.Row.Cells(numParameterWiseScore_percent).Text = Math.Round(((CollectedParamWiseScore / TotalParamWiseScore) * 100), 2)

            e.Row.Cells(numClientCallsMonitored).Text = Clientcallmontored
            e.Row.Cells(numClientNonFatalErrorCount).Text = Clientnonfatalerror

            e.Row.Cells(numClientFatalSheetCount).Text = ClientfatalSheet
            e.Row.Cells(numClientFatalErrorCount).Text = ClientFatalError

            If Clientcallmontored = 0 Then
                e.Row.Cells(numClientNFAR_percent).Text = "NaN"
                e.Row.Cells(numClientFAR_percent).Text = "NaN"
                e.Row.Cells(numClientAccuracyRate).Text = "NaN"
                e.Row.Cells(numClientParameterWiseScore).Text = "NaN"
            Else
                '@commented for Keshav ji 2023-12-30
                'e.Row.Cells(numClientNFAR_percent).Text = 100 - Math.Round(((Clientnonfatalerror) * 100 / Clientnonfatalqcount), 2)
                e.Row.Cells(numClientNFAR_percent).Text = 100 - Math.Round(((Clientnonfatalerror) * 100 / dtgMain.Rows.Count), 2)
                e.Row.Cells(numClientFAR_percent).Text = 100 - Math.Round(((ClientfatalSheet * 100) / dtgMain.Rows.Count), 2)

                'e.Row.Cells(numClientAccuracyRate).Text = 100 - Math.Round(((Clientnonfatalerror + ClientFatalError) * 100 / (Clientnonfatalerror + ClientFatalQcount)), 2)
                e.Row.Cells(numClientAccuracyRate).Text = 100 - Math.Round(((Clientnonfatalerror + ClientFatalError) * 100 / (dtgMain.Rows.Count)), 2)


              
            End If
            e.Row.Cells(numClientParameterWiseScore).Text = Math.Round(((ClientCollectedParamWiseScore / ClientTotalParamWiseScore) * 100), 2)


        End If

        'To hide the section
        e.Row.Cells(numAgentid).Visible = False 'For AgentID
        e.Row.Cells(numClientTotalParamwiseScore).Visible = False
        e.Row.Cells(numClientCollectedParamWiseScore).Visible = False
        e.Row.Cells(numTotalParamWiseScore).Visible = False

        e.Row.Cells(numClientFatalQcount).Visible = False
        e.Row.Cells(numCollectedParamWiseScore).Visible = False
        e.Row.Cells(numClientNonFatalQCount).Visible = False
        e.Row.Cells(numNonFatalQCount).Visible = False
        e.Row.Cells(numFatalQcount).Visible = False

    End Sub
#End Region
#Region "Utility"

    Private Sub AlertMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMFail"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub

    Private Sub SuccessMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMSuccess"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub

    'Protected Sub ImageButton1_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton1.Click
    '    'fillgrid()
    '    GridViewExportUtil.Export(lblReportName.CurrentPage & "-" & LblError.Text & ".xls", Me.GdAttendance)
    'End Sub


    Public Overrides Sub VerifyRenderingInServerForm(ByVal Control As Control)

    End Sub

#End Region
#Region "Support Functions"
    Private Function IntegerToDateString(ByVal d As Integer) As String
        Return d.ToString.Substring(0, 4) & "-" & d.ToString.Substring(4, 2) & "-" & d.ToString.Substring(6, 2)
    End Function
#End Region

    
End Class
