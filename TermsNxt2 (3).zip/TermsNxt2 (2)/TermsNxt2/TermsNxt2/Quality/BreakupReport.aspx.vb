﻿Imports com.nss.DBAccess
Imports System.Data
Imports System.Data.SqlClient
Partial Class Quality_BreakupReport
    Inherits System.Web.UI.Page
#Region "Properties"
    Property CampaignID() As Integer
        Get
            Return ViewState("CampaignID")
        End Get
        Set(ByVal value As Integer)
            ViewState("CampaignID") = value
        End Set
    End Property

    Property AgentID() As String
        Get
            Return ViewState("AgentID")
        End Get
        Set(ByVal value As String)
            ViewState("AgentID") = value
        End Set
    End Property
#End Region

#Region "Load Function"
    Private Sub GetParamWiseBreakUp()
        Dim fromDate, todate As String
        fromDate = DdlYears.SelectedValue + DdlMonths.SelectedValue + DdlDay.SelectedValue
        todate = Ddlyear1.SelectedValue + Ddlmonth1.SelectedValue + Ddlday1.SelectedValue
        If ddlCampaigns.SelectedValue = "" Then
            lblError.Text = "Please select a campaign"
            Exit Sub
        End If

        If ddlCampaigns.SelectedValue = "" And fromDate = "" And todate = "" Then
            lblError.Text = "Please fill in atleast one criteria to proceed."
            Exit Sub
        End If
        Try
            'Dim db As New DBAccess("qualitynew")
            Dim db As New DBAccess

            db.slDataAdd("DateFrom", IIf(fromDate.Trim = "", "%", fromDate.Trim))
            db.slDataAdd("DateTo", IIf(todate.Trim = "", "%", todate.Trim))
            db.slDataAdd("Campaignid", IIf(ddlCampaigns.SelectedValue.Trim = "", "%", Trim(ddlCampaigns.SelectedValue)))
            db.slDataAdd("QEID", Trim(DdlQEName.SelectedValue))
            db.slDataAdd("CallType", Trim(DdlCallType.SelectedValue))
            db.slDataAdd("PRType", Trim(DdlParamType.SelectedValue))
            db.slDataAdd("ErrorType", Trim(ddlErrorType.SelectedValue))
            db.slDataAdd("CMFId", Trim(ddlcmf.SelectedValue))
            Dim dt1 As DataTable = db.ReturnTable("usp_QualityQEParamBreakUp_new", , True)
            dtgMain.DataSource = dt1
            dtgMain.DataBind()
            db = Nothing
            dt1 = Nothing
        Catch ex As Exception
            lblError.Text = ex.ToString.ToString
        End Try
    End Sub
    Public campid As String = ""
    Private Sub PopulateCampaigns()
        Try
            Dim db2 As New DBAccess("crm")
            'db2.slDataAdd("lanID", Session("UserLoginID"))
            db2.slDataAdd("Agentid", AgentID)
            Dim dt1 As DataTable = db2.ReturnTable("usp_GetAgentDetails", "", True)
            db2 = Nothing
            Dim db As New DBAccess("crm")
            db.slDataAdd("Agentid", dt1.Rows(0).Item("Agentid"))
            ddlCampaigns.DataSource = db.ReturnTable("usp_MyCampaigns", , True)
            ddlCampaigns.DataValueField = "campaignid"
            ddlCampaigns.DataTextField = "name"
            ddlCampaigns.DataBind()
            'ddlCampaigns.Items.Insert(0, "")
            btnGetTransactions.Enabled = ddlCampaigns.Items.Count > 0
            dt1 = Nothing
            db = Nothing
        Catch ex As Exception
            lblError.Visible = True
            lblError.Text = ex.Message.ToString
        End Try
    End Sub
    Private Sub GetCurrentDate()
        For Each item As ListItem In DdlYears.Items
            If item.Text = Now.Year.ToString Then
                item.Selected = True
            End If
        Next
        For Each item As ListItem In Ddlyear1.Items
            If item.Text = Now.Year.ToString Then
                item.Selected = True
            End If
        Next
        For Each item As ListItem In DdlDay.Items
            If item.Value = Now.Day.ToString.PadLeft(2, "0") Then
                item.Selected = True
            End If
        Next
        For Each item As ListItem In Ddlday1.Items
            If item.Value = Now.Day.ToString.PadLeft(2, "0") Then
                item.Selected = True
            End If
        Next
        For Each item As ListItem In Ddlmonth1.Items
            If item.Value = Now.Month.ToString.PadLeft(2, "0") Then
                item.Selected = True
            End If
        Next
        For Each item As ListItem In DdlMonths.Items
            If item.Value = Now.Month.ToString.PadLeft(2, "0") Then
                item.Selected = True
            End If
        Next
    End Sub
    Shared dt As DataTable
    Private Sub getdataintable()
        'dt.Clear()
        dt = New DataTable
        Dim fromDate, todate As String
        'Dim db As New DBAccess("qualitynew")
        Dim db As New DBAccess
        '   Dim strsql As String
        fromDate = DdlYears.SelectedValue + DdlMonths.SelectedValue + DdlDay.SelectedValue
        todate = Ddlyear1.SelectedValue + Ddlmonth1.SelectedValue + Ddlday1.SelectedValue

        'strsql = "SELECT  a.*,b.name as CMFName FROM tbl_QualitySheet a inner join [tbl_Config_CMFCampaignMap] b on a.cmfid=b.cmfid"
        'strsql += " WHERE  a.btFreez=1 and a.CampaignId  in (" & ddlCampaigns.SelectedValue & ")"
        'strsql += " and (convert(varchar,dateadd(n,-330,date),112) BETWEEN " & fromDate & " AND " & todate & ")"
        'dt = db.ReturnTable(strsql, , False)

        db.slDataAdd("DateFrom", fromDate)
        db.slDataAdd("DateTo", todate)
        db.slDataAdd("Campaignid", ddlCampaigns.SelectedValue.Trim)

        dt = db.ReturnTable("usp_Quality_getCFname", , True)
        db = Nothing
    End Sub
    Private Sub GetQEName()
        Try
            Dim dtfiltered As DataTable = dt.Clone
            'Dim dtfiltered As New DataTable
            'dtfiltered.Columns.Add("QEID")
            'dtfiltered.Columns.Add("QEName")
            Dim drs As DataRow()
            If ddlcmf.SelectedValue = 0 Then
                drs = dt.Select("calltype like '" & DdlCallType.SelectedValue & "' and errortype like '" & ddlErrorType.SelectedValue & "'")
            Else
                drs = dt.Select("calltype like '" & DdlCallType.SelectedValue & "' and errortype like '" & ddlErrorType.SelectedValue & "' and CMFid = '" & ddlcmf.SelectedValue & "'")
            End If
            '' drs = dt.Compute("Distinct" & " " & "QEID" & "," & "QENAme", "Campaignid in (" & ddlCampaigns.SelectedValue & ")")
            For Each dr1 As DataRow In drs
                dtfiltered.ImportRow(dr1)
                'dtfiltered.Rows.Add(dr1.Item("QEID"), dr1.Item("QEName"))
            Next
            'MsgBox(dt.Rows.Count)
            Dim distinctQE As DataTable = dtfiltered.DefaultView.ToTable(True, New String() {"QEID", "QEName"})
            DdlQEName.DataTextField = "QEName"
            DdlQEName.DataValueField = "QEID"
            DdlQEName.DataSource = distinctQE
            DdlQEName.DataBind()
            Dim item As New ListItem
            item.Text = "All"
            item.Value = "%"
            DdlQEName.Items.Insert(0, item)
            'DdlQEName = Nothing
            distinctQE = Nothing
            dtfiltered = Nothing
            drs = Nothing
        Catch ex As Exception
            lblError.Text = ex.ToString
            lblError.Visible = True
        End Try

    End Sub

    Private Sub GetCallType()
        Try
            Dim dtfiltered As DataTable = dt.Clone
            Dim drs As DataRow()
            If ddlcmf.SelectedValue = 0 Then
                drs = dt.Select("QEID like '" & DdlQEName.SelectedValue & "' and CallType like '" & DdlCallType.SelectedValue & "'")
            Else
                drs = dt.Select("QEID like '" & DdlQEName.SelectedValue & "' and CallType like '" & DdlCallType.SelectedValue & "' and CMFid = '" & ddlcmf.SelectedValue & "'")
            End If
            For Each dr As DataRow In drs
                dtfiltered.ImportRow(dr)
            Next
            Dim distinctCallType As DataTable = dtfiltered.DefaultView.ToTable(True, New String() {"CallType"})
            DdlCallType.DataTextField = "CallType"
            DdlCallType.DataValueField = "CallType"
            DdlCallType.DataSource = distinctCallType
            DdlCallType.DataBind()
            Dim item1 As New ListItem
            item1.Text = "All"
            item1.Value = "%"
            DdlCallType.Items.Insert(0, item1)
            distinctCallType = Nothing
            dtfiltered = Nothing
        Catch ex As Exception
            lblError.Text = ex.ToString
            lblError.Visible = True
        End Try

    End Sub

    Private Sub getErrorType()
        Try
            Dim dtfiltered As DataTable = dt.Clone
            Dim drs As DataRow()
            If ddlcmf.SelectedValue = 0 Then
                drs = dt.Select("QEID like '" & DdlQEName.SelectedValue & "' and errortype like '" & ddlErrorType.SelectedValue & "'")
            Else
                drs = dt.Select("QEID like '" & DdlQEName.SelectedValue & "' and errortype like '" & ddlErrorType.SelectedValue & "' and CMFid = '" & ddlcmf.SelectedValue & "'")
            End If
            For Each dr As DataRow In drs
                dtfiltered.ImportRow(dr)
            Next
            Dim distinctErrorType As DataTable = dtfiltered.DefaultView.ToTable(True, New String() {"errortype"})
            ddlErrorType.DataTextField = "errortype"
            ddlErrorType.DataValueField = "errortype"
            ddlErrorType.DataSource = distinctErrorType
            ddlErrorType.DataBind()
            Dim item1 As New ListItem
            item1.Text = "All"
            item1.Value = "%"
            ddlErrorType.Items.Insert(0, item1)
            distinctErrorType = Nothing
            dtfiltered = Nothing
        Catch ex As Exception
            lblError.Text = ex.ToString
            lblError.Visible = True
        End Try

    End Sub
    
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        'Session("UserLoginID") = "jatint"
        If Not IsPostBack Then
            'userID = Session("userid")
            'userID = 393
            If Session("AgentID") <> "" Then
                CampaignID = Session("CampaignID")
                AgentID = Session("AgentID")
                GetCurrentDate()
                PopulateCampaigns()
                'setfilters()
                getdataintable()
                GetQEName()
                GetCallType()
                getErrorType()
                GetParamWiseBreakUp()
            End If
        Else
            Session("AgentID") = AgentID
        End If
        PanelReports.Controls.Add(Common.GetMenu(Request.Url, AgentID, Request.ApplicationPath))
    End Sub
#End Region
#Region "Events"
    Protected Sub btnGetTransactions_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnGetTransactions.Click
        'setfilters()
        getdataintable()
        GetQEName()
        GetCallType()
        getErrorType()
        getCmf()
        GetParamWiseBreakUp()
        'SetUserFilters()
    End Sub
    Protected Sub DdlQEName_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles DdlQEName.SelectedIndexChanged
        Try
            Dim dbFilter As New DBAccess("qualitynew")
            dbFilter.slDataAdd("QEID", DdlQEName.SelectedValue)
            dbFilter.UpdateinTable("Tbl_UserFilters", "UserId='" & AgentID & "'")
            dbFilter = Nothing
        Catch ex As Exception
            lblError.Text = ex.ToString
            lblError.Visible = True
        End Try
        GetCallType()
        getErrorType()
        getCmf()
        SetUserFilters()
        GetParamWiseBreakUp()
    End Sub
    Protected Sub DdlCallType_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles DdlCallType.SelectedIndexChanged
        Try
            Dim dbFilter As New DBAccess("qualitynew")
            dbFilter.slDataAdd("CallType", DdlCallType.SelectedValue)
            dbFilter.UpdateinTable("Tbl_UserFilters", "UserId='" & AgentID & "'")
            dbFilter = Nothing
        Catch ex As Exception
            lblError.Text = ex.ToString
            lblError.Visible = True
        End Try

        GetQEName()
        getErrorType()
        getCmf()
        SetUserFilters()
        GetParamWiseBreakUp()
    End Sub
    Protected Sub ddlErrorType_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ddlErrorType.SelectedIndexChanged
        Try
            Dim dbFilter As New DBAccess("qualitynew")
            dbFilter.slDataAdd("ErrorType", ddlErrorType.SelectedValue)
            dbFilter.UpdateinTable("Tbl_UserFilters", "UserId='" & AgentID & "'")
            dbFilter = Nothing

        Catch ex As Exception
            lblError.Text = ex.ToString
            lblError.Visible = True
        End Try
        GetQEName()
        GetCallType()
        getCmf()
        SetUserFilters()
        GetParamWiseBreakUp()
    End Sub

    Protected Sub DdlParamType_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles DdlParamType.SelectedIndexChanged
        'GetQEName()
        'GetCallType()
        ' getErrorType()
        SetUserFilters()
        GetParamWiseBreakUp()

    End Sub
    Protected Sub ddlcmf_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ddlcmf.SelectedIndexChanged
        Try
            Dim dbFilter As New DBAccess("qualitynew")
            dbFilter.slDataAdd("CMFid", ddlcmf.SelectedValue)
            dbFilter.UpdateinTable("Tbl_UserFilters", "UserId='" & AgentID & "'")
            dbFilter = Nothing
        Catch ex As Exception
            lblerror.Text = ex.ToString
            lblerror.Visible = True
        End Try
        GetQEName()
        GetCallType()
        getErrorType()
        SetUserFilters()
        GetParamWiseBreakUp()
    End Sub
    Protected Sub imgfav_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles imgfav.Click
        Common.AddToFav(AgentID, "Quality Breakup report")
        Response.Write("<script type = 'text/javascript'>alert('Report has been added to your favourite list')</script>")
        GetParamWiseBreakUp()
    End Sub
#End Region
#Region "Support Function"
    Private Sub getCmf()
        Try
            Dim dtfiltered As DataTable = dt.Clone
            Dim drs As DataRow()
            drs = dt.Select("QEID like '" & DdlQEName.SelectedValue & "' and calltype like '" & DdlCallType.SelectedValue & "' and errortype like '" & ddlErrorType.SelectedValue & "'")
            For Each dr As DataRow In drs
                dtfiltered.ImportRow(dr)
            Next
            Dim distinctCMF As DataTable = dtfiltered.DefaultView.ToTable(True, New String() {"CMfID", "CMFName"})
            ddlcmf.DataTextField = "CMFName"
            ddlcmf.DataValueField = "CMfID"
            ddlcmf.DataSource = distinctCMF
            ddlcmf.DataBind()
            Dim item1 As New ListItem
            item1.Text = "All"
            item1.Value = "0"
            ddlcmf.Items.Insert(0, item1)
            distinctCMF = Nothing
            dtfiltered = Nothing
        Catch ex As Exception
            ddlcmf.Text = ex.ToString
            ddlcmf.Visible = True
        End Try

    End Sub

    Private Sub setfilters()
        Try
            Dim dbFilter As New DBAccess("qualitynew")
            If dbFilter.ReturnValue("select count(*) from Tbl_UserFilters where UserId='" & AgentID & "'", False) = 0 Then
                dbFilter.slDataAdd("UserId", AgentID)
                dbFilter.slDataAdd("CampaignID", ddlCampaigns.SelectedValue)
                dbFilter.slDataAdd("Date", DdlYears.SelectedValue + DdlMonths.SelectedValue + DdlDay.SelectedValue)
                dbFilter.slDataAdd("OUTCome", 0)
                dbFilter.slDataAdd("Customerid", 0)
                dbFilter.InsertinTable("Tbl_UserFilters")
            End If
            dbFilter.slDataAdd("CampaignID", ddlCampaigns.SelectedValue)
            dbFilter.slDataAdd("QEID", "%")
            dbFilter.slDataAdd("CallType", "%")
            dbFilter.slDataAdd("ErrorType", "%")
            dbFilter.UpdateinTable("Tbl_UserFilters", "UserId='" & Session("AgentID") & "'")
            dbFilter = Nothing

        Catch ex As Exception
            lblError.Text = ex.ToString
            lblError.Visible = True
        End Try
    End Sub

    Private Sub SetUserFilters()
        Dim db As New DBAccess("qualitynew")
        Try
            Dim dr As DataRow = db.ReturnRow("Select * from Tbl_UserFilters where userid='" & AgentID & "'")
            If dr Is Nothing Then

            Else
                If Not IsDBNull(dr("QEID")) Then
                    'MsgBox(ddlQE.Items.FindByValue(dr("QEID")).Value)
                    DdlQEName.ClearSelection()
                    DdlQEName.SelectedIndex = -1
                    If Not DdlQEName.Items.FindByValue(dr("QEID")) Is Nothing Then
                        DdlQEName.Items.FindByValue(dr("QEID")).Selected = True
                    End If

                End If
                If Not IsDBNull(dr("CallType")) Then
                    'MsgBox(ddlCallType.Items.FindByValue(dr("CallType")).Value)
                    DdlCallType.ClearSelection()
                    DdlCallType.SelectedIndex = -1
                    If Not DdlCallType.Items.FindByValue(dr("CallType")) Is Nothing Then
                        DdlCallType.Items.FindByValue(dr("CallType")).Selected = True
                    End If

                End If
                If Not IsDBNull(dr("ErrorType")) Then
                    'MsgBox(ddlErrorType.Items.FindByValue(dr("ErrorType")).Value)
                    ddlErrorType.ClearSelection()
                    ddlErrorType.SelectedIndex = -1
                    If Not ddlErrorType.Items.FindByValue(dr("ErrorType")) Is Nothing Then
                        ddlErrorType.Items.FindByValue(dr("ErrorType")).Selected = True
                    End If

                End If
            End If
        Catch ex As Exception
            lblError.Text = ex.ToString
            lblError.Visible = True
        End Try
    End Sub
#End Region
#Region "gridops"
    Protected Sub dtgMain_RowCreated(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles dtgMain.RowCreated
        If e.Row.RowType = DataControlRowType.DataRow Then
            e.Row.Cells(0).Text = e.Row.RowIndex + 1
        End If
    End Sub
#End Region

   
End Class
