﻿Imports com.nss.DBAccess
Imports System.Data
Imports System.IO

Partial Class Quality_QualityDashBoard
    Inherits System.Web.UI.Page
#Region "Enum"
    Enum ChartItem
        CPH
        AHT
        FAR
        NFAR
    End Enum
    Enum PageItem
        Summary
        CPHTrend
        AHTTrend
        FARTrend
        FARTop5
        FARParamWise
        FARAgentWise
        NFARTrend
        NFARTop5
        NFARPareto
        QuizResults
    End Enum
#End Region

#Region "Properties"
    Property GroupBy() As Integer
        Get
            Return ViewState("GroupBy")
        End Get
        Set(ByVal value As Integer)
            ViewState("GroupBy") = value
        End Set
    End Property

    Property ReportTitle() As String
        Get
            Return lblreportname.CurrentPage
        End Get
        Set(ByVal value As String)

            lblreportname.CurrentPage = value & " for the period of " & StartDate & " to " & EndDate
        End Set
    End Property
    Property Monthname1() As String
        Get
            Return ViewState("Monthname1")
        End Get
        Set(ByVal value As String)
            ViewState("Monthname1") = value
        End Set
    End Property
    Property Monthname2() As String
        Get
            Return ViewState("Monthname2")
        End Get
        Set(ByVal value As String)
            ViewState("Monthname2") = value
        End Set
    End Property
    Property Monthname3() As String
        Get
            Return ViewState("Monthname3")
        End Get
        Set(ByVal value As String)
            ViewState("Monthname3") = value
        End Set
    End Property
    'Property dtchart1() As DataTable
    '    Get
    '        Return Session("dtchart1")
    '    End Get
    '    Set(ByVal value As DataTable)
    '        'ViewState("dtchart1") = value
    '        Session("dtchart1") = value
    '    End Set
    'End Property
    'Property dtchart2() As DataTable
    '    Get
    '        Return Session("dtchart2")
    '    End Get
    '    Set(ByVal value As DataTable)
    '        'ViewState("dtchart1") = value
    '        Session("dtchart2") = value
    '    End Set
    'End Property

    'Property dtsummary() As DataTable
    '    Get
    '        Return ViewState("dtSummary")
    '    End Get
    '    Set(ByVal value As DataTable)
    '        ViewState("dtSummary") = value
    '    End Set
    'End Property
    'Property dtparam() As DataTable
    '    Get
    '        Return ViewState("dtparam")
    '    End Get
    '    Set(ByVal value As DataTable)
    '        ViewState("dtparam") = value
    '    End Set
    'End Property
    'Property dtQuiz() As DataTable
    '    Get
    '        Return ViewState("dtQuiz")
    '    End Get
    '    Set(ByVal value As DataTable)
    '        ViewState("dtQuiz") = value
    '    End Set
    'End Property
    Property CampaignID() As Integer
        Get
            Return ViewState("CampaignID")
        End Get
        Set(ByVal value As Integer)
            ViewState("CampaignID") = value
            Session("CampaignID") = value
        End Set
    End Property
    Property TCallMonitored() As Integer
        Get
            Return ViewState("TCallMonitored")
        End Get
        Set(ByVal value As Integer)
            ViewState("TCallMonitored") = value
            Session("TCallMonitored") = value
        End Set
    End Property
    Property ProcessID() As Integer
        Get
            Return ViewState("ProcessID")
        End Get
        Set(ByVal value As Integer)
            ViewState("ProcessID") = value
            Session("ProcessID") = value
        End Set
    End Property
    Property AgentID() As String
        Get
            Return ViewState("AgentID")
        End Get
        Set(ByVal value As String)
            ViewState("AgentID") = value
        End Set
    End Property
    Property dtsupervisor() As DataTable
        Get
            Return ViewState("dtsupervisor")
        End Get
        Set(ByVal value As DataTable)
            ViewState("dtsupervisor") = value
        End Set
    End Property

    Property ChartCase() As ChartItem
        Get
            Return ViewState("chartcase")
        End Get
        Set(ByVal value As ChartItem)
            ViewState("chartcase") = value

        End Set
    End Property


    Property StartDate() As String
        Get
            Return ViewState("startdate")
        End Get
        Set(ByVal value As String)
            ViewState("startdate") = value
        End Set
    End Property

    Property EndDate() As String
        Get
            Return ViewState("enddate")
        End Get
        Set(ByVal value As String)
            ViewState("enddate") = value
        End Set
    End Property

    Property Pageno() As Integer
        Get
            Return ViewState("pageno")
        End Get
        Set(ByVal value As Integer)
            ViewState("pageno") = value
        End Set
    End Property
#End Region

#Region "Data refresh and Graph"

    Private Sub ShowPage()
        Chart1.Visible = False
        GridView1.Visible = False
        GridView2.Visible = False
        legend.Visible = False
        'respective procedure will make grid/chart visible

        Select Case Pageno
            Case 0
                fillsummary()
                ReportTitle = "Summary "
                lblreportname.CurrentPage = "Summary for the month of " & cboMonth.SelectedItem.Text & ", " & cboYear.SelectedValue
            Case 1
                ChartCase = ChartItem.CPH
                RenderChart()
                ReportTitle = "CPH trend "
            Case 2
                ChartCase = ChartItem.AHT
                RenderChart()
                ReportTitle = "AHT trend "
            Case 3
                ChartCase = ChartItem.FAR
                RenderChart()
                ReportTitle = "FAR trend "
            Case 4 'FAR top 5

                GetTop5FAR()
                ReportTitle = "Top 5 FAR contributers "
            Case 5
                GetConsolidatedFAR(1, "F")
                ReportTitle = "Consolidated FAR Tenured"
            Case 6
                GetConsolidatedFAR(2, "F")
                ReportTitle = "Consolidated FAR NonTenured"
            Case 7 'far TM wise
                'GetFARTMwise
                GridView1.Visible = True
                Chart1.Visible = False

                GridView1.DataSource = getTMParameterWiseFAR("F")(0)
                GridView1.DataBind()
                If Not getTMParameterWiseFAR("F")(0) Is Nothing Then
                    showlegend(getTMParameterWiseFAR("F")(1))
                End If

                ReportTitle = "Agent wise FAR contributers "
            Case 8
                ChartCase = ChartItem.NFAR
                RenderChart()
                ReportTitle = "NFAR trend "
            Case 9 'NFAR top 5
                GetTop5NFAR()
                ReportTitle = "Top 5 NFAR contributers "
            Case 10
                GetConsolidatedFAR(1, "N")
                ReportTitle = "Consolidated FAR Tenured"
            Case 11
                GetConsolidatedFAR(2, "N")
                ReportTitle = "Consolidated FAR Tenured"
            Case 12
                GridView1.Visible = True
                Chart1.Visible = False
                GridView1.DataSource = getTMParameterWiseFAR("N")(0)
                GridView1.DataBind()
                If Not getTMParameterWiseFAR("N")(0) Is Nothing Then
                    showlegend(getTMParameterWiseFAR("N")(1))
                End If

                ReportTitle = "Agent wise NFAR contributers "
            Case 13 'pareto
                GetLegendNFAR()
                ReportTitle = "NFAR Pareto "
            Case 14 'pareto
                GetLegendEUSAT()
                ReportTitle = "EU Complaints Pareto "
            Case 15
                GetQuizResult()
                lblreportname.CurrentPage = "Quiz result for the month of " & cboMonth.SelectedItem.Text & ", " & cboYear.SelectedValue
            Case 16
                GetParamTrend("F")
                ReportTitle = "Consolidated FAR Trend"
            Case 17
                GetParamTrend("N")
                ReportTitle = "Consolidated NFAR Trend"
            Case 18
                GetTeamLeaderWiseSummary()
                ReportTitle = "Team Leader Wise Summary"
            Case 19
                GetTeamLeaderWiseParameter()
                ReportTitle = "Team Leader Wise Parameter"
        End Select
    End Sub

    Private Sub fillsummary()
        Dim startdt As DateTime = DateTime.Parse(cboYear.SelectedValue & "-" & cboMonth.SelectedValue & "-" & "01")
        Dim enddt As DateTime = startdt.AddMonths(1).AddDays(-1)
        GridView2.DataSource = Nothing

        Dim db As New DBAccess
        Dim dtsummary As New DataTable
        db.slDataAdd("startdate", startdt.ToString("yyyyMMdd"))
        db.slDataAdd("endDate", enddt.ToString("yyyyMMdd"))
        db.slDataAdd("processid", CboProcess.SelectedValue)
        db.slDataAdd("campaignid", CampaignID)
        dtsummary = db.ReturnTable("[usp_DashboardSummary]", , True)
        db = Nothing
        Dim str As String = ""
        For Each col As DataColumn In dtsummary.Columns
            str += "[" & col.ColumnName & "] is null and "
        Next
        Dim showsummary As Boolean
        If Not str = "" Then
            str = str.Substring(0, Len(str) - 4)
            Dim dta() As DataRow = dtsummary.Select(str)
            If dta.Length = 0 Then
                showsummary = True
            Else
                showsummary = False
            End If
        End If
        If showsummary = True Then
            Dim dt As New DataTable
            dt.Columns.Add("Metrix", System.Type.GetType("System.String"))
            dt.Columns.Add("Actual", System.Type.GetType("System.String"))
            dt.Columns.Add("Target", System.Type.GetType("System.String"))
            Dim row As DataRow

            row = dt.NewRow
            row("Metrix") = "CPH"
            row("Actual") = dtsummary.Rows(0).Item("CPH")
            row("Target") = dtsummary.Rows(0).Item("CPHTarget")
            dt.Rows.Add(row)

            row = dt.NewRow
            row("Metrix") = "AHT"
            row("Actual") = dtsummary.Rows(0).Item("AHT")
            row("Target") = dtsummary.Rows(0).Item("AHTTarget")
            dt.Rows.Add(row)


            row = dt.NewRow
            row("Metrix") = "FAR %"
            row("Actual") = dtsummary.Rows(0).Item("Far %")
            row("Target") = dtsummary.Rows(0).Item("FARTarget")
            dt.Rows.Add(row)

            row = dt.NewRow
            row("Metrix") = "NFAR %"
            row("Actual") = dtsummary.Rows(0).Item("NFAR %")
            row("Target") = dtsummary.Rows(0).Item("NFARTarget")
            dt.Rows.Add(row)
            GridView2.DataSource = dt
            GridView2.DataBind()
            GridView2.Visible = True
        Else
            GridView2.DataSource = Nothing
            GridView2.DataBind()
            GridView2.Visible = True
            GridView2.BorderStyle = BorderStyle.None
            GridView2.BorderWidth = 0
            GridView2.Font.Size = 10
        End If


    End Sub

    Private Sub GetTop5FAR()

        Dim dt As New DataTable
        Dim startdt As DateTime = DateTime.Parse(cboYear.SelectedValue & "-" & cboMonth.SelectedValue & "-" & "01")
        Dim enddt As DateTime = startdt.AddMonths(1).AddDays(-1)
        StartDate = startdt.ToString("yyyyMMdd")
        EndDate = enddt.ToString("yyyyMMdd")

        'Dim db As New DBAccess("QualityNew")
        Dim db As New DBAccess
        Dim dtparam As DataTable
        db.slDataAdd("startdate", startdt.ToString("yyyyMMdd"))
        db.slDataAdd("endDate", enddt.ToString("yyyyMMdd"))
        db.slDataAdd("processid", CboProcess.SelectedValue)
        db.slDataAdd("campaignid", CampaignID)
        db.slDataAdd("ParamType", "F")
        dtparam = db.ReturnTable("usp_Parameterwisecount", , True)
        db = Nothing

        'first month
        If dtparam.Rows.Count > 0 Then

            dt = dtparam.Clone
            Dim row() As DataRow
            row = dtparam.Select("", "TotalErrorCount desc")
            Dim totalerrorcount As Integer = 0
            If row.Length >= 5 Then
                For i As Integer = 0 To 4
                    'row(i).Item(2) = row(i).Item(1) / totalerrorcount
                    dt.ImportRow(row(i))
                    totalerrorcount = totalerrorcount + row(i).Item(2)
                Next
            Else
                For Each row3 In row
                    dt.ImportRow(row3)
                    totalerrorcount = totalerrorcount + row3.Item(2)
                Next
            End If
            TCallMonitored = dt.Rows(0).Item(4)
            Dim j As Integer = 1
            For Each row2 As DataRow In dt.Rows
                row2.Item(0) = j
                If totalerrorcount = 0 Then
                    row2.Item(3) = 0
                Else
                    row2.Item(3) = Math.Round((row2.Item(2) / totalerrorcount) * 100.0, 2)
                End If
                If TCallMonitored = 0 Then
                    row2.Item(4) = 0
                Else
                    row2.Item(4) = Math.Round((row2.Item(2) / TCallMonitored) * 100.0, 2)
                End If

                j += 1
            Next
            Dim rowdt As DataRow = dt.NewRow
            rowdt.Item(1) = "Total Error Count"
            rowdt.Item(2) = totalerrorcount
            dt.Rows.Add(rowdt)
            rowdt = dt.NewRow
            rowdt.Item(1) = "Call Monitored"
            rowdt.Item(2) = TCallMonitored
            dt.Rows.Add(rowdt)
        End If


        GridView1.DataSource = dt
        GridView1.DataBind()

        GridView1.Visible = True


        ' GridView1.FooterRow.Visible = True
    End Sub

    Private Sub GetTop5NFAR()

        Dim startdt As DateTime = DateTime.Parse(cboYear.SelectedValue & "-" & cboMonth.SelectedValue & "-" & "01")
        Dim enddt As DateTime = startdt.AddMonths(1).AddDays(-1)
        StartDate = startdt.ToString("yyyyMMdd")
        EndDate = enddt.ToString("yyyyMMdd")

        ' Dim db As New DBAccess("QualityNew")
        Dim db As New DBAccess
        Dim dtparam As DataTable
        db.slDataAdd("startdate", startdt.ToString("yyyyMMdd"))
        db.slDataAdd("endDate", enddt.ToString("yyyyMMdd"))
        db.slDataAdd("processid", CboProcess.SelectedValue)
        db.slDataAdd("campaignid", CampaignID)
        db.slDataAdd("ParamType", "N")
        dtparam = db.ReturnTable("usp_Parameterwisecount", , True)
        db = Nothing
        If dtparam.Rows.Count > 0 Then

            Dim dt As New DataTable
            dt = dtparam.Clone
            Dim row() As DataRow
            row = dtparam.Select("", "TotalErrorCount desc")
            Dim totalerrorcount As Integer = 0
            If row.Length >= 5 Then
                For i As Integer = 0 To 4
                    'row(i).Item(2) = row(i).Item(1) / totalerrorcount
                    dt.ImportRow(row(i))
                    totalerrorcount = totalerrorcount + row(i).Item(2)
                Next
            Else
                For Each row3 In row
                    dt.ImportRow(row3)
                    totalerrorcount = totalerrorcount + row3.Item(2)
                Next
            End If
            TCallMonitored = dt.Rows(0).Item(4)
            Dim j As Integer = 1
            For Each row2 As DataRow In dt.Rows
                row2.Item(0) = j
                If totalerrorcount = 0 Then
                    row2.Item(3) = 0
                Else
                    row2.Item(3) = Math.Round((row2.Item(2) / totalerrorcount) * 100.0, 2)
                End If
                If TCallMonitored = 0 Then
                    row2.Item(4) = 0
                Else
                    row2.Item(4) = Math.Round((row2.Item(2) / TCallMonitored) * 100.0, 2)
                End If

                j += 1
            Next
            Dim rowdt As DataRow = dt.NewRow
            rowdt.Item(1) = "Total Error Count"
            rowdt.Item(2) = totalerrorcount
            dt.Rows.Add(rowdt)
            rowdt = dt.NewRow
            rowdt.Item(1) = "Call Monitored"
            rowdt.Item(2) = TCallMonitored
            dt.Rows.Add(rowdt)

            GridView1.DataSource = dt
            GridView1.DataBind()

            GridView1.Visible = True
        End If

        ' GridView1.FooterRow.Visible = True
    End Sub

    Private Sub GetConsolidatedFAR(ByVal tablecount As Integer, ByVal paramtype As String)

        Dim startdt As DateTime = DateTime.Parse(cboYear.SelectedValue & "-" & cboMonth.SelectedValue & "-" & "01")
        Dim enddt As DateTime = startdt.AddMonths(1).AddDays(-1)
        StartDate = startdt.AddMonths(-6).ToString("yyyyMMdd")
        EndDate = enddt.ToString("yyyyMMdd")


        ' Dim db As New DBAccess("QualityNew")
        Dim db As New DBAccess
        Dim ds As New DataSet
        'Dim dtparam(2) As DataTable
        db.slDataAdd("startdate", StartDate)
        db.slDataAdd("endDate", EndDate)
        db.slDataAdd("processid", CboProcess.SelectedValue)
        db.slDataAdd("campaignid", CampaignID)
        db.slDataAdd("ParamType", paramtype)
        ds = db.ReturnDataset("usp_Parameterwisecount", True)
        'dtparam(2) = db.ReturnTable("usp_Parameterwisecount", , True)
        db = Nothing
        If ds.Tables(tablecount).Rows.Count > 0 Then
            Dim dt As New DataTable
            dt = ds.Tables(tablecount).Clone
            ' dt.Columns.Add("% On Error Count")
            Dim row() As DataRow
            row = ds.Tables(tablecount).Select("", "TotalErrorCount desc")
            Dim totalerrorcount As Integer = 0
            For Each row1 As DataRow In row
                'row(i).Item(2) = row(i).Item(1) / totalerrorcount
                dt.ImportRow(row1)
                totalerrorcount = totalerrorcount + row1.Item(2)
            Next
            TCallMonitored = dt.Rows(0).Item(4)
            Dim j As Integer = 1
            For Each row2 As DataRow In dt.Rows
                row2.Item(0) = j
                If row2.Item(2) <> 0 Then
                    row2.Item(3) = Math.Round((row2.Item(2) / totalerrorcount) * 100.0, 2)
                    row2.Item(4) = Math.Round((row2.Item(2) / TCallMonitored) * 100.0, 2)
                Else
                    row2.Item(3) = 0
                    row2.Item(4) = 0
                End If
                j += 1
            Next
            Dim rowdt As DataRow = dt.NewRow
            rowdt.Item(1) = "Total Error Count"
            rowdt.Item(2) = totalerrorcount
            dt.Rows.Add(rowdt)
            rowdt = dt.NewRow
            rowdt.Item(1) = "Call Monitored"
            rowdt.Item(2) = TCallMonitored
            dt.Rows.Add(rowdt)
            GridView1.DataSource = dt
            GridView1.DataBind()

            GridView1.Visible = True
            dt = Nothing
            'GridView1.Columns.Item(1).ItemStyle.Width = "50"
        End If
        ds = Nothing
        ' GridView1.FooterRow.Visible = True
    End Sub
    Private Sub GetTeamLeaderWiseParameter()
        Dim startdt As DateTime = DateTime.Parse(cboYear.SelectedValue & "-" & cboMonth.SelectedValue & "-" & "01")
        Dim enddt As DateTime = startdt.AddMonths(1).AddDays(-1)
        StartDate = startdt.ToString("yyyyMMdd")
        EndDate = enddt.ToString("yyyyMMdd")
        'Dim dtsupervisor As New DataTable


        ' Dim db As New DBAccess("QualityNew")
        Dim db As New DBAccess
        db.slDataAdd("startdate", StartDate)
        db.slDataAdd("endDate", EndDate)
        db.slDataAdd("processid", CboProcess.SelectedValue)
        db.slDataAdd("campaignid", CampaignID)
        db.slDataAdd("userid", AgentID)
        dtsupervisor = db.ReturnTable("usp_getqualitySupervisor", , True)
        db = Nothing
        If dtsupervisor.Rows.Count > 0 Then
            Dim dtfinal As New DataTable
            Dim dt(dtsupervisor.Rows.Count - 1) As DataTable
            dtfinal.Columns.Add("S.no.")
            dtfinal.Columns.Add("Parameter Text")
            Dim c As Integer = 0
            For Each row1 As DataRow In dtsupervisor.Rows

                'db = New DBAccess("QualityNew")
                db = New DBAccess
                db.slDataAdd("startdate", StartDate)
                db.slDataAdd("endDate", EndDate)
                db.slDataAdd("processid", CboProcess.SelectedValue)
                db.slDataAdd("campaignid", CampaignID)
                db.slDataAdd("Supervisorid", row1.Item("supervisorid"))
                dt(c) = db.ReturnTable("usp_TeamLeaderwisecount", , True)
                db = Nothing

                Dim count As Integer = dt(c).Compute("sum(TotalErrorCount)", "")
                Dim cal As Integer = dt(c).Rows(0)("%OnCallMonitored")
                For Each row As DataRow In dt(c).Rows
                    If row("TotalErrorCount") <> 0 Then
                        row("%OnErrorCount") = Math.Round((row("TotalErrorCount") / count) * 100.0, 2)
                        row("%OnCallMonitored") = Math.Round((row("TotalErrorCount") / row("%OnCallMonitored")) * 100.0, 2)
                    Else
                        row("%OnErrorCount") = 0
                        row("%OnCallMonitored") = 0
                    End If

                Next
                For Each col As DataColumn In dt(c).Columns
                    If col.ColumnName <> "Parameter Text" And col.ColumnName <> "S.no." Then
                        col.ColumnName = "[ " & row1.Item("supervisorName") & " ] " & col.ColumnName.ToString
                        dtfinal.Columns.Add(col.ColumnName)
                    End If
                Next
                c += 1
            Next
            Dim i = 1, j As Integer
            For Each row As DataRow In dt(0).Rows
                Dim r As DataRow = dtfinal.NewRow
                r("S.no.") = i
                r("Parameter Text") = row("Parameter Text")
                For j = 0 To dt.Length - 1
                    Dim r1() As DataRow
                    r1 = dt(j).Select("[Parameter Text]='" & row("Parameter Text").ToString.Replace("'", "''") & "'")
                    For Each col As DataColumn In dt(j).Columns
                        If col.ColumnName <> "Parameter Text" And col.ColumnName <> "S.no." Then
                            If r1.Length <> 0 Then
                                r(col.ColumnName) = r1(0).Item(col.ColumnName)
                            Else
                                r(col.ColumnName) = 0
                            End If
                        End If
                    Next
                Next j
                i += 1
                dtfinal.Rows.Add(r)
            Next
            GridView1.DataSource = dtfinal
            GridView1.DataBind()
            GridView1.Visible = True
            dtfinal = Nothing
        Else
            GridView1.DataSource = Nothing
            GridView1.DataBind()
            GridView1.Visible = True
        End If

    End Sub
    Private Sub GetTeamLeaderWiseSummary()
        'Dim monthname1, monthname2, monthname3 As String
        Dim startdt As DateTime = DateTime.Parse(cboYear.SelectedValue & "-" & cboMonth.SelectedValue & "-" & "01")
        Dim enddt As DateTime = startdt.AddMonths(1).AddDays(-1)
        'StartDate = startdt.ToString("yyyyMMdd")
        EndDate = enddt.ToString("yyyyMMdd")
        Monthname1 = startdt.ToString("MMM")

        ' Dim db As New DBAccess("QualityNew")
        Dim db As New DBAccess

        Dim dtfinal, dt1, dt2, dt3 As New DataTable
        db.slDataAdd("startdate", startdt.ToString("yyyyMMdd"))
        db.slDataAdd("endDate", enddt.ToString("yyyyMMdd"))
        db.slDataAdd("processid", CboProcess.SelectedValue)
        db.slDataAdd("campaignid", CampaignID)
        dt1 = db.ReturnTable("usp_TeamLeaderSummary", , True)
        db = Nothing
        For Each col As DataColumn In dt1.Columns
            If col.ColumnName <> "Team Leader" Then
                col.ColumnName = Monthname1 & " " & col.ColumnName.ToString
            End If
        Next
        dtfinal = dt1.Clone
        ' StartDate = startdt.AddMonths(-1).ToString("yyyyMMdd")
        ' EndDate = enddt.AddMonths(-1).ToString("yyyyMMdd")
        Monthname2 = startdt.AddMonths(-1).ToString("MMM")


        ' db = New DBAccess("QualityNew")
        db = New DBAccess
        db.slDataAdd("startdate", startdt.AddMonths(-1).ToString("yyyyMMdd"))
        db.slDataAdd("endDate", enddt.AddMonths(-1).ToString("yyyyMMdd"))
        db.slDataAdd("processid", CboProcess.SelectedValue)
        db.slDataAdd("campaignid", CampaignID)
        dt2 = db.ReturnTable("usp_TeamLeaderSummary", , True)
        db = Nothing
        For Each col As DataColumn In dt2.Columns
            If col.ColumnName <> "Team Leader" Then
                col.ColumnName = Monthname2 & " " & col.ColumnName
                dtfinal.Columns.Add(col.ColumnName)
            End If
        Next
        StartDate = startdt.AddMonths(-2).ToString("yyyyMMdd")
        'EndDate = enddt.AddMonths(-2).ToString("yyyyMMdd")
        Monthname3 = startdt.AddMonths(-2).ToString("MMM")

        ' db = New DBAccess("QualityNew")
        db = New DBAccess
        db.slDataAdd("startdate", startdt.AddMonths(-2).ToString("yyyyMMdd"))
        db.slDataAdd("endDate", enddt.AddMonths(-2).ToString("yyyyMMdd"))
        db.slDataAdd("processid", CboProcess.SelectedValue)
        db.slDataAdd("campaignid", CampaignID)
        dt3 = db.ReturnTable("usp_TeamLeaderSummary", , True)
        db = Nothing
        For Each col As DataColumn In dt3.Columns
            If col.ColumnName <> "Team Leader" Then
                col.ColumnName = Monthname3 & " " & col.ColumnName
                dtfinal.Columns.Add(col.ColumnName)
            End If
        Next
        Dim i As Integer = 1
        For Each row As DataRow In dt1.Rows
            Dim r3(), r2() As DataRow
            r2 = dt2.Select("[Team Leader]='" & row("Team Leader") & "'")
            r3 = dt3.Select("[Team Leader]='" & row("Team Leader") & "'")
            Dim r As DataRow = dtfinal.NewRow

            r("Team Leader") = row("Team Leader")
            For Each col As DataColumn In dt1.Columns
                If col.ColumnName <> "Team Leader" Then
                    r(col.ColumnName) = row.Item(col.ColumnName)
                End If
            Next
            For Each col As DataColumn In dt2.Columns
                If col.ColumnName <> "Team Leader" Then
                    If r2.Length <> 0 Then
                        r(col.ColumnName) = r2(0).Item(col.ColumnName)
                    Else
                        r(col.ColumnName) = 0
                    End If
                End If
            Next
            For Each col As DataColumn In dt3.Columns
                If col.ColumnName <> "Team Leader" Then
                    If r3.Length <> 0 Then
                        r(col.ColumnName) = r3(0).Item(col.ColumnName)
                    Else
                        r(col.ColumnName) = 0
                    End If
                End If
            Next
            i += 1
            dtfinal.Rows.Add(r)

        Next

        GridView1.DataSource = dtfinal
        GridView1.DataBind()
        GridView1.Visible = True

        dtfinal = Nothing
    End Sub
    Private Sub GetParamTrend(ByVal paramtype As String)
        ' Dim monthname1, monthname2, monthname3 As String
        Dim count, count2, count3, cal, cal2, cal3 As Integer
        Dim startdt As DateTime = DateTime.Parse(cboYear.SelectedValue & "-" & cboMonth.SelectedValue & "-" & "01")
        Dim enddt As DateTime = startdt.AddMonths(1).AddDays(-1)
        'StartDate = startdt.ToString("yyyyMMdd")
        EndDate = enddt.ToString("yyyyMMdd")
        Monthname1 = startdt.ToString("MMM")

        ' Dim db As New DBAccess("QualityNew")
        Dim db As New DBAccess
        Dim dtfinal, dt1, dt2, dt3 As New DataTable
        db.slDataAdd("startdate", startdt.ToString("yyyyMMdd"))
        db.slDataAdd("endDate", enddt.ToString("yyyyMMdd"))
        db.slDataAdd("processid", CboProcess.SelectedValue)
        db.slDataAdd("campaignid", cboCampaigns.SelectedValue)
        db.slDataAdd("ParamType", paramtype)
        dt1 = db.ReturnTable("usp_Parameterwisecount", , True)
        db = Nothing
        If dt1.Rows.Count > 0 Then
            count = dt1.Compute("sum(TotalErrorCount)", "")
            cal = dt1.Rows(0)("%OnCallMonitored")
            For Each row As DataRow In dt1.Rows
                If row("TotalErrorCount") <> 0 Then
                    row("%OnErrorCount") = Math.Round((row("TotalErrorCount") / count) * 100.0, 2)
                    row("%OnCallMonitored") = Math.Round((row("TotalErrorCount") / row("%OnCallMonitored")) * 100.0, 2)
                Else
                    row("%OnErrorCount") = 0
                    row("%OnCallMonitored") = 0
                End If

            Next
        End If

        For Each col As DataColumn In dt1.Columns
            If col.ColumnName <> "Parameter Text" And col.ColumnName <> "S.no." Then
                col.ColumnName = Monthname1 & " " & col.ColumnName.ToString
            End If
        Next
        dtfinal = dt1.Clone
        'StartDate = startdt.AddMonths(-1).ToString("yyyyMMdd")
        'EndDate = enddt.AddMonths(-1).ToString("yyyyMMdd")
        Monthname2 = startdt.AddMonths(-1).ToString("MMM")

        'db = New DBAccess("QualityNew")
        db = New DBAccess
        db.slDataAdd("startdate", startdt.AddMonths(-1).ToString("yyyyMMdd"))
        db.slDataAdd("endDate", enddt.AddMonths(-1).ToString("yyyyMMdd"))
        db.slDataAdd("processid", CboProcess.SelectedValue)
        db.slDataAdd("campaignid", cboCampaigns.SelectedValue)
        db.slDataAdd("ParamType", paramtype)
        dt2 = db.ReturnTable("usp_Parameterwisecount", , True)
        db = Nothing
        If dt2.Rows.Count > 0 Then
            count2 = dt2.Compute("sum(TotalErrorCount)", "")
            cal2 = dt2.Rows(0)("%OnCallMonitored")
            For Each row As DataRow In dt2.Rows
                If row("TotalErrorCount") <> 0 Then
                    row("%OnErrorCount") = Math.Round((row("TotalErrorCount") / count2) * 100.0, 2)
                    row("%OnCallMonitored") = Math.Round((row("TotalErrorCount") / row("%OnCallMonitored")) * 100.0, 2)
                Else
                    row("%OnErrorCount") = 0
                    row("%OnCallMonitored") = 0
                End If

            Next
        End If

        For Each col As DataColumn In dt2.Columns
            If col.ColumnName <> "Parameter Text" And col.ColumnName <> "S.no." Then
                col.ColumnName = Monthname2 & " " & col.ColumnName
                dtfinal.Columns.Add(col.ColumnName)
            End If
        Next
        StartDate = startdt.AddMonths(-2).ToString("yyyyMMdd")
        'EndDate = enddt.AddMonths(-2).ToString("yyyyMMdd")
        Monthname3 = startdt.AddMonths(-2).ToString("MMM")

        ' db = New DBAccess("QualityNew")
        db = New DBAccess
        db.slDataAdd("startdate", startdt.AddMonths(-2).ToString("yyyyMMdd"))
        db.slDataAdd("endDate", enddt.AddMonths(-2).ToString("yyyyMMdd"))
        db.slDataAdd("processid", CboProcess.SelectedValue)
        db.slDataAdd("campaignid", cboCampaigns.SelectedValue)
        db.slDataAdd("ParamType", paramtype)
        dt3 = db.ReturnTable("usp_Parameterwisecount", , True)
        db = Nothing
        If dt3.Rows.Count > 0 Then
            count3 = dt3.Compute("sum(TotalErrorCount)", "")
            cal3 = dt3.Rows(0)("%OnCallMonitored")
            For Each row As DataRow In dt3.Rows
                If row("TotalErrorCount") <> 0 Then
                    row("%OnErrorCount") = Math.Round((row("TotalErrorCount") / count3) * 100.0, 2)
                    row("%OnCallMonitored") = Math.Round((row("TotalErrorCount") / row("%OnCallMonitored")) * 100.0, 2)
                Else
                    row("%OnErrorCount") = 0
                    row("%OnCallMonitored") = 0
                End If

            Next
        End If

        For Each col As DataColumn In dt3.Columns
            If col.ColumnName <> "Parameter Text" And col.ColumnName <> "S.no." Then
                col.ColumnName = Monthname3 & " " & col.ColumnName
                dtfinal.Columns.Add(col.ColumnName)
            End If
        Next
        Dim i As Integer = 1

        For Each row As DataRow In dt1.Rows
            Dim r3(), r2() As DataRow
            r2 = dt2.Select("[Parameter Text]='" & row("Parameter Text").ToString.Replace("'", "''") & "'")
            r3 = dt3.Select("[Parameter Text]='" & row("Parameter Text").ToString.Replace("'", "''") & "'")
            Dim r As DataRow = dtfinal.NewRow
            r("S.no.") = i
            r("Parameter Text") = row("Parameter Text")
            For Each col As DataColumn In dt1.Columns
                If col.ColumnName <> "Parameter Text" And col.ColumnName <> "S.no." Then
                    r(col.ColumnName) = row.Item(col.ColumnName)
                End If
            Next
            For Each col As DataColumn In dt2.Columns
                If col.ColumnName <> "Parameter Text" And col.ColumnName <> "S.no." Then
                    If r2.Length <> 0 Then
                        r(col.ColumnName) = r2(0).Item(col.ColumnName)
                    Else
                        r(col.ColumnName) = 0
                    End If
                End If
            Next
            For Each col As DataColumn In dt3.Columns
                If col.ColumnName <> "Parameter Text" And col.ColumnName <> "S.no." Then
                    If r3.Length <> 0 Then
                        r(col.ColumnName) = r3(0).Item(col.ColumnName)
                    Else
                        r(col.ColumnName) = 0
                    End If
                End If
            Next
            i += 1
            dtfinal.Rows.Add(r)
        Next
        Dim rowdt As DataRow = dtfinal.NewRow
        If count <> 0 And count2 <> 0 And count3 <> 0 Then
            rowdt.Item("Parameter Text") = "Total Error Count"
            rowdt.Item(Monthname1 & " " & "TotalErrorCount") = count
            rowdt.Item(Monthname2 & " " & "TotalErrorCount") = count2
            rowdt.Item(Monthname3 & " " & "TotalErrorCount") = count3
            dtfinal.Rows.Add(rowdt)
        End If
        If cal <> 0 And cal2 <> 0 And cal3 <> 0 Then
            rowdt = dtfinal.NewRow
            rowdt.Item("Parameter Text") = "Call Monitored"
            rowdt.Item(Monthname1 & " " & "TotalErrorCount") = cal
            rowdt.Item(Monthname2 & " " & "TotalErrorCount") = cal2
            rowdt.Item(Monthname3 & " " & "TotalErrorCount") = cal3
            dtfinal.Rows.Add(rowdt)
        End If
        GridView1.DataSource = dtfinal
        GridView1.DataBind()
        GridView1.Visible = True
        dtfinal = Nothing
        'End If

    End Sub

    Private Sub GetLegendNFAR()
        Dim startdt As DateTime = DateTime.Parse(cboYear.SelectedValue & "-" & cboMonth.SelectedValue & "-" & "01")
        Dim enddt As DateTime = startdt.AddMonths(1).AddDays(-1)
        StartDate = startdt.ToString("yyyyMMdd")
        EndDate = enddt.ToString("yyyyMMdd")


        '  Dim db As New DBAccess("QualityNew")
        Dim db As New DBAccess
        Dim dtparam As DataTable
        db.slDataAdd("startdate", StartDate)
        db.slDataAdd("endDate", EndDate)
        db.slDataAdd("processid", CboProcess.SelectedValue)
        db.slDataAdd("campaignid", CampaignID)
        db.slDataAdd("ParamType", "N")
        dtparam = db.ReturnTable("usp_Parameterwisecount", , True)
        db = Nothing
        If dtparam.Rows.Count > 0 Then
            Dim dt As New DataTable
            dt = dtparam.Clone
            dt.Columns.Add("Cummulative")
            Dim row() As DataRow
            row = dtparam.Select("", "TotalErrorCount desc")
            Dim totalerrorcount As Integer = 0

            For Each row1 As DataRow In row
                'row(i).Item(2) = row(i).Item(1) / totalerrorcount
                dt.ImportRow(row1)
                totalerrorcount = totalerrorcount + row1.Item(2)
            Next
            TCallMonitored = dt.Rows(0).Item(4)
            Dim j As Integer = 65
            Dim k As Integer
            For Each row2 As DataRow In dt.Rows
                If j <= 90 Then
                    row2.Item(0) = Char.ConvertFromUtf32(j)
                Else
                    k = j - 26

                    row2.Item(0) = Char.ConvertFromUtf32(k) + Char.ConvertFromUtf32(k)
                End If
                If totalerrorcount = 0 Then
                    row2.Item(3) = 0
                Else
                    row2.Item(3) = Math.Round((row2.Item(2) / totalerrorcount) * 100.0, 2)
                End If
                If TCallMonitored = 0 Then
                    row2.Item(4) = 0
                Else
                    row2.Item(4) = Math.Round((row2.Item(2) / TCallMonitored) * 100.0, 2)
                End If

                j += 1
            Next
            dt.Rows(0).Item(5) = dt.Rows(0).Item(3)
            For m As Integer = 1 To dt.Rows.Count - 1
                dt.Rows(m).Item(5) = dt.Rows(m).Item(3) + dt.Rows(m - 1).Item(5)
                If dt.Rows(m).Item(5) > 100 Then dt.Rows(m).Item(5) = 100 'last item should be 100
            Next
            If dt.Rows(dt.Rows.Count - 1).Item(5) < 100 Then dt.Rows(dt.Rows.Count - 1).Item(5) = 100 'last item should be 100

            Dim rowdt As DataRow = dt.NewRow
            rowdt.Item(1) = "Total Error Count"
            rowdt.Item(2) = totalerrorcount
            dt.Rows.Add(rowdt)
            rowdt = dt.NewRow
            rowdt.Item(1) = "Call Monitored"
            rowdt.Item(2) = TCallMonitored
            dt.Rows.Add(rowdt)

            GridView1.DataSource = dt
            GridView1.DataBind()

            GridView1.HeaderRow.Cells(0).Text = "Legends"
            GridView1.Visible = True

            'draw the pareto
            Chart1.Visible = True
            With Chart1
                .Series.Clear()
                .Series.Add("Error Count")
                .Series.Add("Cummulative")
                With .Series(0)
                    .XValueMember = "S.no."
                    .YValueMembers = "totalerrorcount"

                    .YAxisType = DataVisualization.Charting.AxisType.Primary

                    .ChartType = DataVisualization.Charting.SeriesChartType.Column
                    .BorderWidth = 4
                    .Color = Drawing.Color.Blue
                    .BackGradientStyle = DataVisualization.Charting.GradientStyle.VerticalCenter
                    .BackSecondaryColor = Drawing.Color.SkyBlue
                    '.MarkerStyle = DataVisualization.Charting.MarkerStyle.Diamond
                    '.MarkerSize = 6
                    '.MarkerColor = Drawing.Color.White
                    .IsValueShownAsLabel = True
                End With
                With .Series(1)
                    .XValueMember = "S.no."
                    .YValueMembers = "Cummulative"
                    .YAxisType = DataVisualization.Charting.AxisType.Secondary

                    .ChartType = DataVisualization.Charting.SeriesChartType.Line
                    .BorderWidth = 2
                    .Color = Drawing.Color.Red
                    .MarkerStyle = DataVisualization.Charting.MarkerStyle.Diamond
                    .MarkerSize = 6
                    .MarkerColor = Drawing.Color.Yellow
                    .IsValueShownAsLabel = True
                End With
                .Legends(0).Docking = DataVisualization.Charting.Docking.Bottom
                .ChartAreas(0).AxisX.MajorGrid.Enabled = False
                .ChartAreas(0).AxisY.MajorGrid.Enabled = False
                .ChartAreas(0).AxisX.Interval = 1
                .ChartAreas(0).AxisX2.Interval = 1
                .ChartAreas(0).AxisX.IntervalAutoMode = DataVisualization.Charting.IntervalAutoMode.FixedCount
                .ChartAreas(0).AxisX2.IntervalAutoMode = DataVisualization.Charting.IntervalAutoMode.FixedCount
                .ChartAreas(0).AxisY2.MajorGrid.Enabled = False
                .DataSource = dt.DefaultView
                .DataBind()
            End With
        Else
            GridView1.DataSource = Nothing
            GridView1.DataBind()
            GridView1.Visible = True
        End If
    End Sub
    Private Sub GetLegendEUSAT()
        Dim startdt As DateTime = DateTime.Parse(cboYear.SelectedValue & "-" & cboMonth.SelectedValue & "-" & "01")
        Dim enddt As DateTime = startdt.AddMonths(1).AddDays(-1)
        StartDate = startdt.ToString("yyyyMMdd")
        EndDate = enddt.ToString("yyyyMMdd")
        Dim db As New DBAccess("Report")
        Dim dtparam As DataTable
        db.slDataAdd("startdate", StartDate)
        db.slDataAdd("endDate", EndDate)
        db.slDataAdd("processid", CboProcess.SelectedValue)
        db.slDataAdd("campaignid", CampaignID)
        'db.slDataAdd("ParamType", "N")
        dtparam = db.ReturnTable("usp_EUSATwisecount", , True)
        db = Nothing
        If dtparam.Rows.Count > 0 Then
            Dim dt As New DataTable
            dt = dtparam.Clone
            dt.Columns.Add("Cummulative")
            Dim row() As DataRow
            row = dtparam.Select("", "TotalComplaintCount desc")
            Dim totalerrorcount As Integer = 0

            For Each row1 As DataRow In row
                'row(i).Item(2) = row(i).Item(1) / totalerrorcount
                dt.ImportRow(row1)
                totalerrorcount = totalerrorcount + row1.Item(2)
            Next
            ' TCallMonitored = dt.Rows(0).Item(4)
            Dim j As Integer = 65
            Dim k As Integer
            For Each row2 As DataRow In dt.Rows
                If j <= 90 Then
                    row2.Item(0) = Char.ConvertFromUtf32(j)
                Else
                    k = j - 26

                    row2.Item(0) = Char.ConvertFromUtf32(k) + Char.ConvertFromUtf32(k)
                End If
                If totalerrorcount = 0 Then
                    row2.Item(3) = 0
                Else
                    row2.Item(3) = Math.Round((row2.Item(2) / totalerrorcount) * 100.0, 2)
                End If
                'If TCallMonitored = 0 Then
                '    row2.Item(4) = 0
                'Else
                '    row2.Item(4) = Math.Round((row2.Item(2) / TCallMonitored) * 100.0, 2)
                'End If

                j += 1
            Next
            dt.Rows(0).Item(4) = dt.Rows(0).Item(3)
            For m As Integer = 1 To dt.Rows.Count - 1
                dt.Rows(m).Item(4) = dt.Rows(m).Item(3) + dt.Rows(m - 1).Item(4)
                If dt.Rows(m).Item(4) > 100 Then dt.Rows(m).Item(4) = 100 'last item should be 100
            Next
            If dt.Rows(dt.Rows.Count - 1).Item(4) < 100 Then dt.Rows(dt.Rows.Count - 1).Item(4) = 100 'last item should be 100

            Dim rowdt As DataRow = dt.NewRow
            rowdt.Item(1) = "Total Complaint Count"
            rowdt.Item(2) = totalerrorcount
            dt.Rows.Add(rowdt)
            'rowdt = dt.NewRow
            'rowdt.Item(1) = "Call Monitored"
            'rowdt.Item(2) = TCallMonitored
            'dt.Rows.Add(rowdt)

            GridView1.DataSource = dt
            GridView1.DataBind()

            GridView1.HeaderRow.Cells(0).Text = "Legends"
            GridView1.Visible = True

            'draw the pareto
            Chart1.Visible = True
            With Chart1
                .Series.Clear()
                .Series.Add("Error Count")
                .Series.Add("Cummulative")
                With .Series(0)
                    .XValueMember = "S.no."
                    .YValueMembers = "totalComplaintcount"

                    .YAxisType = DataVisualization.Charting.AxisType.Primary

                    .ChartType = DataVisualization.Charting.SeriesChartType.Column
                    .BorderWidth = 4
                    .Color = Drawing.Color.Blue
                    .BackGradientStyle = DataVisualization.Charting.GradientStyle.VerticalCenter
                    .BackSecondaryColor = Drawing.Color.SkyBlue
                    '.MarkerStyle = DataVisualization.Charting.MarkerStyle.Diamond
                    '.MarkerSize = 6
                    '.MarkerColor = Drawing.Color.White
                    .IsValueShownAsLabel = True
                End With
                With .Series(1)
                    .XValueMember = "S.no."
                    .YValueMembers = "Cummulative"
                    .YAxisType = DataVisualization.Charting.AxisType.Secondary

                    .ChartType = DataVisualization.Charting.SeriesChartType.Line
                    .BorderWidth = 2
                    .Color = Drawing.Color.Red
                    .MarkerStyle = DataVisualization.Charting.MarkerStyle.Diamond
                    .MarkerSize = 6
                    .MarkerColor = Drawing.Color.Yellow
                    .IsValueShownAsLabel = True
                End With
                .Legends(0).Docking = DataVisualization.Charting.Docking.Bottom
                .ChartAreas(0).AxisX.MajorGrid.Enabled = False
                .ChartAreas(0).AxisY.MajorGrid.Enabled = False
                .ChartAreas(0).AxisX.Interval = 1
                .ChartAreas(0).AxisX2.Interval = 1
                .ChartAreas(0).AxisX.IntervalAutoMode = DataVisualization.Charting.IntervalAutoMode.FixedCount
                .ChartAreas(0).AxisX2.IntervalAutoMode = DataVisualization.Charting.IntervalAutoMode.FixedCount
                .ChartAreas(0).AxisY2.MajorGrid.Enabled = False
                .DataSource = dt.DefaultView
                .DataBind()
            End With
        Else
            GridView1.DataSource = Nothing
            GridView1.DataBind()


            GridView1.Visible = True
        End If
    End Sub
    Protected Sub ImageButton1_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton1.Click
        '  PopulateCMF()
        'GridViewExportUtil.Export(lblReportName.Text & "-" & LblError.Text & ".xls", Me.GridView1)
        'Dim gv As New GridView
        'gv.DataSource = dtnew
        'gv.DataBind()
        'GridViewExportUtil.Export("QualitySummaryReportPerAgentWise" & ".xls", gv)

        Response.Clear()
        Response.Buffer = True
        Response.AddHeader("content-disposition", "attachment;filename=ChartExport.xls")
        Response.ContentType = "application/vnd.ms-excel"
        Response.Charset = ""
        Dim sw As New StringWriter()
        Dim hw As New HtmlTextWriter(sw)
        Chart1.RenderControl(hw)
        Dim src As String = Regex.Match(sw.ToString(), "<img.+?src=[""'](.+?)[""'].+?>", RegexOptions.IgnoreCase).Groups(1).Value
        Dim table As String = "<table><tr><td><img src='{0}' /></td></tr></table>"
        table = String.Format(table, Request.Url.GetLeftPart(UriPartial.Authority) + src)
        Response.Write(table)
        Response.Flush()
        Response.End()
    End Sub

    Private Sub RenderChart()
        With Chart1

            .Visible = True
            With .ChartAreas(0)
                .AxisX.MajorGrid.Enabled = False
                .AxisY.MajorGrid.Enabled = False
                '.AxisY.Interval = 1
                .AxisY.IsStartedFromZero = False
                .AxisX.IsStartedFromZero = False
                .AxisX.Title = "Month"
                Select Case ChartCase
                    Case ChartItem.CPH
                        .AxisY.Title = "Minutes"
                    Case ChartItem.AHT
                        .AxisY.Title = "Seconds"
                    Case 2, 3
                        .AxisY.Title = "%"
                End Select


            End With

            .TextAntiAliasingQuality = DataVisualization.Charting.TextAntiAliasingQuality.High
            .Series.Clear()
            .Series.Add("Tenured")
            .Series.Add("Non Tenured")
            .Series.Add("Target")
            For Each obj As System.Web.UI.DataVisualization.Charting.Series In .Series
                obj.XValueMember = "Month"
                obj.ChartType = DataVisualization.Charting.SeriesChartType.Spline
                obj.BorderWidth = 2
                obj.Color = Drawing.Color.Blue
                obj.MarkerStyle = DataVisualization.Charting.MarkerStyle.Diamond
                obj.MarkerSize = 6
                obj.MarkerColor = Drawing.Color.White
                obj.IsValueShownAsLabel = True


            Next
            .Series("Target").ChartType = DataVisualization.Charting.SeriesChartType.Line
            .Series("Target").BorderDashStyle = DataVisualization.Charting.ChartDashStyle.Dash
            .Series("Target").BorderWidth = 2
            .Series("Target").Color = Drawing.Color.Green

            .Series("Tenured").Color = Drawing.Color.Orange
            .Series("Non Tenured").Color = Drawing.Color.Yellow
            ' Set legend style
            .Legends(0).Docking = DataVisualization.Charting.Docking.Bottom
            .Legends(0).LegendStyle = DataVisualization.Charting.LegendStyle.Table

            ' Set table style if legend style is Table
            .Legends(0).TableStyle = DataVisualization.Charting.LegendTableStyle.Auto
            .ChartAreas(0).AxisX.IntervalType = DataVisualization.Charting.IntervalType.Months
            .ChartAreas(0).AxisX.IntervalAutoMode = DataVisualization.Charting.IntervalAutoMode.FixedCount
            .ChartAreas(0).AxisX.LabelStyle.Format = "MMM yy"
            Dim db As DBAccess
            Dim dt As DataTable
            Dim MonthStartDate As DateTime = DateTime.Parse(cboYear.SelectedValue & "-" & cboMonth.SelectedValue & "-" & "01")
            Dim MonthEndDate As DateTime = MonthStartDate.AddMonths(1).AddDays(-1)
            .Series.Add(ChartCase.ToString)
            With .Series(ChartCase.ToString)
                .IsValueShownAsLabel = True
                .ChartType = DataVisualization.Charting.SeriesChartType.Spline
                .Color = Drawing.Color.Blue
                .XValueMember = "Month"
                .YValueMembers = ChartCase.ToString
                .BorderWidth = 2
            End With

            .Series("Tenured").YValueMembers = ChartCase.ToString & " Tenured"
            .Series("Non Tenured").YValueMembers = ChartCase.ToString & " NonTenured"
            .Series("Target").YValueMembers = ChartCase.ToString & "Target"

            'Select Case ChartCase
            '    Case ChartItem.CPH 'CPH
            '        .Series.Add(ChartItem.CPH.ToString)
            '        With .Series("CPH")
            '            .IsValueShownAsLabel = True
            '            .ChartType = DataVisualization.Charting.SeriesChartType.Line
            '            .Color = Drawing.Color.Blue
            '            .XValueMember = "Month"
            '            .YValueMembers = "CPH"
            '        End With

            '        .Series("Tenured").YValueMembers = "CPH Tenured"
            '        .Series("Non Tenured").YValueMembers = "CPH NonTenured"
            '        .Series("Target").YValueMembers = "CPHTarget"

            '    Case ChartItem.AHT 'AHT
            '        .Series.Add(ChartCase.ToString)
            '        .Series("AHT").ChartType = DataVisualization.Charting.SeriesChartType.Line
            '        .Series("AHT").Color = Drawing.Color.Blue
            '        .Series("AHT").XValueMember = "Month"
            '        .Series("AHT").YValueMembers = "AHT"
            '        .Series("Tenured").YValueMembers = "AHT Tenured"
            '        .Series("Non Tenured").YValueMembers = "AHT NonTenured"
            '        .Series("Target").YValueMembers = "AHTTarget"


            '    Case ChartItem.FAR 'FAR
            '        .Series.Add("FAR")
            '        .Series("FAR").ChartType = DataVisualization.Charting.SeriesChartType.Spline
            '        .Series("FAR").Color = Drawing.Color.Blue
            '        .Series("FAR").XValueMember = "Month"
            '        .Series("FAR").YValueMembers = "FAR"
            '        .Series("Tenured").YValueMembers = "FAR Tenured"
            '        .Series("Non Tenured").YValueMembers = "FAR NonTenured"
            '        .Series("Target").YValueMembers = "FARTarget"
            '        'get data

            '        'bind chart

            '    Case ChartItem.NFAR
            '        .Series.Add("NFAR")
            '        .Series("NFAR").ChartType = DataVisualization.Charting.SeriesChartType.Line
            '        .Series("NFAR").Color = Drawing.Color.Blue
            '        .Series("NFAR").XValueMember = "Month"
            '        .Series("NFAR").YValueMembers = "NFAR"
            '        .Series("Tenured").YValueMembers = "NFAR Tenured"
            '        .Series("Non Tenured").YValueMembers = "NFAR NonTenured"
            '        .Series("Target").YValueMembers = "NFARTarget"


            'End Select

            'get data
            Select Case ChartCase
                Case ChartItem.AHT, ChartItem.CPH
                    'Get Data
                    StartDate = MonthStartDate.AddMonths(-6).ToString("yyyyMMdd")
                    EndDate = MonthEndDate.ToString("yyyyMMdd")
                    db = New DBAccess
                    db.slDataAdd("startdate", StartDate)
                    db.slDataAdd("endDate", EndDate)
                    '@20210128 comment
                    db.slDataAdd("processid", CboProcess.SelectedValue)
                    db.slDataAdd("campaignid", CampaignID)

                    '@20210128 Add
                    'db.slDataAdd("groupBy", "3")
                    'dt = db.ReturnTable("[usp_GetKPIChart]", , True)
                    'If GroupBy = 3 Then 'that is day
                    '    dt.Columns.Add("Day", System.Type.GetType("System.DateTime"), "groupname")
                    'End If


                    '@20210128 comment
                    dt = db.ReturnTable("[usp_DashboardSummaryPerf_MonthWise]", , True)
                    db = Nothing
                Case ChartItem.FAR, ChartItem.NFAR
                    StartDate = MonthStartDate.AddMonths(-6).ToString("yyyyMMdd")
                    EndDate = MonthEndDate.ToString("yyyyMMdd")
                    db = New DBAccess '("TermsMonitor")
                    db.slDataAdd("startdate", StartDate)
                    db.slDataAdd("endDate", EndDate)
                    db.slDataAdd("processid", CboProcess.SelectedValue)
                    db.slDataAdd("campaignid", CampaignID)
                    'dt = db.ReturnTable("[usp_DashboardSummaryPerf_MonthWiseQuality]", , True)
                    dt = db.ReturnTable("[usp_DashboardSummaryPerf_MonthWise]", , True)
                    db = Nothing
            End Select
            'bind chart
            .DataSource = dt.DefaultView
            .DataBind()
        End With
    End Sub
    Private Sub GetQuizResult()
        Dim db As New DBAccess
        Dim dtquiz As DataTable
        db.slDataAdd("Month", cboMonth.SelectedValue)
        db.slDataAdd("Year", cboYear.SelectedValue)
        db.slDataAdd("processid", ProcessID)
        db.slDataAdd("campaignid", CampaignID)
        dtquiz = db.ReturnTable("usp_QuizeResult", , True)
        db = Nothing
        Dim total As Integer
        total = dtquiz.Rows(0).Item(0)
        Dim dt As New DataTable
        If total <> 0 Then
            dt.Columns.Add("Metrix", System.Type.GetType("System.String"))
            dt.Columns.Add("Result", System.Type.GetType("System.String"))
            Dim row As DataRow
            row = dt.NewRow
            row("Metrix") = "Total"
            row("Result") = dtquiz.Rows(0).Item("Total")
            dt.Rows.Add(row)

            row = dt.NewRow
            row("Metrix") = "Total Appeared"
            row("Result") = dtquiz.Rows(0).Item("Total Appeared")
            dt.Rows.Add(row)

            row = dt.NewRow
            row("Metrix") = "Total Passed"
            row("Result") = dtquiz.Rows(0).Item("Total Passed")
            dt.Rows.Add(row)

            row = dt.NewRow
            row("Metrix") = "Total Failed"
            row("Result") = dtquiz.Rows(0).Item("Total Failed")
            dt.Rows.Add(row)

            row = dt.NewRow
            row("Metrix") = "Passing Marks(%)"
            row("Result") = dtquiz.Rows(0).Item("Passing Marks(%)")
            dt.Rows.Add(row)

            row = dt.NewRow
            row("Metrix") = "TMs Passed(%)"
            row("Result") = dtquiz.Rows(0).Item("TMs Passed(%)")
            dt.Rows.Add(row)

            row = dt.NewRow
            row("Metrix") = "TMs Appeard(Retest)"
            row("Result") = dtquiz.Rows(0).Item("TMs Appeard(Retest)")
            dt.Rows.Add(row)

            row = dt.NewRow
            row("Metrix") = "TMs Passed(Retest)"
            row("Result") = dtquiz.Rows(0).Item("TMs Passed(Retest)")
            dt.Rows.Add(row)

            row = dt.NewRow
            row("Metrix") = "Leave/Resigned/Process Change"
            row("Result") = dtquiz.Rows(0).Item("Leave/Resigned/Process Change")
            dt.Rows.Add(row)
        Else
            GridView2.BorderStyle = BorderStyle.None
            GridView2.BorderWidth = 0
            GridView2.Font.Size = 10
        End If


        GridView2.DataSource = dt
        GridView2.DataBind()
        If total <> 0 Then
            GridView2.HeaderRow.Cells.RemoveAt(1)
            GridView2.HeaderRow.Cells(0).Text = "Quiz Result"
            GridView2.HeaderRow.Cells(0).ColumnSpan = 2
        End If
        'GridView2.HeaderRow.Cells.RemoveAt(1)
        'GridView2.HeaderRow.Visible = False
        'GridView1.Caption = "Quiz Result for " & MonthName(cboMonth.SelectedValue) & " " & cboYear.SelectedValue
        GridView2.Visible = True
    End Sub
    Private Function getTMParameterWiseFAR(ByVal paramtype As Char) As DataTable()
        Dim startdt As DateTime = DateTime.Parse(cboYear.SelectedValue & "-" & cboMonth.SelectedValue & "-" & "01")
        Dim enddt As DateTime = startdt.AddMonths(1).AddDays(-1)
        StartDate = startdt.ToString("yyyyMMdd")
        EndDate = enddt.ToString("yyyyMMdd")


        ' Dim db As New DBAccess("QualityNew")
        Dim db As New DBAccess
        db.slDataAdd("StartDate", startdt.ToString("yyyyMMdd"))
        db.slDataAdd("EndDate", enddt.ToString("yyyyMMdd"))
        db.slDataAdd("processid", CboProcess.SelectedValue)
        db.slDataAdd("CampaignID", cboCampaigns.SelectedValue)
        db.slDataAdd("paramType", paramtype)
        Dim dt As DataTable
        dt = db.ReturnTable("usp_TMwiseFARcount", , True)
        db = Nothing
        If dt.Rows.Count > 0 Then
            Dim dtTMparam As New DataTable
            dtTMparam.Columns.Add("AgentId")
            dtTMparam.Columns.Add("AgentName")
            Dim params As DataTable = dt.DefaultView.ToTable(True, "Parameter Text")
            For Each row As DataRow In params.Rows
                dtTMparam.Columns.Add(row.Item(0))
            Next
            dtTMparam.Columns.Add("Total")
            Dim legend As New DataTable
            legend.Columns.Add("ParamId")
            legend.Columns.Add("Parameter Text")
            Dim col() As String = {"Agentid", "AgentName"}
            Dim rowtotal = 0, coltotal As Integer
            For Each row As DataRow In dt.DefaultView.ToTable(True, col).Rows
                Dim dr As DataRow = dtTMparam.NewRow
                dr.Item("AgentId") = row.Item("AgentId")
                dr.Item("AgentName") = row.Item("AgentName")
                For Each row1 As DataRow In dt.Select("Agentid='" & row.Item("AgentId") & "'")
                    dr.Item(row1.Item("Parameter Text")) = row1.Item("Errorcount")
                    rowtotal += row1.Item("Errorcount")
                Next
                dr.Item("Total") = rowtotal
                dtTMparam.Rows.Add(dr)
                rowtotal = 0
            Next
            dtTMparam = dtTMparam.Select("", "Total Desc").CopyToDataTable
            Dim dr1 As DataRow = dtTMparam.NewRow
            dr1("AgentName") = "Total"

            For Each col1 As DataColumn In dtTMparam.Columns
                If col1.ColumnName <> "AgentId" And col1.ColumnName <> "AgentName" And col1.ColumnName <> "Total" Then
                    For Each row As DataRow In dtTMparam.Rows
                        coltotal += IIf(IsDBNull(row.Item(col1.ColumnName)), 0, row.Item(col1.ColumnName))
                    Next
                    dr1(col1.ColumnName) = coltotal
                    coltotal = 0
                End If
            Next
            dtTMparam.Rows.Add(dr1)
            Dim rowcount As Integer = 1
            For Each col1 As DataColumn In dtTMparam.Columns
                If col1.ColumnName <> "AgentId" And col1.ColumnName <> "AgentName" And col1.ColumnName <> "Total" Then
                    Dim dr As DataRow = legend.NewRow
                    dr.Item("ParamId") = "Param " & rowcount
                    dr.Item("Parameter Text") = col1.ColumnName
                    col1.ColumnName = "Param " & rowcount
                    legend.Rows.Add(dr)
                    rowcount += 1
                End If
            Next
            dtTMparam.Columns.Remove("agentid")
            'by satyendra to show total, it working fine.
            'dtTMparam.Columns.Add("Total")
            'Dim total As Integer = 0
            'For Each row As DataRow In dtTMparam.Rows
            '    total = 0
            '    For i As Integer = 1 To dtTMparam.Columns.Count - 1
            '        total = total + IIf(IsDBNull(row.Item(i)), 0, row.Item(i))
            '    Next
            '    row.Item("Total") = total

            'Next 
            Dim dtTMFAR(1) As DataTable
            dtTMFAR(0) = dtTMparam.Copy
            dtTMFAR(1) = legend.Copy
            Return (dtTMFAR)
        Else
            Dim dtTMFAR1(1) As DataTable
            Return (dtTMFAR1)
        End If

    End Function
#Region "notused"
    Private Function getTMParameterWiseNFAR() As DataTable()
        Dim startdt As DateTime = DateTime.Parse(cboYear.SelectedValue & "-" & cboMonth.SelectedValue & "-" & "01")
        Dim enddt As DateTime = startdt.AddMonths(1).AddDays(-1)
        StartDate = startdt.ToString("yyyyMMdd")
        EndDate = enddt.ToString("yyyyMMdd")

        ' Dim db As New DBAccess("QualityNew")
        Dim db As New DBAccess
        db.slDataAdd("StartDate", startdt.ToString("yyyyMMdd"))
        db.slDataAdd("EndDate", enddt.ToString("yyyyMMdd"))
        db.slDataAdd("processid", ProcessID)
        db.slDataAdd("CampaignID", CampaignID)
        db.slDataAdd("paramType", "N")
        Dim dt As DataTable
        dt = db.ReturnTable("usp_TMwiseFARcount", , True)
        db = Nothing
        Dim dtTMparam As New DataTable
        dtTMparam.Columns.Add("AgentId")
        dtTMparam.Columns.Add("AgentName")
        Dim params As DataTable = dt.DefaultView.ToTable(True, "Parameter Text")
        For Each row As DataRow In params.Rows
            dtTMparam.Columns.Add(row.Item(0))
        Next
        dtTMparam.Columns.Add("Total")
        Dim legend As New DataTable
        legend.Columns.Add("ParamId")
        legend.Columns.Add("Parameter Text")
        Dim col() As String = {"Agentid", "AgentName"}
        Dim rowtotal = 0, coltotal As Integer
        For Each row As DataRow In dt.DefaultView.ToTable(True, col).Rows
            Dim dr As DataRow = dtTMparam.NewRow
            dr.Item("AgentId") = row.Item("AgentId")
            dr.Item("AgentName") = row.Item("AgentName")
            For Each row1 As DataRow In dt.Select("Agentid='" & row.Item("AgentId") & "'")
                dr.Item(row1.Item("Parameter Text")) = row1.Item("Errorcount")
                rowtotal += row1.Item("Errorcount")
            Next
            dr.Item("Total") = rowtotal
            dtTMparam.Rows.Add(dr)
            rowtotal = 0
        Next
        dtTMparam = dtTMparam.Select("", "Total Desc").CopyToDataTable
        Dim dr1 As DataRow = dtTMparam.NewRow
        dr1("AgentName") = "Total"

        For Each col1 As DataColumn In dtTMparam.Columns
            If col1.ColumnName <> "AgentId" And col1.ColumnName <> "AgentName" And col1.ColumnName <> "Total" Then
                For Each row As DataRow In dtTMparam.Rows
                    coltotal += IIf(IsDBNull(row.Item(col1.ColumnName)), 0, row.Item(col1.ColumnName))
                Next
                dr1(col1.ColumnName) = coltotal
                coltotal = 0
            End If
        Next
        dtTMparam.Rows.Add(dr1)
        Dim rowcount As Integer = 1
        For Each col1 As DataColumn In dtTMparam.Columns
            If col1.ColumnName <> "AgentId" And col1.ColumnName <> "AgentName" And col1.ColumnName <> "Total" Then
                Dim dr As DataRow = legend.NewRow
                dr.Item("ParamId") = "Param " & rowcount
                dr.Item("Parameter Text") = col1.ColumnName
                col1.ColumnName = "Param " & rowcount
                legend.Rows.Add(dr)
                rowcount += 1
            End If
        Next
        dtTMparam.Columns.Remove("agentid")
        'by satyendra to show total, it working fine.
        'dtTMparam.Columns.Add("Total")
        'Dim total As Integer = 0
        'For Each row As DataRow In dtTMparam.Rows
        '    total = 0
        '    For i As Integer = 1 To dtTMparam.Columns.Count - 1
        '        total = total + IIf(IsDBNull(row.Item(i)), 0, row.Item(i))
        '    Next
        '    row.Item("Total") = total

        'Next
        Dim dtTMFAR(1) As DataTable
        dtTMFAR(0) = dtTMparam.Copy
        dtTMFAR(1) = legend.Copy
        Return (dtTMFAR)
    End Function
#End Region

    Private Sub showlegend(ByVal tablename As DataTable)
        'legend.Visible = True
        'If Not tablename Is Nothing Then
        Dim legendrow As TableRow
        Dim legendcell As TableCell
        Dim legendcell1 As TableCell
        Dim legendcell2 As New TableCell
        Dim tablerow As Integer
        tablerow = legend.Rows.Count
        If legend.Rows.Count > 0 Then
            For i As Integer = 0 To tablerow - 1
                legend.Rows.RemoveAt(tablerow - i - 1)

            Next
        End If

        For Each row As DataRow In tablename.Rows
            legendrow = New TableRow
            legendcell = New TableCell
            legendcell1 = New TableCell
            legendcell2 = New TableCell
            legendcell.Text = row.Item(0)
            legendcell1.Text = "->"
            legendcell2.Text = row.Item(1)
            legendcell1.ForeColor = Drawing.Color.Green
            legendcell1.Font.Bold = True
            legendrow.Cells.Add(legendcell)
            legendrow.Cells.Add(legendcell1)
            legendrow.Cells.Add(legendcell2)
            legend.Rows.Add(legendrow)
        Next
        legend.Caption = "Parameters Description"
        legend.Visible = True
        ' End If

    End Sub
    Protected Sub GridView1_RowCreated(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles GridView1.RowCreated
        If Pageno = 18 Then
            If e.Row.RowType = DataControlRowType.Header Then
                For i As Integer = 0 To e.Row.Cells.Count - 1
                    If e.Row.Cells(i).Text.Contains(Monthname1) Then
                        e.Row.Cells(i).Text = e.Row.Cells(i).Text.Replace(Monthname1, "")
                    ElseIf e.Row.Cells(i).Text.Contains(Monthname2) Then
                        e.Row.Cells(i).Text = e.Row.Cells(i).Text.Replace(Monthname2, "")
                    ElseIf e.Row.Cells(i).Text.Contains(Monthname3) Then
                        e.Row.Cells(i).Text = e.Row.Cells(i).Text.Replace(Monthname3, "")
                    End If
                Next

                Dim headerrow As GridViewRow = New GridViewRow(0, 0, DataControlRowType.Header, DataControlRowState.Insert)
                Dim cell_header As TableCell = New TableCell
                cell_header.Text = ""
                cell_header.HorizontalAlign = HorizontalAlign.Center
                cell_header.ColumnSpan = 1
                headerrow.Cells.Add(cell_header)
                cell_header = New TableCell
                cell_header.Text = Monthname1
                cell_header.HorizontalAlign = HorizontalAlign.Center
                cell_header.ColumnSpan = 2
                cell_header.BorderStyle = BorderStyle.Solid
                cell_header.BorderWidth = 1
                cell_header.BorderColor = Drawing.Color.FromName("#bbd9ee")
                cell_header.Font.Bold = True
                headerrow.Cells.Add(cell_header)
                cell_header = New TableCell
                cell_header.Text = Monthname2
                cell_header.HorizontalAlign = HorizontalAlign.Center
                cell_header.ColumnSpan = 2
                cell_header.BorderStyle = BorderStyle.Solid
                cell_header.BorderWidth = 1
                cell_header.BorderColor = Drawing.Color.FromName("#bbd9ee")
                cell_header.Font.Bold = True
                headerrow.Cells.Add(cell_header)
                cell_header = New TableCell
                cell_header.Text = Monthname3
                cell_header.HorizontalAlign = HorizontalAlign.Center
                cell_header.ColumnSpan = 2
                cell_header.BorderStyle = BorderStyle.Solid
                cell_header.BorderWidth = 1
                cell_header.BorderColor = Drawing.Color.FromName("#bbd9ee")
                cell_header.Font.Bold = True
                headerrow.Cells.Add(cell_header)

                GridView1.Controls(0).Controls.AddAt(0, headerrow)

            End If
        ElseIf Pageno = 16 Or Pageno = 17 Then
            If e.Row.RowType = DataControlRowType.Header Then
                For i As Integer = 0 To e.Row.Cells.Count - 1
                    If e.Row.Cells(i).Text.Contains(Monthname1) Then
                        e.Row.Cells(i).Text = e.Row.Cells(i).Text.Replace(Monthname1, "")
                    ElseIf e.Row.Cells(i).Text.Contains(Monthname2) Then
                        e.Row.Cells(i).Text = e.Row.Cells(i).Text.Replace(Monthname2, "")
                    ElseIf e.Row.Cells(i).Text.Contains(Monthname3) Then
                        e.Row.Cells(i).Text = e.Row.Cells(i).Text.Replace(Monthname3, "")
                    End If
                Next
                Dim headerrow As GridViewRow = New GridViewRow(0, 0, DataControlRowType.Header, DataControlRowState.Insert)
                Dim cell_header As TableCell = New TableCell
                cell_header.Text = ""
                cell_header.HorizontalAlign = HorizontalAlign.Center
                cell_header.ColumnSpan = 2
                headerrow.Cells.Add(cell_header)
                cell_header = New TableCell
                cell_header.Text = Monthname1
                cell_header.HorizontalAlign = HorizontalAlign.Center
                cell_header.ColumnSpan = 3
                cell_header.BorderStyle = BorderStyle.Solid
                cell_header.BorderWidth = 1
                cell_header.BorderColor = Drawing.Color.FromName("#bbd9ee")
                cell_header.Font.Bold = True
                headerrow.Cells.Add(cell_header)
                cell_header = New TableCell
                cell_header.Text = Monthname2
                cell_header.HorizontalAlign = HorizontalAlign.Center
                cell_header.ColumnSpan = 3
                cell_header.BorderStyle = BorderStyle.Solid
                cell_header.BorderWidth = 1
                cell_header.BorderColor = Drawing.Color.FromName("#bbd9ee")
                cell_header.Font.Bold = True
                headerrow.Cells.Add(cell_header)
                cell_header = New TableCell
                cell_header.Text = Monthname3
                cell_header.HorizontalAlign = HorizontalAlign.Center
                cell_header.ColumnSpan = 3
                cell_header.BorderStyle = BorderStyle.Solid
                cell_header.BorderWidth = 1
                cell_header.BorderColor = Drawing.Color.FromName("#bbd9ee")
                cell_header.Font.Bold = True
                headerrow.Cells.Add(cell_header)
                GridView1.Controls(0).Controls.AddAt(0, headerrow)
            End If
        ElseIf Pageno = 19 Then
            If e.Row.RowType = DataControlRowType.Header Then
                For i As Integer = 0 To e.Row.Cells.Count - 1
                    For Each row As DataRow In dtsupervisor.Rows
                        If e.Row.Cells(i).Text.Contains(row.Item("supervisorname")) Then
                            e.Row.Cells(i).Text = e.Row.Cells(i).Text.Replace("[ " & row.Item("supervisorname") & " ]", "")
                        End If
                    Next
                Next
                Dim headerrow As GridViewRow = New GridViewRow(0, 0, DataControlRowType.Header, DataControlRowState.Insert)
                Dim cell_header As TableCell = New TableCell
                cell_header.Text = ""
                cell_header.HorizontalAlign = HorizontalAlign.Center
                cell_header.ColumnSpan = 2
                headerrow.Cells.Add(cell_header)
                For Each row As DataRow In dtsupervisor.Rows
                    cell_header = New TableCell
                    cell_header.Text = row.Item("supervisorname")
                    cell_header.HorizontalAlign = HorizontalAlign.Center
                    cell_header.ColumnSpan = 3
                    cell_header.BorderStyle = BorderStyle.Solid
                    cell_header.BorderWidth = 1
                    cell_header.BorderColor = Drawing.Color.FromName("#bbd9ee")
                    cell_header.Font.Bold = True
                    headerrow.Cells.Add(cell_header)
                Next

                GridView1.Controls(0).Controls.AddAt(0, headerrow)
            End If

        End If
    End Sub

#End Region

#Region "Support functions"
    Private Sub FillProcessCampaigns()
        Common.FillProcessCampaigns(CboProcess, cboCampaigns, AgentID, CampaignID)
        Dim lstprocess As New ListItem
        lstprocess.Value = 0
        lstprocess.Text = "All"
        If CboProcess.Items.Contains(lstprocess) Then
            CboProcess.Items.Remove(lstprocess)
        End If
        Common.FillCampaigns(cboCampaigns, AgentID, CboProcess.SelectedValue)
        'cboCampaigns.Items.FindByValue(CampaignID).Selected = True

    End Sub

    Private Sub FillMenu()

    End Sub

    Private Sub FillMonthYear()
        For ictr = 1 To 12
            cboMonth.Items.Add(New ListItem(MonthName(ictr), ictr))
        Next

        cboMonth.SelectedIndex = cboMonth.Items.IndexOf(cboMonth.Items.FindByValue(DateTime.Now.Month))
        For ictr = DateTime.Now.Year To 2017 Step -1
            cboYear.Items.Add(New ListItem(ictr, ictr))
        Next
        cboYear.SelectedIndex = cboYear.Items.IndexOf(cboYear.Items.FindByValue(DateTime.Now.Year))
    End Sub
#End Region

#Region "Even Handling"

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        HumanMessage.Style.Item("visibility") = "hidden"
        If Not IsPostBack Then
            If Session("AgentID") <> "" Then
                ChartCase = 0
                ProcessID = Session("ProcessID")

                AgentID = Session("AgentID")
                PanelReports.Controls.Add(Common.GetMenu(Request.Url, AgentID, Request.ApplicationPath))
                Pageno = 0
                FillProcessCampaigns()
                CampaignID = cboCampaigns.SelectedValue 'Session("CampaignID")
                FillMonthYear()
                FillMenu()
                '
                CboMenu.SelectedValue = 0
                'RbMenu.SelectedIndex = 0
                ShowPage()


            End If

        End If
    End Sub

    Protected Sub cboCampaigns_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboCampaigns.SelectedIndexChanged
        CampaignID = cboCampaigns.SelectedValue
        ProcessID = CboProcess.SelectedValue
        ShowPage()
    End Sub

    Protected Sub CboProcess_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles CboProcess.SelectedIndexChanged
        ProcessID = CboProcess.SelectedValue
        Common.FillCampaigns(cboCampaigns, AgentID, CboProcess.SelectedValue)
        CampaignID = cboCampaigns.SelectedValue
        ShowPage()
    End Sub


    Protected Sub cboYear_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboYear.SelectedIndexChanged
        ShowPage()
    End Sub

    Protected Sub cboMonth_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboMonth.SelectedIndexChanged
        ShowPage()
    End Sub

    Protected Sub btnRefresh_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnRefresh.Click
        ShowPage()
    End Sub
    Protected Sub imgfav_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles imgfav.Click
        Common.AddToFav(AgentID, "Quality Dash Board")
        SuccessMessage("Quality Dashboard has been added to your favourite list")
        ShowPage()
    End Sub
    'Protected Sub btnCPH_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnCPH.Click
    '    chartcase = 1
    '    Pageno = 2
    '    ShowPage()

    'End Sub


    'Protected Sub btnAHT_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnAHT.Click
    '    Pageno = 3
    '    chartcase = 2
    '    ShowPage()
    'End Sub

    'Protected Sub btnFAR_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnFAR.Click
    '    Pageno = 4
    '    chartcase = 3
    '    ShowPage()
    'End Sub



    'Protected Sub btnSummary_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnSummary.Click
    '    Pageno = 1
    '    Showpage()


    'End Sub
    'Protected Sub btnTop5FAR_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnTop5FAR.Click
    '    Pageno = 5
    '    ShowPage()

    'End Sub
    'Protected Sub btnConsFAR_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnConsFAR.Click
    '    Pageno = 6
    '    ShowPage()
    'End Sub
    'Protected Sub btnFarTmwise_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnFarTmwise.Click
    '    Pageno = 7
    '    ShowPage()
    'End Sub
    'Protected Sub btnNFAR_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnNFAR.Click

    '    chartcase = 4
    '    Pageno = 8
    '    ShowPage()
    'End Sub
    'Protected Sub btnLegendNFAR_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnLegendNFAR.Click
    '    Pageno = 10
    '    ShowPage()

    'End Sub
    'Protected Sub btnNFARTop5_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnNFARTop5.Click
    '    Pageno = 9
    '    ShowPage()
    'End Sub
    'Protected Sub btnQuiz_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnQuiz.Click
    '    Pageno = 11
    '    ShowPage()
    'End Sub
    Protected Sub CboMenu_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles CboMenu.SelectedIndexChanged
        Pageno = CboMenu.SelectedValue '.SelectedIndex
        ShowPage()
    End Sub
    'Protected Sub RbMenu_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles RbMenu.SelectedIndexChanged
    '    Pageno = RbMenu.SelectedIndex
    '    ShowPage()
    'End Sub
    Protected Sub ImbSettings_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImbSettings.Click
        Response.Redirect("~/Quality/admin.aspx")
    End Sub
#End Region
#Region "Utility"

    Private Sub AlertMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMFail"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub

    Private Sub SuccessMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMSuccess"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub

    'Protected Sub ImageButton1_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton1.Click
    '    'fillgrid()
    '    GridViewExportUtil.Export(lblReportName.CurrentPage & "-" & LblError.Text & ".xls", Me.GdAttendance)
    'End Sub


    Public Overrides Sub VerifyRenderingInServerForm(ByVal Control As Control)

    End Sub

#End Region
End Class
