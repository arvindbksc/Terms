﻿Imports com.nss.DBAccess
Imports System.Data
Imports System.Web.UI.DataVisualization.Charting
Imports System.Drawing
Partial Class Quality_NewQualityDashBoard
    Inherits System.Web.UI.Page
    Dim dtAllData, dtCommulative As DataTable

#Region "Properties"
    Property CampaignID() As Integer
        Get
            Return ViewState("CampaignID")
        End Get
        Set(ByVal value As Integer)
            ViewState("CampaignID") = value
            Session("CampaignID") = value
        End Set
    End Property
    Property AgentID() As String
        Get
            Return ViewState("AgentID")
        End Get
        Set(ByVal value As String)
            ViewState("AgentID") = value
        End Set
    End Property
#End Region
#Region "Support functions"
    Private Sub FillCommonFilters()
        Dim db As New DBAccess
        Dim dt As DataTable = db.ReturnTable("select * from tbl_Reports_DatePeriods")
        db = Nothing
        Dim dr As DataRow = dt.NewRow
        dr(0) = 10
        dr(1) = "Between"
        dt.Rows.Add(dr)
        CboPeriod.DataTextField = "Caption"
        CboPeriod.DataValueField = "Period"
        CboPeriod.DataSource = dt
        CboPeriod.DataBind()

        dt = Nothing
        db = New DBAccess("CRM")
        dt = db.ReturnTable("usp_LCTGgetCategoryList", , True)
        db = Nothing

        Dim dtCategoryList As DataTable = dt.Clone
        dr = dt.NewRow
        Dim dr1 As DataRow = dt.NewRow
        For Each dr2 As DataRow In dt.Rows
            dr(0) = dr2.Item(0)
            dr(1) = dr2.Item(1).ToString + " - Error Percentage"
            dr1(0) = dr2.Item(0).ToString + "1"
            dr1(1) = dr2.Item(1).ToString + " - Error Count"

            dtCategoryList.Rows.Add(dr.ItemArray)
            dtCategoryList.Rows.Add(dr1.ItemArray)

        Next
        dtCategoryList.AcceptChanges()

        CboMenu.DataTextField = "Caption"
        CboMenu.DataValueField = "CategoryID"
        CboMenu.DataSource = dtCategoryList
        CboMenu.DataBind()
        Dim item1 As New ListItem
        item1.Text = "Category Wise"
        item1.Value = 0
        CboMenu.Items.Insert(0, item1)

        Dim item2 As New ListItem
        item2.Text = "Customer Contact required"
        item2.Value = 228
        CboMenu.Items.Insert(7, item2)

        Dim item3 As New ListItem
        item3.Text = "Customer Dissatisfaction"
        item3.Value = 230
        CboMenu.Items.Insert(8, item3)

    End Sub
#End Region

#Region "Even Handling"
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        HumanMessage.Style.Item("visibility") = "hidden"
        If Not IsPostBack Then
            'Session("AgentID") = "NSS51102"
            If Session("AgentID") <> "" Then
                'CampaignID = Session("CampaignID")
                AgentID = Session("AgentID")
                PanelReports.Controls.Add(Common.GetMenu(Request.Url, AgentID, Request.ApplicationPath))
                FillCommonFilters()
                DrawChart()
                UcDateTo.Visible = False
                ucDateFrom.Visible = False
                lblAnd.Visible = False
            End If
        End If
    End Sub
    Private Sub FillData()
        Dim db As New DBAccess
        Dim startday As Integer, endday As Integer
        If CboPeriod.SelectedValue = 10 Then
            startday = ucDateFrom.yyyymmdd
            endday = UcDateTo.yyyymmdd
        Else
            db = New DBAccess
            db.slDataAdd("Period", CboPeriod.SelectedValue)
            db.slDataAdd("Campaignid", 279)
            Dim dr As DataRow = db.ReturnRow("usp_GetStart_EndDateForAPeriod", True)
            db = Nothing
            startday = dr(0)
            endday = dr(1)
        End If
        db = New DBAccess("CRM")
        db.slDataAdd("DateFrom", startday)
        db.slDataAdd("DateTo", endday)
        db.slDataAdd("Campaignid", 279)
        db.slDataAdd("CMFID", 282)
        If CboMenu.SelectedValue = 0 Then
            dtAllData = db.ReturnTable("usp_getLCTGCategoryGraph", , True)
            db = Nothing
        ElseIf CboMenu.SelectedIndex = 7 Then
            Dim dbSubParam As New DBAccess("CRM")
            dbSubParam.slDataAdd("SubCategoryID", 228)
            dbSubParam.slDataAdd("DateFrom", startday)
            dbSubParam.slDataAdd("DateTo", endday)
            dtAllData = dbSubParam.ReturnTable("usp_LCTGgetSubParameter", , True)
            dbSubParam = Nothing
        ElseIf CboMenu.SelectedIndex = 8 Then
            Dim dbSubParam As New DBAccess("CRM")
            dbSubParam.slDataAdd("SubCategoryID", 230)
            dbSubParam.slDataAdd("DateFrom", startday)
            dbSubParam.slDataAdd("DateTo", endday)
            dtAllData = dbSubParam.ReturnTable("usp_LCTGgetSubParameter", , True)
            dbSubParam = Nothing
        Else
            Dim catid As Int16 = CboMenu.SelectedValue
            dtCommulative = New DataTable
            If CboMenu.SelectedIndex = 2 Then
                catid = 119
            ElseIf CboMenu.SelectedIndex = 4 Then
                catid = 120
            ElseIf CboMenu.SelectedIndex = 6 Then
                catid = 121
            End If
            db.slDataAdd("catid", catid)
            db.slDataAdd("GraphIndex", IIf(CboMenu.SelectedItem.Text.ToString.EndsWith("Error Count"), 1, 0))
            dtAllData = db.ReturnTable("usp_getLCTGgraphParameterwiseErrorCount", , True)
            db = Nothing
            dtCommulative.Columns.Add("Parameters")
            dtCommulative.Columns.Add("AccuracyError")
            dtCommulative.Columns.Add("Cumulative Percentage")
            Dim Commulative As Double = 0.0
            For Each dr As DataRow In dtAllData.Rows
                Dim Accuracy As Double = Convert.ToDouble(dr(1))
                Commulative = Commulative + Accuracy
                Dim newRow As DataRow = dtCommulative.NewRow()
                newRow("Parameters") = dr(0)
                newRow("AccuracyError") = Accuracy
                newRow("Cumulative Percentage") = Commulative
                dtCommulative.Rows.Add(newRow)
            Next
            dtCommulative.AcceptChanges()
        End If
    End Sub
    Private Sub DrawChart()
        FillData()
        If Not dtAllData.Rows.Count < 0 Then
            If CboMenu.SelectedValue = 0 Then
                RenderGraph(Chart1, "score", "Category")
            ElseIf CboMenu.SelectedIndex = 7 Or CboMenu.SelectedIndex = 8 Then
                RenderGraph(Chart1, "Percent", "SubParameter")
            Else
                RenderGraph(Chart1, "Parameters", "AccuracyError")
            End If
        End If
    End Sub
    Private Sub RenderGraph(ByVal charts As Chart, ByVal yValueMem As String, ByVal Title As String)
        Dim xValueMem As String = ""
        charts.Series.Clear()
        charts.Series.Add("series1")
        charts.ChartAreas(0).AxisX.IntervalAutoMode = DataVisualization.Charting.IntervalAutoMode.FixedCount
        charts.TextAntiAliasingQuality = DataVisualization.Charting.TextAntiAliasingQuality.High
        Dim mypane As System.Web.UI.DataVisualization.Charting.Series
        mypane = charts.Series(0)
        If CboMenu.SelectedValue = 0 Then
            'Dim xValueMem As String = ""
            'charts.Series.Clear()
            'charts.Series.Add("series1")
            'charts.ChartAreas(0).AxisX.IntervalAutoMode = DataVisualization.Charting.IntervalAutoMode.FixedCount
            'charts.TextAntiAliasingQuality = DataVisualization.Charting.TextAntiAliasingQuality.High
            'Dim mypane As System.Web.UI.DataVisualization.Charting.Series
            mypane = charts.Series(0)
            charts.Series(0).IsValueShownAsLabel = True
            charts.Series(0).MarkerColor = Drawing.Color.White
            charts.ChartAreas(0).AxisX.MajorGrid.Enabled = False
            charts.ChartAreas(0).AxisY.MajorGrid.Enabled = False
            With Chart1
                .Series.Clear()
                .Series.Add("Category")
                With .Series(0)
                    .XValueMember = "Category"
                    .YValueMembers = "score"
                    .ChartType = DataVisualization.Charting.SeriesChartType.Column
                    .BorderWidth = 4
                    .Color = Drawing.Color.Blue
                    .BackGradientStyle = DataVisualization.Charting.GradientStyle.VerticalCenter
                    .BackSecondaryColor = Drawing.Color.SkyBlue
                    .IsValueShownAsLabel = True
                End With
                .ChartAreas(0).AxisX.MajorGrid.Enabled = False
                .ChartAreas(0).AxisX.Interval = 1
                .ChartAreas(0).AxisX2.Interval = 1
                .ChartAreas(0).AxisX.IntervalAutoMode = DataVisualization.Charting.IntervalAutoMode.FixedCount
                .ChartAreas(0).AxisX2.IntervalAutoMode = DataVisualization.Charting.IntervalAutoMode.FixedCount
                .DataSource = dtAllData.DefaultView
                .DataBind()
            End With
        ElseIf CboMenu.SelectedIndex = 7 Or CboMenu.SelectedIndex = 8 Then
            charts.DataSource = dtAllData
            charts.DataBind()
            Chart1.Titles.Add(CboMenu.SelectedItem.Text)
            Chart1.Series(0).LegendText = "#VALX"
            Chart1.Series(0).Label = "#VALY"
            Chart1.Series(0).XValueMember = dtAllData.Columns(0).ColumnName
            Chart1.Series(0).YValueMembers = yValueMem
            Chart1.Legends.Add("Legent1")
            Chart1.Legends("Legent1").Enabled = True
            Chart1.Legends("Legent1").Alignment = System.Drawing.StringAlignment.Near
            Chart1.Series(0).ChartType = DataVisualization.Charting.SeriesChartType.Pie
            Chart1.Series(0)("PieLabelStyle") = "outside"
            Chart1.Series(0).ShadowOffset = 1
            Chart1.Series(0)("PieDrawingStyle") = "Concave"
        Else
            If CboMenu.SelectedItem.Text.ToString.EndsWith("Error Count") Then
                With Chart1
                    .Series.Clear()
                    .Series.Add("Parameters")
                    .Series.Add("Cumulative Percentage")
                    With .Series(0)
                        .XValueMember = "Parameters"
                        .YValueMembers = "AccuracyError"
                        .ChartType = DataVisualization.Charting.SeriesChartType.Column
                        .BorderWidth = 4
                        .Color = Drawing.Color.Blue
                        .BackGradientStyle = DataVisualization.Charting.GradientStyle.VerticalCenter
                        .BackSecondaryColor = Drawing.Color.SkyBlue
                        .IsValueShownAsLabel = True
                    End With
                    With .Series(1)
                        .XValueMember = "Parameters"
                        .YValueMembers = "Cumulative Percentage"
                        .ChartType = DataVisualization.Charting.SeriesChartType.Line
                        .BorderWidth = 2
                        .Color = Drawing.Color.Red
                        .MarkerStyle = DataVisualization.Charting.MarkerStyle.Diamond
                        .MarkerSize = 6
                        .MarkerColor = Drawing.Color.Yellow
                        .IsValueShownAsLabel = True
                    End With
                    .ChartAreas(0).AxisX.MajorGrid.Enabled = False
                    .ChartAreas(0).AxisY.MajorGrid.Enabled = False
                    .ChartAreas(0).AxisX.Interval = 1
                    .ChartAreas(0).AxisX2.Interval = 1
                    .ChartAreas(0).AxisX.IntervalAutoMode = DataVisualization.Charting.IntervalAutoMode.FixedCount
                    .ChartAreas(0).AxisX2.IntervalAutoMode = DataVisualization.Charting.IntervalAutoMode.FixedCount
                    .ChartAreas(0).AxisY2.MajorGrid.Enabled = False
                    .DataSource = dtCommulative.DefaultView
                    .DataBind()
                    'Chart1.Series(1).Label = "#PERCENT"
                End With
            Else
                With Chart1
                    .Series.Clear()
                    .Series.Add("Parameters")
                    With .Series(0)
                        .XValueMember = "Parameters"
                        .YValueMembers = "AccuracyError"
                        .ChartType = DataVisualization.Charting.SeriesChartType.Column
                        .BorderWidth = 4
                        .Color = Drawing.Color.Blue
                        .BackGradientStyle = DataVisualization.Charting.GradientStyle.VerticalCenter
                        .BackSecondaryColor = Drawing.Color.SkyBlue
                        .IsValueShownAsLabel = True
                    End With
                    .ChartAreas(0).AxisX.MajorGrid.Enabled = False
                    .ChartAreas(0).AxisX.Interval = 1
                    .ChartAreas(0).AxisX2.Interval = 1
                    .ChartAreas(0).AxisX.IntervalAutoMode = DataVisualization.Charting.IntervalAutoMode.FixedCount
                    .ChartAreas(0).AxisX2.IntervalAutoMode = DataVisualization.Charting.IntervalAutoMode.FixedCount
                    .DataSource = dtCommulative.DefaultView
                    .DataBind()
                End With
            End If
        End If

    End Sub
    
    Protected Sub btnRefresh_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnRefresh.Click
        DrawChart()
    End Sub
    Protected Sub imgfav_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles imgfav.Click
        Common.AddToFav(AgentID, "LCTG Quality Graph")
        SuccessMessage("Report has been added to your favourite list")
    End Sub
    Protected Sub CboMenu_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles CboMenu.SelectedIndexChanged
        DrawChart()
    End Sub
    Protected Sub CboPeriod_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles CboPeriod.SelectedIndexChanged
        If CboPeriod.SelectedValue = 10 Then
            ucDateFrom.Visible = True
            UcDateTo.Visible = True
            lblAnd.Visible = True
            DrawChart()
        Else
            ucDateFrom.Visible = False
            UcDateTo.Visible = False
            lblAnd.Visible = False
            DrawChart()
        End If
    End Sub
#End Region
#Region "Utility"

    Private Sub AlertMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMFail"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub

    Private Sub SuccessMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMSuccess"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub

    'Protected Sub ImageButton1_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton1.Click
    '    'fillgrid()
    '    GridViewExportUtil.Export(lblReportName.CurrentPage & "-" & LblError.Text & ".xls", Me.GdAttendance)
    'End Sub


    Public Overrides Sub VerifyRenderingInServerForm(ByVal Control As Control)

    End Sub

#End Region
End Class
