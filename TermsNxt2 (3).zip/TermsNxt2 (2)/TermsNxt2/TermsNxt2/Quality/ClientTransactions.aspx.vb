﻿Imports com.nss.DBAccess
Imports System.Data
Imports System.Data.SqlClient
Partial Class Quality_ClientTransactions
    Inherits System.Web.UI.Page
#Region "Properties"
    Property HasQuestion() As Boolean
        Get
            Return ViewState("HasQuestion")
        End Get
        Set(ByVal value As Boolean)
            ViewState("HasQuestion") = value
        End Set
    End Property
    Property LoginUserID() As String
        Get
            Return ViewState("LoginUserID")
        End Get
        Set(ByVal value As String)
            ViewState("LoginUserID") = value
        End Set
    End Property
    Property LoginUserName() As String
        Get
            Return ViewState("LoginUserName")
        End Get
        Set(ByVal value As String)
            ViewState("LoginUserName") = value
        End Set
    End Property
    Property StandAloneCMF() As Boolean
        Get
            Return ViewState("StandAloneCMF")
        End Get
        Set(ByVal value As Boolean)
            ViewState("StandAloneCMF") = value
        End Set
    End Property
    Property ProcessID() As Integer
        Get
            Return ViewState("ProcessID")
        End Get
        Set(ByVal value As Integer)
            ViewState("ProcessID") = value
            Session("ProcessID") = value
        End Set
    End Property
    Property Campaigntype() As Integer
        Get
            Return ViewState("Campaigntype")
        End Get
        Set(ByVal value As Integer)
            ViewState("Campaigntype") = value
            'Session("ProcessID") = value
        End Set
    End Property
    Property ReportType() As Integer
        Get
            Return ViewState("ReportType")
        End Get
        Set(ByVal value As Integer)
            ViewState("ReportType") = value
        End Set
    End Property
    Property CampaignID() As Integer
        Get
            Return ViewState("CampaignID")
        End Get
        Set(ByVal value As Integer)
            ViewState("CampaignID") = value
        End Set
    End Property

    Property AgentID() As String
        Get
            Return ViewState("AgentID")
        End Get
        Set(ByVal value As String)
            ViewState("AgentID") = value
        End Set
    End Property
    Property UserID() As String
        Get
            Return ViewState("UserID")
        End Get
        Set(ByVal value As String)
            ViewState("UserID") = value
        End Set
    End Property
#End Region
#Region "Load Functions"
    Private Sub PopulateCampaigns()
        Try
            Dim db2 As New DBAccess("crm")
            db2.slDataAdd("agentid", UserID)
            Dim dt1 As DataTable = db2.ReturnTable("usp_GetAgentDetails", "", True)
            db2 = Nothing
            Dim db As New DBAccess("crm")
            db.slDataAdd("Agentid", dt1.Rows(0).Item("Agentid"))
            ddlCampaigns.DataSource = db.ReturnTable("usp_MyCampaigns", , True)
            ddlCampaigns.DataValueField = "campaignid"
            ddlCampaigns.DataTextField = "name"
            ddlCampaigns.DataBind()
            'ddlCampaigns.Items.Insert(0, "")
            'btnGetTransactions.Enabled = ddlCampaigns.Items.Count > 0
            dt1 = Nothing
            db = Nothing
        Catch ex As Exception
            lblError.Visible = True
            lblError.Text = ex.Message.ToString
        End Try
    End Sub
    Private Sub PopulateAgents()
        Try
            Dim db As New DBAccess("crm")
            db.slDataAdd("campaignid", ddlCampaigns.SelectedValue)
            Dim dt As DataTable = db.ReturnTable("usp_GetAgentsOfTheProcess", "", True)
            Ddlagents.DataTextField = "agent name"
            Ddlagents.DataValueField = "agentid"
            Ddlagents.DataSource = dt
            Ddlagents.DataBind()
            If dt.Rows.Count > 0 Then
                Dim i As New ListItem
                i.Text = "ALL"
                i.Value = "%"
                Ddlagents.Items.Insert(0, i)
            End If
            db = Nothing
            dt = Nothing
        Catch ex As Exception
            lblError.Visible = True
            lblError.Text = ex.Message.ToString
        End Try
    End Sub
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        'userID = Session("userid")
        'Session("UserLoginID") = "jatinT"
        'userID = 1035
        If Not IsPostBack Then
            CampaignID = Session("CampaignID")
            UserID = Session("AgentID")
            For Each item As ListItem In DdlYears.Items
                If item.Text = Now.Year.ToString Then
                    item.Selected = True
                    Exit For
                End If
            Next
            For Each item As ListItem In Ddlyear1.Items
                If item.Text = Now.Year.ToString Then
                    item.Selected = True
                    Exit For
                End If
            Next
            For Each item As ListItem In DdlDay.Items
                If item.Value = Now.Day.ToString.PadLeft(2, "0") Then
                    item.Selected = True
                    Exit For
                End If
            Next
            For Each item As ListItem In Ddlday1.Items
                If item.Value = Now.Day.ToString.PadLeft(2, "0") Then
                    item.Selected = True
                    Exit For
                End If
            Next
            For Each item As ListItem In Ddlmonth1.Items
                If item.Value = Now.Month.ToString.PadLeft(2, "0") Then
                    item.Selected = True
                    Exit For
                End If
            Next
            For Each item As ListItem In DdlMonths.Items
                If item.Value = Now.Month.ToString.PadLeft(2, "0") Then
                    item.Selected = True
                    Exit For
                End If
            Next
            PopulateCampaigns()
            PopulateAgents()
            getevaluatedcmf()
        Else
            Session("AgentID") = UserID
        End If
        PanelReports.Controls.Add(Common.GetMenu(Request.Url, UserID, Request.ApplicationPath))
    End Sub
    Private Sub getevaluatedcmf()
        Dim fromDate, todate As String
        fromDate = DdlYears.SelectedValue + DdlMonths.SelectedValue + DdlDay.SelectedValue
        todate = Ddlyear1.SelectedValue + Ddlmonth1.SelectedValue + Ddlday1.SelectedValue
        Session("Return") = "~/Quality/ClientTransactions.aspx"
        Dim db As New DBAccess("qualitynew")
        Dim dt As DataTable
        db.slDataAdd("Campaignid", ddlCampaigns.SelectedValue)
        db.slDataAdd("datefrom", fromDate)
        db.slDataAdd("dateto", todate)
        db.slDataAdd("agentid", Ddlagents.SelectedValue)
        dt = db.ReturnTable("usp_Clientcmf_new", , True)
        dtgMain.DataSource = dt
        dtgMain.DataBind()
    End Sub
#End Region
#Region "Events"
    Protected Sub dtgMain_PageIndexChanging(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewPageEventArgs) Handles dtgMain.PageIndexChanging
        dtgMain.PageIndex = e.NewPageIndex
        getevaluatedcmf()
    End Sub

    Protected Sub Ddlagents_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles Ddlagents.SelectedIndexChanged
        getevaluatedcmf()
    End Sub

    Protected Sub btnGetTransactions_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnGetTransactions.Click
        PopulateAgents()
        getevaluatedcmf()
    End Sub
    Protected Sub ddlCampaigns_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ddlCampaigns.SelectedIndexChanged
        PopulateAgents()
        getevaluatedcmf()
    End Sub
    Protected Sub imgfav_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles imgfav.Click
        Common.AddToFav(UserID, "Client Transactions")
        Response.Write("<script type = 'text/javascript'>alert('Report has been added to your favourite list')</script>")
        'SuccessMessage("Report has been added to your favourite list")
        PopulateAgents()
        getevaluatedcmf()
    End Sub
#End Region

End Class
