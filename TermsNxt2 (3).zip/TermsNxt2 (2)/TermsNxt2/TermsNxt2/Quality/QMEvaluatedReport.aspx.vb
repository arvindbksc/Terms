﻿Imports com.nss.DBAccess
Imports System.Data
Partial Class Quality_QMEvaluatedReport
    Inherits System.Web.UI.Page
#Region "--- Properties ---"

    Property ProcessID() As Integer
        Get
            Return ViewState("ProcessID")
        End Get
        Set(ByVal value As Integer)
            ViewState("ProcessID") = value
            Session("ProcessID") = value
        End Set
    End Property
    Property Campaigntype() As Integer
        Get
            Return ViewState("Campaigntype")
        End Get
        Set(ByVal value As Integer)
            ViewState("Campaigntype") = value
            'Session("ProcessID") = value
        End Set
    End Property
    Property ReportType() As Integer
        Get
            Return ViewState("ReportType")
        End Get
        Set(ByVal value As Integer)
            ViewState("ReportType") = value
        End Set
    End Property
    Property CampaignID() As Integer
        Get
            Return ViewState("CampaignID")
        End Get
        Set(ByVal value As Integer)
            ViewState("CampaignID") = value
        End Set
    End Property
    Property AgentID() As String
        Get
            Return ViewState("AgentID")
        End Get
        Set(ByVal value As String)
            ViewState("AgentID") = value
        End Set
    End Property
#End Region
#Region "--- Load Data ---"
    Private Sub LoadData()
        FillCommonFilters()
        PopulateCampaigns()
        PopulateAgents()
    End Sub
#End Region
#Region "---- Functions ----"
    Private Sub FillCommonFilters()
        Dim db As New DBAccess
        Dim dt As DataTable = db.ReturnTable("select * from tbl_Reports_DatePeriods")
        db = Nothing
        Dim dr As DataRow = dt.NewRow
        dr(0) = 10
        dr(1) = "Between"
        dt.Rows.Add(dr)
        CboPeriod.DataTextField = "Caption"
        CboPeriod.DataValueField = "Period"
        CboPeriod.DataSource = dt
        CboPeriod.DataBind()
    End Sub
    Private Sub PopulateCampaigns()
        Try
            Dim db2 As New DBAccess("crm")
            db2.slDataAdd("Agentid", AgentID)
            Dim dt As DataTable = db2.ReturnTable("usp_GetAgentDetails", "", True)
            db2 = Nothing
            Dim db As New DBAccess("crm")
            db.slDataAdd("Agentid", dt.Rows(0).Item("Agentid"))
            cboCampaigns.DataSource = db.ReturnTable("usp_MyCampaigns", , True)
            cboCampaigns.DataValueField = "campaignid"
            cboCampaigns.DataTextField = "name"
            cboCampaigns.DataBind()
            dt = Nothing
            db = Nothing
        Catch ex As Exception
            LblError.Visible = True
            LblError.Text = ex.Message.ToString
        End Try
    End Sub
    Private Sub PopulateAgents()
        Try
            ' Dim db As New DBAccess("CRM")
            Dim db As New DBAccess
            db.slDataAdd("campaignid", cboCampaigns.SelectedValue)
            Dim dt As DataTable = db.ReturnTable("usp_GetAgentsOfTheProcess", "", True)
            cboAgents.DataTextField = "agent name"
            cboAgents.DataValueField = "agentid"
            cboAgents.DataSource = dt
            cboAgents.DataBind()
            If dt.Rows.Count > 0 Then
                Dim i As New ListItem
                i.Text = "ALL"
                i.Value = "%"
                cboAgents.Items.Insert(0, i)
            End If
            db = Nothing
            dt = Nothing
        Catch ex As Exception
            LblError.Visible = True
            LblError.Text = ex.Message.ToString
        End Try
    End Sub
    Private Sub PopulateData()
        Try
            Dim dbdate As New DBAccess
            Dim startday As Integer, endday As Integer
            If CboPeriod.SelectedValue = 10 Then
                startday = ucDateFrom.yyyymmdd
                endday = ucDateTo.yyyymmdd
            Else
                dbdate = New DBAccess
                dbdate.slDataAdd("Period", CboPeriod.SelectedValue)
                dbdate.slDataAdd("Campaignid", cboCampaigns.SelectedValue)
                Dim dr As DataRow = dbdate.ReturnRow("usp_GetStart_EndDateForAPeriod", True)
                dbdate = Nothing
                startday = dr(0)
                endday = dr(1)
            End If
            dgdata.DataSource = Nothing
            Session("Return") = "~/Quality/qmevaluatedreport.aspx"
            '  Dim db As New DBAccess("qualitynew")
            Dim db As New DBAccess("Report_IP")
            Dim dt As DataTable
            db.slDataAdd("Campaignid", cboCampaigns.SelectedValue)
            db.slDataAdd("datefrom", startday)
            db.slDataAdd("dateto", endday)
            db.slDataAdd("agentid", cboAgents.SelectedValue)
            dt = db.ReturnTable("usp_evaluatedcmf_new", , True)
            dgdata.DataSource = dt
            dgdata.DataBind()
            lblReportName.Text = "Quality Evaluated Sheet Report Between " & IntegerToDateString(startday) & "  and " & IntegerToDateString(endday) & " for " & cboCampaigns.SelectedItem.Text & " campaign"
        Catch ex As Exception
            LblError.Visible = True
            LblError.Text = ex.Message.ToString
        End Try

    End Sub
#End Region

#Region "---- Load ----"
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            If Session("AgentID") <> "" Then
                CampaignID = Session("CampaignID")
                AgentID = Session("AgentID")
                PanelReports.Controls.Add(Common.GetMenu(Request.Url, AgentID, Request.ApplicationPath))
               LoadData()
                ucDateTo.Visible = False
                ucDateFrom.Visible = False
                lblAnd.Visible = False
            End If
        End If

        'If Not IsPostBack Then
        '    For Each item As ListItem In DdlYears.Items
        '        If item.Text = Now.Year.ToString Then
        '            item.Selected = True
        '        End If
        '    Next
        '    For Each item As ListItem In Ddlyear1.Items
        '        If item.Text = Now.Year.ToString Then
        '            item.Selected = True
        '        End If
        '    Next
        '    For Each item As ListItem In DdlDay.Items
        '        If item.Value = Now.Day.ToString.PadLeft(2, "0") Then
        '            item.Selected = True
        '        End If
        '    Next
        '    For Each item As ListItem In Ddlday1.Items
        '        If item.Value = Now.Day.ToString.PadLeft(2, "0") Then
        '            item.Selected = True
        '        End If
        '    Next
        '    For Each item As ListItem In Ddlmonth1.Items
        '        If item.Value = Now.Month.ToString.PadLeft(2, "0") Then
        '            item.Selected = True
        '        End If
        '    Next
        '    For Each item As ListItem In DdlMonths.Items
        '        If item.Value = Now.Month.ToString.PadLeft(2, "0") Then
        '            item.Selected = True
        '        End If
        '    Next

        'End If

    End Sub
#End Region

#Region "--- Event ---"
    Protected Sub cboCampaigns_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboCampaigns.SelectedIndexChanged
        Try
            PopulateAgents()
            PopulateData()
        Catch ex As Exception

            LblError.Visible = True
            LblError.Text = ex.Message.ToString
        End Try
       
    End Sub
    Protected Sub btnRefresh_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnRefresh.Click

        Try
            PopulateData()
        Catch ex As Exception

            LblError.Visible = True
            LblError.Text = ex.Message.ToString
        End Try

    End Sub
    Protected Sub CboPeriod_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles CboPeriod.SelectedIndexChanged
        Try
            If CboPeriod.SelectedValue = 10 Then
                ucDateFrom.Visible = True
                ucDateTo.Visible = True
                lblAnd.Visible = True
                PopulateData()
            Else
                ucDateFrom.Visible = False
                ucDateTo.Visible = False
                lblAnd.Visible = False
                PopulateData()
            End If
        Catch ex As Exception
            LblError.Visible = True
            LblError.Text = ex.Message.ToString
        End Try
       
    End Sub
    Protected Sub imgfav_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles imgfav.Click
        Try
            Common.AddToFav(AgentID, "Quality Evaluated Sheet Report")
            SuccessMessage("Report has been added to your favourite list")
            PopulateData()
        Catch ex As Exception

        End Try
       
    End Sub
    Protected Sub ImageButton1_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton1.Click
        Try
            PopulateData()
            GridViewExportUtil.Export(lblReportName.Text & "-" & LblError.Text & ".xls", Me.dgdata)
        Catch ex As Exception
            LblError.Visible = True
            LblError.Text = ex.Message.ToString
        End Try
       
    End Sub
    Protected Sub cboAgents_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboAgents.SelectedIndexChanged
        Try
            PopulateData()
        Catch ex As Exception
            LblError.Visible = True
            LblError.Text = ex.Message.ToString
        End Try

    End Sub
#End Region
#Region "--- Utility ---"

    Private Sub AlertMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMFail"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub

    Private Sub SuccessMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMSuccess"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub

    'Protected Sub ImageButton1_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton1.Click
    '    'fillgrid()
    '    GridViewExportUtil.Export(lblReportName.CurrentPage & "-" & LblError.Text & ".xls", Me.GdAttendance)
    'End Sub

    Public Overrides Sub VerifyRenderingInServerForm(ByVal Control As Control)

    End Sub

#End Region
#Region "Support Functions"
    Private Function IntegerToDateString(ByVal d As Integer) As String
        Try
            Return d.ToString.Substring(0, 4) & "-" & d.ToString.Substring(4, 2) & "-" & d.ToString.Substring(6, 2)
        Catch ex As Exception
            Return ex.Message
        End Try

    End Function
#End Region
    
End Class
