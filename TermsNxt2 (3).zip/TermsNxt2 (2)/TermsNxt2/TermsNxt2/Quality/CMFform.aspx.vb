﻿Imports com.nss.DBAccess
Imports System.Data

Partial Class Quality_CMFform
    Inherits System.Web.UI.Page

#Region "Properties"
    Property SheetID() As Integer
        Get
            Return ViewState("SheetID")
        End Get
        Set(ByVal value As Integer)
            ViewState("SheetID") = value
        End Set
    End Property
    Property CustomerID() As Integer
        Get
            Return ViewState("CustomerID")
        End Get
        Set(ByVal value As Integer)
            ViewState("CustomerID") = value
        End Set
    End Property
    Property TransID() As Integer
        Get
            Return ViewState("TransID")
        End Get
        Set(ByVal value As Integer)
            ViewState("TransID") = value
        End Set
    End Property
    Property CMFID() As Integer
        Get
            Return ViewState("CMFID")
        End Get
        Set(ByVal value As Integer)
            ViewState("CMFID") = value
        End Set
    End Property
    Property CampaignID() As Integer
        Get
            Return ViewState("CampaignID")
        End Get
        Set(ByVal value As Integer)
            ViewState("CampaignID") = value
        End Set
    End Property
    Property MainCatID() As Integer
        Get
            Return ViewState("MainCatID")
        End Get
        Set(ByVal value As Integer)
            ViewState("MainCatID") = value
        End Set
    End Property
    Property SubCatID() As Integer
        Get
            Return ViewState("SubCatID")
        End Get
        Set(ByVal value As Integer)
            ViewState("SubCatID") = value
        End Set
    End Property

    Property Caption() As String
        Get
            Return ViewState("Caption")
        End Get
        Set(ByVal value As String)
            ViewState("Caption") = value
        End Set
    End Property
    Property AnsText() As String
        Get
            Return ViewState("AnsText")
        End Get
        Set(ByVal value As String)
            ViewState("AnsText") = value
        End Set
    End Property
    Property AnsText_Worktype() As String
        Get
            Return ViewState("AnsText_worktype")
        End Get
        Set(ByVal value As String)
            ViewState("AnsText_worktype") = value
        End Set
    End Property
    Property AnsText_ReferenceNo() As String
        Get
            Return ViewState("AnsText_ReferenceNo")
        End Get
        Set(ByVal value As String)
            ViewState("AnsText_ReferenceNo") = value
        End Set
    End Property

    Property AddNo() As String
        Get
            Return ViewState("AddNo")
        End Get
        Set(ByVal value As String)
            ViewState("AddNo") = value
        End Set
    End Property
    Property LoginUserName() As String
        Get
            Return ViewState("LoginUserName")
        End Get
        Set(ByVal value As String)
            ViewState("LoginUserName") = value
        End Set
    End Property
    Property SupervisorID() As String
        Get
            Return ViewState("SupervisorID")
        End Get
        Set(ByVal value As String)
            ViewState("SupervisorID") = value
        End Set
    End Property
    Property AgentID() As String
        Get
            Return ViewState("AgentID")
        End Get
        Set(ByVal value As String)
            ViewState("AgentID") = value
        End Set
    End Property

    Property QEID() As String
        Get
            Return ViewState("QEID")
        End Get
        Set(ByVal value As String)
            ViewState("QEID") = value
        End Set
    End Property

    Property UserID() As String
        Get
            Return ViewState("UserID")
        End Get
        Set(ByVal value As String)
            ViewState("UserID") = value
        End Set
    End Property

    Property btFreez() As Boolean
        Get
            Return ViewState("btFreez")
        End Get
        Set(ByVal value As Boolean)
            ViewState("btFreez") = value
        End Set
    End Property

    Property TransDate() As String
        Get
            Return ViewState("TransDate")
        End Get
        Set(ByVal value As String)
            ViewState("TransDate") = value
        End Set
    End Property

    Property StandaloneCMF() As Boolean
        Get
            Return ViewState("StandaloneCMF")
        End Get
        Set(ByVal value As Boolean)
            ViewState("StandaloneCMF") = value
        End Set
    End Property

    Property TransIDQuality() As String
        Get
            Return ViewState("TransIDQuality")
        End Get
        Set(ByVal value As String)
            ViewState("TransIDQuality") = value
        End Set
    End Property

    Property AHTDuration() As Integer
        Get
            Return ViewState("AHTDuration")
        End Get
        Set(ByVal value As Integer)
            ViewState("AHTDuration") = value
        End Set
    End Property

    Property TMReason() As String
        Get
            Return ViewState("TMReason")
        End Get
        Set(ByVal value As String)
            ViewState("TMReason") = value
        End Set
    End Property

    Property QEReason() As String
        Get
            Return ViewState("QEReason")
        End Get
        Set(ByVal value As String)
            ViewState("QEReason") = value
        End Set
    End Property
#End Region
    Dim dtparamdata As DataTable
#Region "Load Function"
    Private Function GetCass(Custid As Integer, campid As Integer) As String
        Dim db As New DBAccess("Leads")
        db.slDataAdd("leadid", Custid)
        db.slDataAdd("CampaignID", campid)
        Dim str As String = ""
        Str = db.ReturnValue("usp_GetClass32", True)
        db = Nothing
        Return str


    End Function
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Try
            If Not IsPostBack Then
                UserID = Request.QueryString("LoginUserID")
                LoginUserName = Request.QueryString("LoginUserName")
                PanelReports.Controls.Add(Common.GetMenu(Request.Url, UserID, Request.ApplicationPath))
                TransID = Request.QueryString("transid")
                CMFID = Request.QueryString("CMFID")
                lblcmfid.Text = IIf(CustomerID = -1 Or CustomerID = 0, "", CustomerID)
                CampaignID = Request.QueryString("campid")
               

                AHTDuration = Request.QueryString("duration")

                If Request.QueryString("sheetid") Is Nothing Then
                    SheetID = 0
                Else
                    SheetID = Request.QueryString("sheetid")
                End If
                '---------------
                AgentID = Request.QueryString("agentid")
                QEID = Request.QueryString("QEID")
                TransDate = Request.QueryString("transdate")
                CustomerID = Request.QueryString("lid")

                If CampaignID = 32 Then
                    LblClass.Text = GetCass(CustomerID, CampaignID)
                Else
                    LblClass.Text = ""
                End If

                ''------------------------------------------------------------------
                ' Added to insert data in tbl_Data_Transactions (12-12-12) 
                '                If (Request.QueryString("stage") = "N") Then
                If SheetID = 0 Then
                    Dim db As New DBAccess("CRM")
                    db.slDataAdd("lid", CustomerID)
                    db.slDataAdd("QAAgentId", UserID)
                    db.slDataAdd("DialedNumber", "")
                    db.slDataAdd("CampaignID", CampaignID)
                    db.slDataAdd("CallTable", "")
                    TransIDQuality = db.ReturnValue("usp_InsertTransaction_Quality", True)
                    db = Nothing
                End If
                ''------------------------------------------------------------------

                lblcmfid.Text = IIf(CustomerID <> 0 And CustomerID <> -1, CustomerID, "")

                If Not Request.QueryString("StandAloneCMF") Is Nothing Then
                    If Request.QueryString("StandAloneCMF") <> "" Then
                        StandaloneCMF = Request.QueryString("StandAloneCMF")
                    End If
                End If

                txtcomments.Text = "Positives :-" & vbNewLine & "Occurred :-" & vbNewLine & "VNA :-" & vbNewLine & "Soft Skills / Sales Skills :-" & vbNewLine & "Product / Compliance :-" & vbNewLine & "Areas of Improvement :-" & vbNewLine & "Suggestions / POA :-" & vbNewLine & "Others :-"
                getCMFFillHeader()
                CreateForm()
                PopulateCMF()
                GetTransactionData()
                If StandaloneCMF Then
                    btnSave.Visible = False
                End If
            Else
                'Session("AgentID") = UserID
                'Session("UserName") = LoginUserName
                CreateForm()
            End If
            If StandaloneCMF Then
                btnSave.Enabled = False
            End If

            'Adding Dispute Item
            'love Holiday Campaign 341
            If CampaignID = 341 Then
                SetDisputeDisable_341()
                'Tribune Ad Hub Campaign 342
            ElseIf CampaignID = 342 Then
                SetDisputeDisable_342()
            Else
                btnDispute.Visible = False
                BtnAcceptDispute.Visible = False
                BtnRejectDispute.Visible = False
            End If

        Catch ex As Exception
            lblerror.Text = ex.ToString
            lblerror.Visible = True
        End Try
    End Sub
#End Region

#Region "Generate CMF Sheet"

    Private Sub getCMFFillHeader()
        Dim dr As DataRow
        Dim db2 As New DBAccess("CRM")
        Try
            db2.slDataAdd("sheetid", SheetID)
            db2.slDataAdd("transid", TransID)
            db2.slDataAdd("agentid", AgentID)
            db2.slDataAdd("QEID", QEID)
            db2.slDataAdd("transdate", TransDate)
            db2.slDataAdd("CampaignID", CampaignID)

            dr = db2.ReturnRow("usp_Quality_FillCMFheader", True)
            db2 = Nothing

            lblQEName.Text = LoginUserName
            If Not dr Is Nothing Then
                lblTMName.Text = dr("AgentName")
                lblProcess.Text = dr("CampaignName")
                lblevldate.Text = IIf(IsDBNull(dr("EvaluationDate")), "", dr("EvaluationDate"))
                lblTransDate.Text = IIf(IsDBNull(dr("Transdate")), "", dr("Transdate"))
                btFreez = IIf(dr("btFreez") Is Nothing, False, dr("btFreez"))
                CBReferClient.Checked = IIf(IsDBNull(dr("ClientSheet")), "False", dr("ClientSheet"))
                lblQEName.Text = IIf(IsDBNull(dr("QEName")), LoginUserName, dr("QEName"))
                QEID = IIf(IsDBNull(dr("QEID")), LoginUserName, dr("QEID"))
                If btFreez Then
                    lblTmComments.Visible = True
                    lblComments.Visible = True
                    lblTMAcceptance.Visible = True
                    ImgAcceptanceStatus.Visible = True
                    lblAcceptanceStauts.Visible = True
                    lblComments.Text = dr("AcknowledgementComments").ToString
                    If dr("AcknowledgementStatus") = 1 Then
                        ImgAcceptanceStatus.ImageUrl = "~/_assets/img/yes.gif"
                        lblAcceptanceStauts.Text = "Accepted"
                    ElseIf dr("AcknowledgementStatus") = 2 Then
                        ImgAcceptanceStatus.ImageUrl = "~/_assets/img/remove.gif"
                        lblAcceptanceStauts.Text = "Rejected"
                    Else
                        ImgAcceptanceStatus.ImageUrl = "~/_assets/img/why.gif"
                        lblAcceptanceStauts.Text = "Pending"
                    End If
                Else
                    lblTmComments.Visible = False
                    lblComments.Visible = False
                    lblTMAcceptance.Visible = False
                    ImgAcceptanceStatus.Visible = False
                    lblAcceptanceStauts.Visible = False
                End If

            End If



            If dr Is Nothing Then
                lblTL.Text = ""
            ElseIf IsDBNull(dr("SupervisorName")) Then
                lblTL.Text = ""
            Else
                lblTL.Text = IIf(dr Is Nothing, "", dr("SupervisorName")) & "(" & dr("SupervisorID") & ")"
                SupervisorID = IIf(dr Is Nothing, "", dr("SupervisorID"))
            End If
        Catch ex As Exception
            lblerror.Text = ex.ToString
            lblerror.Visible = True
        Finally
            db2 = Nothing
        End Try

    End Sub

    Private Sub PopulateCMF()
        Try
            Dim db As New DBAccess("CRM")
            db.slDataAdd("campid", CampaignID)
            db.slDataAdd("CMFID", CMFID)
            db.slDataAdd("sheetID", SheetID)
            Dim dt As DataTable = db.ReturnTable("usp_Quality_getCategoryHeading", , True)
            maincat.DataSource = dt
            maincat.DataBind()
            db = Nothing

            If SheetID <> 0 Then
                lblSheetID.Text = "CMF Sheet " & SheetID
                lblSheetID.Visible = True
            Else
                lblSheetID.Visible = False
            End If

            Dim dtComm As DataTable
            If SheetID <> 0 Then
                db = New DBAccess("CRM")
                db.slDataAdd("campid", CampaignID)
                db.slDataAdd("Sheetid", SheetID)
                dtComm = db.ReturnTable("usp_QualityGetDataForLead_final_new", "option", True)
                db = Nothing
                If dtComm.Rows.Count > 0 Then
                    txtcomments.Text = dtComm.Rows(0).Item("comments")
                    txtComplaints.Text = dtComm.Rows(0).Item("EndUserCompliant")
                End If
            End If

            If btFreez Then
                db = New DBAccess("CRM")
                db.slDataAdd("SheetID", SheetID)
                Dim dr As DataRow = db.ReturnRow("usp_QualityGetSheetQCScore_New", True)
                PnlScore.Visible = True
                lblFatalError.Text = dr.Item("FatalErrorCount")
                lblFatalErrorpercent.Text = dr.Item("FAR%")
                lblNonFatalError.Text = dr.Item("NonFatalErrorCount")
                lblNonFatalErrorpercent.Text = dr.Item("NFAR%")
                LblParamwisescore.Text = dr.Item("ParameterWiseScore%")
                GridViewExportUtil.PrintPreview(PanelCMF)
                btnSave.Visible = False
                btnfreez.Visible = False
                btnPrint.Visible = True
                db = Nothing
            End If
            'Adding Dispute Item
            'love Holiday Campaign 341
            'If CampaignID = 341 Then
            '    SetDisputeDisable_341()
            '    'Tribune Ad Hub Campaign 342
            'ElseIf CampaignID = 342 Then
            '    SetDisputeDisable_342()
            'Else
            '    btnDispute.Visible = False
            '    BtnAcceptDispute.Visible = False
            '    BtnRejectDispute.Visible = False
            'End If

        Catch ex As Exception
            lblerror.Text = ex.ToString
            lblerror.Visible = True
        End Try

    End Sub

    Private Sub SetDisputeDisable_342()
        If Val(lblFatalError.Text) > 0 Then
            If (lblevldate.Text.Trim() <> "") Then
                Dim evalDate As DateTime = lblevldate.Text
                If DateDiff("d", evalDate, DateTime.Now) <= 3 Then

                    btnDispute.Visible = True
                    btnSaveDispute.Enabled = True
                    BtnAcceptDispute.Visible = True
                    BtnRejectDispute.Visible = True
                    btnDispute.Enabled = True
                    BtnAcceptDispute.Enabled = False
                    BtnRejectDispute.Enabled = False
                    SetDisputeDisableonData()
                Else

                    btnDispute.Visible = True
                    BtnAcceptDispute.Visible = True
                    BtnRejectDispute.Visible = True
                    btnDispute.Enabled = False
                    BtnAcceptDispute.Enabled = False
                    BtnRejectDispute.Enabled = False
                    SetDisputeDisableonData()
                End If
            Else
                btnDispute.Visible = False
                BtnAcceptDispute.Visible = False
                BtnRejectDispute.Visible = False
            End If
            SetDisputeDisableonCampaign()
        Else

            btnDispute.Visible = False
            BtnAcceptDispute.Visible = False
            BtnRejectDispute.Visible = False
        End If
    End Sub

    Private Sub SetDisputeDisable_341()
        If Val(lblFatalError.Text) > 0 Then
            If (lblevldate.Text.Trim() <> "") Then
                Dim evalDate As DateTime = lblevldate.Text
                If DateDiff("d", evalDate, DateTime.Now) <= 3 Then

                    btnDispute.Visible = True
                    btnSaveDispute.Enabled = True
                    BtnAcceptDispute.Visible = True
                    BtnRejectDispute.Visible = True
                    btnDispute.Enabled = True
                    BtnAcceptDispute.Enabled = False
                    BtnRejectDispute.Enabled = False
                    SetDisputeDisableonData()
                Else

                    btnDispute.Visible = True
                    BtnAcceptDispute.Visible = True
                    BtnRejectDispute.Visible = True
                    btnDispute.Enabled = False
                    BtnAcceptDispute.Enabled = False
                    BtnRejectDispute.Enabled = False
                    SetDisputeDisableonData()
                End If
            Else
                btnDispute.Visible = False
                BtnAcceptDispute.Visible = False
                BtnRejectDispute.Visible = False
            End If
            SetDisputeDisableonCampaign()
        Else
            btnDispute.Visible = False
            BtnAcceptDispute.Visible = False
            BtnRejectDispute.Visible = False
        End If
    End Sub
    Private Sub SetDisputeDisableonData()
        Dim db As New DBAccess("CRM")




        Dim dt1 As DataTable
        db.slDataAdd("AgentID", AgentID)
        db.slDataAdd("TransId", TransID)
        db.slDataAdd("CampaignID", CampaignID)
        dt1 = db.ReturnTable("[usp_Get_Disputes_Data]", , True)


        If dt1.Rows.Count > 0 Then

            For Each row As DataRow In dt1.Rows

                If DateDiff("d", row.Item("DisputeDateTime"), DateTime.Now) <= 2 Then
                    btnDispute.Visible = True
                    BtnAcceptDispute.Visible = True
                    BtnRejectDispute.Visible = True
                    btnDispute.Enabled = True
                    BtnAcceptDispute.Enabled = False
                    BtnRejectDispute.Enabled = False
                Else
                    btnDispute.Visible = True
                    BtnAcceptDispute.Visible = True
                    BtnRejectDispute.Visible = True
                    btnDispute.Enabled = False
                    BtnAcceptDispute.Enabled = False
                    BtnRejectDispute.Enabled = False
                End If
            Next
        Else

            btnDispute.Visible = True
            BtnAcceptDispute.Visible = True
            BtnRejectDispute.Visible = True
            btnDispute.Enabled = True
            BtnAcceptDispute.Enabled = True
            BtnRejectDispute.Enabled = True
        End If

    End Sub
    Private Function SendDisputeRaisedMail() As Boolean
        Try

            'Dim objWSMail As New MailSendServiceXX.Service1SoapClient
            'As New MailSendServiceXX.Service1SoapClient
            Dim strFrom As String = System.Configuration.ConfigurationManager.AppSettings("FROM")

            Dim strMailBody As String = ""
            Dim _index As Integer = 1

            ' Dim AgentName As New StringBuilder
            'For Each agent In agentsCSV.Split(",")
            '    AgentName.Append(Convert.ToString(_index) & "). " & agent & ".")
            '    AgentName.Append("</ br>")
            '    _index = _index + 1
            'Next

            Dim db As New DBAccess("CRM")
            Dim dt1 As DataTable
            db.slDataAdd("AgentID", AgentID)
            db.slDataAdd("TransId", TransID)
            db.slDataAdd("CampaignID", CampaignID)
            dt1 = db.ReturnTable("[usp_Get_Disputes_Data]", , True)

            Dim AgentName As String = ""
            Dim QEAgentName As String = ""
            Dim SupervisorName As String
            Dim LeadID As String = ""
            Dim DisputeDatetime As String = ""
            Dim DisputeType As String = ""
            Dim AgentComment As String = ""
            Dim QAAgentComment As String = ""
            Dim MailToEmailIDs As String = ""
            Dim QEEmailID As String = ""
            Dim TMEmailID As String = ""
 
            If dt1.Rows.Count > 0 Then
                For Each row As DataRow In dt1.Rows
                    AgentName = row.Item("AgentName")
                    QEAgentName = row.Item("QEAgentName")
                    SupervisorName = row.Item("SupervisorName")
                    LeadID = row.Item("LeadID")
                    DisputeType = row.Item("DisputeType")
                    AgentComment = row.Item("AgentComment")
                    QAAgentComment = row.Item("QAAgentComment")
                    DisputeDatetime = row.Item("DisputeDatetime")
                    TMEmailID = row.Item("AgentEmailID")
                    QEEmailID = row.Item("QEEmail")
                    If CampaignID = 341 Then
                        ' MailToEmailIDs = row.Item("AgentEmailID") + "," + row.Item("SupervisorEmail") + "," + row.Item("QEEmail") + "," + System.Configuration.ConfigurationManager.AppSettings("Loveholidaysleaders")
                        'MailToEmailIDs = row.Item("AgentEmailID") + "," + row.Item("SupervisorEmail") + "," + System.Configuration.ConfigurationManager.AppSettings("Quality") + "," + System.Configuration.ConfigurationManager.AppSettings("Loveholidaysleaders")
                        MailToEmailIDs = row.Item("SupervisorEmail") + "," + System.Configuration.ConfigurationManager.AppSettings("Quality") + "," + System.Configuration.ConfigurationManager.AppSettings("Loveholidaysleaders")
                    ElseIf CampaignID = 342 Then
                        'MailToEmailIDs = row.Item("AgentEmailID") + "," + row.Item("SupervisorEmail") + "," + row.Item("QEEmail") + "," + "Keshav.Mishra@coforge.com"
                        MailToEmailIDs = row.Item("SupervisorEmail") + "," + row.Item("QEEmail") + "," + System.Configuration.ConfigurationManager.AppSettings("TribuneManagers")
                    End If






                Next
            End If

            Dim dt As DataTable = db.ReturnTable("Select  tm.agentID as agentID,tm.lanID as LanID from tbl_AgentMaster tm  where  tm.AgentID  = '" & UserID & "' ")

            If dt.Rows.Count > 0 Then
                For Each row As DataRow In dt.Rows
                    If row.Item("AgentID") = "36" Or "52" Then 'For Textbox

                    End If
                Next
            End If

            Dim MailSubject As String = "Dispute Raised By (" & AgentName & ")>>" & "Reference No:" & AnsText_ReferenceNo


            strMailBody += "<html xmlns='http://www.w3.org/1999/xhtml'>"
            strMailBody += "<body style='font-family: Verdana; font-size: .8em'>"
            strMailBody += "Hope you doing well !!:<br />"
            strMailBody += "Disputes Raised.:<br /><br />"
            strMailBody += "Actions(Accept/Reject) required as soon as possible :<br />"
            strMailBody += "<table border='1' width='90%' style='border: 1px solid; border-collapse: collapse; font-family: Verdana; font-size: .8em'>"
            strMailBody += "<tr bgcolor='#B8CCE4'>"
            strMailBody += "<td align='center'><b>Agent Name</b></td>"
            strMailBody += "<td align='center'><b>Processing Date</b></td>"
            strMailBody += "<td align='center'><b>Work Type</b></td>"
            strMailBody += "<td align='center'><b>Reference# </b></td>"
            strMailBody += "<td align='center'><b>Lead# </b></td>"
            strMailBody += "<td align='center'><b>Dispute DateTime</b></td>"
            strMailBody += "<td align='center'><b>Dispute Type</b></td>"
            strMailBody += "<td align='center'><b>TM Commnets</b></td>"
            strMailBody += "<td align='center'><b>QE AgentName</b></td>"
            strMailBody += "<td align='center'><b>QE Comments</b></td>"
            strMailBody += "</tr>"
            strMailBody += "<tr >"
            strMailBody += "<td align='center'>" & AgentName & "</td>"
            strMailBody += "<td align='center'>" & lblevldate.Text & "</td>"
            strMailBody += "<td align='center'>" & AnsText_Worktype & "</td>"
            strMailBody += "<td align='center'>" & AnsText_ReferenceNo & "</td>"
            strMailBody += "<td align='center'>" & LeadID & "</td>"
            strMailBody += "<td align='center'>" & DisputeDatetime & "</td>"
            strMailBody += "<td align='center'>" & DisputeType & "</td>"
            strMailBody += "<td align='center'>" & AgentComment & "</td>"
            strMailBody += "<td align='center'>" & QEAgentName & "</td>"
            strMailBody += "<td align='center'>" & QAAgentComment & "</td>"
            strMailBody += "</tr>"
            strMailBody += "</table>"

            strMailBody += "<br /><br />"

            strMailBody += "<p>"
            strMailBody += "Thank You."
            strMailBody += "</p>"



            strMailBody += "</body>"
            strMailBody += "</html>"




            ''Dev One
            'objWSMail.MailSendNewTech(System.Configuration.ConfigurationManager.AppSettings("WSR_PIP_ProcessManager"), MailSubject, "Dispute Data Issue <" & strFrom & ">", "", strMailBody.ToString(), "", "", System.Configuration.ConfigurationManager.AppSettings("BCC"), "") '' Final

            
            ''Live One
            'objWSMail.MailSendNewTech(MailToEmailIDs, MailSubject, "Dispute Data Issue <" & strFrom & ">", "", strMailBody.ToString(), "", TMEmailID, System.Configuration.ConfigurationManager.AppSettings("WSR_PIP_ProcessManager"), "") '' Final

            Common.SMTPSendMail(MailToEmailIDs, MailSubject, "Dispute Data Issue <" & strFrom & ">", strMailBody.ToString(), TMEmailID, System.Configuration.ConfigurationManager.AppSettings("WSR_PIP_ProcessManager"))
            'objWSMail = Nothing

            Return True
        Catch ex As Exception
            '  AlertMessage("Error in sendPIPIssuedMailToHR. description :- " & ex.Message)
            Return False
        End Try
    End Function


    Private Function SendDisputeAcceptedMail() As Boolean
        Try
            'Dim objWSMail As New ServiceReference2.MailSoapClient
            'Dim objWSMail As New MailSendServiceXX.Service1SoapClient
            'As New MailSendServiceXX.Service1SoapClient
            Dim strFrom As String = System.Configuration.ConfigurationManager.AppSettings("FROM")

            Dim strMailBody As String = ""
            Dim _index As Integer = 1

            ' Dim AgentName As New StringBuilder
            'For Each agent In agentsCSV.Split(",")
            '    AgentName.Append(Convert.ToString(_index) & "). " & agent & ".")
            '    AgentName.Append("</ br>")
            '    _index = _index + 1
            'Next

            Dim db As New DBAccess("CRM")
            Dim dt1 As DataTable
            db.slDataAdd("AgentID", AgentID)
            db.slDataAdd("TransId", TransID)
            db.slDataAdd("CampaignID", CampaignID)
            dt1 = db.ReturnTable("[usp_Get_Disputes_Data]", , True)

            Dim AgentName As String = ""

            Dim SupervisorName As String
            Dim LeadID As String = ""
            Dim DisputeDatetime As String = ""
            Dim DisputeType As String = ""
            Dim AgentComment As String = ""
            Dim QAAgentComment As String = ""
            Dim MailToEmailIDs As String = ""
            Dim QEEmailID As String = ""
            Dim TMEmailID As String = ""

            If dt1.Rows.Count > 0 Then
                For Each row As DataRow In dt1.Rows
                    AgentName = row.Item("AgentName")
                    SupervisorName = row.Item("SupervisorName")
                    LeadID = row.Item("LeadID")
                    DisputeType = row.Item("DisputeType")
                    AgentComment = row.Item("AgentComment")
                    QAAgentComment = row.Item("QAAgentComment")
                    DisputeDatetime = row.Item("DisputeDatetime")
                    TMEmailID = row.Item("AgentEmailID")
                    QEEmailID = row.Item("QEEmail")
                    If CampaignID = 341 Then
                        ' MailToEmailIDs = row.Item("AgentEmailID") + "," + row.Item("SupervisorEmail") + "," + row.Item("QEEmail") + "," + System.Configuration.ConfigurationManager.AppSettings("Loveholidaysleaders")
                        'MailToEmailIDs = row.Item("AgentEmailID") + "," + row.Item("SupervisorEmail") + "," + System.Configuration.ConfigurationManager.AppSettings("Quality") + "," + System.Configuration.ConfigurationManager.AppSettings("Loveholidaysleaders")
                        MailToEmailIDs = row.Item("SupervisorEmail") + "," + System.Configuration.ConfigurationManager.AppSettings("Quality") + "," + System.Configuration.ConfigurationManager.AppSettings("Loveholidaysleaders")
                    ElseIf CampaignID = 342 Then
                        'MailToEmailIDs = row.Item("AgentEmailID") + "," + row.Item("SupervisorEmail") + "," + row.Item("QEEmail") + "," + "Keshav.Mishra@coforge.com"
                        MailToEmailIDs = row.Item("SupervisorEmail") + "," + row.Item("QEEmail") + "," + System.Configuration.ConfigurationManager.AppSettings("TribuneManagers")
                    End If






                Next
            End If

            Dim dt As DataTable = db.ReturnTable("Select  tm.agentID as agentID,tm.lanID as LanID from tbl_AgentMaster tm  where  tm.AgentID  = '" & UserID & "' ")

            If dt.Rows.Count > 0 Then
                For Each row As DataRow In dt.Rows
                    If row.Item("AgentID") = "36" Or "52" Then 'For Textbox

                    End If
                Next
            End If

          
            Dim MailSubject As String = "Dispute Accepted  for (" & AgentName & ")>>" & "Reference No:" & AnsText_ReferenceNo


            strMailBody += "<html xmlns='http://www.w3.org/1999/xhtml'>"
            strMailBody += "<body style='font-family: Verdana; font-size: .8em'>"
            strMailBody += "Hope you doing well !!:<br />"
            strMailBody += "Disputes Actions taken.:<br /><br />"
            strMailBody += "Actions(Accepted) :<br />"
            strMailBody += "<table border='1' width='90%' style='border: 1px solid; border-collapse: collapse; font-family: Verdana; font-size: .8em'>"
            strMailBody += "<tr bgcolor='#B8CCE4'>"
            strMailBody += "<td align='center'><b>Agent Name</b></td>"
            strMailBody += "<td align='center'><b>Processing Date</b></td>"
            strMailBody += "<td align='center'><b>Work Type</b></td>"
            strMailBody += "<td align='center'><b>Reference# </b></td>"
            strMailBody += "<td align='center'><b>Lead# </b></td>"
            strMailBody += "<td align='center'><b>Dispute DateTime</b></td>"
            strMailBody += "<td align='center'><b>Dispute Type</b></td>"
            strMailBody += "<td align='center'><b>TM Commnets</b></td>"
            strMailBody += "<td align='center'><b>QE Comments</b></td>"
            strMailBody += "</tr>"
            strMailBody += "<tr >"
            strMailBody += "<td align='center'>" & AgentName & "</td>"
            strMailBody += "<td align='center'>" & lblevldate.Text & "</td>"
            strMailBody += "<td align='center'>" & AnsText_Worktype & "</td>"
            strMailBody += "<td align='center'>" & AnsText_ReferenceNo & "</td>"
            strMailBody += "<td align='center'>" & LeadID & "</td>"
            strMailBody += "<td align='center'>" & DisputeDatetime & "</td>"
            strMailBody += "<td align='center'>" & DisputeType & "</td>"
            strMailBody += "<td align='center'>" & AgentComment & "</td>"
            strMailBody += "<td align='center'>" & QAAgentComment & "</td>"
            strMailBody += "</tr>"
            strMailBody += "</table>"

            strMailBody += "<br /><br />"

            strMailBody += "<p>"
            strMailBody += "Thank You."
            strMailBody += "</p>"



            strMailBody += "</body>"
            strMailBody += "</html>"




            'Dev
            ' objWSMail.MailSendNewTech(System.Configuration.ConfigurationManager.AppSettings("WSR_PIP_ProcessManager"), MailSubject, "Dispute Data Issue <" & strFrom & ">", "", strMailBody.ToString(), "", "", System.Configuration.ConfigurationManager.AppSettings("BCC"), "") '' Final

            ''Live One
            'objWSMail.MailSendNewTech(TMEmailID, MailSubject, "Dispute Data Issue <" & strFrom & ">", "", strMailBody.ToString(), "", MailToEmailIDs, System.Configuration.ConfigurationManager.AppSettings("WSR_PIP_ProcessManager"), "") '' Final
            Common.SMTPSendMail(TMEmailID, MailSubject, "Dispute Data Issue <" & strFrom & ">", strMailBody.ToString(), MailToEmailIDs, System.Configuration.ConfigurationManager.AppSettings("WSR_PIP_ProcessManager"))

            'objWSMail = Nothing

            Return True
        Catch ex As Exception
            '  AlertMessage("Error in sendPIPIssuedMailToHR. description :- " & ex.Message)
            Return False
        End Try
    End Function

    Private Function SendDisputeRejectedMail() As Boolean
        Try
            'Dim objWSMail As New ServiceReference2.MailSoapClient
            'Dim objWSMail As New MailSendServiceXX.Service1SoapClient
            'As New MailSendServiceXX.Service1SoapClient
            Dim strFrom As String = System.Configuration.ConfigurationManager.AppSettings("FROM")

            Dim strMailBody As String = ""
            Dim _index As Integer = 1

            ' Dim AgentName As New StringBuilder
            'For Each agent In agentsCSV.Split(",")
            '    AgentName.Append(Convert.ToString(_index) & "). " & agent & ".")
            '    AgentName.Append("</ br>")
            '    _index = _index + 1
            'Next

            Dim db As New DBAccess("CRM")
            Dim dt1 As DataTable
            db.slDataAdd("AgentID", AgentID)
            db.slDataAdd("TransId", TransID)
            db.slDataAdd("CampaignID", CampaignID)
            dt1 = db.ReturnTable("[usp_Get_Disputes_Data]", , True)

            Dim AgentName As String = ""

            Dim SupervisorName As String
            Dim LeadID As String = ""
            Dim DisputeDatetime As String = ""
            Dim DisputeType As String = ""
            Dim AgentComment As String = ""
            Dim QAAgentComment As String = ""
            Dim MailToEmailIDs As String = ""
            Dim QEEmailID As String = ""
            Dim TMEmailID As String = ""

            If dt1.Rows.Count > 0 Then
                For Each row As DataRow In dt1.Rows
                    AgentName = row.Item("AgentName")
                    SupervisorName = row.Item("SupervisorName")
                    LeadID = row.Item("LeadID")
                    DisputeType = row.Item("DisputeType")
                    AgentComment = row.Item("AgentComment")
                    QAAgentComment = row.Item("QAAgentComment")
                    DisputeDatetime = row.Item("DisputeDatetime")
                    TMEmailID = row.Item("AgentEmailID")
                    QEEmailID = row.Item("QEEmail")
                    If CampaignID = 341 Then
                        ' MailToEmailIDs = row.Item("AgentEmailID") + "," + row.Item("SupervisorEmail") + "," + row.Item("QEEmail") + "," + System.Configuration.ConfigurationManager.AppSettings("Loveholidaysleaders")
                        'MailToEmailIDs = row.Item("AgentEmailID") + "," + row.Item("SupervisorEmail") + "," + System.Configuration.ConfigurationManager.AppSettings("Quality") + "," + System.Configuration.ConfigurationManager.AppSettings("Loveholidaysleaders")
                        MailToEmailIDs = row.Item("SupervisorEmail") + "," + System.Configuration.ConfigurationManager.AppSettings("Quality") + "," + System.Configuration.ConfigurationManager.AppSettings("Loveholidaysleaders")
                    ElseIf CampaignID = 342 Then
                        'MailToEmailIDs = row.Item("AgentEmailID") + "," + row.Item("SupervisorEmail") + "," + row.Item("QEEmail") + "," + "Keshav.Mishra@coforge.com"
                        MailToEmailIDs = row.Item("SupervisorEmail") + "," + row.Item("QEEmail") + "," + System.Configuration.ConfigurationManager.AppSettings("TribuneManagers")
                    End If






                Next
            End If

            Dim dt As DataTable = db.ReturnTable("Select  tm.agentID as agentID,tm.lanID as LanID from tbl_AgentMaster tm  where  tm.AgentID  = '" & UserID & "' ")

            If dt.Rows.Count > 0 Then
                For Each row As DataRow In dt.Rows
                    If row.Item("AgentID") = "36" Or "52" Then 'For Textbox

                    End If
                Next
            End If

            Dim MailSubject As String = "Dispute Rejected  for (" & AgentName & ")>>" & "Reference No:" & AnsText_ReferenceNo


            strMailBody += "<html xmlns='http://www.w3.org/1999/xhtml'>"
            strMailBody += "<body style='font-family: Verdana; font-size: .8em'>"
            strMailBody += "Hope you doing well !!:<br />"
            strMailBody += "Disputes Actions taken.:<br /><br />"
            strMailBody += "Action (Rejected) :<br />"
            strMailBody += "<table border='1' width='90%' style='border: 1px solid; border-collapse: collapse; font-family: Verdana; font-size: .8em'>"
            strMailBody += "<tr bgcolor='#B8CCE4'>"
            strMailBody += "<td align='center'><b>Agent Name</b></td>"
            strMailBody += "<td align='center'><b>Processing Date</b></td>"
            strMailBody += "<td align='center'><b>Work Type</b></td>"
            strMailBody += "<td align='center'><b>Reference# </b></td>"
            strMailBody += "<td align='center'><b>Lead# </b></td>"
            strMailBody += "<td align='center'><b>Dispute DateTime</b></td>"
            strMailBody += "<td align='center'><b>Dispute Type</b></td>"
            strMailBody += "<td align='center'><b>TM Commnets</b></td>"
            strMailBody += "<td align='center'><b>QE Comments</b></td>"
            strMailBody += "</tr>"
            strMailBody += "<tr >"
            strMailBody += "<td align='center'>" & AgentName & "</td>"
            strMailBody += "<td align='center'>" & lblevldate.Text & "</td>"
            strMailBody += "<td align='center'>" & AnsText_Worktype & "</td>"
            strMailBody += "<td align='center'>" & AnsText_ReferenceNo & "</td>"
            strMailBody += "<td align='center'>" & LeadID & "</td>"
            strMailBody += "<td align='center'>" & DisputeDatetime & "</td>"
            strMailBody += "<td align='center'>" & DisputeType & "</td>"
            strMailBody += "<td align='center'>" & AgentComment & "</td>"
            strMailBody += "<td align='center'>" & QAAgentComment & "</td>"
            strMailBody += "</tr>"
            strMailBody += "</table>"

            strMailBody += "<br /><br />"

            strMailBody += "<p>"
            strMailBody += "Thank You."
            strMailBody += "</p>"



            strMailBody += "</body>"
            strMailBody += "</html>"




            ''Dev One
            ' objWSMail.MailSendNewTech(System.Configuration.ConfigurationManager.AppSettings("WSR_PIP_ProcessManager"), MailSubject, "Dispute Data Issue <" & strFrom & ">", "", strMailBody.ToString(), "", "", System.Configuration.ConfigurationManager.AppSettings("BCC"), "") '' Final

            'Live One
            '  objWSMail.MailSendNewTech(TMEmailID, MailSubject, "Dispute Data Issue <" & strFrom & ">", "", strMailBody.ToString(), "", MailToEmailIDs, System.Configuration.ConfigurationManager.AppSettings("WSR_PIP_ProcessManager"), "") '' Final
            Common.SMTPSendMail(TMEmailID, MailSubject, "Dispute Data Issue <" & strFrom & ">", strMailBody.ToString(), MailToEmailIDs, System.Configuration.ConfigurationManager.AppSettings("WSR_PIP_ProcessManager"))

            '            objWSMail = Nothing

            Return True
        Catch ex As Exception
            '  AlertMessage("Error in sendPIPIssuedMailToHR. description :- " & ex.Message)
            Return False
        End Try
    End Function
    Protected Sub btnDispute_Click(sender As Object, e As EventArgs) Handles btnDispute.Click
        Try



            btnSave.Text = "Save"
            btnSave.CommandArgument = ""
            lblDisputedBy.Enabled = False

            SetDisputeDisableonCampaign()
            Dim db As New DBAccess("CRM")




            Dim dt1 As DataTable
            db.slDataAdd("AgentID", AgentID)
            db.slDataAdd("TransId", TransID)
            db.slDataAdd("CampaignID", CampaignID)
            dt1 = db.ReturnTable("[usp_Get_Disputes_Data]", , True)

            Dim evalDate As DateTime = lblevldate.Text
            If dt1.Rows.Count > 0 Then

                For Each row As DataRow In dt1.Rows

                    If DateDiff("d", row.Item("DisputeDateTime"), DateTime.Now) <= 2 And DateDiff("d", evalDate, DateTime.Now) <= 3 Then



                        btnSaveDispute.Enabled = True
                        BtnAcceptDispute.Enabled = True
                        BtnRejectDispute.Enabled = True

                        gvRotDataDetail.DataSource = dt1
                        gvRotDataDetail.DataBind()

                        SetDisputeDisableonCampaign()
                    ElseIf DateDiff("d", row.Item("DisputeDateTime"), DateTime.Now) <= 2 And DateDiff("d", evalDate, DateTime.Now) > 3 Then
                        btnSaveDispute.Enabled = True
                        BtnAcceptDispute.Enabled = True
                        BtnRejectDispute.Enabled = True

                        gvRotDataDetail.DataSource = dt1
                        gvRotDataDetail.DataBind()

                        SetDisputeDisableonCampaign()
                    ElseIf DateDiff("d", row.Item("DisputeDateTime"), DateTime.Now) > 2 And DateDiff("d", evalDate, DateTime.Now) > 3 Then
                        btnSaveDispute.Enabled = False
                        BtnAcceptDispute.Enabled = False
                        BtnRejectDispute.Enabled = False

                        gvRotDataDetail.DataSource = dt1
                        gvRotDataDetail.DataBind()
                        SetDisputeDisableonCampaign()
                    End If
                    TMReason = row.Item("AgentComment")
                    QEReason = row.Item("QAAgentComment")
                Next
            Else
                btnSaveDispute.Enabled = True
                BtnAcceptDispute.Enabled = False
                BtnRejectDispute.Enabled = False

            End If



            lblSuppliers.Text = AnsText
            lblSuppliers.Enabled = False

            uc3Datetime.EnableViewState = False
            uc3Datetime.value = DateAndTime.Now.ToString("dd-MMM-yyyy HH:mm:ss")

            OpenDialog()
          
        Catch ex As Exception
            'AlertMessage("Error in PopulateGridView. description :- " & ex.Message)
            Throw ex
        End Try
    End Sub


  

    Private Sub SetDisputeDisableonCampaign()
        Dim db As New DBAccess("CRM")
        Dim dt As DataTable = db.ReturnTable("Select  tm.campaignID as campaignID from tbl_AgentMaster tm  where  tm.AgentID  = '" & UserID & "' ")

        If dt.Rows.Count > 0 Then
            For Each row As DataRow In dt.Rows
                If row.Item("campaignID") = "36" Then
                    txtQEReason.Enabled = True

                    txtTMReason.Enabled = False
                    lblDisputedBy.Text = UserID + "(" + LoginUserName + ")"
                    BtnAcceptDispute.Enabled = True
                    BtnRejectDispute.Enabled = True

                End If
                'LH 341
                'Tribune 342
                'Pammplin 366
                'NANT 367
                If row.Item("campaignID") = "341" Or row.Item("campaignID") = "342" Or row.Item("campaignID") = "366" Or row.Item("campaignID") = "367" Then
                    txtQEReason.Enabled = False
                    txtTMReason.Enabled = True
                    lblDisputedBy.Text = UserID + "(" + LoginUserName + ")"
                    BtnAcceptDispute.Enabled = False
                    BtnRejectDispute.Enabled = False

                End If

               
            Next

        End If
    End Sub
    Protected Sub gvRotDataDetail_RowEditing(sender As Object, e As GridViewEditEventArgs) Handles gvRotDataDetail.RowEditing
        Try
            btnSaveDispute.Text = "Update"

            Dim index As Integer = Convert.ToInt32(e.NewEditIndex)
            btnSaveDispute.CommandArgument = CType(gvRotDataDetail.Rows(index).FindControl("ltrlID"), Literal).Text
            'ddpAgent.SelectedValue = CType(gvRotDataDetail.Rows(index).FindControl("ltrlAgentID"), WebControls.Label).Text
            'ddpIssuePIP.SelectedValue = CType(gvRotDataDetail.Rows(index).FindControl("ltrlIssuePIP"), WebControls.Label).Text
            'ddpNewLevel.SelectedValue = CType(gvRotDataDetail.Rows(index).FindControl("ltrlLevelId"), WebControls.Label).Text
            'ddpNewStatus.SelectedValue = CType(gvRotDataDetail.Rows(index).FindControl("ltrlStatusId"), WebControls.Label).Text
            lblDisputedBy.Text = CType(gvRotDataDetail.Rows(index).FindControl("ltrlAgent"), Literal).Text

            txtTMReason.Text = CType(gvRotDataDetail.Rows(index).FindControl("ltrlTMReason"), WebControls.Literal).Text
            txtQEReason.Text = CType(gvRotDataDetail.Rows(index).FindControl("ltrlQCReason"), WebControls.Literal).Text
            'ucPIPStartDate.value = Convert.ToDateTime(CType(gvRotDataDetail.Rows(index).FindControl("ltrlStartDate"), Literal).Text)
            OpenDialog()
        Catch ex As Exception
            ' AlertMessage("Error in gvRotDataDetail_RowEditing. description :- " & ex.Message)
        End Try

    End Sub
    Protected Sub btnCancelDispute_Click(sender As Object, e As EventArgs) Handles btnCancelDispute.Click

        ClientScript.RegisterStartupScript([GetType](), "SetFocusScript", "<Script>self.close();</Script>")
    End Sub

    Protected Sub btnSaveDispute_Click(sender As Object, e As EventArgs) Handles btnSaveDispute.Click
        Try
            Dim Id As Integer = -1
            Dim UpdateFlag As Integer = 0
            If (btnSaveDispute.Text = "Update") Then
                Id = Convert.ToInt32(btnSaveDispute.CommandArgument)
                UpdateFlag = 1
            End If
            If txtTMReason.Text <> "" Then
                txtTMReason.Text = txtTMReason.Text
            Else
                txtTMReason.Text = TMReason
            End If




            If txtQEReason.Text <> "" Then
                txtQEReason.Text = txtQEReason.Text
            Else
                txtQEReason.Text = QEReason
            End If

            SetDispute(AgentID, SupervisorID, QEID, lblcmfid.Text, TransID, SheetID, lblSuppliers.Text, ddDisputeType.SelectedItem.Text, txtTMReason.Text, txtQEReason.Text, DateTime.Now(), CampaignID, AddNo, 0, UpdateFlag)
            SendDisputeRaisedMail()
        Catch ex As Exception
            'AlertMessage("Error in btnSave_Click. description :- " & ex.Message)
        End Try
    End Sub
    Protected Sub BtnAcceptDispute_Click(sender As Object, e As EventArgs) Handles BtnAcceptDispute.Click
        Try
            Dim db As New DBAccess("CRM")
            If CampaignID = "341" Then
                db.slDataAdd("CampaignID", CampaignID)
                db.slDataAdd("sheetid", SheetID)
                db.slDataAdd("DisputeType", ddDisputeType.SelectedItem.Text)
                db.slDataAdd("AcceptReject", "Accept")

                db.Executeproc("usp_UpdateDisputeStatus")

            ElseIf CampaignID = "342" Then
                db.slDataAdd("CampaignID", CampaignID)
                db.slDataAdd("sheetid", SheetID)
                db.slDataAdd("DisputeType", ddDisputeType.SelectedItem.Text)

                db.slDataAdd("AdNumber", AddNo)
                db.slDataAdd("AcceptReject", "Accept")

                db.Executeproc("usp_UpdateDisputeStatus")
            End If


            Dim Id As Integer = -1
            Dim UpdateFlag As Integer = 0
            If (btnSaveDispute.Text = "Update") Then
                Id = Convert.ToInt32(btnSaveDispute.CommandArgument)
                UpdateFlag = 1
            End If
            If txtTMReason.Text <> "" Then
                txtTMReason.Text = txtTMReason.Text
            Else
                txtTMReason.Text = TMReason
            End If




            If txtQEReason.Text <> "" Then
                txtQEReason.Text = txtQEReason.Text
            Else
                txtQEReason.Text = QEReason
            End If

            SetDispute(AgentID, SupervisorID, QEID, lblcmfid.Text, TransID, SheetID, lblSuppliers.Text, ddDisputeType.SelectedItem.Text, txtTMReason.Text, txtQEReason.Text, DateTime.Now(), CampaignID, AddNo, 0, UpdateFlag)
            SendDisputeAcceptedMail()
        Catch ex As Exception
            Throw ex
        End Try
     
    End Sub

    Protected Sub BtnRejectDispute_Click(sender As Object, e As EventArgs) Handles BtnRejectDispute.Click
        Try
            Dim db As New DBAccess("CRM")
            If CampaignID = "341" Then
                db.slDataAdd("CampaignID", CampaignID)
                db.slDataAdd("sheetid", SheetID)
                db.slDataAdd("DisputeType", ddDisputeType.SelectedItem.Text)
                db.slDataAdd("AcceptReject", "Reject")

                db.Executeproc("usp_UpdateDisputeStatus")

            ElseIf CampaignID = "342" Then
                db.slDataAdd("CampaignID", CampaignID)
                db.slDataAdd("sheetid", SheetID)
                db.slDataAdd("DisputeType", ddDisputeType.SelectedItem.Text)
                db.slDataAdd("AdNumber", AddNo)
                db.slDataAdd("AcceptReject", "Reject")

                db.Executeproc("usp_UpdateDisputeStatus")
            End If

            Dim Id As Integer = -1
            Dim UpdateFlag As Integer = 0
            If (btnSaveDispute.Text = "Update") Then
                Id = Convert.ToInt32(btnSaveDispute.CommandArgument)
                UpdateFlag = 1
            End If
            If txtTMReason.Text <> "" Then
                txtTMReason.Text = txtTMReason.Text
            Else
                txtTMReason.Text = TMReason
            End If




            If txtQEReason.Text <> "" Then
                txtQEReason.Text = txtQEReason.Text
            Else
                txtQEReason.Text = QEReason
            End If

            SetDispute(AgentID, SupervisorID, QEID, lblcmfid.Text, TransID, SheetID, lblSuppliers.Text, ddDisputeType.SelectedItem.Text, txtTMReason.Text, txtQEReason.Text, DateTime.Now(), CampaignID, AddNo, 0, UpdateFlag)
            SendDisputeRejectedMail()
        Catch ex As Exception
            Throw ex
        End Try

    End Sub

    Dim dt As DataTable
    Private Sub SetDispute(ByVal agentID As String, ByVal SupervisoragentID As String, ByVal QAagentID As String, ByVal LeadID As Integer, ByVal TransID As Integer, ByVal SheetID As Integer, ByVal SupplierName As String, ByVal Disputetype As String, ByVal AgentComment As String, ByVal QAAgentComment As String, ByVal DisputeDateTime As DateTime, CampaignID As Integer, Addno As String, ByVal ideleted As Integer, ByVal iupdateflag As Integer)
        Try
            Dim db As New DBAccess("CRM")
            'Dim db As New DBAccess("CRM")



            db.slDataAdd("agentID", agentID)
            db.slDataAdd("SupervisoragentID", SupervisoragentID)
            db.slDataAdd("QAagentID", QAagentID)
            db.slDataAdd("LeadID", LeadID)
            db.slDataAdd("TransID", TransID)
            db.slDataAdd("SheetID", SheetID)
            db.slDataAdd("SupplierName", SupplierName)
            db.slDataAdd("DisputeType", Disputetype)
            db.slDataAdd("AgentComment", AgentComment)
            db.slDataAdd("QAAgentComment", QAAgentComment)
            db.slDataAdd("DisputeDateTime", DisputeDateTime)
            db.slDataAdd("CampaignID", CampaignID)
            db.slDataAdd("AddNo", Addno)
            db.slDataAdd("iDeleted", ideleted)
            db.slDataAdd("iUPDATEFLAG", iupdateflag)

            dt = db.ReturnTable("[SET_DisputesActions]", , True)
            db = Nothing

            If (dt IsNot Nothing) Then
                Select Case (dt.Rows(0)("MESSAGE_TYPE"))
                    Case "S"

                        lblerror.Text = dt.Rows(0)("MESSAGE")
                        lblerror.Visible = True


                        PopulateGridView()
                        lblerror.Text = "Dispute Data Saved"

                    Case "E"
                        lblerror.Text = dt.Rows(0)("MESSAGE")
                        lblerror.Visible = True

                End Select
            End If

        Catch ex As Exception
            lblerror.Text = "Error in SetDispute. description :- " & ex.Message
            lblerror.Visible = True

        End Try
    End Sub
    Private Sub PopulateGridView()
        Try



            Dim dt1 As DataTable
            Dim db As New DBAccess("CRM")
            db.slDataAdd("AgentID", AgentID)
            db.slDataAdd("TransId", TransID)
            db.slDataAdd("CampaignID", CampaignID)
            dt1 = db.ReturnTable("[usp_Get_Disputes_Data]", , True)




            If dt1.Rows.Count > 0 Then


                gvRotDataDetail.DataSource = dt1
                gvRotDataDetail.DataBind()
               
            Else


                lblDispute.Visible = True
                lbluc3Datetime.Visible = True
                uc3Datetime.Visible = True

                lDisputedBy.Visible = True
                lblDisputedBy.Visible = True
                lSuppliers.Visible = True
                lblSuppliers.Visible = True
                lblDisputeType.Visible = True
                ddDisputeType.Visible = True
                lblTMReason.Visible = True
                txtTMReason.Visible = True
                lblQEReason.Visible = True
                txtQEReason.Visible = True
            End If



        Catch ex As Exception
            'AlertMessage("Error in PopulateGridView. description :- " & ex.Message)
            Throw ex
        End Try
    End Sub
    'Private Sub AlertMessage(ByVal msg As String)
    '    lblHumanMessage.Text = msg
    '    HumanMessage.CssClass = "HMFail"
    '    HumanMessage.Style.Item("visibility") = "visible"
    'End Sub

    'Private Sub SuccessMessage(ByVal msg As String)
    '    lblHumanMessage.Text = msg
    '    HumanMessage.CssClass = "HMSuccess"
    '    HumanMessage.Style.Item("visibility") = "visible"
    'End Sub

    Private Sub OpenDialog()
        Dim str As String
        str = "$('#DialogBackground').height($(document).height()-2);$('#DialogBackground').width($(window).width());$('#DialogBackground').css('visibility','visible');$('#PnlDisputFormAdd').css('visibility','visible'); $('#PnlDisputFormAdd').css('left',($(window).width() - $('#PnlDisputFormAdd').width())/2); "
        ScriptManager.RegisterStartupScript(Page, Page.GetType(), "Movedialog", str, True)
    End Sub
    'Private Sub OpenDialog2()
    '    Dim str As String
    '    str = "$('#DialogBackground').height($(document).height()-2);$('#DialogBackground').width($(window).width());$('#DialogBackground').css('visibility','visible');$('#PnlDisputFormExisting').css('visibility','visible'); $('#PnlDisputFormExisting').css('left',($(window).width() - $('#PnlDisputFormExisting').width())/2); "
    '    ScriptManager.RegisterStartupScript(Page, Page.GetType(), "Movedialog", str, True)
    'End Sub
    Protected Sub maincat_ItemDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.RepeaterItemEventArgs) Handles maincat.ItemDataBound
        Try
            Dim db As New DBAccess("CRM")
            Dim lblcatid1 As Label = e.Item.FindControl("lblcatid")
            Dim ds As New DataSet
            Dim subcat As DataTable
            db.slDataAdd("campid", CampaignID)
            db.slDataAdd("CMFID", CMFID)
            db.slDataAdd("mcid", lblcatid1.Text)
            db.slDataAdd("sheetID", SheetID)
            MainCatID = lblcatid1.Text
            subcat = db.ReturnTable("usp_QualityGetSubCategory_New", "subcat", True)
            db = Nothing
            ds.Tables.Add(subcat)
            Dim dtlst1 As Repeater = e.Item.FindControl("subcat")
            AddHandler dtlst1.ItemDataBound, AddressOf subcat_ItemDataBound
            dtlst1.DataSource = ds
            dtlst1.DataBind()
        Catch ex As Exception
            lblerror.Text = ex.ToString
            lblerror.Visible = True
        End Try
    End Sub

    Protected Sub subcat_ItemDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.RepeaterItemEventArgs)
        Try
            Dim lblcatid1 As Label = e.Item.FindControl("lblcatid1")
            Dim lblsubcatid1 As Label = e.Item.FindControl("lblsubcatid")
            Dim db As New DBAccess("CRM")
            'db.slDataAdd("campid", CampaignID)
            db.slDataAdd("mcid", lblcatid1.Text)
            db.slDataAdd("CMFID", CMFID)
            db.slDataAdd("scid", lblsubcatid1.Text)
            SubCatID = lblsubcatid1.Text
            MainCatID = lblcatid1.Text
            db.slDataAdd("sheetID", SheetID)
            dtparamdata = db.ReturnTable("usp_Quality_GetParameters", "Parameter", True)
            db = Nothing
            Dim cols() As String = {"ParamID", "ParmText", "Parametertype"}
            Dim dtq As DataTable = dtparamdata.DefaultView.ToTable(True, cols)
            Dim dtlst2 As DataList = e.Item.FindControl("dtlst")
            Dim pcount As Label = e.Item.FindControl("parameterCount")
            pcount.Text = dtq.Rows.Count
            AddHandler dtlst2.ItemDataBound, AddressOf dtlist_ItemDataBound
            dtlst2.DataSource = dtq
            dtlst2.DataBind()
            Dim ddoptions As DropDownList = e.Item.FindControl("ddlOptions")
            If btFreez Then
                ddoptions.Items.Clear()
            End If
        Catch ex As Exception
            lblerror.Text = ex.ToString
            lblerror.Visible = True
        End Try
    End Sub

    Protected Sub dtlist_ItemDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.DataListItemEventArgs)
        Try
            Dim lblcatid1 As Label = e.Item.Parent.Parent.Parent.Parent.FindControl("lblcatid")
            Dim lblsubcatid1 As Label = e.Item.Parent.Parent.FindControl("lblsubcatid")
            Dim ddoptions As DropDownList = e.Item.FindControl("ddParamOption")
            Dim lblparamid As Label = e.Item.FindControl("lblParamid")
            Dim lblparamtype As Label = e.Item.FindControl("lblparamtype")
            Dim lblparam As Label = e.Item.FindControl("lblparam")
            If lblparamtype.Text = "F" Then
                lblparam.ForeColor = System.Drawing.Color.Red
            End If
            'Dim db As New DBAccess("CRM")
            'Dim dtOption As New DataTable()
            'db.slDataAdd("paramid", lblparamid.Text)
            'db.slDataAdd("mcid", MainCatID)
            'db.slDataAdd("scid", SubCatID)
            'db.slDataAdd("Sheetid", SheetID)
            'dtOption = db.ReturnTable("usp_QualityGetParameterOptions_New", "option", True)
            'ddoptions.DataSource = dtOption
            'ddoptions.DataTextField = "OptionText"
            'ddoptions.DataValueField = "Optid"
            'ddoptions.DataBind()
            'db = Nothing
            Dim cols() As String = {"Optid", "OptionText", "SelectedOption", "Sequence"}
            Dim dtOption As DataTable = dtparamdata.Select("ParamID =" & lblparamid.Text, "Sequence").CopyToDataTable.DefaultView.ToTable(True, cols)
            ddoptions.DataSource = dtOption
            ddoptions.DataTextField = "OptionText"
            ddoptions.DataValueField = "Optid"
            ddoptions.DataBind()
            Dim drOpt() As DataRow = dtOption.Select("SelectedOption is not null")
            If drOpt.Length > 0 Then
                ddoptions.Items.FindByText(drOpt(0)("SelectedOption")).Selected = True
            End If
            '-------Panel Subparameters --start
            Dim chkSubParameter As CheckBoxList = e.Item.FindControl("chkBoxList1")

            'Dim dtSubParameters As New DataTable
            'db = New DBAccess("CRM")
            'db.slDataAdd("campid", CampaignID)
            'db.slDataAdd("mcid", lblcatid1.Text)
            'db.slDataAdd("scid", lblsubcatid1.Text)
            'db.slDataAdd("cmfid", CMFID)
            'db.slDataAdd("sheetid", SheetID)
            'db.slDataAdd("paramid", lblparamid.Text)
            'dtSubParameters = db.ReturnTable("usp_Quality_GetSubParameters", , True)
            Dim cols1() As String = {"SubParamID", "SubParmText", "ParamSequence"}
            Dim cols2() As String = {"Selected"}
            Dim dtSubParameters As New DataTable
            Dim dtSelectedSubParameters As New DataTable
            Dim dr() As DataRow = dtparamdata.Select("SubParamId is not null and ParamID =" & lblparamid.Text, "ParamSequence")
            If dr.Length > 0 Then
                dtSubParameters = dr.CopyToDataTable.DefaultView.ToTable(True, cols1)
                dtSelectedSubParameters = dr.CopyToDataTable.DefaultView.ToTable(True, cols2)
            End If
            If SheetID <> 0 Then
                If dtSubParameters.Rows.Count > 0 Then
                    If ddoptions.SelectedItem.Text = "No" Then
                        lblparam.Text = lblparam.Text & dtSubParameters.Rows.Count
                        Dim pnlSubQues As Panel = e.Item.FindControl("pnlSubQuestions")
                        pnlSubQues.Attributes.Add("style", "display:block")
                    End If
                Else
                    Dim pnlSubQues As Panel = e.Item.FindControl("pnlSubQuestions")
                    pnlSubQues.Attributes.Add("style", "display:none")
                End If
            End If
            If dtSubParameters.Rows.Count > 0 Then
                chkSubParameter.DataValueField = "SubParamID"
                chkSubParameter.DataTextField = "SubParmText"
                chkSubParameter.DataSource = dtSubParameters
                chkSubParameter.DataBind()
            End If
            '-------Panel Subparameters --end
            For Each li As ListItem In chkSubParameter.Items
                Dim r() As DataRow = dtSelectedSubParameters.Select("Selected='" & li.Value & "'")
                If r.Length > 0 Then
                    li.Selected = True
                End If
            Next
        Catch ex As Exception
            lblerror.Text = ex.ToString
            lblerror.Visible = True
        End Try
    End Sub

#End Region

#Region "----Support Functions"
    Private Sub CreateForm()
        'If Not IsPostBack Then
        Dim objTable As Table
        Dim objTablerow As TableRow
        Dim objTableCol As TableCell
        Dim objLabel As Label
        Dim objText As TextBox
        Dim objSelect As DropDownList

        Dim dtMandatoryQuest As New DataTable
        Dim db As DBAccess

        Dim iCtr As Integer
        pnlDynamicHeader.Controls.Remove(pnlDynamicHeader.FindControl("dynamic"))
        Try
            objTable = New Table
            objTable.ID = "dynamic"
            objTable.Width = System.Web.UI.WebControls.Unit.Percentage(100)
            objTable.CellSpacing = 0
            objTable.HorizontalAlign = HorizontalAlign.Center
            objTable.EnableViewState = True
            db = New DBAccess("CRM")
            db.slDataAdd("campaignid", CampaignID)
            db.slDataAdd("CMFID", CMFID)
            db.slDataAdd("sheetid", SheetID)

            dtMandatoryQuest = db.ReturnTable("usp_Quality_GetCMFfields", , True)
            db = Nothing
            If Not dtMandatoryQuest Is Nothing Then
                For iCtr = 0 To dtMandatoryQuest.Rows.Count - 1
                    objTablerow = New TableRow
                    objTablerow.ID = "TblRow" & dtMandatoryQuest.Rows(iCtr).Item("FieldID")
                    'objTablerow.BackColor = Color.LightGray
                    objTable.Rows.Add(objTablerow)
                    objTablerow.EnableViewState = True
                    objTableCol = New TableCell
                    objTablerow.Cells.Add(objTableCol)
                    objTableCol.EnableViewState = True
                    objTableCol.BackColor = System.Drawing.Color.Transparent
                    objTableCol.VerticalAlign = VerticalAlign.Top
                    objTableCol.HorizontalAlign = HorizontalAlign.Left
                    'objTableCol.Width = System.Web.UI.WebControls.Unit.Percentage(40)
                    objTableCol.Attributes.Add("style", "border-bottom: solid 1px #bbd9ee")
                    objLabel = New Label
                    objTableCol.Controls.Add(objLabel)
                    objLabel.Text = dtMandatoryQuest.Rows(iCtr).Item("FieldName")
                    objLabel.EnableViewState = True
                    objTableCol = New TableCell
                    objTablerow.Cells.Add(objTableCol)
                    objTableCol.BackColor = System.Drawing.Color.Transparent
                    objTableCol.VerticalAlign = VerticalAlign.Top
                    objTableCol.HorizontalAlign = HorizontalAlign.Left
                    'objTableCol.Width = System.Web.UI.WebControls.Unit.Percentage(55)
                    objTableCol.Attributes.Add("style", "border-bottom: solid 1px #bbd9ee")
                    objTableCol.EnableViewState = True
                    Select Case dtMandatoryQuest.Rows(iCtr).Item("Type")
                        Case 1
                            objText = New TextBox
                            objTableCol.Controls.Add(objText)
                            'objText.Text = dt.Rows(iCtr).Item("quest_dataheading")
                            'objText.Height = System.Web.UI.WebControls.Unit.Pixel(20)
                            objText.Width = System.Web.UI.WebControls.Unit.Percentage(79)
                            objText.MaxLength = 255
                            objText.Font.Size = System.Web.UI.WebControls.FontUnit.Point(10)
                            objText.BorderColor = Drawing.Color.AliceBlue
                            objText.ID = "Field" & dtMandatoryQuest.Rows(iCtr).Item("FieldID")

                            If Not IsDBNull(dtMandatoryQuest.Rows(iCtr).Item("SavedValue")) Then 'i.e value is present
                                objText.Text = dtMandatoryQuest.Rows(iCtr).Item("SavedValue")
                            ElseIf dtMandatoryQuest.Rows(iCtr).Item("FieldName") = "AHT" Then
                                Dim span As TimeSpan = New TimeSpan(TimeSpan.TicksPerSecond * Request.QueryString("duration"))
                                objText.Text = span.Hours.ToString("00") + ":" + span.Minutes.ToString("00") + ":" + span.Seconds.ToString("00")
                            ElseIf dtMandatoryQuest.Rows(iCtr).Item("FieldName").ToString.ToLower.Contains("Telephone No") Then
                                objText.Text = Request.QueryString("Telephone")
                            ElseIf dtMandatoryQuest.Rows(iCtr).Item("FieldName").ToString.ToLower.Contains("Ref Number") Then
                                objText.Text = Request.QueryString("Ref Number")
                            Else
                                objText.Text = "0"
                            End If

                            'objText.Text = IIf(IsDBNull(dtMandatoryQuest.Rows(iCtr).Item("SavedValue")), "", dtMandatoryQuest.Rows(iCtr).Item("SavedValue"))
                            objText.EnableViewState = True
                            objText.Attributes.Add("Type", dtMandatoryQuest.Rows(iCtr).Item("Type"))
                            objText.Visible = True
                            If dtMandatoryQuest.Rows(iCtr).Item("IsMandatory") Then
                                Dim valid = New RequiredFieldValidator
                                valid.ID = "valid" & dtMandatoryQuest.Rows(iCtr).Item("FieldID")
                                valid.ControlToValidate = objText.ID
                                valid.ErrorMessage = "Required"
                                'valid.Width = System.Web.UI.WebControls.Unit.Pixel(50)
                                'valid.Font.Size = System.Web.UI.WebControls.FontUnit.Point(8)
                                'valid.Display = ValidatorDisplay.None
                                objTableCol.Controls.Add(valid)
                            End If


                        Case 2
                            objSelect = New DropDownList
                            objSelect.Height = System.Web.UI.WebControls.Unit.Pixel(25)
                            objSelect.Width = System.Web.UI.WebControls.Unit.Percentage(80)
                            objSelect.Font.Size = System.Web.UI.WebControls.FontUnit.Small
                            objSelect.ID = "Field" & dtMandatoryQuest.Rows(iCtr).Item("FieldID")
                            objSelect.EnableViewState = True
                            objSelect.Attributes.Add("Type", dtMandatoryQuest.Rows(iCtr).Item("Type"))
                            Dim ans As DataTable

                            Dim db2 As New DBAccess("CRM")
                            db2.slDataAdd("CampaignID", CampaignID)
                            db2.slDataAdd("CMFID", CMFID)
                            db2.slDataAdd("FieldID", dtMandatoryQuest.Rows(iCtr).Item("FieldID"))
                            ans = db2.ReturnTable("usp_Quality_GetCMFfieldsMap", , True)
                            db2 = Nothing

                            If ans.Rows.Count > 0 Then
                                objSelect.DataSource = ans
                                objSelect.DataTextField = "FieldValue"
                                objSelect.DataValueField = "AnsID"
                                objSelect.DataBind()
                            End If
                            objSelect.Visible = True

                            If Not IsDBNull(dtMandatoryQuest.Rows(iCtr).Item("SavedValue")) Then
                                For Each e As ListItem In objSelect.Items
                                    If e.Text.Trim = dtMandatoryQuest.Rows(iCtr).Item("SavedValue").ToString().Trim Then
                                        e.Selected = True
                                    End If
                                Next
                            End If
                            objTableCol.Controls.Add(objSelect)
                    End Select
                Next
            End If

            pnlDynamicHeader.Controls.Add(objTable)
            pnlDynamicHeader.Enabled = True
            '***************TO Get the value of controls that are created dynamically.
        Catch ex As Exception
            lblerror.Text = ex.Message
            lblerror.Visible = True
        Finally
            dtMandatoryQuest = Nothing
        End Try
    End Sub

    Private Sub UpdateTransaction(ByVal val As String)
        Dim dbQuality As New DBAccess("CRM")
        dbQuality.slDataAdd("LID", CustomerID)
        dbQuality.slDataAdd("QAAgentId", UserID)
        dbQuality.slDataAdd("DialedNumber", "")
        dbQuality.slDataAdd("CampaignID", CampaignID)
        dbQuality.slDataAdd("CallTable", "")
        dbQuality.slDataAdd("ToInsert", 0)
        TransIDQuality = dbQuality.ReturnValue("usp_InsertTransaction_Quality", True)
        dbQuality = Nothing
        If TransIDQuality <> "0" Then
            If val = "update" Then
                Dim db As New DBAccess("CRM")
                db.slDataAdd("ID", TransIDQuality)
                db.slDataAdd("CustomerID", CustomerID)
                db.slDataAdd("ResultCode", -2)
                db.slDataAdd("CampaignID", CampaignID)
                db.Executeproc("usp_DisposeACall")
                db = Nothing
            End If
            If val = "delete" Then
                Dim dbcancel As New DBAccess("CRM")
                dbcancel.slDataAdd("Transid", TransIDQuality)
                dbcancel.Executeproc("usp_deleteTransaction")
                dbcancel = Nothing
            End If
        End If
    End Sub

    Private Sub GetTransactionData()
        Dim dt As New DataTable
        Dim db As New DBAccess("crm")
        db.slDataAdd("transid", TransID)
        dt = db.ReturnTable("usp_GetCMFTransactionDetails", , True)
        If dt.Rows.Count > 0 Then
            For Each row As DataRow In dt.Rows
                If row.Item("Caption") = "Supplier Name" Then 'For Textbox
                    AnsText = row.Item("AnsText")
                End If
                If row.Item("Caption") = "Worktype" Then 'For Textbox
                    AnsText_Worktype = row.Item("AnsText")
                End If
                If row.Item("Caption") = "Reference Number" Then
                    AnsText_ReferenceNo = row.Item("AnsText")
                End If
                If row.Item("Caption") = "Ad Number" Then
                    AddNo = row.Item("AnsText")
                End If
            Next

        End If
        db = Nothing
        dlAnswers.DataSource = dt
        dlAnswers.DataBind()
    End Sub
#End Region

#Region "Events"
    Protected Sub btnClose_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnClose.Click
        If Request.QueryString("sheetid") Is Nothing Then
            ' -- '18Dec2012
            '--------------------------------------------------------------
            ' Added to Save Transaction (12-12-12) 
            UpdateTransaction("delete")
            '--------------------------------------------------------------
        ElseIf Request.QueryString("sheetid") = 0 Then
            UpdateTransaction("delete")
        End If
        If Request.QueryString("Return") = "Report" Then
            Response.Redirect("~/Quality/SummaryReportPerAgentWise.aspx?QEID=" & Request.QueryString("QEID") & "&cmfid=" & Request.QueryString("BackCMFID") & "&calltype=" & Request.QueryString("CallType") & "&errortype=" & Request.QueryString("errortype") & "&campid=" & Request.QueryString("campid") & "&SupervisorID=" & Request.QueryString("SupervisorID") & "&Agentid=" & Request.QueryString("Agentid") & "&DateFrom=" & Request.QueryString("datefrom") & "&DateTo=" & Request.QueryString("dateto"))
        Else
            Response.Redirect(Request.QueryString("Return"))
        End If


    End Sub

    Protected Sub btnSave_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnSave.Click
        Dim SheetTemp As Integer
        Dim dtMandatoryQuest As DataTable
        Dim SheetDataID As Integer
        Dim transFlag As Boolean = True
        Dim returnNoUse_1 As String = ""
        Dim returnNoUse_2 As String = ""
        Dim flag As Boolean = False
        '------------------------------------------------------
        Dim db3 As New DBAccess("CRM")
        db3.slDataAdd("campaignid", CampaignID)
        db3.slDataAdd("CMFID", CMFID)
        db3.slDataAdd("sheetid", SheetID)
        dtMandatoryQuest = db3.ReturnTable("usp_Quality_GetCMFfields", , True)
        db3 = Nothing
        '------------------------------------------------------
        Dim db As New DBAccess("CRM")
        Try
            db.BeginTrans()
            '_-------------------------------------------
            db.slDataAdd("campid", CampaignID)
            db.slDataAdd("qeid", UserID)
            'db.slDataAdd("markedby", LoginUserName)
            db.slDataAdd("AgentID", AgentID)
            db.slDataAdd("CustomerID", CustomerID)
            db.slDataAdd("TransID", TransID)
            db.slDataAdd("CMFID", CMFID)
            db.slDataAdd("Comments", txtcomments.Text.Trim)

            db.slDataAdd("btfreez", False)
            db.slDataAdd("Endusercomp", txtComplaints.Text.Trim)
            If lblTL.Text.Trim = "" Then
                db.slDataAdd("SupervisorID", "")
            Else
                db.slDataAdd("SupervisorID", lblTL.Text.Trim.Substring(lblTL.Text.Trim.LastIndexOf("(")).Replace("(", "").Replace(")", ""))
            End If
            db.slDataAdd("ClientSheet", CBReferClient.Checked)

            '@AdNo
            db.slDataAdd("AdNo", AddNo)

            For Each row As DataRow In dtMandatoryQuest.Rows
                If row.Item("Type") = 1 Then 'For Textbox
                    db.slDataAdd("UDF" & row("FieldID"), CType(pnlDynamicHeader.FindControl("Field" & row("FieldID")), TextBox).Text)
                ElseIf row.Item("Type") = 2 Then 'For DropDownList
                    db.slDataAdd("UDF" & row("FieldID"), CType(pnlDynamicHeader.FindControl("Field" & row("FieldID")), DropDownList).SelectedItem.Text)
                End If
            Next
            '-----------------------------------
            db.slDataAdd("sheetid", SheetID)
            If SheetID = 0 Then
                If StandaloneCMF Then
                    db.slDataAdd("StandaloneCMF", StandaloneCMF)
                    db.slDataAdd("Transactiondate", IIf(TransDate Is Nothing, lblTransDate.Text, TransDate))
                End If
            End If

            '@AdNo
            SheetTemp = db.ReturnValue("usp_QualityInsertQMSheetMst_New1", True)
            ''----------------------------------------------
            For Each ctrl As Control In maincat.Controls
                Dim lblcatid1 As Label = ctrl.FindControl("lblcatid")
                Dim rpitem As RepeaterItem = ctrl.FindControl("lblsubcatid")
                For Each rpitem In ctrl.FindControl("subcat").Controls
                    Dim lblsubcatid1 As Label = rpitem.FindControl("lblsubcatid")
                    For Each lstitem As DataListItem In rpitem.FindControl("dtlst").Controls
                        Dim lblparamid As Label = lstitem.FindControl("lblParamid")
                        Dim ddoptions As DropDownList = lstitem.FindControl("ddParamOption")
                        db.slDataAdd("sheetid", SheetTemp)
                        db.slDataAdd("campid", CampaignID)
                        db.slDataAdd("paramid", lblparamid.Text)
                        db.slDataAdd("optid", ddoptions.SelectedValue)
                        db.slDataAdd("mcid", lblcatid1.Text)
                        db.slDataAdd("CMFID", CMFID)
                        db.slDataAdd("scid", lblsubcatid1.Text)
                        SheetDataID = db.ReturnValue("usp_QualityInsertSheetData_New", True)
                        Dim pnlSubQuestions As Panel = lstitem.FindControl("pnlSubQuestions")
                        Dim chkBoxList As CheckBoxList = pnlSubQuestions.FindControl("chkBoxList1")
                        db.exeSQL("DELETE FROM tbl_Quality_Data_SheetData_SubParams WHERE SheetDataID=" & SheetDataID)

                        flag = False  '(1)

                        '@20200627 Restrict check for Cox(372),Gannet(373),hearst(374)
                        ' ''If Not (CampaignID = 372 Or CampaignID = 373 Or CampaignID = 374) Then


                        ' ''    If ddoptions.Items.FindByText("No").Selected = True And chkBoxList.Items.Count > 0 Then
                        ' ''        For Each li As ListItem In chkBoxList.Items
                        ' ''            If li.Selected Then
                        ' ''                flag = True
                        ' ''                db.slDataAdd("SheetDataID", SheetDataID)
                        ' ''                'db4.slDataAdd("paramid", lblparamid.Text)
                        ' ''                db.slDataAdd("SubParamID", li.Value)
                        ' ''                ' db.Executeproc("usp_Quality_insertSubParameters")
                        ' ''                returnNoUse_1 = db.ReturnValue("usp_Quality_insertSubParameters", True)
                        ' ''            End If
                        ' ''        Next
                        ' ''    End If

                        ' ''    '(2)
                        ' ''    If ddoptions.Items.FindByText("No").Selected = True And chkBoxList.Items.Count > 0 Then 'if "No" is selected in answer option
                        ' ''        If flag = False Then 'i.e. if not any one subparameter is selected
                        ' ''            lblerror.Text = "Please select atleast one Subparameter in selected parameter."
                        ' ''            lblerror.Visible = True
                        ' ''            db.RollBackTrans()
                        ' ''            transFlag = False
                        ' ''            Exit Sub
                        ' ''        End If
                        ' ''    End If
                        ' ''End If

                    Next
                Next
            Next
            SheetID = SheetTemp
            db.slDataAdd("Sheetid", SheetID)
            returnNoUse_2 = db.ReturnValue("usp_QualitySaveSheetQCScore_New", True)
            db.CommitTrans()

            If Request.QueryString("sheetid") Is Nothing Then
                ' -- '18Dec2012
                '--------------------------------------------------------------
                ' Added to Save Transaction (12-12-12) 
                UpdateTransaction("update")
                '--------------------------------------------------------------
            ElseIf Request.QueryString("sheetid") = 0 Then
                UpdateTransaction("update")
            End If

        Catch ex As Exception
            lblerror.Text = ex.ToString
            lblerror.Visible = True
            db.RollBackTrans()
            transFlag = False
        Finally
            db = Nothing
            dtMandatoryQuest = Nothing
        End Try

        If transFlag Then
            Response.Redirect("~/Quality/^ListTransactions")
            'Response.Redirect("~/Quality/CMFForm.aspx?lid=" & Request.QueryString("lid") & "&campid=" & Request.QueryString("campid") & "&agentid=" & Request.QueryString("agentid") & "&TransID=" & Request.QueryString("TransID") & "&CMFID=" & CMFID & "&SheetID=" & SheetID & "&Return=ListTransactions.aspx" & "&LoginUserID=" & UserID & "&LoginUserName=" & LoginUserName)
        End If
    End Sub

    Protected Sub btnfreez_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnfreez.Click
        Dim SheetTemp As Integer
        Dim SheetDataID As Integer
        Dim dtMandatoryQuest As DataTable
        Dim flag As Boolean = False
        Dim transFlag As Boolean = True
        Dim returnNoUse_1 As String = ""
        Dim returnNoUse_2 As String = ""
        Dim db3 As New DBAccess("CRM")
        db3.slDataAdd("campaignid", CampaignID)
        db3.slDataAdd("CMFID", CMFID)
        db3.slDataAdd("sheetid", SheetID)
        dtMandatoryQuest = db3.ReturnTable("usp_Quality_GetCMFfields", , True)
        db3 = Nothing
        Dim db As New DBAccess("CRM")
        Try

            db.BeginTrans() '1
            db.slDataAdd("campid", CampaignID)
            db.slDataAdd("qeid", UserID)
            'db.slDataAdd("markedby", LoginUserName)
            db.slDataAdd("AgentID", AgentID)
            db.slDataAdd("CustomerID", CustomerID)
            db.slDataAdd("TransID", TransID)
            db.slDataAdd("CMFID", CMFID)
            db.slDataAdd("Comments", txtcomments.Text.Trim)
            db.slDataAdd("btfreez", True)
            db.slDataAdd("Endusercomp", txtComplaints.Text.Trim)
            If lblTL.Text.Trim = "" Then
                db.slDataAdd("SupervisorID", "")
            Else
                db.slDataAdd("SupervisorID", lblTL.Text.Trim.Substring(lblTL.Text.Trim.LastIndexOf("(")).Replace("(", "").Replace(")", ""))
            End If
            db.slDataAdd("ClientSheet", CBReferClient.Checked)


            '@AdNo
            db.slDataAdd("AdNo", AddNo)
            For Each row As DataRow In dtMandatoryQuest.Rows
                If row.Item("Type") = 1 Then 'For Textbox
                    db.slDataAdd("UDF" & row("FieldID"), CType(pnlDynamicHeader.FindControl("Field" & row("FieldID")), TextBox).Text)
                ElseIf row.Item("Type") = 2 Then 'For DropDownList
                    db.slDataAdd("UDF" & row("FieldID"), CType(pnlDynamicHeader.FindControl("Field" & row("FieldID")), DropDownList).SelectedItem.Text)
                End If
            Next
            '-----------------------------------
            db.slDataAdd("sheetid", SheetID)
            If SheetID = 0 Then
                If StandaloneCMF Then
                    db.slDataAdd("StandaloneCMF", StandaloneCMF)
                    db.slDataAdd("Transactiondate", IIf(TransDate Is Nothing, lblTransDate.Text, TransDate))
                End If
            End If

            '@AdNo
            SheetTemp = db.ReturnValue("usp_QualityInsertQMSheetMst_New1", True)
            'insert SheetData data
            For Each ctrl As Control In maincat.Controls
                Dim lblcatid1 As Label = ctrl.FindControl("lblcatid")
                Dim rpitem As RepeaterItem = ctrl.FindControl("lblsubcatid")
                For Each rpitem In ctrl.FindControl("subcat").Controls
                    Dim lblsubcatid1 As Label = rpitem.FindControl("lblsubcatid")
                    For Each lstitem As DataListItem In rpitem.FindControl("dtlst").Controls
                        Dim lblparamid As Label = lstitem.FindControl("lblParamid")
                        Dim ddoptions As DropDownList = lstitem.FindControl("ddParamOption")
                        db.slDataAdd("sheetid", SheetTemp)
                        db.slDataAdd("campid", CampaignID)
                        db.slDataAdd("paramid", lblparamid.Text)
                        db.slDataAdd("optid", ddoptions.SelectedValue)
                        db.slDataAdd("mcid", lblcatid1.Text)
                        db.slDataAdd("CMFID", CMFID)
                        db.slDataAdd("scid", lblsubcatid1.Text)
                        ddoptions.Enabled = False
                        SheetDataID = db.ReturnValue("usp_QualityInsertSheetData_New", True)
                        Dim pnlSubQuestions As Panel = lstitem.FindControl("pnlSubQuestions")
                        Dim chkBoxList As CheckBoxList = pnlSubQuestions.FindControl("chkBoxList1")
                        db.DeleteinTable("tbl_Quality_Data_SheetData_SubParams", "SheetDataID=" & SheetDataID)
                        flag = False

                        ' ''@20200627 Restrict check for Cox(372),Gannet(373),hearst(374)
                        'If Not (CampaignID = 372 Or CampaignID = 373 Or CampaignID = 374) Then


                        '    If ddoptions.Items.FindByText("No").Selected = True And chkBoxList.Items.Count > 0 Then
                        '        For Each li As ListItem In chkBoxList.Items
                        '            If li.Selected Then
                        '                flag = True
                        '                db.slDataAdd("SheetDataID", SheetDataID)
                        '                'db4.slDataAdd("paramid", lblparamid.Text)
                        '                db.slDataAdd("SubParamID", li.Value)
                        '                ' db.Executeproc("usp_Quality_insertSubParameters")
                        '                returnNoUse_1 = db.ReturnValue("usp_Quality_insertSubParameters", True)
                        '            End If
                        '        Next
                        '    End If

                        '    '(2)
                        '    If ddoptions.Items.FindByText("No").Selected = True And chkBoxList.Items.Count > 0 Then 'if "No" is selected in answer option
                        '        If flag = False Then 'i.e. if not any one subparameter is selected
                        '            lblerror.Text = "Please select atleast one Subparameter in selected parameter."
                        '            lblerror.Visible = True
                        '            db.RollBackTrans() '2
                        '            transFlag = False
                        '            Exit Sub
                        '        End If
                        '    End If
                        'End If



                    Next
                Next
            Next
            SheetID = SheetTemp
            db.slDataAdd("Sheetid", SheetID)
            returnNoUse_2 = db.ReturnValue("usp_QualitySaveSheetQCScore_New", True)
            db.CommitTrans() '3

            If Request.QueryString("sheetid") Is Nothing Then
                ' -- '18Dec2012
                '--------------------------------------------------------------
                ' Added to Save Transaction (12-12-12) 
                UpdateTransaction("update")
                '--------------------------------------------------------------
            ElseIf Request.QueryString("sheetid") = 0 Then
                UpdateTransaction("update")
            End If
        Catch ex As Exception
            lblerror.Text = ex.ToString
            lblerror.Visible = True
            db.RollBackTrans() '4
            transFlag = False
            Return
        Finally
            db = Nothing
        End Try
        If transFlag Then
            Response.Redirect("~/Quality/CMFForm.aspx?campid=" & Request.QueryString("campid") & "&standalonecmf=" & Request.QueryString("standalonecmf") & "&lid=" & Request.QueryString("lid") & "&agentid=" & Request.QueryString("agentid") & "&TransID=" & Request.QueryString("TransID") & "&CMFID=" & CMFID & "&SheetID=" & SheetID & "&Return=^ListTransactions" & "&LoginUserID=" & UserID & "&LoginUserName=" & LoginUserName)
        End If

    End Sub

#End Region

    Protected Sub btnCancel_Click(sender As Object, e As EventArgs) Handles btnCancel.Click

    End Sub

    Protected Sub txtComplaints_TextChanged(sender As Object, e As EventArgs) Handles txtComplaints.TextChanged

    End Sub
End Class
