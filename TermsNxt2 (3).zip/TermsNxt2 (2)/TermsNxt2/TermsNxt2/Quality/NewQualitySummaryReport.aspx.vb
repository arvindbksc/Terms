﻿Imports com.nss.DBAccess
Imports System.Data
Imports System.Text
Partial Class Quality_NewQualitySummaryReport
    Inherits System.Web.UI.Page
#Region "--- Properties ---"
    Property ProcessID() As Integer
        Get
            Return ViewState("ProcessID")
        End Get
        Set(ByVal value As Integer)
            ViewState("ProcessID") = value
            Session("ProcessID") = value
        End Set
    End Property
    Property CampaignID() As Integer
        Get
            Return ViewState("CampaignID")
        End Get
        Set(ByVal value As Integer)
            ViewState("CampaignID") = value
        End Set
    End Property

    Property AgentID() As String
        Get
            Return ViewState("AgentID")
        End Get
        Set(ByVal value As String)
            ViewState("AgentID") = value
        End Set
    End Property

    Property startday() As Integer
        Get
            Return ViewState("startday")
        End Get
        Set(ByVal value As Integer)
            ViewState("startday") = value
        End Set
    End Property

    Property endday() As Integer
        Get
            Return ViewState("endday")
        End Get
        Set(ByVal value As Integer)
            ViewState("endday") = value
        End Set
    End Property
    Property UserID() As String
        Get
            Return ViewState("UserID")
        End Get
        Set(ByVal value As String)
            ViewState("UserID") = value
        End Set
    End Property

    Property totalerror() As Integer
        Get
            Return ViewState("totalerror")
        End Get
        Set(ByVal value As Integer)
            ViewState("totalerror") = value
        End Set
    End Property

#End Region

#Region "--- Load ---"
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        HumanMessage.Style.Item("visibility") = "hidden"
        If Not IsPostBack Then
            If Session("AgentID") <> "" Then
                If Not Request.QueryString("Campaign") Is Nothing Then
                    Session("CampaignID") = Request.QueryString("Campaign")
                End If
                CampaignID = Session("CampaignID")
                AgentID = Session("AgentID")
                UserID = Session("AgentID")
                'PanelReports.Controls.Add(Common.GetMenu(Request.Url, AgentID))
                PanelReports.Controls.Add(Common.GetMenu(Request.Url, UserID, Request.ApplicationPath))
                UcDateTo.Visible = False
                ucDateFrom.Visible = False
                lblAnd.Visible = False
                'FillGrid()
                FillCommonFilters()
                FillProcessCampaigns()
                LoadData()
            Else
            End If
        Else
            CreateForm_Report()
            FillGrid()
        End If
    End Sub

    Private Sub FillCommonFilters()
        Dim db As New DBAccess
        Dim dt As DataTable = db.ReturnTable("select * from tbl_Reports_DatePeriods")
        db = Nothing
        Dim dr As DataRow = dt.NewRow
        dr(0) = 10
        dr(1) = "Between"
        dt.Rows.Add(dr)
        CboPeriod.DataTextField = "Caption"
        CboPeriod.DataValueField = "Period"
        CboPeriod.DataSource = dt
        CboPeriod.DataBind()
        db = New DBAccess
        dt = db.ReturnTable("Select * from tbl_Reports_GroupBy")
        db = Nothing

        Dim dr2() As DataRow
        dr2 = dt.Select("Caption='Hour'") 'To remove Hour option
        dt.Rows.Remove(dr2(0))
        CboGroup.DataTextField = "Caption"
        CboGroup.DataValueField = "ID"
        CboGroup.DataSource = dt
        CboGroup.DataBind()

    End Sub

    Private Sub FillProcessCampaigns()
        Common.FillProcesses(CboProcess, AgentID)
        Dim lstprocess As New ListItem
        lstprocess.Value = 0
        lstprocess.Text = "All"
        If CboProcess.Items.Contains(lstprocess) Then
            CboProcess.Items.Remove(lstprocess)
        End If
        Dim db As New DBAccess
        db.slDataAdd("Agentid", AgentID)
        CboProcess.SelectedValue = db.ReturnRow("usp_getAgentProcess", True)(4)
        db = Nothing
        Common.FillCampaigns(cboCampaigns, AgentID, CboProcess.SelectedValue)
    End Sub

    Private Sub getQE()
        'Dim db As New DBAccess("qualitynew")
        Dim db As New DBAccess
        db.slDataAdd("DateFrom", startday)
        db.slDataAdd("DateTo", endday)
        db.slDataAdd("camp", cboCampaigns.SelectedValue)
        db.slDataAdd("processID", CboProcess.SelectedValue)

        db.slDataAdd("Filter", "QE")
        Dim dt As DataTable = db.ReturnTable("usp_QualitySummaryGetFilter_All_New", , True)
        db = Nothing
        ddlQE.DataTextField = "QEName"
        ddlQE.DataValueField = "QEID"
        ddlQE.DataSource = dt
        ddlQE.DataBind()
        Dim item1 As New ListItem
        item1.Text = "All"
        item1.Value = "%"
        ddlQE.Items.Insert(0, item1)
        dt = Nothing
    End Sub

    Private Sub getCMFList()
        'Dim db As New DBAccess("qualitynew")
        Dim db As New DBAccess
        db.slDataAdd("DateFrom", startday)
        db.slDataAdd("DateTo", endday)
        db.slDataAdd("camp", cboCampaigns.SelectedValue)
        db.slDataAdd("Filter", "CMFList")
        db.slDataAdd("ProcessID", CboProcess.SelectedValue)
        Dim dt As DataTable = db.ReturnTable("usp_QualitySummaryGetFilter_All_New", , True)
        db = Nothing
        ddlcmf.DataTextField = "CmfName"
        ddlcmf.DataValueField = "cmfid"
        ddlcmf.DataSource = dt
        ddlcmf.DataBind()
        Dim item1 As New ListItem
        item1.Text = "All"
        item1.Value = 0
        ddlcmf.Items.Insert(0, item1)
        dt = Nothing
    End Sub

    Private Sub CreateForm_Report()
        'If Not IsPostBack Then
        Dim objTable As Table
        Dim objTablerow As TableRow
        Dim objTableCol As TableCell
        Dim objLabel As Label
        Dim objText As TextBox
        Dim objSelect As DropDownList

        Dim dtMandatoryQuest As New DataTable
        Dim db As DBAccess

        Dim iCtr As Integer
        pnlDynamicHeader.Controls.Remove(pnlDynamicHeader.FindControl("dynamic"))
        Try
            objTable = New Table
            objTable.ID = "dynamic"
            objTable.Width = System.Web.UI.WebControls.Unit.Percentage(70)
            objTable.CellSpacing = 0
            objTable.HorizontalAlign = HorizontalAlign.Left
            objTable.EnableViewState = True

            ' db = New DBAccess("CRM")
            db = New DBAccess
            db.slDataAdd("campaignid", cboCampaigns.SelectedValue)
            db.slDataAdd("CMFID", ddlcmf.SelectedValue)
            'db.slDataAdd("sheetid", 0)
            db.slDataAdd("ProcessID", CboProcess.SelectedValue)
            db.slDataAdd("DateFrom", startday)
            db.slDataAdd("DateTo", endday)

            dtMandatoryQuest = db.ReturnTable("usp_Quality_GetCMFfields_Report", , True)

            db = Nothing
            If Not dtMandatoryQuest Is Nothing Then
                For iCtr = 0 To dtMandatoryQuest.Rows.Count - 1
                    If iCtr Mod 2 = 0 Then
                        objTablerow = New TableRow
                        objTablerow.ID = "TblRow" & dtMandatoryQuest.Rows(iCtr).Item("FieldID") '& dtMandatoryQuest.Rows(iCtr).Item("CampaignID") '& dtMandatoryQuest.Rows(iCtr).Item("CMFID") '=== By Rajendra
                        'objTablerow.BackColor = Color.LightGray
                        objTable.Rows.Add(objTablerow)
                        objTablerow.EnableViewState = True
                    End If

                    objTableCol = New TableCell
                    objTablerow.Cells.Add(objTableCol)
                    objTableCol.EnableViewState = True
                    objTableCol.BackColor = System.Drawing.Color.Transparent
                    objTableCol.VerticalAlign = VerticalAlign.Middle
                    objTableCol.HorizontalAlign = HorizontalAlign.Left
                    objTableCol.Width = System.Web.UI.WebControls.Unit.Percentage(20)
                    ' objTableCol.ColumnSpan = 2
                    'objTableCol.Attributes.Add("style", "border-bottom: solid 1px #bbd9ee")
                    objLabel = New Label

                    objTableCol.Controls.Add(objLabel)
                    objLabel.Text = dtMandatoryQuest.Rows(iCtr).Item("FieldName")
                    objLabel.EnableViewState = True
                    objTableCol = New TableCell
                    objTablerow.Cells.Add(objTableCol)
                    objTableCol.BackColor = System.Drawing.Color.Transparent
                    objTableCol.VerticalAlign = VerticalAlign.Middle
                    objTableCol.HorizontalAlign = HorizontalAlign.Left
                    objTableCol.Width = System.Web.UI.WebControls.Unit.Percentage(25)
                    objTableCol.EnableViewState = True
                 
                    objSelect = New DropDownList
                    objSelect.Height = System.Web.UI.WebControls.Unit.Pixel(20)
                    'objSelect.Width = System.Web.UI.WebControls.Unit.Percentage(100)
                    objSelect.Font.Size = System.Web.UI.WebControls.FontUnit.Smaller
                    objSelect.ID = "Field" & dtMandatoryQuest.Rows(iCtr).Item("FieldID") '& dtMandatoryQuest.Rows(iCtr).Item("CampaignID") '& dtMandatoryQuest.Rows(iCtr).Item("CMFID")      '=== By Rajendra
                    ' LblError.Text = iCtr + "th ID " + objSelect.ID
                    objSelect.EnableViewState = True
                    objSelect.Visible = True
                    Dim ans As DataTable
                    ' ans = dtcombodata.Select("Questid=" & dtMandatoryQuest.Rows(iCtr).Item("questid")).CopyToDataTable

                    ' Dim db2 As New DBAccess("CRM")
                    Dim db2 As New DBAccess
                    db2.slDataAdd("CampaignID", cboCampaigns.SelectedValue)
                    db2.slDataAdd("CMFID", ddlcmf.SelectedValue)
                    db2.slDataAdd("FieldID", dtMandatoryQuest.Rows(iCtr).Item("FieldID"))
                    db2.slDataAdd("ProcessID", CboProcess.SelectedValue)
                    db2.slDataAdd("DateFrom", startday)
                    db2.slDataAdd("DateTo", endday)
                    ans = db2.ReturnTable("usp_Quality_GetCMFfieldsMap_Report", , True)
                    db2 = Nothing
                    objSelect.DataSource = ans
                    objSelect.DataTextField = "FieldValue"
                    objSelect.DataValueField = "FieldValue"
                    objSelect.DataBind()
                    'Rajkumar ,have inserted  the 'All' field in dynamic created controls
                    Dim item1 As New ListItem
                    item1.Text = "All"
                    item1.Value = "%"
                    objSelect.Items.Insert(0, item1)
                    AddHandler objSelect.SelectedIndexChanged, AddressOf DropDownSelectionChange
                    objSelect.AutoPostBack = True
                    objTableCol.Controls.Add(objSelect)

                Next
            End If

            pnlDynamicHeader.Controls.Add(objTable)
            pnlDynamicHeader.Enabled = True
            '***************TO Get the value of controls that are created dynamically.
        Catch ex As Exception
            LblError.Text = ex.Message
            LblError.Visible = True
        Finally
            dtMandatoryQuest = Nothing
        End Try
    End Sub

    Private Sub LoadData()
        ' FillCommonFilters()
        'FillProcessCampaigns()

        ' Dim db As New DBAccess("CRM")
        Dim db As New DBAccess
        Dim dbPro As DBAccess
        If CboPeriod.SelectedValue = 10 Then
            startday = ucDateFrom.yyyymmdd
            endday = UcDateTo.yyyymmdd
        Else
            db = New DBAccess
            db.slDataAdd("Period", CboPeriod.SelectedValue)

            If cboCampaigns.SelectedValue <> 0 Then
                db.slDataAdd("Campaignid", cboCampaigns.SelectedValue)
            Else
                ' dbPro = New DBAccess("CRM")
                dbPro = New DBAccess
                Dim retVal As Integer = dbPro.ReturnValue("SELECT CampaignID FROM tbl_Config_Campaigns WHERE ISPrimary=1 AND ProcessID='" & CboProcess.SelectedValue & "'", False)
                dbPro = Nothing
                db.slDataAdd("Campaignid", retVal)
            End If

            Dim dr As DataRow = db.ReturnRow("usp_GetStart_EndDateForAPeriod", True)
            db = Nothing
            startday = dr(0)
            endday = dr(1)
        End If

        getQE()
        getCMFList()
        CreateForm_Report()
        FillGrid()
    End Sub

#End Region

#Region "--- Events ---"
    Protected Sub cboCampaigns_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboCampaigns.SelectedIndexChanged
        CampaignID = cboCampaigns.SelectedValue
        LoadData()
    End Sub
    Protected Sub CboGroup_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles CboGroup.SelectedIndexChanged
        LoadData()
    End Sub
    Protected Sub CboPeriod_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles CboPeriod.SelectedIndexChanged
        If CboPeriod.SelectedValue = 10 Then
            ucDateFrom.Visible = True
            UcDateTo.Visible = True
            lblAnd.Visible = True
            LoadData()
        Else
            ucDateFrom.Visible = False
            UcDateTo.Visible = False
            lblAnd.Visible = False
            LoadData()
        End If

    End Sub
    Protected Sub CboProcess_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles CboProcess.SelectedIndexChanged
        ProcessID = CboProcess.SelectedValue
        Common.FillCampaigns(cboCampaigns, AgentID, CboProcess.SelectedValue)
        CampaignID = cboCampaigns.SelectedValue
        LoadData()
    End Sub
    'Protected Sub btnFilter_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnFilter.Click
    '    LoadData()
    'End Sub
    Protected Sub btnRefresh_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnRefresh.Click
        LoadData()
        'FillGrid()
    End Sub
    Protected Sub imgfav_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles imgfav.Click
        Common.AddToFav(AgentID, "New Quality Summary Report")
        SuccessMessage("Report has been added to your favourite list")
        FillGrid()
    End Sub
    Protected Sub imgExport_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles imgExport.Click
        'LoadData()
        FillGrid()
        GridViewExportUtil.Export(lblReportName.Text & "-" & LblError.Text & ".xls", Me.gvData)
    End Sub

    Protected Sub ddlcmf_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ddlcmf.SelectedIndexChanged
        CreateForm_Report()
        FillGrid()
    End Sub

    Protected Sub ddlQE_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ddlQE.SelectedIndexChanged
        CreateForm_Report()
        FillGrid()
    End Sub

    Protected Sub DropDownSelectionChange(ByVal sender As Object, ByVal e As System.EventArgs)
        FillGrid()
    End Sub

    Protected Sub gvData_RowCommand(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewCommandEventArgs) Handles gvData.RowCommand
        Dim param As String = ""
        Dim length As Int16 = 0
        If e.CommandName = "View" Then
            'to read the parametrs value

            OpenParameterPopup()
            'OpenPopUp("pnlParameters")

            Dim db As New DBAccess
            Dim dtData As DataTable
            ' db = New DBAccess("CRM")
            db = New DBAccess
            db.slDataAdd("DateFrom", startday)
            db.slDataAdd("DateTo", endday)
            db.slDataAdd("camp", cboCampaigns.SelectedValue)
            db.slDataAdd("GroupBy", CboGroup.SelectedValue)
            db.slDataAdd("inQAId", ddlQE.SelectedValue)
            db.slDataAdd("cmfid", ddlcmf.SelectedValue)
            '---------------------rajkumar start
            Dim row As GridViewRow = DirectCast((DirectCast(e.CommandSource, LinkButton).NamingContainer), GridViewRow)

            If CboGroup.SelectedValue = 0 Then  ''campaignid
                param = CType(row.FindControl("hiddenField"), HiddenField).Value

            ElseIf CboGroup.SelectedValue = 1 Then  'agent
                'length = row.Cells(1).Text.IndexOf(")") - row.Cells(1).Text.IndexOf("(")
                'param = row.Cells(1).Text.Substring(row.Cells(1).Text.IndexOf("("), length)
                param = CType(row.FindControl("hiddenField"), HiddenField).Value

            ElseIf CboGroup.SelectedValue = 2 Then ''team
                'length = row.Cells(1).Text.IndexOf(")") - row.Cells(1).Text.IndexOf("(")
                'param = row.Cells(1).Text.Substring(row.Cells(1).Text.IndexOf("("), length)
                param = CType(row.FindControl("hiddenField"), HiddenField).Value

            ElseIf CboGroup.SelectedValue = 3 Then 'day
                param = row.Cells(1).Text 'value is retrieved from gridview itself
            End If

            ' db.slDataAdd("groupByParameter", "NSS59002") 'for agent
            'db.slDataAdd("groupByParameter", 246) 'for campaign
            db.slDataAdd("groupByParameter", param) 'for campaign
            '---------------------rajkumar end 

            If pnlDynamicHeader.HasControls Then
                For i As Int16 = 1 To 10
                    If Not pnlDynamicHeader.FindControl("Field" & i) Is Nothing Then
                        If Not CType(pnlDynamicHeader.FindControl("Field" & i), DropDownList).SelectedItem Is Nothing Then
                            If CType(pnlDynamicHeader.FindControl("Field" & i), DropDownList).SelectedItem.Text.ToUpper = "ALL" Then
                                db.slDataAdd("UDF" & i, CType(pnlDynamicHeader.FindControl("Field" & i), DropDownList).SelectedItem.Value)
                            Else
                                db.slDataAdd("UDF" & i, CType(pnlDynamicHeader.FindControl("Field" & i), DropDownList).SelectedItem.Text)
                            End If
                        End If
                    End If
                Next i
            End If

            db.slDataAdd("ProcessID", CboProcess.SelectedValue)
            dtData = db.ReturnTable("usp_Quality_ParameterWiseCount", , True)
            db = Nothing
            pnlParameters.Visible = True
            '----------------------------------------------------------------------------------
            ' Dim totalerror As Integer = 0
            totalerror = 0
            For Each rowErr As DataRow In dtData.Rows
                totalerror += rowErr.Item("ErrorCount")
            Next

            Dim drow As DataRow = dtData.NewRow
            drow.Item(1) = "Total"
            drow.Item(2) = totalerror.ToString
            drow.Item(3) = ""

            dtData.Rows.Add(drow)
            '-------------------------------------------------------------------------------
            '---------------------------------------------------------------------
            gvParameters.DataSource = dtData
            gvParameters.DataBind()
            '---------------------------------------------------------------------
        End If
    End Sub

    Protected Sub gvParameters_RowDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles gvParameters.RowDataBound
        If e.Row.RowType = DataControlRowType.DataRow Then
            If e.Row.Cells(3).Text = "F" Then
                e.Row.Cells(0).ForeColor = Drawing.Color.Red
                e.Row.Cells(1).ForeColor = Drawing.Color.Red
                e.Row.Cells(2).ForeColor = Drawing.Color.Red
                e.Row.Cells(3).ForeColor = Drawing.Color.Red

                'e.Row.Cells(e.Row.Cells.Count - 1).Text = ""
            End If

            If e.Row.Cells(3).Text = "F" Or e.Row.Cells(3).Text = "N" Then
                'for Serial No.
                e.Row.Cells(0).Text = e.Row.RowIndex + 1

                If e.Row.Cells(2).Text <> 0 Then
                    Dim lblForText, lblForNum As New Label

                    'for graph
                    lblForText.BorderStyle = BorderStyle.None
                    If e.Row.Cells(2).ForeColor = Drawing.Color.Red Then
                        lblForText.BackColor = Drawing.Color.Red
                    Else
                        lblForText.BackColor = Drawing.Color.Gray
                    End If

                    lblForText.Width = Math.Round(e.Row.Cells(2).Text / totalerror, 2) * 100
                    lblForText.Height = 14
                    e.Row.Cells(4).Controls.Add(lblForText)

                    'for text of percentage
                    lblForNum.BorderStyle = BorderStyle.None
                    lblForNum.Enabled = False
                    lblForNum.Text = Math.Round(e.Row.Cells(2).Text / totalerror, 2) * 100 & "%"

                    e.Row.Cells(4).Controls.Add(lblForNum)
                Else
                    e.Row.Cells(4).Text = ""
                End If
            End If

        End If

        If e.Row.Cells.Count > 1 Then
            e.Row.Cells.RemoveAt(3)
        End If

    End Sub

    Protected Sub imgBtnCancelPanel_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles imgBtnCancelPanel.Click
        CloseParameterPopup()
    End Sub

    Protected Sub gvData_RowDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles gvData.RowDataBound
        If e.Row.Cells.Count > 1 Then
            'To remove the hidden field of "Selectcolumn" in gridview
            e.Row.Cells.RemoveAt(1)
        End If

    End Sub

#End Region

#Region "--- Support Functions ---"

    Private Sub FillGrid()
        Dim db As New DBAccess
        Dim dtData As DataTable
        ' db = New DBAccess("CRM")
        db = New DBAccess
        db.slDataAdd("DateFrom", startday)
        db.slDataAdd("DateTo", endday)
        db.slDataAdd("camp", cboCampaigns.SelectedValue)
        db.slDataAdd("GroupBy", CboGroup.SelectedValue)
        db.slDataAdd("inQAId", ddlQE.SelectedValue)
        db.slDataAdd("cmfid", ddlcmf.SelectedValue)
        If pnlDynamicHeader.HasControls Then
            For i As Int16 = 1 To 10
                If Not pnlDynamicHeader.FindControl("Field" & i) Is Nothing Then
                    If Not CType(pnlDynamicHeader.FindControl("Field" & i), DropDownList).SelectedItem Is Nothing Then
                        If CType(pnlDynamicHeader.FindControl("Field" & i), DropDownList).SelectedItem.Text.ToUpper = "ALL" Then
                            db.slDataAdd("UDF" & i, CType(pnlDynamicHeader.FindControl("Field" & i), DropDownList).SelectedItem.Value)
                        Else
                            db.slDataAdd("UDF" & i, CType(pnlDynamicHeader.FindControl("Field" & i), DropDownList).SelectedItem.Text)
                        End If
                    End If
                End If
            Next i
        End If
        db.slDataAdd("ProcessID", CboProcess.SelectedValue)
        'dtData = db.ReturnTable("usp_QualityReportQCScore_New", , True)
        dtData = db.ReturnTable("usp_QualityReportQCScore_New_Test", , True)
        db = Nothing
        Dim dtHeading As DataTable
        ' db = New DBAccess("CRM")
        db = New DBAccess
        db.slDataAdd("campaignid", cboCampaigns.SelectedValue)
        db.slDataAdd("ProcessID", CboProcess.SelectedValue)
        dtHeading = db.ReturnTable("usp_Quality_GetHeadingfields_report", , True)
        db = Nothing

        Dim dtHeading_Distinct As DataTable = Nothing

        Dim HeadingCount As Integer = 0
        If dtHeading.Rows.Count > 0 Then
            ' HeadingCount = dtHeading.Rows.Count
            dtHeading_Distinct = dtHeading.DefaultView.ToTable(True, "HeadingID")
            HeadingCount = dtHeading_Distinct.Rows.Count
        End If

        Dim HeadingName As String

        If dtHeading.Rows.Count > 0 Then
            If dtData.Rows.Count > 0 Then
                For m As Integer = 0 To HeadingCount - 1
                    ' HeadingName = "Heading" & m + 1 & "ErrorCount%"
                    'if the Heading ID is greater than 1 for given prcess
                    If dtHeading.Select("HeadingID=" & dtHeading_Distinct.Rows(m).Item("HeadingID").ToString).Length = 1 Then
                        HeadingName = "Heading" & dtHeading_Distinct.Rows(m).Item("HeadingID").ToString & "ErrorCount%" 'HeadingID is used for 
                        dtData.Columns(HeadingName).ColumnName = dtHeading.Select("HeadingID=" & dtHeading_Distinct.Rows(m).Item("HeadingID")).CopyToDataTable.Rows(0)("Caption").Replace(" ", "")
                    ElseIf dtHeading.Select("HeadingID=" & dtHeading_Distinct.Rows(m).Item("HeadingID").ToString).Length > 1 Then
                        HeadingName = "Heading" & (m + 1) & "ErrorCount%"
                        dtData.Columns(HeadingName).ColumnName = HeadingName
                    End If
                Next
                'For i As Integer = HeadingCount + 1 To 10 'AS 10 Columns are fixed
                '    HeadingName = "Heading" & i & "ErrorCount%"
                '    dtData.Columns.Remove(HeadingName)
                'Next
            End If
        End If

        For i As Integer = HeadingCount + 1 To 10 'AS 10 Columns are fixed
            HeadingName = "Heading" & i & "ErrorCount%"
            dtData.Columns.Remove(HeadingName)
        Next

        gvData.DataSource = dtData
        gvData.DataBind()
        '-----------------------------


        lblReportName.Text = CboGroup.SelectedItem.Text & " Wise Quality Summary "
        LblError.Text = "Between " & IntegerToDateString(startday) & "  and " & IntegerToDateString(endday) & " for " & cboCampaigns.SelectedItem.Text & " campaign"
    End Sub

    Private Function IntegerToDateString(ByVal d As Integer) As String
        Return d.ToString.Substring(0, 4) & "-" & d.ToString.Substring(4, 2) & "-" & d.ToString.Substring(6, 2)
    End Function

    Private Sub OpenParameterPopup()
        Dim str As String
        str = "$('#DialogBackground').height($(document).height());$('#DialogBackground').width($(window).width());$('#DialogBackground').css('visibility','visible');" & _
        " $('#pnlParameters').css('visibility','visible');$('#pnlParameters').css('left',($(window).width() - $('#pnlParameters').width())/2); "
        ScriptManager.RegisterStartupScript(Page, Page.GetType(), "Movedialog", str, True)
    End Sub


    Private Sub CloseParameterPopup()
        Dim str As String
        str = "$('#DialogBackground').css('visibility','hidden');$('#pnlParameters').css('visibility','hidden');"
        ScriptManager.RegisterStartupScript(Page, Page.GetType(), "Movedialog", str, True)
    End Sub

    'Private Sub ExportToexcel()
    '    Dim tw As New IO.StringWriter()
    '    Dim hw As New System.Web.UI.HtmlTextWriter(tw)
    '    Response.ContentType = "application/vnd.ms-excel"
    '    Response.AddHeader("content-disposition", "attachment;filename=" & lblReportName.Text & "-" & LblError.Text & ".xls")
    '    Response.Charset = ""
    '    EnableViewState = False
    '    gvData.RenderControl(hw)
    '    Response.Write(tw.ToString())
    '    Response.End()
    'End Sub

#End Region

#Region "--- Utility ---"
    Private Sub AlertMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMFail"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub
    Private Sub SuccessMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMSuccess"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub
#End Region


End Class
