﻿Imports System.Data
Imports com.nss.DBAccess
Imports System.Data.SqlClient
Partial Class Quality_SummaryReportTeamWise
    Inherits System.Web.UI.Page
    Private datefrom As String
    Private dateto As String
    Private campid As Integer
    Private QEID As String
    Private calltype As String
    Private errortype As String
    Private cmfid As String
#Region "Properties"
    Property CampaignID() As Integer
        Get
            Return ViewState("CampaignID")
        End Get
        Set(ByVal value As Integer)
            ViewState("CampaignID") = value
        End Set
    End Property

    Property AgentID() As String
        Get
            Return ViewState("AgentID")
        End Get
        Set(ByVal value As String)
            ViewState("AgentID") = value
        End Set
    End Property
#End Region
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        lblcampaign1.Text = Request.QueryString("SupervisorID")
        lblcampaign1.Text = Request.QueryString("SupervisorName")
        If Not IsPostBack Then
            CampaignID = Session("CampaignID")
            AgentID = Session("AgentID")
            PanelReports.Controls.Add(Common.GetMenu(Request.Url, AgentID, Request.ApplicationPath))
            PopulateCMF()
        Else
            Session("AgentID") = AgentID
        End If

    End Sub
    Protected Sub filldata() Handles SubSummaryReportFilters1.firedata
        Populatedata()
    End Sub
    'Protected Sub btnClose_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnClose.Click
    '    Response.Redirect("~/mainsummaryreport.aspx")
    'End Sub
    Private Sub PopulateCMF()
        datefrom = Request.QueryString("DateFrom")
        dateto = Request.QueryString("DateTo")
        campid = Request.QueryString("campid")
        QEID = Request.QueryString("QEID")
        calltype = Request.QueryString("calltype")
        errortype = Request.QueryString("errortype")
        cmfid = Request.QueryString("cmfid")
        Dim finaltable As New DataTable
        Try
            'lblcampaign1.NavigateUrl = "~/SummaryReportPerTeamWise.aspx?QEID=" & Request.QueryString("QEID") & "&cmfid=" & Request.QueryString("cmfid") & "&calltype=" & Request.QueryString("calltype") & "&errortype=" & Request.QueryString("errortype") & "&campid=" & Request.QueryString("campid") & "&SupervisorID=%&DateFrom=" & Request.QueryString("DateFrom") & "&DateTo=" & Request.QueryString("DateTo")
            Dim dt1 As DataTable

            ' Dim db1 As New DBAccess("qualitynew")
            Dim db1 As New DBAccess
            db1.slDataAdd("DateFrom", Request.QueryString("DateFrom"))
            db1.slDataAdd("DateTo", Request.QueryString("DateTo"))
            db1.slDataAdd("Supervisorid", Request.QueryString("Supervisorid"))
            db1.slDataAdd("camp", Request.QueryString("campid"))
            db1.slDataAdd("inQAId", Request.QueryString("QEID"))
            db1.slDataAdd("inCallType", Request.QueryString("calltype"))
            db1.slDataAdd("inErrorType", Request.QueryString("errortype"))
            db1.slDataAdd("cmfid", Request.QueryString("cmfid"))
            dt1 = db1.ReturnTable("usp_QualityReport3QCScore_new", , True)
            db1 = Nothing
            Dim dt As DataTable

            '  Dim db As New DBAccess("qualitynew")
            Dim db As New DBAccess
            db.slDataAdd("DateFrom", Request.QueryString("DateFrom"))
            db.slDataAdd("DateTo", Request.QueryString("DateTo"))
            db.slDataAdd("camp", Request.QueryString("campid"))
            db.slDataAdd("Supervisorid", Request.QueryString("Supervisorid"))
            db.slDataAdd("inQAId", Request.QueryString("QEID"))
            db.slDataAdd("inCallType", Request.QueryString("calltype"))
            db.slDataAdd("inErrorType", Request.QueryString("errortype"))
            db.slDataAdd("cmfid", Request.QueryString("cmfid"))
            dt = db.ReturnTable("usp_QualitySummaryReport3_new", , True)
            db = Nothing

            Dim dtnew As New DataTable
            dtnew.Columns.Add("Agentid")
            dtnew.Columns.Add("AgentName")
            'For Creating Columns
            Dim dtsubcat As DataTable = dt.DefaultView.ToTable(True, New String() {"maincat", "subcat"})
            For i As Integer = 0 To dtsubcat.Rows.Count - 1
                dtnew.Columns.Add(i)
            Next
            For Each col As DataColumn In dt1.Columns
                If col.ColumnName = "Agentid" Or col.ColumnName = "AgentName" Then
                Else
                    dtnew.Columns.Add(col.ColumnName)
                End If
            Next
            'For Creating Rows
            For i As Integer = 0 To dt1.Rows.Count + 1
                Dim dr As DataRow = dtnew.NewRow
                dtnew.Rows.Add(dr)
            Next
            'For Adding Categories and Sub Categories Headers
            For j As Integer = 0 To dtsubcat.Rows.Count - 1
                For i As Integer = 0 To dtsubcat.Rows.Count - 1
                    dtnew.Rows(0).Item(i + 2) = dtsubcat.Rows(i).Item(0)
                    dtnew.Rows(1).Item(i + 2) = dtsubcat.Rows(i).Item(1)
                Next
            Next
            'For Adding Header
            dtnew.Columns.Remove("ParameterWiseScore%")
            dtnew.Columns.Add("ParameterWiseScore%")
            dtnew.Columns.Remove("ClientCallsMonitored")
            dtnew.Columns.Add("ClientCallsMonitored")
            dtnew.Columns.Remove("ClientNonFatalErrorCount")
            dtnew.Columns.Add("ClientNonFatalErrorCount")
            dtnew.Columns.Remove("ClientFatalErrorCount")
            dtnew.Columns.Add("ClientFatalErrorCount")
            dtnew.Columns.Remove("ClientNFAR%")
            dtnew.Columns.Add("ClientNFAR%")
            dtnew.Columns.Remove("ClientFAR%")
            dtnew.Columns.Add("ClientFAR%")
            dtnew.Columns.Remove("ClientParameterWiseScore%")
            dtnew.Columns.Add("ClientParameterWiseScore%")
            dtnew.Rows(0).Item("Agentid") = "Agent ID"
            dtnew.Rows(0).Item("AgentName") = "Agent Name"
            'dtnew.Rows(0).Item("callsmonitored") = "Calls Monitored"
            dtnew.Rows(0).Item("callsmonitored") = "Monitored"
            dtnew.Rows(0).Item("NonFatalErrorCount") = "Non Fatal Error Count"
            dtnew.Rows(0).Item("FatalErrorCount") = "Fatal Sheet Count"
            dtnew.Rows(0).Item("NonFatalQCount") = "NonFatalQCount"
            dtnew.Rows(0).Item("NFAR%") = "NFAR%"
            dtnew.Rows(0).Item("FAR%") = "FAR%"
            dtnew.Rows(0).Item("TotalParamWiseScore") = "TotalParamWiseScore"
            dtnew.Rows(0).Item("CollectedParamWiseScore") = "CollectedParamWiseScore"
            dtnew.Rows(0).Item("ParameterWiseScore%") = "OverAll Score%"
            'For Client
            dtnew.Rows(0).Item("ClientCallsMonitored") = "Client Monitored"
            dtnew.Rows(0).Item("ClientNonFatalErrorCount") = "Client Non Fatal Error Count"
            dtnew.Rows(0).Item("ClientFatalErrorCount") = "Client Fatal Sheet Count"
            dtnew.Rows(0).Item("ClientNonFatalQCount") = "ClientNonFatalQCount"
            dtnew.Rows(0).Item("ClientNFAR%") = "Client NFAR%"
            dtnew.Rows(0).Item("ClientFAR%") = "Client FAR%"
            dtnew.Rows(0).Item("ClientTotalParamWiseScore") = "Client TotalParamWiseScore"
            dtnew.Rows(0).Item("ClientCollectedParamWiseScore") = "Client CollectedParamWiseScore"
            dtnew.Rows(0).Item("ClientParameterWiseScore%") = "Client OverAll Score%"
            'For Adding Data for under Categories and Sub Categories and other Headers
            For row As Integer = 0 To dt1.Rows.Count - 1
                Dim data() As DataRow = dt.Select("Agentid='" & dt1.Rows(row)("Agentid") & "'")
                For i As Integer = 0 To data.Length - 1
                    'If data(i).Item("maincat") = dtnew.Rows(0).Item(i + 2) And data(i).Item("subcat") = dtnew.Rows(1).Item(i + 2) Then
                    '    dtnew.Rows(row + 2).Item(i + 2) = data(i).Item("TotalErrorCount")
                    'End If
                    For c As Integer = 2 To dtnew.Columns.Count - 1
                        If Not IsDBNull(dtnew.Rows(0).Item(c)) And Not IsDBNull(dtnew.Rows(1).Item(c)) Then
                            If data(i).Item("maincat") = dtnew.Rows(0).Item(c) And data(i).Item("subcat") = dtnew.Rows(1).Item(c) Then
                                dtnew.Rows(row + 2).Item(c) = data(i).Item("TotalErrorCount")
                            End If
                        End If
                    Next
                Next

                dtnew.Rows(row + 2).Item("Agentid") = dt1.Rows(row).Item("Agentid")
                dtnew.Rows(row + 2).Item("AgentName") = dt1.Rows(row).Item("AgentName")
                dtnew.Rows(row + 2).Item("callsmonitored") = dt1.Rows(row).Item("callsmonitored")
                dtnew.Rows(row + 2).Item("NonFatalErrorCount") = dt1.Rows(row).Item("NonFatalErrorCount")
                dtnew.Rows(row + 2).Item("FatalErrorCount") = dt1.Rows(row).Item("FatalErrorCount")
                dtnew.Rows(row + 2).Item("NonFatalQCount") = dt1.Rows(row).Item("NonFatalQCount")
                dtnew.Rows(row + 2).Item("NFAR%") = dt1.Rows(row).Item("NFAR%")
                dtnew.Rows(row + 2).Item("FAR%") = dt1.Rows(row).Item("FAR%")
                dtnew.Rows(row + 2).Item("TotalParamWiseScore") = dt1.Rows(row).Item("TotalParamWiseScore")
                dtnew.Rows(row + 2).Item("CollectedParamWiseScore") = dt1.Rows(row).Item("CollectedParamWiseScore")
                dtnew.Rows(row + 2).Item("ParameterWiseScore%") = dt1.Rows(row).Item("ParameterWiseScore%")
                'For Client
                dtnew.Rows(row + 2).Item("ClientCallsMonitored") = dt1.Rows(row).Item("ClientCallsMonitored")
                dtnew.Rows(row + 2).Item("ClientNonFatalErrorCount") = dt1.Rows(row).Item("ClientNonFatalErrorCount")
                dtnew.Rows(row + 2).Item("ClientFatalErrorCount") = dt1.Rows(row).Item("ClientFatalErrorCount")
                dtnew.Rows(row + 2).Item("ClientNonFatalQCount") = dt1.Rows(row).Item("ClientNonFatalQCount")
                dtnew.Rows(row + 2).Item("ClientNFAR%") = dt1.Rows(row).Item("ClientNFAR%")
                dtnew.Rows(row + 2).Item("ClientFAR%") = dt1.Rows(row).Item("ClientFAR%")
                dtnew.Rows(row + 2).Item("ClientTotalParamWiseScore") = dt1.Rows(row).Item("ClientTotalParamWiseScore")
                dtnew.Rows(row + 2).Item("ClientCollectedParamWiseScore") = dt1.Rows(row).Item("ClientCollectedParamWiseScore")
                dtnew.Rows(row + 2).Item("ClientParameterWiseScore%") = dt1.Rows(row).Item("ClientParameterWiseScore%")
            Next
            campaigndata.DataSource = dtnew
            campaigndata.DataBind()
            db1 = Nothing
            callmontored = 0
            nonfatalerror = 0
            fatalerror = 0
            nonfatalqcount = 0
            TotalParamWiseScore = 0
            CollectedParamWiseScore = 0
            Clientcallmontored = 0
            Clientnonfatalerror = 0
            Clientfatalerror = 0
            Clientnonfatalqcount = 0
            ClientTotalParamWiseScore = 0
            ClientCollectedParamWiseScore = 0
        Catch ex As Exception
            lblerror.Text = ex.ToString
            lblerror.Visible = True
        End Try
    End Sub

    Private Sub Populatedata()
        datefrom = SubSummaryReportFilters1.DateFrom
        dateto = SubSummaryReportFilters1.DateTO
        campid = Request.QueryString("campid")
        QEID = SubSummaryReportFilters1.Qe
        calltype = SubSummaryReportFilters1.calltype
        errortype = SubSummaryReportFilters1.Errortype
        cmfid = SubSummaryReportFilters1.cmfid
        Dim finaltable As New DataTable
        Try
            'lblcampaign1.NavigateUrl = "~/SummaryReportPerTeamWise.aspx?QEID=" & Request.QueryString("QEID") & "&cmfid=" & Request.QueryString("cmfid") & "&calltype=" & Request.QueryString("calltype") & "&errortype=" & Request.QueryString("errortype") & "&campid=" & Request.QueryString("campid") & "&SupervisorID=%&DateFrom=" & Request.QueryString("DateFrom") & "&DateTo=" & Request.QueryString("DateTo")
            Dim dt1 As DataTable

            '  Dim db1 As New DBAccess("qualitynew")
            Dim db1 As New DBAccess
            db1.slDataAdd("DateFrom", SubSummaryReportFilters1.DateFrom)
            db1.slDataAdd("DateTo", SubSummaryReportFilters1.DateTO)
            db1.slDataAdd("Supervisorid", Request.QueryString("Supervisorid"))
            db1.slDataAdd("camp", Request.QueryString("campid"))
            db1.slDataAdd("inQAId", SubSummaryReportFilters1.Qe)
            db1.slDataAdd("inCallType", SubSummaryReportFilters1.calltype)
            db1.slDataAdd("inErrorType", SubSummaryReportFilters1.Errortype)
            db1.slDataAdd("cmfid", SubSummaryReportFilters1.cmfid)
            dt1 = db1.ReturnTable("usp_QualityReport3QCScore_new", , True)
            db1 = Nothing
            Dim dt As DataTable

            '   Dim db As New DBAccess("qualitynew")
            Dim db As New DBAccess
            db.slDataAdd("DateFrom", SubSummaryReportFilters1.DateFrom)
            db.slDataAdd("DateTo", SubSummaryReportFilters1.DateTO)
            db.slDataAdd("camp", Request.QueryString("campid"))
            db.slDataAdd("Supervisorid", Request.QueryString("Supervisorid"))
            db.slDataAdd("inQAId", SubSummaryReportFilters1.Qe)
            db.slDataAdd("inCallType", SubSummaryReportFilters1.calltype)
            db.slDataAdd("inErrorType", SubSummaryReportFilters1.Errortype)
            db.slDataAdd("cmfid", SubSummaryReportFilters1.cmfid)
            dt = db.ReturnTable("usp_QualitySummaryReport3_new", , True)
            db = Nothing

            Dim dtnew As New DataTable
            'dtnew.Columns.Add("TLid")
            dtnew.Columns.Add("Agentid")
            dtnew.Columns.Add("AgentName")
            'For Creating Columns
            Dim dtsubcat As DataTable = dt.DefaultView.ToTable(True, New String() {"maincat", "subcat"})
            For i As Integer = 0 To dtsubcat.Rows.Count - 1
                dtnew.Columns.Add(i)
            Next
            For Each col As DataColumn In dt1.Columns
                If col.ColumnName = "Agentid" Or col.ColumnName = "AgentName" Then
                Else
                    dtnew.Columns.Add(col.ColumnName)
                End If
            Next
            'For Creating Rows
            For i As Integer = 0 To dt1.Rows.Count + 1
                Dim dr As DataRow = dtnew.NewRow
                dtnew.Rows.Add(dr)
            Next
            'For Adding Categories and Sub Categories Headers
            For j As Integer = 0 To dtsubcat.Rows.Count - 1
                For i As Integer = 0 To dtsubcat.Rows.Count - 1
                    dtnew.Rows(0).Item(i + 2) = dtsubcat.Rows(i).Item(0)
                    dtnew.Rows(1).Item(i + 2) = dtsubcat.Rows(i).Item(1)
                Next
            Next
            'For Adding Header
            dtnew.Columns.Remove("ParameterWiseScore%")
            dtnew.Columns.Add("ParameterWiseScore%")
            dtnew.Columns.Remove("ClientCallsMonitored")
            dtnew.Columns.Add("ClientCallsMonitored")
            dtnew.Columns.Remove("ClientNonFatalErrorCount")
            dtnew.Columns.Add("ClientNonFatalErrorCount")
            dtnew.Columns.Remove("ClientFatalErrorCount")
            dtnew.Columns.Add("ClientFatalErrorCount")
            dtnew.Columns.Remove("ClientNFAR%")
            dtnew.Columns.Add("ClientNFAR%")
            dtnew.Columns.Remove("ClientFAR%")
            dtnew.Columns.Add("ClientFAR%")
            dtnew.Columns.Remove("ClientParameterWiseScore%")
            dtnew.Columns.Add("ClientParameterWiseScore%")
            dtnew.Rows(0).Item("Agentid") = "Agent ID"
            dtnew.Rows(0).Item("AgentName") = "Agent Name"
            'dtnew.Rows(0).Item("callsmonitored") = "Calls Monitored"
            dtnew.Rows(0).Item("callsmonitored") = "Monitored"
            dtnew.Rows(0).Item("NonFatalErrorCount") = "Non Fatal Error Count"
            dtnew.Rows(0).Item("FatalErrorCount") = "Fatal Error Count"
            dtnew.Rows(0).Item("NonFatalQCount") = "NonFatalQCount"
            dtnew.Rows(0).Item("NFAR%") = "NFAR%"
            dtnew.Rows(0).Item("FAR%") = "FAR%"
            dtnew.Rows(0).Item("TotalParamWiseScore") = "TotalParamWiseScore"
            dtnew.Rows(0).Item("CollectedParamWiseScore") = "CollectedParamWiseScore"
            dtnew.Rows(0).Item("ParameterWiseScore%") = "OverAll Score%"
            'For Client
            dtnew.Rows(0).Item("ClientCallsMonitored") = "Client Monitored"
            dtnew.Rows(0).Item("ClientNonFatalErrorCount") = "Client Non Fatal Error Count"
            dtnew.Rows(0).Item("ClientFatalErrorCount") = "Client Fatal Sheet Count"
            dtnew.Rows(0).Item("ClientNonFatalQCount") = "ClientNonFatalQCount"
            dtnew.Rows(0).Item("ClientNFAR%") = "Client NFAR%"
            dtnew.Rows(0).Item("ClientFAR%") = "Client FAR%"
            dtnew.Rows(0).Item("ClientTotalParamWiseScore") = "Client TotalParamWiseScore"
            dtnew.Rows(0).Item("ClientCollectedParamWiseScore") = "Client CollectedParamWiseScore"
            dtnew.Rows(0).Item("ClientParameterWiseScore%") = "Client OverAll Score%"
            'For Adding Data for under Categories and Sub Categories and other Headers
            For row As Integer = 0 To dt1.Rows.Count - 1
                Dim data() As DataRow = dt.Select("Agentid='" & dt1.Rows(row)("Agentid") & "'")
                For i As Integer = 0 To data.Length - 1
                    'If data(i).Item("maincat") = dtnew.Rows(0).Item(i + 2) And data(i).Item("subcat") = dtnew.Rows(1).Item(i + 2) Then
                    '    dtnew.Rows(row + 2).Item(i + 2) = data(i).Item("TotalErrorCount")
                    'End If
                    For c As Integer = 2 To dtnew.Columns.Count - 1
                        If Not IsDBNull(dtnew.Rows(0).Item(c)) And Not IsDBNull(dtnew.Rows(1).Item(c)) Then
                            If data(i).Item("maincat") = dtnew.Rows(0).Item(c) And data(i).Item("subcat") = dtnew.Rows(1).Item(c) Then
                                dtnew.Rows(row + 2).Item(c) = data(i).Item("TotalErrorCount")
                            End If
                        End If
                    Next
                Next

                dtnew.Rows(row + 2).Item("Agentid") = dt1.Rows(row).Item("Agentid")
                dtnew.Rows(row + 2).Item("AgentName") = dt1.Rows(row).Item("AgentName")
                dtnew.Rows(row + 2).Item("callsmonitored") = dt1.Rows(row).Item("callsmonitored")
                dtnew.Rows(row + 2).Item("NonFatalErrorCount") = dt1.Rows(row).Item("NonFatalErrorCount")
                dtnew.Rows(row + 2).Item("FatalErrorCount") = dt1.Rows(row).Item("FatalErrorCount")
                dtnew.Rows(row + 2).Item("NonFatalQCount") = dt1.Rows(row).Item("NonFatalQCount")
                dtnew.Rows(row + 2).Item("NFAR%") = dt1.Rows(row).Item("NFAR%")
                dtnew.Rows(row + 2).Item("FAR%") = dt1.Rows(row).Item("FAR%")
                dtnew.Rows(row + 2).Item("TotalParamWiseScore") = dt1.Rows(row).Item("TotalParamWiseScore")
                dtnew.Rows(row + 2).Item("CollectedParamWiseScore") = dt1.Rows(row).Item("CollectedParamWiseScore")
                dtnew.Rows(row + 2).Item("ParameterWiseScore%") = dt1.Rows(row).Item("ParameterWiseScore%")
                'For Client
                dtnew.Rows(row + 2).Item("ClientCallsMonitored") = dt1.Rows(row).Item("ClientCallsMonitored")
                dtnew.Rows(row + 2).Item("ClientNonFatalErrorCount") = dt1.Rows(row).Item("ClientNonFatalErrorCount")
                dtnew.Rows(row + 2).Item("ClientFatalErrorCount") = dt1.Rows(row).Item("ClientFatalErrorCount")
                dtnew.Rows(row + 2).Item("ClientNonFatalQCount") = dt1.Rows(row).Item("ClientNonFatalQCount")
                dtnew.Rows(row + 2).Item("ClientNFAR%") = dt1.Rows(row).Item("ClientNFAR%")
                dtnew.Rows(row + 2).Item("ClientFAR%") = dt1.Rows(row).Item("ClientFAR%")
                dtnew.Rows(row + 2).Item("ClientTotalParamWiseScore") = dt1.Rows(row).Item("ClientTotalParamWiseScore")
                dtnew.Rows(row + 2).Item("ClientCollectedParamWiseScore") = dt1.Rows(row).Item("ClientCollectedParamWiseScore")
                dtnew.Rows(row + 2).Item("ClientParameterWiseScore%") = dt1.Rows(row).Item("ClientParameterWiseScore%")

            Next
            campaigndata.DataSource = dtnew
            campaigndata.DataBind()
            db1 = Nothing
            callmontored = 0
            nonfatalerror = 0
            fatalerror = 0
            nonfatalqcount = 0
            TotalParamWiseScore = 0
            CollectedParamWiseScore = 0
            Clientcallmontored = 0
            Clientnonfatalerror = 0
            Clientfatalerror = 0
            Clientnonfatalqcount = 0
            ClientTotalParamWiseScore = 0
            ClientCollectedParamWiseScore = 0
        Catch ex As Exception
            lblerror.Text = ex.ToString
            lblerror.Visible = True
        End Try
    End Sub
    Dim callmontored, nonfatalerror, fatalerror, nonfatalqcount, TotalParamWiseScore, CollectedParamWiseScore, Clientcallmontored, Clientnonfatalerror, Clientfatalerror, Clientnonfatalqcount, ClientTotalParamWiseScore, ClientCollectedParamWiseScore As Integer
    Protected Sub dgdata_RowDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles campaigndata.RowDataBound
        Try
            Dim dgdata As GridView = sender
            Dim cell As TableCell
            If e.Row.RowType = DataControlRowType.DataRow Then
                If e.Row.RowIndex = 0 Then
                    Dim previouscelltext As String = "", currentcelltext As String = ""
                    Dim startcolumn As Integer = -1, ctr As Integer = 0, ctrcolspan As Integer = 1
                    For Each cell In e.Row.Cells
                        If previouscelltext = cell.Text Then
                            If startcolumn = -1 Then
                                startcolumn = ctr - 1
                            End If
                            ctrcolspan += 1
                            cell.Visible = False
                        Else
                            If startcolumn <> -1 Then
                                e.Row.Cells(startcolumn).ColumnSpan = ctrcolspan
                            End If
                            startcolumn = -1
                            ctrcolspan = 1
                        End If
                        ctr += 1
                        previouscelltext = cell.Text
                    Next
                    If startcolumn <> -1 Then
                        e.Row.Cells(startcolumn).ColumnSpan = ctrcolspan
                    End If
                    e.Row.Cells(0).Text = "SL No."
                ElseIf e.Row.RowIndex >= 2 Then
                    e.Row.Font.Bold = False
                    Clientnonfatalqcount += e.Row.Cells(e.Row.Cells.Count - 18).Text
                    ClientTotalParamWiseScore += e.Row.Cells(e.Row.Cells.Count - 17).Text
                    ClientCollectedParamWiseScore += e.Row.Cells(e.Row.Cells.Count - 16).Text
                    TotalParamWiseScore += e.Row.Cells(e.Row.Cells.Count - 15).Text
                    CollectedParamWiseScore += e.Row.Cells(e.Row.Cells.Count - 14).Text
                    callmontored += e.Row.Cells(e.Row.Cells.Count - 13).Text
                    nonfatalerror += e.Row.Cells(e.Row.Cells.Count - 12).Text
                    fatalerror += e.Row.Cells(e.Row.Cells.Count - 11).Text
                    nonfatalqcount += e.Row.Cells(e.Row.Cells.Count - 10).Text
                    Clientcallmontored += e.Row.Cells(e.Row.Cells.Count - 6).Text
                    Clientnonfatalerror += e.Row.Cells(e.Row.Cells.Count - 5).Text
                    Clientfatalerror += e.Row.Cells(e.Row.Cells.Count - 4).Text
                    Dim hy As New HyperLink
                    hy.Text = e.Row.Cells(1).Text
                    hy.NavigateUrl = "~/Quality/SummaryReportPerAgentWise.aspx?QEID=" & QEID & "&cmfid=" & cmfid & "&calltype=" & calltype & "&errortype=" & errortype & "&campid=" & Request.QueryString("campid") & "&SupervisorID=" & Request.QueryString("SupervisorID") & "&Agentid=" & e.Row.Cells(0).Text & "&DateFrom=" & datefrom & "&DateTo=" & dateto & "&AgentName=" & e.Row.Cells(1).Text
                    e.Row.Cells(1).Controls.Add(hy)
                    e.Row.Cells(0).Text = e.Row.RowIndex - 1
                End If
            ElseIf e.Row.RowType = DataControlRowType.Footer Then
                e.Row.Font.Bold = True
                e.Row.VerticalAlign = VerticalAlign.Middle
                e.Row.HorizontalAlign = HorizontalAlign.Center
                e.Row.Cells(1).Text = "Total"
                e.Row.Cells(e.Row.Cells.Count - 18).Text = Clientnonfatalqcount
                e.Row.Cells(e.Row.Cells.Count - 17).Text = ClientTotalParamWiseScore
                e.Row.Cells(e.Row.Cells.Count - 16).Text = ClientCollectedParamWiseScore
                e.Row.Cells(e.Row.Cells.Count - 15).Text = TotalParamWiseScore
                e.Row.Cells(e.Row.Cells.Count - 14).Text = CollectedParamWiseScore
                e.Row.Cells(e.Row.Cells.Count - 13).Text = callmontored
                e.Row.Cells(e.Row.Cells.Count - 12).Text = nonfatalerror
                e.Row.Cells(e.Row.Cells.Count - 11).Text = fatalerror
                e.Row.Cells(e.Row.Cells.Count - 10).Text = nonfatalqcount
                e.Row.Cells(e.Row.Cells.Count - 9).Text = 100 - Math.Round(((nonfatalerror) * 100 / nonfatalqcount), 2)
                e.Row.Cells(e.Row.Cells.Count - 8).Text = 100 - Math.Round(((fatalerror * 100) / callmontored), 2)
                e.Row.Cells(e.Row.Cells.Count - 7).Text = Math.Round(((CollectedParamWiseScore / TotalParamWiseScore) * 100), 2)
                e.Row.Cells(e.Row.Cells.Count - 6).Text = Clientcallmontored
                e.Row.Cells(e.Row.Cells.Count - 5).Text = Clientnonfatalerror
                e.Row.Cells(e.Row.Cells.Count - 4).Text = Clientfatalerror
                e.Row.Cells(e.Row.Cells.Count - 3).Text = 100 - Math.Round(((Clientnonfatalerror) * 100 / Clientnonfatalqcount), 2)
                e.Row.Cells(e.Row.Cells.Count - 2).Text = 100 - Math.Round(((Clientfatalerror * 100) / Clientcallmontored), 2)
                e.Row.Cells(e.Row.Cells.Count - 1).Text = Math.Round(((ClientCollectedParamWiseScore / ClientTotalParamWiseScore) * 100), 2)
            End If
            e.Row.Cells(e.Row.Cells.Count - 18).Visible = False
            e.Row.Cells(e.Row.Cells.Count - 17).Visible = False
            e.Row.Cells(e.Row.Cells.Count - 16).Visible = False
            e.Row.Cells(e.Row.Cells.Count - 15).Visible = False
            e.Row.Cells(e.Row.Cells.Count - 14).Visible = False
            e.Row.Cells(e.Row.Cells.Count - 10).Visible = False
            e.Row.Cells(e.Row.Cells.Count - 11).ForeColor = Drawing.Color.Red
            e.Row.Cells(e.Row.Cells.Count - 8).ForeColor = Drawing.Color.Red
            e.Row.Cells(e.Row.Cells.Count - 2).ForeColor = Drawing.Color.Red
            e.Row.Cells(e.Row.Cells.Count - 4).ForeColor = Drawing.Color.Red
        Catch ex As Exception
            lblerror.Text = ex.ToString
            lblerror.Visible = True
        End Try
    End Sub
End Class
