﻿Imports System.Data
Imports System.Data.SqlClient
Imports System.Web.Services.Description
Imports LibFolder.TermsNxt2
Partial Public Class _TrackerLogin
    Inherits System.Web.UI.Page

    'Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

    'End Sub

    Dim connCRM As String = Common.connCRM
    Dim connLeads As String = Common.connLeads
    Dim connreport As String = Common.connreport

    Dim conn As SqlConnection
    Dim cmd As SqlCommand
    Dim adp As SqlDataAdapter

#Region "Properties"
    'Shared LoginHelper1 As New LoginHelper

    Public Property CampaignID() As Integer
        Get
            Return ViewState("CampaignID")
        End Get
        Set(ByVal value As Integer)
            ViewState("CampaignID") = value
        End Set
    End Property
    Public Property AgentId() As String
        Get
            Return ViewState("AgentId")
        End Get
        Set(ByVal value As String)
            ViewState("AgentId") = value
        End Set
    End Property
    Public Property AgentName() As String
        Get
            Return ViewState("AgentName")
        End Get
        Set(ByVal value As String)
            ViewState("AgentName") = value
        End Set
    End Property
    Public Property IsVerifier() As Boolean
        Get
            Return ViewState("IsVerifier")
        End Get
        Set(ByVal value As Boolean)
            ViewState("IsVerifier") = value
        End Set
    End Property
    Private m_breaktype As Integer
    Public Property breaktype() As Integer
        Get
            Return m_breaktype
        End Get
        Set(ByVal value As Integer)
            m_breaktype = value
        End Set
    End Property
#End Region
    Protected Sub page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        'If Not IsPostBack Then

        '    If Session("AgentID") <> "" Then
        '        CampaignID = Session("CampaignID")
        '        AgentId = Session("AgentID")
        '        IsVerifier = Session("IsVerifier")
        '        GetCampaign()
        '    End If
        'End If





        '@Old code
        If Not IsPostBack Then
            AgentId = Session("AgentID")
            AgentName = Session("username")
            IsVerifier = Session("IsVerifier")
            GetCampaign()
        End If
        'Header1.AgentID = AgentId
        'Header1.Agentname = AgentName




        '@Restrict LH Amadeus User
        'Dim strAmadeus As String = ""
        'Dim bln As Boolean
        'strAmadeus = System.Configuration.ConfigurationManager.AppSettings("Amadeuslst")
        'bln = strAmadeus.Contains(AgentId)
        ' If bln = True Then
        'Response.Clear()
        'Response.Write("<table><tr><td><font color=""red"">Amadeus Users are Not authorized to Logged-In.</font></td></tr></table>")
        'Response.End()

        'End If



        '@Captcha Image
        'If (txtimgcode.Text <> Session("CaptchaImageText").ToString()) Then

        'End If



    End Sub
    Private Sub GetCampaign()
        If Not AgentId Is Nothing Then
            FillCampaigns()
        Else
            Response.Clear()
            Response.Write("<table><tr><td><font color=""red"">Either you are Not authorized to Logged-In or your session has been expired.</font></td></tr></table>")
            Response.End()
        End If
    End Sub
    Private Sub FillCampaigns()
        Dim dt As New DataTable
        ' Dim db As New DBAccess("CRM")

        'db.slDataAdd("Agentid", AgentId)
        'dt = db.ReturnTable("usp_MyCampaigns", , True)

        '--------------
        conn = New SqlConnection(connCRM)
        cmd = New SqlCommand()
        cmd.Parameters.AddWithValue("Agentid", AgentId)
        cmd.Connection = conn
        cmd.CommandType = CommandType.StoredProcedure
        cmd.CommandText = "usp_MyCampaigns"
        adp = New SqlDataAdapter(cmd)
        adp.Fill(dt)
        cmd = Nothing
        adp = Nothing
        '--------------
        lstCampaign.DataTextField = "Name"
        lstCampaign.DataValueField = "Campaignid"
        lstCampaign.DataSource = dt
        lstCampaign.DataBind()
        '  db = Nothing

        dt = Nothing
    End Sub
    Protected Sub imgLogin_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles imgLogin.Click
        If lstCampaign.GetSelectedIndices.Length > 0 Then
            CampaignID = lstCampaign.SelectedValue
            UpdateAgentLog()

            ' Dim strAmadeus As String = ""
            'strAmadeus = System.Configuration.ConfigurationManager.AppSettings("Amadeuslst")
            'Dim bln As Boolean = strAmadeus.Contains(AgentId)
            'LH Process 341
            If CampaignID = 341 Then
                If hdpopup.Value = "false" Then
                    ' If bln = False Then
                    Response.Redirect("~/Tracker/_NewTrackerLH.aspx?CampaignID=" & CampaignID & "&AgentId=" & AgentId & "&AgentName=" & AgentName & "&IsVerifier=" & IsVerifier)
                    'Else
                    '   Response.Redirect("~/Staffing/unauthorized.htm")
                    ' End If

                Else
                    Dim str As String
                    If Request.Browser.Type.Contains("IE") Then
                        str = "window.moveTo(0,0); window.open('_NewTrackerLH.aspx?CampaignID=" & CampaignID & "&AgentId=" & AgentId & "&AgentName=" & AgentName & "&IsVerifier=" & IsVerifier & "', '', 'menubar=no,toolbar=no,scrollbars=1,status=yes,resizable=yes, width=' + screen.width + ', height= ' + screen.height + ' top=0, left=0,right=0, bottom=-10','true');"
                    Else
                        str = "window.moveTo(0,0); window.open('_NewTrackerLH.aspx?CampaignID=" & CampaignID & "&AgentId=" & AgentId & "&AgentName=" & AgentName & "&IsVerifier=" & IsVerifier & "', '', 'menubar=no,toolbar=no,scrollbars=1,status=yes, width=' + screen.width + ', height= ' + screen.height + ' top=0, left=0,right=0, bottom=-10','true');"
                    End If

                    ScriptManager.RegisterStartupScript(Page, Page.GetType(), "OpenWindow", str, True)

                    Dim str1 As String
                    If Request.Browser.Type.Contains("IE") Then
                        str1 = "window.open('', '_self','');window.close(); "
                    Else
                        str1 = "window.open('', '_self','');window.close(); "
                    End If
                    ScriptManager.RegisterStartupScript(Page, Page.GetType(), "CloseWindow", str1, True)
                End If
                'LH Version 1.0.0
            ElseIf CampaignID = 388 Then
                If hdpopup.Value = "false" Then
                    'If bln = False Then
                    Response.Redirect("~/Tracker/_NewTrackerLH100.aspx?CampaignID=" & CampaignID & "&AgentId=" & AgentId & "&AgentName=" & AgentName & "&IsVerifier=" & IsVerifier)
                    'Else
                    '   Response.Redirect("~/Staffing/unauthorized.htm")
                    'End If

                Else
                    Dim str As String
                    If Request.Browser.Type.Contains("IE") Then
                        str = "window.moveTo(0,0); window.open('_NewTrackerLH100.aspx?CampaignID=" & CampaignID & "&AgentId=" & AgentId & "&AgentName=" & AgentName & "&IsVerifier=" & IsVerifier & "', '', 'menubar=no,toolbar=no,scrollbars=1,status=yes,resizable=yes, width=' + screen.width + ', height= ' + screen.height + ' top=0, left=0,right=0, bottom=-10','true');"
                    Else
                        str = "window.moveTo(0,0); window.open('_NewTrackerLH100.aspx?CampaignID=" & CampaignID & "&AgentId=" & AgentId & "&AgentName=" & AgentName & "&IsVerifier=" & IsVerifier & "', '', 'menubar=no,toolbar=no,scrollbars=1,status=yes, width=' + screen.width + ', height= ' + screen.height + ' top=0, left=0,right=0, bottom=-10','true');"
                    End If

                    ScriptManager.RegisterStartupScript(Page, Page.GetType(), "OpenWindow", str, True)

                    Dim str1 As String
                    If Request.Browser.Type.Contains("IE") Then
                        str1 = "window.open('', '_self','');window.close(); "
                    Else
                        str1 = "window.open('', '_self','');window.close(); "
                    End If
                    ScriptManager.RegisterStartupScript(Page, Page.GetType(), "CloseWindow", str1, True)
                End If

            Else
                'other than LH process 341
                If hdpopup.Value = "false" Then

                    Response.Redirect("~/Tracker/_NewTracker.aspx?CampaignID=" & CampaignID & "&AgentId=" & AgentId & "&AgentName=" & AgentName & "&IsVerifier=" & IsVerifier)
                Else
                    Dim str As String
                    If Request.Browser.Type.Contains("IE") Then
                        str = "window.moveTo(0,0); window.open('_NewTracker.aspx?CampaignID=" & CampaignID & "&AgentId=" & AgentId & "&AgentName=" & AgentName & "&IsVerifier=" & IsVerifier & "', '', 'menubar=no,toolbar=no,scrollbars=1,status=yes,resizable=yes, width=' + screen.width + ', height= ' + screen.height + ' top=0, left=0,right=0, bottom=-10','true');"
                    Else
                        str = "window.moveTo(0,0); window.open('_NewTracker.aspx?CampaignID=" & CampaignID & "&AgentId=" & AgentId & "&AgentName=" & AgentName & "&IsVerifier=" & IsVerifier & "', '', 'menubar=no,toolbar=no,scrollbars=1,status=yes, width=' + screen.width + ', height= ' + screen.height + ' top=0, left=0,right=0, bottom=-10','true');"
                    End If

                    ScriptManager.RegisterStartupScript(Page, Page.GetType(), "OpenWindow", str, True)

                    Dim str1 As String
                    If Request.Browser.Type.Contains("IE") Then
                        str1 = "window.open('', '_self','');window.close(); "
                    Else
                        str1 = "window.open('', '_self','');window.close(); "
                    End If
                    ScriptManager.RegisterStartupScript(Page, Page.GetType(), "CloseWindow", str1, True)
                End If


            End If

        End If

    End Sub
#Region "Agent Log Related"
    Private Sub UpdateAgentLog(Optional ByVal logout As Boolean = False, Optional ByVal isbreak As Boolean = False)
        '  Dim db As New DBAccess("CRM")
        Try
            'db.slDataAdd("CampaignId", CampaignID)
            'db.slDataAdd("AgentId", AgentId)
            'db.slDataAdd("isBreak", isbreak)
            'db.slDataAdd("logout", logout) 'Logging out
            'db.slDataAdd("BreakType", IIf(isbreak, breaktype, 1))
            'db.Executeproc("usp_UpdateAgentLog")
            '--------------
            conn = New SqlConnection(connCRM)
            cmd = New SqlCommand()

            cmd.Parameters.AddWithValue("CampaignId", CampaignID)
            cmd.Parameters.AddWithValue("AgentId", AgentId)
            cmd.Parameters.AddWithValue("isBreak", isbreak)
            cmd.Parameters.AddWithValue("logout", logout)
            cmd.Parameters.AddWithValue("BreakType", IIf(isbreak, breaktype, 1))

            cmd.Connection = conn
            cmd.CommandType = CommandType.StoredProcedure
            cmd.CommandText = "usp_UpdateAgentLog"
            conn.Open()
            cmd.ExecuteNonQuery()
            conn.Close()
            cmd = Nothing
            '--------------

        Catch ex As Exception
            'winException.Log(ex)
            MsgBox(ex.ToString)
        Finally
            ' db = Nothing
        End Try
    End Sub
#End Region

End Class