﻿Imports com.nss.DBAccess
Imports System.Data
Imports System.Data.SqlClient


Partial Class Tracker_ReopenCases
    Inherits System.Web.UI.Page

    Dim dt As DataTable
    Dim connCRM As String = Common.connCRM
    Dim connLeads As String = Common.connLeads
    Dim connreport As String = Common.connreport

    Dim conn As SqlConnection
    Dim cmd As SqlCommand
    Dim adp As SqlDataAdapter


#Region "--- Properties ---"
    Dim m_ISTL As Boolean
    Public Property CampaignID() As Integer
        Get
            Return ViewState("CampaignID")
        End Get
        Set(ByVal value As Integer)
            ViewState("CampaignID") = value
        End Set
    End Property
    Public Property AgentID() As String
        Get
            Return ViewState("AgentID")
        End Get
        Set(ByVal value As String)
            ViewState("AgentID") = value
        End Set
    End Property
    Public Property AgentName() As String
        Get
            Return ViewState("AgentName")
        End Get
        Set(ByVal value As String)
            ViewState("AgentName") = value
        End Set
    End Property
    Public Property IsVerifier() As Boolean
        Get
            Return ViewState("IsVerifier")
        End Get
        Set(ByVal value As Boolean)
            ViewState("IsVerifier") = value
        End Set
    End Property
    Public Property TransID() As Int64
        Get
            Return ViewState("TransID")
        End Get
        Set(ByVal value As Int64)
            ViewState("TransID") = value
        End Set
    End Property
    Public Property customerid() As Integer
        Get
            Return ViewState("customerid")
        End Get
        Set(ByVal value As Integer)
            ViewState("customerid") = value
        End Set
    End Property
    Public Property DailStateBased() As Boolean
        Get
            Return ViewState("DailStateBased")
        End Get
        Set(ByVal value As Boolean)
            ViewState("DailStateBased") = value
        End Set
    End Property
#End Region
#Region "--- Load ---"
    Protected Sub setdate()
        For Each item As ListItem In DdlYears.Items
            If item.Text = Now.Year.ToString Then
                item.Selected = True
            End If
        Next
        For Each item As ListItem In DdlDay.Items
            If item.Value = Now.Day.ToString.PadLeft(2, "0") Then
                item.Selected = True
            End If
        Next
        For Each item As ListItem In DdlMonths.Items
            If item.Value = MonthName(Now.Month, True) Then
                item.Selected = True
            End If
        Next
        For Each item As ListItem In Ddlhh.Items
            If item.Value = Now.Hour.ToString.PadLeft(2, "0") Then
                item.Selected = True
            End If
        Next
        For Each item As ListItem In Ddlmm.Items
            If item.Value = Now.Minute.ToString.PadLeft(2, "0") Then
                item.Selected = True
            End If
        Next
    End Sub
    Private Function GetData() As Boolean
        dt = New DataTable
        '  Dim db1 As New DBAccess("CRM")
        'm_ISTL = db1.ReturnValue("SELECT [IsSupervisor] FROM [tbl_Data_UserRights] where [AgentID] ='" & AgentID & "' and CampaignID=" & CampaignID, False)
        'db1 = Nothing
        '--------------
        conn = New SqlConnection(connCRM)
        cmd = New SqlCommand()
        cmd.Connection = conn
        cmd.CommandType = CommandType.Text
        cmd.CommandText = "SELECT [IsSupervisor] FROM [tbl_Data_UserRights] where [AgentID] ='" & AgentID & "' and CampaignID=" & CampaignID
        conn.Open()
        m_ISTL = CBool(cmd.ExecuteScalar())
        conn.Close()
        cmd = Nothing
        '--------------

        ' Dim db As New DBAccess("Leads")

        If m_ISTL Then
            dgLeadData.Columns(0).Visible = True
        Else
            dgLeadData.Columns(0).Visible = False
        End If

        'db.slDataAdd("btexpired", 1)
        'db.slDataAdd("datefrom", DdlYears1.SelectedValue.ToString & DdlMonths1.SelectedValue.ToString & DdlDay1.SelectedValue.ToString)
        'db.slDataAdd("dateto", DdlYears2.SelectedValue.ToString & DdlMonths2.SelectedValue.ToString & DdlDay2.SelectedValue.ToString)
        'dt = db.ReturnTable("usp_Getleads" & CampaignID, , True)
        'db = Nothing

        '--------------
        conn = New SqlConnection(connLeads)
        cmd = New SqlCommand()
        cmd.Parameters.AddWithValue("btexpired", 1)
        cmd.Parameters.AddWithValue("datefrom", DdlYears1.SelectedValue.ToString & DdlMonths1.SelectedValue.ToString & DdlDay1.SelectedValue.ToString)
        cmd.Parameters.AddWithValue("dateto", DdlYears2.SelectedValue.ToString & DdlMonths2.SelectedValue.ToString & DdlDay2.SelectedValue.ToString)
        cmd.Connection = conn
        cmd.CommandType = CommandType.StoredProcedure
        cmd.CommandText = "usp_Getleads" & CampaignID
        adp = New SqlDataAdapter(cmd)
        adp.Fill(dt)
        cmd = Nothing
        adp = Nothing
        '--------------

        If dt.Columns.Count > 0 Then
            dgLeadData.DataSource = dt
            dgLeadData.DataBind()
        End If

        '  dt = Nothing
    End Function
    Protected Sub getsearch()
        If dt.Columns.Count > 0 Then
            cmbSearch.Items.Clear()
            For Each col As DataColumn In dt.Columns
                cmbSearch.Items.Add(col.ColumnName)
            Next
        End If
    End Sub
    Private Sub getoutcomefilter()
        Dim dtoutcome As New DataTable
        'Dim db As New DBAccess("CRM")

        'db.slDataAdd("CampaignID", CampaignID)
        'db.slDataAdd("isVerifier", 1)
        'dtoutcome = db.ReturnTable("usp_GetDispositions", , True)
        '--------------
        conn = New SqlConnection(connCRM)
        cmd = New SqlCommand()
        cmd.Parameters.AddWithValue("CampaignID", CampaignID)
        cmd.Parameters.AddWithValue("isVerifier", 1)
        cmd.Connection = conn
        cmd.CommandType = CommandType.StoredProcedure
        cmd.CommandText = "usp_GetDispositions"
        adp = New SqlDataAdapter(cmd)
        adp.Fill(dtoutcome)
        cmd = Nothing
        adp = Nothing
        '--------------

        cmbOutcome.DataTextField = "Caption"
        cmbOutcome.DataSource = dtoutcome
        cmbOutcome.DataBind()
        cmbOutcome.Items.Insert(0, "All")
        cmbOutcome.Items.Insert(1, "None")
        'If Not db Is Nothing Then
        '    db = Nothing
        'End If

        dtoutcome = Nothing
    End Sub
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        CampaignID = Request.QueryString("CampaignID")
        AgentID = Request.QueryString("AgentID")
        AgentName = Request.QueryString("AgentName")
        IsVerifier = Request.QueryString("IsVerifier")
        DailStateBased = Request.QueryString("DailStateBased")
        Header1.AgentID = AgentID
        Header1.Agentname = AgentName
        If Not IsPostBack Then
            DdlYears1.SelectedValue = Date.Now.AddDays(-10).Year
            DdlMonths1.SelectedValue = Date.Now.AddDays(-10).Month.ToString.PadLeft(2, "0")
            DdlDay1.SelectedValue = Date.Now.AddDays(-10).Day.ToString.PadLeft(2, "0")
            DdlYears2.SelectedValue = Date.Now.Year
            DdlMonths2.SelectedValue = Date.Now.Month.ToString.PadLeft(2, "0")
            DdlDay2.SelectedValue = Date.Now.Day.ToString.PadLeft(2, "0")
            GetData()
            getsearch()
            getoutcomefilter()
            setdate()
            'FillDispostions(CampaignID)
        End If
    End Sub
#End Region
#Region "--- Support Functions ---"
    Protected Sub search()
        GetData()
        If txtreferenceid.Text = "" Then
            'GetData()
            dgLeadData.DataSource = Nothing
            dgLeadData.DataSource = dt.DefaultView
        Else
            If cmbSearch.SelectedItem.Text <> "" Then

                If dt.Rows.Count > 0 Then
                    Dim dtfiltered As DataTable = dt.Clone
                    Dim drs As DataRow()
                    drs = dt.Select("[" & cmbSearch.SelectedItem.Text & "] = '" & txtreferenceid.Text & "'")
                    For Each dr1 As DataRow In drs
                        dtfiltered.ImportRow(dr1)
                    Next
                    dgLeadData.DataSource = Nothing
                    dgLeadData.DataSource = dtfiltered.DefaultView
                    'dgLeadData.DataBind()
                Else
                    customerid = -1
                    dgLeadData.DataSource = dt
                End If
                dgLeadData.DataBind()
            End If

        End If
    End Sub
    Private Sub insertintolog(ByVal comment As String, ByVal type As String)
        ' Dim dblog As New com.nss.DBAccess.DBAccess("CRM")
        'dblog.slDataAdd("process", CampaignID)
        'dblog.slDataAdd("User", AgentID)
        'dblog.slDataAdd("Type", type)
        'dblog.slDataAdd("change", comment)
        'dblog.InsertinTable("tbl_changeLog")
        'dblog = Nothing
        '--------------
        conn = New SqlConnection(connCRM)
        cmd = New SqlCommand()
        cmd.Connection = conn
        cmd.CommandType = CommandType.Text
        cmd.CommandText = "INSERT INTO tbl_changeLog (process,[User],Type,change) VALUES ('" & CampaignID & "','" & AgentID & "','" & type & "','" & comment & "')"
        conn.Open()
        cmd.ExecuteNonQuery()
        conn.Close()
        cmd = Nothing
        '--------------
    End Sub
    Private Sub FillDispostions(ByVal CampaignID As Integer)
        Try
            Dim dtDisposition As New DataTable

            conn = New SqlConnection(connCRM)
            cmd = New SqlCommand()

            cmd.Parameters.AddWithValue("CampaignID", CampaignID)
            cmd.Parameters.AddWithValue("isVerifier", IsVerifier)

            cmd.Connection = conn
            cmd.CommandType = CommandType.StoredProcedure
            cmd.CommandText = "usp_GetDispositions"
            adp = New SqlDataAdapter(cmd)
            adp.Fill(dtDisposition)
            cmd = Nothing
            adp = Nothing
            'ddlReason.DataTextField = "Caption"
            'ddlReason.DataValueField = "Code"
            'ddlReason.DataSource = dtDisposition
            'ddlReason.DataBind()
            dtDisposition = Nothing

        Catch ex As Exception
            lblhidden.Text = ex.Message
        End Try
    End Sub
#End Region
#Region "--- Events ---"
    Protected Sub btSearch_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btSearch.Click
        search()
    End Sub

   
    Protected Sub dgLeadData_PageIndexChanging(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewPageEventArgs) Handles dgLeadData.PageIndexChanging
        dgLeadData.PageIndex = e.NewPageIndex
        GetData()
    End Sub

    Protected Sub dgLeadData_RowDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles dgLeadData.RowDataBound
        'Dim strdate As String = ""
        'strdate = DdlDay.SelectedValue & "-" & DdlMonths.SelectedItem.Text & "-" & DdlYears.Text & " " & Ddlhh.SelectedValue & ":" & Ddlmm.SelectedValue
        If e.Row.RowType = DataControlRowType.DataRow Then
            Dim lnk As LinkButton = e.Row.FindControl("btselect")
            lnk.Attributes.Add("onclick", "javascript:return " _
           & "confirm('You are about to re-open a case with Customer Id [ " & DataBinder.Eval(e.Row.DataItem, "CustomerId") & " ]')")
           
        End If
    End Sub
    Protected Sub dgLeadData_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles dgLeadData.SelectedIndexChanged
        insertTransaction(dgLeadData.SelectedDataKey.Value)
    End Sub
    Protected Sub insertTransaction(ByVal customerid As Integer)
        If txtReason.Text.Trim <> "" Then
            Dim tran As SqlTransaction
            Dim datediff As Integer
            ' Dim dbSetting As New DBAccess("CRM")
            'datediff = dbSetting.ReturnValue("SELECT [TimeDiff]  FROM [tbl_Config_Campaign_TimeDifference] where Campaignid =" & CampaignID)
            'dbSetting = Nothing
            '--------------
            conn = New SqlConnection(connCRM)
            cmd = New SqlCommand()
            cmd.Connection = conn
            cmd.CommandType = CommandType.Text
            cmd.CommandText = "SELECT [TimeDiff]  FROM [tbl_Config_Campaign_TimeDifference] where Campaignid =" & CampaignID
            conn.Open()
            datediff = CInt(cmd.ExecuteScalar())
            conn.Close()
            cmd = Nothing
            '--------------

            Dim fromDate As String
            fromDate = DdlYears.SelectedValue.ToString & "-" & DdlMonths.SelectedValue & "-" & DdlDay.SelectedValue.ToString.PadLeft(2, "0") & " " & Ddlhh.SelectedValue.ToString & ":" & Ddlmm.SelectedValue.ToString
            ' Dim db As New DBAccess("CRM")
            Try
                'db.BeginTrans()
                'db.exeSQL("UPDATE [tbl_Data_TATDetails] SET [LastTATStartTime] ='" & fromDate & "',[LastTATEndTime] = null,[RetroTAT] = isnull(([dbo].[ufn_GetRazonTat]([LastTATStartTime],dateadd(n," & datediff & ",[LastTATEndTime]))*3600) + [RetroTAT],0)  WHERE [CustomerID] =" & customerid & " and campaignid=" & CampaignID)
                'db.exeSQL("update tbl_Customer_Last_Status set btExpired =0 WHERE [CustomerID] =" & customerid & " and campaignid=" & CampaignID)
                'db.exeSQL("update [Leads].[dbo].tbl_LeadMaster159 set IsExpired =0,DialState=0 WHERE [CustomerID] =" & customerid)

                'db.slDataAdd("customerid", customerid)
                'db.slDataAdd("Campaignid", CampaignID)
                'db.slDataAdd("Reason", ddlReason.SelectedItem.Text.Trim)
                'db.slDataAdd("UpdatedBy", AgentID)
                'db.slDataAdd("RecievedDateTime", fromDate)
                'db.InsertinTable("tbl_Data_ReopenStatus")
                'db.CommitTrans()
                '--------------
                conn = New SqlConnection(connCRM)
                cmd = New SqlCommand()
                conn.Open()

                tran = conn.BeginTransaction()

                cmd.Transaction = tran
                cmd.Connection = conn
                cmd.CommandType = CommandType.Text

                If CampaignID = 159 Then
                    cmd.CommandText = "UPDATE [tbl_Data_TATDetails] SET [LastTATStartTime] ='" & fromDate & "',[LastTATEndTime] = null,[RetroTAT] = isnull(([dbo].[ufn_GetRazonTat]([LastTATStartTime],dateadd(n," & datediff & ",[LastTATEndTime]))*3600) + [RetroTAT],0)  WHERE [CustomerID] =" & customerid & " and campaignid=" & CampaignID
                    cmd.ExecuteNonQuery()
                Else
                    cmd.CommandText = "UPDATE [tbl_Data_TATDetails] SET [LastTATStartTime] ='" & fromDate & "',[LastTATEndTime] = null,[RetroTAT] = isnull([dbo].[ufn_GetBusinessDays](isnull([LastTATStartTime],dateadd(n," & datediff & ",[LastTATEndTime])),GETDATE()) + isnull([RetroTAT],0),0)  WHERE [CustomerID] =" & customerid & " and campaignid=" & CampaignID
                    cmd.ExecuteNonQuery()
                End If
                cmd.CommandText = "update tbl_Customer_Last_Status set btExpired =0 WHERE [CustomerID] =" & customerid & " and campaignid=" & CampaignID
                cmd.ExecuteNonQuery()

                If DailStateBased Then
                    cmd.CommandText = "update [Leads].[dbo].tbl_LeadMaster" & CampaignID & "  set IsExpired =0,DialState=0 WHERE [CustomerID] =" & customerid
                    cmd.ExecuteNonQuery()
                Else
                    cmd.CommandText = "update [Leads].[dbo].tbl_LeadMaster" & CampaignID & "  set IsExpired =0 WHERE [CustomerID] =" & customerid
                    cmd.ExecuteNonQuery()
                End If
                'cmd.CommandText = "INSERT INTO tbl_Data_ReopenStatus(customerid,Campaignid,Reason,UpdatedBy,RecievedDateTime) VALUES('" & customerid & "','" & CampaignID & "','" & ddlReason.SelectedItem.Text.Trim & "','" & AgentID & "','" & fromDate & "')"
                cmd.CommandText = "INSERT INTO tbl_Data_ReopenStatus(customerid,Campaignid,Reason,UpdatedBy,RecievedDateTime) VALUES('" & customerid & "','" & CampaignID & "','" & txtReason.Text & "','" & AgentID & "','" & fromDate & "')"
                cmd.ExecuteNonQuery()
                tran.Commit()
                cmd = Nothing

                '--------------
            Catch ex As Exception
                'db.RollBackTrans()
                tran.Rollback()
            Finally
                'db = Nothing
                conn.Close()
            End Try
            ' db = Nothing

            Dim comment As String = ""
            comment = customerid & " Lead has been Re- opened By " & AgentID & " For Campaign " & CampaignID & " And Reason Selected is " & txtReason.Text.Trim  'ddlReason.SelectedItem.Text.Trim
            insertintolog(comment, "Lead Re-Open")
            search()
            lblErrormsg.Text = ""
            txtReason.Text = ""
        Else
            lblErrormsg.Text = "Please enter the reason for Re-Open"
        End If
    End Sub
    Protected Sub cmbOutcome_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmbOutcome.SelectedIndexChanged
        GetData()
        If dt.Rows.Count > 0 Then
            Dim dtfiltered As DataTable = dt.Clone
            Dim drs As DataRow()
            If cmbOutcome.SelectedItem.Text = "All" Then
                drs = dt.Select
            ElseIf cmbOutcome.SelectedItem.Text = "None" Then
                drs = dt.Select("[Out Come] is null")
            Else
                drs = dt.Select("[Out Come] = '" & Convert.ToString(cmbOutcome.SelectedItem.Text) & "'")
            End If
            For Each dr1 As DataRow In drs
                dtfiltered.ImportRow(dr1)
            Next
            dgLeadData.DataSource = Nothing
            dgLeadData.DataSource = dtfiltered
        Else
            customerid = -1
            dgLeadData.DataSource = dt
        End If
        dgLeadData.DataBind()
    End Sub
    Protected Sub LinkButton1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles LinkButton1.Click
        Response.Redirect("~/Tracker/NewTracker.aspx?CampaignID=" & CampaignID & "&AgentId=" & AgentID & "&AgentName=" & AgentName & "&IsVerifier=" & IsVerifier)
    End Sub
#End Region

End Class
