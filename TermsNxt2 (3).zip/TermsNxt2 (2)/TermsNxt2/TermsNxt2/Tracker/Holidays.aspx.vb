﻿Imports System.Data
Imports com.nss.DBAccess
Imports System.Data.SqlClient
Imports System.Data.Sql


Partial Class Tracker_Holidays
    Inherits System.Web.UI.Page

    Dim connCRM As String = Common.connCRM
    Dim connLeads As String = Common.connLeads
    Dim connreport As String = Common.connreport

    Dim conn As SqlConnection
    Dim cmd As SqlCommand
    Dim adp As SqlDataAdapter

#Region "--- Load ---"
    Private Sub HolidayList()
        ' Dim db As New DBAccess("CRM")
        Dim dt As New DataTable
        Try
            'dt = db.ReturnTable("SELECT * FROM [tbl_Config_Holidays] WHERE CampaignID=159 order by date", False)
            'db = Nothing
            '--------------
            conn = New SqlConnection(connCRM)
            cmd = New SqlCommand()
            cmd.Connection = conn
            cmd.CommandType = CommandType.Text
            cmd.CommandText = "SELECT * FROM [tbl_Config_Holidays] WHERE CampaignID=159 order by date"
            adp = New SqlDataAdapter(cmd)
            adp.Fill(dt)
            cmd = Nothing
            adp = Nothing
            '--------------

            gdHolidayList.DataSource = dt
            gdHolidayList.DataBind()
        Catch ex As Exception
            lblmsg.Text = ex.Message.ToString
        End Try
    End Sub
    Protected Sub setdate()
        For Each item As ListItem In ddlYear.Items
            If item.Text = Now.Year.ToString Then
                item.Selected = True
            End If
        Next
        For Each item As ListItem In DdlDay.Items
            If item.Value = Now.Day.ToString.PadLeft(2, "0") Then
                item.Selected = True
            End If
        Next
        For Each item As ListItem In ddlMonth.Items
            If item.Value = Now.Month.ToString.PadLeft(2, "0") Then
                item.Selected = True
            End If
        Next
    End Sub
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            HolidayList()
            setdate()
        End If
    End Sub
#End Region
#Region "--- Suport Functions ---"
    Private Sub SaveHolidy()
        ' Dim db As New DBAccess("CRM")
        Try
            lblmsg.Text = ""
            Dim holiday = ddlYear.SelectedValue
            holiday += ddlMonth.SelectedValue
            holiday += ddlDay.SelectedValue
            Dim Day = ""
            '------------------------
            conn = New SqlConnection(connCRM)
            cmd = New SqlCommand()
            cmd.Connection = conn
            cmd.CommandType = CommandType.Text
            cmd.CommandText = "select date From [tbl_Config_Holidays] where date='" + holiday + "' and CampaignID=159"
            conn.Open()
            Day = CStr(cmd.ExecuteScalar())
            conn.Close()
            cmd = Nothing
            '-----------------------
            If Day = "" Then
                Dim db1 As New DBAccess("CRM")
                db1.slDataAdd("CampaignID", 159)
                db1.slDataAdd("Reason", txtReason.Text)
                db1.slDataAdd("date", holiday)
                db1.InsertinTable("[tbl_Config_Holidays]")
                db1 = Nothing
                txtReason.Text = ""
                HolidayList()
            Else
                lblmsg.Text = "Date Already in Holiday List !!...."
            End If
        Catch ex As Exception
            lblmsg.Text = ex.Message.ToString
        End Try
    End Sub
#End Region
#Region "--- Events ---"
    Protected Sub btsave_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btsave.Click
        SaveHolidy()
    End Sub
    Protected Sub gdHolidayList_RowCommand(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewCommandEventArgs) Handles gdHolidayList.RowCommand
        '  Dim db As New DBAccess("CRM")
        Try
            If e.CommandName = "Remove" Then
                lblmsg.Text = ""
                Dim gvr As GridViewRow = gdHolidayList.Rows(Convert.ToInt32(e.CommandArgument))
                Dim CampID As String = gdHolidayList.DataKeys(gvr.RowIndex)("CampaignID")
                Dim Hdate As String = gvr.Cells(0).Text
                Dim Day = ""

                'Day = db.ReturnValue("select date From [CRM].[dbo].[tbl_Config_Holidays] where date='" + Hdate + "' and CampaignID=159")
                'db = Nothing
                '--------------
                conn = New SqlConnection(connCRM)
                cmd = New SqlCommand()
                cmd.Connection = conn
                cmd.CommandType = CommandType.Text
                cmd.CommandText = "select date From [CRM].[dbo].[tbl_Config_Holidays] where date='" + Hdate + "' and CampaignID=159"
                conn.Open()
                Day = CStr(cmd.ExecuteScalar())
                conn.Close()
                cmd = Nothing
                '--------------

                If Day <> "" Then
                    Dim db1 As New DBAccess("CRM")
                    db1.slDataAdd("CampaignID", CampID)
                    db1.slDataAdd("date", Day)
                    db1.DeleteinTable("[tbl_Config_Holidays]", "CampaignID='" + CampID + "' and date='" + Day + "'")
                    db1 = Nothing
                    HolidayList()
                End If
            End If
        Catch ex As Exception
            lblmsg.Text = ex.Message.ToString
        End Try
    End Sub
#End Region

End Class
