﻿Imports System.Globalization
Imports LibFolder
Imports com.nss.DBAccess
Imports System.Data
Public Class _TMPerformanceData_Datewise
    Inherits System.Web.UI.Page

    'Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

    'End Sub

    Dim footerval(12) As Integer
    Dim dt, dt1 As DataTable

#Region "Properties"

    Property startday() As String
        Get
            Return ViewState("startday")
        End Get
        Set(ByVal value As String)
            ViewState("startday") = value
        End Set
    End Property
    Property endday() As String
        Get
            Return ViewState("endday")
        End Get
        Set(ByVal value As String)
            ViewState("endday") = value
        End Set
    End Property

    Property CampaignID() As Integer
        Get
            Return ViewState("CampaignID")
        End Get
        Set(ByVal value As Integer)
            ViewState("CampaignID") = value
        End Set
    End Property

    Property AgentID() As String
        Get
            Return ViewState("AgentID")
        End Get
        Set(ByVal value As String)
            ViewState("AgentID") = value
        End Set
    End Property

    Public Property AgentName() As String
        Get
            Return ViewState("AgentName")
        End Get
        Set(ByVal value As String)
            ViewState("AgentName") = value
        End Set
    End Property
#End Region

#Region "Load"
    Protected Sub CboPeriod_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles CboPeriod.SelectedIndexChanged
        If CboPeriod.SelectedValue = 10 Then
            'ucDateFrom.Visible = True
            'UcDateTo.Visible = True
            'lblAnd.Visible = True

            txtFrom.Visible = True
            lblAnd.Visible = True
            txtTo.Visible = True

            fillgrid()
        Else
            'ucDateFrom.Visible = False
            'UcDateTo.Visible = False
            'lblAnd.Visible = False

            txtFrom.Visible = False
            lblAnd.Visible = False
            txtTo.Visible = False

            fillgrid()
        End If
    End Sub


    Protected Sub btnRefresh_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnRefresh.Click
        'If cboCampaigns.SelectedItem.Text = "HPS" Then
        '    CboPeriod.SelectedValue = 3
        'End If
        fillgrid()
    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        HumanMessage.Style.Item("visibility") = "hidden"
        If Not IsPostBack Then
            CampaignID = Request.QueryString("CampaignID")
            AgentID = Request.QueryString("AgentID")
            AgentName = Request.QueryString("AgentName")

            'TrackerHeader1.AgentID = AgentID
            ' TrackerHeader1.Agentname = AgentName
            'To maximise the Web Page during loading
            ' RegisterClientScriptBlock("", "<script>top.window.moveTo(0,0); top.window.resizeTo(screen.availWidth,screen.availHeight);</script>")
            ClientScript.RegisterClientScriptBlock(Page.GetType(), "", "<script>top.window.moveTo(0,0); top.window.resizeTo(screen.availWidth,screen.availHeight);</script>")

            FillCommonFilters()
            fillgrid()
        End If

    End Sub
    Private Sub FillCommonFilters()
        Dim db As New DBAccess("report")
        Dim dt As DataTable = db.ReturnTable("select * from tbl_Reports_DatePeriods")
        db = Nothing
        Dim dr As DataRow = dt.NewRow
        dr(0) = 10
        dr(1) = "Between"
        dt.Rows.Add(dr)
        CboPeriod.DataTextField = "Caption"
        CboPeriod.DataValueField = "Period"
        CboPeriod.DataSource = dt
        CboPeriod.DataBind()
        'db = New DBAccess
        'dt = db.ReturnTable("Select * from tbl_Reports_GroupBy")
        'db = Nothing
        'CboGroup.DataTextField = "Caption"
        'CboGroup.DataValueField = "ID"
        'CboGroup.DataSource = dt
        'CboGroup.DataBind()
    End Sub

    Private Sub fillgrid()
        For Each obj In footerval
            obj = 0
        Next
        'Dim db As New DBAccess

        Dim db As New DBAccess("report")
        'Dim startday As Integer, endday As Integer
        If CboPeriod.SelectedValue = 10 Then
            If (txtFrom.Text <> "") Then
                startday = Convert.ToDateTime(txtFrom.Text).ToString("yyyyMMdd", CultureInfo.InvariantCulture).ToString()

            End If
            If (txtTo.Text <> "") Then
                endday = Convert.ToDateTime(txtTo.Text).ToString("yyyyMMdd", CultureInfo.InvariantCulture).ToString()

            End If

        Else
            db = New DBAccess("report")
            db.slDataAdd("Period", CboPeriod.SelectedValue)
            db.slDataAdd("Campaignid", CampaignID)
            Dim dr As DataRow = db.ReturnRow("usp_GetStart_EndDateForAPeriod", True)
            db = Nothing
            startday = dr(0)
            endday = dr(1) + 1
        End If
        db = New DBAccess("report")



        db.slDataAdd("startday", startday)
        db.slDataAdd("endDay", endday)

        db.slDataAdd("campaignid", CampaignID)
        db.slDataAdd("agentID", AgentID)




        dt = db.ReturnTable("usp_QuestData_AgentWise_341", , True)
        db = Nothing
        ' lblReportName.Text = "Transaction Summary "
        ' LblError.Text = "Between " & IntegerToDateString(startday) & "  and " & IntegerToDateString(endday) & " for " & cboCampaigns.SelectedItem.Text & " campaign"

        CreateGridColumns(dt.Columns)
        dt1 = dt.Copy
        For Each col As DataColumn In dt.Columns
            If col.ColumnName.Contains("Question") Then
                dt1.Columns.Remove(col.ColumnName)
            End If
        Next
        dt = dt1
        dt1 = Nothing

        If dt.Rows.Count > 0 Then
            GridView1.DataSource = dt
            GridView1.DataBind()
        End If
    End Sub

#End Region

#Region "Grid Ops"
    Private Sub CreateGridColumns(ByVal cols As DataColumnCollection)
        Dim db As New DBAccess("report")
        db.slDataAdd("CampaignID", CampaignID)
        Dim dtoutcome As DataTable = db.ReturnTable("usp_ReportQuestDataDescription", , True)
        For Each dr In dtoutcome.Rows
            cols("Question" & dr("ReportSequence")).Caption = dr("Caption")
        Next

        Dim objcol As DataColumn

        For Each objcol In cols

            If objcol.ColumnName.Contains("Question") Then
                If objcol.Caption <> objcol.ColumnName Then
                    objcol.ColumnName = objcol.Caption

                End If

            End If
        Next
    End Sub
#End Region

#Region "Utility"
    Private Sub AlertMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMFail"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub
    Private Sub SuccessMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMSuccess"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub

#End Region

End Class