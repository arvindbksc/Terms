﻿Imports com.nss.DBAccess
Imports System.Data
Imports System.Drawing
Imports System.Data.Sql
Imports System.Data.SqlClient

Partial Class Tracker_NewTrackerLH
    Inherits System.Web.UI.Page

    Dim dt As DataTable
    Dim connCRM As String = Common.connCRM
    Dim connLeads As String = Common.connLeads
    Dim connreport As String = Common.connreport

    Dim conn As SqlConnection
    Dim cmd As SqlCommand
    Dim adp As SqlDataAdapter
    Dim dateflag As Boolean = True
    Dim dtparamdata As DataTable

#Region "--- Properties ---"
    Dim m_ISTL As Boolean
    Dim m_strAssisted As String = "Assisted"
    Dim m_strAmadeus As String = "Amadeus"
    Dim m_strInResort As String = "InResort"
    Dim m_strPostTravel As String = "PostTravel"
    Dim m_strMMB As String = "MMB"
    Dim m_strMMBKustomer As String = "MMBKustomer"
    Dim m_strMMBDE As String = "MMBDE"
    Dim m_strCSChat As String = "CsChat"
    Dim m_strCSVoice As String = "CsVoice"
    Dim m_strCreditControl As String = "CreditControl"
    Dim m_strSupplierRelocation As String = "SupplierRelocation"
    Dim m_strCustomerServiceInbox As String = "CustomerServiceInbox"
    Dim m_strAssistedRyanAir As String = "AssistedRyanAir"
    Dim m_strRefundTask As String = "RefundTask"
    Dim m_strOtherWorkType As String = "OtherWorkType"


    Public Property Assisted() As String
        Get
            Return ViewState("Assisted")
        End Get
        Set(ByVal value As String)
            ViewState("Assisted") = value
        End Set
    End Property

    Public Property Amadeus() As String
        Get
            Return ViewState("Amadeus")
        End Get
        Set(ByVal value As String)
            ViewState("Amadeus") = value
        End Set
    End Property

    Public Property InResort() As String
        Get
            Return ViewState("InResort")
        End Get
        Set(ByVal value As String)
            ViewState("InResort") = value
        End Set
    End Property

    Public Property PostTravel() As String
        Get
            Return ViewState("PostTravel")
        End Get
        Set(ByVal value As String)
            ViewState("PostTravel") = value
        End Set
    End Property

    Public Property MMB() As String
        Get
            Return ViewState("MMB")
        End Get
        Set(ByVal value As String)
            ViewState("MMB") = value
        End Set
    End Property


    Public Property MMBDE() As String
        Get
            Return ViewState("MMBDE")
        End Get
        Set(ByVal value As String)
            ViewState("MMBDE") = value
        End Set
    End Property
    Public Property MMBKustomer() As String
        Get
            Return ViewState("MMBKustomer")
        End Get
        Set(ByVal value As String)
            ViewState("MMBKustomer") = value
        End Set
    End Property

    Public Property CSChat() As String
        Get
            Return ViewState("CSChat")
        End Get
        Set(ByVal value As String)
            ViewState("CSChat") = value
        End Set
    End Property

    Public Property CSVoice() As String
        Get
            Return ViewState("CSVoice")
        End Get
        Set(ByVal value As String)
            ViewState("CSVoice") = value
        End Set
    End Property

    Public Property CreditControl() As String
        Get
            Return ViewState("CreditControl")
        End Get
        Set(ByVal value As String)
            ViewState("CreditControl") = value
        End Set
    End Property


    Public Property SupplierRelocation() As String
        Get
            Return ViewState("SupplierRelocation")
        End Get
        Set(ByVal value As String)
            ViewState("SupplierRelocation") = value
        End Set
    End Property
    Public Property CustomerServiceInbox() As String
        Get
            Return ViewState("CustomerServiceInbox")
        End Get
        Set(ByVal value As String)
            ViewState("CustomerServiceInbox") = value
        End Set
    End Property
    Public Property AssistedRyanAir() As String
        Get
            Return ViewState("AssistedRyanAir")
        End Get
        Set(ByVal value As String)
            ViewState("AssistedRyanAir") = value
        End Set
    End Property

    Public Property RefundTask() As String
        Get
            Return ViewState("RefundTask")
        End Get
        Set(ByVal value As String)
            ViewState("RefundTask") = value
        End Set
    End Property


    Public Property OtherWorkType() As String
        Get
            Return ViewState("OtherWorkType")
        End Get
        Set(ByVal value As String)
            ViewState("OtherWorkType") = value
        End Set
    End Property
    Public Property CampaignID() As Integer
        Get
            Return ViewState("CampaignID")
        End Get
        Set(ByVal value As Integer)
            ViewState("CampaignID") = value
        End Set
    End Property
    Public Property AgentID() As String
        Get
            Return ViewState("AgentID")
        End Get
        Set(ByVal value As String)
            ViewState("AgentID") = value
        End Set
    End Property
    Public Property AgentName() As String
        Get
            Return ViewState("AgentName")
        End Get
        Set(ByVal value As String)
            ViewState("AgentName") = value
        End Set
    End Property
    Public Property IsVerifier() As Boolean
        Get
            Return ViewState("IsVerifier")
        End Get
        Set(ByVal value As Boolean)
            ViewState("IsVerifier") = value
        End Set
    End Property
    Public Property TransID() As Int64
        Get
            Return ViewState("TransID")
        End Get
        Set(ByVal value As Int64)
            ViewState("TransID") = value
        End Set
    End Property

    Public Property TransIDTMF() As Int64
        Get
            Return ViewState("TransIDTMF")
        End Get
        Set(ByVal value As Int64)
            ViewState("TransIDTMF") = value
        End Set
    End Property

    Public Property customerid() As Integer
        Get
            Return ViewState("customerid")
        End Get
        Set(ByVal value As Integer)
            ViewState("customerid") = value
        End Set
    End Property
    Public Property DailStateBased() As Boolean
        Get
            Return ViewState("DailStateBased")
        End Get
        Set(ByVal value As Boolean)
            ViewState("DailStateBased") = value
        End Set
    End Property
    Public Property UpdateLead() As Boolean
        Get
            Return ViewState("UpdateLead")
        End Get
        Set(ByVal value As Boolean)
            ViewState("UpdateLead") = value
        End Set
    End Property
    Public Property LeadsBased() As Boolean
        Get
            Return ViewState("LeadsBased")
        End Get
        Set(ByVal value As Boolean)
            ViewState("LeadsBased") = value
        End Set
    End Property
    Public Property ReceivedDateTimeBased() As Boolean
        Get
            Return ViewState("ReceivedDateTimeBased")
        End Get
        Set(ByVal value As Boolean)
            ViewState("ReceivedDateTimeBased") = value
        End Set
    End Property
    Public Property ReopenBased() As Boolean
        Get
            Return ViewState("ReopenBased")
        End Get
        Set(ByVal value As Boolean)
            ViewState("ReopenBased") = value
        End Set
    End Property
    Public Property BreakType() As Integer
        Get
            Return ViewState("BreakType")
        End Get
        Set(ByVal value As Integer)
            ViewState("BreakType") = value
        End Set
    End Property
    Public Property ISbreaktype() As Boolean
        Get
            Return ViewState("ISbreaktype")
        End Get
        Set(ByVal value As Boolean)
            ViewState("ISbreaktype") = value
        End Set
    End Property

    Public Property OnBreak() As Boolean
        Get
            Return ViewState("OnBreak")
        End Get
        Set(ByVal value As Boolean)
            ViewState("OnBreak") = value
        End Set
    End Property
    Public Property TransactionBased() As Boolean
        Get
            Return ViewState("TransactionBased")
        End Get
        Set(ByVal value As Boolean)
            ViewState("TransactionBased") = value
        End Set
    End Property
    Public Property CanDeleteLeads() As Boolean
        Get
            Return ViewState("CanDeleteLeads")
        End Get
        Set(ByVal value As Boolean)
            ViewState("CanDeleteLeads") = value
        End Set
    End Property
    'Public Property Saveclick() As Integer
    '    Get
    '        Return Session("Saveclick")
    '    End Get
    '    Set(ByVal value As Integer)
    '        Session("Saveclick") = value
    '    End Set
    'End Property
    Public Property dtcalculate() As DataTable
        Get
            Return ViewState("dtcalculate")
        End Get
        Set(ByVal value As DataTable)
            ViewState("dtcalculate") = value
        End Set
    End Property

    Public Property IsLeadcomment() As Boolean
        Get
            Return ViewState("IsLeadcomment")
        End Get
        Set(ByVal value As Boolean)
            ViewState("IsLeadcomment") = value
        End Set
    End Property

    'Public Property IsLeadcomment() As Boolean
    '    Get
    '        Return ViewState("IsLeadcomment")
    '    End Get
    '    Set(ByVal value As Boolean)
    '        ViewState("IsLeadcomment") = value
    '    End Set
    'End Property

    '---Added rajkumar 09-08-2013   -- Start
    Property CMFID() As Integer
        Get
            Return ViewState("CMFID")
        End Get
        Set(ByVal value As Integer)
            ViewState("CMFID") = value
        End Set
    End Property
    Property SheetID() As Integer
        Get
            Return ViewState("SheetID")
        End Get
        Set(ByVal value As Integer)
            ViewState("SheetID") = value
        End Set
    End Property
    Property TransDate() As String
        Get
            Return ViewState("TransDate")
        End Get
        Set(ByVal value As String)
            ViewState("TransDate") = value
        End Set
    End Property
    Property StandaloneCMF() As Boolean
        Get
            Return ViewState("StandaloneCMF")
        End Get
        Set(ByVal value As Boolean)
            ViewState("StandaloneCMF") = value
        End Set
    End Property
    Property UserID() As String
        Get
            Return ViewState("UserID")
        End Get
        Set(ByVal value As String)
            ViewState("UserID") = value
        End Set
    End Property
    Property WorkingonTMF() As Boolean
        Get
            Return ViewState("WorkingonTMF")
        End Get
        Set(ByVal value As Boolean)
            ViewState("WorkingonTMF") = value
        End Set
    End Property
    Property MainCatID() As Integer
        Get
            Return ViewState("MainCatID")
        End Get
        Set(ByVal value As Integer)
            ViewState("MainCatID") = value
        End Set
    End Property
    Property SubCatID() As Integer
        Get
            Return ViewState("SubCatID")
        End Get
        Set(ByVal value As Integer)
            ViewState("SubCatID") = value
        End Set
    End Property
    Property LoginUserName() As String
        Get
            Return ViewState("LoginUserName")
        End Get
        Set(ByVal value As String)
            ViewState("LoginUserName") = value
        End Set
    End Property
    Property btFreez() As Boolean
        Get
            Return ViewState("btFreez")
        End Get
        Set(ByVal value As Boolean)
            ViewState("btFreez") = value
        End Set
    End Property
    Property QEID() As String
        Get
            Return ViewState("QEID")
        End Get
        Set(ByVal value As String)
            ViewState("QEID") = value
        End Set
    End Property
    Property TransIDQuality() As String
        Get
            Return ViewState("TransIDQuality")
        End Get
        Set(ByVal value As String)
            ViewState("TransIDQuality") = value
        End Set
    End Property
    Public Property QEAgentID() As String
        Get
            Return ViewState("QEAgentID")
        End Get
        Set(ByVal value As String)
            ViewState("QEAgentID") = value
        End Set
    End Property
    '---Added rajkumar 09-08-2013   --End
    Public Property Paused() As Integer
        Get
            Return ViewState("Paused")
        End Get
        Set(ByVal value As Integer)
            ViewState("Paused") = value
        End Set
    End Property
    Public Property PausedId() As Integer
        Get
            Return ViewState("PausedId")
        End Get
        Set(ByVal value As Integer)
            ViewState("PausedId") = value
        End Set
    End Property

    Public Property HolidayBased() As Boolean
        Get
            Return ViewState("HolidayBased")
        End Get
        Set(ByVal value As Boolean)
            ViewState("HolidayBased") = value
        End Set
    End Property
    Public Property UpdateClientTat() As Boolean
        Get
            Return ViewState("UpdateClientTat")
        End Get
        Set(ByVal value As Boolean)
            ViewState("UpdateClientTat") = value
        End Set
    End Property

    Public Property SDecNSlip() As String
        Get
            Return ViewState("SDecNSlip")
        End Get
        Set(ByVal value As String)
            ViewState("SDecNSlip") = value
        End Set
    End Property

    Public Property CurrentAnsID() As String
        Get
            Return ViewState("CurrentAnsID")
        End Get
        Set(ByVal value As String)
            ViewState("CurrentAnsID") = value
        End Set
    End Property

    Public Property CurrentAnsText() As String
        Get
            Return ViewState("CurrentAnsText")
        End Get
        Set(ByVal value As String)
            ViewState("CurrentAnsText") = value
        End Set
    End Property






#End Region

#Region "--- Load Data ---"
    Protected Sub LoadSetting()
        ' === Modify on 26/05/10 ===
        Dim dtSetting As DataTable = New DataTable
        conn = New SqlConnection(connCRM)
        cmd = New SqlCommand("SELECT SettingValue,SettingName FROM tbl_Config_Campaign_Settings WHERE Campaignid='" & CampaignID & "'", conn)
        cmd.CommandType = CommandType.Text
        adp = New SqlDataAdapter(cmd)
        adp.Fill(dtSetting)

        For Each row As DataRow In dtSetting.Rows
            If row.Item("SettingName").ToString.ToLower = "dailstatebased" Then
                DailStateBased = row.Item("SettingValue")
            End If
            If row.Item("SettingName").ToString.ToLower = "leadsbased" Then
                LeadsBased = row.Item("SettingValue")
            End If
            If row.Item("SettingName").ToString.ToLower = "receiveddatetimebased" Then
                ReceivedDateTimeBased = row.Item("SettingValue")
            End If
            If row.Item("SettingName").ToString.ToLower = "reopenbased" Then
                ReopenBased = row.Item("SettingValue")
            End If
            If row.Item("SettingName").ToString.ToLower = "breaktype" Then
                ISbreaktype = row.Item("SettingValue")
            End If
            If row.Item("SettingName").ToString.ToLower = "transactionbased" Then
                TransactionBased = row.Item("SettingValue")
            End If
            If row.Item("SettingName").ToString.ToLower = "candeleteleads" Then
                CanDeleteLeads = row.Item("SettingValue")
            End If
            If row.Item("SettingName").ToString.ToLower = "updatelead" Then
                UpdateLead = row.Item("SettingValue")
            End If
            If row.Item("SettingName").ToString.ToLower = "holidaybased" Then
                HolidayBased = row.Item("SettingValue")
            End If
            If row.Item("SettingName").ToString.ToLower = "updateclienttat" Then
                UpdateClientTat = row.Item("SettingValue")
            End If
        Next
        ' === END ===
        dtSetting = Nothing
    End Sub

    Private Function GetData() As Boolean
        Dim flagColumn As Boolean = False
        Dim varTMFView As String = ""

        dt = New DataTable

        conn = New SqlConnection(connCRM)
        cmd = New SqlCommand()
        cmd.Connection = conn
        cmd.CommandType = CommandType.Text
        cmd.CommandText = "SELECT [Btupload] FROM [tbl_AgentMaster] where [AgentID] ='" & AgentID & "'"
        conn.Open()
        m_ISTL = CBool(cmd.ExecuteScalar())
        cmd = Nothing
        conn.Close()

        conn = New SqlConnection(connCRM)
        cmd = New SqlCommand()
        cmd.Connection = conn
        cmd.CommandType = CommandType.Text
        cmd.CommandText = "SELECT [IsSupervisor] FROM [tbl_Data_UserRights] where [AgentID] ='" & AgentID & "' and CampaignID=" & CampaignID
        conn.Open()
        Dim TL As Boolean = CBool(cmd.ExecuteScalar())
        cmd = Nothing
        conn.Close()

        If TL Then
            ' === Modify on 26/05/10 ===
            If ReopenBased Then
                hlReopen.Visible = True
            Else
                hlReopen.Visible = False
            End If
            If HolidayBased Then
                hlHoliday.Visible = True
            Else
                hlHoliday.Visible = False
            End If
            ' ===== END=====
        Else
            hlReopen.Visible = False
            hlHoliday.Visible = False
        End If
        If LeadsBased Then
            conn = New SqlConnection(connLeads)
            cmd = New SqlCommand()

            If m_ISTL Then
                cmd.Parameters.AddWithValue("Agentid", "%")
                pnlAllocateAgents.Visible = True

                assign1.Visible = True
                assign.Visible = True
            Else
                cmd.Parameters.AddWithValue("Agentid", AgentID)
                pnlAllocateAgents.Visible = False

                assign1.Visible = False
                assign.Visible = False
            End If


            cmd.Connection = conn
            cmd.CommandType = CommandType.StoredProcedure
            cmd.CommandText = "usp_Getleads" & CampaignID

            adp = New SqlDataAdapter(cmd)
            adp.Fill(dt)
            cmd = Nothing
            adp = Nothing

            If dt.Columns.Count > 0 Then
                If txtreferenceid.Text <> "" Then
                    If dt.Rows.Count > 0 Then
                        Dim dtfiltered As DataTable = dt.Clone
                        Dim drs As DataRow()
                        drs = dt.Select("[" & cmbSearch.SelectedItem.Text & "] = '" & txtreferenceid.Text & "'")
                        For Each dr1 As DataRow In drs
                            dtfiltered.ImportRow(dr1)
                        Next
                        dt.Clear()
                        dt = dtfiltered

                    End If
                End If
                If dt.Rows.Count > 0 Then
                    Dim dtfiltered As DataTable = dt.Clone
                    Dim drs As DataRow()
                    If cmbOutcome.SelectedItem.Text = "All" Then
                        drs = dt.Select
                    ElseIf cmbOutcome.SelectedItem.Text = "None" Then
                        drs = dt.Select("[Out Come] is null")
                    Else
                        drs = dt.Select("[Out Come] = '" & Convert.ToString(cmbOutcome.SelectedItem.Text) & "'")
                    End If
                    For Each dr1 As DataRow In drs
                        dtfiltered.ImportRow(dr1)
                    Next
                    dt.Clear()
                    dt = dtfiltered
                End If


                Dim varColor As String = ""
                Dim URL As String = ""


            End If
        End If
    End Function

    Private Function GetData_Atrium() As Boolean
        Dim flagColumn As Boolean = False
        Dim varTMFView As String = ""

        dt = New DataTable

        conn = New SqlConnection(connCRM)
        cmd = New SqlCommand()
        cmd.Connection = conn
        cmd.CommandType = CommandType.Text
        cmd.CommandText = "SELECT [Btupload] FROM [tbl_AgentMaster] where [AgentID] ='" & AgentID & "'"
        conn.Open()
        m_ISTL = CBool(cmd.ExecuteScalar())
        cmd = Nothing
        conn.Close()

        conn = New SqlConnection(connCRM)
        cmd = New SqlCommand()
        cmd.Connection = conn
        cmd.CommandType = CommandType.Text
        cmd.CommandText = "SELECT [IsSupervisor] FROM [tbl_Data_UserRights] where [AgentID] ='" & AgentID & "' and CampaignID=" & CampaignID
        conn.Open()
        Dim TL As Boolean = CBool(cmd.ExecuteScalar())
        cmd = Nothing
        conn.Close()

        If TL Then
            ' === Modify on 26/05/10 ===
            If ReopenBased Then
                hlReopen.Visible = True
            Else
                hlReopen.Visible = False
            End If
            If HolidayBased Then
                hlHoliday.Visible = True
            Else
                hlHoliday.Visible = False
            End If
            btnAtriumStatusUpdate.Visible = True
            ' ===== END=====
        Else
            hlReopen.Visible = False
            hlHoliday.Visible = False
            btnAtriumStatusUpdate.Visible = False
        End If
        If LeadsBased Then
            conn = New SqlConnection(connLeads)
            cmd = New SqlCommand()

            If m_ISTL Then
                cmd.Parameters.AddWithValue("Agentid", "%")
                pnlAllocateAgents.Visible = True



            Else
                cmd.Parameters.AddWithValue("Agentid", AgentID)
                pnlAllocateAgents.Visible = False
                assign1.Visible = False
                assign.Visible = False
            End If


            cmd.Connection = conn
            cmd.CommandType = CommandType.StoredProcedure
            cmd.CommandText = "usp_Getleads" & CampaignID

            adp = New SqlDataAdapter(cmd)
            adp.Fill(dt)
            cmd = Nothing
            adp = Nothing

            If dt.Columns.Count > 0 Then
                If txtreferenceid.Text <> "" Then
                    If dt.Rows.Count > 0 Then
                        Dim dtfiltered As DataTable = dt.Clone
                        Dim drs As DataRow()
                        drs = dt.Select("[" & cmbSearch.SelectedItem.Text & "] = '" & txtreferenceid.Text & "'")
                        For Each dr1 As DataRow In drs
                            dtfiltered.ImportRow(dr1)
                        Next
                        dt.Clear()
                        dt = dtfiltered

                    End If
                End If
                If dt.Rows.Count > 0 Then
                    Dim dtfiltered As DataTable = dt.Clone
                    Dim drs As DataRow()
                    If cmbOutcome.SelectedItem.Text = "All" Then
                        drs = dt.Select
                    ElseIf cmbOutcome.SelectedItem.Text = "None" Then
                        drs = dt.Select("[Out Come] is null")
                    Else
                        drs = dt.Select("[Out Come] = '" & Convert.ToString(cmbOutcome.SelectedItem.Text) & "'")
                    End If
                    For Each dr1 As DataRow In drs
                        dtfiltered.ImportRow(dr1)
                    Next
                    dt.Clear()
                    dt = dtfiltered
                End If


                Dim varColor As String = ""
                Dim URL As String = ""


            End If
        End If
    End Function



    Private Sub getoutcomefilter()
        Dim dtoutcome As New DataTable
        conn = New SqlConnection(connCRM)
        cmd = New SqlCommand()

        cmd.Parameters.AddWithValue("CampaignID", CampaignID)
        cmd.Parameters.AddWithValue("isVerifier", IsVerifier)

        cmd.Connection = conn
        cmd.CommandType = CommandType.StoredProcedure
        cmd.CommandText = "usp_GetDispositions"

        adp = New SqlDataAdapter(cmd)
        adp.Fill(dtoutcome)
        cmd = Nothing
        adp = Nothing

        cmbOutcome.DataTextField = "Caption"
        cmbOutcome.DataSource = dtoutcome
        cmbOutcome.DataBind()
        cmbOutcome.Items.Insert(0, "All")
        cmbOutcome.Items.Insert(1, "None")

        dtoutcome = New DataTable
    End Sub

    Protected Sub getsearch()
        If dt.Columns.Count > 0 Then
            cmbSearch.Items.Clear()
            For Each col As DataColumn In dt.Columns
                cmbSearch.Items.Add(col.ColumnName)
            Next
        End If
    End Sub

    Private Sub fillProcess()
        Try
            Dim dtProcess As New DataTable
            conn = New SqlConnection(connCRM)
            cmd = New SqlCommand()
            ddlProcess.Items.Clear()
            cmd.Parameters.AddWithValue("Agentid", AgentID)
            cmd.Connection = conn
            cmd.CommandType = CommandType.StoredProcedure
            cmd.CommandText = "usp_GetPrimaryCampaigns"
            adp = New SqlDataAdapter(cmd)
            adp.Fill(dtProcess)
            cmd = Nothing
            adp = Nothing

            ddlProcess.DataTextField = "ProcessName"
            ddlProcess.DataValueField = "CampaignID"
            ddlProcess.DataSource = dtProcess
            ddlProcess.DataBind()
            If ddlProcess.Items.Count > 0 Then
                ddlProcess.SelectedIndex = 0
                fillAgents(ddlProcess.SelectedValue)
            End If
            dtProcess = Nothing
        Catch ex As Exception
            AlertMessage(ex.Message)
        End Try
    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        HumanMessage.Style.Item("visibility") = "hidden"
        CampaignID = Request.QueryString("CampaignID")
        AgentID = Request.QueryString("AgentID")
        AgentName = Request.QueryString("AgentName")
        IsVerifier = Convert.ToBoolean(Request.QueryString("IsVerifier"))

        Header1.AgentID = AgentID
        Header1.Agentname = AgentName
        IsLeadcomment = False
        ' MsgBox("TransID=" & TransID)

        If Not IsPostBack Then
            WorkingonTMF = False

            '@TransactionData_agentwise  20230714
            If CampaignID = "341" Then
                hypTransData.NavigateUrl = "TMPerformanceData_Datewise.aspx?CampaignID=" & CampaignID & "&AgentID=" & AgentID & "&AgentName=" & AgentName
            Else
                hypTransData.NavigateUrl = "TMPerformanceData.aspx?CampaignID=" & CampaignID & "&AgentID=" & AgentID & "&AgentName=" & AgentName
            End If

            ' hypTransData.NavigateUrl = "TMPerformanceData.aspx?CampaignID=" & 281 & "&AgentID=" & "NSS55812" & "&AgentName=" & "Ankit"

            'btsave.Attributes.Item("onclick") = "this.value=" & Chr(34) & "Processing..." & Chr(34) & ";this.disabled=true;" & ClientScript.GetPostBackEventReference(btsave, Nothing).ToString
            If Not IsAgentIn() Then
                Response.Redirect("~/Tracker/Login.aspx")
            End If
            AgentCurrentStatus()
            'If Session("Onbreak") = False Then
            If OnBreak = False Then
                LoadSetting()


                ' If it is quality transaction then SheetID,CMFID has been set in below Function.
                LatestTransaction()
                LatestPausedTransaction()
                If TransactionBased Then
                    btNewTransactionAssisted.Visible = True

                Else
                    btNewTransactionAssisted.Visible = False

                End If

                '@22-06-2022 Atrium changes
                If CampaignID = "159" Then
                    PanelDispostion.Visible = True
                    pnlSaveCmfList.Visible = True
                    btnAtriumStatusUpdate.Visible = True
                Else
                    PanelDispostion.Visible = True
                    pnlSaveCmfList.Visible = False
                    btnAtriumStatusUpdate.Visible = False

                End If
                If LeadsBased Then
                    getoutcomefilter()
                    fillProcess()




                    getsearch()
                    pnlshowlist.Visible = True
                    pnlshowtracker.Visible = False
                    ''-----------------------------
                    Showbreak.Visible = False
                    Panel1.Visible = True
                    pnlOutcome.Visible = True
                    pnlshowlist.Visible = True

                    pnlAssign.Visible = True
                    pnlfilter.Visible = True

                Else
                    Panel1.Visible = False
                    pnlfilter.visible = False
                    pnlOutcome.Visible = False
                    pnlshowlist.Visible = True

                    pnlAssign.Visible = False
                End If

                If WorkingonTMF = False Then  'rajkumar Aug'13  'for tracker
                    'if TransID is being received from getLatestTransaction() Function for non-disposed transaction, so open the Form for it.
                    If TransID <> Nothing And customerid <> Nothing Then

                        If Not Assisted Is Nothing Then
                            CreateForm(CampaignID, "PanelCRMData", customerid, Assisted)
                        ElseIf Not Amadeus Is Nothing Then
                            CreateForm(CampaignID, "PanelCRMData", customerid, Amadeus)

                        ElseIf Not InResort Is Nothing Then
                            CreateForm(CampaignID, "PanelCRMData", customerid, InResort)
                        ElseIf Not PostTravel Is Nothing Then
                            CreateForm(CampaignID, "PanelCRMData", customerid, PostTravel)
                        ElseIf Not MMB Is Nothing Then
                            CreateForm(CampaignID, "PanelCRMData", customerid, MMB)
                        ElseIf Not MMBDE Is Nothing Then
                            CreateForm(CampaignID, "PanelCRMData", customerid, MMBDE)

                        ElseIf Not MMBKustomer Is Nothing Then
                            CreateForm(CampaignID, "PanelCRMData", customerid, MMBKustomer)

                        ElseIf Not CSChat Is Nothing Then
                            CreateForm(CampaignID, "PanelCRMData", customerid, CSChat)
                        ElseIf Not CSVoice Is Nothing Then
                            CreateForm(CampaignID, "PanelCRMData", customerid, CSVoice)
                        ElseIf Not CreditControl Is Nothing Then
                            CreateForm(CampaignID, "PanelCRMData", customerid, CreditControl)
                        ElseIf Not SupplierRelocation Is Nothing Then
                            CreateForm(CampaignID, "PanelCRMData", customerid, SupplierRelocation)
                        ElseIf Not CustomerServiceInbox Is Nothing Then
                            CreateForm(CampaignID, "PanelCRMData", customerid, CustomerServiceInbox)
                        ElseIf Not AssistedRyanAir Is Nothing Then
                            CreateForm(CampaignID, "PanelCRMData", customerid, AssistedRyanAir)
                        ElseIf Not RefundTask Is Nothing Then
                            CreateForm(CampaignID, "PanelCRMData", customerid, RefundTask)
                        ElseIf Not OtherWorkType Is Nothing Then
                            CreateForm(CampaignID, "PanelCRMData", customerid, OtherWorkType)

                        Else
                            CreateForm(CampaignID, "PanelCRMData", customerid, m_strAssisted)
                        End If


                        ' CreateForm(CampaignID, "PanelCRMData", customerid, strAssisted)
                        changeControlsVisiblityAtFirstTime()
                        FillDispostions(CampaignID)
                        pnlshowtracker.Visible = True
                        '-------------------------------------------------
                        PanelCRMData.Visible = True
                        pnlComment.Visible = True
                        btbreak.Enabled = False
                        pnlCMFBody.Visible = False
                        '---------------------------------------------
                        pnlshowlist.Visible = False
                        Showbreak.Visible = False
                        btexit.Enabled = False
                        btAgentStat.Enabled = False
                        btNewTransactionAssisted.Enabled = False
                        btNewTransactionAmadeus.Enabled = False
                        btNewTransactionInResort.Enabled = False
                        btNewTransactionPostTravel.Enabled = False
                        btNewTransactionMMB.Enabled = False
                        btNewTransactionMMBKustomer.Enabled = False
                        btNewTransactionMMBDE.Enabled = False
                        btNewTransactionCSChat.Enabled = False
                        btNewTransactionCSVoice.Enabled = False
                        btnNewTransactionCreditControl.Enabled = False
                        btnNewTransactionSupplierrelocation.Enabled = False
                        btnNewTransactionCustomerServiceInbox.Enabled = False
                        btnNewTransactionAssistedRyanAir.Enabled = False
                        btnNewTransactionRefundTask.Enabled = False
                        btnNewTransactionOtherWorkType.Enabled = False


                        If Paused = 1 Then '------------- by Rajendra if last transaction was paused
                            RecoverPausedTransaction()
                        End If
                    End If
                Else ''WorkingonTMF is TRUE
                    If TransID <> Nothing And customerid <> Nothing Then
                        'CreateForm(CampaignID, "PanelCRMData", customerid)
                        'changeControlsVisiblityAtFirstTime()
                        FillDispostions(CampaignID)
                        pnlshowtracker.Visible = True   'chhh
                        '-------------------------------------------------
                        PanelCRMData.Visible = False
                        pnlComment.Visible = False
                        pnlCMFBody.Visible = True
                        '---------------------------------------------
                        pnlshowlist.Visible = False
                        Showbreak.Visible = False
                        btbreak.Enabled = False
                        btexit.Enabled = False
                        btAgentStat.Enabled = False
                        btNewTransactionAssisted.Enabled = False
                        btNewTransactionAmadeus.Enabled = False
                        btNewTransactionInResort.Enabled = False
                        btNewTransactionPostTravel.Enabled = False
                        btNewTransactionMMB.Enabled = False
                        btNewTransactionMMBKustomer.Enabled = False
                        btNewTransactionMMBDE.Enabled = False
                        btNewTransactionCSChat.Enabled = False
                        btNewTransactionCSVoice.Enabled = False
                        btnNewTransactionCreditControl.Enabled = False
                        btnNewTransactionSupplierrelocation.Enabled = False
                        btnNewTransactionCustomerServiceInbox.Enabled = False
                        btnNewTransactionAssistedRyanAir.Enabled = False
                        btnNewTransactionRefundTask.Enabled = False
                        btnNewTransactionOtherWorkType.Enabled = False

                        If Paused = 1 Then '------------- by Rajendra if last transaction was paused
                            RecoverPausedTransaction()
                        End If
                    End If   'of  TransID <> Nothing And customerid <> Nothing
                End If     'of ''WorkingonTMF
                'LatestPausedTransaction() '----- If Last Transaction was puased

            End If    'of    OnBreak = False   
            '----------------------------------------------------
            If WorkingonTMF = True Then
                If TransID <> Nothing And customerid <> Nothing Then
                    'fillCmfList function is being set in LatestTransaction for CMFID
                    'Check here for existing SheetID for that particular [ TransID-->CustomerID]  'rajkumar 11-sep-2013

                    fillCmfList()
                    If CMFID > 0 Then
                        ddlCMFList.SelectedValue = CMFID
                    End If

                    If SheetID = 0 Then ' New TMF
                        ddlCMFList.Enabled = True
                    ElseIf SheetID > 0 Then
                        ddlCMFList.Enabled = False
                    End If
                    Load_TMF()
                    If Paused = 1 Then '------------- by Rajendra if last transaction was paused
                        RecoverPausedTransaction()
                    End If
                End If
            End If
            '----------------------------------------------------

        Else            'of "NOT isPostBack"
            If WorkingonTMF = False Then  'rajkumar Aug'13   'for tracker
                If TransID <> 0 And customerid <> 0 Then
                    If Not Assisted Is Nothing Then
                        CreateForm(CampaignID, "PanelCRMData", customerid, Assisted)
                    ElseIf Not Amadeus Is Nothing Then
                        CreateForm(CampaignID, "PanelCRMData", customerid, Amadeus)
                    ElseIf Not InResort Is Nothing Then
                        CreateForm(CampaignID, "PanelCRMData", customerid, InResort)
                    ElseIf Not PostTravel Is Nothing Then
                        CreateForm(CampaignID, "PanelCRMData", customerid, PostTravel)
                    ElseIf Not MMB Is Nothing Then
                        CreateForm(CampaignID, "PanelCRMData", customerid, MMB)
                    ElseIf Not MMBDE Is Nothing Then
                        CreateForm(CampaignID, "PanelCRMData", customerid, MMBDE)
                    ElseIf Not MMBKustomer Is Nothing Then
                        CreateForm(CampaignID, "PanelCRMData", customerid, MMBKustomer)
                    ElseIf Not CSChat Is Nothing Then
                        CreateForm(CampaignID, "PanelCRMData", customerid, CSChat)
                    ElseIf Not CSVoice Is Nothing Then
                        CreateForm(CampaignID, "PanelCRMData", customerid, CSVoice)
                    ElseIf Not CreditControl Is Nothing Then
                        CreateForm(CampaignID, "PanelCRMData", customerid, CreditControl)
                    ElseIf Not SupplierRelocation Is Nothing Then
                        CreateForm(CampaignID, "PanelCRMData", customerid, SupplierRelocation)
                    ElseIf Not CustomerServiceInbox Is Nothing Then
                        CreateForm(CampaignID, "PanelCRMData", customerid, CustomerServiceInbox)

                    ElseIf Not AssistedRyanAir Is Nothing Then
                        CreateForm(CampaignID, "PanelCRMData", customerid, AssistedRyanAir)
                    ElseIf Not RefundTask Is Nothing Then
                        CreateForm(CampaignID, "PanelCRMData", customerid, RefundTask)

                    ElseIf Not OtherWorkType Is Nothing Then
                        CreateForm(CampaignID, "PanelCRMData", customerid, OtherWorkType)

                    Else

                        CreateForm(CampaignID, "PanelCRMData", customerid, m_strAssisted)
                    End If


                    '''''' CreateForm(CampaignID, "PanelCRMData", customerid, strAssisted)

                    'FillDispostions(CampaignID)  'No Need here in  isPostBack=True
                    btcancel.PostBackUrl = "~/Tracker/deletetransaction.aspx?CampaignID=" & CampaignID & "&AgentId=" & AgentID & "&AgentName=" & AgentName & "&IsVerifier=" & IsVerifier & "&TransId=" & TransID & "&CustomerId=" & customerid & "&DailStateBased=" & DailStateBased
                    pnlshowtracker.Visible = True
                    '-------------------------------------------------
                    PanelCRMData.Visible = True
                    pnlComment.Visible = True
                    pnlCMFBody.Visible = False
                    '---------------------------------------------
                    pnlshowlist.Visible = False
                    Showbreak.Visible = False
                    btbreak.Enabled = False
                    btexit.Enabled = False
                    btAgentStat.Enabled = False
                    btNewTransactionAssisted.Enabled = False
                    btNewTransactionAmadeus.Enabled = False
                    btNewTransactionInResort.Enabled = False
                    btNewTransactionPostTravel.Enabled = False
                    btNewTransactionMMB.Enabled = False
                    btNewTransactionMMBKustomer.Enabled = False
                    btNewTransactionMMBDE.Enabled = False
                    btNewTransactionCSChat.Enabled = False
                    btNewTransactionCSVoice.Enabled = False
                    btnNewTransactionCreditControl.Enabled = False
                    btnNewTransactionSupplierrelocation.Enabled = False
                    btnNewTransactionCustomerServiceInbox.Enabled = False
                    btnNewTransactionAssistedRyanAir.Enabled = False
                    btnNewTransactionRefundTask.Enabled = False
                    btnNewTransactionOtherWorkType.Enabled = False


                    If Paused = 1 Then '------------- by Rajendra if last transaction was paused
                        RecoverPausedTransaction()
                    End If
                End If



            End If      'of workingonTMF

            '----------------------------------------------------
        End If     'of NOT isPostBack   closed



        If OnBreak = True Then
            Showbreak.Visible = True
            btbreak.Text = "End Break"
            btbreak.ToolTip = "End Break"
            btbreak.Enabled = True
            btexit.Enabled = False
            Showbreak.Visible = True
            pnlshowlist.Visible = False
            btexit.Enabled = False
            pnlshowtracker.Visible = False

            ''----------------------------------a little change
            'PanelCRMData.Visible = False
            'pnlComment.Visible = False
            'pnlCMFBody.Visible = False
            ''-----------------------------------

            btNewTransactionAssisted.Enabled = False
            btNewTransactionAmadeus.Enabled = False
            btNewTransactionInResort.Enabled = False
            btNewTransactionPostTravel.Enabled = False
            btNewTransactionMMB.Enabled = False
            btNewTransactionMMBKustomer.Enabled = False
            btNewTransactionMMBDE.Enabled = False
            btNewTransactionCSChat.Enabled = False
            btNewTransactionCSVoice.Enabled = False
            btnNewTransactionCreditControl.Enabled = False
            btnNewTransactionSupplierrelocation.Enabled = False
            btnNewTransactionCustomerServiceInbox.Enabled = False
            btnNewTransactionAssistedRyanAir.Enabled = False
            btnNewTransactionRefundTask.Enabled = False
            btnNewTransactionOtherWorkType.Enabled = False


        ElseIf btbreak.Enabled = False Then
            btbreak.Enabled = False
            btexit.Enabled = False
        Else

            If Paused = 1 Then '------------- by Rajendra if last transaction was paused
                RecoverPausedTransaction()
            Else
                Showbreak.Visible = False
                btbreak.Text = "Take Break"
                btbreak.ToolTip = "Take Break"
                btbreak.Enabled = True
                btexit.Enabled = True
                btAgentStat.Enabled = True
                btNewTransactionAssisted.Enabled = True
                btNewTransactionAmadeus.Enabled = True
                btNewTransactionInResort.Enabled = True
                btNewTransactionPostTravel.Enabled = True
                btNewTransactionMMB.Enabled = True
                btNewTransactionMMBKustomer.Enabled = True
                btNewTransactionMMBDE.Enabled = True
                btNewTransactionCSChat.Enabled = True
                btNewTransactionCSVoice.Enabled = True
                btnNewTransactionCreditControl.Enabled = True
                btnNewTransactionSupplierrelocation.Enabled = True
                btnNewTransactionCustomerServiceInbox.Enabled = True
                btnNewTransactionAssistedRyanAir.Enabled = True
                btnNewTransactionRefundTask.Enabled = True
                btnNewTransactionOtherWorkType.Enabled = True

            End If

        End If




    End Sub

#End Region

    Dim StartBreakTime As DateTime
    Private m_StartTime As DateTime
    Dim pauseSec As Integer = 0
    Public Property StartTime() As DateTime
        Get
            Return m_StartTime
        End Get
        Set(ByVal value As DateTime)
            m_StartTime = value
        End Set
    End Property

#Region "--- Support Functions ---"
    Public Sub fillAgents(ByVal primaryCampID As Integer)
        Try
            Dim dtCampID As New DataTable
            ddlAgents.Items.Clear()

            conn = New SqlConnection(connCRM)
            cmd = New SqlCommand()
            cmd.Parameters.AddWithValue("Campaignid", primaryCampID)
            cmd.Connection = conn
            cmd.CommandType = CommandType.StoredProcedure
            cmd.CommandText = "usp_GetAgentsOfTheProcess"

            adp = New SqlDataAdapter(cmd)
            adp.Fill(dtCampID)
            cmd = Nothing
            adp = Nothing
            ddlAgents.DataSource = dtCampID
            ddlAgents.DataTextField = "agent name"
            ddlAgents.DataValueField = "AgentId"
            ddlAgents.DataBind()

            dtCampID = Nothing
        Catch ex As Exception
            AlertMessage(ex.Message)
        Finally

        End Try
    End Sub
    Private Sub FillDispostions(ByVal CampaignID As Integer)
        Try
            Dim dtDisposition As New DataTable

            conn = New SqlConnection(connCRM)
            cmd = New SqlCommand()

            cmd.Parameters.AddWithValue("CampaignID", CampaignID)
            cmd.Parameters.AddWithValue("isVerifier", IsVerifier)

            cmd.Connection = conn
            cmd.CommandType = CommandType.StoredProcedure
            cmd.CommandText = "usp_GetDispositions"

            adp = New SqlDataAdapter(cmd)
            adp.Fill(dtDisposition)
            cmd = Nothing
            adp = Nothing

            ddlDisposition.DataTextField = "Caption"
            ddlDisposition.DataValueField = "Code"
            ddlDisposition.DataSource = dtDisposition
            ddlDisposition.DataBind()
            dtDisposition = Nothing
            btcancel.PostBackUrl = "~/Tracker/deletetransaction.aspx?CampaignID=" & CampaignID & "&AgentId=" & AgentID & "&AgentName=" & AgentName & "&IsVerifier=" & IsVerifier & "&TransId=" & TransID & "&CustomerId=" & customerid & "&DailStateBased=" & DailStateBased
        Catch ex As Exception
            AlertMessage(ex.Message)
        End Try
    End Sub
    Protected Sub insertTransaction()
        conn = New SqlConnection(connCRM)
        cmd = New SqlCommand()

        cmd.Parameters.AddWithValue("lid", customerid)
        cmd.Parameters.AddWithValue("AgentID", AgentID)
        cmd.Parameters.AddWithValue("DialedNumber", "")
        cmd.Parameters.AddWithValue("CampaignID", CampaignID)
        cmd.Parameters.AddWithValue("CallTable", "")

        cmd.Connection = conn
        cmd.CommandType = CommandType.StoredProcedure
        cmd.CommandText = "usp_InsertTransaction"

        conn.Open()
        TransID = CInt(cmd.ExecuteScalar())
        conn.Close()
        cmd = Nothing
    End Sub

    Protected Sub insertTransactionQuality()
        '------------------------------------------------For Execute scalar ---for usp
        conn = New SqlConnection(connCRM)
        cmd = New SqlCommand()
        cmd.Connection = conn

        cmd.Parameters.AddWithValue("lid", customerid)
        'cmd.Parameters.AddWithValue("QAAgentId", IIf(UserID Is Nothing, Session("AgentID"), UserID))
        cmd.Parameters.AddWithValue("QAAgentId", IIf(UserID Is Nothing, AgentID, UserID)) '========= By Rajendra 25th Sep'13
        cmd.Parameters.AddWithValue("DialedNumber", "")
        cmd.Parameters.AddWithValue("CampaignID", CampaignID)
        cmd.Parameters.AddWithValue("CallTable", "")

        cmd.CommandType = CommandType.StoredProcedure
        cmd.CommandText = "usp_InsertTransaction_Quality"
        conn.Open()
        TransID = CInt(cmd.ExecuteScalar())
        cmd = Nothing
        conn.Close()
        '-----------------------------------------------
    End Sub
    Private dtResponses As New DataTable
#Region "changedControlVisibiliity-Dynamically"

    'Private Sub CreateDropDownList(ByVal pQuestid As String, ByVal pAnsID As String, pAnsDesc As String)
    '    Dim dropDown As DropDownList = New DropDownList()
    '    dropDown.ID = pQuestid & "-" & pAnsID
    '    ' dropDown.Text = pAnsDesc

    '    Using conn = New SqlConnection(connCRM)
    '        Using cmd As SqlCommand = New SqlCommand("SELECT QuestID, AnsID , QuestID & " - " & AnsID  As QuestAnsID FROM [tbl_Config_QuestLogics3] where PQuestID = " & pQuestid & " and PAnsID =" & pAnsID & "")
    '            cmd.Connection = conn
    '            conn.Open()
    '            dropDown.DataSource = cmd.ExecuteReader()
    '            dropDown.DataTextField = "AnsID"
    '            dropDown.DataValueField = "QuestAnsID"
    '            dropDown.DataBind()
    '            conn.Close()
    '        End Using
    '    End Using

    '    pnlDropDownLists.Controls.Add(dropDown)
    '    'Dim lt As Literal = New Literal()
    '    'lt.Text = "<br />"
    '    'pnlDropDownLists.Controls.Add(lt)
    'End Sub

    Private Function FillControlsVisiblity(ByVal CurrentQuestId As Integer, ByVal CurrentAnsDesc As String, ByVal CurrentQuestSequence As Decimal, ByVal CurrentAnsId As Integer) As DataTable
        'Loop through controls and make them visible or not
        'CreateDropDownList(CurrentQuestId, CurrentAnsId, CurrentAnsDesc)
        Dim dtmandatoryQuest As New DataTable
        Dim iCtr As Integer

        conn = New SqlConnection(connCRM)
        cmd = New SqlCommand()

        cmd.Parameters.AddWithValue("campaignid", CampaignID)

        cmd.Connection = conn
        cmd.CommandType = CommandType.StoredProcedure
        cmd.CommandText = "usp_getmandatoryquest"

        adp = New SqlDataAdapter(cmd)
        adp.Fill(dtmandatoryQuest)
        cmd = Nothing
        adp = Nothing

        Dim dtFilteredQuest As New DataTable
        Dim iCtrFilter As Integer
        conn = New SqlConnection(connCRM)
        cmd = New SqlCommand()

        cmd.Parameters.AddWithValue("campaignid", CampaignID)
        cmd.Parameters.AddWithValue("PQuestID", CurrentQuestId)
        cmd.Parameters.AddWithValue("PansID", CurrentAnsId)
        cmd.Connection = conn
        cmd.CommandType = CommandType.StoredProcedure
        cmd.CommandText = "usp_getmandatoryquest3"

        adp = New SqlDataAdapter(cmd)
        adp.Fill(dtFilteredQuest)
        cmd = Nothing
        adp = Nothing

        Dim dtcombodata As New DataTable

        conn = New SqlConnection(connCRM)
        cmd = New SqlCommand()
        cmd.Parameters.AddWithValue("campaignid", CampaignID)
        cmd.Connection = conn
        cmd.CommandType = CommandType.StoredProcedure
        cmd.CommandText = "usp_getcombodata"
        adp = New SqlDataAdapter(cmd)
        adp.Fill(dtcombodata)
        cmd = Nothing
        adp = Nothing
        Dim dtans As DataTable



        If Not dtmandatoryQuest Is Nothing Then
            For iCtr = 0 To dtmandatoryQuest.Rows.Count - 1

                Select Case dtmandatoryQuest.Rows(iCtr).Item("inputType")
                    Case 211


                        dtans = New DataTable()
                        dtans.Columns.Add("caption")
                        dtans.Columns.Add("value")
                        Dim dr As DataRow


                        If Not dtFilteredQuest Is Nothing Then



                            For iCtrFilter = 0 To dtFilteredQuest.Rows.Count - 1

                                Dim ans As DataTable
                                ans = dtcombodata.Select("Questid=" & dtFilteredQuest.Rows(iCtrFilter).Item("questid") & " and value =" & dtFilteredQuest.Rows(iCtrFilter).Item("Ansid")).CopyToDataTable


                                dr = dtans.NewRow
                                dr("caption") = ans.Rows(0)(1).ToString()
                                dr("value") = ans.Rows(0)(2).ToString()
                                dtans.Rows.Add(dr)


                            Next

                        End If


                End Select
            Next

        End If


        dtFilteredQuest = Nothing
        dtmandatoryQuest = Nothing
        conn = Nothing
        Return dtans
    End Function

    Private Sub ChangeControlsVisiblity3(ByVal CurrentQuestId As Integer, ByVal CurrentAnsDesc As String, ByVal CurrentQuestSequence As Decimal, ByVal CurrentAnsId As Integer)
        'Loop through controls and make them visible or not
        'CreateDropDownList(CurrentQuestId, CurrentAnsId, CurrentAnsDesc)

        Dim objTable As Table
        Dim objTablerow As TableRow
        Dim objTableCol As TableCell
        Dim objLabel As Label
        Dim objDropdown As DropDownList


        Dim dtmandatoryQuest As New DataTable
        Dim iCtr As Integer

        conn = New SqlConnection(connCRM)
        cmd = New SqlCommand()

        cmd.Parameters.AddWithValue("campaignid", CampaignID)

        cmd.Connection = conn
        cmd.CommandType = CommandType.StoredProcedure
        cmd.CommandText = "usp_getmandatoryquest"

        adp = New SqlDataAdapter(cmd)
        adp.Fill(dtmandatoryQuest)
        cmd = Nothing
        adp = Nothing

        Dim dtFilteredQuest As New DataTable
        Dim iCtrFilter As Integer
        conn = New SqlConnection(connCRM)
        cmd = New SqlCommand()

        cmd.Parameters.AddWithValue("campaignid", CampaignID)
        cmd.Parameters.AddWithValue("PQuestID", CurrentQuestId)
        cmd.Parameters.AddWithValue("PansID", CurrentAnsId)
        cmd.Connection = conn
        cmd.CommandType = CommandType.StoredProcedure
        cmd.CommandText = "usp_getmandatoryquest3"

        adp = New SqlDataAdapter(cmd)
        adp.Fill(dtFilteredQuest)
        cmd = Nothing
        adp = Nothing

        Dim dtcombodata As New DataTable

        conn = New SqlConnection(connCRM)
        cmd = New SqlCommand()
        cmd.Parameters.AddWithValue("campaignid", CampaignID)
        cmd.Connection = conn
        cmd.CommandType = CommandType.StoredProcedure
        cmd.CommandText = "usp_getcombodata"
        adp = New SqlDataAdapter(cmd)
        adp.Fill(dtcombodata)
        cmd = Nothing
        adp = Nothing




        If Not dtmandatoryQuest Is Nothing Then
            For iCtr = 0 To dtmandatoryQuest.Rows.Count - 1

                Select Case dtmandatoryQuest.Rows(iCtr).Item("inputType")
                    Case 211

                        objTable = New Table
                        objTable.ID = "dynamic2"
                        objTable.Width = System.Web.UI.WebControls.Unit.Percentage(100)
                        objTable.CellSpacing = 0
                        objTable.HorizontalAlign = HorizontalAlign.Center
                        objTable.EnableViewState = True

                        objTablerow = New TableRow
                        objTablerow.ID = "TblRow1" & dtmandatoryQuest.Rows(iCtr).Item("Questid")
                        'objTablerow.BackColor = Color.LightGray
                        objTable.Rows.Add(objTablerow)
                        objTablerow.EnableViewState = True
                        objTableCol = New TableCell
                        objTablerow.Cells.Add(objTableCol)
                        objTableCol.EnableViewState = True
                        objTableCol.BackColor = System.Drawing.Color.Transparent
                        objTableCol.VerticalAlign = VerticalAlign.Top
                        objTableCol.HorizontalAlign = HorizontalAlign.Left
                        objTableCol.Width = System.Web.UI.WebControls.Unit.Percentage(40)
                        objTableCol.Attributes.Add("style", "border-bottom: solid 1px #bbd9ee")
                        objLabel = New Label
                        objTableCol.Controls.Add(objLabel)
                        objLabel.Text = dtmandatoryQuest.Rows(iCtr).Item("quest_dataheading")
                        objLabel.EnableViewState = True
                        objTableCol = New TableCell
                        objTablerow.Cells.Add(objTableCol)

                        objTableCol.BackColor = System.Drawing.Color.Transparent
                        objTableCol.VerticalAlign = VerticalAlign.Top
                        objTableCol.HorizontalAlign = HorizontalAlign.Left
                        objTableCol.Width = System.Web.UI.WebControls.Unit.Percentage(55)
                        objTableCol.Attributes.Add("style", "border-bottom: solid 1px #bbd9ee")
                        objTableCol.EnableViewState = True

                        Dim dtans As New DataTable
                        dtans.Columns.Add("caption")
                        dtans.Columns.Add("value")
                        Dim dr As DataRow


                        If Not dtFilteredQuest Is Nothing Then

                            objDropdown = New DropDownList

                            For iCtrFilter = 0 To dtFilteredQuest.Rows.Count - 1


                                objDropdown.Height = System.Web.UI.WebControls.Unit.Pixel(20)
                                objDropdown.Width = System.Web.UI.WebControls.Unit.Percentage(100)
                                objDropdown.Font.Size = System.Web.UI.WebControls.FontUnit.Smaller
                                objDropdown.ID = dtFilteredQuest.Rows(iCtrFilter).Item("id") & dtFilteredQuest.Rows(iCtrFilter).Item("Questid") & dtFilteredQuest.Rows(iCtrFilter).Item("Ansid")
                                objDropdown.EnableViewState = True
                                'objDropdown.AutoPostBack = True



                                Dim ans As DataTable
                                ans = dtcombodata.Select("Questid=" & dtFilteredQuest.Rows(iCtrFilter).Item("questid") & " and value =" & dtFilteredQuest.Rows(iCtrFilter).Item("Ansid")).CopyToDataTable


                                dr = dtans.NewRow
                                dr("caption") = ans.Rows(0)(1).ToString()
                                dr("value") = ans.Rows(0)(2).ToString()
                                dtans.Rows.Add(dr)





                                If Not dtcombodata Is Nothing Then
                                    objDropdown.DataSource = dtans
                                    objDropdown.DataTextField = "caption"
                                    objDropdown.DataValueField = "value"
                                    objDropdown.DataBind()
                                End If
                                objDropdown.Attributes.Add("Sequence", dtFilteredQuest.Rows(iCtrFilter).Item("Sequence"))
                                objDropdown.Attributes.Add("DisplayCriteria", dtFilteredQuest.Rows(iCtrFilter).Item("DisplayCriteria"))
                                objDropdown.AutoPostBack = True
                                objDropdown.Visible = True
                                ' AddHandler objDropdown.SelectedIndexChanged, AddressOf DropDownSelectionChange2


                                'If dtFilteredQuest.Rows(iCtrFilter).Item("Sequence") = 1 Then
                                '    FirstSelectedAnsID = dtFilteredQuest.Rows(iCtrFilter).Item("Ansid")
                                'End If
                                'If dtFilteredQuest.Rows(iCtrFilter).Item("Sequence") = 2 Then
                                '    SecondSelectedAnsID = dtFilteredQuest.Rows(iCtrFilter).Item("Ansid")

                                'End If






                            Next

                            objTableCol.Controls.Add(objDropdown)
                            pnlDropDownLists.Controls.Add(objTable)
                            pnlDropDownLists.Enabled = True
                            pnlDropDownLists.EnableViewState = True


                        End If



                End Select
            Next
        End If

        dtFilteredQuest = Nothing
        dtmandatoryQuest = Nothing
        conn = Nothing
    End Sub


    Private Sub ChangeControlsVisiblity2(ByVal currentQuestsequence As Decimal, ByVal currentQuestID As Integer, ByVal currentansid As Integer)
        Dim ctrlmorecontrol As Object
        Dim ansLogic, ansLogic1, anslogic2 As String
        Dim Num As Int16
        For ctr As Integer = 0 To PanelCRMData.Controls.Count - 1
            ctrlmorecontrol = PanelCRMData.Controls(ctr)
            If ctrlmorecontrol.sequence > currentQuestsequence Then
                If ctrlmorecontrol.GetType.Name.Contains("NSSDropDown") Then
                    Dim dtComboDataSEI, dtComboDataSEI1 As New DataTable
                    Dim dtcombodata1 As New DataTable
                    dtcombodata1 = dtComboData.Clone
                    dtComboDataSEI1 = dtComboData.Clone
                    dtComboDataSEI = dtComboData.Clone

                    Dim db As New DBAccess
                    Dim dtlogicrow() As DataRow = dtanslogic.Select("questid='" & ctrlmorecontrol.QuestionID & "'")
                    If dtlogicrow.Length > 0 Then
                        For Each row As DataRow In dtlogicrow
                            ansLogic = IIf(IsDBNull(row.Item("Anscriteria")), "", row.Item("Anscriteria"))
                            anslogic2 = ansLogic
                            Num = (ansLogic.Length - ansLogic.Replace(")  AND  (", "").Length) / ")  AND  (".Length
                            ansLogic = ansLogic.Replace(")  AND  (", ")  OR  (")
                            ansLogic1 = ansLogic.Replace("parentquestid", "Questid")
                            ansLogic1 = ansLogic1.Replace("parentansid", "Ansid")
                            Dim viewresponse As DataView = New DataView(dtResponses)
                            viewresponse.RowFilter = ansLogic1

                            If viewresponse.Count > 0 Then
                                If viewresponse.Count > Num Then
                                    Dim dtrow As DataRow = dtComboDataSEI.NewRow
                                    dtrow("QuestID") = row.Item("Questid")
                                    dtrow("caption") = row.Item("caption")
                                    dtrow("value") = row.Item("Ansid")
                                    dtComboDataSEI.Rows.Add(dtrow)
                                End If
                            Else
                            End If
                        Next
                        db = New DBAccess
                        db.slDataAdd("CampaignID", CampaignID.ToString)
                        db.slDataAdd("QuestionID", ctrlmorecontrol.QuestionID.ToString)
                        dtComboDataSEI1 = db.ReturnTable("usp_GetQuestAnsMap", "", True)
                        db = Nothing
                        For Each rowans As DataRow In dtComboDataSEI1.Rows
                            dtComboDataSEI.ImportRow(rowans)
                        Next
                        If Not dtComboDataSEI Is Nothing Then
                            Dim bindmanager As System.Windows.Forms.BindingSource
                            bindmanager = New System.Windows.Forms.BindingSource
                            bindmanager.DataSource = dtComboDataSEI.Copy
                            ctrlmorecontrol.Combo.ValueMember = dtComboDataSEI.Columns(2).ColumnName
                            ctrlmorecontrol.Combo.DisplayMember = dtComboDataSEI.Columns(1).ColumnName
                            ctrlmorecontrol.Datasource = bindmanager
                        End If
                    End If
                Else
                End If
            End If
        Next
    End Sub
#End Region
    Private Sub ChangeControlsVisiblity(ByVal CurrentQuestId As Integer, ByVal CurrentAnsDesc As String, ByVal CurrentQuestSequence As Decimal, ByVal CurrentAnsId As Integer)
        'Loop through controls and make them visible or not

        Dim dtmandatoryQuest As New DataTable
        Dim iCtr As Integer
        Dim questID As String

        conn = New SqlConnection(connCRM)
        cmd = New SqlCommand()

        cmd.Parameters.AddWithValue("campaignid", CampaignID)

        cmd.Connection = conn
        cmd.CommandType = CommandType.StoredProcedure
        cmd.CommandText = "usp_getmandatoryquest"

        adp = New SqlDataAdapter(cmd)
        adp.Fill(dtmandatoryQuest)
        cmd = Nothing
        adp = Nothing
        Dim DisplayLogic As String
        Dim totalheight As Integer = 0
        Dim ctrlmorecontrol As Object
        Dim dtResponses As New DataTable
        dtResponses.Columns.Add("QuestID")
        dtResponses.Columns.Add("AnsID")
        dtResponses.Columns.Add("AnsText")
        Dim dr As DataRow
        dr = dtResponses.NewRow
        dr("QuestID") = CurrentQuestId
        dr("AnsID") = CurrentAnsId
        dr("AnsText") = CurrentAnsDesc
        dtResponses.Rows.Add(dr)
        For iCtr = 0 To dtmandatoryQuest.Rows.Count - 1
            questID = ""
            questID = dtmandatoryQuest.Rows(iCtr).Item("questid").ToString()
            If Not PanelCRMData.FindControl(questID) Is Nothing Then
                If PanelCRMData.FindControl(questID).ID Then
                    ctrlmorecontrol = PanelCRMData.FindControl(questID)
                    If ctrlmorecontrol.Attributes("Sequence") > CurrentQuestSequence Then
                        If dtmandatoryQuest.Rows(iCtr).Item("InputType") = 2 Then
                            Dim dr1 As DataRow
                            dr1 = dtResponses.NewRow
                            dr1("QuestID") = dtmandatoryQuest.Rows(iCtr).Item("questid")
                            dr1("AnsID") = CType(PanelCRMData.FindControl(questID), DropDownList).SelectedItem.Value
                            dr1("AnsText") = CType(PanelCRMData.FindControl(questID), DropDownList).SelectedItem.Text
                            dtResponses.Rows.Add(dr1)
                        End If
                        DisplayLogic = ctrlmorecontrol.Attributes("DisplayCriteria")
                        If DisplayLogic.Trim = "" Then
                            CType(PanelCRMData.FindControl("TblRow" & ctrlmorecontrol.ID), TableRow).Visible = True
                            ctrlmorecontrol.Visible = True
                        Else
                            Dim dr1() As DataRow = dtResponses.Select(DisplayLogic)
                            If (dr1.Length <> 0) Then
                                CType(PanelCRMData.FindControl("TblRow" & ctrlmorecontrol.ID), TableRow).Visible = True
                                ctrlmorecontrol.Visible = True
                            Else
                                CType(PanelCRMData.FindControl("TblRow" & ctrlmorecontrol.ID), TableRow).Visible = False
                                ctrlmorecontrol.Visible = False
                            End If




                        End If
                    End If
                    ctrlmorecontrol = Nothing
                End If
            End If
        Next
        dtmandatoryQuest = Nothing
    End Sub
    Private Sub changeControlsVisiblityAtFirstTime()
        Dim dtMandatory As New DataTable
        Dim dtTemp As DataTable

        Dim iCtr As Integer
        conn = New SqlConnection(connCRM)
        cmd = New SqlCommand()
        cmd.Parameters.AddWithValue("campaignid", CampaignID)
        cmd.Connection = conn
        cmd.CommandType = CommandType.StoredProcedure
        cmd.CommandText = "usp_getmandatoryquest"
        adp = New SqlDataAdapter(cmd)
        adp.Fill(dtMandatory)
        cmd = Nothing
        adp = Nothing
        Dim dtWorktype As New DataTable
        dtWorktype.Columns.Add("QuestID")
        dtWorktype.Columns.Add("AnsID")
        dtWorktype.Columns.Add("AnsText")
        dtWorktype.Columns.Add("QuestSeq")
        For iCtr = 0 To dtMandatory.Rows.Count - 1
            If dtMandatory.Rows(iCtr).Item("inputType") = 11 Then
                dtTemp = New DataTable
                conn = New SqlConnection(connCRM)
                cmd = New SqlCommand()
                cmd.Connection = conn
                cmd.CommandType = CommandType.Text
                cmd.CommandText = "SELECT top 1 A.Questid,A.Sequence,B.AnsID,C.Description FROM tbl_Config_Questions A INNER JOIN tbl_Config_QuestAnsMaps B ON A.QuestID = B.QuestID INNER JOIN tbl_Config_Answers C ON B.AnsID=C.AnsID WHERE A.CampaignID=" & CampaignID & " AND A.Questid ='" & dtMandatory.Rows(iCtr).Item("questid") & "' order by B.Sequence "
                adp = New SqlDataAdapter(cmd)
                adp.Fill(dtTemp)
                cmd = Nothing
                adp = Nothing

                Dim drwork As DataRow = dtTemp.Rows(0)
                Dim dr As DataRow
                dr = dtWorktype.NewRow
                dr("QuestID") = drwork("Questid")
                dr("AnsID") = drwork("AnsID")
                dr("AnsText") = drwork("Description")
                dr("QuestSeq") = drwork("Sequence")
                dtWorktype.Rows.Add(dr)
                dtTemp = Nothing
            End If
        Next
        For Each drr As DataRow In dtWorktype.Rows
            '@orig
            ChangeControlsVisiblity(drr("QuestID"), drr("AnsText"), drr("QuestSeq"), drr("AnsID"))

            '' ''@2022-01-01
            ' ''If CampaignID = "371" Then 'R1-371 LH-341 coxoid-362
            ' ''    ChangeControlsVisiblity3(drr("QuestID"), drr("AnsText"), drr("QuestSeq"), drr("AnsID"))

            ' ''Else
            ' ''    ChangeControlsVisiblity(drr("QuestID"), drr("AnsText"), drr("QuestSeq"), drr("AnsID"))
            ' ''End If

        Next
        dtMandatory = Nothing
    End Sub
    Private Sub SetValueInControls(ByVal dtVal As DataTable, ByVal dtCustomerID As DataTable)
        Dim Value As String
        Dim questID As String
        Dim numericValue As Integer
        Try
            For iCtr = 0 To dtVal.Rows.Count - 1
                questID = ""
                questID = dtVal.Rows(iCtr).Item("questid").ToString()
                If dtCustomerID.Columns.Contains("Ques" & questID) Then
                    Value = ""
                    Value = dtCustomerID.Rows(0).Item("Ques" & questID).ToString()
                    If Not PanelCRMData.FindControl(questID) Is Nothing Then
                        If PanelCRMData.FindControl(questID).ID Then
                            If dtVal.Rows(iCtr).Item("inputType") = 0 Then 'For Label 
                                CType(PanelCRMData.FindControl(questID), TextBox).Text = Value
                                '@ark 20210220

                            ElseIf dtVal.Rows(iCtr).Item("inputType") = 22 Then 'For Label  UK DateTime Field
                                Dim dt As DateTime
                                dt = TimeZoneInfo.ConvertTimeBySystemTimeZoneId(DateTime.UtcNow, "GMT Standard Time")
                                ' CType(PanelCRMData.FindControl(questID), TextBox).Text = DateTime.Now.ToString("dd-MMM-yyyy HH:mm")
                                CType(PanelCRMData.FindControl(questID), TextBox).Text = dt.ToString("dd-MMM-yyyy HH:mm")

                            ElseIf dtVal.Rows(iCtr).Item("inputType") = 23 Then 'For Label  IST DateTime Field
                                CType(PanelCRMData.FindControl(questID), TextBox).Text = DateTime.Now.ToString("dd-MMM-yyyy HH:mm")

                            ElseIf dtVal.Rows(iCtr).Item("inputType") = 25 Then 'For Label  EST DateTime Field
                                Dim dt As DateTime
                                dt = TimeZoneInfo.ConvertTimeBySystemTimeZoneId(DateTime.UtcNow, "Eastern Standard Time")
                                ' CType(PanelCRMData.FindControl(questID), TextBox).Text = DateTime.Now.ToString("dd-MMM-yyyy HH:mm")
                                CType(PanelCRMData.FindControl(questID), TextBox).Text = dt.ToString("dd-MMM-yyyy HH:mm")


                            ElseIf dtVal.Rows(iCtr).Item("inputType") = 25 Then 'For Label  EST DateTime Field
                                CType(PanelCRMData.FindControl(questID), TextBox).Text = DateTime.Now.ToString("dd-MMM-yyyy HH:mm")



                            ElseIf dtVal.Rows(iCtr).Item("inputType") = 1 Then 'For Text Box
                                CType(PanelCRMData.FindControl(questID), TextBox).Text = Value

                                '@20230831
                            ElseIf dtVal.Rows(iCtr).Item("inputType") = 111 Then 'For Text Box
                                CType(PanelCRMData.FindControl(questID), TextBox).Text = Value

                                '@20220516
                            ElseIf dtVal.Rows(iCtr).Item("inputType") = 24 Then 'For Money Text Box


                                If CType(PanelCRMData.FindControl(questID), TextBox).Text.Length = 3 Or 6 Or 9 Or 12 Or 15 Or 18 Or 21 Then
                                    CType(PanelCRMData.FindControl(questID), TextBox).Text &= "," & Value
                                End If
                                'CType(PanelCRMData.FindControl(questID), TextBox).Text = Value


                            ElseIf dtVal.Rows(iCtr).Item("inputType") = 8 Then 'For Text Box
                                CType(PanelCRMData.FindControl(questID), TextBox).Text = Value
                            ElseIf dtVal.Rows(iCtr).Item("inputType") = 12 Then 'For Text Box
                                Dim a As Object
                                a = CType(PanelCRMData.FindControl(questID), UserControl)
                                'Page.LoadControl("~/_assets/usrcontrol/DateTimePicker.ascx")
                                If Value <> "" Then
                                    'a.Text = Value
                                    a.value = Value

                                    'Else
                                    '    a.value = a.value & DateTime.Now.Hour
                                End If


                            ElseIf dtVal.Rows(iCtr).Item("inputType") = 2 Then 'For Drop Down
                                numericValue = 0
                                conn = New SqlConnection(connCRM)
                                cmd = New SqlCommand()
                                cmd.Connection = conn
                                cmd.CommandType = CommandType.Text
                                cmd.CommandText = "SELECT B.AnsID,C.Description FROM tbl_Config_Questions A INNER JOIN tbl_Config_QuestAnsMaps B ON A.QuestID = B.QuestID INNER JOIN tbl_Config_Answers C ON B.AnsID=C.AnsID WHERE A.CampaignID=" & CampaignID & " AND C.Description='" & Value & "' AND A.Questid='" & questID & "'"
                                conn.Open()
                                numericValue = CInt(cmd.ExecuteScalar())
                                conn.Close()
                                cmd = Nothing
                                If numericValue <> 0 Then
                                    CType(PanelCRMData.FindControl(questID), DropDownList).SelectedValue = numericValue  'numericValue


                                End If
                            ElseIf dtVal.Rows(iCtr).Item("inputType") = 11 Then 'For WorkDown Drop Down
                                numericValue = 0
                                conn = New SqlConnection(connCRM)
                                cmd = New SqlCommand()
                                cmd.Connection = conn
                                cmd.CommandType = CommandType.Text
                                cmd.CommandText = "SELECT B.AnsID,C.Description FROM tbl_Config_Questions A INNER JOIN tbl_Config_QuestAnsMaps B ON A.QuestID = B.QuestID INNER JOIN tbl_Config_Answers C ON B.AnsID=C.AnsID WHERE A.CampaignID=" & CampaignID & " AND C.Description='" & Value & "' AND A.Questid='" & questID & "'"
                                conn.Open()
                                adp = New SqlDataAdapter(cmd)
                                Dim datat As New DataTable
                                adp.Fill(datat)
                                conn.Close()
                                cmd = Nothing
                                adp = Nothing
                                If datat.Rows.Count > 0 Then
                                    CType(PanelCRMData.FindControl(questID), DropDownList).SelectedValue = datat.Rows(0).Item("AnsID")
                                    '@Orig
                                    ' ChangeControlsVisiblity(questID, datat.Rows(0).Item("Description"), CType(PanelCRMData.FindControl(questID), DropDownList).Attributes("Sequence"), datat.Rows(0).Item("AnsID"))

                                    ''@2019-01-01 LH-341 R1-371 CoxoiID-371 James villas 361
                                    If CampaignID = "371" Or CampaignID = "361" Then
                                        ChangeControlsVisiblity3(questID, datat.Rows(0).Item("Description"), CType(PanelCRMData.FindControl(questID), DropDownList).Attributes("Sequence"), datat.Rows(0).Item("AnsID"))
                                    Else
                                        ChangeControlsVisiblity(questID, datat.Rows(0).Item("Description"), CType(PanelCRMData.FindControl(questID), DropDownList).Attributes("Sequence"), datat.Rows(0).Item("AnsID"))
                                    End If


                                End If

                            ElseIf dtVal.Rows(iCtr).Item("inputType") = 20 Then 'For Datetime Text Box
                                CType(PanelCRMData.FindControl(questID), TextBox).Text = Value


                            ElseIf dtVal.Rows(iCtr).Item("inputType") = 21 Then 'For Datetime Text Box
                                CType(PanelCRMData.FindControl(questID), TextBox).Text = Value

                            End If
                        End If
                    End If
                End If
            Next

            '------------Added by Satyendra on 17th sep 2012-----------'

            Dim dr() As DataRow
            Dim dtst As New DataTable

            conn = New SqlConnection(connCRM)
            cmd = New SqlCommand()
            cmd.Parameters.AddWithValue("customerid", customerid)
            cmd.Parameters.AddWithValue("campaignId", CampaignID)
            cmd.Connection = conn
            cmd.CommandType = CommandType.StoredProcedure
            cmd.CommandText = "usp_GetLastStatus"
            adp = New SqlDataAdapter(cmd)
            adp.Fill(dtst)
            cmd = Nothing
            adp = Nothing
            If dtst.Rows.Count > 0 Then
                For iCtr = 0 To dtVal.Rows.Count - 1
                    questID = ""
                    questID = dtVal.Rows(iCtr).Item("questid").ToString()
                    dr = dtst.Select("questid='" & questID & "'")
                    If Not dr Is Nothing And dr.Length > 0 Then
                        For Each drvalue As DataRow In dr
                            ' Value = ""
                            'Value = dtCustomerID.Rows(0).Item("Ques" & questID).ToString()
                            If Not PanelCRMData.FindControl(questID) Is Nothing Then
                                If PanelCRMData.FindControl(questID).ID Then
                                    If dtVal.Rows(iCtr).Item("inputType") = 0 Then 'For Label 
                                        CType(PanelCRMData.FindControl(questID), TextBox).Text = IIf(IsDBNull(drvalue("AnsText")), "", drvalue("AnsText"))
                                        '@ark 20210220
                                    ElseIf dtVal.Rows(iCtr).Item("inputType") = 22 Then 'For Label  'UK TimeZone
                                        'UK TimeZone
                                        Dim dt As DateTime
                                        dt = TimeZoneInfo.ConvertTimeBySystemTimeZoneId(DateTime.UtcNow, "GMT Standard Time")
                                        'CType(PanelCRMData.FindControl(questID), TextBox).Text = IIf(IsDBNull(drvalue("AnsText")), DateTime.Now.ToString("dd-MMM-yyyy HH:mm"), DateTime.Now.ToString("dd-MMM-yyyy HH:mm"))
                                        CType(PanelCRMData.FindControl(questID), TextBox).Text = IIf(IsDBNull(drvalue("AnsText")), dt.ToString("dd-MMM-yyyy HH:mm"), dt.ToString("dd-MMM-yyyy HH:mm"))

                                    ElseIf dtVal.Rows(iCtr).Item("inputType") = 23 Then 'For Label  'IST TimeZone
                                        CType(PanelCRMData.FindControl(questID), TextBox).Text = IIf(IsDBNull(drvalue("AnsText")), DateTime.Now.ToString("dd-MMM-yyyy HH:mm"), DateTime.Now.ToString("dd-MMM-yyyy HH:mm"))


                                    ElseIf dtVal.Rows(iCtr).Item("inputType") = 25 Then 'For Label  'Eastern TimeZone
                                        'Eastern TimeZone
                                        Dim dt As DateTime
                                        dt = TimeZoneInfo.ConvertTimeBySystemTimeZoneId(DateTime.UtcNow, "Eastern Standard Time")
                                        'CType(PanelCRMData.FindControl(questID), TextBox).Text = IIf(IsDBNull(drvalue("AnsText")), DateTime.Now.ToString("dd-MMM-yyyy HH:mm"), DateTime.Now.ToString("dd-MMM-yyyy HH:mm"))
                                        CType(PanelCRMData.FindControl(questID), TextBox).Text = IIf(IsDBNull(drvalue("AnsText")), dt.ToString("dd-MMM-yyyy HH:mm"), dt.ToString("dd-MMM-yyyy HH:mm"))

                                    ElseIf dtVal.Rows(iCtr).Item("inputType") = 1 Then 'For Text Box
                                        CType(PanelCRMData.FindControl(questID), TextBox).Text = IIf(IsDBNull(drvalue("AnsText")), "", drvalue("AnsText"))

                                        '@20230831 
                                    ElseIf dtVal.Rows(iCtr).Item("inputType") = 111 Then 'For Text Box
                                        CType(PanelCRMData.FindControl(questID), TextBox).Text = IIf(IsDBNull(drvalue("AnsText")), "", drvalue("AnsText"))

                                        '@20220516
                                    ElseIf dtVal.Rows(iCtr).Item("inputType") = 24 Then 'For Money Text Box
                                        If drvalue("AnsText").ToString().Length = 3 Or 6 Or 9 Or 12 Or 15 Or 18 Or 21 Then
                                            drvalue("AnsText") &= ","
                                        End If
                                        CType(PanelCRMData.FindControl(questID), TextBox).Text = IIf(IsDBNull(drvalue("AnsText")), "", drvalue("AnsText"))

                                    ElseIf dtVal.Rows(iCtr).Item("inputType") = 8 Then 'For Text Box
                                        CType(PanelCRMData.FindControl(questID), TextBox).Text = IIf(IsDBNull(drvalue("AnsText")), "", drvalue("AnsText"))
                                    ElseIf dtVal.Rows(iCtr).Item("inputType") = 2 Then 'For Drop Down
                                        CType(PanelCRMData.FindControl(questID), DropDownList).SelectedValue = drvalue("AnsID").ToString  'numericValue
                                    ElseIf dtVal.Rows(iCtr).Item("inputType") = 11 Then 'For WorkDown Drop Down
                                        CType(PanelCRMData.FindControl(questID), DropDownList).SelectedValue = drvalue("AnsID").ToString  'numericValue
                                        '@Orig
                                        ' ChangeControlsVisiblity(questID, drvalue("anstext"), CType(PanelCRMData.FindControl(questID), DropDownList).Attributes("Sequence"), drvalue("AnsID"))

                                        If CampaignID = "371" Then  '341-LH ,371-R1,CoxoID 371
                                            ChangeControlsVisiblity3(questID, drvalue("anstext"), CType(PanelCRMData.FindControl(questID), DropDownList).Attributes("Sequence"), drvalue("AnsID"))
                                        Else
                                            ChangeControlsVisiblity(questID, drvalue("anstext"), CType(PanelCRMData.FindControl(questID), DropDownList).Attributes("Sequence"), drvalue("AnsID"))
                                        End If

                                    ElseIf dtVal.Rows(iCtr).Item("inputType") = 12 Then 'For Date Time Control
                                        Dim a As Object = PanelCRMData.FindControl(questID)
                                        If IIf(IsDBNull(drvalue("AnsText")), "", drvalue("AnsText")) <> "" Then
                                            'a.Text = IIf(IsDBNull(drvalue("AnsText")), "", drvalue("AnsText"))
                                            a.value = IIf(IsDBNull(drvalue("AnsText")), "", drvalue("AnsText"))
                                        End If
                                    ElseIf dtVal.Rows(iCtr).Item("inputType") = 20 Then 'For Datetime Text Box in MM/dd/yyyy hh:mm:ss fromat
                                        CType(PanelCRMData.FindControl(questID), TextBox).Text = IIf(IsDBNull(drvalue("AnsText")), "", drvalue("AnsText"))
                                    ElseIf dtVal.Rows(iCtr).Item("inputType") = 21 Then 'For Datetime Text Box dd/MM/yyyy hh:mm:ss format
                                        CType(PanelCRMData.FindControl(questID), TextBox).Text = IIf(IsDBNull(drvalue("AnsText")), "", drvalue("AnsText"))

                                    End If
                                End If
                            End If
                        Next
                    End If
                Next
            End If
        Catch ex As Exception
            'AlertMessage(ex.Message)
            Throw ex
        End Try
    End Sub
    Private Sub FindControlValues(ByVal campaignid As Int32, ByVal TransID As Long)
        Dim dtMandatoryQuest As New DataTable
        Dim AnsTextValue, AnsIdValue As String
        Dim iCtr As Integer
        Dim dtlead As New DataTable
        Dim conn2 As SqlConnection
        Dim cmd2 As SqlCommand
        Try
            conn = New SqlConnection(connCRM)
            cmd = New SqlCommand()
            cmd.Parameters.AddWithValue("campaignid", campaignid)
            cmd.Connection = conn
            cmd.CommandType = CommandType.StoredProcedure
            cmd.CommandText = "usp_GetMandatoryQuest"
            adp = New SqlDataAdapter(cmd)
            adp.Fill(dtMandatoryQuest)
            cmd = Nothing
            adp = Nothing

            If Not dtMandatoryQuest Is Nothing Then
                For iCtr = 0 To dtMandatoryQuest.Rows.Count - 1
                    If Not PanelCRMData.FindControl(dtMandatoryQuest.Rows(iCtr).Item("questid")) Is Nothing Then
                        If PanelCRMData.FindControl(dtMandatoryQuest.Rows(iCtr).Item("questid")).ID And PanelCRMData.FindControl(dtMandatoryQuest.Rows(iCtr).Item("questid")).Visible Then
                            conn = New SqlConnection(connCRM)
                            cmd = New SqlCommand()
                            cmd.Parameters.AddWithValue("TransID", TransID)
                            cmd.Parameters.AddWithValue("Questid", dtMandatoryQuest.Rows(iCtr).Item("questid"))

                            '@20220516
                            If dtMandatoryQuest.Rows(iCtr).Item("InputType") = 0 Or dtMandatoryQuest.Rows(iCtr).Item("InputType") = 22 Or dtMandatoryQuest.Rows(iCtr).Item("InputType") = 23 Or dtMandatoryQuest.Rows(iCtr).Item("InputType") = 25 Or dtMandatoryQuest.Rows(iCtr).Item("InputType") = 1 Or dtMandatoryQuest.Rows(iCtr).Item("InputType") = 8 Or dtMandatoryQuest.Rows(iCtr).Item("InputType") = 24 Or dtMandatoryQuest.Rows(iCtr).Item("InputType") = 111 Then
                                cmd.Parameters.AddWithValue("ansid", -1)
                                AnsTextValue = Request.Form(dtMandatoryQuest.Rows(iCtr).Item("questid").ToString)

                            ElseIf dtMandatoryQuest.Rows(iCtr).Item("InputType") = 2 Or dtMandatoryQuest.Rows(iCtr).Item("InputType") = 11 Then
                                cmd.Parameters.AddWithValue("ansid", Request.Form(dtMandatoryQuest.Rows(iCtr).Item("questid").ToString))
                                AnsIdValue = Request.Form(dtMandatoryQuest.Rows(iCtr).Item("questid").ToString)
                                If dtMandatoryQuest.Rows(iCtr).Item("IsMandatory") = True Then '----- By Rajendra
                                    If AnsIdValue = "1936" Then
                                        dateflag = False
                                        lblError.Text = "Please enter " & dtMandatoryQuest.Rows(iCtr).Item("quest_dataheading").ToString
                                        Exit Sub
                                    End If

                                    ''@2022-01-12 start
                                    'If AnsIdValue = "690" Or AnsIdValue = "30" Then
                                    '    'ScriptManager.RegisterClientScriptBlock(Me, System.Type.GetType("System.String"), "alertMessage", "javascript:alert('Please re - check the our share limit before completing !!');", False)
                                    '    System.Web.UI.ScriptManager.RegisterClientScriptBlock(Page, GetType(Page), "Script", "alert('Please re - check the our share limit before completing !!');", True)
                                    '    'Exit Sub
                                    'End If
                                    ''@2022-01-12 end

                                End If

                                conn2 = New SqlConnection(connCRM)
                                cmd2 = New SqlCommand()
                                cmd2.Connection = conn2
                                cmd2.CommandType = CommandType.Text
                                cmd2.CommandText = "SELECT isnull(Description,'') as Description FROM tbl_Config_Answers WHERE AnsID=" & AnsIdValue
                                conn2.Open()
                                AnsTextValue = CStr(cmd2.ExecuteScalar())
                                conn2.Close()
                                cmd2 = Nothing
                                '--------------

                            ElseIf dtMandatoryQuest.Rows(iCtr).Item("InputType") = 12 Then
                                cmd.Parameters.AddWithValue("ansid", -1)
                                Dim datevalue As Object = PanelCRMData.FindControl(dtMandatoryQuest.Rows(iCtr).Item("questid"))
                                '@old usp_questdata Love Holiday  failure AnsTextValue = datevalue.Text
                                AnsTextValue = datevalue.Text.trim()

                                If dtMandatoryQuest.Rows(iCtr).Item("IsMandatory") = True Then
                                    If AnsTextValue Is Nothing Then
                                        dateflag = False
                                        lblError.Text = "Please enter " & dtMandatoryQuest.Rows(iCtr).Item("quest_dataheading").ToString
                                        Exit Sub
                                    ElseIf AnsTextValue = "" Then
                                        dateflag = False
                                        lblError.Text = "Please enter " & dtMandatoryQuest.Rows(iCtr).Item("quest_dataheading").ToString
                                        Exit Sub
                                    End If
                                    If Not IsDate(AnsTextValue) Then
                                        lblError.Text = dtMandatoryQuest.Rows(iCtr).Item("quest_dataheading").ToString & " is not valid"
                                        dateflag = False
                                        Exit Sub
                                    End If
                                Else
                                    If Not AnsTextValue Is Nothing Then
                                        If AnsTextValue <> "" Then
                                            If Not IsDate(AnsTextValue) Then
                                                lblError.Text = dtMandatoryQuest.Rows(iCtr).Item("quest_dataheading").ToString & " is not valid"
                                                dateflag = False
                                                Exit Sub
                                            End If
                                        End If
                                    End If
                                End If
                                'ark 20210216 default Datetime Dropdown
                                'ElseIf dtMandatoryQuest.Rows(iCtr).Item("InputType") = 22 Then
                                '    cmd.Parameters.AddWithValue("ansid", -1)
                                '    Dim datevalue As Object = PanelCRMData.FindControl(dtMandatoryQuest.Rows(iCtr).Item("questid"))
                                '    AnsTextValue = datevalue.Text
                                '    If dtMandatoryQuest.Rows(iCtr).Item("IsMandatory") = True Then
                                '        If AnsTextValue Is Nothing Then
                                '            dateflag = False
                                '            lblError.Text = "Please enter " & dtMandatoryQuest.Rows(iCtr).Item("quest_dataheading").ToString
                                '            Exit Sub
                                '        ElseIf AnsTextValue = "" Then
                                '            dateflag = False
                                '            lblError.Text = "Please enter " & dtMandatoryQuest.Rows(iCtr).Item("quest_dataheading").ToString
                                '            Exit Sub
                                '        End If
                                '        If Not IsDate(AnsTextValue) Then
                                '            lblError.Text = dtMandatoryQuest.Rows(iCtr).Item("quest_dataheading").ToString & " is not valid"
                                '            dateflag = False
                                '            Exit Sub
                                '        End If
                                '    Else
                                '        If Not AnsTextValue Is Nothing Then
                                '            If AnsTextValue <> "" Then
                                '                If Not IsDate(AnsTextValue) Then
                                '                    lblError.Text = dtMandatoryQuest.Rows(iCtr).Item("quest_dataheading").ToString & " is not valid"
                                '                    dateflag = False
                                '                    Exit Sub
                                '                End If
                                '            End If
                                '        End If
                                '    End If

                            ElseIf dtMandatoryQuest.Rows(iCtr).Item("InputType") = 20 Then   'DateTimeWithoutCalendar(MM/dd/yyyy hh:mm:ss)
                                '-----------------------------------------------------------------------------
                                cmd.Parameters.AddWithValue("ansid", -1)
                                Dim datevalue As Object = PanelCRMData.FindControl(dtMandatoryQuest.Rows(iCtr).Item("questid"))
                                AnsTextValue = datevalue.Text

                                If dtMandatoryQuest.Rows(iCtr).Item("IsMandatory") = True Then
                                    If AnsTextValue Is Nothing Then
                                        dateflag = False
                                        lblError.Text = "Please enter " & dtMandatoryQuest.Rows(iCtr).Item("quest_dataheading").ToString
                                        Exit Sub
                                    ElseIf AnsTextValue = "" Then
                                        dateflag = False
                                        lblError.Text = "Please enter " & dtMandatoryQuest.Rows(iCtr).Item("quest_dataheading").ToString
                                        Exit Sub
                                    End If
                                    '------------------------------------------------------------------
                                    'To reverse position of MM with DD to check for date

                                    Dim originalAnsTextValue As String = AnsTextValue

                                    Dim ChangeAnsTextValue As String = ""
                                    If AnsTextValue.Length >= 18 Then
                                        ChangeAnsTextValue = AnsTextValue.Substring(3, 3) & AnsTextValue.Substring(0, 3) & AnsTextValue.Substring(6)
                                        AnsTextValue = ChangeAnsTextValue
                                    Else
                                        lblError.Text = dtMandatoryQuest.Rows(iCtr).Item("quest_dataheading").ToString & " is not in valid Datetime Format"
                                        dateflag = False
                                        Exit Sub
                                    End If
                                    '------------------------------------------------------------------
                                    If Not IsDate(AnsTextValue) Then
                                        lblError.Text = dtMandatoryQuest.Rows(iCtr).Item("quest_dataheading").ToString & " is not valid Datetime."
                                        dateflag = False
                                        Exit Sub
                                    End If

                                    'MM/dd/yyyy hh:mm:ss AM/PM    '--AM/PM  is optional
                                    Dim regString As String = "([0-3][0-9]\/[0-1][0-9]\/[0-9]{4} [0-2][0-9]:[0-5][0-9]:[0-5][0-9])([paPA][Mm]){0,}"
                                    Dim dtInput As New System.Text.RegularExpressions.Regex(regString)
                                    If dtInput.IsMatch(AnsTextValue.Trim).ToString Then
                                    Else
                                        lblError.Text = dtMandatoryQuest.Rows(iCtr).Item("quest_dataheading").ToString & " is not in valid Datetime Format"
                                        dateflag = False
                                        Exit Sub
                                    End If

                                    AnsTextValue = originalAnsTextValue

                                Else
                                    If Not AnsTextValue Is Nothing Then
                                        If AnsTextValue <> "" Then

                                            '------------------------------------------------------------------
                                            'To reverse position of MM with DD to check for date

                                            Dim originalAnsTextValue As String = AnsTextValue

                                            Dim ChangeAnsTextValue As String = ""
                                            If AnsTextValue.Length >= 18 Then
                                                ChangeAnsTextValue = AnsTextValue.Substring(3, 3) & AnsTextValue.Substring(0, 3) & AnsTextValue.Substring(6)
                                                AnsTextValue = ChangeAnsTextValue
                                            Else
                                                lblError.Text = dtMandatoryQuest.Rows(iCtr).Item("quest_dataheading").ToString & " is not in valid Datetime Format"
                                                dateflag = False
                                                Exit Sub
                                            End If
                                            '------------------------------------------------------------------

                                            If Not IsDate(AnsTextValue) Then
                                                lblError.Text = dtMandatoryQuest.Rows(iCtr).Item("quest_dataheading").ToString & " is not valid Datetime."
                                                dateflag = False
                                                Exit Sub
                                            End If

                                            'MM/dd/yyyy hh:mm:ss AM/PM    '--AM/PM  is optional
                                            Dim regString As String = "([0-3][0-9]\/[0-1][0-9]\/[0-9]{4} [0-2][0-9]:[0-5][0-9]:[0-5][0-9])([paPA][Mm]){0,}"
                                            Dim dtInput As New System.Text.RegularExpressions.Regex(regString)
                                            If dtInput.IsMatch(AnsTextValue.Trim).ToString Then
                                            Else
                                                lblError.Text = dtMandatoryQuest.Rows(iCtr).Item("quest_dataheading").ToString & " is not in valid Datetime Format"
                                                dateflag = False
                                                Exit Sub
                                            End If

                                            AnsTextValue = originalAnsTextValue
                                        End If
                                    End If
                                End If
                                '-----------------------------------------------------------------------------
                            ElseIf dtMandatoryQuest.Rows(iCtr).Item("InputType") = 21 Then 'DateTimeWithoutCalendar(dd/MM/yyyy hh:mm:ss)
                                '-----------------------------------------------------------------------------
                                cmd.Parameters.AddWithValue("ansid", -1)
                                Dim datevalue As Object = PanelCRMData.FindControl(dtMandatoryQuest.Rows(iCtr).Item("questid"))
                                AnsTextValue = datevalue.Text

                                If dtMandatoryQuest.Rows(iCtr).Item("IsMandatory") = True Then
                                    If AnsTextValue Is Nothing Then
                                        dateflag = False
                                        lblError.Text = "Please enter " & dtMandatoryQuest.Rows(iCtr).Item("quest_dataheading").ToString
                                        Exit Sub
                                    ElseIf AnsTextValue = "" Then
                                        dateflag = False
                                        lblError.Text = "Please enter " & dtMandatoryQuest.Rows(iCtr).Item("quest_dataheading").ToString
                                        Exit Sub
                                    End If

                                    If Not IsDate(AnsTextValue) Then
                                        lblError.Text = dtMandatoryQuest.Rows(iCtr).Item("quest_dataheading").ToString & " is not valid Datetime."
                                        dateflag = False
                                        Exit Sub
                                    End If

                                    'dd/MM/yyyy hh:mm:ss AM/PM    '--AM/PM  is optional
                                    Dim regString As String = "([0-3][0-9]\/[0-1][0-9]\/[0-9]{4} [0-2][0-9]:[0-5][0-9]:[0-5][0-9])([paPA][Mm]){0,}"
                                    Dim dtInput As New System.Text.RegularExpressions.Regex(regString)
                                    If dtInput.IsMatch(AnsTextValue.Trim).ToString Then
                                    Else
                                        lblError.Text = dtMandatoryQuest.Rows(iCtr).Item("quest_dataheading").ToString & " is not in valid Datetime Format"
                                        dateflag = False
                                        Exit Sub
                                    End If


                                Else
                                    If Not AnsTextValue Is Nothing Then
                                        If AnsTextValue <> "" Then

                                            If Not IsDate(AnsTextValue) Then
                                                lblError.Text = dtMandatoryQuest.Rows(iCtr).Item("quest_dataheading").ToString & " is not valid Datetime."
                                                dateflag = False
                                                Exit Sub
                                            End If

                                            'dd/MM/yyyy hh:mm:ss AM/PM    '--AM/PM  is optional
                                            Dim regString As String = "([0-3][0-9]\/[0-1][0-9]\/[0-9]{4} [0-2][0-9]:[0-5][0-9]:[0-5][0-9])([paPA][Mm]){0,}"
                                            Dim dtInput As New System.Text.RegularExpressions.Regex(regString)
                                            If dtInput.IsMatch(AnsTextValue.Trim).ToString Then
                                            Else
                                                lblError.Text = dtMandatoryQuest.Rows(iCtr).Item("quest_dataheading").ToString & " is not in valid Datetime Format"
                                                dateflag = False
                                                Exit Sub
                                            End If
                                        End If
                                    End If
                                End If
                                '-----------------------------------------------------------------------------
                            Else
                                AnsTextValue = ""
                            End If


                            cmd.Parameters.AddWithValue("ansText", AnsTextValue)

                            cmd.Connection = conn
                            cmd.CommandType = CommandType.StoredProcedure
                            cmd.CommandText = "usp_insertAnswers"
                            conn.Open()
                            cmd.ExecuteNonQuery()
                            conn.Close()
                            cmd = Nothing
                            conn = New SqlConnection(connLeads)
                            dtlead = New DataTable
                            Dim adp2 As SqlDataAdapter

                            conn2 = New SqlConnection(connLeads)
                            cmd2 = New SqlCommand()
                            cmd2.Connection = conn2
                            cmd2.CommandType = CommandType.Text
                            cmd2.CommandText = "select * from tbl_LeadMaster" & campaignid & " where 1=2"
                            adp2 = New SqlDataAdapter(cmd2)
                            adp2.Fill(dtlead)
                            cmd2 = Nothing
                            adp2 = Nothing
                            If dtlead.Columns.Contains("Ques" & dtMandatoryQuest.Rows(iCtr).Item("questid")) Then
                                cmd = New SqlCommand()
                                cmd.Connection = conn
                                cmd.CommandType = CommandType.Text
                                cmd.CommandText = "UPDATE tbl_LeadMaster" & campaignid & " SET Ques" & dtMandatoryQuest.Rows(iCtr).Item("questid") & "='" & Replace(AnsTextValue, "'", "''") & "'  WHERE customerid=" & customerid
                                conn.Open()
                                cmd.ExecuteNonQuery()
                                conn.Close()
                                cmd = Nothing
                            End If
                        End If
                    End If
                Next
                '--------- By Rajendra
                If dtcalculate.Rows.Count > 0 Then
                    For Each calrow As DataRow In dtcalculate.Rows
                        conn = New SqlConnection(connCRM)
                        cmd = New SqlCommand()
                        cmd.Parameters.AddWithValue("campaignID", campaignid)
                        cmd.Parameters.AddWithValue("ID", TransID)
                        cmd.Parameters.AddWithValue("QuestionId", calrow("questid"))
                        cmd.Connection = conn
                        cmd.CommandType = CommandType.StoredProcedure
                        cmd.CommandText = "usp_SaveCalculateField"
                        conn.Open()
                        cmd.ExecuteScalar()
                        conn.Close()
                        cmd = Nothing
                    Next
                    dtcalculate = Nothing
                End If
                '-----------------------------
            End If

        Catch ex1 As SqlClient.SqlException
            If ex1.Number = 207 Then

            Else
                'AlertMessage(ex1.Message)
                Throw ex1
            End If
        Catch ex As Exception
            'AlertMessage(ex.Message)
            Throw ex
        Finally
            dtlead = Nothing
            dtMandatoryQuest = Nothing
        End Try

    End Sub
    '@2022-02-03
    Private Sub FindControlValues3(ByVal campaignid As Int32, ByVal TransID As Long)
        Dim dtMandatoryQuest As New DataTable
        Dim AnsTextValue, AnsIdValue As String
        Dim iCtr As Integer
        Dim dtlead As New DataTable
        Dim conn2 As SqlConnection
        Dim cmd2 As SqlCommand
        Try
            conn = New SqlConnection(connCRM)
            cmd = New SqlCommand()
            cmd.Parameters.AddWithValue("campaignid", campaignid)
            cmd.Connection = conn
            cmd.CommandType = CommandType.StoredProcedure
            cmd.CommandText = "usp_GetMandatoryQuest"
            adp = New SqlDataAdapter(cmd)
            adp.Fill(dtMandatoryQuest)
            cmd = Nothing
            adp = Nothing



            If Not dtMandatoryQuest Is Nothing Then
                For iCtr = 0 To dtMandatoryQuest.Rows.Count - 1



                    If Not PanelCRMData.FindControl(dtMandatoryQuest.Rows(iCtr).Item("questid")) Is Nothing Then
                        If PanelCRMData.FindControl(dtMandatoryQuest.Rows(iCtr).Item("questid")).ID And PanelCRMData.FindControl(dtMandatoryQuest.Rows(iCtr).Item("questid")).Visible Then
                            conn = New SqlConnection(connCRM)
                            cmd = New SqlCommand()
                            cmd.Parameters.AddWithValue("TransID", TransID)
                            cmd.Parameters.AddWithValue("Questid", dtMandatoryQuest.Rows(iCtr).Item("questid"))

                            If dtMandatoryQuest.Rows(iCtr).Item("InputType") = 0 Or dtMandatoryQuest.Rows(iCtr).Item("InputType") = 22 Or dtMandatoryQuest.Rows(iCtr).Item("InputType") = 23 Or dtMandatoryQuest.Rows(iCtr).Item("InputType") = 25 Or dtMandatoryQuest.Rows(iCtr).Item("InputType") = 1 Or dtMandatoryQuest.Rows(iCtr).Item("InputType") = 8 Or dtMandatoryQuest.Rows(iCtr).Item("InputType") = 111 Then
                                cmd.Parameters.AddWithValue("ansid", -1)
                                AnsTextValue = Request.Form(dtMandatoryQuest.Rows(iCtr).Item("questid").ToString)

                            ElseIf dtMandatoryQuest.Rows(iCtr).Item("InputType") = 2 Or dtMandatoryQuest.Rows(iCtr).Item("InputType") = 11 Then
                                cmd.Parameters.AddWithValue("ansid", Request.Form(dtMandatoryQuest.Rows(iCtr).Item("questid").ToString))
                                AnsIdValue = Request.Form(dtMandatoryQuest.Rows(iCtr).Item("questid").ToString)
                                If dtMandatoryQuest.Rows(iCtr).Item("IsMandatory") = True Then '----- By Rajendra
                                    If AnsIdValue = "1936" Then
                                        dateflag = False
                                        lblError.Text = "Please enter " & dtMandatoryQuest.Rows(iCtr).Item("quest_dataheading").ToString
                                        Exit Sub
                                    End If

                                    ''@2022-01-12 start
                                    'If AnsIdValue = "690" Or AnsIdValue = "30" Then
                                    '    'ScriptManager.RegisterClientScriptBlock(Me, System.Type.GetType("System.String"), "alertMessage", "javascript:alert('Please re - check the our share limit before completing !!');", False)
                                    '    System.Web.UI.ScriptManager.RegisterClientScriptBlock(Page, GetType(Page), "Script", "alert('Please re - check the our share limit before completing !!');", True)
                                    '    'Exit Sub
                                    'End If
                                    ''@2022-01-12 end

                                End If

                                conn2 = New SqlConnection(connCRM)
                                cmd2 = New SqlCommand()
                                cmd2.Connection = conn2
                                cmd2.CommandType = CommandType.Text
                                cmd2.CommandText = "SELECT isnull(Description,'') as Description FROM tbl_Config_Answers WHERE AnsID=" & AnsIdValue
                                conn2.Open()
                                AnsTextValue = CStr(cmd2.ExecuteScalar())
                                conn2.Close()
                                cmd2 = Nothing
                                '--------------
                            ElseIf dtMandatoryQuest.Rows(iCtr).Item("InputType") = 12 Then
                                cmd.Parameters.AddWithValue("ansid", -1)
                                Dim datevalue As Object = PanelCRMData.FindControl(dtMandatoryQuest.Rows(iCtr).Item("questid"))
                                '@old usp_questdata Love Holiday  failure AnsTextValue = datevalue.Text
                                AnsTextValue = datevalue.Text.trim()

                                If dtMandatoryQuest.Rows(iCtr).Item("IsMandatory") = True Then
                                    If AnsTextValue Is Nothing Then
                                        dateflag = False
                                        lblError.Text = "Please enter " & dtMandatoryQuest.Rows(iCtr).Item("quest_dataheading").ToString
                                        Exit Sub
                                    ElseIf AnsTextValue = "" Then
                                        dateflag = False
                                        lblError.Text = "Please enter " & dtMandatoryQuest.Rows(iCtr).Item("quest_dataheading").ToString
                                        Exit Sub
                                    End If
                                    If Not IsDate(AnsTextValue) Then
                                        lblError.Text = dtMandatoryQuest.Rows(iCtr).Item("quest_dataheading").ToString & " is not valid"
                                        dateflag = False
                                        Exit Sub
                                    End If
                                Else
                                    If Not AnsTextValue Is Nothing Then
                                        If AnsTextValue <> "" Then
                                            If Not IsDate(AnsTextValue) Then
                                                lblError.Text = dtMandatoryQuest.Rows(iCtr).Item("quest_dataheading").ToString & " is not valid"
                                                dateflag = False
                                                Exit Sub
                                            End If
                                        End If
                                    End If
                                End If
                                'ark 20210216 default Datetime Dropdown
                                'ElseIf dtMandatoryQuest.Rows(iCtr).Item("InputType") = 22 Then
                                '    cmd.Parameters.AddWithValue("ansid", -1)
                                '    Dim datevalue As Object = PanelCRMData.FindControl(dtMandatoryQuest.Rows(iCtr).Item("questid"))
                                '    AnsTextValue = datevalue.Text
                                '    If dtMandatoryQuest.Rows(iCtr).Item("IsMandatory") = True Then
                                '        If AnsTextValue Is Nothing Then
                                '            dateflag = False
                                '            lblError.Text = "Please enter " & dtMandatoryQuest.Rows(iCtr).Item("quest_dataheading").ToString
                                '            Exit Sub
                                '        ElseIf AnsTextValue = "" Then
                                '            dateflag = False
                                '            lblError.Text = "Please enter " & dtMandatoryQuest.Rows(iCtr).Item("quest_dataheading").ToString
                                '            Exit Sub
                                '        End If
                                '        If Not IsDate(AnsTextValue) Then
                                '            lblError.Text = dtMandatoryQuest.Rows(iCtr).Item("quest_dataheading").ToString & " is not valid"
                                '            dateflag = False
                                '            Exit Sub
                                '        End If
                                '    Else
                                '        If Not AnsTextValue Is Nothing Then
                                '            If AnsTextValue <> "" Then
                                '                If Not IsDate(AnsTextValue) Then
                                '                    lblError.Text = dtMandatoryQuest.Rows(iCtr).Item("quest_dataheading").ToString & " is not valid"
                                '                    dateflag = False
                                '                    Exit Sub
                                '                End If
                                '            End If
                                '        End If
                                '    End If

                            ElseIf dtMandatoryQuest.Rows(iCtr).Item("InputType") = 20 Then   'DateTimeWithoutCalendar(MM/dd/yyyy hh:mm:ss)
                                '-----------------------------------------------------------------------------
                                cmd.Parameters.AddWithValue("ansid", -1)
                                Dim datevalue As Object = PanelCRMData.FindControl(dtMandatoryQuest.Rows(iCtr).Item("questid"))
                                AnsTextValue = datevalue.Text

                                If dtMandatoryQuest.Rows(iCtr).Item("IsMandatory") = True Then
                                    If AnsTextValue Is Nothing Then
                                        dateflag = False
                                        lblError.Text = "Please enter " & dtMandatoryQuest.Rows(iCtr).Item("quest_dataheading").ToString
                                        Exit Sub
                                    ElseIf AnsTextValue = "" Then
                                        dateflag = False
                                        lblError.Text = "Please enter " & dtMandatoryQuest.Rows(iCtr).Item("quest_dataheading").ToString
                                        Exit Sub
                                    End If
                                    '------------------------------------------------------------------
                                    'To reverse position of MM with DD to check for date

                                    Dim originalAnsTextValue As String = AnsTextValue

                                    Dim ChangeAnsTextValue As String = ""
                                    If AnsTextValue.Length >= 18 Then
                                        ChangeAnsTextValue = AnsTextValue.Substring(3, 3) & AnsTextValue.Substring(0, 3) & AnsTextValue.Substring(6)
                                        AnsTextValue = ChangeAnsTextValue
                                    Else
                                        lblError.Text = dtMandatoryQuest.Rows(iCtr).Item("quest_dataheading").ToString & " is not in valid Datetime Format"
                                        dateflag = False
                                        Exit Sub
                                    End If
                                    '------------------------------------------------------------------
                                    If Not IsDate(AnsTextValue) Then
                                        lblError.Text = dtMandatoryQuest.Rows(iCtr).Item("quest_dataheading").ToString & " is not valid Datetime."
                                        dateflag = False
                                        Exit Sub
                                    End If

                                    'MM/dd/yyyy hh:mm:ss AM/PM    '--AM/PM  is optional
                                    Dim regString As String = "([0-3][0-9]\/[0-1][0-9]\/[0-9]{4} [0-2][0-9]:[0-5][0-9]:[0-5][0-9])([paPA][Mm]){0,}"
                                    Dim dtInput As New System.Text.RegularExpressions.Regex(regString)
                                    If dtInput.IsMatch(AnsTextValue.Trim).ToString Then
                                    Else
                                        lblError.Text = dtMandatoryQuest.Rows(iCtr).Item("quest_dataheading").ToString & " is not in valid Datetime Format"
                                        dateflag = False
                                        Exit Sub
                                    End If

                                    AnsTextValue = originalAnsTextValue

                                Else
                                    If Not AnsTextValue Is Nothing Then
                                        If AnsTextValue <> "" Then

                                            '------------------------------------------------------------------
                                            'To reverse position of MM with DD to check for date

                                            Dim originalAnsTextValue As String = AnsTextValue

                                            Dim ChangeAnsTextValue As String = ""
                                            If AnsTextValue.Length >= 18 Then
                                                ChangeAnsTextValue = AnsTextValue.Substring(3, 3) & AnsTextValue.Substring(0, 3) & AnsTextValue.Substring(6)
                                                AnsTextValue = ChangeAnsTextValue
                                            Else
                                                lblError.Text = dtMandatoryQuest.Rows(iCtr).Item("quest_dataheading").ToString & " is not in valid Datetime Format"
                                                dateflag = False
                                                Exit Sub
                                            End If
                                            '------------------------------------------------------------------

                                            If Not IsDate(AnsTextValue) Then
                                                lblError.Text = dtMandatoryQuest.Rows(iCtr).Item("quest_dataheading").ToString & " is not valid Datetime."
                                                dateflag = False
                                                Exit Sub
                                            End If

                                            'MM/dd/yyyy hh:mm:ss AM/PM    '--AM/PM  is optional
                                            Dim regString As String = "([0-3][0-9]\/[0-1][0-9]\/[0-9]{4} [0-2][0-9]:[0-5][0-9]:[0-5][0-9])([paPA][Mm]){0,}"
                                            Dim dtInput As New System.Text.RegularExpressions.Regex(regString)
                                            If dtInput.IsMatch(AnsTextValue.Trim).ToString Then
                                            Else
                                                lblError.Text = dtMandatoryQuest.Rows(iCtr).Item("quest_dataheading").ToString & " is not in valid Datetime Format"
                                                dateflag = False
                                                Exit Sub
                                            End If

                                            AnsTextValue = originalAnsTextValue
                                        End If
                                    End If
                                End If
                                '-----------------------------------------------------------------------------
                            ElseIf dtMandatoryQuest.Rows(iCtr).Item("InputType") = 21 Then 'DateTimeWithoutCalendar(dd/MM/yyyy hh:mm:ss)
                                '-----------------------------------------------------------------------------
                                cmd.Parameters.AddWithValue("ansid", -1)
                                Dim datevalue As Object = PanelCRMData.FindControl(dtMandatoryQuest.Rows(iCtr).Item("questid"))
                                AnsTextValue = datevalue.Text

                                If dtMandatoryQuest.Rows(iCtr).Item("IsMandatory") = True Then
                                    If AnsTextValue Is Nothing Then
                                        dateflag = False
                                        lblError.Text = "Please enter " & dtMandatoryQuest.Rows(iCtr).Item("quest_dataheading").ToString
                                        Exit Sub
                                    ElseIf AnsTextValue = "" Then
                                        dateflag = False
                                        lblError.Text = "Please enter " & dtMandatoryQuest.Rows(iCtr).Item("quest_dataheading").ToString
                                        Exit Sub
                                    End If

                                    If Not IsDate(AnsTextValue) Then
                                        lblError.Text = dtMandatoryQuest.Rows(iCtr).Item("quest_dataheading").ToString & " is not valid Datetime."
                                        dateflag = False
                                        Exit Sub
                                    End If

                                    'dd/MM/yyyy hh:mm:ss AM/PM    '--AM/PM  is optional
                                    Dim regString As String = "([0-3][0-9]\/[0-1][0-9]\/[0-9]{4} [0-2][0-9]:[0-5][0-9]:[0-5][0-9])([paPA][Mm]){0,}"
                                    Dim dtInput As New System.Text.RegularExpressions.Regex(regString)
                                    If dtInput.IsMatch(AnsTextValue.Trim).ToString Then
                                    Else
                                        lblError.Text = dtMandatoryQuest.Rows(iCtr).Item("quest_dataheading").ToString & " is not in valid Datetime Format"
                                        dateflag = False
                                        Exit Sub
                                    End If


                                Else
                                    If Not AnsTextValue Is Nothing Then
                                        If AnsTextValue <> "" Then

                                            If Not IsDate(AnsTextValue) Then
                                                lblError.Text = dtMandatoryQuest.Rows(iCtr).Item("quest_dataheading").ToString & " is not valid Datetime."
                                                dateflag = False
                                                Exit Sub
                                            End If

                                            'dd/MM/yyyy hh:mm:ss AM/PM    '--AM/PM  is optional
                                            Dim regString As String = "([0-3][0-9]\/[0-1][0-9]\/[0-9]{4} [0-2][0-9]:[0-5][0-9]:[0-5][0-9])([paPA][Mm]){0,}"
                                            Dim dtInput As New System.Text.RegularExpressions.Regex(regString)
                                            If dtInput.IsMatch(AnsTextValue.Trim).ToString Then
                                            Else
                                                lblError.Text = dtMandatoryQuest.Rows(iCtr).Item("quest_dataheading").ToString & " is not in valid Datetime Format"
                                                dateflag = False
                                                Exit Sub
                                            End If
                                        End If
                                    End If
                                End If
                                '-----------------------------------------------------------------------------
                            Else
                                AnsTextValue = ""
                            End If


                            cmd.Parameters.AddWithValue("ansText", AnsTextValue)

                            cmd.Connection = conn
                            cmd.CommandType = CommandType.StoredProcedure
                            cmd.CommandText = "usp_insertAnswers"
                            conn.Open()
                            cmd.ExecuteNonQuery()
                            conn.Close()
                            cmd = Nothing
                            conn = New SqlConnection(connLeads)
                            dtlead = New DataTable
                            Dim adp2 As SqlDataAdapter

                            conn2 = New SqlConnection(connLeads)
                            cmd2 = New SqlCommand()
                            cmd2.Connection = conn2
                            cmd2.CommandType = CommandType.Text
                            cmd2.CommandText = "select * from tbl_LeadMaster" & campaignid & " where 1=2"
                            adp2 = New SqlDataAdapter(cmd2)
                            adp2.Fill(dtlead)
                            cmd2 = Nothing
                            adp2 = Nothing
                            If dtlead.Columns.Contains("Ques" & dtMandatoryQuest.Rows(iCtr).Item("questid")) Then
                                cmd = New SqlCommand()
                                cmd.Connection = conn
                                cmd.CommandType = CommandType.Text
                                cmd.CommandText = "UPDATE tbl_LeadMaster" & campaignid & " SET Ques" & dtMandatoryQuest.Rows(iCtr).Item("questid") & "='" & Replace(AnsTextValue, "'", "''") & "'  WHERE customerid=" & customerid
                                conn.Open()
                                cmd.ExecuteNonQuery()
                                conn.Close()
                                cmd = Nothing
                            End If
                        End If
                    End If

                    '@2022-02-03  dependent Dropdown start
                    If dtMandatoryQuest.Rows(iCtr).Item("InputType") = 211 Then


                        If ddlsubworkType.SelectedValue <> "" Then
                            CurrentAnsID = ddlsubworkType.SelectedValue
                        End If
                        If ddlsubworkType.SelectedItem.Text <> "" Then
                            CurrentAnsText = ddlsubworkType.SelectedItem.Text

                        End If
                        conn = New SqlConnection(connCRM)
                        cmd = New SqlCommand()
                        cmd.Parameters.AddWithValue("TransID", TransID)
                        cmd.Parameters.AddWithValue("Questid", dtMandatoryQuest.Rows(iCtr).Item("questid"))
                        cmd.Parameters.AddWithValue("ansid", CurrentAnsID)



                        'conn2 = New SqlConnection(connCRM)
                        'cmd2 = New SqlCommand()
                        'cmd2.Connection = conn2
                        'cmd2.CommandType = CommandType.Text
                        'cmd2.CommandText = "SELECT isnull(Description,'') as Description FROM tbl_Config_Answers WHERE AnsID=" & CurrentAnsID
                        'conn2.Open()
                        'AnsTextValue = CStr(cmd2.ExecuteScalar())
                        'conn2.Close()
                        'cmd2 = Nothing



                        cmd.Parameters.AddWithValue("ansText", CurrentAnsText)
                        cmd.Connection = conn
                        cmd.CommandType = CommandType.StoredProcedure
                        cmd.CommandText = "usp_insertAnswers"
                        conn.Open()
                        cmd.ExecuteNonQuery()
                        conn.Close()
                        cmd = Nothing

                        conn = New SqlConnection(connLeads)
                        dtlead = New DataTable
                        Dim adp2 As SqlDataAdapter

                        conn2 = New SqlConnection(connLeads)
                        cmd2 = New SqlCommand()
                        cmd2.Connection = conn2
                        cmd2.CommandType = CommandType.Text
                        cmd2.CommandText = "select * from tbl_LeadMaster" & campaignid & " where 1=2"
                        adp2 = New SqlDataAdapter(cmd2)
                        adp2.Fill(dtlead)
                        cmd2 = Nothing
                        adp2 = Nothing
                        If dtlead.Columns.Contains("Ques" & dtMandatoryQuest.Rows(iCtr).Item("questid")) Then
                            cmd = New SqlCommand()
                            cmd.Connection = conn
                            cmd.CommandType = CommandType.Text
                            cmd.CommandText = "UPDATE tbl_LeadMaster" & campaignid & " SET Ques" & dtMandatoryQuest.Rows(iCtr).Item("questid") & "='" & Replace(CurrentAnsText, "'", "''") & "'  WHERE customerid=" & customerid
                            conn.Open()
                            cmd.ExecuteNonQuery()
                            conn.Close()
                            cmd = Nothing
                        End If

                    End If
                    '@2022-02-03 end
                Next
                '--------- By Rajendra
                If dtcalculate.Rows.Count > 0 Then
                    For Each calrow As DataRow In dtcalculate.Rows
                        conn = New SqlConnection(connCRM)
                        cmd = New SqlCommand()
                        cmd.Parameters.AddWithValue("campaignID", campaignid)
                        cmd.Parameters.AddWithValue("ID", TransID)
                        cmd.Parameters.AddWithValue("QuestionId", calrow("questid"))
                        cmd.Connection = conn
                        cmd.CommandType = CommandType.StoredProcedure
                        cmd.CommandText = "usp_SaveCalculateField"
                        conn.Open()
                        cmd.ExecuteScalar()
                        conn.Close()
                        cmd = Nothing
                    Next
                    dtcalculate = Nothing
                End If
                '-----------------------------
            End If

        Catch ex1 As SqlClient.SqlException
            If ex1.Number = 207 Then

            Else
                'AlertMessage(ex1.Message)
                Throw ex1
            End If
        Catch ex As Exception
            'AlertMessage(ex.Message)
            Throw ex
        Finally
            dtlead = Nothing
            dtMandatoryQuest = Nothing
        End Try

    End Sub

    Private Sub deletetransaction()
        conn = New SqlConnection(connCRM)
        cmd = New SqlCommand()
        cmd.Parameters.AddWithValue("Transid", TransID)
        cmd.Connection = conn
        cmd.CommandType = CommandType.StoredProcedure
        cmd.CommandText = "usp_deleteTransaction"
        conn.Open()
        cmd.ExecuteNonQuery()
        conn.Close()
        cmd = Nothing

        If DailStateBased Then
            conn = New SqlConnection(connLeads)
            cmd = New SqlCommand()
            cmd.Connection = conn
            cmd.CommandType = CommandType.Text
            cmd.CommandText = "UPDATE tbl_LeadMaster" & CampaignID & " SET DialState=0  WHERE customerid=" & customerid
            conn.Open()
            cmd.ExecuteNonQuery()
            conn.Close()
            cmd = Nothing
        End If
    End Sub
    Private Sub EndTransaction()
        Try
            Dim CreationTime As DateTime = Now
            conn = New SqlConnection(connLeads)
            cmd = New SqlCommand()
            cmd.Parameters.AddWithValue("CustomerID", customerid)
            cmd.Connection = conn
            cmd.CommandType = CommandType.Text

            If ReceivedDateTimeBased Then
                cmd.CommandText = "SELECT ISNULL(ReceivedDateTime,getdate()) FROM tbl_LeadMaster" & CampaignID & " WHERE CustomerID = " & customerid & ""
                conn.Open()
                CreationTime = CDate(cmd.ExecuteScalar())
                conn.Close()
                cmd = Nothing
            Else
                cmd.CommandText = "SELECT ISNULL(CreationTime,getdate()) FROM tbl_LeadMaster" & CampaignID & " WHERE CustomerID = " & customerid & ""
                conn.Open()
                CreationTime = CDate(cmd.ExecuteScalar())
                conn.Close()
                cmd = Nothing
            End If
            conn = New SqlConnection(connLeads)
            cmd = New SqlCommand()
            cmd.Connection = conn
            cmd.CommandType = CommandType.Text
            cmd.CommandText = "select top 1 convert(varchar, getdate(), 100) as Getdate,* from tbl_LeadMaster" & CampaignID
            conn.Open()
            adp = New SqlDataAdapter(cmd)
            conn.Close()
            cmd = Nothing
            Dim dtlead As New DataTable
            adp.Fill(dtlead)

            Dim isExpired As Boolean
            conn = New SqlConnection(connCRM)
            cmd = New SqlCommand()
            cmd.Parameters.AddWithValue("ID", TransID)
            cmd.Parameters.AddWithValue("CustomerID", customerid)
            cmd.Parameters.AddWithValue("ResultCode", ddlDisposition.SelectedValue)
            cmd.Parameters.AddWithValue("CampaignID", CampaignID)

            If IsDate(CreationTime) Then
                cmd.Parameters.AddWithValue("CreationTime", CreationTime.ToString("yyyy-MMM-dd HH:mm:ss"))
            Else
                lblError.Text = "Error in Creation Date"
                lblError.Visible = True
            End If
            cmd.Parameters.AddWithValue("UpdateTat", 1)
            cmd.Parameters.AddWithValue("comments", txtnewcomments.Text.Trim)

            cmd.Connection = conn
            cmd.CommandType = CommandType.StoredProcedure
            cmd.CommandText = "usp_DisposeACall"
            conn.Open()
            isExpired = CBool(cmd.ExecuteScalar())
            conn.Close()
            cmd = Nothing

            If isExpired Then
                conn = New SqlConnection(connLeads)
                cmd = New SqlCommand()
                cmd.Connection = conn
                cmd.CommandType = CommandType.Text
                cmd.CommandText = "UPDATE tbl_LeadMaster" & CampaignID & " SET IsExpired=" & IIf(isExpired, 1, 0) & "  WHERE customerid=" & customerid
                conn.Open()
                cmd.ExecuteNonQuery()
                conn.Close()
                cmd = Nothing
            End If
            If DailStateBased Then
                conn = New SqlConnection(connLeads)
                cmd = New SqlCommand()
                cmd.Connection = conn
                cmd.CommandType = CommandType.Text
                cmd.CommandText = "UPDATE tbl_LeadMaster" & CampaignID & " SET DialState=0  WHERE customerid=" & customerid
                conn.Open()
                cmd.ExecuteNonQuery()
                conn.Close()
                cmd = Nothing
            End If
            If UpdateLead Then
                Dim UpdateFlaglead As Boolean = False

                conn = New SqlConnection(connLeads)
                cmd = New SqlCommand()
                cmd.Connection = conn
                cmd.CommandType = CommandType.Text
                conn.Open()
                Dim str As String = "UPDATE tbl_LeadMaster" & CampaignID & " SET "
                For Each col As DataColumn In dtlead.Columns
                    If col.ColumnName = "LastResultCode" Then
                        str += "LastResultCode=" & ddlDisposition.SelectedValue & ","
                    ElseIf col.ColumnName = "LastResult" Then
                        str += "LastResult='" & ddlDisposition.SelectedItem.Text & "',"
                    ElseIf col.ColumnName = "LastTransDateTime" Then
                        str += "LastTransDateTime='" & DateTime.Now.ToString("yyyy-MMM-dd HH:mm:ss") & "',"
                    ElseIf col.ColumnName = "LastTransId" Then
                        str += "LastTransId=" & TransID & ","
                    ElseIf col.ColumnName.ToLower = "lastagent" Then
                        str += "lastagent='" & AgentID & "',"
                    ElseIf col.ColumnName.ToLower = "comments" Then
                        str += "comments='" & txtprevcomments.Text.Replace("'", "''") & " " & txtnewcomments.Text.Replace("'", "''") & "',"
                    End If
                Next
                If str.EndsWith(",") Then
                    str = str.Remove(str.Length - 1, 1)
                End If
                str += "  WHERE customerid=" & customerid
                cmd.CommandText = str
                cmd.ExecuteNonQuery()
                conn.Close()
                cmd = Nothing

            End If
            '--- By Rajendra On 4th Feb 2014
            If UpdateClientTat Then
                conn = New SqlConnection(connCRM)
                cmd = New SqlCommand()
                cmd.Connection = conn
                cmd.CommandType = CommandType.Text
                conn.Open()
                Dim str As String = "select ResultCode from tbl_Config_ResultGroups where GroupName='ShowClient' AND CampaignID = " & CampaignID & " AND ResultCode=" & ddlDisposition.SelectedValue
                cmd.CommandText = str
                Dim dt As New DataTable
                adp = New SqlDataAdapter(cmd)
                adp.Fill(dt)
                conn.Close()

                If dt.Rows.Count > 0 Then
                    conn = New SqlConnection(connreport)
                    cmd = New SqlCommand()
                    cmd.Parameters.AddWithValue("CampaignID", CampaignID)
                    cmd.Parameters.AddWithValue("CustomerID", customerid)
                    cmd.Parameters.AddWithValue("Createdby", AgentID)
                    cmd.Connection = conn
                    cmd.CommandType = CommandType.StoredProcedure
                    cmd.CommandText = "usp_InsertClientTatDetail"
                    conn.Open()
                    cmd.ExecuteNonQuery()
                    conn.Close()
                    cmd = Nothing
                End If

            End If
            '-------------------
            If WorkingonTMF = True Then
                conn = New SqlConnection(connCRM)
                cmd = New SqlCommand()
                cmd.Parameters.AddWithValue("OldTransID", TransIDTMF)
                cmd.Parameters.AddWithValue("NewTransid", TransID)
                cmd.Connection = conn
                cmd.CommandType = CommandType.StoredProcedure
                cmd.CommandText = "usp_InsertAnswers_QEwise"
                conn.Open()
                cmd.ExecuteNonQuery()
                conn.Close()
                cmd = Nothing
            End If

        Catch ex As Exception
            dateflag = False
            AlertMessage(ex.Message)
            Throw ex
        End Try
    End Sub
    Private Sub break()
        If btbreak.Text = "Take Break" Then
            OnBreak = False
            TakeBreak()
            'Session("Onbreak") = True
            OnBreak = True
            btbreak.Text = "End Break"
            btbreak.ToolTip = "End Break"
            Showbreak.Visible = True
            pnlshowlist.Visible = False
            pnlshowtracker.Visible = False
            ''-----------------------------a little change in below
            'PanelCRMData.Visible = False
            'pnlComment.Visible = False
            'pnlCMFBody.Visible = False
            ''-----------------------------------
            btexit.Enabled = False
            btNewTransactionAssisted.Enabled = False
            btNewTransactionAmadeus.Enabled = False
            btNewTransactionInResort.Enabled = False
            btNewTransactionPostTravel.Enabled = False
            btNewTransactionMMB.Enabled = False
            btNewTransactionMMBKustomer.Enabled = False
            btNewTransactionMMBDE.Enabled = False
            btNewTransactionCSChat.Enabled = False
            btNewTransactionCSVoice.Enabled = False
            btnNewTransactionCreditControl.Enabled = False
            btnNewTransactionSupplierrelocation.Enabled = False
            btnNewTransactionCustomerServiceInbox.Enabled = False
            btnNewTransactionAssistedRyanAir.Enabled = False
            btnNewTransactionRefundTask.Enabled = False
            btnNewTransactionOtherWorkType.Enabled = False

            '------------------ By Rajendra 
            pnlPaused.Visible = False
            If OnBreak Then
                btbreak.Enabled = True
                btPausedTransaction.Enabled = False
            End If
        ElseIf btbreak.Text = "End Break" Then
            OnBreak = True
            TakeBreak()
            'Session("Onbreak") = False
            OnBreak = False
            btbreak.Text = "Take Break"
            btbreak.ToolTip = "Take Break"
            '------------------ By Rajendra 
            If OnBreak = False Then
                Showbreak.Visible = False
                btbreak.Enabled = False
                btPausedTransaction.Enabled = True
            End If
            If Paused = 1 Then
                pnlPaused.Visible = True
            ElseIf Paused = 2 Then
            Else
                Response.Redirect("~/Tracker/NewTrackerLH.aspx?CampaignID=" & CampaignID & "&AgentId=" & AgentID & "&AgentName=" & AgentName & "&IsVerifier=" & IsVerifier)
            End If

        End If
    End Sub
    Private Sub getcommentdata()
        Dim dtRow As New DataTable
        conn = New SqlConnection(connLeads)
        cmd = New SqlCommand()
        cmd.Connection = conn
        cmd.CommandType = CommandType.Text
        cmd.CommandText = "select top 1 * from tbl_LeadMaster" & Me.CampaignID & " where customerid =" & customerid
        adp = New SqlDataAdapter(cmd)
        adp.Fill(dtRow)
        cmd = Nothing
        adp = Nothing

        For Each col As DataColumn In dtRow.Columns
            If col.ColumnName.ToLower = "comments" Then
                'IsLeadcomment = True
                If dtRow.Rows.Count > 0 Then
                    txtprevcomments.Text = IIf(IsDBNull(dtRow.Rows(0).Item("comments")), "", dtRow.Rows(0).Item("comments"))


                Else

                    If CampaignID = 342 Then
                        txtprevcomments.Text = ""
                    Else
                        txtprevcomments.Text = ""
                    End If


                End If

                Exit For
            End If
        Next
        dtRow = Nothing

        '-------------------------------------------------------------------------------------
        'If IsLeadcomment = False Then
        If CampaignID <> 342 Then


            If txtprevcomments.Text = "" Then
                conn = New SqlConnection(connCRM)
                cmd = New SqlCommand()
                cmd.Connection = conn
                cmd.CommandType = CommandType.Text
                cmd.CommandText = "SELECT isnull(comments,'') comments FROM tbl_Customer_Last_Status where customerid =" & customerid & " and campaignid=" & CampaignID
                conn.Open()
                txtprevcomments.Text = CStr(cmd.ExecuteScalar())
                conn.Close()
                cmd = Nothing
            End If
        Else
            txtprevcomments.Text = ""
        End If
        '--------------
    End Sub
    Private Function IsAgentIn() As Boolean
        Dim dr As DataRow
        Dim dtAgentStatus As New DataTable

        conn = New SqlConnection(connCRM)
        cmd = New SqlCommand()
        cmd.Parameters.AddWithValue("AgentID", AgentID)
        cmd.Parameters.AddWithValue("CampID", CampaignID)
        cmd.Connection = conn
        cmd.CommandType = CommandType.StoredProcedure
        cmd.CommandText = "usp_AgentCurrentStatus"
        adp = New SqlDataAdapter(cmd)
        adp.Fill(dtAgentStatus)
        cmd = Nothing
        adp = Nothing

        If dtAgentStatus.Rows.Count > 0 Then
            dr = dtAgentStatus.Rows(0)
            Return Not dr Is Nothing

        End If
        dtAgentStatus = Nothing
    End Function
    Private Function HasagentLoggedout() As Boolean
        If IsAgentIn() Then
            lblError.Visible = False
            lblError.Text = ""
            Return False
        Else
            lblError.Visible = True
            lblError.Text = "You have been logged out by supervisor"
            Return True
        End If
    End Function
    Private Sub showbreaktype()
        Dim dtBreaktype As New DataTable
        conn = New SqlConnection(connCRM)
        cmd = New SqlCommand()
        cmd.Parameters.AddWithValue("campaignid", CampaignID)
        cmd.Connection = conn
        cmd.CommandType = CommandType.StoredProcedure
        cmd.CommandText = "usp_GetBreakType"
        adp = New SqlDataAdapter(cmd)
        adp.Fill(dtBreaktype)
        cmd = Nothing
        adp = Nothing

        cboBreaktype.DataTextField = "BreakDescription"
        cboBreaktype.DataValueField = "BreakType"
        cboBreaktype.DataSource = dtBreaktype
        cboBreaktype.DataBind()

        dtBreaktype = Nothing
    End Sub
    Dim dtComboData, dtanslogic As DataTable

    Private Sub CreateForm(ByVal campaignid As Int32, ByVal control As String, ByVal LeadID As Integer, ByVal WorkType As String)
        'If Not IsPostBack Then
        Dim objTable As Table
        Dim objTablerow As TableRow
        Dim objTableCol As TableCell
        Dim objLabel As Label
        Dim objText As TextBox
        Dim objSelect As DropDownList
        Dim valid As RequiredFieldValidator
        Dim dtMandatoryQuest As New DataTable

        Dim dtcombodata As New DataTable
        Dim dtCustomerID As New DataTable
        Dim abc As UserControl


        Dim iCtr As Integer
        PanelCRMData.Controls.Remove(PanelCRMData.FindControl("dynamic"))
        Try
            objTable = New Table
            objTable.ID = "dynamic"
            objTable.Width = System.Web.UI.WebControls.Unit.Percentage(100)
            objTable.CellSpacing = 0
            objTable.HorizontalAlign = HorizontalAlign.Center
            objTable.EnableViewState = True


            conn = New SqlConnection(connCRM)
            cmd = New SqlCommand()
            cmd.Parameters.AddWithValue("workType", WorkType)
            cmd.Parameters.AddWithValue("campaignid", campaignid)
            cmd.Connection = conn
            cmd.CommandType = CommandType.StoredProcedure
            cmd.CommandText = "usp_getcombodataLH"
            adp = New SqlDataAdapter(cmd)
            adp.Fill(dtcombodata)
            cmd = Nothing
            adp = Nothing

            'Worktype Userrights
            'If campaignid = 341 Then
            '    conn = New SqlConnection(connCRM)
            '    cmd = New SqlCommand()
            '    cmd.Parameters.AddWithValue("campaignid", campaignid)
            '    cmd.Parameters.AddWithValue("AgentID", AgentID)
            '    cmd.Connection = conn
            '    cmd.CommandType = CommandType.StoredProcedure
            '    cmd.CommandText = "usp_getcombodataLH"
            '    adp = New SqlDataAdapter(cmd)
            '    adp.Fill(dtcombodata)
            '    cmd = Nothing
            '    adp = Nothing

            'Else
            '    conn = New SqlConnection(connCRM)
            '    cmd = New SqlCommand()
            '    cmd.Parameters.AddWithValue("campaignid", campaignid)
            '    cmd.Connection = conn
            '    cmd.CommandType = CommandType.StoredProcedure
            '    cmd.CommandText = "usp_getcombodata"
            '    adp = New SqlDataAdapter(cmd)
            '    adp.Fill(dtcombodata)
            '    cmd = Nothing
            '    adp = Nothing


            'End If


            conn = New SqlConnection(connCRM)
            cmd = New SqlCommand()
            cmd.Parameters.AddWithValue("campaignid", campaignid)
            cmd.Connection = conn
            cmd.CommandType = CommandType.StoredProcedure
            cmd.CommandText = "usp_getmandatoryquest"
            adp = New SqlDataAdapter(cmd)
            adp.Fill(dtMandatoryQuest)
            cmd = Nothing
            adp = Nothing




            dtanslogic = New DataTable
            conn = New SqlConnection(connCRM)
            cmd = New SqlCommand()
            cmd.Parameters.AddWithValue("campaignid", campaignid)
            cmd.Connection = conn
            cmd.CommandType = CommandType.StoredProcedure
            cmd.CommandText = "usp_getQuestLogic"
            adp = New SqlDataAdapter(cmd)
            adp.Fill(dtanslogic)
            cmd = Nothing
            adp = Nothing








            conn = New SqlConnection(connLeads)
            cmd = New SqlCommand()
            cmd.Parameters.AddWithValue("leadid", LeadID)
            cmd.Parameters.AddWithValue("agentid", AgentID)
            cmd.Connection = conn
            cmd.CommandType = CommandType.StoredProcedure
            cmd.CommandText = "usp_getLidtoDial" & campaignid
            adp = New SqlDataAdapter(cmd)
            adp.Fill(dtCustomerID)
            cmd = Nothing
            adp = Nothing
            '--------------

            If TransactionBased Then
                customerid = dtCustomerID.Rows(0).Item("customerid")
                'Session("customerid") = customerid
            End If

            '----- By Rajendra for Calculated Field
            dtcalculate = New DataTable
            dtcalculate.Columns.Add("Questid")


            If Not dtMandatoryQuest Is Nothing Then
                For iCtr = 0 To dtMandatoryQuest.Rows.Count - 1

                    Select Case dtMandatoryQuest.Rows(iCtr).Item("inputType")
                        Case 1
                            objTablerow = New TableRow
                            objTablerow.ID = "TblRow" & dtMandatoryQuest.Rows(iCtr).Item("questid")
                            'objTablerow.BackColor = Color.LightGray
                            objTable.Rows.Add(objTablerow)
                            objTablerow.EnableViewState = True
                            objTableCol = New TableCell
                            objTablerow.Cells.Add(objTableCol)
                            objTableCol.EnableViewState = True
                            objTableCol.BackColor = System.Drawing.Color.Transparent
                            objTableCol.VerticalAlign = VerticalAlign.Top
                            objTableCol.HorizontalAlign = HorizontalAlign.Left
                            objTableCol.Width = System.Web.UI.WebControls.Unit.Percentage(40)
                            objTableCol.Attributes.Add("style", "border-bottom: solid 1px #bbd9ee")
                            objLabel = New Label
                            objTableCol.Controls.Add(objLabel)
                            objLabel.Text = dtMandatoryQuest.Rows(iCtr).Item("quest_dataheading")
                            objLabel.EnableViewState = True
                            objTableCol = New TableCell
                            objTablerow.Cells.Add(objTableCol)
                            objTableCol.BackColor = System.Drawing.Color.Transparent
                            objTableCol.VerticalAlign = VerticalAlign.Top
                            objTableCol.HorizontalAlign = HorizontalAlign.Left
                            objTableCol.Width = System.Web.UI.WebControls.Unit.Percentage(55)
                            objTableCol.Attributes.Add("style", "border-bottom: solid 1px #bbd9ee")
                            objTableCol.EnableViewState = True

                            objText = New TextBox
                            objTableCol.Controls.Add(objText)
                            'objText.Text = dt.Rows(iCtr).Item("quest_dataheading")
                            objText.Height = System.Web.UI.WebControls.Unit.Pixel(15)
                            objText.Width = System.Web.UI.WebControls.Unit.Percentage(100)
                            objText.MaxLength = 255
                            objText.Font.Size = System.Web.UI.WebControls.FontUnit.Point(8)
                            objText.BorderColor = Drawing.Color.AliceBlue
                            objText.ID = dtMandatoryQuest.Rows(iCtr).Item("questid")
                            objText.EnableViewState = True
                            objText.Attributes.Add("DisplayCriteria", dtMandatoryQuest.Rows(iCtr).Item("DisplayCriteria"))
                            objText.Attributes.Add("Sequence", dtMandatoryQuest.Rows(iCtr).Item("Sequence"))
                            objText.Visible = True
                            If dtMandatoryQuest.Rows(iCtr).Item("IsMandatory") = True Then
                                valid = New RequiredFieldValidator
                                valid.ID = "valid" & dtMandatoryQuest.Rows(iCtr).Item("questid")
                                valid.ControlToValidate = objText.ID
                                valid.ErrorMessage = "Required"
                                valid.Width = System.Web.UI.WebControls.Unit.Pixel(50)
                                valid.Font.Size = System.Web.UI.WebControls.FontUnit.Point(8)
                                objTableCol.Controls.Add(valid)
                            End If
                            '@20220516 for Atrium Campaign-159
                            'Money Datatype are allowed in textbox
                        Case 24
                            objTablerow = New TableRow
                            objTablerow.ID = "TblRow" & dtMandatoryQuest.Rows(iCtr).Item("questid")
                            'objTablerow.BackColor = Color.LightGray
                            objTable.Rows.Add(objTablerow)
                            objTablerow.EnableViewState = True
                            objTableCol = New TableCell
                            objTablerow.Cells.Add(objTableCol)
                            objTableCol.EnableViewState = True
                            objTableCol.BackColor = System.Drawing.Color.Transparent
                            objTableCol.VerticalAlign = VerticalAlign.Top
                            objTableCol.HorizontalAlign = HorizontalAlign.Left
                            objTableCol.Width = System.Web.UI.WebControls.Unit.Percentage(40)
                            objTableCol.Attributes.Add("style", "border-bottom: solid 1px #bbd9ee")
                            objLabel = New Label
                            objTableCol.Controls.Add(objLabel)
                            objLabel.Text = dtMandatoryQuest.Rows(iCtr).Item("quest_dataheading")
                            objLabel.EnableViewState = True
                            objTableCol = New TableCell
                            objTablerow.Cells.Add(objTableCol)
                            objTableCol.BackColor = System.Drawing.Color.Transparent
                            objTableCol.VerticalAlign = VerticalAlign.Top
                            objTableCol.HorizontalAlign = HorizontalAlign.Left
                            objTableCol.Width = System.Web.UI.WebControls.Unit.Percentage(55)
                            objTableCol.Attributes.Add("style", "border-bottom: solid 1px #bbd9ee")
                            objTableCol.EnableViewState = True

                            objText = New TextBox
                            objTableCol.Controls.Add(objText)
                            'objText.Text = dt.Rows(iCtr).Item("quest_dataheading")
                            objText.Height = System.Web.UI.WebControls.Unit.Pixel(15)
                            objText.Width = System.Web.UI.WebControls.Unit.Percentage(100)
                            objText.MaxLength = 255
                            objText.Font.Size = System.Web.UI.WebControls.FontUnit.Point(8)
                            objText.BorderColor = Drawing.Color.AliceBlue
                            objText.ID = dtMandatoryQuest.Rows(iCtr).Item("questid")
                            objText.EnableViewState = True
                            objText.Attributes.Add("DisplayCriteria", dtMandatoryQuest.Rows(iCtr).Item("DisplayCriteria"))
                            objText.Attributes.Add("Sequence", dtMandatoryQuest.Rows(iCtr).Item("Sequence"))
                            objText.Visible = True

                            '  AddHandler objText.TextChanged, AddressOf TextBox1_TextChanged

                            If dtMandatoryQuest.Rows(iCtr).Item("IsMandatory") = True Then
                                valid = New RequiredFieldValidator
                                valid.ID = "valid" & dtMandatoryQuest.Rows(iCtr).Item("questid")
                                valid.ControlToValidate = objText.ID
                                valid.ErrorMessage = "Required"
                                valid.Width = System.Web.UI.WebControls.Unit.Pixel(50)
                                valid.Font.Size = System.Web.UI.WebControls.FontUnit.Point(8)

                                objTableCol.Controls.Add(valid)

                            End If


                        Case 2
                            objTablerow = New TableRow
                            objTablerow.ID = "TblRow" & dtMandatoryQuest.Rows(iCtr).Item("questid")
                            'objTablerow.BackColor = Color.LightGray
                            objTable.Rows.Add(objTablerow)
                            objTablerow.EnableViewState = True
                            objTableCol = New TableCell
                            objTablerow.Cells.Add(objTableCol)
                            objTableCol.EnableViewState = True
                            objTableCol.BackColor = System.Drawing.Color.Transparent
                            objTableCol.VerticalAlign = VerticalAlign.Top
                            objTableCol.HorizontalAlign = HorizontalAlign.Left
                            objTableCol.Width = System.Web.UI.WebControls.Unit.Percentage(40)
                            objTableCol.Attributes.Add("style", "border-bottom: solid 1px #bbd9ee")
                            objLabel = New Label
                            objTableCol.Controls.Add(objLabel)
                            objLabel.Text = dtMandatoryQuest.Rows(iCtr).Item("quest_dataheading")
                            objLabel.EnableViewState = True
                            objTableCol = New TableCell
                            objTablerow.Cells.Add(objTableCol)
                            objTableCol.BackColor = System.Drawing.Color.Transparent
                            objTableCol.VerticalAlign = VerticalAlign.Top
                            objTableCol.HorizontalAlign = HorizontalAlign.Left
                            objTableCol.Width = System.Web.UI.WebControls.Unit.Percentage(55)
                            objTableCol.Attributes.Add("style", "border-bottom: solid 1px #bbd9ee")
                            objTableCol.EnableViewState = True

                            objSelect = New DropDownList
                            objSelect.Height = System.Web.UI.WebControls.Unit.Pixel(20)
                            objSelect.Width = System.Web.UI.WebControls.Unit.Percentage(100)
                            objSelect.Font.Size = System.Web.UI.WebControls.FontUnit.Smaller
                            objSelect.ID = dtMandatoryQuest.Rows(iCtr).Item("questid")
                            objSelect.EnableViewState = True
                            Dim ans As DataTable
                            ans = dtcombodata.Select("Questid=" & dtMandatoryQuest.Rows(iCtr).Item("questid")).CopyToDataTable
                            If Not dtcombodata Is Nothing Then
                                objSelect.DataSource = ans
                                objSelect.DataTextField = "caption"
                                objSelect.DataValueField = "value"
                                'objSelect.SelectedValue = dtCustomerID.Select("WorkType=" & dt.Rows(iCtr).Item("quest_dataheading"))
                                objSelect.DataBind()
                            End If
                            objSelect.Attributes.Add("Sequence", dtMandatoryQuest.Rows(iCtr).Item("Sequence"))
                            objSelect.Attributes.Add("DisplayCriteria", dtMandatoryQuest.Rows(iCtr).Item("DisplayCriteria"))
                            '@orig
                            objSelect.Visible = True
                            objTableCol.Controls.Add(objSelect)





                            If dtMandatoryQuest.Rows(iCtr).Item("IsMandatory") = True Then
                                'If objSelect.Text.ToString() = "1936" Then
                                'CreateForm(campaignid, "PanelCRMData", customerid)
                                'lblError.Text = "Required"
                                valid = New RequiredFieldValidator
                                valid.ID = "valid" & dtMandatoryQuest.Rows(iCtr).Item("questid")
                                valid.ControlToValidate = objSelect.ID
                                valid.ErrorMessage = "Required"
                                valid.Width = System.Web.UI.WebControls.Unit.Pixel(50)
                                valid.Font.Size = System.Web.UI.WebControls.FontUnit.Point(8)
                                objTableCol.Controls.Add(valid)
                                'End If
                            End If

                            'Case 211
                            '    objTablerow = New TableRow
                            '    objTablerow.ID = "TblRow" & dtMandatoryQuest.Rows(iCtr).Item("questid")
                            '    'objTablerow.BackColor = Color.LightGray
                            '    objTable.Rows.Add(objTablerow)
                            '    objTablerow.EnableViewState = True
                            '    objTableCol = New TableCell
                            '    objTablerow.Cells.Add(objTableCol)
                            '    objTableCol.EnableViewState = True
                            '    objTableCol.BackColor = System.Drawing.Color.Transparent
                            '    objTableCol.VerticalAlign = VerticalAlign.Top
                            '    objTableCol.HorizontalAlign = HorizontalAlign.Left
                            '    objTableCol.Width = System.Web.UI.WebControls.Unit.Percentage(40)
                            '    objTableCol.Attributes.Add("style", "border-bottom: solid 1px #bbd9ee")
                            '    objLabel = New Label
                            '    objTableCol.Controls.Add(objLabel)
                            '    objLabel.Text = dtMandatoryQuest.Rows(iCtr).Item("quest_dataheading")
                            '    objLabel.EnableViewState = True
                            '    objTableCol = New TableCell
                            '    objTablerow.Cells.Add(objTableCol)
                            '    objTableCol.BackColor = System.Drawing.Color.Transparent
                            '    objTableCol.VerticalAlign = VerticalAlign.Top
                            '    objTableCol.HorizontalAlign = HorizontalAlign.Left
                            '    objTableCol.Width = System.Web.UI.WebControls.Unit.Percentage(55)
                            '    objTableCol.Attributes.Add("style", "border-bottom: solid 1px #bbd9ee")
                            '    objTableCol.EnableViewState = True

                            '    objSelect = New DropDownList
                            '    objSelect.Height = System.Web.UI.WebControls.Unit.Pixel(20)
                            '    objSelect.Width = System.Web.UI.WebControls.Unit.Percentage(100)
                            '    objSelect.Font.Size = System.Web.UI.WebControls.FontUnit.Smaller
                            '    objSelect.ID = dtMandatoryQuest.Rows(iCtr).Item("questid")
                            '    objSelect.EnableViewState = True
                            '    Dim ans As DataTable
                            '    ans = dtcombodata.Select("Questid=" & dtMandatoryQuest.Rows(iCtr).Item("questid")).CopyToDataTable
                            '    If Not dtcombodata Is Nothing Then
                            '        objSelect.DataSource = ans
                            '        objSelect.DataTextField = "caption"
                            '        objSelect.DataValueField = "value"
                            '        'objSelect.SelectedValue = dtCustomerID.Select("WorkType=" & dt.Rows(iCtr).Item("quest_dataheading"))
                            '        objSelect.DataBind()
                            '    End If
                            '    objSelect.Attributes.Add("Sequence", dtMandatoryQuest.Rows(iCtr).Item("Sequence"))
                            '    objSelect.Attributes.Add("DisplayCriteria", dtMandatoryQuest.Rows(iCtr).Item("DisplayCriteria"))
                            '    '@orig
                            '    objSelect.Visible = True
                            '    objTableCol.Controls.Add(objSelect)





                            '    If dtMandatoryQuest.Rows(iCtr).Item("IsMandatory") = True Then
                            '        'If objSelect.Text.ToString() = "1936" Then
                            '        'CreateForm(campaignid, "PanelCRMData", customerid)
                            '        'lblError.Text = "Required"
                            '        valid = New RequiredFieldValidator
                            '        valid.ID = "valid" & dtMandatoryQuest.Rows(iCtr).Item("questid")
                            '        valid.ControlToValidate = objSelect.ID
                            '        valid.ErrorMessage = "Required"
                            '        valid.Width = System.Web.UI.WebControls.Unit.Pixel(50)
                            '        valid.Font.Size = System.Web.UI.WebControls.FontUnit.Point(8)
                            '        objTableCol.Controls.Add(valid)
                            '        'End If
                            '    End If

                        Case 0
                            objTablerow = New TableRow
                            objTablerow.ID = "TblRow" & dtMandatoryQuest.Rows(iCtr).Item("questid")
                            'objTablerow.BackColor = Color.LightGray
                            objTable.Rows.Add(objTablerow)
                            objTablerow.EnableViewState = True
                            objTableCol = New TableCell
                            objTablerow.Cells.Add(objTableCol)
                            objTableCol.EnableViewState = True
                            objTableCol.BackColor = System.Drawing.Color.Transparent
                            objTableCol.VerticalAlign = VerticalAlign.Top
                            objTableCol.HorizontalAlign = HorizontalAlign.Left
                            objTableCol.Width = System.Web.UI.WebControls.Unit.Percentage(40)
                            objTableCol.Attributes.Add("style", "border-bottom: solid 1px #bbd9ee")
                            objLabel = New Label
                            objTableCol.Controls.Add(objLabel)
                            objLabel.Text = dtMandatoryQuest.Rows(iCtr).Item("quest_dataheading")
                            objLabel.EnableViewState = True
                            objTableCol = New TableCell
                            objTablerow.Cells.Add(objTableCol)
                            objTableCol.BackColor = System.Drawing.Color.Transparent
                            objTableCol.VerticalAlign = VerticalAlign.Top
                            objTableCol.HorizontalAlign = HorizontalAlign.Left
                            objTableCol.Width = System.Web.UI.WebControls.Unit.Percentage(55)
                            objTableCol.Attributes.Add("style", "border-bottom: solid 1px #bbd9ee")
                            objTableCol.EnableViewState = True

                            objText = New TextBox
                            objTableCol.Controls.Add(objText)
                            'objText.Text = dt.Rows(iCtr).Item("quest_dataheading")
                            objText.Height = System.Web.UI.WebControls.Unit.Pixel(15)
                            objText.Width = System.Web.UI.WebControls.Unit.Percentage(100)
                            objText.MaxLength = 255
                            objText.Font.Size = System.Web.UI.WebControls.FontUnit.Point(8)
                            objText.BorderColor = Drawing.Color.AliceBlue
                            objText.ID = dtMandatoryQuest.Rows(iCtr).Item("questid")
                            objText.EnableViewState = True
                            objText.ReadOnly = True
                            objText.Attributes.Add("Sequence", dtMandatoryQuest.Rows(iCtr).Item("Sequence"))
                            objText.Visible = True
                            objText.Attributes.Add("DisplayCriteria", dtMandatoryQuest.Rows(iCtr).Item("DisplayCriteria"))

                            If dtMandatoryQuest.Rows(iCtr).Item("IsMandatory") = True Then
                                valid = New RequiredFieldValidator
                                valid.ID = "valid" & dtMandatoryQuest.Rows(iCtr).Item("questid")
                                valid.ControlToValidate = objText.ID
                                valid.ErrorMessage = "Required"
                                valid.Width = System.Web.UI.WebControls.Unit.Pixel(50)
                                valid.Font.Size = System.Web.UI.WebControls.FontUnit.Point(8)
                                objTableCol.Controls.Add(valid)
                            End If
                            '@ark 20210220
                        Case 22
                            objTablerow = New TableRow
                            objTablerow.ID = "TblRow" & dtMandatoryQuest.Rows(iCtr).Item("questid")
                            'objTablerow.BackColor = Color.LightGray
                            objTable.Rows.Add(objTablerow)
                            objTablerow.EnableViewState = True
                            objTableCol = New TableCell
                            objTablerow.Cells.Add(objTableCol)
                            objTableCol.EnableViewState = True
                            objTableCol.BackColor = System.Drawing.Color.Transparent
                            objTableCol.VerticalAlign = VerticalAlign.Top
                            objTableCol.HorizontalAlign = HorizontalAlign.Left
                            objTableCol.Width = System.Web.UI.WebControls.Unit.Percentage(40)
                            objTableCol.Attributes.Add("style", "border-bottom: solid 1px #bbd9ee")
                            objLabel = New Label
                            objTableCol.Controls.Add(objLabel)
                            objLabel.Text = dtMandatoryQuest.Rows(iCtr).Item("quest_dataheading")
                            objLabel.EnableViewState = True
                            objTableCol = New TableCell
                            objTablerow.Cells.Add(objTableCol)
                            objTableCol.BackColor = System.Drawing.Color.Transparent
                            objTableCol.VerticalAlign = VerticalAlign.Top
                            objTableCol.HorizontalAlign = HorizontalAlign.Left
                            objTableCol.Width = System.Web.UI.WebControls.Unit.Percentage(55)
                            objTableCol.Attributes.Add("style", "border-bottom: solid 1px #bbd9ee")
                            objTableCol.EnableViewState = True

                            objText = New TextBox
                            objTableCol.Controls.Add(objText)
                            'objText.Text = dt.Rows(iCtr).Item("quest_dataheading")
                            objText.Height = System.Web.UI.WebControls.Unit.Pixel(15)
                            objText.Width = System.Web.UI.WebControls.Unit.Percentage(100)
                            objText.MaxLength = 255
                            objText.Font.Size = System.Web.UI.WebControls.FontUnit.Point(8)
                            objText.BorderColor = Drawing.Color.AliceBlue
                            objText.ID = dtMandatoryQuest.Rows(iCtr).Item("questid")
                            objText.EnableViewState = True
                            objText.ReadOnly = False
                            objText.Attributes.Add("Sequence", dtMandatoryQuest.Rows(iCtr).Item("Sequence"))
                            objText.Visible = True
                            objText.Attributes.Add("DisplayCriteria", dtMandatoryQuest.Rows(iCtr).Item("DisplayCriteria"))
                            'objText.Text = DateTime.Now.ToString("dd-MMM-yyyy HH:mm")
                            'UK TimeZone
                            Dim dt As DateTime
                            dt = TimeZoneInfo.ConvertTimeBySystemTimeZoneId(DateTime.UtcNow, "GMT Standard Time")
                            objText.Text = dt.ToString("dd-MMM-yyyy HH:mm")
                            If dtMandatoryQuest.Rows(iCtr).Item("IsMandatory") = True Then
                                valid = New RequiredFieldValidator
                                valid.ID = "valid" & dtMandatoryQuest.Rows(iCtr).Item("questid")
                                valid.ControlToValidate = objText.ID
                                valid.ErrorMessage = "Required"
                                valid.Width = System.Web.UI.WebControls.Unit.Pixel(50)
                                valid.Font.Size = System.Web.UI.WebControls.FontUnit.Point(8)

                                ' objText.Attributes.Add("onkeypress", "return isFutureDate(event);")
                                objTableCol.Controls.Add(valid)
                            End If

                            '@ark 20211229
                        Case 23
                            objTablerow = New TableRow
                            objTablerow.ID = "TblRow" & dtMandatoryQuest.Rows(iCtr).Item("questid")
                            'objTablerow.BackColor = Color.LightGray
                            objTable.Rows.Add(objTablerow)
                            objTablerow.EnableViewState = True
                            objTableCol = New TableCell
                            objTablerow.Cells.Add(objTableCol)
                            objTableCol.EnableViewState = True
                            objTableCol.BackColor = System.Drawing.Color.Transparent
                            objTableCol.VerticalAlign = VerticalAlign.Top
                            objTableCol.HorizontalAlign = HorizontalAlign.Left
                            objTableCol.Width = System.Web.UI.WebControls.Unit.Percentage(40)
                            objTableCol.Attributes.Add("style", "border-bottom: solid 1px #bbd9ee")
                            objLabel = New Label
                            objTableCol.Controls.Add(objLabel)
                            objLabel.Text = dtMandatoryQuest.Rows(iCtr).Item("quest_dataheading")
                            objLabel.EnableViewState = True
                            objTableCol = New TableCell
                            objTablerow.Cells.Add(objTableCol)
                            objTableCol.BackColor = System.Drawing.Color.Transparent
                            objTableCol.VerticalAlign = VerticalAlign.Top
                            objTableCol.HorizontalAlign = HorizontalAlign.Left
                            objTableCol.Width = System.Web.UI.WebControls.Unit.Percentage(55)
                            objTableCol.Attributes.Add("style", "border-bottom: solid 1px #bbd9ee")
                            objTableCol.EnableViewState = True

                            objText = New TextBox
                            objTableCol.Controls.Add(objText)
                            'objText.Text = dt.Rows(iCtr).Item("quest_dataheading")
                            objText.Height = System.Web.UI.WebControls.Unit.Pixel(15)
                            objText.Width = System.Web.UI.WebControls.Unit.Percentage(100)
                            objText.MaxLength = 255
                            objText.Font.Size = System.Web.UI.WebControls.FontUnit.Point(8)
                            objText.BorderColor = Drawing.Color.AliceBlue
                            objText.ID = dtMandatoryQuest.Rows(iCtr).Item("questid")
                            objText.EnableViewState = True
                            objText.ReadOnly = False
                            objText.Attributes.Add("Sequence", dtMandatoryQuest.Rows(iCtr).Item("Sequence"))
                            objText.Visible = True
                            objText.Attributes.Add("DisplayCriteria", dtMandatoryQuest.Rows(iCtr).Item("DisplayCriteria"))
                            objText.Text = DateTime.Now.ToString("dd-MMM-yyyy HH:mm")

                            If dtMandatoryQuest.Rows(iCtr).Item("IsMandatory") = True Then
                                valid = New RequiredFieldValidator
                                valid.ID = "valid" & dtMandatoryQuest.Rows(iCtr).Item("questid")
                                valid.ControlToValidate = objText.ID
                                valid.ErrorMessage = "Required"
                                valid.Width = System.Web.UI.WebControls.Unit.Pixel(50)
                                valid.Font.Size = System.Web.UI.WebControls.FontUnit.Point(8)

                                ' objText.Attributes.Add("onkeypress", "return isFutureDate(event);")
                                objTableCol.Controls.Add(valid)
                            End If

                        Case 25
                            objTablerow = New TableRow
                            objTablerow.ID = "TblRow" & dtMandatoryQuest.Rows(iCtr).Item("questid")
                            'objTablerow.BackColor = Color.LightGray
                            objTable.Rows.Add(objTablerow)
                            objTablerow.EnableViewState = True
                            objTableCol = New TableCell
                            objTablerow.Cells.Add(objTableCol)
                            objTableCol.EnableViewState = True
                            objTableCol.BackColor = System.Drawing.Color.Transparent
                            objTableCol.VerticalAlign = VerticalAlign.Top
                            objTableCol.HorizontalAlign = HorizontalAlign.Left
                            objTableCol.Width = System.Web.UI.WebControls.Unit.Percentage(40)
                            objTableCol.Attributes.Add("style", "border-bottom: solid 1px #bbd9ee")
                            objLabel = New Label
                            objTableCol.Controls.Add(objLabel)
                            objLabel.Text = dtMandatoryQuest.Rows(iCtr).Item("quest_dataheading")
                            objLabel.EnableViewState = True
                            objTableCol = New TableCell
                            objTablerow.Cells.Add(objTableCol)
                            objTableCol.BackColor = System.Drawing.Color.Transparent
                            objTableCol.VerticalAlign = VerticalAlign.Top
                            objTableCol.HorizontalAlign = HorizontalAlign.Left
                            objTableCol.Width = System.Web.UI.WebControls.Unit.Percentage(55)
                            objTableCol.Attributes.Add("style", "border-bottom: solid 1px #bbd9ee")
                            objTableCol.EnableViewState = True

                            objText = New TextBox
                            objTableCol.Controls.Add(objText)
                            'objText.Text = dt.Rows(iCtr).Item("quest_dataheading")
                            objText.Height = System.Web.UI.WebControls.Unit.Pixel(15)
                            objText.Width = System.Web.UI.WebControls.Unit.Percentage(100)
                            objText.MaxLength = 255
                            objText.Font.Size = System.Web.UI.WebControls.FontUnit.Point(8)
                            objText.BorderColor = Drawing.Color.AliceBlue
                            objText.ID = dtMandatoryQuest.Rows(iCtr).Item("questid")
                            objText.EnableViewState = True
                            objText.ReadOnly = False
                            objText.Attributes.Add("Sequence", dtMandatoryQuest.Rows(iCtr).Item("Sequence"))
                            objText.Visible = True
                            objText.Attributes.Add("DisplayCriteria", dtMandatoryQuest.Rows(iCtr).Item("DisplayCriteria"))
                            'objText.Text = DateTime.Now.ToString("dd-MMM-yyyy HH:mm")
                            'Eastern TimeZone
                            Dim dt As DateTime
                            dt = TimeZoneInfo.ConvertTimeBySystemTimeZoneId(DateTime.UtcNow, "Eastern Standard Time")
                            objText.Text = dt.ToString("dd-MMM-yyyy HH:mm")
                            If dtMandatoryQuest.Rows(iCtr).Item("IsMandatory") = True Then
                                valid = New RequiredFieldValidator
                                valid.ID = "valid" & dtMandatoryQuest.Rows(iCtr).Item("questid")
                                valid.ControlToValidate = objText.ID
                                valid.ErrorMessage = "Required"
                                valid.Width = System.Web.UI.WebControls.Unit.Pixel(50)
                                valid.Font.Size = System.Web.UI.WebControls.FontUnit.Point(8)

                                ' objText.Attributes.Add("onkeypress", "return isFutureDate(event);")
                                objTableCol.Controls.Add(valid)
                            End If

                            '@ark 20220619
                        Case 8
                            objTablerow = New TableRow
                            objTablerow.ID = "TblRow" & dtMandatoryQuest.Rows(iCtr).Item("questid")
                            'objTablerow.BackColor = Color.LightGray
                            objTable.Rows.Add(objTablerow)
                            objTablerow.EnableViewState = True
                            objTableCol = New TableCell
                            objTablerow.Cells.Add(objTableCol)
                            objTableCol.EnableViewState = True
                            objTableCol.BackColor = System.Drawing.Color.Transparent
                            objTableCol.VerticalAlign = VerticalAlign.Top
                            objTableCol.HorizontalAlign = HorizontalAlign.Left
                            objTableCol.Width = System.Web.UI.WebControls.Unit.Percentage(40)
                            objTableCol.Attributes.Add("style", "border-bottom: solid 1px #bbd9ee")
                            objLabel = New Label
                            objTableCol.Controls.Add(objLabel)
                            objLabel.Text = dtMandatoryQuest.Rows(iCtr).Item("quest_dataheading")
                            objLabel.EnableViewState = True
                            objTableCol = New TableCell
                            objTablerow.Cells.Add(objTableCol)
                            objTableCol.BackColor = System.Drawing.Color.Transparent
                            objTableCol.VerticalAlign = VerticalAlign.Top
                            objTableCol.HorizontalAlign = HorizontalAlign.Left
                            objTableCol.Width = System.Web.UI.WebControls.Unit.Percentage(55)
                            objTableCol.Attributes.Add("style", "border-bottom: solid 1px #bbd9ee")
                            objTableCol.EnableViewState = True

                            objText = New TextBox
                            objTableCol.Controls.Add(objText)
                            'objText.Text = dt.Rows(iCtr).Item("quest_dataheading")
                            objText.Height = System.Web.UI.WebControls.Unit.Pixel(15)
                            objText.Width = System.Web.UI.WebControls.Unit.Percentage(100)
                            objText.MaxLength = 15
                            objText.Font.Size = System.Web.UI.WebControls.FontUnit.Point(8)
                            objText.BorderColor = Drawing.Color.AliceBlue
                            objText.ID = dtMandatoryQuest.Rows(iCtr).Item("questid")
                            objText.EnableViewState = True
                            'objText.CssClass = "numeric"
                            objText.Attributes.Add("Sequence", dtMandatoryQuest.Rows(iCtr).Item("Sequence"))
                            objText.Attributes.Add("DisplayCriteria", dtMandatoryQuest.Rows(iCtr).Item("DisplayCriteria"))
                            objText.Visible = True
                            If dtMandatoryQuest.Rows(iCtr).Item("IsMandatory") = True Then
                                valid = New RequiredFieldValidator
                                valid.ID = "valid" & dtMandatoryQuest.Rows(iCtr).Item("questid")
                                valid.ControlToValidate = objText.ID
                                valid.ErrorMessage = "Required"
                                valid.Width = System.Web.UI.WebControls.Unit.Pixel(50)
                                valid.Font.Size = System.Web.UI.WebControls.FontUnit.Point(8)
                                objText.Attributes.Add("onkeypress", "return CheckNemericValue(event);")
                                objTableCol.Controls.Add(valid)
                            End If
                            'Dim numeric As New RegularExpressionValidator
                            'numeric.ValidationExpression = "^\d+$"   

                            '@ark 20230819
                        Case 111
                            objTablerow = New TableRow
                            objTablerow.ID = "TblRow" & dtMandatoryQuest.Rows(iCtr).Item("questid")
                            'objTablerow.BackColor = Color.LightGray
                            objTable.Rows.Add(objTablerow)
                            objTablerow.EnableViewState = True
                            objTableCol = New TableCell
                            objTablerow.Cells.Add(objTableCol)
                            objTableCol.EnableViewState = True
                            objTableCol.BackColor = System.Drawing.Color.Transparent
                            objTableCol.VerticalAlign = VerticalAlign.Top
                            objTableCol.HorizontalAlign = HorizontalAlign.Left
                            objTableCol.Width = System.Web.UI.WebControls.Unit.Percentage(40)
                            objTableCol.Attributes.Add("style", "border-bottom: solid 1px #bbd9ee")
                            objLabel = New Label
                            objTableCol.Controls.Add(objLabel)
                            objLabel.Text = dtMandatoryQuest.Rows(iCtr).Item("quest_dataheading")
                            objLabel.EnableViewState = True
                            objTableCol = New TableCell
                            objTablerow.Cells.Add(objTableCol)
                            objTableCol.BackColor = System.Drawing.Color.Transparent
                            objTableCol.VerticalAlign = VerticalAlign.Top
                            objTableCol.HorizontalAlign = HorizontalAlign.Left
                            objTableCol.Width = System.Web.UI.WebControls.Unit.Percentage(55)
                            objTableCol.Attributes.Add("style", "border-bottom: solid 1px #bbd9ee")
                            objTableCol.EnableViewState = True

                            objText = New TextBox
                            objTableCol.Controls.Add(objText)
                            'objText.Text = dt.Rows(iCtr).Item("quest_dataheading")
                            objText.Height = System.Web.UI.WebControls.Unit.Pixel(15)
                            objText.Width = System.Web.UI.WebControls.Unit.Percentage(100)
                            objText.MaxLength = 35
                            objText.Font.Size = System.Web.UI.WebControls.FontUnit.Point(8)
                            objText.BorderColor = Drawing.Color.AliceBlue
                            objText.ID = dtMandatoryQuest.Rows(iCtr).Item("questid")
                            objText.EnableViewState = True
                            'objText.CssClass = "numeric"
                            objText.Attributes.Add("Sequence", dtMandatoryQuest.Rows(iCtr).Item("Sequence"))
                            objText.Attributes.Add("DisplayCriteria", dtMandatoryQuest.Rows(iCtr).Item("DisplayCriteria"))
                            objText.Visible = True
                            If dtMandatoryQuest.Rows(iCtr).Item("IsMandatory") = True Then
                                valid = New RequiredFieldValidator
                                valid.ID = "valid" & dtMandatoryQuest.Rows(iCtr).Item("questid")
                                valid.ControlToValidate = objText.ID
                                valid.ErrorMessage = "Required"
                                valid.Width = System.Web.UI.WebControls.Unit.Pixel(50)
                                valid.Font.Size = System.Web.UI.WebControls.FontUnit.Point(8)
                                objText.Attributes.Add("onkeypress", "return CheckAlphaNemericValue(event);")
                                ' objText.Attributes.Add("onkeyup", "return CheckLengthvalue(event);")
                                objTableCol.Controls.Add(valid)
                            End If
                            'Dim numeric As New RegularExpressionValidator
                            'numeric.ValidationExpression = "^\d+$"
                        Case 11
                            objTablerow = New TableRow
                            objTablerow.ID = "TblRow" & dtMandatoryQuest.Rows(iCtr).Item("questid")
                            'objTablerow.BackColor = Color.LightGray
                            objTable.Rows.Add(objTablerow)
                            objTablerow.EnableViewState = True
                            objTableCol = New TableCell
                            objTablerow.Cells.Add(objTableCol)
                            objTableCol.EnableViewState = True
                            objTableCol.BackColor = System.Drawing.Color.Transparent
                            objTableCol.VerticalAlign = VerticalAlign.Top
                            objTableCol.HorizontalAlign = HorizontalAlign.Left
                            objTableCol.Width = System.Web.UI.WebControls.Unit.Percentage(40)
                            objTableCol.Attributes.Add("style", "border-bottom: solid 1px #bbd9ee")
                            objLabel = New Label
                            objTableCol.Controls.Add(objLabel)
                            objLabel.Text = dtMandatoryQuest.Rows(iCtr).Item("quest_dataheading")
                            objLabel.EnableViewState = True
                            objTableCol = New TableCell
                            objTablerow.Cells.Add(objTableCol)
                            objTableCol.BackColor = System.Drawing.Color.Transparent
                            objTableCol.VerticalAlign = VerticalAlign.Top
                            objTableCol.HorizontalAlign = HorizontalAlign.Left
                            objTableCol.Width = System.Web.UI.WebControls.Unit.Percentage(55)
                            objTableCol.Attributes.Add("style", "border-bottom: solid 1px #bbd9ee")
                            objTableCol.EnableViewState = True


                            objSelect = New DropDownList
                            objSelect.Height = System.Web.UI.WebControls.Unit.Pixel(20)
                            objSelect.Width = System.Web.UI.WebControls.Unit.Percentage(100)
                            objSelect.Font.Size = System.Web.UI.WebControls.FontUnit.Smaller
                            objSelect.ID = dtMandatoryQuest.Rows(iCtr).Item("questid")
                            objSelect.EnableViewState = True
                            Dim ans As DataTable
                            ans = dtcombodata.Select("Questid=" & dtMandatoryQuest.Rows(iCtr).Item("questid")).CopyToDataTable
                            If Not dtcombodata Is Nothing Then
                                objSelect.DataSource = ans
                                objSelect.DataTextField = "caption"
                                objSelect.DataValueField = "value"
                                'objSelect.SelectedValue = dtCustomerID.Select("WorkType=" & dt.Rows(iCtr).Item("quest_dataheading"))
                                objSelect.DataBind()
                            End If
                            objSelect.Attributes.Add("Sequence", dtMandatoryQuest.Rows(iCtr).Item("Sequence"))
                            objSelect.Attributes.Add("DisplayCriteria", dtMandatoryQuest.Rows(iCtr).Item("DisplayCriteria"))
                            objSelect.AutoPostBack = True
                            objSelect.Visible = True

                            AddHandler objSelect.SelectedIndexChanged, AddressOf DropDownSelectionChange
                            objTableCol.Controls.Add(objSelect)
                            If dtMandatoryQuest.Rows(iCtr).Item("IsMandatory") = True Then
                                valid = New RequiredFieldValidator
                                valid.ID = "valid" & dtMandatoryQuest.Rows(iCtr).Item("questid")
                                valid.ControlToValidate = objSelect.ID
                                valid.ErrorMessage = "Required"
                                valid.Width = System.Web.UI.WebControls.Unit.Pixel(50)
                                valid.Font.Size = System.Web.UI.WebControls.FontUnit.Point(8)
                                objTableCol.Controls.Add(valid)
                            End If


                        Case 12
                            objTablerow = New TableRow
                            objTablerow.ID = "TblRow" & dtMandatoryQuest.Rows(iCtr).Item("questid")
                            'objTablerow.BackColor = Color.LightGray
                            objTable.Rows.Add(objTablerow)
                            objTablerow.EnableViewState = True
                            objTableCol = New TableCell
                            objTablerow.Cells.Add(objTableCol)
                            objTableCol.EnableViewState = True
                            objTableCol.BackColor = System.Drawing.Color.Transparent
                            objTableCol.VerticalAlign = VerticalAlign.Top
                            objTableCol.HorizontalAlign = HorizontalAlign.Left
                            objTableCol.Width = System.Web.UI.WebControls.Unit.Percentage(40)
                            objTableCol.Attributes.Add("style", "border-bottom: solid 1px #bbd9ee")
                            objLabel = New Label
                            objTableCol.Controls.Add(objLabel)
                            objLabel.Text = dtMandatoryQuest.Rows(iCtr).Item("quest_dataheading")
                            objLabel.EnableViewState = True
                            objTableCol = New TableCell
                            objTablerow.Cells.Add(objTableCol)
                            objTableCol.BackColor = System.Drawing.Color.Transparent
                            objTableCol.VerticalAlign = VerticalAlign.Top
                            objTableCol.HorizontalAlign = HorizontalAlign.Left
                            objTableCol.Width = System.Web.UI.WebControls.Unit.Percentage(55)
                            objTableCol.Attributes.Add("style", "border-bottom: solid 1px #bbd9ee")
                            objTableCol.EnableViewState = True



                            abc = New UserControl
                            abc = Page.LoadControl("~/_assets/usrcontrol/DateTimePicker.ascx")
                            abc.ID = dtMandatoryQuest.Rows(iCtr).Item("questid")

                            'abc.FindControl()
                            abc.EnableViewState = True
                            objTableCol.Controls.Add(abc)


                            'Dim datevalid As New RegularExpressionValidator
                            'datevalid.ID = "datevalid" & dtMandatoryQuest.Rows(iCtr).Item("questid")
                            'datevalid.ControlToValidate = abc.ID
                            'datevalid.ValidationExpression = "^\d[0-9]{2}-[a-zA-Z]{3}-\d{4}$"
                            'datevalid.ErrorMessage = "Date is not valid"
                            'datevalid.Width = System.Web.UI.WebControls.Unit.Pixel(50)
                            'datevalid.Font.Size = System.Web.UI.WebControls.FontUnit.Point(8)
                            'objTableCol.Controls.Add(datevalid)



                        Case 17 '------ is a calculate field
                            Dim row As DataRow = dtcalculate.NewRow
                            row(0) = dtMandatoryQuest.Rows(iCtr).Item("questid")
                            dtcalculate.Rows.Add(row)

                        Case 20
                            objTablerow = New TableRow
                            objTablerow.ID = "TblRow" & dtMandatoryQuest.Rows(iCtr).Item("questid")
                            'objTablerow.BackColor = Color.LightGray
                            objTable.Rows.Add(objTablerow)
                            objTablerow.EnableViewState = True
                            objTableCol = New TableCell
                            objTablerow.Cells.Add(objTableCol)
                            objTableCol.EnableViewState = True
                            objTableCol.BackColor = System.Drawing.Color.Transparent
                            objTableCol.VerticalAlign = VerticalAlign.Top
                            objTableCol.HorizontalAlign = HorizontalAlign.Left
                            objTableCol.Width = System.Web.UI.WebControls.Unit.Percentage(40)
                            objTableCol.Attributes.Add("style", "border-bottom: solid 1px #bbd9ee")
                            objLabel = New Label
                            objTableCol.Controls.Add(objLabel)
                            objLabel.Text = dtMandatoryQuest.Rows(iCtr).Item("quest_dataheading")
                            objLabel.EnableViewState = True
                            objTableCol = New TableCell
                            objTablerow.Cells.Add(objTableCol)
                            objTableCol.BackColor = System.Drawing.Color.Transparent
                            objTableCol.VerticalAlign = VerticalAlign.Top
                            objTableCol.HorizontalAlign = HorizontalAlign.Left
                            objTableCol.Width = System.Web.UI.WebControls.Unit.Percentage(55)
                            objTableCol.Attributes.Add("style", "border-bottom: solid 1px #bbd9ee")
                            objTableCol.EnableViewState = True

                            objText = New TextBox
                            objTableCol.Controls.Add(objText)
                            'objText.Text = dt.Rows(iCtr).Item("quest_dataheading")
                            objText.Height = System.Web.UI.WebControls.Unit.Pixel(15)
                            objText.Width = System.Web.UI.WebControls.Unit.Percentage(100)
                            objText.MaxLength = 255
                            objText.Font.Size = System.Web.UI.WebControls.FontUnit.Point(8)
                            objText.BorderColor = Drawing.Color.AliceBlue
                            objText.ID = dtMandatoryQuest.Rows(iCtr).Item("questid")
                            objText.EnableViewState = True
                            objText.Attributes.Add("DisplayCriteria", dtMandatoryQuest.Rows(iCtr).Item("DisplayCriteria"))
                            objText.Attributes.Add("Sequence", dtMandatoryQuest.Rows(iCtr).Item("Sequence"))
                            objText.Visible = True
                            If dtMandatoryQuest.Rows(iCtr).Item("IsMandatory") = True Then
                                valid = New RequiredFieldValidator
                                valid.ID = "valid" & dtMandatoryQuest.Rows(iCtr).Item("questid")
                                valid.ControlToValidate = objText.ID
                                valid.ErrorMessage = "Required"
                                valid.Width = System.Web.UI.WebControls.Unit.Pixel(50)
                                valid.Font.Size = System.Web.UI.WebControls.FontUnit.Point(8)
                                objTableCol.Controls.Add(valid)
                            End If

                        Case 21
                            objTablerow = New TableRow
                            objTablerow.ID = "TblRow" & dtMandatoryQuest.Rows(iCtr).Item("questid")
                            'objTablerow.BackColor = Color.LightGray
                            objTable.Rows.Add(objTablerow)
                            objTablerow.EnableViewState = True
                            objTableCol = New TableCell
                            objTablerow.Cells.Add(objTableCol)
                            objTableCol.EnableViewState = True
                            objTableCol.BackColor = System.Drawing.Color.Transparent
                            objTableCol.VerticalAlign = VerticalAlign.Top
                            objTableCol.HorizontalAlign = HorizontalAlign.Left
                            objTableCol.Width = System.Web.UI.WebControls.Unit.Percentage(40)
                            objTableCol.Attributes.Add("style", "border-bottom: solid 1px #bbd9ee")
                            objLabel = New Label
                            objTableCol.Controls.Add(objLabel)
                            objLabel.Text = dtMandatoryQuest.Rows(iCtr).Item("quest_dataheading")
                            objLabel.EnableViewState = True
                            objTableCol = New TableCell
                            objTablerow.Cells.Add(objTableCol)
                            objTableCol.BackColor = System.Drawing.Color.Transparent
                            objTableCol.VerticalAlign = VerticalAlign.Top
                            objTableCol.HorizontalAlign = HorizontalAlign.Left
                            objTableCol.Width = System.Web.UI.WebControls.Unit.Percentage(55)
                            objTableCol.Attributes.Add("style", "border-bottom: solid 1px #bbd9ee")
                            objTableCol.EnableViewState = True

                            objText = New TextBox
                            objTableCol.Controls.Add(objText)
                            'objText.Text = dt.Rows(iCtr).Item("quest_dataheading")
                            objText.Height = System.Web.UI.WebControls.Unit.Pixel(15)
                            objText.Width = System.Web.UI.WebControls.Unit.Percentage(100)
                            objText.MaxLength = 255
                            objText.Font.Size = System.Web.UI.WebControls.FontUnit.Point(8)
                            objText.BorderColor = Drawing.Color.AliceBlue
                            objText.ID = dtMandatoryQuest.Rows(iCtr).Item("questid")
                            objText.EnableViewState = True
                            objText.Attributes.Add("DisplayCriteria", dtMandatoryQuest.Rows(iCtr).Item("DisplayCriteria"))
                            objText.Attributes.Add("Sequence", dtMandatoryQuest.Rows(iCtr).Item("Sequence"))
                            objText.Visible = True
                            If dtMandatoryQuest.Rows(iCtr).Item("IsMandatory") = True Then
                                valid = New RequiredFieldValidator
                                valid.ID = "valid" & dtMandatoryQuest.Rows(iCtr).Item("questid")
                                valid.ControlToValidate = objText.ID
                                valid.ErrorMessage = "Required"
                                valid.Width = System.Web.UI.WebControls.Unit.Pixel(50)
                                valid.Font.Size = System.Web.UI.WebControls.FontUnit.Point(8)
                                objTableCol.Controls.Add(valid)
                            End If

                    End Select
                Next
            End If

            ' '' ''@Dynamic Checkbox for Confirmation Tribune Campaign -342 20230128
            '' ''If campaignid = 342 Then
            '' ''    objTablerow = New TableRow
            '' ''    objTablerow.ID = "TblRow" & "chkbx1"
            '' ''    'objTablerow.BackColor = Color.LightGray
            '' ''    objTable.Rows.Add(objTablerow)
            '' ''    objTablerow.EnableViewState = True
            '' ''    objTableCol = New TableCell
            '' ''    objTablerow.Cells.Add(objTableCol)
            '' ''    objTableCol.EnableViewState = True
            '' ''    objTableCol.BackColor = System.Drawing.Color.Transparent
            '' ''    objTableCol.VerticalAlign = VerticalAlign.Top
            '' ''    objTableCol.HorizontalAlign = HorizontalAlign.Left
            '' ''    objTableCol.Width = System.Web.UI.WebControls.Unit.Percentage(40)
            '' ''    objTableCol.Attributes.Add("style", "border-bottom: solid 1px #bbd9ee")
            '' ''    Dim objCB As CheckBox
            '' ''    objCB = New CheckBox
            '' ''    objCB.ID = "Chkbx123"
            '' ''    objCB.EnableViewState = True
            '' ''    objCB.Attributes.Add("DisplayCriteria", True)
            '' ''    objCB.Attributes.Add("Sequence", 1)
            '' ''    objCB.Checked = False
            '' ''    objCB.Visible = True
            '' ''    objTableCol.Controls.Add(objCB)

            '' ''    objLabel = New Label
            '' ''    objLabel.ID = "LblChkbx123"
            '' ''    objTableCol.Controls.Add(objLabel)
            '' ''    objLabel.Height = System.Web.UI.WebControls.Unit.Pixel(40)
            '' ''    objLabel.Width = System.Web.UI.WebControls.Unit.Percentage(250)
            '' ''    objLabel.Font.Size = System.Web.UI.WebControls.FontUnit.Smaller
            '' ''    objLabel.Text = "I confirm that I have examined the advertisements for the following criteria: Scaling of Fonts, Resolution of Image, sizing & balancing, Overprint issues i.e. visibility of fonts, font size, Spell check, Visual Glance Instructions and Ad Log checked thoroughly."
            '' ''    objLabel.EnableViewState = True

            '' ''    objTableCol.Controls.Add(objLabel)

            '' ''End If



            PanelCRMData.Controls.Add(objTable)
            PanelCRMData.Enabled = True
            '***************TO Get the value of controls that are created dynamically.
            SetValueInControls(dtMandatoryQuest, dtCustomerID)
            getcommentdata()
        Catch ex As Exception
            AlertMessage(ex.Message)
            'Throw ex
        Finally
            dtcombodata = Nothing
            dtCustomerID = Nothing
            dtMandatoryQuest = Nothing
        End Try
        'End If
    End Sub
    Public Sub TakeBreak()
        If Not OnBreak Then
            UpdateAgentLog(False, True)
            OnBreak = True
        Else
            UpdateAgentLog(False, False)
            OnBreak = False
        End If
    End Sub
    Private Sub UpdateAgentLog(Optional ByVal logout As Boolean = False, Optional ByVal isbreak As Boolean = False)
        Try
            conn = New SqlConnection(connCRM)
            cmd = New SqlCommand()
            cmd.Parameters.AddWithValue("CampaignId", CampaignID)
            cmd.Parameters.AddWithValue("AgentId", AgentID)
            cmd.Parameters.AddWithValue("isBreak", isbreak)
            cmd.Parameters.AddWithValue("logout", logout)
            cmd.Parameters.AddWithValue("BreakType", IIf(isbreak, BreakType, 1))
            cmd.Connection = conn
            cmd.CommandType = CommandType.StoredProcedure

            cmd.CommandText = "usp_UpdateAgentLog"
            conn.Open()
            cmd.ExecuteNonQuery()
            conn.Close()
            cmd = Nothing

        Catch ex As Exception
            AlertMessage(ex.ToString)
        Finally
            conn.Close()
        End Try
    End Sub

    Private Sub LatestTransaction()
        Dim dtLatestTransaction As New DataTable
        conn = New SqlConnection(connCRM)
        cmd = New SqlCommand()
        cmd.Parameters.AddWithValue("CampaignID", CampaignID)
        cmd.Parameters.AddWithValue("AgentID", AgentID)
        cmd.Connection = conn
        cmd.CommandType = CommandType.StoredProcedure
        cmd.CommandText = "usp_getLatestTransaction"
        adp = New SqlDataAdapter(cmd)
        adp.Fill(dtLatestTransaction)

        Dim dr As DataRow = Nothing
        If dtLatestTransaction.Rows.Count > 0 Then
            dr = dtLatestTransaction.Rows(0)
        End If
        cmd = Nothing
        adp = Nothing

        If Not dr Is Nothing Then
            If dr("ResultCode").ToString = "" Then
                AgentID = dr("AgentId")
                customerid = dr("CustomerID")
                TransID = dr("ID")

                UserID = AgentID  'Session("AgentID") '========= By Rajendra 25th Sep'13
                lblcmfid.Text = IIf(customerid = -1 Or customerid = 0, "", customerid)
                QEID = UserID

                'For Tracker Transaction
                lblError.Text = "Your previous transaction was recovered from loss. This is your previous transaction"
                '--- By Rajendra for Paused Transaction
                btPausedTransaction.Enabled = True

                'dialstate for Quality TMF filled
                'rajkumar 11-Sep-2013  start
                Dim dtDial As New DataTable
                conn = New SqlConnection(connCRM)
                cmd = New SqlCommand()
                cmd.Parameters.AddWithValue("CampaignID", CampaignID)
                cmd.Parameters.AddWithValue("CustomerID", customerid)
                cmd.Connection = conn
                cmd.CommandType = CommandType.StoredProcedure
                cmd.CommandText = "usp_getLatestDialState"
                adp = New SqlDataAdapter(cmd)
                adp.Fill(dtDial)

                Dim drDial As DataRow = Nothing
                If dtDial.Rows.Count > 0 Then
                    drDial = dtDial.Rows(0)
                End If
                cmd = Nothing
                adp = Nothing

                If Not drDial Is Nothing Then
                    If drDial("dialstate").ToString = 2 Then  'if dialstate =2 in Leadmster then it is Quality transaction
                        WorkingonTMF = True
                        '-------------------------------------------
                        'already upper there

                        If drDial.Table.Columns.Contains("TransIdTMF") Then
                            TransIDTMF = drDial("TransIdTMF")
                        End If

                        If drDial.Table.Columns.Contains("SheetID") Then
                            SheetID = drDial("SheetID")
                        End If

                        If drDial.Table.Columns.Contains("TransDate") Then
                            TransDate = drDial("TransDate")
                        End If

                        If drDial.Table.Columns.Contains("StandAloneCMF") Then
                            StandaloneCMF = drDial("StandAloneCMF")
                        End If

                        'for CMFID
                        If SheetID = 0 Then  'if it is New TMF
                            ' fillCmfList()    'set for CMF ID
                        ElseIf SheetID > 0 Then
                            If drDial.Table.Columns.Contains("CMFID") Then
                                CMFID = drDial("CMFID")
                            End If
                        Else
                            If drDial.Table.Columns.Contains("CMFID") Then
                                CMFID = drDial("CMFID")
                            End If
                        End If

                        ''No need below ,,,,done upper
                        'If (Not drDial("CMFID") Is Nothing) And (drDial("CMFID") <> 0) Then  ' if exists then it will override the CMFID upper value 
                        '    CMFID = drDial("CMFID")
                        '    ' ddlCMFList.SelectedValue = CMFID
                        'End If
                        ''------------------------------------------
                    Else  'i.e dialstate is 0 or 1

                    End If    'for drDial("dialstate").ToString = 2
                    'rajkumar 11-Sep-2013 end
                End If     'for Not drDial Is Nothing
            End If         'for dr("ResultCode").ToString = "" 

        Else   ''dr is nothing
            lblError.Text = ""
        End If          'for Not dr Is Nothing
        dtLatestTransaction = Nothing
    End Sub


    Private Sub AgentCurrentStatus()
        Dim dtAgentStatus As New DataTable
        conn = New SqlConnection(connCRM)
        cmd = New SqlCommand()
        cmd.Parameters.AddWithValue("CampaignID", CampaignID)
        cmd.Parameters.AddWithValue("AgentID", AgentID)
        cmd.Connection = conn
        cmd.CommandType = CommandType.StoredProcedure
        cmd.CommandText = "usp_getAgentBreakStatus"
        adp = New SqlDataAdapter(cmd)
        adp.Fill(dtAgentStatus)
        Dim dr As DataRow = dtAgentStatus.Rows(0)
        cmd = Nothing
        adp = Nothing
        If Not dr Is Nothing Then
            OnBreak = dr("isBreak")
        End If
        dtAgentStatus = Nothing
    End Sub

#End Region

#Region "--- Events ---"
    'Protected Sub DropDownSelectionChange2(ByVal sender As Object, ByVal e As System.EventArgs)
    '    If (sender.Id <> "") Then
    '        FirstSelectedAnsText = sender.SelectedItem.Text
    '        FirstSelectedAnsID = sender.SelectedValue


    '    End If

    'End Sub

    Private Sub OpenDialog()
        Dim str As String
        str = "$('#DialogBackground').height($(document).height()-2);$('#DialogBackground').width($(window).width());$('#DialogBackground').css('visibility','visible');$('#pnlDropDownLists').css('visibility','visible'); $('#pnlDropDownLists').css('left',($(window).width() - $('#pnlDropDownLists').width())/2); "
        ScriptManager.RegisterStartupScript(Page, Page.[GetType](), "Movedialog", str, True)
    End Sub
    Protected Sub TextBox1_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs)

        'If objText.Text.Length = 3 Or 6 Or 9 Or 12 Or 15 Or 18 Or 21 Then
        '    objText.Text = objText.Text & ","
        'End If


    End Sub
    Protected Sub DropDownSelectionChange(ByVal sender As Object, ByVal e As System.EventArgs)
        '@Orig
        ' ChangeControlsVisiblity(sender.ID, sender.SelectedItem.Text, sender.Attributes("Sequence"), sender.SelectedValue)


        ' 371 -R1RCM ,361 -Jamesvillas 341-love holiday 362-coxoID

        If CampaignID = "371" Or CampaignID = "361" Then

            'ChangeControlsVisiblity3(sender.ID, sender.SelectedItem.Text, sender.Attributes("Sequence"), sender.SelectedValue)
            'ChangeControlsVisiblity2(sender.Attributes("Sequence"), sender.SelectedItem.Text, sender.SelectedValue)

            ' OpenDialog()

            popup.Show()
            ddlsubworkType.Items.Clear()
            ddlsubworkType.DataSource = FillControlsVisiblity(sender.ID, sender.SelectedItem.Text, sender.Attributes("Sequence"), sender.SelectedValue)

            ddlsubworkType.DataTextField = "caption"
            ddlsubworkType.DataValueField = "value"
            ddlsubworkType.DataBind()

        Else
            ChangeControlsVisiblity(sender.ID, sender.SelectedItem.Text, sender.Attributes("Sequence"), sender.SelectedValue)
        End If


        'If CampaignID = "341" Then 'Love Holiday
        '    ChangeControlsVisiblity3(sender.ID, sender.SelectedItem.Text, sender.Attributes("Sequence"), sender.SelectedValue)
        '    '  ChangeControlsVisiblity2(sender.Attributes("Sequence"), sender.SelectedItem.Text, sender.SelectedValue)

        'ElseIf CampaignID = "371" Then ' 371 -R1RCM ,361 -Jamesvillas
        '    ChangeControlsVisiblity3(sender.ID, sender.SelectedItem.Text, sender.Attributes("Sequence"), sender.SelectedValue)


        'Else
        '    ChangeControlsVisiblity(sender.ID, sender.SelectedItem.Text, sender.Attributes("Sequence"), sender.SelectedValue)
        'End If
    End Sub





    Protected Sub btSearch_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btSearch.Click
        If CampaignID = 341 Then
            GetData()

        End If

    End Sub


    Protected Sub btsave_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btsave.Click




        If ddlDisposition.SelectedValue <> 0 Then
            'Dim ISError As Boolean = False
            Try
                If WorkingonTMF = False Then

                    '@2022-01-21 Atrium start
                    If CampaignID = "159" Then
                        Dim dtCustomerID As New DataTable


                        conn = New SqlConnection(connLeads)
                        cmd = New SqlCommand()
                        cmd.Parameters.AddWithValue("leadid", customerid)
                        cmd.Parameters.AddWithValue("agentid", AgentID)
                        cmd.Connection = conn
                        cmd.CommandType = CommandType.StoredProcedure
                        cmd.CommandText = "usp_getLidtoDial" & CampaignID
                        adp = New SqlDataAdapter(cmd)
                        adp.Fill(dtCustomerID)
                        cmd = Nothing
                        adp = Nothing
                        '--------------


                        If ((dtCustomerID.Rows(0).Item("Ques1590007").ToString().Trim().ToLower() = "declarations") And (ddlDisposition.SelectedValue = "470")) Then

                            ScriptManager.RegisterStartupScript(UpdatePanel5, UpdatePanel5.GetType(), "alertMessage", "CheckIsRepeat(UpdatePanel5.GetType());", True)
                            'ScriptManager.RegisterClientScriptBlock(this, typeof(Page), "uniqueId" + Guid.NewId(), "<script>alert('hello');</script>", false);
                            ' ScriptManager.RegisterStartupScript(Me.UpdatePanel5, GetType(Page), "uniqueId" + Guid.NewGuid().ToString(), "<script>alert('hello');</script>", False)


                        ElseIf ((dtCustomerID.Rows(0).Item("Ques1590007").ToString().Trim().ToLower() = "slip") And (ddlDisposition.SelectedValue = "470")) Then

                            ScriptManager.RegisterStartupScript(UpdatePanel5, UpdatePanel5.GetType(), "alertMessage", "CheckIsRepeat(UpdatePanel5.GetType());", True)

                        ElseIf ((dtCustomerID.Rows(0).Item("Ques1590007").ToString().Trim().ToLower() = "declarations") And (ddlDisposition.SelectedValue = "471")) Then

                            ScriptManager.RegisterStartupScript(UpdatePanel5, UpdatePanel5.GetType(), "alertMessage", "CheckIsRepeat(UpdatePanel5.GetType());", True)

                        ElseIf ((dtCustomerID.Rows(0).Item("Ques1590007").ToString().Trim().ToLower() = "slip") And (ddlDisposition.SelectedValue = "471")) Then

                            ScriptManager.RegisterStartupScript(UpdatePanel5, UpdatePanel5.GetType(), "alertMessage", "CheckIsRepeat(UpdatePanel5.GetType());", True)


                        ElseIf ((dtCustomerID.Rows(0).Item("Ques1590007").ToString().Trim().ToLower() = "dec") And (ddlDisposition.SelectedValue = "470")) Then

                            ScriptManager.RegisterStartupScript(UpdatePanel5, UpdatePanel5.GetType(), "alertMessage", "CheckIsRepeat(UpdatePanel5.GetType());", True)


                        ElseIf ((dtCustomerID.Rows(0).Item("Ques1590007").ToString().Trim().ToLower() = "dec") And (ddlDisposition.SelectedValue = "471")) Then
                            ScriptManager.RegisterStartupScript(UpdatePanel5, UpdatePanel5.GetType(), "alertMessage", "CheckIsRepeat(UpdatePanel5.GetType());", True)


                        End If
                    End If
                    '@2022-01-21 Atrium end


                    sender.enabled = False
                    '@2022-02-03 R1-371 Jamesvillas-361
                    If CampaignID = "371" Or CampaignID = "361" Then
                        FindControlValues3(CampaignID, TransID)
                    Else

                        FindControlValues(CampaignID, TransID)
                    End If



                    '@test
                    ' ''If CampaignID = 342 Then
                    ' ''    If ddlDisposition.SelectedValue = "5157" Then
                    ' ''        If Not PanelCRMData.FindControl("3420017") Is Nothing Then
                    ' ''            If PanelCRMData.FindControl("3420017").ID And PanelCRMData.FindControl("3420017").Visible Then


                    ' ''                Dim numericValue As Integer = 0
                    ' ''                conn = New SqlConnection(connCRM)
                    ' ''                cmd = New SqlCommand()
                    ' ''                cmd.Connection = conn
                    ' ''                cmd.CommandType = CommandType.Text
                    ' ''                cmd.CommandText = "SELECT B.AnsID,C.Description FROM tbl_Config_Questions A INNER JOIN tbl_Config_QuestAnsMaps B ON A.QuestID = B.QuestID INNER JOIN tbl_Config_Answers C ON B.AnsID=C.AnsID WHERE A.CampaignID=" & CampaignID & " AND C.Description='" & Value & "' AND A.Questid= "
                    ' ''                conn.Open()
                    ' ''                numericValue = CInt(cmd.ExecuteScalar())
                    ' ''                conn.Close()
                    ' ''                cmd = Nothing
                    ' ''                If numericValue <> 0 Then
                    ' ''                    CType(PanelCRMData.FindControl("3420017"), DropDownList).SelectedValue = numericValue  'numericValue


                    ' ''                End If

                    ' ''            End If
                    ' ''        End If
                    ' ''    End If
                    ' ''End If
                    '    If Not PanelCRMData.FindControl("TblRowchkbx1") Is Nothing Then
                    '        If PanelCRMData.FindControl("TblRowchkbx1").ID = "TblRowchkbx1" Then
                    '            If Not CType(PanelCRMData.FindControl("chkbx123"), CheckBox).Checked Then
                    '                ' AlertMessage("Please Select  agreement then only to save")
                    '                'ScriptManager.RegisterStartupScript(PanelCRMData, PanelCRMData.GetType(), "alertMessage", "CheckIsRepeat(PanelCRMData.GetType());", True)
                    '                'Dim msg As String = ""
                    '                'msg = "I confirm that I have examined the advertisements for the following criteria: Scaling of Fonts, Resolution of Image, sizing & balancing, Overprint issues i.e. visibility of fonts, font size, Spell check, Visual Glance Instructions and Ad Log checked thoroughly. !!!"
                    '                'ScriptManager.RegisterStartupScript(Me, Me.[GetType](), "message", "<script language='javascript'>alert('" + msg.Replace("'", "\'") + "');</script>", True)
                    '                lblError_Tribune.Visible = True
                    '                lblError_Tribune.Text = "Please Select  agreement then only to save"
                    '                ' CType(PanelCRMData.FindControl("LblChkbx1234"), Label).Text = "Please Select  agreement then only to save"

                    '                Exit Sub
                    '            End If
                    '        End If
                    '    End If
                    'Else

                    '    lblError_Tribune.Visible = False


                    '@test 342 Tribue checkbox
                    'If CampaignID = 342 Then
                    '    If chbxTribune342.Checked = False Then
                    '        AlertMessage("Please tick Checkboxes")
                    '        Exit Sub
                    '    End If
                    'End If




                    If dateflag = True Then
                        DateValidation.Value = "true"

                        If CampaignID = 341 Then
                            EndTransaction()
                        End If


                        sender.enabled = True
                        customerid = Nothing
                        TransID = Nothing
                    Else
                        btsave.Enabled = True
                        DateValidation.Value = "false"
                    End If

                Else  '' If WorkingonTMF =True
                    If IsTMFLock() = False Then  'ie no other QE is working on this.
                        sender.enabled = False
                        If SaveTMFdata() = True Then
                            EndTransaction()
                            customerid = Nothing
                            TransID = Nothing
                        End If
                        sender.enabled = True
                    Else
                        'same as canceltransaction() but not having below redirect url.
                        deletetransaction()
                        customerid = Nothing
                        TransID = Nothing
                        'Response.Redirect("~/Tracker/NewTracker.aspx?CampaignID=" & CampaignID & "&AgentId=" & AgentID & "&AgentName=" & AgentName & "&IsVerifier=" & IsVerifier)
                        btNewTransactionAssisted.Enabled = True
                        btNewTransactionAmadeus.Enabled = True
                        btNewTransactionInResort.Enabled = True
                        btNewTransactionPostTravel.Enabled = True
                        btNewTransactionMMB.Enabled = True
                        btNewTransactionMMBKustomer.Enabled = True
                        btNewTransactionMMBDE.Enabled = True
                        btNewTransactionCSChat.Enabled = True
                        btNewTransactionCSVoice.Enabled = True
                        btnNewTransactionCreditControl.Enabled = True
                        btnNewTransactionSupplierrelocation.Enabled = True
                        btnNewTransactionCustomerServiceInbox.Enabled = True
                        btnNewTransactionAssistedRyanAir.Enabled = True
                        btnNewTransactionRefundTask.Enabled = True
                        btnNewTransactionOtherWorkType.Enabled = True

                        AlertMessage("Other QE has saved this TMF.") 'other QE is working on this.
                    End If

                End If

                If CampaignID = "371" Or CampaignID = "361" Then
                    ddlsubworkType.Items.Clear()
                    popup.Hide()
                End If



            Catch ex As Exception
                'ISError = True
                Dim MailTo As String
                Dim strSubject As String
                Dim strFrom As String
                Dim DisplayName As String
                MailTo = System.Configuration.ConfigurationManager.AppSettings("BCC") '"jatint@niitsmartserve.com,RajendraR_nss@niitsmartserve.com,Gauravs@niitsmartserve.com"
                ' MailTo = "rajkumar.sharma@niit-tech.com"
                strSubject = "Transaction Tracker Error"
                strFrom = System.Configuration.ConfigurationManager.AppSettings("FROM")
                DisplayName = "Web Tracker Error"
                ' Dim objWSMail As New MailSendServiceXX.Service1SoapClient
                Dim strMailBody As String
                strMailBody = ex.ToString & vbCrLf & "<br/> Agent Id :- " & AgentID & "<br/> Agent Name :-" & AgentName & " <br/> Transaction Id :-" & TransID & "<br/> CustomerId :-" & customerid & "<br/> CampaignId :-" & CampaignID
                '  objWSMail.MailSendNewTech(MailTo, strSubject, strFrom, DisplayName, strMailBody, "", "", "", "")

                Common.SMTPSendMail(MailTo, strSubject, "Terms Monitor  <" & strFrom & ">", strMailBody, System.Configuration.ConfigurationManager.AppSettings("WSR_PIP_ProcessManager"), System.Configuration.ConfigurationManager.AppSettings("WSR_PIP_ProcessManager"))
                'AlertMessage(ex.Message)
                lblError.Text = ex.ToString
                lblErrorTMF.Text = ex.ToString
            End Try
            'CType(PanelCRMData.FindControl("HiddenSaveclick"), HiddenField).Value += 1
            'Saveclick += 1
            'If Not ISError Then           
            If dateflag = True Then
                Response.Redirect("~/Tracker/NewTrackerLH.aspx?CampaignID=" & CampaignID & "&AgentId=" & AgentID & "&AgentName=" & AgentName & "&IsVerifier=" & IsVerifier)
            End If
        End If
        'Else
        'AlertMessage("Please do not click multiple times")

        'End If
    End Sub
    Protected Sub btcancel_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btcancel.Click
        CancelTransaction()
        If CampaignID = "371" Or CampaignID = "361" Then
            ddlsubworkType.Items.Clear()
            popup.Hide()
        End If
    End Sub
    Protected Sub btnCMFClose_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnCMFCose.Click

        CMFCloseTransaction()

    End Sub
    Private Sub CMFCloseTransaction()
        ' Response.Redirect("~/Tracker/NewTracker.aspx?CampaignID=" & CampaignID & "&AgentId=" & AgentID & "&AgentName=" & AgentName & "&IsVerifier=" & IsVerifier)
        'btNewTransactionAssisted.Enabled = True
        'Dim str As String
        'If Request.Browser.Type.Contains("IE") Then
        '    str = "window.open('', '_self','');window.close(); "
        'Else
        '    str = "window.open('', '_self','');window.close(); "
        'End If

        'ScriptManager.RegisterStartupScript(Page, Page.GetType(), "OpenWindow", str, True)
        CancelTransaction()

    End Sub

    Private Sub CancelTransaction()
        deletetransaction()
        customerid = Nothing
        TransID = Nothing
        Response.Redirect("~/Tracker/NewTrackerLH.aspx?CampaignID=" & CampaignID & "&AgentId=" & AgentID & "&AgentName=" & AgentName & "&IsVerifier=" & IsVerifier)
        btNewTransactionAssisted.Enabled = True
        btNewTransactionAmadeus.Enabled = True
        btNewTransactionInResort.Enabled = True
        btNewTransactionPostTravel.Enabled = True
        btNewTransactionMMB.Enabled = True
        btNewTransactionMMBKustomer.Enabled = True
        btNewTransactionMMBDE.Enabled = True
        btNewTransactionCSChat.Enabled = True
        btNewTransactionCSVoice.Enabled = True
        btnNewTransactionCreditControl.Enabled = True
        btnNewTransactionSupplierrelocation.Enabled = True
        btnNewTransactionCustomerServiceInbox.Enabled = True
        btnNewTransactionAssistedRyanAir.Enabled = True
        btnNewTransactionRefundTask.Enabled = True
        btnNewTransactionOtherWorkType.Enabled = True

    End Sub

    Protected Sub btbreak_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btbreak.Click
        Try
            If ISbreaktype = True Then
                If btbreak.Text = "Take Break" Then

                    showbreaktype()
                    OpenBreakPopup()
                    btbreak.ToolTip = "Take Break"
                    '------------------ By Rajendra 
                    If OnBreak Then
                        btbreak.Enabled = True
                        btPausedTransaction.Enabled = False

                    End If
                    pnlPaused.Visible = False
                ElseIf btbreak.Text = "End Break" Then

                    OnBreak = True
                    TakeBreak()
                    'Session("Onbreak") = False
                    OnBreak = False
                    btbreak.Text = "End Break"
                    btbreak.ToolTip = "End Break"
                    '------------------ By Rajendra                    
                    If OnBreak = False Then
                        Showbreak.Visible = False
                        btPausedTransaction.Enabled = True

                    End If
                    If Paused = 1 Then
                        pnlPaused.Visible = True
                    ElseIf Paused = 2 Then
                    Else
                        Response.Redirect("~/Tracker/NewTrackerLH.aspx?CampaignID=" & CampaignID & "&AgentId=" & AgentID & "&AgentName=" & AgentName & "&IsVerifier=" & IsVerifier)
                    End If
                End If
            Else
                BreakType = 0
                break()
            End If
        Catch ex As Exception
            AlertMessage(ex.Message)
        End Try
    End Sub
    Protected Sub btexit_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btexit.Click
        If btexit.Text = "Log Out" Then
            UpdateAgentLog(True)
            Response.Redirect("~/Tracker/Login.aspx")
        ElseIf btexit.Text = "Log In" Then
            'CampaignID = 159
            UpdateAgentLog()
            btbreak.Enabled = True
            btexit.Text = "Log Out"
            If LeadsBased Then
                If CampaignID = 342 Then
                    GetData()

                End If


                getsearch()
                fillProcess()
            End If
            pnlshowlist.Visible = True
            pnlshowtracker.Visible = False
            ''-----------------------------a little change in below
            'PanelCRMData.Visible = False
            'pnlComment.Visible = False
            'pnlCMFBody.Visible = False
            ''-----------------------------------
            Showbreak.Visible = False
            btAgentStat.Enabled = True
            btexit.Enabled = True
        End If
    End Sub

    Protected Sub btnAgentAllocationsave_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnAgentAllocationsave.Click
        Try


            If CampaignID = 341 Then

                GetData()

            End If


        Catch ex As Exception
            AlertMessage(ex.Message)
        End Try
    End Sub

    Protected Sub btnAtriumStatusUpdate_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnAtriumStatusUpdate.Click
        Try


            If CampaignID = 342 Then

                GetData()

            End If



        Catch ex As Exception
            AlertMessage(ex.Message)
        End Try
    End Sub

    Protected Sub cmbOutcome_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmbOutcome.SelectedIndexChanged
        If CampaignID <> "159" Then
            GetData()
        Else
            GetData_Atrium()
        End If

    End Sub

    Protected Sub btnBreakType_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnBreakType.Click
        BreakType = cboBreaktype.SelectedValue
        OnBreak = False
        TakeBreak()
        'Session("Onbreak") = True
        OnBreak = True
        btbreak.Text = "End Break"
        Showbreak.Visible = True
        pnlshowlist.Visible = False
        pnlshowtracker.Visible = False
        ''-----------------------------a little change in below
        'PanelCRMData.Visible = False
        'pnlComment.Visible = False
        'pnlCMFBody.Visible = False
        ''-----------------------------------
        btNewTransactionAssisted.Enabled = False
        btNewTransactionAmadeus.Enabled = False
        btNewTransactionInResort.Enabled = False
        btNewTransactionPostTravel.Enabled = False
        btNewTransactionMMB.Enabled = False
        btNewTransactionMMBKustomer.Enabled = False
        btNewTransactionMMBDE.Enabled = False
        btNewTransactionCSChat.Enabled = False
        btNewTransactionCSVoice.Enabled = False
        btnNewTransactionCreditControl.Enabled = False
        btnNewTransactionSupplierrelocation.Enabled = False
        btnNewTransactionCustomerServiceInbox.Enabled = False
        btnNewTransactionAssistedRyanAir.Enabled = False
        btnNewTransactionRefundTask.Enabled = False
        btnNewTransactionOtherWorkType.Enabled = False

        btexit.Enabled = False
        '------------------ By Rajendra 
        If OnBreak Then
            btbreak.Enabled = True
            btPausedTransaction.Enabled = False
        End If
        pnlPaused.Visible = False
    End Sub
    Protected Sub btAgentStat_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btAgentStat.Click
        OpenAgentStatPopup()

        Dim dtAgentStats As New DataTable
        Try
            conn = New SqlConnection(connreport)
            cmd = New SqlCommand()
            cmd.Parameters.AddWithValue("monthly", "N")
            cmd.Parameters.AddWithValue("Agent_Id", AgentID)
            cmd.Parameters.AddWithValue("vcCampaign", CampaignID)
            cmd.Connection = conn
            cmd.CommandType = CommandType.StoredProcedure


            cmd.CommandText = "usp_agentstats_old"
            adp = New SqlDataAdapter(cmd)
            adp.Fill(dtAgentStats)
            cmd = Nothing
            adp = Nothing

            gdAgentStat.DataSource = dtAgentStats
            gdAgentStat.DataBind()
            gdAgentStat.Visible = True
            ddlAgents.Visible = False
            cmbSearch.Visible = False
            cmbOutcome.Visible = False

        Catch ex As Exception
            AlertMessage(ex.Message)
        Finally
            dtAgentStats = Nothing
        End Try
    End Sub
    Protected Sub ImgCloseStat_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImgCloseStat.Click
        gdAgentStat.DataSource = Nothing
        gdAgentStat.Visible = False
        ddlAgents.Visible = True
        cmbSearch.Visible = True
        cmbOutcome.Visible = True
    End Sub
    Protected Sub hlHoliday_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles hlHoliday.Click
        Response.Redirect("~/Tracker/Holidays.aspx")
    End Sub
    Protected Sub hlReopen_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles hlReopen.Click
        Response.Redirect("~/Tracker/ReopenCases.aspx?CampaignID=" & CampaignID & "&AgentId=" & AgentID & "&AgentName=" & AgentName & "&IsVerifier=" & IsVerifier & "&DailStateBased=" & DailStateBased)
    End Sub
    Protected Sub ddlProcess_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ddlProcess.SelectedIndexChanged
        fillAgents(ddlProcess.SelectedValue)
    End Sub
 
    Protected Sub btNewTransactionAssisted_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btNewTransactionAssisted.Click
        WorkingonTMF = False

        If WorkingonTMF = False Then

            Ltworktype.Text = "Transaction Detail :- " + m_strAssisted
            Assisted = m_strAssisted
            CreateForm(CampaignID, "PanelCRMData", 0, Assisted)
            changeControlsVisiblityAtFirstTime()
            insertTransaction()
            FillDispostions(CampaignID)
            txtnewcomments.Text = ""

            pnlshowtracker.Visible = True
            '-------------------------------------------------
            If WorkingonTMF = False Then
                PanelCRMData.Visible = True
                pnlComment.Visible = True
                pnlCMFBody.Visible = False
                btPausedTransaction.Enabled = True '---- By Rajendra 2013-09-27
                btbreak.Enabled = False
                btbreak.CausesValidation = False
            Else
                PanelCRMData.Visible = False
                pnlComment.Visible = False
                pnlCMFBody.Visible = True

            End If
            '---------------------------------------------
            pnlshowlist.Visible = False
            Showbreak.Visible = False
            'btbreak.Enabled = False
            btexit.Enabled = False
            btAgentStat.Enabled = False
            btNewTransactionAssisted.Enabled = False
            btNewTransactionAmadeus.Enabled = False
            btNewTransactionInResort.Enabled = False
            btNewTransactionPostTravel.Enabled = False
            btNewTransactionMMB.Enabled = False
            btNewTransactionMMBKustomer.Enabled = False
            btNewTransactionMMBDE.Enabled = False
            btNewTransactionCSChat.Enabled = False
            btNewTransactionCSVoice.Enabled = False
            btnNewTransactionCreditControl.Enabled = False
            btnNewTransactionSupplierrelocation.Enabled = False
            btnNewTransactionCustomerServiceInbox.Enabled = False
            btnNewTransactionAssistedRyanAir.Enabled = False
            btnNewTransactionRefundTask.Enabled = False
            btnNewTransactionOtherWorkType.Enabled = False

        End If

    End Sub

    Protected Sub btNewTransactionAmadeus_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btNewTransactionAmadeus.Click
        WorkingonTMF = False

        If WorkingonTMF = False Then

            Ltworktype.Text = "Transaction Detail :- " + m_strAmadeus
            Amadeus = m_strAmadeus
            CreateForm(CampaignID, "PanelCRMData", 0, Amadeus)
            changeControlsVisiblityAtFirstTime()
            insertTransaction()
            FillDispostions(CampaignID)
            txtnewcomments.Text = ""

            pnlshowtracker.Visible = True
            '-------------------------------------------------
            If WorkingonTMF = False Then
                PanelCRMData.Visible = True
                pnlComment.Visible = True
                pnlCMFBody.Visible = False
                btPausedTransaction.Enabled = True '---- By Rajendra 2013-09-27
                btbreak.Enabled = False
                btbreak.CausesValidation = False
            Else
                PanelCRMData.Visible = False
                pnlComment.Visible = False
                pnlCMFBody.Visible = True

            End If
            '---------------------------------------------
            pnlshowlist.Visible = False
            Showbreak.Visible = False
            'btbreak.Enabled = False
            btexit.Enabled = False
            btAgentStat.Enabled = False
            btNewTransactionAssisted.Enabled = False
            btNewTransactionAmadeus.Enabled = False
            btNewTransactionInResort.Enabled = False
            btNewTransactionPostTravel.Enabled = False
            btNewTransactionMMB.Enabled = False
            btNewTransactionMMBKustomer.Enabled = False
            btNewTransactionMMBDE.Enabled = False
            btNewTransactionCSChat.Enabled = False
            btNewTransactionCSVoice.Enabled = False
            btnNewTransactionCreditControl.Enabled = False
            btnNewTransactionSupplierrelocation.Enabled = False
            btnNewTransactionCustomerServiceInbox.Enabled = False
            btnNewTransactionAssistedRyanAir.Enabled = False
            btnNewTransactionRefundTask.Enabled = False
            btnNewTransactionOtherWorkType.Enabled = False

        End If

    End Sub

    Protected Sub btNewTransactionInResort_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btNewTransactionInResort.Click
        WorkingonTMF = False

        If WorkingonTMF = False Then


            Ltworktype.Text = "Transaction Detail :- " + m_strInResort
            InResort = m_strInResort
            CreateForm(CampaignID, "PanelCRMData", 0, InResort)
            changeControlsVisiblityAtFirstTime()
            insertTransaction()
            FillDispostions(CampaignID)
            txtnewcomments.Text = ""

            pnlshowtracker.Visible = True
            '-------------------------------------------------
            If WorkingonTMF = False Then
                PanelCRMData.Visible = True
                pnlComment.Visible = True
                pnlCMFBody.Visible = False
                btPausedTransaction.Enabled = True '---- By Rajendra 2013-09-27
                btbreak.Enabled = False
                btbreak.CausesValidation = False
            Else
                PanelCRMData.Visible = False
                pnlComment.Visible = False
                pnlCMFBody.Visible = True

            End If
            '---------------------------------------------
            pnlshowlist.Visible = False
            Showbreak.Visible = False
            'btbreak.Enabled = False
            btexit.Enabled = False
            btAgentStat.Enabled = False
            btNewTransactionAssisted.Enabled = False
            btNewTransactionAmadeus.Enabled = False
            btNewTransactionInResort.Enabled = False
            btNewTransactionPostTravel.Enabled = False
            btNewTransactionMMB.Enabled = False
            btNewTransactionMMBKustomer.Enabled = False
            btNewTransactionMMBDE.Enabled = False
            btNewTransactionCSChat.Enabled = False
            btNewTransactionCSVoice.Enabled = False
            btnNewTransactionCreditControl.Enabled = False
            btnNewTransactionSupplierrelocation.Enabled = False
            btnNewTransactionCustomerServiceInbox.Enabled = False
            btnNewTransactionAssistedRyanAir.Enabled = False
            btnNewTransactionRefundTask.Enabled = False
            btnNewTransactionOtherWorkType.Enabled = False

        End If

    End Sub

    Protected Sub btNewTransactionPostTravel_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btNewTransactionPostTravel.Click
        WorkingonTMF = False

        If WorkingonTMF = False Then


            Ltworktype.Text = "Transaction Detail :- " + m_strPostTravel
            PostTravel = m_strPostTravel
            CreateForm(CampaignID, "PanelCRMData", 0, PostTravel)
            changeControlsVisiblityAtFirstTime()
            insertTransaction()
            FillDispostions(CampaignID)
            txtnewcomments.Text = ""

            pnlshowtracker.Visible = True
            '-------------------------------------------------
            If WorkingonTMF = False Then
                PanelCRMData.Visible = True
                pnlComment.Visible = True
                pnlCMFBody.Visible = False
                btPausedTransaction.Enabled = True '---- By Rajendra 2013-09-27
                btbreak.Enabled = False
                btbreak.CausesValidation = False
            Else
                PanelCRMData.Visible = False
                pnlComment.Visible = False
                pnlCMFBody.Visible = True

            End If
            '---------------------------------------------
            pnlshowlist.Visible = False
            Showbreak.Visible = False
            'btbreak.Enabled = False
            btexit.Enabled = False
            btAgentStat.Enabled = False
            btNewTransactionAssisted.Enabled = False
            btNewTransactionAmadeus.Enabled = False
            btNewTransactionInResort.Enabled = False
            btNewTransactionPostTravel.Enabled = False
            btNewTransactionMMB.Enabled = False
            btNewTransactionMMBKustomer.Enabled = False
            btNewTransactionMMBDE.Enabled = False
            btNewTransactionCSChat.Enabled = False
            btNewTransactionCSVoice.Enabled = False
            btnNewTransactionCreditControl.Enabled = False
            btnNewTransactionSupplierrelocation.Enabled = False
            btnNewTransactionCustomerServiceInbox.Enabled = False
            btnNewTransactionAssistedRyanAir.Enabled = False
            btnNewTransactionRefundTask.Enabled = False
            btnNewTransactionOtherWorkType.Enabled = False

        End If

    End Sub

    Protected Sub btNewTransactionMMB_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btNewTransactionMMB.Click
        WorkingonTMF = False

        If WorkingonTMF = False Then


            
            Ltworktype.Text = "Transaction Detail :- " + m_strMMB
            MMB = m_strMMB
            CreateForm(CampaignID, "PanelCRMData", 0, MMB)
            changeControlsVisiblityAtFirstTime()
            insertTransaction()
            FillDispostions(CampaignID)
            txtnewcomments.Text = ""

            pnlshowtracker.Visible = True
            '-------------------------------------------------
            If WorkingonTMF = False Then
                PanelCRMData.Visible = True
                pnlComment.Visible = True
                pnlCMFBody.Visible = False
                btPausedTransaction.Enabled = True '---- By Rajendra 2013-09-27
                btbreak.Enabled = False
                btbreak.CausesValidation = False
            Else
                PanelCRMData.Visible = False
                pnlComment.Visible = False
                pnlCMFBody.Visible = True

            End If
            '---------------------------------------------
            pnlshowlist.Visible = False
            Showbreak.Visible = False
            'btbreak.Enabled = False
            btexit.Enabled = False
            btAgentStat.Enabled = False
            btNewTransactionAssisted.Enabled = False
            btNewTransactionAmadeus.Enabled = False
            btNewTransactionInResort.Enabled = False
            btNewTransactionPostTravel.Enabled = False
            btNewTransactionMMB.Enabled = False
            btNewTransactionMMBKustomer.Enabled = False
            btNewTransactionMMBDE.Enabled = False
            btNewTransactionCSChat.Enabled = False
            btNewTransactionCSVoice.Enabled = False
            btnNewTransactionCreditControl.Enabled = False
            btnNewTransactionSupplierrelocation.Enabled = False
            btnNewTransactionCustomerServiceInbox.Enabled = False
            btnNewTransactionAssistedRyanAir.Enabled = False
            btnNewTransactionRefundTask.Enabled = False
            btnNewTransactionOtherWorkType.Enabled = False

        End If

    End Sub

    Protected Sub btNewTransactionMMBKustomer_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btNewTransactionMMBKustomer.Click
        WorkingonTMF = False

        If WorkingonTMF = False Then



            Ltworktype.Text = "Transaction Detail :- " + m_strMMBKustomer
            MMBKustomer = m_strMMBKustomer
            CreateForm(CampaignID, "PanelCRMData", 0, MMBKustomer)
            changeControlsVisiblityAtFirstTime()
            insertTransaction()
            FillDispostions(CampaignID)
            txtnewcomments.Text = ""

            pnlshowtracker.Visible = True
            '-------------------------------------------------
            If WorkingonTMF = False Then
                PanelCRMData.Visible = True
                pnlComment.Visible = True
                pnlCMFBody.Visible = False
                btPausedTransaction.Enabled = True '---- By Rajendra 2013-09-27
                btbreak.Enabled = False
                btbreak.CausesValidation = False
            Else
                PanelCRMData.Visible = False
                pnlComment.Visible = False
                pnlCMFBody.Visible = True

            End If
            '---------------------------------------------
            pnlshowlist.Visible = False
            Showbreak.Visible = False
            'btbreak.Enabled = False
            btexit.Enabled = False
            btAgentStat.Enabled = False
            btNewTransactionAssisted.Enabled = False
            btNewTransactionAmadeus.Enabled = False
            btNewTransactionInResort.Enabled = False
            btNewTransactionPostTravel.Enabled = False
            btNewTransactionMMB.Enabled = False
            btNewTransactionMMBKustomer.Enabled = False
            btNewTransactionMMBDE.Enabled = False
            btNewTransactionCSChat.Enabled = False
            btNewTransactionCSVoice.Enabled = False
            btnNewTransactionCreditControl.Enabled = False
            btnNewTransactionSupplierrelocation.Enabled = False
            btnNewTransactionCustomerServiceInbox.Enabled = False
            btnNewTransactionAssistedRyanAir.Enabled = False
            btnNewTransactionRefundTask.Enabled = False
            btnNewTransactionOtherWorkType.Enabled = False

        End If

    End Sub

    Protected Sub btNewTransactionMMBDE_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btNewTransactionMMBDE.Click
        WorkingonTMF = False

        If WorkingonTMF = False Then



            Ltworktype.Text = "Transaction Detail :- " + m_strMMBDE
            MMBKustomer = m_strMMBDE
            CreateForm(CampaignID, "PanelCRMData", 0, MMBKustomer)
            changeControlsVisiblityAtFirstTime()
            insertTransaction()
            FillDispostions(CampaignID)
            txtnewcomments.Text = ""

            pnlshowtracker.Visible = True
            '-------------------------------------------------
            If WorkingonTMF = False Then
                PanelCRMData.Visible = True
                pnlComment.Visible = True
                pnlCMFBody.Visible = False
                btPausedTransaction.Enabled = True '---- By Rajendra 2013-09-27
                btbreak.Enabled = False
                btbreak.CausesValidation = False
            Else
                PanelCRMData.Visible = False
                pnlComment.Visible = False
                pnlCMFBody.Visible = True

            End If
            '---------------------------------------------
            pnlshowlist.Visible = False
            Showbreak.Visible = False
            'btbreak.Enabled = False
            btexit.Enabled = False
            btAgentStat.Enabled = False
            btNewTransactionAssisted.Enabled = False
            btNewTransactionAmadeus.Enabled = False
            btNewTransactionInResort.Enabled = False
            btNewTransactionPostTravel.Enabled = False
            btNewTransactionMMB.Enabled = False
            btNewTransactionMMBKustomer.Enabled = False
            btNewTransactionMMBDE.Enabled = False
            btNewTransactionCSChat.Enabled = False
            btNewTransactionCSVoice.Enabled = False
            btnNewTransactionCreditControl.Enabled = False
            btnNewTransactionSupplierrelocation.Enabled = False
            btnNewTransactionCustomerServiceInbox.Enabled = False
            btnNewTransactionAssistedRyanAir.Enabled = False
            btnNewTransactionRefundTask.Enabled = False
            btnNewTransactionOtherWorkType.Enabled = False

        End If

    End Sub



    Protected Sub btNewTransactionCSChat_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btNewTransactionCSChat.Click
        WorkingonTMF = False

        If WorkingonTMF = False Then


            
            Ltworktype.Text = "Transaction Detail :- " + m_strCSChat
            CSChat = m_strCSChat
            CreateForm(CampaignID, "PanelCRMData", 0, CSChat)
            changeControlsVisiblityAtFirstTime()
            insertTransaction()
            FillDispostions(CampaignID)
            txtnewcomments.Text = ""

            pnlshowtracker.Visible = True
            '-------------------------------------------------
            If WorkingonTMF = False Then
                PanelCRMData.Visible = True
                pnlComment.Visible = True
                pnlCMFBody.Visible = False
                btPausedTransaction.Enabled = True '---- By Rajendra 2013-09-27
                btbreak.Enabled = False
                btbreak.CausesValidation = False
            Else
                PanelCRMData.Visible = False
                pnlComment.Visible = False
                pnlCMFBody.Visible = True

            End If
            '---------------------------------------------
            pnlshowlist.Visible = False
            Showbreak.Visible = False
            'btbreak.Enabled = False
            btexit.Enabled = False
            btAgentStat.Enabled = False
            btNewTransactionAssisted.Enabled = False
            btNewTransactionAmadeus.Enabled = False
            btNewTransactionInResort.Enabled = False
            btNewTransactionPostTravel.Enabled = False
            btNewTransactionMMB.Enabled = False
            btNewTransactionMMBKustomer.Enabled = False
            btNewTransactionMMBDE.Enabled = False
            btNewTransactionCSChat.Enabled = False
            btNewTransactionCSVoice.Enabled = False
            btnNewTransactionCreditControl.Enabled = False
            btnNewTransactionSupplierrelocation.Enabled = False
            btnNewTransactionCustomerServiceInbox.Enabled = False
            btnNewTransactionAssistedRyanAir.Enabled = False
            btnNewTransactionRefundTask.Enabled = False
            btnNewTransactionOtherWorkType.Enabled = False

        End If

    End Sub

    Protected Sub btNewTransactionCSVoice_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btNewTransactionCSVoice.Click
        WorkingonTMF = False

        If WorkingonTMF = False Then



            Ltworktype.Text = "Transaction Detail :- " + m_strCSVoice
            CSVoice = m_strCSVoice
            CreateForm(CampaignID, "PanelCRMData", 0, CSVoice)
            changeControlsVisiblityAtFirstTime()
            insertTransaction()
            FillDispostions(CampaignID)
            txtnewcomments.Text = ""

            pnlshowtracker.Visible = True
            '-------------------------------------------------
            If WorkingonTMF = False Then
                PanelCRMData.Visible = True
                pnlComment.Visible = True
                pnlCMFBody.Visible = False
                btPausedTransaction.Enabled = True '---- By Rajendra 2013-09-27
                btbreak.Enabled = False
                btbreak.CausesValidation = False
            Else
                PanelCRMData.Visible = False
                pnlComment.Visible = False
                pnlCMFBody.Visible = True

            End If
            '---------------------------------------------
            pnlshowlist.Visible = False
            Showbreak.Visible = False
            'btbreak.Enabled = False
            btexit.Enabled = False
            btAgentStat.Enabled = False
            btNewTransactionAssisted.Enabled = False
            btNewTransactionAmadeus.Enabled = False
            btNewTransactionInResort.Enabled = False
            btNewTransactionPostTravel.Enabled = False
            btNewTransactionMMB.Enabled = False
            btNewTransactionMMBKustomer.Enabled = False
            btNewTransactionMMBDE.Enabled = False
            btNewTransactionCSChat.Enabled = False
            btNewTransactionCSVoice.Enabled = False
            btnNewTransactionCreditControl.Enabled = False
            btnNewTransactionSupplierrelocation.Enabled = False
            btnNewTransactionCustomerServiceInbox.Enabled = False
            btnNewTransactionAssistedRyanAir.Enabled = False
            btnNewTransactionRefundTask.Enabled = False
            btnNewTransactionOtherWorkType.Enabled = False

        End If

    End Sub

    Protected Sub btnNewTransactionCreditControl_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnNewTransactionCreditControl.Click
        WorkingonTMF = False

        If WorkingonTMF = False Then


            Ltworktype.Text = "Transaction Detail :- " + m_strCreditControl
            CreditControl = m_strCreditControl
            CreateForm(CampaignID, "PanelCRMData", 0, CreditControl)
            changeControlsVisiblityAtFirstTime()
            insertTransaction()
            FillDispostions(CampaignID)
            txtnewcomments.Text = ""

            pnlshowtracker.Visible = True
            '-------------------------------------------------
            If WorkingonTMF = False Then
                PanelCRMData.Visible = True
                pnlComment.Visible = True
                pnlCMFBody.Visible = False
                btPausedTransaction.Enabled = True '---- By Rajendra 2013-09-27
                btbreak.Enabled = False
                btbreak.CausesValidation = False
            Else
                PanelCRMData.Visible = False
                pnlComment.Visible = False
                pnlCMFBody.Visible = True

            End If
            '---------------------------------------------
            pnlshowlist.Visible = False
            Showbreak.Visible = False
            'btbreak.Enabled = False
            btexit.Enabled = False
            btAgentStat.Enabled = False
            btNewTransactionAssisted.Enabled = False
            btNewTransactionAmadeus.Enabled = False
            btNewTransactionInResort.Enabled = False
            btNewTransactionPostTravel.Enabled = False
            btNewTransactionMMB.Enabled = False
            btNewTransactionMMBKustomer.Enabled = False
            btNewTransactionMMBDE.Enabled = False
            btNewTransactionCSChat.Enabled = False
            btNewTransactionCSVoice.Enabled = False
            btnNewTransactionCreditControl.Enabled = False
            btnNewTransactionSupplierrelocation.Enabled = False
            btnNewTransactionCustomerServiceInbox.Enabled = False
            btnNewTransactionAssistedRyanAir.Enabled = False
            btnNewTransactionRefundTask.Enabled = False
            btnNewTransactionOtherWorkType.Enabled = False

        End If

    End Sub

    Protected Sub btnNewTransactionSupplierrelocation_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnNewTransactionSupplierrelocation.Click
        WorkingonTMF = False

        If WorkingonTMF = False Then


            Ltworktype.Text = "Transaction Detail :- " + m_strSupplierRelocation
            SupplierRelocation = m_strSupplierRelocation
            CreateForm(CampaignID, "PanelCRMData", 0, SupplierRelocation)
            changeControlsVisiblityAtFirstTime()
            insertTransaction()
            FillDispostions(CampaignID)
            txtnewcomments.Text = ""

            pnlshowtracker.Visible = True
            '-------------------------------------------------
            If WorkingonTMF = False Then
                PanelCRMData.Visible = True
                pnlComment.Visible = True
                pnlCMFBody.Visible = False
                btPausedTransaction.Enabled = True '---- By Rajendra 2013-09-27
                btbreak.Enabled = False
                btbreak.CausesValidation = False
            Else
                PanelCRMData.Visible = False
                pnlComment.Visible = False
                pnlCMFBody.Visible = True

            End If
            '---------------------------------------------
            pnlshowlist.Visible = False
            Showbreak.Visible = False
            'btbreak.Enabled = False
            btexit.Enabled = False
            btAgentStat.Enabled = False
            btNewTransactionAssisted.Enabled = False
            btNewTransactionAmadeus.Enabled = False
            btNewTransactionInResort.Enabled = False
            btNewTransactionPostTravel.Enabled = False
            btNewTransactionMMB.Enabled = False
            btNewTransactionMMBKustomer.Enabled = False
            btNewTransactionMMBDE.Enabled = False
            btNewTransactionCSChat.Enabled = False
            btNewTransactionCSVoice.Enabled = False
            btnNewTransactionCreditControl.Enabled = False
            btnNewTransactionSupplierrelocation.Enabled = False
            btnNewTransactionCustomerServiceInbox.Enabled = False
            btnNewTransactionAssistedRyanAir.Enabled = False
            btnNewTransactionRefundTask.Enabled = False
            btnNewTransactionOtherWorkType.Enabled = False

        End If

    End Sub

    Protected Sub btnNewTransactionCustomerServiceInbox_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnNewTransactionCustomerServiceInbox.Click
        WorkingonTMF = False

        If WorkingonTMF = False Then


            Ltworktype.Text = "Transaction Detail :- " + m_strCustomerServiceInbox
            CustomerServiceInbox = m_strCustomerServiceInbox
            CreateForm(CampaignID, "PanelCRMData", 0, CustomerServiceInbox)
            changeControlsVisiblityAtFirstTime()
            insertTransaction()
            FillDispostions(CampaignID)
            txtnewcomments.Text = ""

            pnlshowtracker.Visible = True
            '-------------------------------------------------
            If WorkingonTMF = False Then
                PanelCRMData.Visible = True
                pnlComment.Visible = True
                pnlCMFBody.Visible = False
                btPausedTransaction.Enabled = True '---- By Rajendra 2013-09-27
                btbreak.Enabled = False
                btbreak.CausesValidation = False
            Else
                PanelCRMData.Visible = False
                pnlComment.Visible = False
                pnlCMFBody.Visible = True

            End If
            '---------------------------------------------
            pnlshowlist.Visible = False
            Showbreak.Visible = False
            'btbreak.Enabled = False
            btexit.Enabled = False
            btAgentStat.Enabled = False
            btNewTransactionAssisted.Enabled = False
            btNewTransactionAmadeus.Enabled = False
            btNewTransactionInResort.Enabled = False
            btNewTransactionPostTravel.Enabled = False
            btNewTransactionMMB.Enabled = False
            btNewTransactionMMBKustomer.Enabled = False
            btNewTransactionMMBDE.Enabled = False
            btNewTransactionCSChat.Enabled = False
            btNewTransactionCSVoice.Enabled = False
            btnNewTransactionCreditControl.Enabled = False
            btnNewTransactionSupplierrelocation.Enabled = False
            btnNewTransactionCustomerServiceInbox.Enabled = False
            btnNewTransactionAssistedRyanAir.Enabled = False
            btnNewTransactionRefundTask.Enabled = False
            btnNewTransactionOtherWorkType.Enabled = False

        End If

    End Sub

    Protected Sub btnNewTransactionAssistedRyanAir_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnNewTransactionAssistedRyanAir.Click
        WorkingonTMF = False

        If WorkingonTMF = False Then


            Ltworktype.Text = "Transaction Detail :- " + m_strAssistedRyanAir
            AssistedRyanAir = m_strAssistedRyanAir
            CreateForm(CampaignID, "PanelCRMData", 0, AssistedRyanAir)
            changeControlsVisiblityAtFirstTime()
            insertTransaction()
            FillDispostions(CampaignID)
            txtnewcomments.Text = ""

            pnlshowtracker.Visible = True
            '-------------------------------------------------
            If WorkingonTMF = False Then
                PanelCRMData.Visible = True
                pnlComment.Visible = True
                pnlCMFBody.Visible = False
                btPausedTransaction.Enabled = True '---- By Rajendra 2013-09-27
                btbreak.Enabled = False
                btbreak.CausesValidation = False
            Else
                PanelCRMData.Visible = False
                pnlComment.Visible = False
                pnlCMFBody.Visible = True

            End If
            '---------------------------------------------
            pnlshowlist.Visible = False
            Showbreak.Visible = False
            'btbreak.Enabled = False
            btexit.Enabled = False
            btAgentStat.Enabled = False
            btNewTransactionAssisted.Enabled = False
            btNewTransactionAmadeus.Enabled = False
            btNewTransactionInResort.Enabled = False
            btNewTransactionPostTravel.Enabled = False
            btNewTransactionMMB.Enabled = False
            btNewTransactionMMBKustomer.Enabled = False
            btNewTransactionMMBDE.Enabled = False
            btNewTransactionCSChat.Enabled = False
            btNewTransactionCSVoice.Enabled = False
            btnNewTransactionCreditControl.Enabled = False
            btnNewTransactionSupplierrelocation.Enabled = False
            btnNewTransactionCustomerServiceInbox.Enabled = False
            btnNewTransactionAssistedRyanAir.Enabled = False
            btnNewTransactionRefundTask.Enabled = False
            btnNewTransactionOtherWorkType.Enabled = False

        End If

    End Sub
    Protected Sub btnNewTransactionRefundTask_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnNewTransactionRefundTask.Click
        WorkingonTMF = False

        If WorkingonTMF = False Then


            Ltworktype.Text = "Transaction Detail :- " + m_strRefundTask
            RefundTask = m_strRefundTask
            CreateForm(CampaignID, "PanelCRMData", 0, RefundTask)
            changeControlsVisiblityAtFirstTime()
            insertTransaction()
            FillDispostions(CampaignID)
            txtnewcomments.Text = ""

            pnlshowtracker.Visible = True
            '-------------------------------------------------
            If WorkingonTMF = False Then
                PanelCRMData.Visible = True
                pnlComment.Visible = True
                pnlCMFBody.Visible = False
                btPausedTransaction.Enabled = True '---- By Rajendra 2013-09-27
                btbreak.Enabled = False
                btbreak.CausesValidation = False
            Else
                PanelCRMData.Visible = False
                pnlComment.Visible = False
                pnlCMFBody.Visible = True

            End If
            '---------------------------------------------
            pnlshowlist.Visible = False
            Showbreak.Visible = False
            'btbreak.Enabled = False
            btexit.Enabled = False
            btAgentStat.Enabled = False
            btNewTransactionAssisted.Enabled = False
            btNewTransactionAmadeus.Enabled = False
            btNewTransactionInResort.Enabled = False
            btNewTransactionPostTravel.Enabled = False
            btNewTransactionMMB.Enabled = False
            btNewTransactionMMBKustomer.Enabled = False
            btNewTransactionMMBDE.Enabled = False
            btNewTransactionCSChat.Enabled = False
            btNewTransactionCSVoice.Enabled = False
            btnNewTransactionCreditControl.Enabled = False
            btnNewTransactionSupplierrelocation.Enabled = False
            btnNewTransactionCustomerServiceInbox.Enabled = False
            btnNewTransactionAssistedRyanAir.Enabled = False
            btnNewTransactionRefundTask.Enabled = False
            btnNewTransactionOtherWorkType.Enabled = False

        End If

    End Sub

    Protected Sub btnNewTransactionOtherWorkType_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnNewTransactionOtherWorkType.Click
        WorkingonTMF = False

        If WorkingonTMF = False Then


            Ltworktype.Text = "Transaction Detail :- " + m_strOtherWorkType
            OtherWorkType = m_strOtherWorkType
            CreateForm(CampaignID, "PanelCRMData", 0, OtherWorkType)
            changeControlsVisiblityAtFirstTime()
            insertTransaction()
            FillDispostions(CampaignID)
            txtnewcomments.Text = ""

            pnlshowtracker.Visible = True
            '-------------------------------------------------
            If WorkingonTMF = False Then
                PanelCRMData.Visible = True
                pnlComment.Visible = True
                pnlCMFBody.Visible = False
                btPausedTransaction.Enabled = True '---- By Rajendra 2013-09-27
                btbreak.Enabled = False
                btbreak.CausesValidation = False
            Else
                PanelCRMData.Visible = False
                pnlComment.Visible = False
                pnlCMFBody.Visible = True

            End If
            '---------------------------------------------
            pnlshowlist.Visible = False
            Showbreak.Visible = False
            'btbreak.Enabled = False
            btexit.Enabled = False
            btAgentStat.Enabled = False
            btNewTransactionAssisted.Enabled = False
            btNewTransactionAmadeus.Enabled = False
            btNewTransactionInResort.Enabled = False
            btNewTransactionPostTravel.Enabled = False
            btNewTransactionMMB.Enabled = False
            btNewTransactionMMBKustomer.Enabled = False
            btNewTransactionMMBDE.Enabled = False
            btNewTransactionCSChat.Enabled = False
            btNewTransactionCSVoice.Enabled = False
            btnNewTransactionCreditControl.Enabled = False
            btnNewTransactionSupplierrelocation.Enabled = False
            btnNewTransactionCustomerServiceInbox.Enabled = False
            btnNewTransactionAssistedRyanAir.Enabled = False
            btnNewTransactionRefundTask.Enabled = False
            btnNewTransactionOtherWorkType.Enabled = False

        End If

    End Sub



#End Region
#Region "--- Popup Functions ---"
    Private Sub OpenBreakPopup()
        Dim str As String
        str = "$('#DialogBackground').height($(document).height());$('#DialogBackground').width($(window).width());$('#DialogBackground').css('visibility','visible');" & _
        " $('#pnlBreak').css('visibility','visible');$('#pnlBreak').css('left',($(window).width() - $('#pnlBreak').width())/2); "
        ScriptManager.RegisterStartupScript(Page, Page.GetType(), "Movedialog", str, True)
    End Sub
    Private Sub OpenAgentStatPopup()
        Dim str As String
        str = "$('#DialogBackground').height($(document).height());$('#DialogBackground').width($(window).width());$('#DialogBackground').css('visibility','visible');" & _
        " $('#pnlagent').css('visibility','visible');$('#pnlagent').css('left',($(window).width() - $('#pnlagent').width())/2); "
        ScriptManager.RegisterStartupScript(Page, Page.GetType(), "Movedialog", str, True)
    End Sub
    Private Sub CloseBreakPopup()
        Dim str As String
        str = "$('#DialogBackground').css('visibility','hidden');$('#pnlagent').css('visibility','hidden');"
        ScriptManager.RegisterStartupScript(Page, Page.GetType(), "Movedialog", str, True)
    End Sub
    Private Sub CloseAgentStatPopup()
        Dim str As String
        str = "$('#DialogBackground').css('visibility','hidden');$('#pnlBreak').css('visibility','hidden');"
        ScriptManager.RegisterStartupScript(Page, Page.GetType(), "Movedialog", str, True)
    End Sub
#End Region


#Region "---------------Support Functions-----"
    Private Sub SetDialState_ToTMF()
        If DailStateBased Then
            conn = New SqlConnection(connLeads)
            cmd = New SqlCommand()
            cmd.Connection = conn
            cmd.CommandType = CommandType.Text
            'Update dialstate to 2 for working on TMF for "New TMF" or "Modify Details"
            cmd.CommandText = "UPDATE tbl_LeadMaster" & CampaignID & " SET DialState=2  WHERE customerid=" & customerid
            conn.Open()
            cmd.ExecuteNonQuery()
            conn.Close()
            cmd = Nothing
        End If
    End Sub

#End Region


#Region "--- Utility ---"
    Private Sub AlertMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMFail"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub

    Private Sub SuccessMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMSuccess"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub
#End Region
#Region "--- Confirmation to delete Leads --- "

#End Region


#Region "-------TMF Functionality-------"

    Protected Function SaveTMFdata() As Boolean

        Dim tran As SqlTransaction
        Dim SheetTemp As Integer
        Dim SheetDataID As Integer
        ' Dim dtMandatoryQuest As DataTable
        Dim flag As Boolean = False
        Dim transFlag As Boolean = True
        Dim returnNoUse_1 As String = ""
        Dim returnNoUse_2 As String = ""

        ' Dim db3 As New DBAccess("CRM")
        'db3.slDataAdd("campaignid", CampaignID)
        'db3.slDataAdd("CMFID", CMFID)
        'db3.slDataAdd("sheetid", SheetID)
        'dtMandatoryQuest = db3.ReturnTable("usp_Quality_GetCMFfields", , True)
        'db3 = Nothing
        '----------------------------------------------For datatable
        Dim dtMandatoryQuest As New DataTable
        conn = New SqlConnection(connCRM)
        cmd = New SqlCommand()
        cmd.Parameters.AddWithValue("campaignid", CampaignID)
        cmd.Parameters.AddWithValue("CMFID", CMFID)
        cmd.Parameters.AddWithValue("sheetid", SheetID)

        cmd.Connection = conn
        cmd.CommandType = CommandType.StoredProcedure
        cmd.CommandText = "usp_Quality_GetCMFfields"
        adp = New SqlDataAdapter(cmd)
        adp.Fill(dtMandatoryQuest)
        cmd = Nothing
        adp = Nothing
        '------------------------------------------------------------

        ' Dim db As New DBAccess("CRM")
        Try

            'db.BeginTrans() '1
            'db.slDataAdd("campid", CampaignID)
            'db.slDataAdd("qeid", UserID)
            'db.slDataAdd("AgentID", AgentID)
            'db.slDataAdd("CustomerID", customerid)
            'db.slDataAdd("TransID", TransIDTMF)   ' (NOT TransID) ----'TransIDTMF is the TransID of the agent that will be saved for quality 
            ''                                                           'and not the newly generated TransID of QC one
            'db.slDataAdd("CMFID", CMFID)
            'db.slDataAdd("Comments", txtcomments.Text.Trim)
            'db.slDataAdd("btfreez", True)
            'db.slDataAdd("Endusercomp", txtComplaints.Text.Trim)
            'If lblTL.Text.Trim = "" Then
            '    db.slDataAdd("SupervisorID", "")
            'Else
            '    db.slDataAdd("SupervisorID", lblTL.Text.Trim.Substring(lblTL.Text.Trim.LastIndexOf("(")).Replace("(", "").Replace(")", ""))
            'End If
            'db.slDataAdd("ClientSheet", CBReferClient.Checked)
            'For Each row As DataRow In dtMandatoryQuest.Rows
            '    If row.Item("Type") = 1 Then 'For Textbox
            '        db.slDataAdd("UDF" & row("FieldID"), CType(pnlDynamicHeader.FindControl("Field" & row("FieldID") & "TMF"), TextBox).Text)
            '    ElseIf row.Item("Type") = 2 Then 'For DropDownList
            '        db.slDataAdd("UDF" & row("FieldID"), CType(pnlDynamicHeader.FindControl("Field" & row("FieldID") & "TMF"), DropDownList).SelectedItem.Text)
            '    End If
            'Next
            ''-----------------------------------
            'db.slDataAdd("sheetid", SheetID)
            'If SheetID = 0 Then
            '    If StandaloneCMF Then
            '        db.slDataAdd("StandaloneCMF", StandaloneCMF)
            '        db.slDataAdd("Transactiondate", IIf(TransDate Is Nothing, lblTransDate.Text, TransDate))
            '    End If
            'End If
            'SheetTemp = db.ReturnValue("usp_QualityInsertQMSheetMst_New", True)

            '-------------------------------------------------------------------------------
            '-------------------------------------------------------------------------------
            '-------------------------------------------------------------------------------
            conn = New SqlConnection(connCRM)
            cmd = New SqlCommand()
            conn.Open()

            tran = conn.BeginTransaction()
            cmd.Transaction = tran

            cmd.Connection = conn

            cmd.Parameters.AddWithValue("campid", CampaignID)
            cmd.Parameters.AddWithValue("qeid", UserID)
            cmd.Parameters.AddWithValue("AgentID", QEAgentID)
            cmd.Parameters.AddWithValue("CustomerID", customerid)
            cmd.Parameters.AddWithValue("TransID", TransIDTMF) '''''rajkumar   this is different
            cmd.Parameters.AddWithValue("CMFID", CMFID)
            cmd.Parameters.AddWithValue("Comments", txtcomments.Text.Trim)
            cmd.Parameters.AddWithValue("btfreez", True)
            cmd.Parameters.AddWithValue("Endusercomp", txtComplaints.Text.Trim)
            If lblTL.Text.Trim = "" Then
                cmd.Parameters.AddWithValue("SupervisorID", "")
            Else
                cmd.Parameters.AddWithValue("SupervisorID", lblTL.Text.Trim.Substring(lblTL.Text.Trim.LastIndexOf("(")).Replace("(", "").Replace(")", ""))
            End If
            cmd.Parameters.AddWithValue("ClientSheet", CBReferClient.Checked)

            For Each row As DataRow In dtMandatoryQuest.Rows
                If row.Item("Type") = 1 Then 'For Textbox
                    cmd.Parameters.AddWithValue("UDF" & row("FieldID"), CType(pnlDynamicHeader.FindControl("Field" & row("FieldID") & "TMF"), TextBox).Text)

                    'If CType(pnlDynamicHeader.FindControl("valid" & row("FieldID") & "TMF"), RequiredFieldValidator).ErrorMessage = "ErrorMessage" Then
                    '    CType(pnlDynamicHeader.FindControl("valid" & row("FieldID") & "TMF"), RequiredFieldValidator).Focus()
                    '    tran.Rollback()
                    '    Exit Sub
                    'End If

                ElseIf row.Item("Type") = 2 Then 'For DropDownList
                    cmd.Parameters.AddWithValue("UDF" & row("FieldID"), CType(pnlDynamicHeader.FindControl("Field" & row("FieldID") & "TMF"), DropDownList).SelectedItem.Text)
                End If
            Next
            '-----------------------------------
            cmd.Parameters.AddWithValue("sheetid", SheetID)
            If SheetID = 0 Then
                If StandaloneCMF Then
                    cmd.Parameters.AddWithValue("StandaloneCMF", StandaloneCMF)
                    cmd.Parameters.AddWithValue("Transactiondate", IIf(TransDate Is Nothing, lblTransDate.Text, TransDate))
                End If
            End If

            cmd.CommandType = CommandType.StoredProcedure
            cmd.CommandText = "usp_QualityInsertQMSheetMst_New"
            ' conn.Open()
            SheetTemp = CInt(cmd.ExecuteScalar())
            '--------------------------------------------------------------------------------
            '--------------------------------------------------------------------------------

            'insert SheetData data
            For Each ctrl As Control In maincat.Controls
                Dim lblcatid1 As Label = ctrl.FindControl("lblcatid")
                Dim rpitem As RepeaterItem = ctrl.FindControl("lblsubcatid")
                For Each rpitem In ctrl.FindControl("subcat").Controls
                    Dim lblsubcatid1 As Label = rpitem.FindControl("lblsubcatid")
                    For Each lstitem As DataListItem In rpitem.FindControl("dtlst").Controls
                        Dim lblparamid As Label = lstitem.FindControl("lblParamid")
                        Dim ddoptions As DropDownList = lstitem.FindControl("ddParamOption")

                        'db.slDataAdd("sheetid", SheetTemp)
                        'db.slDataAdd("campid", CampaignID)
                        'db.slDataAdd("paramid", lblparamid.Text)
                        'db.slDataAdd("optid", ddoptions.SelectedValue)
                        'db.slDataAdd("mcid", lblcatid1.Text)
                        'db.slDataAdd("CMFID", CMFID)
                        'db.slDataAdd("scid", lblsubcatid1.Text)
                        'ddoptions.Enabled = False
                        'SheetDataID = db.ReturnValue("usp_QualityInsertSheetData_New", True)
                        '------------------------------------------------For Execute scalar ---for usp
                        ' '' ''conn = New SqlConnection(connCRM)
                        ' '' ''cmd = New SqlCommand()
                        ' '' ''cmd.Connection = conn

                        cmd = New SqlCommand()
                        cmd.Connection = conn
                        cmd.Transaction = tran

                        cmd.Parameters.AddWithValue("sheetid", SheetTemp)
                        cmd.Parameters.AddWithValue("campid", CampaignID)
                        cmd.Parameters.AddWithValue("paramid", lblparamid.Text)
                        cmd.Parameters.AddWithValue("optid", ddoptions.SelectedValue)
                        cmd.Parameters.AddWithValue("mcid", lblcatid1.Text)
                        cmd.Parameters.AddWithValue("CMFID", CMFID)
                        cmd.Parameters.AddWithValue("scid", lblsubcatid1.Text)
                        ddoptions.Enabled = False

                        cmd.CommandType = CommandType.StoredProcedure
                        cmd.CommandText = "usp_QualityInsertSheetData_New"
                        ' '' ''conn.Open()
                        SheetDataID = CInt(cmd.ExecuteScalar())
                        ' '' ''cmd = Nothing
                        ' '' ''conn.Close()
                        '-----------------------------------------------

                        Dim pnlSubQuestions As Panel = lstitem.FindControl("pnlSubQuestions")
                        Dim chkBoxList As CheckBoxList = pnlSubQuestions.FindControl("chkBoxList1")

                        'db.DeleteinTable("tbl_Quality_Data_SheetData_SubParams", "SheetDataID=" & SheetDataID)
                        '------------------------------------------------For Execute scalar ---for query
                        ' '' ''conn = New SqlConnection(connCRM)
                        ' '' ''cmd = New SqlCommand()
                        ' '' ''cmd.Connection = conn
                        cmd = New SqlCommand()
                        cmd.Connection = conn
                        cmd.Transaction = tran

                        cmd.CommandType = CommandType.Text
                        cmd.CommandText = "DELETE FROM tbl_Quality_Data_SheetData_SubParams WHERE SheetDataID=" & SheetDataID
                        ' '' ''conn.Open()
                        cmd.ExecuteNonQuery()
                        ' '' ''cmd = Nothing
                        ' '' ''conn.Close()
                        '-----------------------------------------------
                        flag = False
                        If ddoptions.Items.FindByText("No").Selected = True And chkBoxList.Items.Count > 0 Then
                            For Each li As ListItem In chkBoxList.Items
                                If li.Selected Then
                                    flag = True
                                    'db.slDataAdd("SheetDataID", SheetDataID)
                                    'db.slDataAdd("SubParamID", li.Value)
                                    'returnNoUse_1 = db.ReturnValue("usp_Quality_insertSubParameters", True)
                                    '------------------------------------------------For Execute scalar ---for usp
                                    ' '' ''conn = New SqlConnection(connCRM)
                                    ' '' ''cmd = New SqlCommand()
                                    ' '' ''cmd.Connection = conn
                                    cmd = New SqlCommand()
                                    cmd.Connection = conn
                                    cmd.Transaction = tran

                                    cmd.Parameters.AddWithValue("SheetDataID", SheetDataID)
                                    cmd.Parameters.AddWithValue("SubParamID", li.Value)

                                    cmd.CommandType = CommandType.StoredProcedure
                                    cmd.CommandText = "usp_Quality_insertSubParameters"
                                    ' '' ''conn.Open()
                                    returnNoUse_1 = CObj(cmd.ExecuteScalar())
                                    ' '' ''cmd = Nothing
                                    ' '' ''conn.Close()
                                    '-----------------------------------------------


                                End If
                            Next
                        End If

                        '(2)
                        If ddoptions.Items.FindByText("No").Selected = True And chkBoxList.Items.Count > 0 Then 'if "No" is selected in answer option
                            If flag = False Then 'i.e. if not any one subparameter is selected
                                'lblErrorTMF.Text = "Please select atleast one Subparameter in selected parameter."
                                AlertMessage("Please select atleast one Subparameter in selected parameter.")

                                lblErrorTMF.Visible = True
                                ' db.RollBackTrans() '2
                                tran.Rollback()
                                transFlag = False
                                Exit Function
                            End If
                        End If

                    Next
                Next
            Next
            SheetID = SheetTemp

            'db.slDataAdd("Sheetid", SheetID)
            'returnNoUse_2 = db.ReturnValue("usp_QualitySaveSheetQCScore_New", True)
            '------------------------------------------------For Execute scalar ---for usp
            ' '' ''conn = New SqlConnection(connCRM)
            ' '' ''cmd = New SqlCommand()
            ' '' ''cmd.Connection = conn
            cmd = New SqlCommand()
            cmd.Connection = conn
            cmd.Transaction = tran

            cmd.Parameters.AddWithValue("Sheetid", SheetID)
            cmd.CommandType = CommandType.StoredProcedure
            cmd.CommandText = "usp_QualitySaveSheetQCScore_New"
            ' '' ''conn.Open()
            returnNoUse_2 = CObj(cmd.ExecuteScalar())
            ' '' ''cmd = Nothing
            ' '' ''conn.Close()
            '-----------------------------------------------
            '            db.CommitTrans() '3
            tran.Commit()

            cmd = Nothing

            Return True

        Catch ex As Exception
            lblErrorTMF.Text = ex.ToString
            lblErrorTMF.Visible = True
            'db.RollBackTrans() '4
            tran.Rollback()
            transFlag = False
            Return False
        Finally
            'db = Nothing
            conn.Close()
        End Try
        '---Commented Rajkumar 09-08-2013
        'If transFlag Then
        '    Response.Redirect("~/Quality/CMFForm.aspx?campid=" & Request.QueryString("campid") & "&standalonecmf=" & Request.QueryString("standalonecmf") & "&lid=" & Request.QueryString("lid") & "&agentid=" & Request.QueryString("agentid") & "&TransID=" & Request.QueryString("TransID") & "&CMFID=" & CMFID & "&SheetID=" & SheetID & "&Return=ListTransactions.aspx" & "&LoginUserID=" & UserID & "&LoginUserName=" & LoginUserName)
        'End If
    End Function

    Private Sub CreateForm_TMF()
        'If Not IsPostBack Then
        Dim objTable As Table
        Dim objTablerow As TableRow
        Dim objTableCol As TableCell
        Dim objLabel As Label
        Dim objText As TextBox
        Dim objSelect As DropDownList

        Dim dtMandatoryQuest As New DataTable
        'Dim db As DBAccess

        Dim iCtr As Integer
        pnlDynamicHeader.Controls.Remove(pnlDynamicHeader.FindControl("dynamicTMF"))
        Try
            objTable = New Table
            objTable.ID = "dynamicTMF"
            objTable.Width = System.Web.UI.WebControls.Unit.Percentage(100)
            objTable.CellSpacing = 0
            objTable.HorizontalAlign = HorizontalAlign.Center
            objTable.EnableViewState = True


            'db = New DBAccess("CRM")
            'db.slDataAdd("campaignid", CampaignID)
            'db.slDataAdd("CMFID", CMFID)
            'db.slDataAdd("sheetid", SheetID)
            'dtMandatoryQuest = db.ReturnTable("usp_Quality_GetCMFfields", , True)
            'db = Nothing
            '----------------------------------------------For datatable
            ' Dim dtTable As New DataTable
            conn = New SqlConnection(connCRM)
            cmd = New SqlCommand()
            cmd.Parameters.AddWithValue("campaignid", CampaignID)
            cmd.Parameters.AddWithValue("CMFID", CMFID)
            cmd.Parameters.AddWithValue("sheetid", SheetID)

            cmd.Connection = conn
            cmd.CommandType = CommandType.StoredProcedure
            cmd.CommandText = "usp_Quality_GetCMFfields"
            adp = New SqlDataAdapter(cmd)
            adp.Fill(dtMandatoryQuest)
            cmd = Nothing
            adp = Nothing
            '------------------------------------------------------------

            If Not dtMandatoryQuest Is Nothing Then
                For iCtr = 0 To dtMandatoryQuest.Rows.Count - 1
                    objTablerow = New TableRow
                    objTablerow.ID = "TblRow" & dtMandatoryQuest.Rows(iCtr).Item("FieldID") & "TMF"
                    'objTablerow.BackColor = Color.LightGray
                    objTable.Rows.Add(objTablerow)
                    objTablerow.EnableViewState = True
                    objTableCol = New TableCell
                    objTablerow.Cells.Add(objTableCol)
                    objTableCol.EnableViewState = True
                    objTableCol.BackColor = System.Drawing.Color.Transparent
                    objTableCol.VerticalAlign = VerticalAlign.Top
                    objTableCol.HorizontalAlign = HorizontalAlign.Left
                    'objTableCol.Width = System.Web.UI.WebControls.Unit.Percentage(40)
                    objTableCol.Attributes.Add("style", "border-bottom: solid 1px #bbd9ee")
                    objLabel = New Label
                    objTableCol.Controls.Add(objLabel)
                    objLabel.Text = dtMandatoryQuest.Rows(iCtr).Item("FieldName")
                    objLabel.EnableViewState = True
                    objTableCol = New TableCell
                    objTablerow.Cells.Add(objTableCol)
                    objTableCol.BackColor = System.Drawing.Color.Transparent
                    objTableCol.VerticalAlign = VerticalAlign.Top
                    objTableCol.HorizontalAlign = HorizontalAlign.Left
                    'objTableCol.Width = System.Web.UI.WebControls.Unit.Percentage(55)
                    objTableCol.Attributes.Add("style", "border-bottom: solid 1px #bbd9ee")
                    objTableCol.EnableViewState = True
                    Select Case dtMandatoryQuest.Rows(iCtr).Item("Type")
                        Case 1
                            objText = New TextBox
                            objTableCol.Controls.Add(objText)
                            'objText.Text = dt.Rows(iCtr).Item("quest_dataheading")
                            'objText.Height = System.Web.UI.WebControls.Unit.Pixel(20)
                            objText.Width = System.Web.UI.WebControls.Unit.Percentage(79)
                            objText.MaxLength = 255
                            objText.Font.Size = System.Web.UI.WebControls.FontUnit.Point(10)
                            objText.BorderColor = Drawing.Color.AliceBlue
                            objText.ID = "Field" & dtMandatoryQuest.Rows(iCtr).Item("FieldID") & "TMF"

                            If Not IsDBNull(dtMandatoryQuest.Rows(iCtr).Item("SavedValue")) Then 'i.e value is present
                                objText.Text = dtMandatoryQuest.Rows(iCtr).Item("SavedValue")
                            ElseIf dtMandatoryQuest.Rows(iCtr).Item("FieldName") = "AHT" Then
                                Dim span As TimeSpan = New TimeSpan(TimeSpan.TicksPerSecond * Request.QueryString("duration"))
                                objText.Text = span.Hours.ToString("00") + ":" + span.Minutes.ToString("00") + ":" + span.Seconds.ToString("00")
                            ElseIf dtMandatoryQuest.Rows(iCtr).Item("FieldName").ToString.ToLower.Contains("telephone") Then
                                objText.Text = Request.QueryString("Telephone")
                            Else
                                objText.Text = ""
                            End If

                            'objText.Text = IIf(IsDBNull(dtMandatoryQuest.Rows(iCtr).Item("SavedValue")), "", dtMandatoryQuest.Rows(iCtr).Item("SavedValue"))
                            objText.EnableViewState = True
                            objText.Attributes.Add("Type", dtMandatoryQuest.Rows(iCtr).Item("Type"))
                            objText.Visible = True
                            If dtMandatoryQuest.Rows(iCtr).Item("IsMandatory") Then
                                Dim valid = New RequiredFieldValidator
                                valid.ID = "valid" & dtMandatoryQuest.Rows(iCtr).Item("FieldID") & "TMF"
                                valid.ControlToValidate = objText.ID
                                valid.ErrorMessage = "Required"
                                valid.SetFocusOnError = True
                                'valid.Width = System.Web.UI.WebControls.Unit.Pixel(50)
                                'valid.Font.Size = System.Web.UI.WebControls.FontUnit.Point(8)
                                'valid.Display = ValidatorDisplay.None
                                objTableCol.Controls.Add(valid)
                                'CType(pnlDynamicHeader.FindControl("valid" & dtMandatoryQuest.Rows(iCtr).Item("FieldID") & "TMF"), RequiredFieldValidator).Focus()
                            End If


                        Case 2
                            objSelect = New DropDownList
                            objSelect.Height = System.Web.UI.WebControls.Unit.Pixel(25)
                            objSelect.Width = System.Web.UI.WebControls.Unit.Percentage(80)
                            objSelect.Font.Size = System.Web.UI.WebControls.FontUnit.Small
                            objSelect.ID = "Field" & dtMandatoryQuest.Rows(iCtr).Item("FieldID") & "TMF"
                            objSelect.EnableViewState = True
                            objSelect.Attributes.Add("Type", dtMandatoryQuest.Rows(iCtr).Item("Type"))

                            ' Dim ans As DataTable  
                            ' Dim db2 As New DBAccess("CRM")
                            'db2.slDataAdd("CampaignID", CampaignID)
                            'db2.slDataAdd("CMFID", CMFID)
                            'db2.slDataAdd("FieldID", dtMandatoryQuest.Rows(iCtr).Item("FieldID"))
                            'ans = db2.ReturnTable("usp_Quality_GetCMFfieldsMap", , True)
                            'db2 = Nothing
                            '----------------------------------------------For datatable
                            Dim ans As New DataTable
                            conn = New SqlConnection(connCRM)
                            cmd = New SqlCommand()

                            cmd.Parameters.AddWithValue("CampaignID", CampaignID)
                            cmd.Parameters.AddWithValue("CMFID", CMFID)
                            cmd.Parameters.AddWithValue("FieldID", dtMandatoryQuest.Rows(iCtr).Item("FieldID"))

                            cmd.Connection = conn
                            cmd.CommandType = CommandType.StoredProcedure
                            cmd.CommandText = "usp_Quality_GetCMFfieldsMap"
                            adp = New SqlDataAdapter(cmd)
                            adp.Fill(ans)
                            cmd = Nothing
                            adp = Nothing
                            '------------------------------------------------------------

                            If ans.Rows.Count > 0 Then
                                objSelect.DataSource = ans
                                objSelect.DataTextField = "FieldValue"
                                objSelect.DataValueField = "AnsID"
                                objSelect.DataBind()
                            End If
                            objSelect.Visible = True

                            If Not IsDBNull(dtMandatoryQuest.Rows(iCtr).Item("SavedValue")) Then
                                For Each e As ListItem In objSelect.Items
                                    If e.Text.Trim = dtMandatoryQuest.Rows(iCtr).Item("SavedValue").ToString().Trim Then
                                        e.Selected = True
                                    End If
                                Next
                            End If
                            objTableCol.Controls.Add(objSelect)
                    End Select
                Next
            End If

            pnlDynamicHeader.Controls.Add(objTable)
            pnlDynamicHeader.Enabled = True
            '***************TO Get the value of controls that are created dynamically.
        Catch ex As Exception
            lblErrorTMF.Text = ex.Message
            lblErrorTMF.Visible = True
        Finally
            dtMandatoryQuest = Nothing
        End Try
    End Sub

    Private Function fillCmfList() As Boolean
        'Dim db As New DBAccess("qualitynew")
        'db.slDataAdd("CampId", CampaignID)
        'Dim dt As DataTable = db.ReturnTable("usp_QualityGetCMFList_new", , True)
        '----------------------------------------------For datatable
        Dim dt As New DataTable
        conn = New SqlConnection(connCRM)
        cmd = New SqlCommand()
        cmd.Parameters.AddWithValue("CampId", CampaignID)

        cmd.Connection = conn
        cmd.CommandType = CommandType.StoredProcedure
        cmd.CommandText = "usp_QualityGetCMFList_new"
        adp = New SqlDataAdapter(cmd)
        adp.Fill(dt)
        cmd = Nothing
        adp = Nothing
        '------------------------------------------------------------

        If dt.Rows.Count < 1 Then
            Return False
        End If
        ' db = Nothing
        ddlCMFList.DataSource = dt
        ddlCMFList.DataTextField = "Name"
        ddlCMFList.DataValueField = "CMFId"
        ddlCMFList.SelectedIndex = -1
        ddlCMFList.DataBind()

        '--rajkumar Added 10-Aug-2013
        If CMFID = 0 Then
            CMFID = ddlCMFList.Items(0).Value  'For selecting topmost value
        End If

        Return True
    End Function

    Protected Sub ddlCMFList_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ddlCMFList.SelectedIndexChanged
        CMFID = ddlCMFList.SelectedValue
        Load_TMF()
    End Sub

    '-------just like page_load of CMFForm.aspx page
    Protected Sub Load_TMF()  'just like page_load of CMFForm.aspx page
        ' Dim db As DBAccess
        Try
            'insertTransactionQuality()

            ' If SheetID = 0 Then   'for New TMF
            ''------------------------------------------------For Execute scalar ---for usp
            'conn = New SqlConnection(connCRM)
            'cmd = New SqlCommand()
            'cmd.Connection = conn

            'cmd.Parameters.AddWithValue("lid", customerid)
            'cmd.Parameters.AddWithValue("QAAgentId", UserID)
            'cmd.Parameters.AddWithValue("DialedNumber", "")
            'cmd.Parameters.AddWithValue("CampaignID", CampaignID)
            'cmd.Parameters.AddWithValue("CallTable", "")

            'cmd.CommandType = CommandType.StoredProcedure
            'cmd.CommandText = "usp_InsertTransaction_Quality"
            'conn.Open()
            'TransID = CInt(cmd.ExecuteScalar())
            'cmd = Nothing
            'conn.Close()
            '-----------------------------------------------
            'End If
            ''------------------------------------------------------------------

            lblcmfid.Text = IIf(customerid <> 0 And customerid <> -1, customerid, "")

            txtcomments.Text = "Positives :-" & vbNewLine & "Occurred :-" & vbNewLine & "VNA :-" & vbNewLine & "Soft Skills / Sales Skills :-" & vbNewLine & "Product / Compliance :-" & vbNewLine & "Areas of Improvement :-" & vbNewLine & "Suggestions / POA :-" & vbNewLine & "Others :-"
            getCMFFillHeader()   'To fill Header Information
            CreateForm_TMF()     'For dynamic questions
            PopulateCMF()           'for Category-->Subcategory and drill dowm

            GetTransactionData()    'to fill Transactions details of that Transaction under "Transaction Data"
        Catch ex As Exception
            lblErrorTMF.Text = ex.ToString
            lblErrorTMF.Visible = True
        End Try
    End Sub


    ' Protected Function IsTMFLock(ByVal TransIDTMF As Integer) As Boolean
    Protected Function IsTMFLock() As Boolean

        Dim dtTMF As New DataTable
        Dim varReturn As Boolean = False

        conn = New SqlConnection(connCRM)
        cmd = New SqlCommand()
        'cmd.Parameters.AddWithValue("TransIDTMF", TransIDTMF)
        cmd.Parameters.AddWithValue("CustomerID", customerid)
        cmd.Parameters.AddWithValue("CampID", CampaignID)
        cmd.Connection = conn
        cmd.CommandType = CommandType.StoredProcedure
        cmd.CommandText = "usp_Quality_isTMFexist"

        adp = New SqlDataAdapter(cmd)
        adp.Fill(dtTMF)
        cmd = Nothing
        adp = Nothing

        If dtTMF.Rows.Count > 0 Then  'some other QE is working on this 
            varReturn = True
        Else
            varReturn = False   'no other QE has locked this TransID
        End If

        dtTMF = Nothing

        Return varReturn
    End Function

    Protected Sub Load_TMF_values()
        Try
            ' Dim db As DBAccess
            '------------------------------Rajkumar --Aug
            'db = New DBAccess("CRM")
            'db.slDataAdd("CustomerID", customerid)
            'db.slDataAdd("CampaignID", CampaignID)
            'Dim drID As DataRow = db.ReturnRow("usp_Quality_getCustomerIDDetails", True)
            'db = Nothing
            '------------------------------------------For datarow
            Dim dtRow As New DataTable
            conn = New SqlConnection(connCRM)
            cmd = New SqlCommand()
            cmd.Parameters.AddWithValue("CustomerID", customerid)
            cmd.Parameters.AddWithValue("CampaignID", CampaignID)

            cmd.Connection = conn
            cmd.CommandType = CommandType.StoredProcedure
            cmd.CommandText = "usp_Quality_getCustomerIDDetails"
            adp = New SqlDataAdapter(cmd)
            adp.Fill(dtRow)
            Dim drID As DataRow = dtRow.Rows(0)
            cmd = Nothing
            adp = Nothing
            '------------------------------------------------------------

            '-------------------------------------------
            TransIDTMF = drID("TransId")
            SheetID = drID("SheetID")
            TransDate = drID("TransDate").ToString
            StandaloneCMF = drID("StandAloneCMF")

            If (Not drID("CMFID") Is Nothing) And (drID("CMFID") <> 0) Then  ' if exists then it will override the CMFID upper value 
                CMFID = drID("CMFID")
                ddlCMFList.SelectedValue = CMFID
            End If
            '------------------------------------------
            UserID = AgentID  'Session("AgentID") '========= By Rajendra 25th Sep'13
            lblcmfid.Text = IIf(customerid = -1 Or customerid = 0, "", customerid)
            QEID = UserID
        Catch ex As Exception
            lblErrorTMF.Text = ex.ToString
            lblErrorTMF.Visible = True
        End Try
    End Sub

#End Region

#Region "--------Generate CMF Sheet"

    Private Sub getCMFFillHeader()
        Dim dr As DataRow
        ' Dim db2 As New DBAccess("CRM")
        Try
            'db2.slDataAdd("sheetid", SheetID)
            'db2.slDataAdd("transid", TransIDTMF)
            'db2.slDataAdd("agentid", AgentID)
            'db2.slDataAdd("QEID", QEID)
            'db2.slDataAdd("transdate", TransDate)
            'db2.slDataAdd("CampaignID", CampaignID)

            'dr = db2.ReturnRow("usp_Quality_FillCMFheader", True)
            'db2 = Nothing
            '------------------------------------------For datarow
            Dim dtRow As New DataTable
            conn = New SqlConnection(connCRM)
            cmd = New SqlCommand()

            cmd.Parameters.AddWithValue("sheetid", SheetID)
            cmd.Parameters.AddWithValue("transid", TransIDTMF)
            cmd.Parameters.AddWithValue("agentid", AgentID)
            cmd.Parameters.AddWithValue("QEID", QEID)
            cmd.Parameters.AddWithValue("transdate", TransDate)
            cmd.Parameters.AddWithValue("CampaignID", CampaignID)

            cmd.Connection = conn
            cmd.CommandType = CommandType.StoredProcedure
            cmd.CommandText = "usp_Quality_FillCMFheader"
            adp = New SqlDataAdapter(cmd)
            adp.Fill(dtRow)

            If dtRow.Rows.Count > 0 Then
                dr = dtRow.Rows(0)
            End If

            cmd = Nothing
            adp = Nothing
            '------------------------------------------------------------

            lblQEName.Text = LoginUserName
            If Not dr Is Nothing Then
                lblTMName.Text = dr("AgentName")
                lblProcess2.Text = dr("CampaignName")
                lblevldate.Text = IIf(IsDBNull(dr("EvaluationDate")), "", dr("EvaluationDate"))
                lblTransDate.Text = IIf(IsDBNull(dr("Transdate")), "", dr("Transdate"))
                btFreez = IIf(dr("btFreez") Is Nothing, False, dr("btFreez"))
                CBReferClient.Checked = IIf(IsDBNull(dr("ClientSheet")), "False", dr("ClientSheet"))
                lblQEName.Text = IIf(IsDBNull(dr("QEName")), LoginUserName, dr("QEName"))
                QEAgentID = dr("AgentID")
            End If

            If dr Is Nothing Then
                lblTL.Text = ""
            ElseIf IsDBNull(dr("SupervisorName")) Then
                lblTL.Text = ""
            Else
                lblTL.Text = IIf(dr Is Nothing, "", dr("SupervisorName")) & "(" & dr("SupervisorID") & ")"
            End If
        Catch ex As Exception
            lblErrorTMF.Text = ex.ToString
            lblErrorTMF.Visible = True
        Finally
            ' db2 = Nothing
        End Try

    End Sub

    Private Sub PopulateCMF()
        Try
            'Dim db As New DBAccess("CRM")
            'db.slDataAdd("campid", CampaignID)
            'db.slDataAdd("CMFID", CMFID)
            'db.slDataAdd("sheetID", SheetID)
            'Dim dt As DataTable = db.ReturnTable("usp_Quality_getCategoryHeading", , True)
            'maincat.DataSource = dt
            'maincat.DataBind()
            'db = Nothing
            '-----------------------------------------------------
            Dim dt As New DataTable
            conn = New SqlConnection(connCRM)
            cmd = New SqlCommand()
            cmd.Parameters.AddWithValue("campid", CampaignID)
            cmd.Parameters.AddWithValue("CMFID", CMFID)
            cmd.Parameters.AddWithValue("sheetID", SheetID)

            cmd.Connection = conn
            cmd.CommandType = CommandType.StoredProcedure
            cmd.CommandText = "usp_Quality_getCategoryHeading"
            adp = New SqlDataAdapter(cmd)
            adp.Fill(dt)
            cmd = Nothing
            adp = Nothing
            '---------------------------------------------------------
            maincat.DataSource = dt
            maincat.DataBind()

            'If SheetID <> 0 Then
            '    lblSheetID.Text = "CMF Sheet " & SheetID
            '    lblSheetID.Visible = True
            'Else
            '    lblSheetID.Visible = False
            'End If

            ' Dim dtComm As DataTable
            If SheetID <> 0 Then
                'db = New DBAccess("CRM")
                'db.slDataAdd("campid", CampaignID)
                'db.slDataAdd("Sheetid", SheetID)
                'dtComm = db.ReturnTable("usp_QualityGetDataForLead_final_new", "option", True)
                'db = Nothing
                '------------------------------------------------------------
                Dim dtComm As New DataTable
                conn = New SqlConnection(connCRM)
                cmd = New SqlCommand()
                cmd.Parameters.AddWithValue("campid", CampaignID)
                cmd.Parameters.AddWithValue("Sheetid", SheetID)

                cmd.Connection = conn
                cmd.CommandType = CommandType.StoredProcedure
                cmd.CommandText = "usp_QualityGetDataForLead_final_new"
                adp = New SqlDataAdapter(cmd)
                adp.Fill(dtComm)
                dtComm.TableName = "option"
                cmd = Nothing
                adp = Nothing
                '------------------------------------------------------------
                If dtComm.Rows.Count > 0 Then
                    txtcomments.Text = dtComm.Rows(0).Item("comments")
                    txtComplaints.Text = dtComm.Rows(0).Item("EndUserCompliant")
                End If
            End If

            If btFreez Then
                'db = New DBAccess("CRM")
                'db.slDataAdd("SheetID", SheetID)
                'Dim dr As DataRow = db.ReturnRow("usp_QualityGetSheetQCScore_New", True)
                '------------------------------------------------------------
                Dim dtRow As New DataTable
                conn = New SqlConnection(connCRM)
                cmd = New SqlCommand()
                cmd.Parameters.AddWithValue("Sheetid", SheetID)

                cmd.Connection = conn
                cmd.CommandType = CommandType.StoredProcedure
                cmd.CommandText = "usp_QualityGetSheetQCScore_New"
                adp = New SqlDataAdapter(cmd)
                adp.Fill(dtRow)
                Dim dr As DataRow = dtRow.Rows(0)
                cmd = Nothing
                adp = Nothing
                '------------------------------------------------------------

                PnlScore.Visible = True
                lblFatalError.Text = dr.Item("FatalErrorCount")
                lblFatalErrorpercent.Text = dr.Item("FAR%")
                lblNonFatalError.Text = dr.Item("NonFatalErrorCount")
                lblNonFatalErrorpercent.Text = dr.Item("NFAR%")
                LblParamwisescore.Text = dr.Item("ParameterWiseScore%")
                GridViewExportUtil.PrintPreview(PanelCMF)
                'db = Nothing
            End If

        Catch ex As Exception
            lblErrorTMF.Text = ex.ToString
            lblErrorTMF.Visible = True
        End Try

    End Sub

    Protected Sub maincat_ItemDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.RepeaterItemEventArgs) Handles maincat.ItemDataBound
        Try
            ' Dim db As New DBAccess("CRM")
            'Dim lblcatid1 As Label = e.Item.FindControl("lblcatid")
            'Dim ds As New DataSet
            'Dim subcat As DataTable

            'db.slDataAdd("campid", CampaignID)
            'db.slDataAdd("CMFID", CMFID)
            'db.slDataAdd("mcid", lblcatid1.Text)
            'db.slDataAdd("sheetID", SheetID)

            'MainCatID = lblcatid1.Text
            'subcat = db.ReturnTable("usp_QualityGetSubCategory_New", "subcat", True)
            'db = Nothing
            'ds.Tables.Add(subcat)

            'Dim dtlst1 As Repeater = e.Item.FindControl("subcat")
            'AddHandler dtlst1.ItemDataBound, AddressOf subcat_ItemDataBound
            'dtlst1.DataSource = ds
            'dtlst1.DataBind()
            '----------------------------------------------For datatable
            Dim lblcatid1 As Label = e.Item.FindControl("lblcatid")
            Dim ds As New DataSet
            Dim subcat As New DataTable

            'Dim dtTable As New DataTable
            conn = New SqlConnection(connCRM)
            cmd = New SqlCommand()

            cmd.Parameters.AddWithValue("campid", CampaignID)
            cmd.Parameters.AddWithValue("CMFID", CMFID)
            cmd.Parameters.AddWithValue("mcid", lblcatid1.Text)
            cmd.Parameters.AddWithValue("sheetID", SheetID)

            cmd.Connection = conn
            cmd.CommandType = CommandType.StoredProcedure
            cmd.CommandText = "usp_QualityGetSubCategory_New"
            adp = New SqlDataAdapter(cmd)
            adp.Fill(subcat)
            subcat.TableName = "subcat"
            cmd = Nothing
            adp = Nothing

            MainCatID = lblcatid1.Text
            ds.Tables.Add(subcat)

            Dim dtlst1 As Repeater = e.Item.FindControl("subcat")
            AddHandler dtlst1.ItemDataBound, AddressOf subcat_ItemDataBound
            dtlst1.DataSource = ds
            dtlst1.DataBind()
            '------------------------------------------------------------
        Catch ex As Exception
            lblErrorTMF.Text = ex.ToString
            lblErrorTMF.Visible = True
        End Try
    End Sub

    Protected Sub subcat_ItemDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.RepeaterItemEventArgs)
        Try
            dtparamdata = New DataTable() 'rajkumar Added for memory allocation

            Dim lblcatid1 As Label = e.Item.FindControl("lblcatid1")
            Dim lblsubcatid1 As Label = e.Item.FindControl("lblsubcatid")

            'Dim db As New DBAccess("CRM")
            'db.slDataAdd("mcid", lblcatid1.Text)
            'db.slDataAdd("CMFID", CMFID)
            'db.slDataAdd("scid", lblsubcatid1.Text)

            'SubCatID = lblsubcatid1.Text
            'MainCatID = lblcatid1.Text
            'db.slDataAdd("sheetID", SheetID)
            'dtparamdata = db.ReturnTable("usp_Quality_GetParameters", "Parameter", True)
            'db = Nothing
            '-------------------------------------------------------
            'Dim dtTable As New DataTable
            conn = New SqlConnection(connCRM)
            cmd = New SqlCommand()
            cmd.Parameters.AddWithValue("mcid", lblcatid1.Text)
            cmd.Parameters.AddWithValue("CMFID", CMFID)
            cmd.Parameters.AddWithValue("scid", lblsubcatid1.Text)
            SubCatID = lblsubcatid1.Text
            MainCatID = lblcatid1.Text
            cmd.Parameters.AddWithValue("sheetID", SheetID)


            cmd.Connection = conn
            cmd.CommandType = CommandType.StoredProcedure
            cmd.CommandText = "usp_Quality_GetParameters"
            adp = New SqlDataAdapter(cmd)
            adp.Fill(dtparamdata)
            dtparamdata.TableName = "Parameter"
            cmd = Nothing
            adp = Nothing
            '-------------------------------------------------------


            Dim cols() As String = {"ParamID", "ParmText", "Parametertype"}
            Dim dtq As DataTable = dtparamdata.DefaultView.ToTable(True, cols)
            Dim dtlst2 As DataList = e.Item.FindControl("dtlst")
            Dim pcount As Label = e.Item.FindControl("parameterCount")
            pcount.Text = dtq.Rows.Count
            AddHandler dtlst2.ItemDataBound, AddressOf dtlist_ItemDataBound
            dtlst2.DataSource = dtq
            dtlst2.DataBind()
            Dim ddoptions As DropDownList = e.Item.FindControl("ddlOptions")
            If btFreez Then
                ddoptions.Items.Clear()
            End If
        Catch ex As Exception
            lblErrorTMF.Text = ex.ToString
            lblErrorTMF.Visible = True
        End Try
    End Sub

    Protected Sub dtlist_ItemDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.DataListItemEventArgs)
        Try
            Dim lblcatid1 As Label = e.Item.Parent.Parent.Parent.Parent.FindControl("lblcatid")
            Dim lblsubcatid1 As Label = e.Item.Parent.Parent.FindControl("lblsubcatid")
            Dim ddoptions As DropDownList = e.Item.FindControl("ddParamOption")
            Dim lblparamid As Label = e.Item.FindControl("lblParamid")
            Dim lblparamtype As Label = e.Item.FindControl("lblparamtype")
            Dim lblparam As Label = e.Item.FindControl("lblparam")
            If lblparamtype.Text = "F" Then
                lblparam.ForeColor = System.Drawing.Color.Red
            End If


            Dim cols() As String = {"Optid", "OptionText", "SelectedOption", "Sequence"}
            Dim dtOption As DataTable = dtparamdata.Select("ParamID =" & lblparamid.Text, "Sequence").CopyToDataTable.DefaultView.ToTable(True, cols)
            ddoptions.DataSource = dtOption
            ddoptions.DataTextField = "OptionText"
            ddoptions.DataValueField = "Optid"
            ddoptions.DataBind()
            Dim drOpt() As DataRow = dtOption.Select("SelectedOption is not null")
            If drOpt.Length > 0 Then
                ddoptions.Items.FindByText(drOpt(0)("SelectedOption")).Selected = True
            End If
            '-------Panel Subparameters --start
            Dim chkSubParameter As CheckBoxList = e.Item.FindControl("chkBoxList1")

            Dim cols1() As String = {"SubParamID", "SubParmText", "ParamSequence"}
            Dim cols2() As String = {"Selected"}
            Dim dtSubParameters As New DataTable
            Dim dtSelectedSubParameters As New DataTable
            Dim dr() As DataRow = dtparamdata.Select("SubParamId is not null and ParamID =" & lblparamid.Text, "ParamSequence")
            If dr.Length > 0 Then
                dtSubParameters = dr.CopyToDataTable.DefaultView.ToTable(True, cols1)
                dtSelectedSubParameters = dr.CopyToDataTable.DefaultView.ToTable(True, cols2)
            End If
            If SheetID <> 0 Then
                If dtSubParameters.Rows.Count > 0 Then
                    If ddoptions.SelectedItem.Text = "No" Then
                        Dim pnlSubQues As Panel = e.Item.FindControl("pnlSubQuestions")
                        pnlSubQues.Attributes.Add("style", "display:block")
                    End If
                Else
                    Dim pnlSubQues As Panel = e.Item.FindControl("pnlSubQuestions")
                    pnlSubQues.Attributes.Add("style", "display:none")
                End If
            End If
            If dtSubParameters.Rows.Count > 0 Then
                chkSubParameter.DataValueField = "SubParamID"
                chkSubParameter.DataTextField = "SubParmText"
                chkSubParameter.DataSource = dtSubParameters
                chkSubParameter.DataBind()
            End If
            '-------Panel Subparameters --end
            For Each li As ListItem In chkSubParameter.Items
                Dim r() As DataRow = dtSelectedSubParameters.Select("Selected='" & li.Value & "'")
                If r.Length > 0 Then
                    li.Selected = True
                End If
            Next
        Catch ex As Exception
            lblErrorTMF.Text = ex.ToString
            lblErrorTMF.Visible = True
        End Try
    End Sub

    Private Sub GetTransactionData()
        'Dim dt As New DataTable
        'Dim db As New DBAccess("crm")
        'db.slDataAdd("transid", TransIDTMF)
        'dt = db.ReturnTable("usp_GetCMFTransactionDetails", , True)
        'db = Nothing
        'dlAnswers.DataSource = dt
        'dlAnswers.DataBind()

        '----------------------------------------------For datatable
        Dim dt As New DataTable
        conn = New SqlConnection(connCRM)
        cmd = New SqlCommand()
        cmd.Parameters.AddWithValue("transid", TransIDTMF)

        cmd.Connection = conn
        cmd.CommandType = CommandType.StoredProcedure
        cmd.CommandText = "usp_GetCMFTransactionDetails"
        adp = New SqlDataAdapter(cmd)
        adp.Fill(dt)
        cmd = Nothing
        adp = Nothing
        '------------------------------------------------------------
        dlAnswers.DataSource = dt
        dlAnswers.DataBind()
    End Sub

#End Region

#Region "------------Comments----"
    Protected Sub FreezeTMF()
        Dim tran As SqlTransaction
        Dim SheetTemp As Integer
        Dim SheetDataID As Integer
        ' Dim dtMandatoryQuest As DataTable
        Dim flag As Boolean = False
        Dim transFlag As Boolean = True
        Dim returnNoUse_1 As String = ""
        Dim returnNoUse_2 As String = ""

        'Dim db3 As New DBAccess("CRM")
        'db3.slDataAdd("campaignid", CampaignID)
        'db3.slDataAdd("CMFID", CMFID)
        'db3.slDataAdd("sheetid", SheetID)
        'dtMandatoryQuest = db3.ReturnTable("usp_Quality_GetCMFfields", , True)
        'db3 = Nothing

        '----------------------------------------------For datatable
        Dim dtMandatoryQuest As New DataTable
        conn = New SqlConnection(connCRM)
        cmd = New SqlCommand()
        cmd.Parameters.AddWithValue("campaignid", CampaignID)
        cmd.Parameters.AddWithValue("CMFID", CMFID)
        cmd.Parameters.AddWithValue("sheetid", SheetID)

        cmd.Connection = conn
        cmd.CommandType = CommandType.StoredProcedure
        cmd.CommandText = "usp_Quality_GetCMFfields"
        adp = New SqlDataAdapter(cmd)
        adp.Fill(dtMandatoryQuest)
        cmd = Nothing
        adp = Nothing
        '------------------------------------------------------------

        ' Dim db As New DBAccess("CRM")
        Try
            ' db.BeginTrans() '1


            'db.slDataAdd("campid", CampaignID)
            'db.slDataAdd("qeid", UserID)
            'db.slDataAdd("AgentID", AgentID)
            'db.slDataAdd("CustomerID", customerid)
            'db.slDataAdd("TransID", TransID)
            'db.slDataAdd("CMFID", CMFID)
            'db.slDataAdd("Comments", txtcomments.Text.Trim)
            'db.slDataAdd("btfreez", True)
            'db.slDataAdd("Endusercomp", txtComplaints.Text.Trim)
            'If lblTL.Text.Trim = "" Then
            '    db.slDataAdd("SupervisorID", "")
            'Else
            '    db.slDataAdd("SupervisorID", lblTL.Text.Trim.Substring(lblTL.Text.Trim.LastIndexOf("(")).Replace("(", "").Replace(")", ""))
            'End If
            'db.slDataAdd("ClientSheet", CBReferClient.Checked)
            'For Each row As DataRow In dtMandatoryQuest.Rows
            '    If row.Item("Type") = 1 Then 'For Textbox
            '        db.slDataAdd("UDF" & row("FieldID"), CType(pnlDynamicHeader.FindControl("Field" & row("FieldID") & "TMF"), TextBox).Text)
            '    ElseIf row.Item("Type") = 2 Then 'For DropDownList
            '        db.slDataAdd("UDF" & row("FieldID"), CType(pnlDynamicHeader.FindControl("Field" & row("FieldID") & "TMF" ), DropDownList).SelectedItem.Text)
            '    End If
            'Next
            ''-----------------------------------
            'db.slDataAdd("sheetid", SheetID)
            'If SheetID = 0 Then
            '    If StandaloneCMF Then
            '        db.slDataAdd("StandaloneCMF", StandaloneCMF)
            '        db.slDataAdd("Transactiondate", IIf(TransDate Is Nothing, lblTransDate.Text, TransDate))
            '    End If
            'End If
            'SheetTemp = db.ReturnValue("usp_QualityInsertQMSheetMst_New", True)
            '---------------------------------------------------------------------------------------------------
            '---------------------------------------------------------------------------------------------------
            conn = New SqlConnection(connCRM)
            cmd = New SqlCommand()
            conn.Open()

            tran = conn.BeginTransaction()
            cmd.Transaction = tran

            cmd.Connection = conn
            cmd.Parameters.AddWithValue("campid", CampaignID)
            cmd.Parameters.AddWithValue("qeid", UserID)
            cmd.Parameters.AddWithValue("AgentID", AgentID)
            cmd.Parameters.AddWithValue("CustomerID", customerid)
            cmd.Parameters.AddWithValue("TransID", TransID)
            cmd.Parameters.AddWithValue("CMFID", CMFID)
            cmd.Parameters.AddWithValue("Comments", txtcomments.Text.Trim)
            cmd.Parameters.AddWithValue("btfreez", True)
            cmd.Parameters.AddWithValue("Endusercomp", txtComplaints.Text.Trim)
            If lblTL.Text.Trim = "" Then
                cmd.Parameters.AddWithValue("SupervisorID", "")
            Else
                cmd.Parameters.AddWithValue("SupervisorID", lblTL.Text.Trim.Substring(lblTL.Text.Trim.LastIndexOf("(")).Replace("(", "").Replace(")", ""))
            End If
            cmd.Parameters.AddWithValue("ClientSheet", CBReferClient.Checked)

            For Each row As DataRow In dtMandatoryQuest.Rows
                If row.Item("Type") = 1 Then 'For Textbox
                    cmd.Parameters.AddWithValue("UDF" & row("FieldID"), CType(pnlDynamicHeader.FindControl("Field" & row("FieldID") & "TMF"), TextBox).Text)
                ElseIf row.Item("Type") = 2 Then 'For DropDownList
                    cmd.Parameters.AddWithValue("UDF" & row("FieldID"), CType(pnlDynamicHeader.FindControl("Field" & row("FieldID") & "TMF"), DropDownList).SelectedItem.Text)
                End If
            Next
            '-----------------------------------
            cmd.Parameters.AddWithValue("sheetid", SheetID)
            If SheetID = 0 Then
                If StandaloneCMF Then
                    cmd.Parameters.AddWithValue("StandaloneCMF", StandaloneCMF)
                    cmd.Parameters.AddWithValue("Transactiondate", IIf(TransDate Is Nothing, lblTransDate.Text, TransDate))
                End If
            End If

            cmd.CommandType = CommandType.StoredProcedure
            cmd.CommandText = "usp_QualityInsertQMSheetMst_New"
            ' conn.Open()
            SheetTemp = CInt(cmd.ExecuteScalar())

            ' '' ''cmd = Nothing
            ' '' ''conn.Close()
            '---------------------------------------------------------------------------------------------------
            '---------------------------------------------------------------------------------------------------
            'insert SheetData data
            For Each ctrl As Control In maincat.Controls
                Dim lblcatid1 As Label = ctrl.FindControl("lblcatid")
                Dim rpitem As RepeaterItem = ctrl.FindControl("lblsubcatid")
                For Each rpitem In ctrl.FindControl("subcat").Controls
                    Dim lblsubcatid1 As Label = rpitem.FindControl("lblsubcatid")
                    For Each lstitem As DataListItem In rpitem.FindControl("dtlst").Controls
                        Dim lblparamid As Label = lstitem.FindControl("lblParamid")
                        Dim ddoptions As DropDownList = lstitem.FindControl("ddParamOption")
                        'db.slDataAdd("sheetid", SheetTemp)
                        'db.slDataAdd("campid", CampaignID)
                        'db.slDataAdd("paramid", lblparamid.Text)
                        'db.slDataAdd("optid", ddoptions.SelectedValue)
                        'db.slDataAdd("mcid", lblcatid1.Text)
                        'db.slDataAdd("CMFID", CMFID)
                        'db.slDataAdd("scid", lblsubcatid1.Text)
                        'ddoptions.Enabled = False
                        'SheetDataID = db.ReturnValue("usp_QualityInsertSheetData_New", True)
                        '------------------------------------------------For Execute scalar ---for usp
                        ' '' ''conn = New SqlConnection(connCRM)
                        ' '' ''cmd = New SqlCommand()
                        ' '' ''cmd.Connection = conn
                        cmd = New SqlCommand()
                        cmd.Connection = conn
                        cmd.Transaction = tran

                        cmd.Parameters.AddWithValue("sheetid", SheetTemp)
                        cmd.Parameters.AddWithValue("campid", CampaignID)
                        cmd.Parameters.AddWithValue("paramid", lblparamid.Text)
                        cmd.Parameters.AddWithValue("optid", ddoptions.SelectedValue)
                        cmd.Parameters.AddWithValue("mcid", lblcatid1.Text)
                        cmd.Parameters.AddWithValue("CMFID", CMFID)
                        cmd.Parameters.AddWithValue("scid", lblsubcatid1.Text)
                        ddoptions.Enabled = False

                        cmd.CommandType = CommandType.StoredProcedure
                        cmd.CommandText = "usp_QualityInsertSheetData_New"
                        ' '' ''conn.Open()
                        SheetDataID = CInt(cmd.ExecuteScalar())
                        ' '' ''cmd = Nothing
                        ' '' ''conn.Close()
                        '-----------------------------------------------

                        Dim pnlSubQuestions As Panel = lstitem.FindControl("pnlSubQuestions")
                        Dim chkBoxList As CheckBoxList = pnlSubQuestions.FindControl("chkBoxList1")

                        ' db.DeleteinTable("tbl_Quality_Data_SheetData_SubParams", "SheetDataID=" & SheetDataID)
                        '------------------------------------------------For Execute scalar ---for query
                        ' '' ''conn = New SqlConnection(connCRM)
                        ' '' ''cmd = New SqlCommand()
                        ' '' ''cmd.Connection = conn
                        cmd.CommandType = CommandType.Text
                        cmd.CommandText = "DELETE FROM tbl_Quality_Data_SheetData_SubParams WHERE SheetDataID=" & SheetDataID
                        ' '' ''conn.Open()
                        cmd.ExecuteNonQuery()
                        ' '' ''cmd = Nothing
                        ' '' ''conn.Close()
                        '-----------------------------------------------

                        flag = False
                        If ddoptions.Items.FindByText("No").Selected = True And chkBoxList.Items.Count > 0 Then
                            For Each li As ListItem In chkBoxList.Items
                                If li.Selected Then
                                    flag = True

                                    'db.slDataAdd("SheetDataID", SheetDataID)
                                    'db.slDataAdd("SubParamID", li.Value)
                                    'returnNoUse_1 = db.ReturnValue("usp_Quality_insertSubParameters", True)
                                    '------------------------------------------------For Execute scalar ---for usp
                                    ' '' ''conn = New SqlConnection(connCRM)
                                    ' '' ''cmd = New SqlCommand()
                                    ' '' ''cmd.Connection = conn
                                    cmd = New SqlCommand()
                                    cmd.Connection = conn
                                    cmd.Transaction = tran

                                    cmd.Parameters.AddWithValue("SheetDataID", SheetDataID)
                                    cmd.Parameters.AddWithValue("SubParamID", li.Value)

                                    cmd.CommandType = CommandType.StoredProcedure
                                    cmd.CommandText = "usp_Quality_insertSubParameters"
                                    ' '' ''conn.Open()
                                    returnNoUse_1 = CObj(cmd.ExecuteScalar())
                                    ' '' ''cmd = Nothing
                                    ' '' ''conn.Close()
                                    '-----------------------------------------------
                                End If
                            Next
                        End If

                        '(2)
                        If ddoptions.Items.FindByText("No").Selected = True And chkBoxList.Items.Count > 0 Then 'if "No" is selected in answer option
                            If flag = False Then 'i.e. if not any one subparameter is selected
                                lblErrorTMF.Text = "Please select atleast one Subparameter in selected parameter."
                                lblErrorTMF.Visible = True
                                ' db.RollBackTrans() '2
                                tran.Rollback()

                                transFlag = False
                                Exit Sub
                            End If
                        End If

                    Next
                Next
            Next
            SheetID = SheetTemp


            'db.slDataAdd("Sheetid", SheetID)
            'returnNoUse_2 = db.ReturnValue("usp_QualitySaveSheetQCScore_New", True)
            '------------------------------------------------For Execute scalar ---for usp
            ' '' ''conn = New SqlConnection(connCRM)
            ' '' ''cmd = New SqlCommand()
            ' '' ''cmd.Connection = conn
            cmd = New SqlCommand()
            cmd.Connection = conn
            cmd.Transaction = tran

            cmd.Parameters.AddWithValue("Sheetid", SheetID)
            cmd.CommandType = CommandType.StoredProcedure
            cmd.CommandText = "usp_QualitySaveSheetQCScore_New"
            ' '' ''conn.Open()
            returnNoUse_2 = CObj(cmd.ExecuteScalar())
            ' '' ''cmd = Nothing
            ' '' ''conn.Close()
            '-----------------------------------------------

            'db.CommitTrans() '3
            tran.Commit()

            cmd = Nothing
            'conn.Close()

        Catch ex As Exception
            lblErrorTMF.Text = ex.ToString
            lblErrorTMF.Visible = True
            ' db.RollBackTrans() '4
            tran.Rollback()
            transFlag = False
            Return
        Finally
            'db = Nothing
            conn.Close()
        End Try
        If transFlag Then
            Response.Redirect("~/Quality/CMFForm.aspx?campid=" & Request.QueryString("campid") & "&standalonecmf=" & Request.QueryString("standalonecmf") & "&lid=" & Request.QueryString("lid") & "&agentid=" & Request.QueryString("agentid") & "&TransID=" & Request.QueryString("TransID") & "&CMFID=" & CMFID & "&SheetID=" & SheetID & "&Return=^ListTransactions" & "&LoginUserID=" & UserID & "&LoginUserName=" & LoginUserName)
        End If

    End Sub
#End Region

    '============= By Rajendra on 2013-09-26
#Region "---- Paused Feature"
    Protected Sub btPausedTransaction_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btPausedTransaction.Click
        CheckPausedTransaction()
    End Sub

    Private Sub CheckPausedTransaction()
        If btPausedTransaction.Text.Trim = "Pause Transaction" Then
            Paused = 1
            btPausedTransaction.Text = "Resume Transaction"
            btPausedTransaction.ToolTip = "Resume Transaction"
            pnlPaused.Visible = True
            Showbreak.Visible = False
            pnlshowlist.Visible = False
            pnlshowtracker.Visible = False
            btNewTransactionAssisted.Enabled = False
            btexit.Enabled = False
            btAgentStat.Enabled = False
            btbreak.Enabled = True
            If PausedId = 0 Then
                PasusedTransactions(0)
            Else
                DisableLinks()
                btPausedTransaction.Enabled = True
            End If
        Else
            Paused = 2
            PasusedTransactions(1)
            btPausedTransaction.Text = "Pause Transaction"
            btPausedTransaction.ToolTip = "Pause Transaction"
            pnlPaused.Visible = False
            If OnBreak Then
                Showbreak.Visible = True
            Else
                Showbreak.Visible = False
                pnlshowtracker.Visible = True
                btbreak.Enabled = False
                'pnlshowlist.Visible = True
            End If

        End If
    End Sub
    Private Sub PasusedTransactions(ByVal Flag As Int16)
        conn = New SqlConnection(connCRM)
        cmd = New SqlCommand()
        If PausedId <> 0 Then
            cmd.Parameters.AddWithValue("Id", PausedId)
            PausedId = 0
        End If
        cmd.Parameters.AddWithValue("TransId", TransID)
        cmd.Parameters.AddWithValue("CustomerId", customerid)
        cmd.Parameters.AddWithValue("Campaignid", CampaignID)
        cmd.Parameters.AddWithValue("Flag", Flag)
        cmd.Connection = conn
        conn.Open()
        cmd.CommandType = CommandType.StoredProcedure
        cmd.CommandText = "usp_InsertPausedTransaction"
        PausedId = CInt(cmd.ExecuteScalar()) 'db.ReturnValue("usp_InsertPausedTransaction", True)
        conn.Close()
        cmd = Nothing
        adp = Nothing
    End Sub
    Private Sub DisableLinks()
        If OnBreak Then
            btbreak.Enabled = True
        Else
            btbreak.Enabled = True
        End If
        If Paused = 1 Then
            btbreak.Enabled = True
        ElseIf Paused = 2 Then
        End If
        btNewTransactionAssisted.Enabled = False
        btexit.Enabled = False
        btAgentStat.Enabled = False
    End Sub
    Private Sub LatestPausedTransaction()
        Dim dtLatestTransaction As New DataTable
        conn = New SqlConnection(connCRM)
        cmd = New SqlCommand()
        cmd.Parameters.AddWithValue("CampaignID", CampaignID)
        cmd.Parameters.AddWithValue("AgentID", AgentID)
        cmd.Connection = conn
        conn.Open()
        cmd.CommandType = CommandType.StoredProcedure
        cmd.CommandText = "usp_getLatestPausedTransaction"
        adp = New SqlDataAdapter(cmd)
        adp.Fill(dtLatestTransaction)
        conn.Close()
        cmd = Nothing
        adp = Nothing
        'db.ReturnTable("usp_getLatestPausedTransaction", , True)

        Dim dr As DataRow = Nothing
        If dtLatestTransaction.Rows.Count > 0 Then
            dr = dtLatestTransaction.Rows(0)
        End If
        If Not dr Is Nothing Then
            customerid = dr("CustomerID")
            TransID = dr("ID")
            Paused = 1
            PausedId = dr("PausedId")
            ' lblError.Text = "Your previous transaction was recovered from loss. This is your previous transaction"
        End If
        dtLatestTransaction = Nothing
    End Sub
    Private Sub RecoverPausedTransaction()
        pnlshowtracker.Visible = False
        btNewTransactionAssisted.Enabled = False
        btAgentStat.Enabled = False
        pnlPaused.Visible = True
        btbreak.Enabled = True
        btPausedTransaction.Text = "Resume Transaction"
        btPausedTransaction.ToolTip = "Resume Transaction"
    End Sub
#End Region

    Private Sub ChangeControlsVisiblity2(p1 As Object, p2 As Object, p3 As Object, p4 As Object)
        Throw New NotImplementedException
    End Sub


    Protected Sub btnfreez_Click(sender As Object, e As EventArgs) Handles btnfreez.Click
        SaveTMFdata()
    End Sub
    Protected Sub btnCMFSave_Click(sender As Object, e As EventArgs) Handles btnCMFSave.Click
        SaveTMFdata()
    End Sub


    Private Sub UpdateTransaction(ByVal val As String)
        Dim dbQuality As New DBAccess("CRM")
        dbQuality.slDataAdd("LID", customerid)
        dbQuality.slDataAdd("QAAgentId", UserID)
        dbQuality.slDataAdd("DialedNumber", "")
        dbQuality.slDataAdd("CampaignID", CampaignID)
        dbQuality.slDataAdd("CallTable", "")
        dbQuality.slDataAdd("ToInsert", 0)
        TransIDQuality = dbQuality.ReturnValue("usp_InsertTransaction_Quality", True)
        dbQuality = Nothing
        If TransIDQuality <> "0" Then
            If val = "update" Then
                Dim db As New DBAccess("CRM")
                db.slDataAdd("ID", TransIDQuality)
                db.slDataAdd("CustomerID", customerid)
                db.slDataAdd("ResultCode", -2)
                db.slDataAdd("CampaignID", CampaignID)
                db.Executeproc("usp_DisposeACall")
                db = Nothing
            End If
            If val = "delete" Then
                Dim dbcancel As New DBAccess("CRM")
                dbcancel.slDataAdd("Transid", TransIDQuality)
                dbcancel.Executeproc("usp_deleteTransaction")
                dbcancel = Nothing
            End If
        End If
    End Sub

End Class
