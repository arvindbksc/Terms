﻿Imports LibFolder
Imports com.nss.DBAccess
Imports System.Data
Public Class _TMPerformanceData
    Inherits System.Web.UI.Page

    'Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

    'End Sub

    Dim footerval(12) As Integer
    Dim dt, dt1 As DataTable

#Region "Properties"
    Property CampaignID() As Integer
        Get
            Return ViewState("CampaignID")
        End Get
        Set(ByVal value As Integer)
            ViewState("CampaignID") = value
        End Set
    End Property

    Property AgentID() As String
        Get
            Return ViewState("AgentID")
        End Get
        Set(ByVal value As String)
            ViewState("AgentID") = value
        End Set
    End Property

    Public Property AgentName() As String
        Get
            Return ViewState("AgentName")
        End Get
        Set(ByVal value As String)
            ViewState("AgentName") = value
        End Set
    End Property
#End Region

#Region "Load"
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        HumanMessage.Style.Item("visibility") = "hidden"
        If Not IsPostBack Then
            CampaignID = Request.QueryString("CampaignID")
            AgentID = Request.QueryString("AgentID")
            AgentName = Request.QueryString("AgentName")

            'TrackerHeader1.AgentID = AgentID
            TrackerHeader1.Agentname = AgentName
            'To maximise the Web Page during loading
            ' RegisterClientScriptBlock("", "<script>top.window.moveTo(0,0); top.window.resizeTo(screen.availWidth,screen.availHeight);</script>")
            ClientScript.RegisterClientScriptBlock(Page.GetType(), "", "<script>top.window.moveTo(0,0); top.window.resizeTo(screen.availWidth,screen.availHeight);</script>")

        End If
        fillgrid()
    End Sub

    Private Sub fillgrid()
        For Each obj In footerval
            obj = 0
        Next
        Dim db As New DBAccess

        db.slDataAdd("campaignid", CampaignID)
        db.slDataAdd("agentID", AgentID)

        dt = db.ReturnTable("usp_QuestData_AgentWise", , True)
        db = Nothing
        ' lblReportName.Text = "Transaction Summary "
        ' LblError.Text = "Between " & IntegerToDateString(startday) & "  and " & IntegerToDateString(endday) & " for " & cboCampaigns.SelectedItem.Text & " campaign"

        CreateGridColumns(dt.Columns)
        dt1 = dt.Copy
        For Each col As DataColumn In dt.Columns
            If col.ColumnName.Contains("Question") Then
                dt1.Columns.Remove(col.ColumnName)
            End If
        Next
        dt = dt1
        dt1 = Nothing

        If dt.Rows.Count > 0 Then
            GridView1.DataSource = dt
            GridView1.DataBind()
        End If
    End Sub

#End Region

#Region "Grid Ops"
    Private Sub CreateGridColumns(ByVal cols As DataColumnCollection)
        Dim db As New DBAccess
        db.slDataAdd("CampaignID", CampaignID)
        Dim dtoutcome As DataTable = db.ReturnTable("usp_ReportQuestDataDescription", , True)
        For Each dr In dtoutcome.Rows
            cols("Question" & dr("ReportSequence")).Caption = dr("Caption")
        Next

        Dim objcol As DataColumn

        For Each objcol In cols

            If objcol.ColumnName.Contains("Question") Then
                If objcol.Caption <> objcol.ColumnName Then
                    objcol.ColumnName = objcol.Caption

                End If

            End If
        Next
    End Sub
#End Region

#Region "Utility"
    Private Sub AlertMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMFail"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub
    Private Sub SuccessMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMSuccess"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub

#End Region

End Class