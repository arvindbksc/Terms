﻿Imports System.Data.SqlClient
Imports System.Data
Imports System.Data.Sql
Imports LibFolder.TermsNxt2
Public Class _DeleteTransaction
    Inherits System.Web.UI.Page

    'Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

    'End Sub


    Public Property CampaignID() As Integer
        Get
            Return ViewState("CampaignID")
        End Get
        Set(ByVal value As Integer)
            ViewState("CampaignID") = value
        End Set
    End Property
    Public Property AgentID() As String
        Get
            Return ViewState("AgentID")
        End Get
        Set(ByVal value As String)
            ViewState("AgentID") = value
        End Set
    End Property
    Public Property AgentName() As String
        Get
            Return ViewState("AgentName")
        End Get
        Set(ByVal value As String)
            ViewState("AgentName") = value
        End Set
    End Property
    Public Property IsVerifier() As Boolean
        Get
            Return ViewState("IsVerifier")
        End Get
        Set(ByVal value As Boolean)
            ViewState("IsVerifier") = value
        End Set
    End Property
    Public Property TransID() As Int64
        Get
            Return ViewState("TransID")
        End Get
        Set(ByVal value As Int64)
            ViewState("TransID") = value
        End Set
    End Property
    Public Property customerid() As Integer
        Get
            Return ViewState("customerid")
        End Get
        Set(ByVal value As Integer)
            ViewState("customerid") = value
        End Set
    End Property
    Public Property DailStateBased() As Boolean
        Get
            Return ViewState("DailStateBased")
        End Get
        Set(ByVal value As Boolean)
            ViewState("DailStateBased") = value
        End Set
    End Property
    Dim connCRM As String = Common.connCRM
    Dim connLeads As String = Common.connLeads
    Private Sub CancelTransaction()
        deletetransaction()
        If CampaignID = 341 Then
            Response.Redirect("~/Tracker/_NewTrackerLH.aspx?CampaignID=" & CampaignID & "&AgentId=" & AgentID & "&AgentName=" & AgentName & "&IsVerifier=" & IsVerifier)
        ElseIf CampaignID = 388 Then
            Response.Redirect("~/Tracker/_NewTrackerLH100.aspx?CampaignID=" & CampaignID & "&AgentId=" & AgentID & "&AgentName=" & AgentName & "&IsVerifier=" & IsVerifier)

        Else
            Response.Redirect("~/Tracker/_NewTracker.aspx?CampaignID=" & CampaignID & "&AgentId=" & AgentID & "&AgentName=" & AgentName & "&IsVerifier=" & IsVerifier)
        End If

    End Sub
    Private Sub deletetransaction()
        Dim conn As SqlConnection
        Dim cmd As SqlCommand
        conn = New SqlConnection(connCRM)
        cmd = New SqlCommand()
        cmd.Parameters.AddWithValue("Transid", TransID)
        cmd.Connection = conn
        cmd.CommandType = CommandType.StoredProcedure
        cmd.CommandText = "usp_deleteTransaction"
        conn.Open()
        cmd.ExecuteNonQuery()
        conn.Close()
        cmd = Nothing

        If DailStateBased Then
            conn = New SqlConnection(connLeads)
            cmd = New SqlCommand()
            cmd.Connection = conn
            cmd.CommandType = CommandType.Text
            cmd.CommandText = "UPDATE tbl_LeadMaster" & CampaignID & " SET DialState=0  WHERE customerid=" & customerid
            conn.Open()
            cmd.ExecuteNonQuery()
            conn.Close()
            cmd = Nothing
        End If
    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        CampaignID = Request.QueryString("CampaignID")
        AgentID = Request.QueryString("AgentID")
        AgentName = Request.QueryString("AgentName")
        IsVerifier = Convert.ToBoolean(Request.QueryString("IsVerifier"))
        TransID = Request.QueryString("transid")
        customerid = Request.QueryString("customerid")
        DailStateBased = Convert.ToBoolean(Request.QueryString("DailStateBased"))
        CancelTransaction()
    End Sub
End Class