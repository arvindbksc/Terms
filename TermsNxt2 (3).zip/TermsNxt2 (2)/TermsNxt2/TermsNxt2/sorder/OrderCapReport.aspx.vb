﻿Imports com.nss.DBAccess
Imports System.Data
Partial Class PerfSum_OrderCapReport
    Inherits System.Web.UI.Page
    Private Sub CheckVolumes1()

        Dim ConnectionString As String = "Report"
        Dim dt As DataTable
        Dim dtcount As New DataTable
        Dim objQuestion As New DBAccess(ConnectionString)
        objQuestion.slDataAdd("startdate", ucDateFrom.yyyymmdd)
        objQuestion.slDataAdd("enddate", DateTime.Now.ToString("yyyyMMdd"))
        dt = objQuestion.ReturnTable("usp_GetOrderDetail", , True)
        objQuestion = Nothing
        gdordercap.DataSource = dt
        gdordercap.AutoGenerateColumns = True
        gdordercap.DataBind()

    End Sub
    Private Sub CheckVolumes2()

        Dim ConnectionString As String = "Report"
        'Dim i As Int16 = 0

        Try
            Dim finaltable_new As New DataTable
            'If txtAblSubject.Text <> "" Then
            'Try

            finaltable_new.Columns.Add("OrderDate")
            finaltable_new.Columns.Add("Caption")
            finaltable_new.Columns.Add("PositiveTotal")
            finaltable_new.Columns.Add("Cap")
            finaltable_new.Columns.Add("Volume")
            finaltable_new.Columns.Add("ordernumber")
            finaltable_new.Columns.Add("poscountperctovol")

            Dim dt As DataTable
            Dim dtcount As New DataTable
            Dim objQuestion As New DBAccess(ConnectionString)
            Dim str As String
            str = "select question,max(expectedvolume) as volume,max(ordernumber) as ordernumber,max(startdate) as orderdate "
            str = str + "from tbl_data_ordervolume where startdate < '" & ucDateFrom.yyyymmdd & "' "
            str = str + "and question in (SELECT distinct questtype FROM tbl_Summary_Revenue WHERE [Day] = '" & ucDateFrom.yyyymmdd & "' and sponsored=1 and campaignid in (2,95,208))"
            str = str + "and expectedvolume>0 group by question"
            dt = objQuestion.ReturnTable(str, , False)
            objQuestion = Nothing
            If dt.Rows.Count > 0 Then
                For Each row As DataRow In dt.Rows
                    Dim dr As DataRow = finaltable_new.Rows.Add
                    Dim collectedvolume As Integer = 0
                    Dim objSummary As New DBAccess(ConnectionString)
                    'objSummary.slDataAdd("Processid", row("processid"))
                    'objSummary.slDataAdd("campaignid", row("campaignid"))
                    'objSummary.slDataAdd("QuestCaption", row("question"))
                    'objSummary.slDataAdd("startdate", row("startdate"))
                    'collectedvolume = objSummary.ReturnValue("usp_CollateOrderVolume", True)

                    collectedvolume = objSummary.ReturnValue("select isnull(sum(positive),0) as [collected volume] from tbl_Summary_Revenue where campaignid in (2,95,208) and Questtype='" & row("question").ToString.Trim & "' and [day] >= '" & row.Item(3) & "' and [day]<='" & ucDateFrom.yyyymmdd & "' and Sponsored=1", False)
                    'collectedvolume += row("startvolume")
                    objSummary = Nothing
                    ' If collectedvolume <> 0 Then
                    'If collectedvolume >= row("Expectedvolume") * 0.77 Then
                    '    i = i + 1
                    'Call DraftMail(row("question"), collectedvolume, IIf(row("Expectedvolume") = 0, 1, row("Expectedvolume")), IIf(row("Expectedvolume") = 0, 1, row("Expectedvolume")) * 0.77, row("startdate"))
                    'End If
                    ' End If
                    dr.Item("OrderDate") = row.Item("OrderDate")
                    dr.Item("Caption") = row.Item("question")
                    dr.Item("PositiveTotal") = collectedvolume
                    dr.Item("Cap") = row.Item("volume") * 0.7
                    dr.Item("Volume") = row.Item("volume")
                    dr.Item("ordernumber") = row.Item("ordernumber")
                    'dr.Item("Positive Count to Cap Percentage") = row.Item("Expectedvolume")
                    dr.Item("poscountperctovol") = Math.Round(((collectedvolume) * 100.0) / IIf(IsDBNull(row.Item("volume")), 1, row.Item("volume")), 2)

                Next
                If finaltable_new.Rows.Count > 0 Then
                    gdordercap.DataSource = finaltable_new
                Else
                    gdordercap.DataSource = Nothing
                End If
                gdordercap.AutoGenerateColumns = False

                gdordercap.DataBind()
            End If

        Catch ex As Exception
            MsgBox(ex.Message)

        End Try

    End Sub
    Private Sub checkvolume()
        Dim i As Integer = 0
        Try
            Dim dt As DataTable
            Dim dtcount As New DataTable

            Dim objQuestion As New DBAccess("ordercap")
            'dt = objQuestion.ReturnTable("SELECT DISTINCT Caption, OrderDate FROM [tbl_OrderCap_Orion] WHERE [Date] = CONVERT(INT,CONVERT(VARCHAR(8),GETDATE()-1,112)) AND (Caption IS NOT NULL OR OrderDate IS NOT NULL)", , False)
            dt = objQuestion.ReturnTable("SELECT DISTINCT Caption, max(OrderDate) FROM [tbl_OrderCap_Orion] WHERE [Date] = '" & ucDateFrom.yyyymmdd & "' AND (Caption IS NOT NULL OR OrderDate IS NOT NULL) group by Caption", , False)
            objQuestion = Nothing
            If dt.Rows.Count > 0 Then
                For Each row As DataRow In dt.Rows
                    Dim objSummary As New DBAccess("ordercap")
                    'Dim dr As DataRow '= dtcount.Row

                    Dim dt1 As DataTable = objSummary.ReturnTable("SELECT Caption,max(OrderDate) as orderdate, SUM([Count]) AS PositiveTotal, ISNULL(MAX(Volume),0) AS [Volume],ISNULL(MAX(Volume),0) * .70 as cap,Convert(decimal(10,2),(SUM([Count])*100.0)/ISNULL(MAX(Volume),1)) as poscountperctovol,max(ordernumber) as ordernumber FROM [tbl_OrderCap_Orion] WHERE isPositive = 1 AND Caption = '" & row.Item(0).ToString.Trim & "' AND [Date] <= '" & ucDateFrom.yyyymmdd & "' and [Date]>= '" & row.Item(1) & "' GROUP BY Caption ORDER BY Caption", , False)
                    'dtcount = objSummary.ReturnTable("SELECT Caption, SUM([Count]) AS [Positive Total], ISNULL(MAX(Volume),0) AS [Volume] FROM [tbl_OrderCap_Orion] WHERE isPositive = 1 AND Caption = '" & row.Item(0).ToString.Trim & "' AND [Date] >= " & row.Item(1) & " GROUP BY Caption ORDER BY Caption", , False)
                    objSummary = Nothing
                    If dt1.Rows.Count > 0 Then
                        dtcount.Merge(dt1)
                        dt1 = Nothing
                        'If dr.Item(1) >= dr.Item(2) * 0.77 Then
                        '    i = i + 1
                        '    Call getbreachedorder(dr.Item(0), dr.Item(1), dr.Item(2), dr.Item(2) * 0.77, row.Item(1))
                        'End If
                    End If
                Next
                If dtcount.Rows.Count > 0 Then
                    gdordercap.DataSource = dtcount
                Else
                    gdordercap.DataSource = Nothing
                End If
                gdordercap.AutoGenerateColumns = False

                gdordercap.DataBind()
            End If
        Catch ex As Exception
            MsgBox(ex.Message)

        End Try
    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            'calfrom.SelectedDate = DateTime.Now.AddDays(-1)
            ucDateFrom.value = DateTime.Now.AddDays(-20)
            UcDateTo.value = DateTime.Now.AddDays(-1)
            'calto.SelectedDate = DateTime.Now.AddDays(-1)
            CheckVolumes1()
        End If

    End Sub

    Protected Sub btnRefresh_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnRefresh.Click
        CheckVolumes1()
    End Sub

    Protected Sub gdordercap_RowDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles gdordercap.RowDataBound
        'For Each row As GridViewRow In gdordercap.Rows
        If e.Row.RowType <> DataControlRowType.DataRow Then Return

        If e.Row.Cells(7).Text >= 70 Then
            e.Row.Cells(7).BackColor = Drawing.Color.Green
            e.Row.Cells(7).ForeColor = Drawing.Color.White
        End If
        Dim d As Date
        d = e.Row.Cells(4).Text.Substring(0, 4) & "-" & e.Row.Cells(4).Text.Substring(4, 2) & "-" & e.Row.Cells(4).Text.Substring(6, 2)
        e.Row.Cells(4).Text = d.ToString("dd-MMM-yy")
        'Next
    End Sub
End Class
