﻿Imports com.nss.DBAccess
Imports System.Data
Partial Class PerfSum_setorder
    Inherits System.Web.UI.Page
    Private Sub CheckVolumes1()

        Dim ConnectionString As String = "Report"
        Dim dt As DataTable
        Dim dtcount As New DataTable
        Dim objQuestion As New DBAccess(ConnectionString)
        objQuestion.slDataAdd("startdate", ucDateFrom.yyyymmdd)
        objQuestion.slDataAdd("enddate", DateTime.Now.ToString("yyyyMMdd"))
        dt = objQuestion.ReturnTable("usp_GetOrderDetail", , True)
        objQuestion = Nothing
        gdordercap.DataSource = dt
        gdordercap.AutoGenerateColumns = False
        gdordercap.DataBind()


    End Sub
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            'calfrom.SelectedDate = DateTime.Now.AddDays(-1)
            ucDateFrom.value = DateTime.Now.AddDays(-1)
            UcDateTo.value = DateTime.Now.AddDays(-1)
            'calto.SelectedDate = DateTime.Now.AddDays(-1)
            getclientcode()
            CheckVolumes1()
            PrepareControls()
        End If

    End Sub
    Protected Sub btnRefresh_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnRefresh.Click
        CheckVolumes1()
    End Sub
    Protected Sub gdordercap_RowCancelingEdit(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewCancelEditEventArgs) Handles gdordercap.RowCancelingEdit
        gdordercap.EditIndex = -1
        CheckVolumes1()
    End Sub
    Protected Sub gdordercap_RowEditing(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewEditEventArgs) Handles gdordercap.RowEditing
        gdordercap.EditIndex = e.NewEditIndex
        CheckVolumes1()
        'Dim OrderDate, volume As TextBox
        'Dim row As GridViewRow = gdordercap.Rows(e.NewEditIndex)
        'volume = CType(gdordercap.Rows(row.RowIndex).Cells(5).FindControl("txtVolume"), TextBox)
        'OrderDate = CType(gdordercap.Rows(row.RowIndex).Cells(4).FindControl("txtOrderDate"), TextBox)
        'OrderDate.ReadOnly = False
        ''OrderDate.CssClass = "gridupdatetextbox"
        'volume.ReadOnly = False
        'volume.CssClass = "gridupdatetextbox"
        'Dim j As Integer = row.Cells.Count
        'For k As Integer = 1 To j - 3
        'If gdordercap.HeaderRow.Cells(k).Text = "ClientCode" Then
        'row.Cells(1).Enabled = False
        'row.Cells(2).Enabled = False
        'row.Cells(6).Enabled = False
        'row.Cells(7).Enabled = False
        ' End If
        'Next
    End Sub
    Protected Sub gdordercap_RowUpdating(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewUpdateEventArgs) Handles gdordercap.RowUpdating
       
        'Dim i, j As Integer
        'i = gdordercap.DataKeys(e.RowIndex).Value
        Dim row As GridViewRow = gdordercap.Rows(e.RowIndex)
        'j = row.Cells.Count
        Dim db As New DBAccess("Roster")
        'Dim volume As TextBox

        'For k As Integer = 1 To j - 3
        'Dim t As TextBox
        't = row.Cells(k).Controls(0)
        Dim OrderDate, newvolume As TextBox
        Dim question, OrderNumber, clientcode, rate1 As Label
        clientcode = CType(gdordercap.Rows(row.RowIndex).Cells(1).FindControl("lblclientcode"), Label)
        question = CType(gdordercap.Rows(row.RowIndex).Cells(2).FindControl("lblQuestion"), Label)
        OrderNumber = CType(gdordercap.Rows(row.RowIndex).Cells(3).FindControl("lblOrderNumber"), Label)
        newvolume = CType(gdordercap.Rows(row.RowIndex).Cells(5).FindControl("txtVolume"), TextBox)
        OrderDate = CType(gdordercap.Rows(row.RowIndex).Cells(4).FindControl("txtOrderDate"), TextBox)
        rate1 = CType(gdordercap.Rows(row.RowIndex).Cells(7).FindControl("lblPricePerLead"), Label)
        db.slDataAdd("ClientCode", clientcode.Text)
        db.slDataAdd("Question", question.Text)
        db.slDataAdd("OrderNumber", OrderNumber.Text)
        db.slDataAdd("OrderDate", OrderDate.Text)
        db.slDataAdd("Volume", newvolume.Text)
        db.slDataAdd("Rate", rate1.Text)
        db.slDataAdd("flag", "U")
        'db.Executeproc("dbo.usp_updateorder")
        db.Executeproc("usp_updateorder")
        db = Nothing
        gdordercap.EditIndex = -1
        CheckVolumes1()
    End Sub
    
   

    Protected Sub ucDateFrom_Changed(ByVal sender As Object, ByVal e As System.EventArgs) Handles ucDateFrom.Changed
        CheckVolumes1()
    End Sub

    Protected Sub UcDateTo_Changed(ByVal sender As Object, ByVal e As System.EventArgs) Handles UcDateTo.Changed
        CheckVolumes1()
    End Sub

    Protected Sub lnkNewOrder_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles lnkNewOrder.Click
        Dim str As String
        str = "$('#DialogBackground').height($(document).height()-10);$('#DialogBackground').width($(window).width());$('#DialogBackground').css('visibility','visible');$('#PanelMove').css('visibility','visible');" & _
        " $('#PanelMove').css('left',($(window).width() - $('#PanelMove').width())/2); "
        ScriptManager.RegisterStartupScript(Page, Page.GetType(), "Movedialog", str, True)
    End Sub
    Private Sub SaveNewOrder()

        Dim orderdate As String
        Dim oldorderdate As String
        Dim day, month As String
        day = Now.Day.ToString
        month = Now.Month.ToString
        If day < 10 Then
            day = "0" + day
        End If
        If month < 10 Then
            month = "0" + month
        End If
        oldorderdate = Now.Year.ToString + month + day
        orderdate = CboYear.SelectedValue + CboMonth.SelectedValue + CboDay.SelectedValue
        If orderdate < oldorderdate Then
            AlertMessage("Order date can not be less then current date")
            Exit Sub
        End If
        Dim db As New DBAccess("Roster")
        Dim dt As DataTable = db.ReturnTable("select * from tbl_ordercap where clientcode='" & cboclientcode.SelectedValue & "' and OrderNumber='" & txtordernumber.Text.Trim & "'", , False)
        db = Nothing
        If dt.Rows.Count > 0 Then
            '= "New Order can not has existing order number"
            Exit Sub
        End If
        db = New DBAccess("roster")
        db.slDataAdd("ClientCode", cboclientcode.SelectedValue)
        db.slDataAdd("Question", cboclientcode.SelectedItem.Text.Substring(0, cboclientcode.SelectedItem.Text.IndexOf("(")))
        db.slDataAdd("OrderNumber", txtordernumber.Text.Trim)
        db.slDataAdd("OrderDate", orderdate)
        db.slDataAdd("Volume", txtvolume.Text.Trim)
        db.slDataAdd("Rate", txtprice.Text.Trim)
        db.slDataAdd("flag", "N")
        db.Executeproc("usp_updateorder")
        db = Nothing
        'Response.Write("Order has been placed; it would be update by next 24 hours")
        txtordernumber.Text = ""
        txtvolume.Text = ""
       
        txtprice.Text = ""
        lblerror.Text = "New Order has been Placed; it would be update by next 24 hours"
        lblerror.Visible = True
    End Sub

    Private Sub getclientcode()
        Dim db As New DBAccess("report")
        Dim dt As DataTable = db.ReturnTable("select question + '(' + convert(varchar,clientcode) +')' as Caption, clientcode,question from tbl_data_ordervolume where active=1 order by clientcode", , False)
        cboclientcode.DataSource = dt
        cboclientcode.DataTextField = "caption"
        cboclientcode.DataValueField = "clientcode"
        cboclientcode.DataBind()
        dt = Nothing
        db = Nothing
        'db = New DBAccess("report")
        'Dim question As String
        'question = db.ReturnValue("select question from tbl_data_ordervolume where clientcode='" & cboclientcode.SelectedValue & "'", False)
        'txtquestion1.Text = question
        'db = Nothing
    End Sub
    Private Sub PrepareControls()
        Dim CurrentDate As Date
        CurrentDate = DateTime.Now
        CboDay.Items.Clear()

        For ictr As Integer = 1 To 31
            CboDay.Items.Add(ictr)

        Next
        CboDay.Items.FindByText(CurrentDate.Day).Selected = True

        CboMonth.Items.Clear()

        For ictr As Integer = 1 To 12
            CboMonth.Items.Add(MonthName(ictr, True))

        Next
        CboMonth.Items.FindByText(MonthName(CurrentDate.Month, True)).Selected = True

        CboYear.Items.Clear()

        For ictr As Integer = 2009 To 2020
            CboYear.Items.Add(ictr)

        Next
        CboYear.Items.FindByText(CurrentDate.Year).Selected = True

    End Sub
    Protected Sub btnSave_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnSave.Click
        AlertMessage("Could not save the new order!")
    End Sub

#Region "Utility"

    Private Sub AlertMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMFail"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub

    Private Sub SuccessMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMSuccess"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub

    Protected Sub ImageButton1_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton1.Click
        'fillgrid()
        GridViewExportUtil.Export(lblReportName.Text & "-" & lblerror.Text & ".xls", Me.gdordercap)
    End Sub


    Public Overrides Sub VerifyRenderingInServerForm(ByVal Control As Control)

    End Sub
#End Region
End Class
