﻿Imports com.nss.DBAccess
Imports System.Data
Partial Class PerfSum_Approveorder
    Inherits System.Web.UI.Page
    Private Sub getupdatedorder()
        Dim dt As DataTable
        Dim dtcount As New DataTable
        Dim objQuestion As New DBAccess("Roster")
        Dim strsql As String
        If CboProcess.SelectedValue = "1" Then
            strsql = "select * from tbl_ordercap where status='U'"
        Else
            strsql = "select * from tbl_ordercap where status='N'"
        End If
        dt = objQuestion.ReturnTable(strsql, , False)
        objQuestion = Nothing
        gdordercap.DataSource = dt
        gdordercap.AutoGenerateColumns = False
        gdordercap.DataBind()
    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            getupdatedorder()
        End If
    End Sub

    Protected Sub CboProcess_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles CboProcess.SelectedIndexChanged
        getupdatedorder()
    End Sub

    Protected Sub gdordercap_RowCommand(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewCommandEventArgs) Handles gdordercap.RowCommand
        Dim currentcommand As String = e.CommandName
        Dim currentrowindex As Integer = Int32.Parse(e.CommandArgument)
        Dim clientcode As String = gdordercap.DataKeys(currentrowindex).Value
        If currentcommand = "Approved" Then
            Dim db As New DBAccess("Roster")
            Dim strsql As String
            strsql = "update tbl_ordercap set approved=1 where clientcode='" & clientcode & "'"
            db.exeSQL(strsql)
            db = Nothing
        ElseIf currentcommand = "Cancel" Then
            Dim db As New DBAccess("Roster")
            Dim strsql As String
            strsql = "update tbl_ordercap set approved=2 where clientcode='" & clientcode & "'"
            db.exeSQL(strsql)
            db = Nothing
        End If
        getupdatedorder()
    End Sub
End Class
