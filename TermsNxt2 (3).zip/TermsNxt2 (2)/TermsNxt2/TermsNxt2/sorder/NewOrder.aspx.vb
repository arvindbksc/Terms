﻿Imports com.nss.DBAccess
Imports System.Data
Partial Class PerfSum_NewOrder
    Inherits System.Web.UI.Page
    Private Sub getclientcode()
        Dim db As New DBAccess("report")
        Dim dt As DataTable = db.ReturnTable("select clientcode from tbl_data_ordervolume where active=1 order by clientcode", , False)
        cboclientcode.DataSource = dt
        cboclientcode.DataTextField = "clientcode"
        cboclientcode.DataValueField = "clientcode"
        cboclientcode.DataBind()
        dt = Nothing
        db = Nothing
        db = New DBAccess("report")
        Dim question As String
        question = db.ReturnValue("select question from tbl_data_ordervolume where clientcode='" & cboclientcode.SelectedValue & "'", False)
        txtquestion1.Text = question
        db = Nothing
    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            getclientcode()
            'btclose.Attributes.Add("OnClick", "close1()")
        End If

    End Sub

    Protected Sub btsave_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btsave.Click
        Dim db As New DBAccess("Roster")
        Dim orderdate As String
        Dim oldorderdate As String
        Dim day, month As String
        day = Now.Day.ToString
        month = Now.Month.ToString
        If day < 10 Then
            day = "0" + day
        End If
        If month < 10 Then
            month = "0" + month
        End If
        oldorderdate = Now.Year.ToString + month + day
        orderdate = cboyear.SelectedValue + cbomonth.SelectedValue + cboday.SelectedValue
        If orderdate < oldorderdate Then
            lblerror.Text = "Order date can not be less then current date"
            Exit Sub
        End If
        Dim dt As DataTable = db.ReturnTable("select * from tbl_ordercap where clientcode='" & cboclientcode.SelectedValue & "' and OrderNumber='" & txtordernumber.Text.Trim & "'", , False)
        db = Nothing
        If dt.Rows.Count > 0 Then
            lblerror.Text = "New Order can not has existing order number"
            Exit Sub
        End If
        db = New DBAccess("roster")
        db.slDataAdd("ClientCode", cboclientcode.SelectedValue)
        db.slDataAdd("Question", txtquestion1.Text.Trim)
        db.slDataAdd("OrderNumber", txtordernumber.Text.Trim)
        db.slDataAdd("OrderDate", orderdate)
        db.slDataAdd("Volume", txtvolume.Text.Trim)
        db.slDataAdd("Rate", txtprice.Text.Trim)
        db.slDataAdd("flag", "N")
        db.Executeproc("usp_updateorder")
        db = Nothing
        'Response.Write("Order has been placed; it would be update by next 24 hours")
        txtordernumber.Text = ""
        txtvolume.Text = ""
        cbomonth.SelectedIndex = 1
        cboday.SelectedIndex = 1
        cboclientcode.SelectedIndex = 1
        txtprice.Text = ""
        lblerror.Text = "New Order has been Placed; it would be update by next 24 hours"
        lblerror.Visible = True
    End Sub
    Protected Sub cboclientcode_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboclientcode.SelectedIndexChanged
        Dim db As New DBAccess("report")
        Dim question As String
        txtquestion1.Text = ""
        question = db.ReturnValue("select question from tbl_data_ordervolume where clientcode='" & cboclientcode.SelectedValue & "'", False)
        txtquestion1.Text = question

        db = Nothing
    End Sub
End Class
