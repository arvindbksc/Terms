﻿Imports Microsoft.VisualBasic
Namespace TermsNxt2

    Public Class TemplateAgentName
        Implements ITemplate, INamingContainer

        Private _DataTextField As String
        Public Property DataTextField() As String
            Get
                Return _DataTextField
            End Get
            Set(ByVal value As String)
                _DataTextField = value
            End Set
        End Property
        Private _DataImageField As String
        Public Property DataImageField() As String
            Get
                Return _DataImageField
            End Get
            Set(ByVal value As String)
                _DataImageField = value
            End Set
        End Property
        Public Sub InstantiateIn(ByVal container As System.Web.UI.Control) Implements System.Web.UI.ITemplate.InstantiateIn
            Dim lc As New LiteralControl
            AddHandler lc.DataBinding, AddressOf BindLiteralControl
            'container.Controls.Add(lc)
            Dim img As New Image
            AddHandler img.DataBinding, AddressOf BindImageControl
            img.CssClass = "noprint"
            Dim tb As New Table
            tb.CellPadding = 0
            tb.CellSpacing = 0
            Dim tr As New TableRow
            Dim td As New TableCell
            td.Width = 20
            td.BorderStyle = BorderStyle.None
            td.CssClass = "nametable"
            td.Controls.Add(img)
            tr.Cells.Add(td)
            td = New TableCell
            td.CssClass = "nametable"
            td.BorderStyle = BorderStyle.None
            td.HorizontalAlign = HorizontalAlign.Left
            td.Controls.Add(lc)
            tr.Cells.Add(td)

            tr.BorderStyle = BorderStyle.None
            tb.Rows.Add(tr)
            tb.CssClass = "nametable"

            tb.Style.Add("align", "left")
            container.Controls.AddAt(0, tb)
        End Sub
        Private Sub BindLiteralControl(ByVal sender As Object, ByVal e As System.EventArgs)
            Dim lc As LiteralControl
            lc = sender
            Dim row As GridViewRow = CType(lc.NamingContainer, GridViewRow)
            lc.Text = DataBinder.Eval(row.DataItem, "[" & DataTextField & "]")
        End Sub

        Private Sub BindImageControl(ByVal sender As Object, ByVal e As System.EventArgs)
            Dim lc As Image
            lc = sender
            Dim row As GridViewRow = CType(lc.NamingContainer, GridViewRow)
            Dim agentstatus As Int16 = DataBinder.Eval(row.DataItem, "[" & DataImageField & "]")
            If agentstatus = 254 Then
                lc.ImageUrl = "~/_assets/img/offline.gif"
            ElseIf agentstatus = 1 Then
                lc.ImageUrl = "~/_assets/img/onbreak.gif"
            Else

                lc.ImageUrl = "~/_assets/img/online.gif"

            End If
        End Sub
    End Class
End Namespace