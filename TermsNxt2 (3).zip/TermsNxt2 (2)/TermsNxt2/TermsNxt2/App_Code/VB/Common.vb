﻿Imports Microsoft.VisualBasic
Imports com.nss.DBAccess
Imports System.Data
Imports System.IO
Imports System.Net
Namespace TermsNxt2
    Public Class Common
        Public Shared Function TimeString(ByVal Seconds As Long) As String

            'if verbose = false, returns
            'something like
            '02:22.08
            'if true, returns
            '2 hours, 22 minutes, and 8 seconds

            Dim lHrs As Long
            Dim lMinutes As Long
            Dim lSeconds As Long

            lSeconds = Seconds

            lHrs = Int(lSeconds / 3600)
            lMinutes = (Int(lSeconds / 60)) - (lHrs * 60)
            lSeconds = Int(lSeconds Mod 60)

            If lSeconds = 60 Then
                lMinutes = lMinutes + 1
                lSeconds = 0
            End If

            If lMinutes = 60 Then
                lMinutes = 0
                lHrs = lHrs + 1
            End If

            TimeString = lHrs.ToString("####00") & ":" &
        lMinutes.ToString("00") & ":" &
         lSeconds.ToString("00")

        End Function

        Public Shared Sub FillProcessCampaigns(ByRef cboprocess As DropDownList, ByRef cbocampaigns As DropDownList, ByVal AgentID As String, Optional ByVal CampaignID As Integer = 0, Optional ByVal Processid As Integer = 0)
            FillProcesses(cboprocess, AgentID, Processid)
            'If Processid <= 0 Then
            FillCampaigns(cbocampaigns, AgentID, cboprocess.SelectedValue, CampaignID)
            'End If
        End Sub
        Public Shared Sub FillProcesses(ByRef cboprocess As DropDownList, ByVal AgentID As String, Optional ByVal Processid As Integer = -1)
            Dim db As New DBAccess("Report")
            Dim dt As DataTable
            db.slDataAdd("AgentID", AgentID)
            dt = db.ReturnTable("usp_MyProcesses", , True)
            Dim dr As DataRow
            dr = dt.NewRow
            dr("ProcessName") = "All"
            dr("ProcessID") = 0
            dt.Rows.Add(dr)
            db = Nothing
            cboprocess.DataTextField = "ProcessName"
            cboprocess.DataValueField = "ProcessID"
            cboprocess.DataSource = dt
            cboprocess.DataBind()
            If Processid <> -1 Then
                cboprocess.Items.FindByValue(Processid).Selected = True

            End If
        End Sub
        Public Shared Sub FillCampaigns(ByRef cbocampaigns As DropDownList, ByVal AgentID As String, Optional ByVal Procesid As Integer = 0, Optional ByVal CampaignID As Integer = 0)
            Dim dbt As New DBAccess()
            dbt.slDataAdd("AgentID", AgentID)
            If Procesid > 0 Then
                dbt.slDataAdd("ProcessID", Procesid)
            End If
            Dim dtc As DataTable = dbt.ReturnTable("usp_MyCampaigns", , True)
            dbt = Nothing
            Dim dr As DataRow = dtc.NewRow
            dr("Name") = "All"
            dr("CampaignId") = 0
            dtc.Rows.Add(dr)
            cbocampaigns.DataTextField = "Name"
            cbocampaigns.DataValueField = "CampaignId"
            cbocampaigns.DataSource = dtc

            cbocampaigns.DataBind()
            cbocampaigns.SelectedIndex = -1
            If cbocampaigns.Items.FindByValue(CampaignID) Is Nothing Then
                cbocampaigns.Items.FindByValue(0).Selected = True
            Else
                cbocampaigns.Items.FindByValue(CampaignID).Selected = True
            End If

        End Sub

        Public Shared Sub FillDatePeriod(ByVal cboPeriod As DropDownList)
            Dim db As New DBAccess
            Dim dt As DataTable = db.ReturnTable("select * from tbl_Reports_DatePeriods")
            db = Nothing
            cboPeriod.DataTextField = "Caption"
            cboPeriod.DataValueField = "Period"
            cboPeriod.DataSource = dt
            cboPeriod.DataBind()

        End Sub

        Public Shared Sub FillReportsGroupBy(ByVal CboGroup As DropDownList)
            Dim db As New DBAccess
            Dim dt As DataTable = db.ReturnTable("Select * from tbl_Reports_GroupBy")
            db = Nothing
            CboGroup.DataTextField = "Caption"
            CboGroup.DataValueField = "ID"
            CboGroup.DataSource = dt
            CboGroup.DataBind()
        End Sub

        Public Shared Function GetMenu(ByVal URL As System.Uri, ByVal Agentid As String, ByVal ApplicationPath As String) As HtmlTable
            Dim strPath(), pagepath, urlpath(), actualpath As String
            Dim slashcount As Integer
            'If URL.Host = "localhost" Then
            '    pagepath = URL.ToString.Substring(URL.ToString.ToLower.LastIndexOf("terms2.0/") + 9, URL.ToString.Length - (URL.ToString.ToLower.LastIndexOf("terms2.0/") + 9))
            'Else
            '    pagepath = URL.ToString.Substring(URL.ToString.ToLower.LastIndexOf(".com/") + 5, URL.ToString.Length - (URL.ToString.ToLower.LastIndexOf(".com/") + 5))
            'End If
            If ApplicationPath <> "/" Then
                pagepath = URL.AbsolutePath.ToString.Substring(URL.AbsolutePath.ToString.IndexOf(ApplicationPath) + ApplicationPath.Length + 1)
            Else
                pagepath = URL.AbsolutePath.ToString.Substring(1)
            End If
            slashcount = CountCharacter(pagepath, "/")
            urlpath = URL.ToString.Replace("http://", "").Split("/")
            If URL.Host = "localhost" Then
                actualpath = urlpath(0) & "/Terms-Monitor"
            Else
                actualpath = urlpath(0)
            End If


            strPath = URL.Segments()
            Dim db As New DBAccess
            db.slDataAdd("agentid", Agentid)
            If slashcount > 1 Then
                db.slDataAdd("module", strPath(strPath.Length - 3).Replace("/", ""))
            Else
                db.slDataAdd("module", strPath(strPath.Length - 2).Replace("/", ""))
            End If

            'Dim dt As DataTable = db.ReturnTable("usp_getUserMenu", , True)
            Dim dt As DataTable = db.ReturnTable("usp_GetUserMenu_bkup_20190205", , True)
            db = Nothing
            Dim row As DataRow
            Dim tbl As New HtmlTable
            tbl.Attributes.Add("class", "menu")
            tbl.CellPadding = 4
            tbl.CellSpacing = 4
            Dim tr As HtmlTableRow
            Dim td As HtmlTableCell
            'Dim serverpath As String
            'If URL.Host = "localhost" Then
            '    serverpath = HttpContext.Current.Request.ApplicationPath
            'Else
            '    serverpath = "http://termsmonitor.niitsmartserve.com"
            'End If
            For Each row In dt.Rows

                '-------'
                tr = New HtmlTableRow
                td = New HtmlTableCell
                td.InnerHtml = "<a href='" & "http://" & actualpath & "/" & row("shorturl") & "'><div class='item'><span class='left'>" &
                        row("name") & "</span><span class='right'><img src='/_assets/img/graygo.PNG" & "' /></span></div></a>"
                tr.Cells.Add(td)
                tbl.Rows.Add(tr)

            Next

            Return tbl
        End Function

        Public Shared Function SMTPSendMail(strTo As String, strSUB As String, strFrom As String, strBody As String, strCC As String, strBCC As String) As Boolean
            Try
                Dim ObjMail As New Mail.MailMessage()
                ObjMail.From = New Mail.MailAddress(strFrom)
                ObjMail.To.Add(strTo)
                ObjMail.Subject = strSUB
                ObjMail.IsBodyHtml = True
                ObjMail.Body = strBody
                ObjMail.CC.Add(strCC)
                ObjMail.Bcc.Add(strBCC)
                Dim objsmtp As New Net.Mail.SmtpClient
                objsmtp.DeliveryMethod = Mail.SmtpDeliveryMethod.Network
                objsmtp.UseDefaultCredentials = True
                objsmtp.Host = System.Configuration.ConfigurationManager.AppSettings("SMTPHost")
                objsmtp.Port = System.Configuration.ConfigurationManager.AppSettings("SMTPPort")
                objsmtp.EnableSsl = False
                'asynchronous timeout
                'objsmtp.Timeout = 0
                objsmtp.Send(ObjMail)
                Return True



            Catch ex As Exception
                Throw ex
                Return False
            End Try

        End Function

        Public Shared Function AuthenticatePage(ByVal URL As System.Uri, ByVal Agentid As String, ByVal ApplicationPath As String) As Boolean
            Dim strPath(), pagepath As String
            'Dim slashcount As Integer
            'If URL.Host = "localhost" Then
            '    pagepath = URL.ToString.Substring(URL.ToString.ToLower.LastIndexOf("terms2.0/") + 9, URL.ToString.Length - (URL.ToString.ToLower.LastIndexOf("terms2.0/") + 9))
            'ElseIf URL.ToString.ToLower.Contains(".com/") Then
            '    pagepath = URL.ToString.Substring(URL.ToString.ToLower.LastIndexOf(".com/") + 5, URL.ToString.Length - (URL.ToString.ToLower.LastIndexOf(".com/") + 5))
            'Else
            '    pagepath = URL.AbsolutePath.ToString.Substring(URL.AbsolutePath.ToString.ToLower.IndexOf("/", 1) + 1)
            'End If
            If ApplicationPath <> "/" Then
                pagepath = URL.AbsolutePath.ToString.Substring(URL.AbsolutePath.ToString.IndexOf(ApplicationPath) + ApplicationPath.Length + 1)
            Else
                pagepath = URL.AbsolutePath.ToString.Substring(1)
            End If

            If pagepath.Contains("?") Then
                pagepath = pagepath.Substring(0, pagepath.ToLower.LastIndexOf("?"))
            End If
            ' slashcount = CountCharacter(pagepath, "/")

            strPath = URL.Segments()
            Dim db As New DBAccess("report")
            db.slDataAdd("agentid", Agentid)
            'If slashcount > 1 Then
            '    db.slDataAdd("module", strPath(strPath.Length - 3).Replace("/", ""))
            '    db.slDataAdd("page", strPath(strPath.Length - 2) & strPath(strPath.Length - 1).Replace("/", ""))
            'Else
            db.slDataAdd("module", strPath(strPath.Length - 2).Replace("/", ""))
            db.slDataAdd("page", pagepath)
            'End If


            Dim dt As DataTable = db.ReturnTable("usp_ValidatePage", , True)
            db = Nothing
            db = New DBAccess("CRM")
            db.slDataAdd("Agentid", Agentid)
            db.slDataAdd("URL", strPath(strPath.Length - 1).Replace("/", ""))
            db.Executeproc("usp_SaveTermsVisit")
            db = Nothing
            If Agentid.ToLower = "nss43793" Then Return True
            If dt.Rows.Count > 0 Then

                Return True
            Else
                Return False
            End If

        End Function
        Public Shared Function CountCharacter(ByVal value As String, ByVal ch As Char) As Integer
            Dim cnt As Integer = 0
            For Each c As Char In value
                If c = ch Then
                    cnt += 1
                End If
            Next
            Return cnt
        End Function
        Public Shared Sub AddToFav(ByVal Agentid As String, ByVal Report As String)
            Dim db As New DBAccess
            db.slDataAdd("ReportName", Report)
            db.slDataAdd("AgentID", Agentid)
            db.Executeproc("usp_InsertFavReport")
            db = Nothing
        End Sub
        Public Shared Sub hideDeleteOption(ByRef grid As GridView)
            For Each row As GridViewRow In grid.Rows
                If row.RowType = DataControlRowType.DataRow Then
                    Dim IsHiddenAvailable As Boolean = TryCast(row.Cells(0).FindControl("hdnIsDeleteAvailable"), HiddenField).Value
                    If IsHiddenAvailable = False Then
                        Dim imgbtn = TryCast(row.Cells(row.Cells.Count - 1).FindControl("imgDelete"), ImageButton)
                        If imgbtn Is Nothing Then

                        Else
                            imgbtn.Visible = False
                        End If



                        ' TryCast(row.Cells(7).FindControl("imgDelete"), ImageButton).Visible = False
                    End If

                End If
            Next
        End Sub
        Public Shared Function IsInputNumeric(input As String) As Boolean
            'If String.IsNullOrWhiteSpace(input) Then Return False
            If IsNumeric(input) Then Return True
            Dim parts() As String = input.Split("/"c)
            If parts.Length <> 2 Then Return False
            Return IsNumeric(parts(0)) AndAlso IsNumeric(parts(1))
        End Function

        Public Shared Function GetValues(ByVal uspname As String, Optional ByVal Processid As Integer = -1, Optional ByVal hasParameter As Boolean = True, Optional ByVal pipid As Integer = 0, Optional ByVal yyyy As Integer = 2016, Optional ByVal mm As Integer = 11) As DataTable
            Dim db As DBAccess

            'If uspname.ToUpper.Contains("PIP") Then
            db = New DBAccess("report")
            'Else
            'db = New DBAccess("CRM")
            'End If

            'Dim db As New DBAccess("report") '' 02Feb2017
            ' Dim db As New DBAccess("CRM")
            Dim dt As DataTable
            If (hasParameter = True) Then
                db.slDataAdd("ProcessId", Processid)
                Select Case uspname
                    Case "[GET_WSR_PIPLIST]"
                        db.slDataAdd("PipId", pipid)
                        db.slDataAdd("YYYY", yyyy)
                        db.slDataAdd("MM", mm)

                    Case "[GET_WSR_PIPPROCESSING_STATUS]"
                        db.slDataAdd("YYYY", yyyy)
                        db.slDataAdd("MM", mm)
                End Select
            End If

            dt = db.ReturnTable(uspname, , True)
            db = Nothing
            Return dt
        End Function
        Public Shared connCRM As String = System.Configuration.ConfigurationManager.AppSettings("connCRM")
        Public Shared connLeads As String = System.Configuration.ConfigurationManager.AppSettings("connLeads")
        Public Shared connreport As String = System.Configuration.ConfigurationManager.AppSettings("connReport")


    End Class
End Namespace