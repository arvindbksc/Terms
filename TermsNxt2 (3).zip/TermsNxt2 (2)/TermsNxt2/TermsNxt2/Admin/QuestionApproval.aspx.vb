﻿Imports com.nss.DBAccess
Imports System.Data
Partial Class Admin_QuestionApproval
    Inherits System.Web.UI.Page

#Region "--- Properties ---"
    Property QuestId() As Integer
        Get
            Return ViewState("Questid")
        End Get
        Set(ByVal value As Integer)
            ViewState("Questid") = value
        End Set
    End Property
    Property CampId() As Integer
        Get
            Return ViewState("CampId")
        End Get
        Set(ByVal value As Integer)
            ViewState("CampId") = value
        End Set
    End Property

    Property ApprovalStatus() As String
        Get
            Return ViewState("ApprovalStatus")
        End Get
        Set(ByVal value As String)
            ViewState("ApprovalStatus") = value
        End Set
    End Property

    Property Mode() As String
        Get
            Return ViewState("Mode")
        End Get
        Set(ByVal value As String)
            ViewState("Mode") = value
        End Set
    End Property

    Property ScopeIdentity() As Integer
        Get
            Return ViewState("ScopeIdentity")
        End Get
        Set(ByVal value As Integer)
            ViewState("ScopeIdentity") = value
        End Set
    End Property

    Property ChangeLog_Text() As String
        Get
            Return ViewState("ChangeLog_Text")
        End Get
        Set(ByVal value As String)
            ViewState("ChangeLog_Text") = value
        End Set
    End Property

    Property Caption() As String
        Get
            Return ViewState("Caption")
        End Get
        Set(ByVal value As String)
            ViewState("Caption") = value
        End Set
    End Property

#End Region

#Region "--- Load ---"

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            'DBAccess.process = "Dev1Attendance"
            QuestId = Request.QueryString("qid")
            CampId = Request.QueryString("CampId")
            ApprovalStatus = Request.QueryString("ApprovalStatus")
            Mode = Request.QueryString("Mode")
            Caption = Request.QueryString("Caption")
            'QuestId = 2080232
            'CampId = 208

            If ApprovalStatus = "APPROVE" Then
                ApproveQuestion("APPROVE")
            ElseIf ApprovalStatus = "REJECT" Then
                RejectQuestion("REJECT")
            Else
            End If
        End If
    End Sub

#End Region

#Region "--- Functions ---"

    Private Sub ApproveQuestion(ByVal ApprovalMode As String)
        lblMsg.Text = ""
        Dim IsCharity As Boolean = False
        Dim strQuery As String = ""
        Dim db As New DBAccess("Dev1Attendance")
        Dim dt As New DataTable
        Dim dtCheck As New DataTable

        db.BeginTrans()
        Try
            'log to create values from TEMP tables in Approval/rejection to history table
            db.slDataAdd("Campaignid", CampId)
            db.slDataAdd("QuestId", QuestId)
            db.slDataAdd("Mode", "TEMP")
            db.slDataAdd("UserID", HttpContext.Current.User.Identity.Name.ToString.Replace("NSS\", ""))
            db.slDataAdd("ApprovalStatus", ApprovalStatus)
            db.Executeproc("[DL_QuestionTool].[dbo].usp_LogCreation_Approval")

            dtCheck = db.ReturnTable("SELECT * FROM [DL_QuestionTool].dbo.tbl_config_Questions_temp where questid=" & QuestId & " and Campaignid=" & CampId & " and Caption='" & Caption & "'")

            If dtCheck.Rows.Count > 0 Then
                If dtCheck.Rows(0).Item("Caption").ToString.Contains("_CHARITY") Then
                    IsCharity = True
                Else
                    IsCharity = False
                End If

                ' log for creating already live existing values to history table
                db.slDataAdd("Campaignid", CampId)
                db.slDataAdd("QuestId", QuestId)
                db.slDataAdd("Mode", IIf(IsCharity = True, "ADD/AMEND Charity", "ADD/AMEND Non Charity"))
                db.slDataAdd("UserID", HttpContext.Current.User.Identity.Name.ToString.Replace("NSS\", ""))
                db.slDataAdd("ApprovalStatus", ApprovalStatus)
                db.Executeproc("[DL_QuestionTool].[dbo].usp_LogCreation_Approval_AlreadyExistingQuestions")

                'To update the changes accordingly

                db.slDataAdd("CampaignID", CampId)
                db.slDataAdd("QuestID", QuestId)
                db.slDataAdd("ApprovalStatus", ApprovalMode) '--Change this parameter for approval or rejection
                db.slDataAdd("IsCharity", IsCharity)
                db.ReturnValue("[DL_QuestionTool].[dbo].usp_QuestionApproval", True)

                'LogicUpdation(CampId, QuestId, IsCharity, db)
                '---------------------------
                lblMsg.Text &= "  Question has been added/updated Successfully"
                ' Else        'if question exists in live
                'ScopeIdentity = LogHistory_Questions(CampId, QuestId, "[DL_QuestionTool].dbo.tbl_config_Questions", "ADD_AMEND", db)

            Else
                lblMsg.Text &= "No request is pending for Approving."
            End If

            db.CommitTrans()
        Catch ex As Exception
            db.RollBackTrans()
            lblMsg.Text = ex.ToString
        Finally
            db = Nothing
            dt = Nothing
            dtCheck = Nothing
        End Try

    End Sub

    Private Sub RejectQuestion(ByVal ApprovalMode As String)
        lblMsg.Text = ""
        Dim IsCharity As Boolean = False
        Dim strQuery As String = ""
        Dim db As New DBAccess("Dev1Attendance")
        Dim dt As New DataTable
        Dim dtCheck As New DataTable

        db.BeginTrans()
        Try
            'log to create values from TEMP tables in Approval/rejection to history table
            db.slDataAdd("Campaignid", CampId)
            db.slDataAdd("QuestId", QuestId)
            db.slDataAdd("Mode", "TEMP")
            db.slDataAdd("UserID", HttpContext.Current.User.Identity.Name.ToString.Replace("NSS\", ""))
            db.slDataAdd("ApprovalStatus", ApprovalStatus)
            db.Executeproc("[DL_QuestionTool].[dbo].usp_LogCreation_Approval")

            dtCheck = db.ReturnTable("SELECT * FROM [DL_QuestionTool].dbo.tbl_config_Questions_temp where questid=" & QuestId & " and Campaignid=" & CampId & " and Caption='" & Caption & "'")

            If dtCheck.Rows.Count > 0 Then
                If dtCheck.Rows(0).Item("Caption").ToString.Contains("_CHARITY") Then
                    IsCharity = True
                Else
                    IsCharity = False
                End If

                db.slDataAdd("CampaignID", CampId)
                db.slDataAdd("QuestID", QuestId)
                db.slDataAdd("ApprovalStatus", ApprovalMode) '--Change this parameter for approval or rejection
                db.slDataAdd("IsCharity", IsCharity)
                db.ReturnValue("[DL_QuestionTool].[dbo].usp_QuestionApproval", True)

                ' LogicUpdation(CampId, QuestId, IsCharity, db)
                '---------------------------
                lblMsg.Text &= "  Question has been Rejected."
            Else
                lblMsg.Text &= "No request is pending for Rejection."
            End If

            db.CommitTrans()
        Catch ex As Exception
            db.RollBackTrans()
            lblMsg.Text = ex.ToString
        Finally
            db = Nothing
            dt = Nothing
            dtCheck = Nothing
        End Try
    End Sub

#End Region

End Class
