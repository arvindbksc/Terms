﻿Imports System.Data
Imports com.nss.DBAccess

Partial Class Admin_CreateUser
    Inherits System.Web.UI.Page
#Region "--- Properties ---"
    Property LanId() As String
        Get
            Return ViewState("LanId")
        End Get
        Set(ByVal value As String)
            ViewState("LanId") = value
        End Set
    End Property
    Property AgentID() As String
        Get
            Return ViewState("AgentID")
        End Get
        Set(ByVal value As String)
            ViewState("AgentID") = value
        End Set
    End Property
#End Region

#Region "--- Load ---"
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        HumanMessage.Style.Item("visibility") = "hidden"
        If Not IsPostBack Then
            AgentID = Session("AgentID")
            PanelReports.Controls.Add(Common.GetMenu(Request.Url, AgentID, Request.ApplicationPath))
        End If
    End Sub
#End Region
#Region "--- Change Password ---"
    Private Function Valid() As Boolean
        Dim returnvalue As Boolean
        If txtEmpcode.Text.Trim = Nothing Then
            AlertMessage("Please enter Employee Code")
            'returnvalue = False
            Exit Function
        Else
            returnvalue = True
        End If
        If txtPass1.Text.Trim = Nothing Then
            AlertMessage("Please enter new password")
            Exit Function
        ElseIf txtPass2.Text = Nothing Then
            AlertMessage("Please confirm new password")
            Exit Function
        Else
            Return True
        End If
        If txtPass1.Text.Trim = txtPass2.Text.Trim Then
            returnvalue = True
        Else
            AlertMessage("Password do not match")
            'returnvalue = False
            Exit Function
        End If
        If txtPass1.Text.Length >= 8 Then
            returnvalue = True
        Else
            AlertMessage("Password should be atleast 8 characters long")
            'returnvalue = False
            Exit Function
        End If
        Return returnvalue
    End Function
    Private Sub ChangePassword()
        Dim db As New DBAccess("CRM")
        LanId = db.ReturnValue("select lanid from tbl_AgentMaster where agentid='" & txtEmpcode.Text.Trim & "'and Active=1", False)
        db = Nothing
        If LanId = Nothing Then
            AlertMessage("Please check Employee code")
        Else
            'Dim strquery As String
            Dim dbpwd As New DBAccess("CRM")
            dbpwd.slDataAdd("password", RC4.Encrypt(LanId, txtPass1.Text.Trim))
            dbpwd.UpdateinTable("tbl_AgentMaster", "AgentId='" & txtEmpcode.Text.Trim & "'")
            'strquery = "update tbl_AgentMaster set password='" & RC4.Encrypt(LanId, txtPass1.Text.Trim) & "' where AgentId='" & txtEmpcode.Text.Trim & "'"
            'dbpwd.ReturnValue(strquery, False)
            dbpwd = Nothing
            SuccessMessage("Password Changed.")
        End If
    End Sub

#End Region
#Region "--- Utility ---"
    Private Sub AlertMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMFail"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub

    Private Sub SuccessMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMSuccess"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub
#End Region
#Region "--- Event ---"
    Protected Sub btnOK_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnOK.Click
        If Valid() Then
            ChangePassword()
        End If
    End Sub
#End Region

End Class
