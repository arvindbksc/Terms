﻿Imports com.nss.DBAccess
Partial Class Admin_ProcessList
    Inherits System.Web.UI.Page
    Private Property ProcessID() As Integer
        Get
            Return ViewState("ProcessID")
        End Get
        Set(ByVal value As Integer)
            ViewState("ProcessID") = value
        End Set
    End Property

    Private Property ProcessName() As String
        Get
            Return ViewState("ProcessName")
        End Get
        Set(ByVal value As String)
            ViewState("ProcessName") = value
        End Set
    End Property

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            ProcessName = Request.QueryString("ProcessName")
            ProcessID = Request.QueryString("ProcessID")
            If ProcessID <> -1 Then
                FillGrid()
            Else
                ClientScript.RegisterClientScriptBlock(Me.GetType, "NotValid", "javascript: alert('No process supllied');")

            End If

        End If
    End Sub

    Private Sub FillGrid()
        Dim db As New DBAccess
        dtgMain.DataSource = db.ReturnTable("Select campaignid,name, Campaigntype from tbl_config_Campaigns where processid=" & ProcessID)
        dtgMain.DataBind()
        db = Nothing
    End Sub

    Protected Sub btnAdd_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnAdd.Click
        Response.Redirect("~/Admin/FormCampaign.aspx?Edit=0")
    End Sub

End Class
