﻿Imports com.nss.DBAccess
Imports LibFolder.TermsNxt2
Public Class _AdminAccess
    Inherits System.Web.UI.Page

    'Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

    'End Sub

    Dim previousCat As String = ""
    Dim firstRow As Int16 = -1
#Region "===== PROPERTIES ========"

    Property SupervisorID() As String
        Get
            Return ViewState("SupervisorID")
        End Get
        Set(ByVal value As String)
            ViewState("SupervisorID") = value
        End Set
    End Property
    Property UserID() As String
        Get
            Return ViewState("UserID")
        End Get
        Set(ByVal value As String)
            ViewState("UserID") = value
        End Set
    End Property
    Property LanID() As String
        Get
            Return ViewState("LanID")
        End Get
        Set(ByVal value As String)
            ViewState("LanID") = value
        End Set
    End Property
    Property CampaignID() As Integer
        Get
            Return 0 'ViewState("CampaignID")
        End Get
        Set(ByVal value As Integer)
            'ViewState("CampaignID") = value
            'Session("CampaignID") = value
        End Set
    End Property
    Property ProcessID() As Integer
        Get
            Return ViewState("ProcessID")
        End Get
        Set(ByVal value As Integer)
            ViewState("ProcessID") = value
            Session("ProcessID") = value
        End Set
    End Property
    Property AgentID() As String
        Get
            Return ViewState("AgentID")
        End Get
        Set(ByVal value As String)
            ViewState("AgentID") = value
        End Set
    End Property

#End Region
#Region "====== LOAD ======="
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        HumanMessage.Style.Item("visibility") = "hidden"
        If Not IsPostBack Then
            AgentID = Session("AgentID")
            PanelReports.Controls.Add(Common.GetMenu(Request.Url, AgentID, Request.ApplicationPath))
            SupervisorID = Session("UserID")
            UserID = Session("UserID")
            ProcessID = Session("ProcessID")
            CampaignID = Session("CampaignID")
            txtOthers.Visible = False
            GetAllSupervisors()
            AllReports(CboSupervisor.SelectedValue.Trim)
            AllProcess(CboSupervisor.SelectedValue.Trim)
        End If
    End Sub
    Private Sub GetAllSupervisors()
        Dim db As New DBAccess("CRM")
        Dim dt As New DataTable
        dt = db.ReturnTable("usp_GetAllSupervisors", , True)
        db = Nothing
        lblreportname.CurrentPage = "Access Management"
        If dt.Rows.Count > 0 Then
            Dim finalName As DataColumn = New DataColumn
            With finalName
                .DataType = System.Type.GetType("System.String")
                .ColumnName = "AN"
                .Expression = "AgentName + ' [' + AgentId + ']'"
            End With
            With dt.Columns
                .Add(finalName)
            End With
            dt.AcceptChanges()
            CboSupervisor.DataSource = dt
            CboSupervisor.DataTextField = "AN"
            CboSupervisor.DataValueField = "AgentId"
            CboSupervisor.DataBind()
            CboSupervisor.Items.Insert(dt.Rows.Count, "Others")
        End If
        dt = Nothing
    End Sub
    Private Sub AllReports(ByVal AgentId As String)
        Try
            Dim db As New DBAccess
            Dim dt As New DataTable
            db.slDataAdd("Agentid", AgentId)
            dt = db.ReturnTable("usp_getUserReports", , True)
            db = Nothing
            gvReportsAccess.DataSource = dt
            gvReportsAccess.DataBind()
        Catch ex As Exception
            gvReportsAccess.Enabled = False
            gvCampaignList.Enabled = False
            pnlAccess.Enabled = False
        End Try
    End Sub
    Private Sub AllProcess(ByVal AgentId As String)
        'GetProcess()
        Try
            Dim dtlan As DataTable
            Dim dblan As New DBAccess("CRM")
            dblan.slDataAdd("AgentId", AgentId)
            dtlan = dblan.ReturnTable("usp_getAgentdetails", , True)
            If dtlan.Rows.Count > 0 Then
                LanID = dtlan.Rows(0).Item("lanId")
                dblan = Nothing
            End If
            Dim db As New DBAccess("CRM")
            Dim dt As New DataTable
            db.slDataAdd("Agentid", AgentId)
            dt = db.ReturnTable("usp_getUserProcess", , True)
            db = Nothing
            If dt.Rows.Count > 0 Then
                If dt.Rows(0).Item("IsAdmin") = True Then
                    chkAdmin.Checked = True
                Else
                    chkAdmin.Checked = False
                End If
                If dt.Rows(0).Item("IsManager") = True Then
                    chkIsManager.Checked = True
                Else
                    chkIsManager.Checked = False
                End If
                If dt.Rows(0).Item("IsHR") = True Then
                    chkIsHR.Checked = True
                Else
                    chkIsHR.Checked = False
                End If
                If dt.Rows(0).Item("IsSupervisor") = True Then
                    chkSupervisor.Checked = True
                Else
                    chkSupervisor.Checked = False
                End If
                gvCampaignList.DataSource = dt
                gvCampaignList.DataBind()

                dt = Nothing
                'Dim CmpId As Integer
                'For Each row As DataRow In dt.Rows
                '    For Each gvrow As GridViewRow In gvCampaignList.Rows
                '        Dim chkbx As CheckBox = gvrow.Cells(0).FindControl("chkbox")
                '        Dim Cmp_id = gvCampaignList.DataKeys(gvrow.RowIndex)("CampaignID").ToString()
                '        CmpId = row.Item("CampaignID")
                '        If CmpId = Cmp_id Then
                '            chkbx.Checked = True
                '        End If
                '    Next
                'Next
            End If
        Catch ex As Exception
            AlertMessage("LAN-ID is not updated.")
            gvReportsAccess.Enabled = False
            gvCampaignList.Enabled = False
            pnlAccess.Enabled = False
        End Try
    End Sub
#End Region
#Region "======== EVENT =========="
    Protected Sub CboSupervisor_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles CboSupervisor.SelectedIndexChanged
        If CboSupervisor.SelectedItem.Text = "Others" Then
            txtOthers.Visible = True
            imgRefresh.Visible = True
        Else
            txtOthers.Visible = False
            chkAdmin.Enabled = True
            chkIsHR.Enabled = True
            chkIsManager.Enabled = True
            chkSupervisor.Enabled = True
        End If
        txtOthers.Text = ""

        AllReports(CboSupervisor.SelectedValue.Trim)
        AllProcess(CboSupervisor.SelectedValue.Trim)
    End Sub
    Protected Sub chk_CheckedChanged(ByVal sender As Object, ByVal e As System.EventArgs) '----> Reports Access
        Try
            Dim chk As CheckBox = CType(sender, CheckBox)
            Dim gvr As GridViewRow = CType(chk.NamingContainer, GridViewRow)
            If (gvr IsNot Nothing) Then
                Dim rptID As Integer = gvReportsAccess.DataKeys(gvr.RowIndex)("ID").ToString
                Dim rptName As String = gvReportsAccess.DataKeys(gvr.RowIndex)("Name").ToString
                If txtOthers.Visible = True And imgRefresh.Visible = True Then
                    If txtOthers.Text.Trim <> "" Then
                        If chkOtherAgentId() Then
                            ReportAccess(rptID, rptName, txtOthers.Text.Trim)
                        Else
                            AlertMessage(" Agent ID Not Found ")
                        End If
                    Else
                        AlertMessage(" Please Enter The Agent ID ")
                        Return
                    End If
                Else
                    ReportAccess(rptID, rptName, CboSupervisor.SelectedValue.Trim)
                End If
            End If
            If txtOthers.Visible Then
                AllReports(txtOthers.Text.Trim)
            Else
                AllReports(CboSupervisor.SelectedValue.Trim)
            End If
        Catch ex As Exception
            AlertMessage(ex.ToString)
        Finally

        End Try
    End Sub
    Protected Sub chkbox_CheckedChanged(ByVal sender As Object, ByVal e As System.EventArgs)
        Try
            Dim chk As CheckBox = CType(sender, CheckBox)
            Dim gvr As GridViewRow = CType(chk.NamingContainer, GridViewRow)
            If (gvr IsNot Nothing) Then
                Dim cmpID As Integer = gvCampaignList.DataKeys(gvr.RowIndex)("CampaignID").ToString
                Dim processID As Integer = gvCampaignList.DataKeys(gvr.RowIndex)("ProcessID").ToString
                Dim cmpName As String = gvCampaignList.DataKeys(gvr.RowIndex)("Name").ToString
                Dim status = Convert.ToInt32(chk.Checked)
                If txtOthers.Visible = True And imgRefresh.Visible = True Then
                    If txtOthers.Text.Trim <> "" Then
                        If chkOtherAgentId() Then
                            ProcessAccess(cmpID, cmpName, processID, txtOthers.Text.Trim)
                        Else
                            AlertMessage(" Agent ID Not Found ")
                        End If
                    Else
                        AlertMessage(" Please Enter The Agent ID ")
                        Return
                    End If
                Else
                    ProcessAccess(cmpID, cmpName, processID, CboSupervisor.SelectedValue.Trim)
                End If
            End If
            If txtOthers.Visible Then
                AllReports(txtOthers.Text.Trim)
            Else
                AllReports(CboSupervisor.SelectedValue.Trim)
            End If
        Catch ex As Exception
            AlertMessage(ex.ToString)
        Finally

        End Try
    End Sub

    Protected Sub chkIsHR_CheckedChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles chkIsHR.CheckedChanged
        Try
            Dim AgentId As String = ""
            Dim AgentName As String = CboSupervisor.SelectedItem.Text.Trim
            If AgentName = "Others" Then
                If chkOtherAgentId() Then
                    AgentId = txtOthers.Text.Trim
                Else
                    AlertMessage(" Agent ID Not Found ")
                End If
            Else
                AgentId = CboSupervisor.SelectedValue.Trim
            End If
            IsManager_HR_Admin(AgentId)
            If txtOthers.Visible Then
                AllReports(txtOthers.Text.Trim)
            Else
                AllReports(CboSupervisor.SelectedValue.Trim)
            End If
        Catch ex As Exception
            AlertMessage(ex.ToString)
        End Try
    End Sub
    Protected Sub chkIsManager_CheckedChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles chkIsManager.CheckedChanged
        Try
            Dim AgentId As String = ""
            Dim AgentName As String = CboSupervisor.SelectedItem.Text.Trim
            If AgentName = "Others" Then
                If chkOtherAgentId() Then
                    AgentId = txtOthers.Text.Trim
                Else
                    AlertMessage(" Agent ID Not Found ")
                End If
            Else
                AgentId = CboSupervisor.SelectedValue.Trim
            End If
            IsManager_HR_Admin(AgentId)
            If txtOthers.Visible Then
                AllReports(txtOthers.Text.Trim)
            Else
                AllReports(CboSupervisor.SelectedValue.Trim)
            End If
        Catch ex As Exception
            AlertMessage(ex.ToString)
        End Try
    End Sub
    Protected Sub chkAdmin_CheckedChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles chkAdmin.CheckedChanged
        Try
            Dim AgentId As String = ""
            Dim AgentName As String = CboSupervisor.SelectedItem.Text.Trim
            If AgentName = "Others" Then
                If chkOtherAgentId() Then
                    AgentId = txtOthers.Text.Trim
                Else
                    AlertMessage(" Agent ID Not Found ")
                End If
            Else
                AgentId = CboSupervisor.SelectedValue.Trim
            End If
            IsManager_HR_Admin(AgentId)
            If txtOthers.Visible Then
                AllReports(txtOthers.Text.Trim)
            Else
                AllReports(CboSupervisor.SelectedValue.Trim)
            End If
        Catch ex As Exception
            AlertMessage(ex.ToString)
        End Try
    End Sub
    Protected Sub chkSupervisor_CheckedChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles chkSupervisor.CheckedChanged
        Try
            Dim AgentId As String = ""
            Dim AgentName As String = CboSupervisor.SelectedItem.Text.Trim
            If AgentName = "Others" Then
                If chkOtherAgentId() Then
                    AgentId = txtOthers.Text.Trim
                    If chkSupervisor.Checked = True Then
                        txtSupEmail.Text = ""
                        lblEmpId.Text = ""
                        Dim db As New com.nss.DBAccess.DBAccess("CRM")
                        Dim dt As New DataTable
                        dt = db.ReturnTable("select *from tbl_Config_SupervisorsEmail where AgentID='" & AgentId & "'", False)
                        db = Nothing
                        If dt.Rows.Count = 0 Then
                            OpenPopUp()
                        Else
                            IsManager_HR_Admin(AgentId)
                        End If
                    Else
                        IsManager_HR_Admin(AgentId)
                    End If
                Else
                    AlertMessage(" Agent ID Not Found ")
                End If
            Else
                AgentId = CboSupervisor.SelectedValue.Trim
                IsManager_HR_Admin(AgentId)
            End If
        Catch ex As Exception
            AlertMessage(ex.ToString)
        End Try
    End Sub

    Protected Sub chkUpdate_CheckedChanged(ByVal sender As Object, ByVal e As System.EventArgs)
        Try
            Dim chk As CheckBox = CType(sender, CheckBox)
            Dim gvr As GridViewRow = CType(chk.NamingContainer, GridViewRow)
            If (gvr IsNot Nothing) Then
                Dim cmpID As Integer = gvCampaignList.DataKeys(gvr.RowIndex)("CampaignID").ToString
                Dim status = Convert.ToInt32(chk.Checked)
                CanUpdate(cmpID, status)
                SuccessMessage(" Update Access has been given on selected Campaign ")
            End If
        Catch ex As Exception
            AlertMessage(ex.ToString)
        End Try
    End Sub
    Protected Sub chkUpload_CheckedChanged(ByVal sender As Object, ByVal e As System.EventArgs)
        Try
            Dim chk As CheckBox = CType(sender, CheckBox)
            Dim gvr As GridViewRow = CType(chk.NamingContainer, GridViewRow)
            If (gvr IsNot Nothing) Then
                Dim cmpID As Integer = gvCampaignList.DataKeys(gvr.RowIndex)("CampaignID").ToString
                Dim status = Convert.ToInt32(chk.Checked)
                CanUpload(cmpID, status)
                SuccessMessage(" Upload Access has been given on selected Campaign ")
            End If
        Catch ex As Exception
            AlertMessage(ex.ToString)
        End Try
    End Sub
    Protected Sub chkReports_CheckedChanged(ByVal sender As Object, ByVal e As System.EventArgs)
        Try
            Dim chk As CheckBox = CType(sender, CheckBox)
            Dim gvr As GridViewRow = CType(chk.NamingContainer, GridViewRow)
            If (gvr IsNot Nothing) Then
                Dim cmpID As Integer = gvCampaignList.DataKeys(gvr.RowIndex)("CampaignID").ToString
                Dim status = Convert.ToInt32(chk.Checked)
                CanSeeReports(cmpID, status)
                SuccessMessage(" Report Access has been given on selected Campaign ")
            End If
        Catch ex As Exception
            AlertMessage(ex.ToString)
        End Try
    End Sub
    Protected Sub chkSeeRecording_CheckedChanged(ByVal sender As Object, ByVal e As System.EventArgs)
        Try
            Dim chk As CheckBox = CType(sender, CheckBox)
            Dim gvr As GridViewRow = CType(chk.NamingContainer, GridViewRow)
            If (gvr IsNot Nothing) Then
                Dim cmpID As Integer = gvCampaignList.DataKeys(gvr.RowIndex)("CampaignID").ToString
                Dim status = Convert.ToInt32(chk.Checked)
                CanSeeRecording(cmpID, status)
                SuccessMessage(" Recording Access has been given on selected Campaign ")
            End If
        Catch ex As Exception
            AlertMessage(ex.ToString)
        End Try
    End Sub
    Protected Sub chkCanAmend_CheckedChanged(ByVal sender As Object, ByVal e As System.EventArgs)
        Dim chk As CheckBox = CType(sender, CheckBox)
        Dim gvr As GridViewRow = CType(chk.NamingContainer, GridViewRow)
        If (gvr IsNot Nothing) Then
            Dim cmpID As Integer = gvCampaignList.DataKeys(gvr.RowIndex)("CampaignID").ToString
            Dim CmpName As String = gvCampaignList.DataKeys(gvr.RowIndex)("Name").ToString
            Dim ChkVal As Integer = Convert.ToInt32(chk.Checked)
            AmendmentAccess(cmpID, CmpName, LanID, ChkVal)
        End If
    End Sub

    '============= FOR OTHERS USERS =========
    Protected Sub imgRefresh_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles imgRefresh.Click
        Try
            gvCampaignList.Enabled = True
            gvReportsAccess.Enabled = True
            pnlAccess.Enabled = True

            If txtOthers.Visible = False Then
                AllReports(CboSupervisor.SelectedValue.Trim)
                AllProcess(CboSupervisor.SelectedValue.Trim)
            Else
                If txtOthers.Text.Trim <> "" Then
                    If chkOtherAgentId() Then
                        AllReports(txtOthers.Text.Trim)
                        AllProcess(txtOthers.Text.Trim)
                    Else
                        AlertMessage("Agent Id is not Correct, Please Enter Correct One !!..")
                    End If
                Else
                    AlertMessage("Please Enter The Agent ID")
                    Return
                End If
            End If
        Catch ex As Exception
            AlertMessage(ex.ToString)
        End Try
    End Sub

    '============ TO BIND MODULE LIST =========== Gaurav
    Protected Sub gvReportsAccess_RowDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles gvReportsAccess.RowDataBound
        If e.Row.RowType = DataControlRowType.DataRow Then
            Dim drv As DataRowView = (DirectCast(e.Row.DataItem, DataRowView))
            If gvReportsAccess.Rows.Count >= 0 Then
                If previousCat = drv("DisplayName") Then
                    If gvReportsAccess.Rows(firstRow).Cells(2).RowSpan = 0 Then
                        gvReportsAccess.Rows(firstRow).Cells(2).RowSpan = 2
                    Else
                        gvReportsAccess.Rows(firstRow).Cells(2).RowSpan += 1
                    End If
                    e.Row.Cells.RemoveAt(2)
                Else
                    e.Row.VerticalAlign = VerticalAlign.Top
                    previousCat = drv("DisplayName").ToString()
                    firstRow = e.Row.RowIndex
                End If
                'Dim db As New DBAccess
                'Dim dt As New DataTable
                'db.slDataAdd("reportid", CType(e.Row.Cells(1).FindControl("hfReportID"), HiddenField).Value)
                'dt = db.ReturnTable("usp_GetUserReportWise", , True)
                'db = Nothing
                'e.Row.Cells(1).ToolTip = CType(e.Row.Cells(1).FindControl("lblreport"), Label).Text & vbCrLf & CType(e.Row.Cells(1).FindControl("hfReportID"), HiddenField).Value
            End If
        End If
    End Sub

#End Region
#Region "======= FUNCTIONS ========="

    Private Sub ReportAccess(ByVal rptID As Integer, ByVal rptName As String, ByVal AgentId As String)
        Dim db As New DBAccess
        Dim rptAccess As Boolean
        rptAccess = db.ReturnValue("SELECT Count(*) FROM Tbl_Report_UserRights WHERE AgentID='" & AgentId.ToUpper & "' and ReportID=" & rptID & "", False)
        db = Nothing
        Dim db1 As New DBAccess
        If rptAccess = False Then
            db1.slDataAdd("ReportID", rptID)
            db1.slDataAdd("AgentID", AgentId)
            db1.InsertinTable("Tbl_Report_UserRights")
            SuccessMessage(" [ " & rptName & " ] " & " Report Access has been Given ")
        Else
            Dim strQuery = "DELETE FROM Tbl_Report_UserRights WHERE AgentID='" & AgentId & "' AND ReportID= " & rptID & ""
            db1.ReturnValue(strQuery)
            SuccessMessage(" [ " & rptName & " ] " & " Report Access has been Removed")
        End If
        db1 = Nothing
        If txtOthers.Visible Then
            AllReports(txtOthers.Text.Trim)
        Else
            AllReports(CboSupervisor.SelectedValue.Trim)
        End If
    End Sub
    Private Sub ProcessAccess(ByVal cmpId As Integer, ByVal cmpName As String, ByVal processID As Integer, ByVal AgentId As String)
        Dim db As New DBAccess("CRM")
        Dim dbCmp As New DBAccess("CRM")
        Dim ChkCmpId As Boolean
        ChkCmpId = dbCmp.ReturnValue("SELECT Count(*) FROM Tbl_data_UserRights WHERE AgentID='" & AgentId & "' and CampaignID=" & cmpId & "", False)
        dbCmp = Nothing
        If ChkCmpId = False Then
            db.slDataAdd("CampaignID", cmpId)
            db.slDataAdd("ProcessID", processID)
            db.slDataAdd("AgentID", AgentId)
            db.slDataAdd("CanUpdate", 0)
            db.slDataAdd("CanUpload", 0)
            db.slDataAdd("IsSupervisor", 0)
            db.slDataAdd("IsManager", 0)
            db.slDataAdd("CanSeeReports", 0)
            db.slDataAdd("CanSeeRecordings", 0)
            db.InsertinTable("Tbl_data_UserRights")
            SuccessMessage(" [ " & cmpName & " ] " & " Process Access has been Given ")
        Else
            db.ReturnValue("DELETE FROM Tbl_data_UserRights WHERE AgentID='" & AgentId & "' AND CampaignID= " & cmpId & "", False)
            SuccessMessage(" [ " & cmpName & " ] " & " Process Access has been Removed")
        End If
        db = Nothing
    End Sub
    Private Sub IsManager_HR_Admin(ByVal Empcode As String)
        Dim db As New DBAccess("CRM")
        Try
            db.slDataAdd("IsHR", Convert.ToInt32(chkIsHR.Checked))
            db.slDataAdd("IsManager", Convert.ToInt32(chkIsManager.Checked))
            db.slDataAdd("IsAdmin", Convert.ToInt32(chkAdmin.Checked))
            db.slDataAdd("IsSupervisor", Convert.ToInt32(chkSupervisor.Checked))
            db.UpdateinTable("tbl_AgentMaster", "AgentID='" & Empcode & "'")
            'db.ReturnValue("UPDATE tbl_AgentMaster SET IsHR= " & Convert.ToInt32(chkIsHR.Checked) & ", IsManager=" & Convert.ToInt32(chkIsManager.Checked) & ",IsAdmin=" & Convert.ToInt32(chkAdmin.Checked) & ",IsSupervisor=" & Convert.ToInt32(chkSupervisor.Checked) & " WHERE AgentID='" & Empcode & "'", False)
            db = Nothing
            SuccessMessage(" Required Access has been Given / Removed ")
            If txtOthers.Visible Then
                AllReports(txtOthers.Text.Trim)
            Else
                AllReports(CboSupervisor.SelectedValue.Trim)
            End If
        Catch ex As Exception
            AlertMessage(ex.ToString)
        End Try
    End Sub
    Private Sub CanUpdate(ByVal cmpID As Integer, ByVal chkedVal As Integer)
        Dim db As New DBAccess("CRM")
        Dim AgentId As String = ""
        Dim AgentName As String = CboSupervisor.SelectedItem.Text.Trim
        If AgentName = "Others" Then
            If chkOtherAgentId() Then
                AgentId = txtOthers.Text.Trim
            Else
                AlertMessage(" Agent ID Not Found ")
            End If
        Else
            AgentId = CboSupervisor.SelectedValue.Trim
        End If
        Dim Access As Boolean = db.ReturnValue("SELECT count(*) FROM tbl_Data_UserRights WHERE AgentID='" & AgentId & "' AND CampaignID=" & cmpID & "", False)
        db = Nothing
        If Access = False Then
            AlertMessage("You do not have Access on Selected Campaign")
            Return
        Else
            Dim dbUpdt = New DBAccess("CRM")
            dbUpdt.slDataAdd("CanUpdate", chkedVal)
            dbUpdt.UpdateinTable("tbl_Data_UserRights", "AgentID='" & AgentId & "' AND CampaignID=" & cmpID & "")
            dbUpdt = Nothing
        End If
        If txtOthers.Visible Then
            AllReports(txtOthers.Text.Trim)
        Else
            AllReports(CboSupervisor.SelectedValue.Trim)
        End If
    End Sub
    Private Sub CanUpload(ByVal cmpID As Integer, ByVal chkedVal As Integer)
        Dim db As New DBAccess("CRM")
        Dim AgentId As String = ""
        Dim AgentName As String = CboSupervisor.SelectedItem.Text.Trim
        If AgentName = "Others" Then
            If chkOtherAgentId() Then
                AgentId = txtOthers.Text.Trim
            Else
                AlertMessage(" Agent ID Not Found ")
            End If
        Else
            AgentId = CboSupervisor.SelectedValue.Trim
        End If
        Dim Access As Boolean = db.ReturnValue("SELECT count(*) FROM tbl_Data_UserRights WHERE AgentID='" & AgentId & "' AND CampaignID=" & cmpID & "", False)
        db = Nothing
        If Access = False Then
            AlertMessage("You do not have Access on Selected Campaign")
            Return
        Else
            Dim dbUpdt = New DBAccess("CRM")
            dbUpdt.slDataAdd("CanUpload", chkedVal)
            dbUpdt.UpdateinTable("tbl_Data_UserRights", "AgentID='" & AgentId & "' AND CampaignID=" & cmpID & "")
            dbUpdt = Nothing
        End If

    End Sub
    Private Sub CanSeeReports(ByVal cmpID As Integer, ByVal chkedVal As Integer)
        Dim db As New DBAccess("CRM")
        Dim AgentId As String = ""
        Dim AgentName As String = CboSupervisor.SelectedItem.Text.Trim
        If AgentName = "Others" Then
            If chkOtherAgentId() Then
                AgentId = txtOthers.Text.Trim
            Else
                AlertMessage(" Agent ID Not Found ")
            End If
        Else
            AgentId = CboSupervisor.SelectedValue.Trim
        End If
        Dim Access As Boolean = db.ReturnValue("SELECT count(*) FROM tbl_Data_UserRights WHERE AgentID='" & AgentId & "' AND CampaignID=" & cmpID & "", False)
        db = Nothing
        If Access = False Then
            AlertMessage("You do not have Access on Selected Campaign")
            Return
        Else
            Dim dbUpdt = New DBAccess("CRM")
            dbUpdt.slDataAdd("CanSeeReports", chkedVal)
            dbUpdt.UpdateinTable("tbl_Data_UserRights", "AgentID='" & AgentId & "' AND CampaignID=" & cmpID & "")
            dbUpdt = Nothing
        End If
        If txtOthers.Visible Then
            AllReports(txtOthers.Text.Trim)
        Else
            AllReports(CboSupervisor.SelectedValue.Trim)
        End If
    End Sub
    Private Sub CanSeeRecording(ByVal cmpID As Integer, ByVal chkedVal As Integer)
        Dim db As New DBAccess("CRM")
        Dim AgentId As String = ""
        Dim AgentName As String = CboSupervisor.SelectedItem.Text.Trim
        If AgentName = "Others" Then
            If chkOtherAgentId() Then
                AgentId = txtOthers.Text.Trim
            Else
                AlertMessage(" Agent ID Not Found ")
            End If
        Else
            AgentId = CboSupervisor.SelectedValue.Trim
        End If
        Dim Access As Boolean = db.ReturnValue("SELECT Count(*) FROM tbl_Data_UserRights WHERE AgentID='" & AgentId & "' AND CampaignID=" & cmpID & "", False)
        db = Nothing
        If Access = False Then
            AlertMessage("You do not have Access on Selected Campaign")
            Return
        Else
            Dim dbUpdt As New DBAccess("CRM")
            dbUpdt.slDataAdd("CanSeeRecordings", chkedVal)
            dbUpdt.UpdateinTable("tbl_Data_UserRights", "AgentID='" & AgentId & "' AND CampaignID=" & cmpID & "")
            dbUpdt = Nothing
        End If
        If txtOthers.Visible Then
            AllReports(txtOthers.Text.Trim)
        Else
            AllReports(CboSupervisor.SelectedValue.Trim)
        End If
    End Sub
    Private Sub AmendmentAccess(ByVal cmpId As Integer, ByVal cmpName As String, ByVal UserName As String, ByVal CheckedVal As Integer)
        Dim dbDate As New DBAccess("CRM")
        Dim GrantDate As DateTime = dbDate.ReturnValue("Select GetDate()", False)
        dbDate = Nothing
        Dim db As New DBAccess("CRM")
        Dim AmendAccess As Boolean
        AmendAccess = db.ReturnValue("SELECT count(*) FROM tbl_AdminRights WHERE camp_id=" & cmpId & " AND [user]='" & UserName & "'", False)
        db = Nothing
        Dim dbAmend = New DBAccess("CRM")
        If AmendAccess = False Then
            dbAmend.slDataAdd("Process", cmpName)
            dbAmend.slDataAdd("User", UserName)
            dbAmend.slDataAdd("Active", 1)
            dbAmend.slDataAdd("GrantedBy", UserID)
            dbAmend.slDataAdd("GrantedOn", GrantDate)
            dbAmend.slDataAdd("IsSuperVisor", 0)
            dbAmend.slDataAdd("btUpdate", 1)
            dbAmend.slDataAdd("camp_id", cmpId)
            dbAmend.InsertinTable("tbl_AdminRights")
            SuccessMessage("Amendment Tool Access has been given")
        Else
            dbAmend.slDataAdd("Active", CheckedVal)
            dbAmend.UpdateinTable("tbl_AdminRights", "camp_id=" & cmpId & " AND [user]='" & UserName & "'")
            SuccessMessage("Amendment Tool Access has been Removed")
        End If
        dbAmend = Nothing
        If txtOthers.Visible Then
            AllReports(txtOthers.Text.Trim)
        Else
            AllReports(CboSupervisor.SelectedValue.Trim)
        End If
    End Sub
    Private Function chkOtherAgentId() As Boolean
        Dim db As New DBAccess
        Dim rtrnAgent As Boolean
        rtrnAgent = db.ReturnValue("SELECT * FROM tbl_AgentMaster WHERE AgentId='" & txtOthers.Text.Trim & " '", False)
        db = Nothing
        If rtrnAgent Then
            Return True
        End If
        Return False
    End Function
#End Region
#Region "===== UTILITY ====="

    Private Sub AlertMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMFail"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub

    Private Sub SuccessMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMSuccess"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub

#End Region
#Region "===== POP UP ===="
    Private Sub OpenPopUp()
        lblEmpId.Text = txtOthers.Text.Trim
        Dim str As String
        str = "$('#DialogBackground').height($(document).height()-10);$('#DialogBackground').width($(window).width());$('#DialogBackground').css('visibility','visible');$('#PanelResetPWD').css('visibility','visible');" &
        " $('#PanelResetPWD').css('left',($(window).width() - $('#PanelResetPWD').width())/2); "
        ScriptManager.RegisterStartupScript(Page, Page.GetType(), "Movedialog", str, True)
    End Sub
    Protected Sub btnEmail_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnEmail.Click
        AgentID = txtOthers.Text.Trim
        Dim db As New com.nss.DBAccess.DBAccess("CRM")
        Dim dt As New DataTable
        If txtSupEmail.Text <> "" Or txtSupEmail.Text <> Nothing Then
            dt = db.ReturnTable("select *from tbl_Config_SupervisorsEmail where AgentID='" & AgentID & "'", False)
            If dt.Rows.Count = 0 Then
                db.slDataAdd("Agentid", AgentID)
                db.slDataAdd("Emailid", txtSupEmail.Text.Trim)
                db.InsertinTable("tbl_Config_SupervisorsEmail")
            End If
            db = Nothing
            IsManager_HR_Admin(AgentID)
        End If
    End Sub
    Protected Sub btnClose_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnClose.Click
        chkSupervisor.Checked = False
    End Sub

#End Region
    'Public Event TreeNodeCheckChanged As TreeNodeEventHandler

    'Protected Sub TreeView1_TreeNodeCheckChanged(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.TreeNodeEventArgs) Handles TreeView1.TreeNodeCheckChanged
    '    Dim rptID As Int16 = e.Node.Value
    '    Dim rptname As String = e.Node.Text
    '    ReportAccess(rptID, rptname, AgentID)
    'End Sub
    'Protected Sub LinksTreeView_CheckChanged(ByVal sender As Object, ByVal e As TreeNodeEventArgs)
    '    Dim rptID As Int16 = e.Node.Value
    '    Dim rptname As String = e.Node.Text
    '    ReportAccess(rptID, rptname, AgentID)
    'End Sub

End Class