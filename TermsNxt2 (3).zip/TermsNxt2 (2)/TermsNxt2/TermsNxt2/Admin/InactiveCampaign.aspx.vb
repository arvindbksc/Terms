﻿Imports com.nss.DBAccess
Imports System.Data
Partial Class Admin_InactiveCampaign
    Inherits System.Web.UI.Page

#Region "===== PROPERTIES ========"
    Property dtsummary() As DataTable
        Get
            Return ViewState("dtSummary")
        End Get
        Set(ByVal value As DataTable)
            ViewState("dtSummary") = value
        End Set
    End Property
    Property SupervisorID() As String
        Get
            Return ViewState("SupervisorID")
        End Get
        Set(ByVal value As String)
            ViewState("SupervisorID") = value
        End Set
    End Property
    Property TransID() As Integer
        Get
            Return ViewState("TransID")
        End Get
        Set(ByVal value As Integer)
            ViewState("TransID") = value
        End Set
    End Property
    Property UserID() As String
        Get
            Return ViewState("UserID")
        End Get
        Set(ByVal value As String)
            ViewState("UserID") = value
        End Set
    End Property
    Property CampaignID() As Integer
        Get
            Return 0 'ViewState("CampaignID")
        End Get
        Set(ByVal value As Integer)
            'ViewState("CampaignID") = value
            'Session("CampaignID") = value
        End Set
    End Property
    Property ProcessID() As Integer
        Get
            Return ViewState("ProcessID")
        End Get
        Set(ByVal value As Integer)
            ViewState("ProcessID") = value
            Session("ProcessID") = value
        End Set
    End Property
    Property AgentID() As String
        Get
            Return ViewState("AgentID")
        End Get
        Set(ByVal value As String)
            ViewState("AgentID") = value
        End Set
    End Property
    Property Month() As String
        Get
            Return ViewState("Month")
        End Get
        Set(ByVal value As String)
            ViewState("Month") = value
        End Set
    End Property
    Property Year() As Integer
        Get
            Return ViewState("Year")
        End Get
        Set(ByVal value As Integer)
            ViewState("Year") = value
        End Set
    End Property
    Property UsrID() As Integer
        Get
            Return ViewState("UsrID")
        End Get
        Set(ByVal value As Integer)
            ViewState("UsrID") = value
        End Set
    End Property
    Property LoginID() As Integer
        Get
            Return ViewState("LoginID")
        End Get
        Set(ByVal value As Integer)
            ViewState("LoginID") = value
        End Set
    End Property
    Property CurrentDate() As Date
        Get
            Return ViewState("CurrentDate")
        End Get
        Set(ByVal value As Date)
            ViewState("CurrentDate") = value
        End Set
    End Property
    Property IncentiveMonth() As String
        Get
            Return ViewState("IncentiveMonth")
        End Get
        Set(ByVal value As String)
            ViewState("IncentiveMonth") = value
        End Set
    End Property
    Property IncentiveYear() As Integer
        Get
            Return ViewState("IncentiveYear")
        End Get
        Set(ByVal value As Integer)
            ViewState("IncentiveYear") = value
        End Set
    End Property

#End Region

#Region " ====== LOAD ======"
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        HumanMessage.Style.Item("visibility") = "hidden"
        If Not IsPostBack Then
            AgentID = Session("AgentID")
            PanelReports.Controls.Add(Common.GetMenu(Request.Url, AgentID, Request.ApplicationPath))
            ProcessID = Session("ProcessID")
            CampaignID = Session("CampaignID")
            SupervisorID = Session("UserID")
            UserID = Session("UserID")
            BindAllProcess()
            lblreportname.CurrentPage = "Campaign Status"

        End If
    End Sub

    Private Sub BindAllProcess()
        Dim db As New DBAccess
        Dim dt As New DataTable
        dt = db.ReturnTable("SELECT CampaignID,Name,Active  FROM tbl_Config_Campaigns ORDER BY Name,Active DESC ", False)
        db = Nothing
        gvCampaign.DataSource = dt
        gvCampaign.DataBind()
        dt = Nothing
    End Sub
#End Region

#Region " ====== EVENT ====="
    Protected Sub chkActive_CheckedChanged(ByVal sender As Object, ByVal e As System.EventArgs)
        Try
            Dim chk As CheckBox = CType(sender, CheckBox)
            Dim gvr As GridViewRow = CType(chk.NamingContainer, GridViewRow)
            If (gvr IsNot Nothing) Then
                'Dim index As Integer = gvr.RowIndex
                Dim Cmpid As Integer = gvCampaign.DataKeys(gvr.RowIndex)("CampaignID").ToString
                Dim CmpName As String = gvCampaign.DataKeys(gvr.RowIndex)("Name").ToString
                Active_InactiveCampaigns(Cmpid, CmpName, Convert.ToInt64(chk.Checked))
            End If
        Catch ex As Exception
            AlertMessage(ex.ToString)
        End Try

    End Sub
#End Region

#Region " ===== GRID OPS ====="
    Private Sub Active_InactiveCampaigns(ByVal CampId As Integer, ByVal CmpName As String, ByVal active As Integer)
        Dim db As New DBAccess("CRM")
        'Dim Active As Boolean
        'Active = db.ReturnValue("SELECT * FROM tbl_Config_Campaigns WHERE CampaignID=" & CampId & " AND Active=1", False)
        'If Active = False Then
        db.ReturnValue("UPDATE tbl_Config_Campaigns SET Active=" & active & " WHERE CampaignID=" & CampId & "", False)
        If active = 1 Then
            SuccessMessage("Campaign [" & CmpName & " ]  has been Activated")
        Else
            SuccessMessage("Campaign [" & CmpName & " ] has been DeActivated")
        End If

        ' Else
        'db.ReturnValue("UPDATE tbl_Config_Campaigns SET Active=0 WHERE CampaignID=" & CampId & "", False)
        '
        'End If
        BindAllProcess()
    End Sub
#End Region

#Region " ===== UTILITY ====="

    Private Sub AlertMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMFail"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub

    Private Sub SuccessMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMSuccess"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub

#End Region
   
End Class
