﻿Imports com.nss.DBAccess
Partial Class Admin_ProcessList
    Inherits System.Web.UI.Page
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            FillGrid()
        End If
    End Sub

    Private Sub FillGrid()
        Dim db As New DBAccess
        dtgMain.DataSource = db.ReturnTable("Select processid,processname, '' as processtype from tbl_config_Processes ")
        dtgMain.DataBind()
        db = Nothing
    End Sub

    Protected Sub btnAdd_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnAdd.Click
        Response.Redirect("~/FormProcess.aspx?Edit=0")
    End Sub

End Class
