﻿Imports com.nss.DBAccess
Imports System.Data
Partial Class Admin_Query
    Inherits System.Web.UI.Page
    Private Sub FillGrid()
        Dim db As New DBAccess("Archive")
        Dim dt As New DataTable
        Dim strQuery As String = "usp_getAgentAccessDate"
        db.slDataAdd("URL", cboUpdate.SelectedValue)
        dt = db.ReturnTable(strQuery, , True)
        db = Nothing
        gvQuery.DataSource = dt
        gvQuery.DataBind()
        dt = Nothing
    End Sub
    Private Sub FillUpdateCombo()
        Dim db As New DBAccess("Archive")
        Dim dt As New DataTable
        Dim strQuery As String = "usp_getAllUpdateLinks"
        db.slDataAdd("process", cboProcess.SelectedValue)
        dt = db.ReturnTable(strQuery, , True)
        db = Nothing
        cboUpdate.DataSource = dt
        cboUpdate.DataTextField = "caption"
        cboUpdate.DataValueField = "csUriStem"
        cboUpdate.DataBind()
        dt = Nothing
    End Sub

    Private Sub FillProcessCombo()
        Dim db As New DBAccess("Archive")
        Dim dt As New DataTable
        Dim strQuery As String = "usp_getAllUpdateLinks"
        dt = db.ReturnTable(strQuery, , True)
        db = Nothing
        cboProcess.DataSource = dt
        cboProcess.DataTextField = "caption"
        cboProcess.DataValueField = "caption"
        cboProcess.DataBind()
        dt = Nothing
    End Sub

    Protected Sub cboUpdate_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboUpdate.SelectedIndexChanged
        FillGrid()
    End Sub

    Protected Sub cboProcess_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboProcess.SelectedIndexChanged
        FillUpdateCombo()
        FillGrid()
    End Sub

    Protected Sub btnRefresh_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnRefresh.Click
        FillGrid()
    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            FillProcessCombo()
            FillUpdateCombo()
            FillGrid()
        End If
    End Sub
End Class
