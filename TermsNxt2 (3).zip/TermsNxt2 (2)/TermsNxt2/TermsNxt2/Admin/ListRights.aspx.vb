﻿Imports com.nss.DBAccess
Imports System.Data
Partial Class Admin_ProcessList
    Inherits System.Web.UI.Page
    Private Property ProcessID() As Integer
        Get
            Return ViewState("ProcessID")
        End Get
        Set(ByVal value As Integer)
            ViewState("ProcessID") = value
        End Set
    End Property
    Private Property CampaignID() As Integer
        Get
            Return ViewState("CampaignID")
        End Get
        Set(ByVal value As Integer)
            ViewState("CampaignID") = value
        End Set
    End Property
    Private Property CampaignName() As String
        Get
            Return ViewState("CampaignName")
        End Get
        Set(ByVal value As String)
            ViewState("CampaignName") = value
        End Set
    End Property

    Private Property SelectedUser() As String
        Get
            Return ViewState("SelectedUser")
        End Get
        Set(ByVal value As String)
            ViewState("SelectedUser") = value
        End Set
    End Property

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            'CampaignName = Request.QueryString("CampaignName")
            CampaignID = Request.QueryString("CampaignID")
            If CampaignID <> -1 Then
                FetchUsers()
            Else
                ClientScript.RegisterClientScriptBlock(Me.GetType, "NotValid", "javascript: alert('No Campaign supllied');")

            End If

        End If

    End Sub

    Protected Sub dtgUsers_RowDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles dtgUsers.RowDataBound
        If e.Row.RowType = DataControlRowType.DataRow Then
            'ClientScript.RegisterForEventValidation(dtgUsers.ClientID)
            'e.Row.Attributes("onclick") = ClientScript.GetPostBackClientHyperlink(Me.dtgUsers, "Select$" & e.Row.RowIndex)

        End If
    End Sub

    
    Protected Sub dtgUsers_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles dtgUsers.SelectedIndexChanged
        'Code
        FetchUsers()
        SelectedUser = dtgUsers.SelectedRow.Cells(1).Text
        FetchUserRights()
    End Sub

    Private Sub FetchUsers()
        Dim db As New DBAccess("CRM")
        Dim dt As DataTable
        dt = db.ReturnTable("Select tbl_Data_UserRights.AgentID,[tbl_AgentMaster].Alias +'(' +tbl_Data_UserRights.AgentID +')' as [Name] from tbl_Data_UserRights inner join [tbl_AgentMaster] on [tbl_Data_UserRights].Agentid =[tbl_AgentMaster].agentid where tbl_Data_UserRights.Campaignid=" & CampaignID)
        dtgUsers.DataSource = dt
        dtgUsers.DataBind()
        LstSelectedUser.DataSource = dt
        LstSelectedUser.DataTextField = "Name"
        LstSelectedUser.DataValueField = "AgentID"
        LstSelectedUser.DataBind()
        db = Nothing
        Dim dbAll As New DBAccess("CRM")
        Dim dtAll As DataTable
        dtAll = dbAll.ReturnTable("Select  agentid as AgentID ,Agentname +' (' + agentid +')' as [Name] from  [tbl_AgentMaster] where agentid not in (Select tbl_Data_UserRights.AgentID from tbl_Data_UserRights where tbl_Data_UserRights.Campaignid=" & CampaignID & ") order by 2")
        
        LstAllUsers.DataSource = dtAll
        LstAllUsers.DataTextField = "Name"
        LstAllUsers.DataValueField = "AgentID"
        LstAllUsers.DataBind()
        dbAll = Nothing

    End Sub
    Private Sub FetchUserRights()
        Dim db As New DBAccess("CRM")
        Dim dr As DataRow = db.ReturnRow("Select AgentID ,[CanUpdate],[CanUpload],[IsSupervisor],[IsManager],[CanSeeReports]from tbl_Data_UserRights where Campaignid=" & CampaignID & " and Agentid='" & SelectedUser & "'")
        ChkCanSeeReports.Checked = dr("CanSeeReports")
        ChkCanUpdate.Checked = dr("CanUpdate")
        ChkCanUpload.Checked = dr("CanUpload")
        ChkSupervisor.Checked = dr("IsSupervisor")
        ChkManager.Checked = dr("IsManager")
        db = Nothing
    End Sub

    Protected Sub BtnShowAllUsers_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles BtnShowAllUsers.Click
        PanelUsers.Visible = True
        PanelRights.Visible = False
    End Sub
End Class
