﻿Imports com.nss.DBAccess
Imports System.Data
Imports System.Web.UI.DataVisualization.Charting
Imports System.Drawing
Partial Class Staffing_MPR_MPRgraph
    Inherits System.Web.UI.Page
#Region "--- Properties ---"
    Property AgentID() As String
        Get
            Return ViewState("AgentID")
        End Get
        Set(ByVal value As String)
            ViewState("AgentID") = value
        End Set
    End Property
#End Region
    Dim dtMPR As DataTable
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            If Session("AgentID") <> "" Then
                AgentID = Session("AgentID")
                PanelReports.Controls.Add(Common.GetMenu(Request.Url, AgentID, Request.ApplicationPath))
                FillProcessCampaigns()
                FillMonthYear()
                DrawChart()
            End If
        End If
    End Sub
#Region "---- Support Functions ----"
    Private Sub FillProcessCampaigns()
        Common.FillProcesses(CboProcess, AgentID, 0)
    End Sub
    Private Sub FillMonthYear()
        For ictr = 1 To 12
            cboMonth.Items.Add(New ListItem(MonthName(ictr), ictr))
        Next
        cboMonth.SelectedIndex = cboMonth.Items.IndexOf(cboMonth.Items.FindByValue(DateTime.Now.Month))
        For ictr = DateTime.Now.Year To 2012 Step -1
            cboYear.Items.Add(New ListItem(ictr, ictr))
        Next
        cboYear.SelectedIndex = cboYear.Items.IndexOf(cboYear.Items.FindByValue(DateTime.Now.Year))
    End Sub
    Private Sub GetData()
        Dim db As New DBAccess '("CRM")
        db.slDataAdd("Year", cboYear.SelectedValue)
        db.slDataAdd("Period", cboMonth.SelectedItem.Text)
        db.slDataAdd("ProcessId", CboProcess.SelectedValue)
        db.slDataAdd("GroupBy", CboGroup.SelectedValue)
        dtMPR = db.ReturnTable("usp_GetMPRSummary", , True)
        db = Nothing
        gdMPRdata.DataSource = dtMPR
        gdMPRdata.DataBind()
        lblReportName.Text = "MPR Performance Summary of " & CboProcess.SelectedItem.Text & " Process for month of " & cboMonth.SelectedItem.Text & " " & cboYear.SelectedItem.Text
    End Sub
#End Region
#Region "--- Events ----"
    Protected Sub cboMonth_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboMonth.SelectedIndexChanged
        DrawChart()
    End Sub
    Protected Sub cboYear_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboYear.SelectedIndexChanged
        DrawChart()
    End Sub
    Protected Sub btnRefresh_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnRefresh.Click
        DrawChart()
    End Sub
    Protected Sub CboGroup_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles CboGroup.SelectedIndexChanged
        DrawChart()
    End Sub
    Protected Sub CboProcess_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles CboProcess.SelectedIndexChanged
        DrawChart()
    End Sub
    Protected Sub ImageButton1_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton1.Click
        GetData()
        GridViewExportUtil.Export("MPRSummary.xls", Me.gdMPRdata)
    End Sub
    Dim Footer(10) As Integer
    Protected Sub gdMPRdata_RowDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles gdMPRdata.RowDataBound
        If e.Row.RowType = DataControlRowType.DataRow Then
            Dim SideTotal(10) As Integer
            Footer(1) += e.Row.Cells(1).Text
            Footer(2) += e.Row.Cells(2).Text
            Footer(3) += e.Row.Cells(3).Text
            Footer(4) += e.Row.Cells(4).Text

            SideTotal(1) = Convert.ToDecimal(DataBinder.Eval(e.Row.DataItem, "MPR Closed"))
            SideTotal(2) = Convert.ToDecimal(DataBinder.Eval(e.Row.DataItem, "Pending at TM level"))
            SideTotal(3) = Convert.ToDecimal(DataBinder.Eval(e.Row.DataItem, "Rejected by TM"))
            SideTotal(4) = Convert.ToDecimal(DataBinder.Eval(e.Row.DataItem, "Not Initiated by Supervisor"))
            e.Row.Cells(5).Text = SideTotal(1) + SideTotal(2) + SideTotal(3) + SideTotal(4)
            Footer(5) += e.Row.Cells(5).Text
            e.Row.Cells(5).Font.Bold = True
        End If
        If e.Row.RowType = DataControlRowType.Footer Then
            e.Row.Cells(0).Text = "Grand Total : "
            e.Row.Cells(1).Text = Footer(1)
            e.Row.Cells(2).Text = Footer(2)
            e.Row.Cells(3).Text = Footer(3)
            e.Row.Cells(4).Text = Footer(4)
            e.Row.Cells(5).Text = Footer(5)
        End If
    End Sub
#End Region
#Region "--- Draw Graph ---"
    Private Sub DrawChart()
        GetData()
        If dtMPR.Rows.Count > 0 Then
            RenderGraph(Chart1, CboGroup.SelectedItem.Text)
        End If
    End Sub
    Private Sub RenderGraph(ByVal charts As Chart, ByVal Title As String)
        Dim xValueMem As String = ""
        charts.Series.Clear()
        charts.Series.Add("series1")

        charts.ChartAreas(0).AxisX.IntervalAutoMode = DataVisualization.Charting.IntervalAutoMode.FixedCount
        charts.TextAntiAliasingQuality = DataVisualization.Charting.TextAntiAliasingQuality.High
        Dim mypane As System.Web.UI.DataVisualization.Charting.Series
        mypane = charts.Series(0)
        charts.Series(0).IsValueShownAsLabel = True
        charts.Series(0).MarkerColor = Drawing.Color.White
        charts.ChartAreas(0).AxisX.MajorGrid.Enabled = False
        charts.ChartAreas(0).AxisY.MajorGrid.Enabled = False
        With Chart1
            .Series.Clear()
            .Series.Add("Process")
            .Series.Add("MPR Closed")
            .Series.Add("Pending at TM level")
            .Series.Add("Rejected by TM")
            .Series.Add("Not initiated by Supervisor")
            With .Series(1)
                .XValueMember = dtMPR.Columns(0).ColumnName
                .YValueMembers = "MPR Closed"
                .ChartType = DataVisualization.Charting.SeriesChartType.StackedColumn
                .BorderWidth = 4
                .Color = Drawing.Color.DarkGreen
                .BackGradientStyle = DataVisualization.Charting.GradientStyle.VerticalCenter
                '.BackSecondaryColor = Drawing.Color.LightGray
                .IsValueShownAsLabel = True
            End With
            With .Series(2)
                .XValueMember = dtMPR.Columns(0).ColumnName
                .YValueMembers = "Pending at TM level"
                .ChartType = DataVisualization.Charting.SeriesChartType.StackedColumn
                .BorderWidth = 4
                .Color = Drawing.Color.DarkBlue
                .BackGradientStyle = DataVisualization.Charting.GradientStyle.VerticalCenter
                '.BackSecondaryColor = Drawing.Color.LightPink
                .IsValueShownAsLabel = True
            End With
            With .Series(3)
                .XValueMember = dtMPR.Columns(0).ColumnName
                .YValueMembers = "Rejected by TM"
                .ChartType = DataVisualization.Charting.SeriesChartType.StackedColumn
                .BorderWidth = 4
                .Color = Drawing.Color.Purple
                .BackGradientStyle = DataVisualization.Charting.GradientStyle.VerticalCenter
                '.BackSecondaryColor = Drawing.Color.LightGreen
                .IsValueShownAsLabel = True
            End With
            With .Series(4)
                .XValueMember = dtMPR.Columns(0).ColumnName
                .YValueMembers = "Not initiated by Supervisor"
                .ChartType = DataVisualization.Charting.SeriesChartType.StackedColumn
                .BorderWidth = 4
                .Color = Drawing.Color.Red
                .BackGradientStyle = DataVisualization.Charting.GradientStyle.VerticalCenter
                ' .BackSecondaryColor = Drawing.Color.LightPink
                .IsValueShownAsLabel = True
            End With
            .ChartAreas(0).AxisX.MajorGrid.Enabled = False
            .ChartAreas(0).AxisY.MajorGrid.Enabled = False
            .ChartAreas(0).AxisX.Interval = 1
            .ChartAreas(0).AxisX2.Interval = 1
            .ChartAreas(0).AxisX.IntervalAutoMode = DataVisualization.Charting.IntervalAutoMode.FixedCount
            .ChartAreas(0).AxisX2.IntervalAutoMode = DataVisualization.Charting.IntervalAutoMode.FixedCount
            .ChartAreas(0).AxisY2.MajorGrid.Enabled = False
        End With
        charts.Legends.Add("Legend1")
        charts.Legends("Legend1").Enabled = True
        charts.Legends("Legend1").Alignment = System.Drawing.StringAlignment.Near
        charts.Series(0).IsVisibleInLegend = False

        charts.Series(0).ChartType = DataVisualization.Charting.SeriesChartType.Column
        charts.Series(0).MarkerColor = Drawing.Color.White
        charts.Series(0)("DrawingStyle") = "Cylinder"

        charts.DataSource = dtMPR.DefaultView
        xValueMem = dtMPR.Columns(0).ColumnName
        charts.DataBind()
        charts.Titles.Add(Title)

        charts.Series(0).XValueMember = xValueMem
        charts.Series(0).YValueMembers = dtMPR.Columns(0).ColumnName
        charts.Series(0).LabelFormat = "{0:n}"

    End Sub
#End Region

End Class
