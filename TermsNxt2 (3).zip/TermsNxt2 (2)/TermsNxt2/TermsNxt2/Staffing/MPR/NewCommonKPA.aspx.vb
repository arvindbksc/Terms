﻿Imports com.nss.DBAccess
Imports System.Data

Partial Class Staffing_MPR_NewCommonKPA
    Inherits System.Web.UI.Page

#Region " --- Properties ---"
    Property AgentID() As String
        Get
            Return ViewState("AgentID")
        End Get
        Set(ByVal value As String)
            ViewState("AgentID") = value
        End Set
    End Property
    Property CampaignID() As Integer
        Get
            Return ViewState("CampaignID")
        End Get
        Set(ByVal value As Integer)
            ViewState("CampaignID") = value
        End Set
    End Property
    Property Role() As Integer
        Get
            Return ViewState("Role")
        End Get
        Set(ByVal value As Integer)
            ViewState("Role") = value
        End Set
    End Property
#End Region
#Region " ---- Load ----"
    Private Sub LoadData()
        FillKPARole()
        FillProcessCampaigns()
        FillPerformanceDrivers()
        lblNew.Visible = False
        txtNewcommonKPA.Visible = False
    End Sub
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        HumanMessage.Style.Item("visibility") = "hidden"
        If Not IsPostBack Then
            If Session("AgentID") <> "" Then
                CampaignID = Session("CampaignID")
                AgentID = Session("AgentID")
                PanelReports.Controls.Add(Common.GetMenu(Request.Url, AgentID, Request.ApplicationPath))
                LoadData()
                fillGrid()
                lblreportname.CurrentPage = "New CommonKPA"
            End If
        End If
    End Sub
#End Region
#Region " ---- Functions ----"
    Private Sub FillKPARole()
        Dim db As New DBAccess("CRM")
        Dim dt As New DataTable
        dt = New DataTable
        dt = db.ReturnTable("usp_getRoles", , True)
        db = Nothing
        cboRole.DataTextField = "Designation"
        cboRole.DataValueField = "Roleid"
        cboRole.DataSource = dt
        cboRole.DataBind()
        Role = cboRole.SelectedValue
        dt = Nothing
    End Sub
    Private Sub FillProcessCampaigns()
        Common.FillProcessCampaigns(CboProcess, cboCampaigns, AgentID, CampaignID)
        Common.FillProcesses(CboProcess, AgentID, 0)
        Dim item As New ListItem
        item.Text = "All"
        item.Value = 0
        If CboProcess.Items.Contains(item) Then
            CboProcess.Items.Remove(item)
        End If
    End Sub
    Private Sub FillPerformanceDrivers()
        Dim db As New DBAccess("CRM")
        Dim dt As New DataTable
        dt = New DataTable
        dt = db.ReturnTable("SELECT * FROM [tbl_Config_MPR_CommonKPA] WHERE Active=1 ORDER BY cmKPA asc", , False)
        db = Nothing
        cboCommonKPA.DataSource = dt
        cboCommonKPA.DataTextField = "cmKPA"
        cboCommonKPA.DataValueField = "CMKPAID"
        cboCommonKPA.DataBind()
        cboCommonKPA.Items.Insert(cboCommonKPA.Items.Count, "Other CommonKPA")
        dt = Nothing
    End Sub
    Private Sub fillGrid()
        Dim db As New DBAccess("CRM")
        Dim dt As New DataTable
        dt = New DataTable
        db.slDataAdd("ProcessId", CboProcess.SelectedValue)
        db.slDataAdd("role", Role)
        db.slDataAdd("userid", Session("MPRAgentID").ToString())
        dt = db.ReturnTable("[usp_CampaignCommonKPA]", , True)
        db = Nothing
        gvCommonKPA.DataSource = dt
        gvCommonKPA.DataBind()
        dt = Nothing
    End Sub
    Private Sub Mail(ByVal kpa As String, ByVal Process As String, ByVal role As String)
        Try
            'Dim objWSMail As New MailSendServiceXX.Service1SoapClient
            Dim strFrom As String = System.Configuration.ConfigurationManager.AppSettings("FROM")
            Dim db As New DBAccess("CRM")
            Dim dt As New DataTable
            Dim sAgentEmailId As String = ""
            Dim sMPRAgentEmailId As String = ""
            Dim sAgentName As String = ""
            dt = db.ReturnTable("select * from tbl_agentmaster where AgentID='" & Session("AgentId") & "'", False)
            If dt.Rows.Count > 0 Then
                sAgentEmailId = dt.Rows(0)("LanID") + System.Configuration.ConfigurationManager.AppSettings("EmailidAT")
                sAgentName = dt.Rows(0)("AgentName").ToString()
                dt = Nothing
            End If


            dt = db.ReturnTable("select * from tbl_agentmaster where AgentID ='" & Session("MPRAgentId") & "'", False)
            If dt.Rows.Count > 0 Then
                sMPRAgentEmailId = dt.Rows(0)("LanID") + System.Configuration.ConfigurationManager.AppSettings("EmailidAT")
                dt = Nothing
            End If

            Dim strMailBody As String = ""
            strMailBody += "<html xmlns='http://www.w3.org/1999/xhtml'>"
            strMailBody += "<body style='font-family: Verdana; font-size: .8em'>"
            strMailBody += "Hi,<br /><br />"
            strMailBody += "New CommonKPA has been added in " & Process & " process, detail is given below<br /><br />"
            strMailBody += "KPA:-&nbsp;&nbsp; " & kpa & "<br />"
            strMailBody += "<br /><br /><hr/><P> This mail was sent using the "
            strMailBody += "<a href='https://termsmonitor.coforge.com/'>TermsMonitor&reg;</a> Mail Service.We request you not to reply this message.</P>"
            strMailBody += "<br /><br />In case you wish to report issues with this mail, please send mail to mailto:Developers@coforge.com <br /> "
            strMailBody += "<br />This e-mail is confidential and may also be privileged.If you are not the intended recipient, please notify helpdesk immediately; you should not copy or use it for any purpose,nor disclose its contents to any other person."
            strMailBody += "</body>"
            strMailBody += "</html>"

            Dim MailSubject As String = "New CommonKPA Training Added/Modified By Your Supervisor  (" & sAgentName & ")"
            ''Dev One
            ' objWSMail.MailSendNewTech(System.Configuration.ConfigurationManager.AppSettings("WSR_PIP_ProcessManager"), MailSubject, "MPR Acceptance Form  <" & strFrom & ">", "", strMailBody.ToString(), "", sAgentEmailId, System.Configuration.ConfigurationManager.AppSettings("BCC"), "") '' Final


            ''Live One
            ' objWSMail.MailSendNewTech(sMPRAgentEmailId, MailSubject, "New CommonKPA Training Added/Modified <" & strFrom & ">", "", strMailBody.ToString(), "", sAgentEmailId, System.Configuration.ConfigurationManager.AppSettings("WSR_PIP_ProcessManager"), "") '' Final

            Common.SMTPSendMail(sMPRAgentEmailId, MailSubject, "New CommonKPA Training Added/Modified <" & strFrom & ">", strMailBody.ToString(), sAgentEmailId, System.Configuration.ConfigurationManager.AppSettings("WSR_PIP_ProcessManager"))

            'objWSMail = Nothing
        Catch ex As Exception
            AlertMessage(ex.Message.ToString)
        End Try
    End Sub
#End Region
#Region " --- Event ---"
    Protected Sub btnRefresh_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnRefresh.Click
        fillGrid()
    End Sub
    Protected Sub cboKPA_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboCommonKPA.SelectedIndexChanged
        If cboCommonKPA.Text.Trim = "Other CommonKPA" Then
            lblNew.Visible = True
            txtNewcommonKPA.Visible = True
            txtNewcommonKPA.Focus()
        Else
            lblNew.Visible = False
            txtNewcommonKPA.Visible = False
        End If
    End Sub
    Protected Sub CboProcess_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles CboProcess.SelectedIndexChanged
        fillGrid()
    End Sub
    Protected Sub cboRole_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboRole.SelectedIndexChanged
        Role = cboRole.SelectedValue
        fillGrid()
    End Sub
    Protected Sub btnNewKPA_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnNewCommonKPA.Click
        PanelKPA.Visible = True
        txtNewcommonKPA.Text = ""
        txtNewcommonKPA.Visible = False
        lblNew.Visible = False
        btnNewCommonKPA.Visible = False
    End Sub
    Protected Sub btnSave_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnSave.Click
        Dim db As New DBAccess
        LblError.Text = ""
        If txtNewcommonKPA.Visible = True And txtNewcommonKPA.Text = "" Then
            AlertMessage("Please Enter New CommonKPA")
            txtNewcommonKPA.Focus()
            Exit Sub
        End If
        If txtNewcommonKPA.Visible = True And txtNewcommonKPA.Text <> "" Then
            For i As Integer = 0 To cboCommonKPA.Items.Count - 1
                If RTrim(LTrim(txtNewcommonKPA.Text.ToUpper)) = RTrim(LTrim(cboCommonKPA.Items(i).Text.ToUpper)) Then
                    AlertMessage("The Entered CommonKPA is already listed in available CIDPs")
                    Exit Sub
                End If
            Next
        End If
        'If txtNewcommonKPA.Visible = False And cboCommonKPA.SelectedIndex >= 0 Then
        '    For Each row As GridViewRow In gvCommonKPA.Rows
        '        Dim lblCompare As Label
        '        lblCompare = CType(row.FindControl("lblCDP"), Label)
        '        If cboCommonKPA.SelectedItem.Text.ToUpper = lblCompare.Text.ToUpper Then
        '            AlertMessage("The Selected CommonKPA is listed already in specified Campaign and Role")
        '            Exit Sub
        '        End If
        '    Next
        'End If
        Dim kpa As String = ""
        db = New DBAccess("CRM")
        db.slDataAdd("CampaignID", cboCampaigns.SelectedValue)
        db.slDataAdd("Processid", CboProcess.SelectedValue)
        db.slDataAdd("role", cboRole.SelectedValue)
        If txtNewcommonKPA.Visible = False Then
            db.slDataAdd("cmKPA", cboCommonKPA.SelectedItem.Text.Trim)
        Else
            db.slDataAdd("cmKPA", txtNewcommonKPA.Text.Trim)
            kpa = txtNewcommonKPA.Text.Trim
        End If
        db.Executeproc("usp_MPR_InsertCommonKPA")
        If kpa <> "" Then
            Mail(kpa, CboProcess.SelectedItem.Text, cboRole.SelectedItem.Text)
        End If
        SuccessMessage("CommonKPA Training has been added for campaign " & CboProcess.SelectedItem.Text & " and role " & cboRole.SelectedItem.Text)
        db = Nothing
        PanelKPA.Visible = False
        btnNewCommonKPA.Visible = True
        fillGrid()
    End Sub
    Protected Sub btnCancel_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnCancel.Click
        PanelKPA.Visible = False
        txtNewcommonKPA.Text = ""
        txtNewcommonKPA.Visible = False
        lblNew.Visible = True
        btnNewCommonKPA.Visible = True
        cboCommonKPA.SelectedIndex = 0
    End Sub

    Protected Sub cboCampaigns_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboCampaigns.SelectedIndexChanged
        CampaignID = cboCampaigns.SelectedValue
        fillGrid()
    End Sub
#End Region
#Region "--- Grid Ops--"
    Private Sub DeleteCommonKPA(ByVal kpaid As Integer)
        Dim db As New DBAccess("CRM")
        Try
            Dim str As String = ""
            str = "delete From tbl_Config_MPR_CommonKPA_ProcessMap where CmnKPAID=" & kpaid & " and processid =" & CboProcess.SelectedValue & " and campaignID =" & cboCampaigns.SelectedValue & " and role=" & cboRole.SelectedValue
            db.exeSQL(str)
            db = Nothing
            SuccessMessage("Common KPA has been deleted for campaign " & CboProcess.SelectedItem.Text & " and role " & cboRole.SelectedItem.Text)
            fillGrid()
        Catch ex As Exception
            AlertMessage(ex.ToString)
        End Try
    End Sub
    Protected Sub gvCommonKPA_RowCommand(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewCommandEventArgs) Handles gvCommonKPA.RowCommand
        If e.CommandName.Trim = "DeleteCommonKPA" Then
            Dim kpaid As Integer = Convert.ToInt32(e.CommandArgument)
            DeleteCommonKPA(kpaid)
        End If
    End Sub
    Protected Sub gvCommonKPA_RowDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles gvCommonKPA.RowDataBound
        If e.Row.RowType = DataControlRowType.DataRow Then
            Dim lnk As LinkButton = e.Row.FindControl("lnkEdit")
            lnk.Attributes.Add("onclick", "javascript:return " _
            & "confirm('Are you sure you want to delete CommonKPA  [ " & DataBinder.Eval(e.Row.DataItem, "cmKPA") & " ]')")
        End If
    End Sub
    Protected Sub gvCommonKPA_RowDeleting(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewDeleteEventArgs) Handles gvCommonKPA.RowDeleting
        Dim kpaid As Integer = gvCommonKPA.DataKeys(e.RowIndex).Value
        DeleteCommonKPA(kpaid)
    End Sub
#End Region

#Region " --- Utility ---"

    Private Sub AlertMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMFail"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub

    Private Sub SuccessMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMSuccess"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub

#End Region

End Class
