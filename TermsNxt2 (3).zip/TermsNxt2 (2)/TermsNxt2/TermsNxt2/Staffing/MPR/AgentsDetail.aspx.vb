﻿Imports com.nss.DBAccess
Imports System.Data
Partial Class Staffing_MPR_AgentsDetail
    Inherits System.Web.UI.Page
#Region " ---- Properties -----"
    Property AgentId() As String
        Get
            Return ViewState("AgentId")
        End Get
        Set(ByVal value As String)
            ViewState("AgentId") = value
        End Set
    End Property
    Property CampaignId() As Integer
        Get
            Return ViewState("CampaignId")
        End Get
        Set(ByVal value As Integer)
            ViewState("CampaignId") = value
        End Set
    End Property
    Property FormId() As Integer
        Get
            Return ViewState("FormId")
        End Get
        Set(ByVal value As Integer)
            ViewState("FormId") = value
        End Set
    End Property
    Property CurrentLevel() As Integer
        Get
            Return ViewState("CurrentLevel")
        End Get
        Set(ByVal value As Integer)
            ViewState("CurrentLevel") = value
        End Set
    End Property
    Property SupervisorID() As String
        Get
            Return ViewState("SupervisorID")
        End Get
        Set(ByVal value As String)
            ViewState("SupervisorID") = value
        End Set
    End Property
    Property UserID() As String
        Get
            Return ViewState("UserID")
        End Get
        Set(ByVal value As String)
            ViewState("UserID") = value
        End Set
    End Property
#End Region

#Region " ---- Load ----"
    Protected Sub form1_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles form1.Load
        If Not IsPostBack Then
            AgentId = Session("AgentId")
            CurrentLevel = 2
            SupervisorID = Session("UserID")
            UserID = Session("UserID")
            'Session("username") = "Alok Mani"
            FillGrid(SupervisorID)
            lblReportName.CurrentPage = "Fill MPR"
            link2.Text = Session("username") & "(" & Session("UserID") & ")"
            'link2.Text = Session("username") & "(" & UserID & ")"
            Image3.Visible = False
            Image4.Visible = False
            Image5.Visible = False
            Image6.Visible = False
            Image7.Visible = False
            Image8.Visible = False
        End If
    End Sub
#End Region
#Region " ---- Functions ----"
   
    'Private Sub FillProcessCampaigns()
    '    Common.FillProcessCampaigns(CboProcess, cboCampaigns, AgentId, CampaignId)
    '    Dim lstcampaign As New ListItem
    '    lstcampaign.Value = 0
    '    lstcampaign.Text = "All"
    '    If cboCampaigns.Items.Contains(lstcampaign) Then
    '        cboCampaigns.Items.Remove(lstcampaign)
    '    End If
    'End Sub
    Private Sub FillGrid(ByVal supervisorid As String)
        GridAgents.Columns(GridAgents.Columns.Count - 1).Visible = True
        Dim db As New DBAccess("CRM")
        Dim dt As DataTable
        db.slDataAdd("SupervisorId", supervisorid)
        'db.slDataAdd("Campaignid", CampaignId)
        'db.slDataAdd("userid", UserID)
        dt = db.ReturnTable("usp_GetMPRAgents", , True)
        GridAgents.DataSource = dt
        GridAgents.DataBind()
        dt = Nothing
        db = Nothing
        GridAgents.Columns(GridAgents.Columns.Count - 1).Visible = False
    End Sub
    'Protected Sub SetColor()
    '    Try
    '        For Each row As GridViewRow In GridAgents.Rows
    '            Dim hyer As New LinkButton
    '            'Dim hyer As New HyperLink
    '            'hyer = CType(row.FindControl("HyperStatus"), HyperLink)
    '            hyer = CType(row.FindControl("lbnLink"), LinkButton)
    '            Dim txt As String = hyer.Text
    '            If txt = "Fill New Form" Then
    '                hyer.ForeColor = Drawing.Color.Red
    '            ElseIf txt = "Saved Form" Then
    '                hyer.ForeColor = Drawing.Color.Blue
    '            ElseIf txt = "Closed Form" Then
    '                hyer.ForeColor = Drawing.Color.Green
    '            End If
    '        Next
    '    Catch ex As Exception
    '    End Try
    'End Sub
#End Region

#Region "---- Event ----"
    'Protected Sub cboCampaigns_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboCampaigns.SelectedIndexChanged
    '    CampaignId = cboCampaigns.SelectedValue
    '    FillGrid(SupervisorID)
    'End Sub
    'Protected Sub btnRefresh_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnRefresh.Click
    '    FillGrid(SupervisorID)
    'End Sub
    'Protected Sub GridAgents_RowCommand(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewCommandEventArgs) Handles GridAgents.RowCommand
    '    Dim row As GridViewRow = CType(CType(e.CommandSource, Control).NamingContainer, GridViewRow)
    '    If e.CommandName = "Select" Then
    '        Dim FormStatus As String = CType(row.FindControl("lbnLink"), LinkButton).Text
    '        If FormStatus.ToUpper.Trim = "SAVED FORM" Then
    '            Dim Aid As String = CType(row.FindControl("lblAgentid"), Label).Text
    '            Dim FormId As Integer = GridAgents.DataKeys(row.RowIndex).Value
    '            Response.Redirect("FillMPR.aspx?FormId=" & FormId & "&Status=1&AgentId=" & Aid & "&CampId=" & CampaignId)
    '        ElseIf FormStatus.ToUpper.Trim = "CLOSED FORM" Then
    '            Dim Aid As String = CType(row.FindControl("lblAgentid"), Label).Text
    '            Dim FormId As Integer = GridAgents.DataKeys(row.RowIndex).Value
    '            Response.Redirect("FillMPR.aspx?FormId=" & FormId & "&Status=2&AgentId=" & Aid & "&CampId=" & CampaignId)
    '        Else
    '            Dim Aid As String = CType(row.FindControl("lblAgentid"), Label).Text
    '            Dim FormId As Integer = GridAgents.DataKeys(row.RowIndex).Value
    '            Response.Redirect("FillMPR.aspx?FormId=" & FormId & "&Status=0&AgentId=" & Aid & "&CampId=" & CampaignId)
    '        End If
    '    End If
    'End Sub

    Protected Sub GridAgents_RowDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles GridAgents.RowDataBound

        If e.Row.RowType = DataControlRowType.DataRow Then
            If e.Row.Cells(e.Row.Cells.Count - 1).Text.ToLower = "false" Or CType(e.Row.FindControl("lblAgentID"), Label).Text = SupervisorID Then
                CType(e.Row.FindControl("lnkbtagentname"), LinkButton).Visible = False
            Else
                CType(e.Row.FindControl("lblAgentName"), Label).Visible = False
            End If
        End If
    End Sub
    Protected Sub GridAgents_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles GridAgents.SelectedIndexChanged
        Dim lnk As New LinkButton, img As New Image
        CurrentLevel += 1
        Select Case CurrentLevel
            Case 3
                lnk = link3
                img = Image3
                link2.CssClass = "notselectedlink"
            Case 4
                lnk = Link4
                img = Image4
                link3.CssClass = "notselectedlink"
            Case 5
                lnk = Link5
                img = Image5
                Link4.CssClass = "notselectedlink"
            Case 6
                lnk = Link6
                img = Image6
                Link5.CssClass = "notselectedlink"
            Case 7
                lnk = Link7
                img = Image7
                Link6.CssClass = "notselectedlink"
            Case 8
                lnk = Link8
                img = Image8
                Link7.CssClass = "notselectedlink"
        End Select
        lnk.Text = GridAgents.SelectedDataKey.Item("AgentName").ToString & "(" & GridAgents.SelectedDataKey.Item("AgentID").ToString & ")"
        SupervisorID = GridAgents.SelectedDataKey.Item("AgentID").ToString
        FillGrid(SupervisorID)

        lnk.Visible = True
        lnk.CssClass = "selectedlink"
        img.Visible = True
    End Sub
#End Region
#Region "-----Supervisor change-----"
    Private Sub HideAllSideLinks(ByVal ctrl As LinkButton)
        Dim from As Integer
        from = ctrl.ID.ToLower.Replace("link", "")
        CurrentLevel = from

        Select Case from
            Case 2
                link3.Visible = False
                Link4.Visible = False
                Link5.Visible = False
                Link6.Visible = False
                Link7.Visible = False
                Link8.Visible = False

                Image3.Visible = False
                Image4.Visible = False
                Image5.Visible = False
                Image6.Visible = False
                Image7.Visible = False
                Image8.Visible = False
            Case 3
                Link4.Visible = False
                Link5.Visible = False
                Link6.Visible = False
                Link7.Visible = False
                Link8.Visible = False
                Image4.Visible = False
                Image5.Visible = False
                Image6.Visible = False
                Image7.Visible = False
                Image8.Visible = False
            Case 4

                Link5.Visible = False
                Link6.Visible = False
                Link7.Visible = False
                Link8.Visible = False
                Image5.Visible = False
                Image6.Visible = False
                Image7.Visible = False
                Image8.Visible = False
            Case 5

                Link6.Visible = False
                Link7.Visible = False
                Link8.Visible = False

                Image6.Visible = False
                Image7.Visible = False
                Image8.Visible = False
            Case 6

                Link7.Visible = False
                Link8.Visible = False

                Image7.Visible = False
                Image8.Visible = False
            Case 7

                Link8.Visible = False

                Image8.Visible = False
            Case 8
                'do noting
        End Select




    End Sub
    Protected Sub Sidelink_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles link2.Click

        Dim length As Integer

        length = sender.Text.LastIndexOf(")") - sender.Text.LastIndexOf("(")

        SupervisorID = sender.Text.Substring(sender.Text.LastIndexOf("(") + 1, length - 1)
        fillgrid(SupervisorID)
        HideAllSideLinks(sender)
        sender.CssClass = "selectedlink"
    End Sub
#End Region
    'Private Sub GetAgentDetail()
    'Dim db As New DBAccess("termsmonitor")
    'Dim dt As New DataTable
    'Session("LanId") = "jatint"
    'db.slDataAdd("LanId", Session("LanId"))
    'dt = db.ReturnTable("usp_MPRGetAgentsAsPerStatus", "", True)
    'gvAgents.DataSource = dt
    'gvAgents.DataBind()
    'db = Nothing
    'End Sub
    
   
End Class
