﻿Imports System.Data
Imports com.nss.DBAccess
Partial Class Staffing_MPR_PIPReport
    Inherits System.Web.UI.Page
    Dim dtMPR As New DataTable
#Region "--- Properties --"
    Property AgentId() As String
        Get
            Return ViewState("AgentId")
        End Get
        Set(ByVal value As String)
            ViewState("AgentId") = value
        End Set
    End Property
    Property CampaignID() As Integer
        Get
            Return ViewState("CampaignID")
        End Get
        Set(ByVal value As Integer)
            ViewState("CampaignID") = value
        End Set
    End Property
    Property Month() As String
        Get
            Return ViewState("Month")
        End Get
        Set(ByVal value As String)
            ViewState("Month") = value
        End Set
    End Property
    Property Year() As Integer
        Get
            Return ViewState("Year")
        End Get
        Set(ByVal value As Integer)
            ViewState("Year") = value
        End Set
    End Property

#End Region
#Region "---- Load ----"
    Private Sub LoadData()
        FillProcessCampaigns()
        FillMonthYear()
        GetData()
    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            AgentId = Session("AgentID")
            CampaignID = Session("CampaignID")
            PanelReports.Controls.Add(Common.GetMenu(Request.Url, AgentId, Request.ApplicationPath))
            LoadData()
        Else
            GetData()
            Dim btnlink As New LinkButton()
        End If
        lblreportname.CurrentPage = "MPR PIP Report between " & cboMonth.SelectedItem.Text & ", " & cboYear.SelectedValue & " and " & cboMonth2.SelectedItem.Text & ", " & cboYear2.SelectedValue

    End Sub
#End Region
#Region "--- Event -----"
    Protected Sub btnRefresh_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnRefresh.Click
        GetData()
    End Sub
    Protected Sub cboMonth_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboMonth.SelectedIndexChanged
        GetData()
    End Sub

    Protected Sub cboYear_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboYear.SelectedIndexChanged
        GetData()
    End Sub
    Protected Sub ImageButton1_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton1.Click
        GetData()
        GridViewExportUtil.Export("ViewMPR.xls", Me.GridView1)
    End Sub

#End Region
#Region " ------- FUNCTIONS ---------"

    Private Sub FillMonthYear()
        For ictr = 1 To 12
            cboMonth.Items.Add(New ListItem(MonthName(ictr), ictr))
        Next

        For ictr = DateTime.Now.Year To DateTime.Now.Year - 5 Step -1
            cboYear.Items.Add(New ListItem(ictr, ictr))
        Next

        For ictr = 1 To 12
            cboMonth2.Items.Add(New ListItem(MonthName(ictr), ictr))
        Next

        For ictr = DateTime.Now.Year To DateTime.Now.Year - 5 Step -1
            cboYear2.Items.Add(New ListItem(ictr, ictr))
        Next

    End Sub
    Private Sub GetData()
        Dim db As New DBAccess
        db.slDataAdd("processid", CboProcess.SelectedValue)
        db.slDataAdd("Year", cboYear.SelectedValue)
        db.slDataAdd("Period", cboMonth.SelectedItem.Text)

        db.slDataAdd("Year2", cboYear2.SelectedValue)
        db.slDataAdd("Period2", cboMonth2.SelectedItem.Text)

        db.slDataAdd("GroupBy", CboGroup.SelectedValue)
        dtMPR = db.ReturnTable("usp_getMPR_PIPATVW", , True)
        db = Nothing
        GridView1.DataSource = dtMPR
        GridView1.DataBind()
        dtMPR = Nothing
    End Sub

    Private Sub FillProcessCampaigns()
        Common.FillProcesses(CboProcess, AgentId, 0)
    End Sub

#End Region

End Class
