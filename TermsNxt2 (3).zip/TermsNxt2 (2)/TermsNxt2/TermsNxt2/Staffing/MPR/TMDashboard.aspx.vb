﻿Imports System.Data
Imports com.nss.DBAccess
Partial Class Staffing_MPR_TMDashboard
    Inherits System.Web.UI.Page

#Region "---- Properties ----"
    Property AgentId() As String
        Get
            Return ViewState("AgentId")
        End Get
        Set(ByVal value As String)
            ViewState("AgentId") = value
        End Set
    End Property
#End Region
#Region "---- Load ----"
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            'Session("Agentid") = "NSS44648"
            AgentId = Session("Agentid")
            GetAcceptedMPR()
            GetPendingReview()
        End If
    End Sub
#End Region
#Region "---- Functions ---"
    Private Sub GetAcceptedMPR()
        Dim db As New DBAccess("CRM")
        'Dim db As New DBAccess
        Dim dt As New DataTable
        db.slDataAdd("AgentId", AgentId)
        dt = db.ReturnTable("usp_LatestReviewedMPR", , True)
        db = Nothing
        gvLatestReview.DataSource = dt
        gvLatestReview.DataBind()
    End Sub
    Private Sub GetPendingReview()
        Dim db As New DBAccess("CRM")
        'Dim db As New DBAccess
        Dim dt As New DataTable
        db.slDataAdd("AgentId", AgentId)
        dt = db.ReturnTable("usp_PendinReviewMPR", , True)
        db = Nothing
        gvPendingReview.DataSource = dt
        gvPendingReview.DataBind()
    End Sub
#End Region
#Region "---- Grid Ops ----"
    Protected Sub gvPendingReview_RowCommand(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewCommandEventArgs) Handles gvPendingReview.RowCommand
        Dim row As GridViewRow = CType(CType(e.CommandSource, Control).NamingContainer, GridViewRow)
        If e.CommandName = "Review" Then
            Dim AgentId As String = gvPendingReview.DataKeys(row.RowIndex).Item("AgentId").ToString
            Dim ProcessId As Integer = gvPendingReview.DataKeys(row.RowIndex).Item("ProcessId").ToString
            Dim CampaignId As Integer = gvPendingReview.DataKeys(row.RowIndex).Item("Campaignid").ToString
            Dim lblDate As Label = row.FindControl("lblMonth")
            Dim split() As String = lblDate.Text.ToString.Split("/")
            Response.Redirect("TMreview.aspx?AgentId=" & AgentId & "&Month=" & split(0).ToString.Trim & "&Year=" & split(1) & "&ProcessId=" & ProcessId & "&CampaignId=" & CampaignId & "&Page=2")
        End If
    End Sub
    Protected Sub gvLatestReview_RowCommand(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewCommandEventArgs) Handles gvLatestReview.RowCommand
        Dim row As GridViewRow = CType(CType(e.CommandSource, Control).NamingContainer, GridViewRow)
        If e.CommandName = "View" Then
            Dim AgentId As String = gvLatestReview.DataKeys(row.RowIndex).Item("AgentId").ToString
            Dim ProcessId As Integer = gvLatestReview.DataKeys(row.RowIndex).Item("ProcessId").ToString
            'Dim CampaignId As Integer = gvLatestReview.DataKeys(row.RowIndex).Item("Campaignid").ToString
            Dim lblDate As Label = row.FindControl("lblMonth")
            Dim split() As String = lblDate.Text.ToString.Split("/")
            Response.Redirect("TMreview.aspx?AgentId=" & AgentId & "&Month=" & split(0).ToString.Trim & "&Year=" & split(1) & "&ProcessId=" & ProcessId & "&Page=2&St=3")
        End If
    End Sub
    Protected Sub gvLatestReview_RowDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles gvLatestReview.RowDataBound
        If e.Row.RowType = DataControlRowType.DataRow Then
            If gvLatestReview.DataKeys(e.Row.RowIndex).Item("Status").ToString.ToLower = "rejected" Then
                'Dim status As Label = e.Row.FindControl("lblStatus")
                Dim status As LinkButton = e.Row.FindControl("lbnStatus")
                status.ForeColor = Drawing.Color.Red
                status.Font.Bold = True
            Else
                'Dim status As Label = e.Row.FindControl("lblStatus")
                Dim status As LinkButton = e.Row.FindControl("lbnStatus")
                status.ForeColor = Drawing.Color.Green
                status.Font.Bold = True
            End If
        End If
    End Sub
#End Region
End Class
