﻿Imports System.Data
Imports com.nss.DBAccess
Partial Class Staffing_MPR_viewMPR
    Inherits System.Web.UI.Page
    Dim dtMPR As New DataTable
#Region "--- Properties --"
    Property AgentId() As String
        Get
            Return ViewState("AgentId")
        End Get
        Set(ByVal value As String)
            ViewState("AgentId") = value
        End Set
    End Property
    Property CampaignID() As Integer
        Get
            Return ViewState("CampaignID")
        End Get
        Set(ByVal value As Integer)
            ViewState("CampaignID") = value
        End Set
    End Property
    Property Month() As String
        Get
            Return ViewState("Month")
        End Get
        Set(ByVal value As String)
            ViewState("Month") = value
        End Set
    End Property
    Property Year() As Integer
        Get
            Return ViewState("Year")
        End Get
        Set(ByVal value As Integer)
            ViewState("Year") = value
        End Set
    End Property
    Property AgentRole() As String
        Get
            Return ViewState("AgentRole")
        End Get
        Set(ByVal value As String)
            ViewState("AgentRole") = value
        End Set
    End Property
    Property IsHR() As Boolean
        Get
            Return ViewState("IsHR")
        End Get
        Set(ByVal value As Boolean)
            ViewState("IsHR") = value
        End Set
    End Property
#End Region
#Region "---- Load ----"
    Private Sub LoadData()
        Dim db As New DBAccess
        IsHR = db.ReturnValue("select * from tbl_AgentMaster where IsHR=1 AND AgentID='" & AgentId & "' AND Active=1", False)
        db = Nothing
        FillProcessCampaigns()
        FillMonthYear()
        If Request.QueryString("back") = 1 Then
            CboProcess.Items.FindByValue(Request.QueryString("Process")).Selected = True
            cboMonth.Items.FindByText(Request.QueryString("Month")).Selected = True
            cboYear.Items.FindByText(Request.QueryString("Year")).Selected = True
            GetData()
        Else
            GetData()
        End If
    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            AgentId = Session("AgentID")
            ' AgentId = "NSS59145"
            CampaignID = Session("CampaignID")
            PanelReports.Controls.Add(Common.GetMenu(Request.Url, AgentId, Request.ApplicationPath))
            LoadData()
        Else
            GetData()
            Dim btnlink As New LinkButton()
        End If
        lblreportname.CurrentPage = "MPR Report For " & cboMonth.SelectedItem.Text & ", " & cboYear.SelectedValue
       
    End Sub
#End Region
#Region "--- Event -----"
    Protected Sub btnRefresh_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnRefresh.Click
        GetData()
    End Sub
    Protected Sub cboMonth_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboMonth.SelectedIndexChanged
        GetData()
    End Sub
    'Protected Sub cboCampaigns_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboCampaigns.SelectedIndexChanged
    '    CampaignID = cboCampaigns.SelectedValue
    '    GetData()
    'End Sub
    Protected Sub cboYear_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboYear.SelectedIndexChanged
        GetData()
    End Sub
    Protected Sub ImageButton1_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton1.Click
        GetData()
        GridViewExportUtil.Export("ViewMPR.xls", Me.GridView1)
    End Sub
    Protected Sub CboProcess_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles CboProcess.SelectedIndexChanged
        GetData()
    End Sub
    Protected Sub GridView1_RowDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles GridView1.RowDataBound
        If e.Row.RowType = DataControlRowType.Header Then
            e.Row.Cells(0).Visible = False
            'e.Row.Cells(1).Visible = False
        End If
        Dim btnlink As LinkButton
        If e.Row.RowType = DataControlRowType.DataRow Then
            e.Row.Cells(0).Visible = False
            'e.Row.Cells(1).Visible = False
            btnlink = New LinkButton
            btnlink.ID = e.Row.Cells(1).Text

            Select Case e.Row.Cells(10).Text
                Case "1"
                    e.Row.Cells(10).Text = "Yes"
                Case "2"
                    e.Row.Cells(10).Text = "No"
                Case Else
                    e.Row.Cells(10).Text = "N/A"
            End Select

            Select Case e.Row.Cells(11).Text
                Case "1"
                    e.Row.Cells(11).Text = "Yes"
                Case "2"
                    e.Row.Cells(11).Text = "No"
                Case Else
                    e.Row.Cells(11).Text = "N/A"
            End Select

            Select Case e.Row.Cells(12).Text
                Case "1"
                    e.Row.Cells(12).Text = "Yes"
                Case "2"
                    e.Row.Cells(12).Text = "No"
                Case Else
                    e.Row.Cells(12).Text = "N/A"
            End Select


            Select Case e.Row.Cells(13).Text
                Case "1"
                    e.Row.Cells(13).Text = "Criminal"
                Case "2"
                    e.Row.Cells(13).Text = "Basic"
                Case "3"
                    e.Row.Cells(13).Text = "Expected"
                Case "4"
                    e.Row.Cells(13).Text = "Unbelievable"
                Case "5"
                    e.Row.Cells(13).Text = "Surprise"

                Case Else
                    e.Row.Cells(13).Text = "N/A"
            End Select


            btnlink.Text = dtMPR.Rows(e.Row.RowIndex)(2).ToString
            AgentRole = dtMPR.Rows(e.Row.RowIndex)(0).ToString
            btnlink.ToolTip = "Please Click for Detail View Of [ " & dtMPR.Rows(e.Row.RowIndex)(2).ToString & "]"
            AddHandler btnlink.Click, AddressOf Me.btnlink_OnClick
            e.Row.Cells(2).Controls.Add(btnlink)
            e.Row.Cells(1).Text = Replace(e.Row.Cells(1).Text, "nss", "")
        End If
    End Sub
    Public Sub btnlink_OnClick(ByVal sender As Object, ByVal e As EventArgs)
        Dim AgentId As String = CType(sender, LinkButton).ID
        Response.Redirect("fillMPR.aspx?ProcessId=" & CboProcess.SelectedValue & "&AgentId=" & AgentId & "&Month=" & cboMonth.SelectedItem.Text & "&Year=" & cboYear.SelectedValue & "&page=1&AgentRole=" & AgentRole)
    End Sub
#End Region
#Region " ------- FUNCTIONS ---------"
    Private Sub FillProcessCampaigns()
        'Common.FillProcessCampaigns(CboProcess, cboCampaigns, AgentId, CampaignID)
        Common.FillProcesses(CboProcess, AgentId)
        'If IsHR = False Then
        '    If CampaignID <> 52 Then
        '        Dim lstprocess As New ListItem
        '        lstprocess.Value = 0
        '        lstprocess.Text = "All"
        '        If CboProcess.Items.Contains(lstprocess) Then
        '            CboProcess.Items.Remove(lstprocess)
        '        End If
        '    End If
        'End If
    End Sub
    Private Sub FillMonthYear()
        For ictr = 1 To 12
            cboMonth.Items.Add(New ListItem(MonthName(ictr), ictr))
        Next
        If Not Request.QueryString("back") = 1 Then
            cboMonth.SelectedIndex = cboMonth.Items.IndexOf(cboMonth.Items.FindByValue(DateTime.Now.Month))
        End If

        For ictr = DateTime.Now.Year To DateTime.Now.Year - 5 Step -1
            cboYear.Items.Add(New ListItem(ictr, ictr))
        Next
        If Not Request.QueryString("back") = 1 Then
            cboYear.SelectedIndex = cboYear.Items.IndexOf(cboYear.Items.FindByValue(DateTime.Now.Year))
        End If
    End Sub
    Private Sub GetData()
        Dim db As New DBAccess("CRM")
        db.slDataAdd("processid", CboProcess.SelectedValue)
        db.slDataAdd("Year", cboYear.SelectedValue)
        db.slDataAdd("Period", cboMonth.SelectedItem.Text)
        db.slDataAdd("userid", AgentId)
        dtMPR = db.ReturnTable("usp_getMPRreport", , True)
        db = Nothing
        GridView1.DataSource = dtMPR
        GridView1.DataBind()
        dtMPR = Nothing
    End Sub
#End Region
    
End Class
