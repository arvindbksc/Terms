﻿Imports com.nss.DBAccess
Imports System.Data
Imports System.IO
Imports System.Data.SqlClient
Imports System.Net
Partial Class Staffing_MPR_FillMPR
    Inherits System.Web.UI.Page
    Dim connCRM As String = Common.connCRM
    Dim conn As SqlConnection
    Dim cmd As SqlCommand
    Dim adp As SqlDataAdapter

#Region "---- Properties -----"
    Property FormId() As String
        Get
            Return ViewState("FormId")
        End Get
        Set(ByVal value As String)
            ViewState("FormId") = value
        End Set
    End Property
    Property CampaignId() As Int16
        Get
            Return ViewState("CampaignId")
        End Get
        Set(ByVal value As Int16)
            ViewState("CampaignId") = value
        End Set
    End Property
    Property AgentCampaignId() As Int16
        Get
            Return ViewState("AgentCampaignId")
        End Get
        Set(ByVal value As Int16)
            ViewState("AgentCampaignId") = value
        End Set
    End Property
    Property ProcessId() As Int16
        Get
            Return ViewState("ProcessId")
        End Get
        Set(ByVal value As Int16)
            ViewState("ProcessId") = value
        End Set
    End Property
    Property AgentId() As String
        Get
            Return ViewState("AgentId")
        End Get
        Set(ByVal value As String)
            ViewState("AgentId") = value
        End Set
    End Property
    Property UserID() As String
        Get
            Return ViewState("UserID")
        End Get
        Set(ByVal value As String)
            ViewState("UserID") = value
        End Set
    End Property
    Property Status() As Integer
        Get
            Return ViewState("Status")
        End Get
        Set(ByVal value As Integer)
            ViewState("Status") = value
        End Set
    End Property
    Property StartDate() As String
        Get
            Return ViewState("startdate")
        End Get
        Set(ByVal value As String)
            ViewState("startdate") = value
        End Set
    End Property
    Property EndDate() As String
        Get
            Return ViewState("enddate")
        End Get
        Set(ByVal value As String)
            ViewState("enddate") = value
        End Set
    End Property
    Property AgentRole() As Integer
        Get
            Return ViewState("AgentRole")
        End Get
        Set(ByVal value As Integer)
            ViewState("AgentRole") = value
        End Set
    End Property
    Property AchievementValue() As String
        Get
            Return ViewState("AchievementValue")
        End Get
        Set(ByVal value As String)
            ViewState("AchievementValue") = value
        End Set
    End Property
    Property TargetValue() As String
        Get
            Return ViewState("TargetValue")
        End Get
        Set(ByVal value As String)
            ViewState("TargetValue") = value
        End Set
    End Property
    Property ReportStatus() As Integer
        Get
            Return ViewState("ReportStatus")
        End Get
        Set(ByVal value As Integer)
            ViewState("ReportStatus") = value
        End Set
    End Property
    Property AckStatus() As Integer
        Get
            Return ViewState("AckStatus")
        End Get
        Set(ByVal value As Integer)
            ViewState("AckStatus") = value
        End Set
    End Property
#End Region
#Region "---- Load ---"
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        HumanMessage.Style.Item("visibility") = "hidden"
        If Not IsPostBack Then
            If Request.QueryString("AgentId") = "" Or Request.QueryString("AgentId") Is Nothing Then
                Server.Transfer("default.aspx")
            End If
            UserID = Session("AgentId")
            PanelReports.Controls.Add(Common.GetMenu(Request.Url, UserID, Request.ApplicationPath))
            AgentRole = Request.QueryString("AgentRole")
            AgentId = Request.QueryString("AgentId")
            AgentCampaignId = Request.QueryString("CampId")
            ReportStatus = Request.QueryString("page")
            ProcessId = Request.QueryString("ProcessId")



            If Request.QueryString("page") = 1 Then
                ReportQueryString()
                GetAgentDetail()
                GetPreviousFillData()
                BindKPA()
                BindCommonCDP()
                BindCommonKPA()
                btnBack.Visible = True

                QueryStrings()

            ElseIf Request.QueryString("page") = 2 Then
                ReportQueryString1()
                GetAgentDetail()
                GetPreviousFillData()
                BindKPA()
                BindCommonCDP()
                BindCommonKPA()
                btnBack.Visible = True
                lblMonth.Text = DateTime.Now.AddMonths(-1).ToString("MMMM")
                If (DateTime.Now.Month.ToString() = "1") Then
                    lblyear.Text = Convert.ToDateTime(DateTime.Now.AddYears(-1).ToString()).Year.ToString()
                Else
                    lblyear.Text = DateTime.Now.Year.ToString()
                End If
                Else
                    GetAgentDetail()
                    GetCurrentDate()
                    QueryStrings()
                    BindCommonCDP()
                    BindCommonKPA()
                End If
        End If
    End Sub
#End Region

#Region "--- EVENT ----"
    Protected Sub btnSave_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnSave.Click
        'SaveMPR()
        SaveMPR_NEW(1)
    End Sub
    Protected Sub btnFreeze_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnFreeze.Click
        SaveMPR_NEW(2)
    End Sub
    Protected Sub btnClose_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnClose.Click
        'Response.Redirect("Default.aspx")
        Response.Redirect("../../Data/^Sitemap")
    End Sub
    Protected Sub btnBack_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnBack.Click
        Response.Redirect("viewMPR.aspx?Process=" & Request.QueryString("ProcessId") & "&Month=" & lblMonth.Text & "&Year=" & lblyear.Text & "&back=1")
    End Sub



    Protected Sub btnUpload_Click(ByVal sender As Object, ByVal e As ImageClickEventArgs) Handles btnUpLoad.Click


        Dim FileName As String = String.Empty
        Dim FileSize As String = String.Empty
        Dim extension As String = String.Empty
        Dim FilePath As String = String.Empty

        If (FileUpload1.HasFile) Then

            Dim contentType As String = FileUpload1.PostedFile.ContentType
            extension = Path.GetExtension(FileUpload1.FileName)

            FileName = Path.GetFileName(FileUpload1.PostedFile.FileName)
            FileSize = FileName.Length.ToString() + " Bytes"
            FileUpload1.PostedFile.SaveAs(Server.MapPath("~/myupload/" + FileName.Trim()))
            FilePath = "~/myupload/" + FileName.Trim().ToString()



            Using fs As Stream = FileUpload1.PostedFile.InputStream
                Using br As BinaryReader = New BinaryReader(fs)

                    Dim bytes As Byte() = br.ReadBytes(Convert.ToInt32(fs.Length))

                    Dim db As New DBAccess("CRM")

                    db.slDataAdd("Name", FileName)
                    db.slDataAdd("ContentType", contentType)
                    db.slDataAdd("Data", bytes)
                    db.slDataAdd("FormID", FormId)
                    db.Executeproc("[usp_Save_MPR_Form_Attachments]")
                    db = Nothing

                    If System.IO.File.Exists(FilePath) Then
                        System.IO.File.Delete(FilePath)
                    End If


                End Using


            End Using


        Else

            Label1.Text = "No File Uploaded"





        End If

        ' Response.Redirect(Request.Url.AbsoluteUri)
    End Sub
#End Region

    Protected Sub btnAttach_Click(sender As Object, e As EventArgs) Handles btnAttach.Click
        Try


            Dim db As New DBAccess("CRM")




            Dim dt1 As New DataTable
            db.slDataAdd("FormID", FormId)
            dt1 = db.ReturnTable("[usp_Get_MPR_Form_Attachments]", , True)


            If dt1.Rows.Count > 0 Then

              
                    GridView1.DataSource = dt1
                    GridView1.DataBind()



              
            End If
            OpenDialog()

        Catch ex As Exception
            'AlertMessage("Error in PopulateGridView. description :- " & ex.Message)
            Throw ex
        End Try
    End Sub


    Private Sub OpenDialog()
        Dim str As String
        str = "$('#DialogBackground').height($(document).height()-2);$('#DialogBackground').width($(window).width());$('#DialogBackground').css('visibility','visible');$('#PnlAttachFormAdd').css('visibility','visible'); $('#PnlAttachFormAdd').css('left',($(window).width() - $('#PnlAttachFormAdd').width())/2); "
        ScriptManager.RegisterStartupScript(Page, Page.GetType(), "Movedialog", str, True)
    End Sub

#Region "---- FUNCTION ----"
    Private Sub GetCurrentDate()
        Dim db As New DBAccess
        Dim currentdatetime As DateTime = db.ReturnValue("select getdate()", False)
        db = Nothing

        ' @previous month July 2020
        'lblMonth.Text = currentdatetime.AddMonths(-2).ToString("MMMM")
        'lblyear.Text = currentdatetime.AddMonths(-2).Year.ToString
        'Dim startdt As DateTime = DateTime.Parse(currentdatetime.AddMonths(-2).Year.ToString & "-" & currentdatetime.AddMonths(-2).ToString("MMM") & "-" & "01")
        'Dim enddt As DateTime = startdt.AddMonths(1).AddDays(-1)


        '@Current Month August 2020
        lblMonth.Text = currentdatetime.AddMonths(-1).ToString("MMMM")
        lblyear.Text = currentdatetime.AddMonths(-1).Year.ToString
        Dim startdt As DateTime = DateTime.Parse(currentdatetime.AddMonths(-1).Year.ToString & "-" & currentdatetime.AddMonths(-1).ToString("MMM") & "-" & "01")
        Dim enddt As DateTime = startdt.AddMonths(1).AddDays(-1)


        StartDate = startdt.ToString("yyyyMMdd")
        EndDate = enddt.ToString("yyyyMMdd")

    End Sub
    Protected Sub QueryStrings()
        Dim dt As DataTable
        Dim db As New DBAccess("CRM")
        'Dim db As New DBAccess
        Dim str As String
        str = "select FormStatus,formId from tbl_Data_MPR_FormMaster where agentid='" & AgentId & "' and Period='" & lblMonth.Text & "'"
        str += " and Year='" & lblyear.Text & "' and processid='" & ProcessId & "'"
        dt = db.ReturnTable(str, False)
        If dt.Rows.Count > 0 Then
            Status = dt.Rows(0).Item("FormStatus")
            FormId = dt.Rows(0).Item("formId")
            GetPreviousFillData()
        Else
            Status = 0
            FormId = 0

            '@Previous month July 2020
            'lblMonth.Text = Date.Today.AddMonths(-2).ToString("MMMM")

            '@Current Month Aug 2020
            lblMonth.Text = Date.Today.AddMonths(-1).ToString("MMMM")

            BindKPA()
        End If
    End Sub
    Protected Sub BindKPA()
        Dim db As New DBAccess("CRM")
        'Dim db As New DBAccess
        Dim dt As New DataTable
        gvMPR.BackImageUrl = ""
        gvMPR.Enabled = True

        db.slDataAdd("Agentid", AgentId)
        db.slDataAdd("AgentRole", AgentRole)
        db.slDataAdd("processid", ProcessId)
        db.slDataAdd("UserId", UserID)
        db.slDataAdd("Month", lblMonth.Text.Trim)
        db.slDataAdd("year", Convert.ToInt32(lblyear.Text.Trim))
        dt = db.ReturnTable("usp_getKPA", , True)
        db = Nothing
        If dt.Rows.Count > 0 Then
            gvMPR.DataSource = dt
            gvMPR.DataBind()
        Else
            gvMPR.DataSource = Nothing
            gvMPR.DataBind()
            'txtAchievSumary.Text = ""
            'txtRptMgrCmnts.Text = ""
        End If

        dt = Nothing
    End Sub
    Protected Sub GetAgentDetail()
        Dim db As New DBAccess("report")
        Dim dt As New DataTable
        db.slDataAdd("Agentid", AgentId)
        dt = db.ReturnTable("usp_GetAgentDetails", "", True)
        If dt.Rows.Count > 0 Then
            'CboProcess.SelectedValue = dt.Rows(0)("ProcessID").ToString
            lblAgentId.Text = dt.Rows(0)("AgentID")
            lblAgentName.Text = dt.Rows(0)("AgentName")
            LblAgentRole.Text = dt.Rows(0)("Role")
            lblSupId.Text = dt.Rows(0)("SupervisorID")
            lblSupName.Text = dt.Rows(0)("SupervisorName")
            lblProcess.Text = dt.Rows(0)("ProcessName")
            'CboProcess.SelectedValue = dt.Rows(0)("ProcessID")
            ProcessId = dt.Rows(0)("ProcessID")
            AgentCampaignId = dt.Rows(0)("CampaignID")
            Session("MPRAgentID") = lblAgentId.Text
            dt = Nothing
        End If
    End Sub



    
    Private Function FreezeMPRBySupervisor_Mail() As Boolean
        Try
            'http://del-ggn-web1/MailService2/Service1.asmx
            'Dim objWSMail As New MailSendServiceXX.Service1SoapClient
            '


            'http://del-ggn-web1/mailservice1/Service1.asmx
            'Dim objWSMail As New ServiceReference1.Service1SoapClient

            Dim strFrom As String = System.Configuration.ConfigurationManager.AppSettings("FROM")




            Dim strMailBody As String = ""
            Dim _index As Integer = 1



            Dim AgentName As String = ""
            Dim SupervisorName As String = ""

            Dim db As New DBAccess("CRM")
            Dim dt As New DataTable
            Dim sAgentEmailId As String = ""
            Dim sSupEmailId As String = ""
            dt = db.ReturnTable("select * from tbl_agentmaster where AgentID='" & lblAgentId.Text & "'", False)
            If dt.Rows.Count > 0 Then
                sAgentEmailId = dt.Rows(0)("LanID") + System.Configuration.ConfigurationManager.AppSettings("EmailidAT")
                dt = Nothing
            End If


            dt = db.ReturnTable("select * from tbl_agentmaster where AgentID='" & lblSupId.Text & "'", False)
            If dt.Rows.Count > 0 Then
                sSupEmailId = dt.Rows(0)("LanID") + System.Configuration.ConfigurationManager.AppSettings("EmailidAT")
                dt = Nothing
            End If


            Dim MailSubject As String = "MPR Freezed By (" & lblSupName.Text & ")" & "  For  " & "(" & lblAgentName.Text & ") " & " Period " & lblMonth.Text & "/" & lblyear.Text


            strMailBody += "<html xmlns='http://www.w3.org/1999/xhtml'>"
            strMailBody += "<body style='font-family: Verdana; font-size: .8em'>"
            strMailBody += "Hope you doing well !!:<br />"
            strMailBody += "MPR Form Filled.:<br /><br />"
            strMailBody += "Actions(Accept/Reject) required as soon as possible :<br /><br />"
            strMailBody += "<table border='1' width='90%' style='border: 1px solid; border-collapse: collapse; font-family: Verdana; font-size: .8em'>"
            strMailBody += "<tr bgcolor='#B8CCE4'>"
            strMailBody += "<td align='center'><b>Agent Name</b></td>"
            strMailBody += "<td align='center'><b>Supervisor Name</b></td>"
            strMailBody += "<td align='center'><b> Period </b></td>"
            strMailBody += "<td align='center'><b>Process</b></td>"
            strMailBody += "<td align='center'><b>Reporting Supervisor's Comments:</b></td>"
            strMailBody += "<td align='center'><b>Action Plan For Next Month:</b></td>"
            strMailBody += "</tr>"
            strMailBody += "<tr >"
            strMailBody += "<td align='center'>" & lblAgentName.Text & "</td>"
            strMailBody += "<td align='center'>" & lblSupName.Text & "</td>"
            strMailBody += "<td align='center'>" & lblMonth.Text & " " & lblyear.Text & "</td>"
            strMailBody += "<td align='center'>" & lblProcess.Text & "</td>"
            strMailBody += "<td align='center'>" & txtAchievSumary.Text & "</td>"
            strMailBody += "<td align='center'>" & txtRptMgrCmnts.Text & "</td>"
            strMailBody += "</tr>"
            strMailBody += "</table>"

            strMailBody += "<br /><br />"

            strMailBody += "<p>"
            strMailBody += "Thank You."
            strMailBody += "</p>"



            strMailBody += "</body>"
            strMailBody += "</html>"




            ''Dev One
            ' objWSMail.MailSendNewTech(System.Configuration.ConfigurationManager.AppSettings("WSR_PIP_ProcessManager"), MailSubject, "MPR Acceptance Form  <" & strFrom & ">", "", strMailBody.ToString(), "", sAgentEmailId, System.Configuration.ConfigurationManager.AppSettings("BCC"), "") '' Final
            'objWSMail.MailSendNew(System.Configuration.ConfigurationManager.AppSettings("WSR_PIP_ProcessManager"), MailSubject, "MPR Acceptance Form <" & strFrom & ">", "TermsMonitor", strMailBody.ToString(), "", sAgentEmailId, System.Configuration.ConfigurationManager.AppSettings("WSR_PIP_ProcessManager"), "") ''26Feb2018
            ' Common.SMTPSendMail(System.Configuration.ConfigurationManager.AppSettings("WSR_PIP_ProcessManager") + "," + System.Configuration.ConfigurationManager.AppSettings("WSR_PIP_ProcessManager"), MailSubject, "MPR Acceptance Form <" & strFrom & ">", strMailBody.ToString(), sAgentEmailId, System.Configuration.ConfigurationManager.AppSettings("WSR_PIP_ProcessManager"))

            ''Live One
            ' objWSMail.MailSendNewTech(sAgentEmailId, MailSubject, "MPR Acceptance Form <" & strFrom & ">", "", strMailBody.ToString(), "", sSupEmailId, System.Configuration.ConfigurationManager.AppSettings("WSR_PIP_ProcessManager"), "") '' Final
            'objWSMail.MailSendNew(sAgentEmailId, MailSubject, "MPR Acceptance Form <" & strFrom & ">", "TermsMonitor", strMailBody.ToString(), "", sSupEmailId, System.Configuration.ConfigurationManager.AppSettings("WSR_PIP_ProcessManager"), "") ''26Feb2018
            Common.SMTPSendMail(sAgentEmailId, MailSubject, "MPR Acceptance Form <" & strFrom & ">", strMailBody.ToString(), sSupEmailId, System.Configuration.ConfigurationManager.AppSettings("WSR_PIP_ProcessManager"))

            'objWSMail = Nothing

            Return True
        Catch ex As Exception
            '  AlertMessage("Error in sendPIPIssuedMailToHR. description :- " & ex.Message)
            Return False
        End Try
    End Function


    Protected Sub GetPreviousFillData()
        Dim db As New DBAccess("CRM")
        Dim dt As New DataTable
        Dim strQuery As String = "Select * from tbl_Data_MPR_FormMaster where Agentid='" & AgentId & "' and Period='" & lblMonth.Text & "' and [year]=" & lblyear.Text & " and processid='" & ProcessId & "'"
        dt = db.ReturnTable(strQuery, False)
        If dt.Rows.Count > 0 Then
            txtAchievSumary.Text = dt.Rows(0)("AchievementSummary").ToString
            txtRptMgrCmnts.Text = dt.Rows(0)("RepMgrComments").ToString
            txtTMComments.Text = dt.Rows(0)("TMComment").ToString
            ProcessId = dt.Rows(0)("ProcessId").ToString
            AckStatus = dt.Rows(0)("AcknowledgmentStatus").ToString
            AgentRole = dt.Rows(0).Item("AgentRole")
        End If
        dt = Nothing
        db = Nothing
        Dim dbData As New DBAccess("CRM")
        Dim dtfrmData As New DataTable
        dbData.slDataAdd("Agentid", AgentId)
        dbData.slDataAdd("AgentRole", AgentRole)
        dbData.slDataAdd("processid", ProcessId)
        dbData.slDataAdd("UserId", UserID)
        dbData.slDataAdd("Month", lblMonth.Text.Trim)
        dbData.slDataAdd("year", Convert.ToInt32(lblyear.Text.Trim))
        dtfrmData = dbData.ReturnTable("usp_getKPA", , True)
        dbData = Nothing
        If dtfrmData.Rows.Count > 0 Then
            gvMPR.DataSource = dtfrmData
            gvMPR.DataBind()
        Else
            gvMPR.DataSource = Nothing
            gvMPR.DataBind()
            'txtAchievSumary.Text = ""
            'txtRptMgrCmnts.Text = ""
        End If
        If AckStatus = 1 Then
            lblStatus.Text = "Accepted"
            imgStatus.ImageUrl = "~/_assets/img/green.gif"
            btnSave.Enabled = False
        ElseIf AckStatus = 2 Then
            lblStatus.Text = "Rejected"
            imgStatus.ImageUrl = "~/_assets/img/remove.gif"
        Else
            lblStatus.Text = "Pending"
            imgStatus.ImageUrl = "~/_assets/img/why.gif"
        End If
    End Sub
    ''' <summary>
    ''' ' Get Common CDP trainig Data
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub BindCommonCDP()
        Dim db As New DBAccess("CRM")
        'Dim db As New DBAccess
        Dim dt As New DataTable
        db.slDataAdd("AgentId", AgentId)
        db.slDataAdd("AgentRole", AgentRole)
        db.slDataAdd("processid", ProcessId)
        db.slDataAdd("campaignid", AgentCampaignId)
        db.slDataAdd("Month", lblMonth.Text.Trim)
        db.slDataAdd("year", Convert.ToInt32(lblyear.Text.Trim))
        dt = db.ReturnTable("usp_GetCommonCDP", , True)

        GVCDP.DataSource = dt
        GVCDP.DataBind()
    End Sub
    Private Sub BindCommonKPA()
        Dim db As New DBAccess("CRM")
        'Dim db As New DBAccess
        Dim dt As New DataTable
        db.slDataAdd("AgentId", AgentId)
        db.slDataAdd("AgentRole", AgentRole)
        db.slDataAdd("processid", ProcessId)
        '
        db.slDataAdd("campaignid", AgentCampaignId)
        db.slDataAdd("Month", lblMonth.Text.Trim)
        db.slDataAdd("year", Convert.ToInt32(lblyear.Text.Trim))
        dt = db.ReturnTable("usp_GetCommonKPA", , True)

        Dim dtrow() As DataRow
        dtrow = dt.Select("CmKPAID IN(9,10,11)")
        Dim Alert = "", Pip = "", Verbal As String = ""
        If dtrow.Length > 0 Then
            Alert = dtrow(0).Item("Achievement")
            Pip = dtrow(1).Item("Achievement")
            ' Verbal = dtrow(2).Item("Achievement")
            txtAlertRemarks.Text = dtrow(0).Item("Remarks")
            txtPipRemarks.Text = dtrow(1).Item("Remarks")
            ' txtverbalRemarks.Text = dtrow(2).Item("Remarks")
        End If

        If Alert.Trim <> "" Then
            If Alert = 1 Then
                rdbYes.Checked = True
            ElseIf Alert = 2 Then
                rdbNo.Checked = True
            Else
                rdbYes.Checked = False
                rdbNo.Checked = False
            End If
        End If
        If Pip.Trim <> "" Then
            If Pip = 1 Then
                rdbpipYes.Checked = True
            ElseIf Pip = 2 Then
                rdbpipNo.Checked = True
            Else
                rdbpipYes.Checked = False
                rdbpipNo.Checked = False
            End If
        End If
        If Verbal.Trim <> "" Then
            If Verbal = 1 Then
                rdbVerbalYes.Checked = True
            ElseIf Verbal = 2 Then
                rdbVerbalNo.Checked = True
            Else
                rdbVerbalYes.Checked = False
                rdbVerbalNo.Checked = False
            End If
        End If

        Dim i As Integer = 0
        For i = 0 To dtrow.Length - 1
            dt.Rows.Remove(dtrow(i))
        Next

        db = Nothing
        gvCommonKPA.DataSource = dt
        gvCommonKPA.DataBind()
    End Sub
    ''' <summary>
    ''' 
    ''' </summary>
    ''' <param name="db"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function SaveCommonCDP(ByRef db As DBAccess) As Boolean
        For Each gvr As GridViewRow In GVCDP.Rows
            Dim Training As String = ""
            db.slDataAdd("AgentID", lblAgentId.Text)
            db.slDataAdd("Period", lblMonth.Text)
            db.slDataAdd("Year", lblyear.Text)
            db.slDataAdd("ProcessId", ProcessId)
            db.slDataAdd("CampaignId", AgentCampaignId)
            db.slDataAdd("CmCDPID", CType(gvr.FindControl("lblcmCDPId"), Label).Text)
            If CType(gvr.FindControl("rdbcompleted"), RadioButton).Checked = True Then
                Training = 1
            ElseIf CType(gvr.FindControl("rdbinprocess"), RadioButton).Checked = True Then
                Training = 2
            ElseIf CType(gvr.FindControl("rdbnotdone"), RadioButton).Checked = True Then
                Training = 3
            End If
            If Not Training = "" Then
                db.slDataAdd("Training", Training)
            Else
                Return False
            End If
            db.slDataAdd("Remarks", CType(gvr.FindControl("txtRemarks"), TextBox).Text)
            db.Executeproc("usp_SaveCommonCDP")
        Next
        Return True
    End Function

    Private Function SaveCommonKPA(ByRef db As DBAccess) As Boolean
        For Each gvr As GridViewRow In gvCommonKPA.Rows
            Dim Achievement As String = ""
            db.slDataAdd("AgentID", lblAgentId.Text)
            db.slDataAdd("Period", lblMonth.Text)
            db.slDataAdd("Year", lblyear.Text)
            db.slDataAdd("ProcessId", ProcessId)
            db.slDataAdd("CampaignId", AgentCampaignId)
            db.slDataAdd("CmKPAID", CType(gvr.FindControl("lblcmId"), Label).Text)
            If CType(gvr.FindControl("rdbcmNA"), RadioButton).Checked = True Then
                Achievement = 0
            ElseIf CType(gvr.FindControl("rdbcm1"), RadioButton).Checked = True Then
                Achievement = 1
            ElseIf CType(gvr.FindControl("rdbcm2"), RadioButton).Checked = True Then
                Achievement = 2
            ElseIf CType(gvr.FindControl("rdbcm3"), RadioButton).Checked = True Then
                Achievement = 3
            ElseIf CType(gvr.FindControl("rdbcm4"), RadioButton).Checked = True Then
                Achievement = 4
            End If
            If Not Achievement = "" Then
                db.slDataAdd("Achievement", Achievement)
            Else
                Return False
            End If
            db.slDataAdd("Remarks", CType(gvr.FindControl("txtRemarks"), TextBox).Text)
            db.Executeproc("usp_SaveCommonKPA")
        Next
        '===================== For Alert Trackers / PIP / Verbal Warning KPA.
        Dim performance As String = ""
        Dim i As Integer = 9
        For i = 9 To 11
            db.slDataAdd("AgentID", lblAgentId.Text)
            db.slDataAdd("Period", lblMonth.Text)
            db.slDataAdd("Year", lblyear.Text)
            db.slDataAdd("ProcessId", ProcessId)
            db.slDataAdd("CampaignId", AgentCampaignId)
            db.slDataAdd("CmKPAID", i)
            If i = 9 Then
                If rdbNo.Checked = True Then
                    performance = 2
                ElseIf rdbYes.Checked = True Then
                    performance = 1
                Else
                    Return False
                End If
            ElseIf i = 10 Then
                If rdbpipNo.Checked = True Then
                    performance = 2
                ElseIf rdbpipYes.Checked = True Then
                    performance = 1
                Else
                    Return False
                End If
            ElseIf i = 11 Then
                If rdbVerbalNo.Checked = True Then
                    performance = 2
                ElseIf rdbVerbalYes.Checked = True Then
                    performance = 1
                Else
                    Return False
                End If
            End If

            If Not performance = "" Then
                db.slDataAdd("Achievement", performance)
            Else
                Return False
            End If
            db.slDataAdd("Remarks", txtAlertRemarks.Text)
            db.Executeproc("usp_SaveCommonKPA")
        Next
        Return True
        '==========================       
    End Function
    Private Sub SaveMPR_NEW(ByVal frmStatus As Integer)
        Dim db As New DBAccess("CRM")
        Dim FrmID As String
        Try
            db.BeginTrans()
            db.slDataAdd("AgentID", lblAgentId.Text.Trim)
            db.slDataAdd("Period", lblMonth.Text.Trim)
            db.slDataAdd("Year", Convert.ToInt32(lblyear.Text.Trim))
            db.slDataAdd("RepMgrId", lblSupId.Text)
            db.slDataAdd("FormStatus", frmStatus)
            db.slDataAdd("FilledBy", UserID)
            db.slDataAdd("UpdateBy", UserID)
            db.slDataAdd("AchievementSummary", txtAchievSumary.Text)
            db.slDataAdd("RepMgrComments", txtRptMgrCmnts.Text)
            db.slDataAdd("ProcessId", ProcessId)
            db.slDataAdd("CampaignId", AgentCampaignId)
            db.slDataAdd("AgentRole", AgentRole)
            'db.slDataAdd("TMComment", txtTMComments.Text.Trim)
            FrmID = db.ReturnValue("usp_SaveMPR_New", True)

            For Each gvr As GridViewRow In gvMPR.Rows
                TargetValue = CType(gvr.FindControl("txtTarget"), TextBox).Text
                AchievementValue = CType(gvr.FindControl("txtAchieve"), TextBox).Text

                If CType(gvr.FindControl("txtAchieve"), TextBox).Enabled = True And CType(gvr.FindControl("txtAchieve"), TextBox).Text = "" Then
                    AlertMessage("Please enter the Achievement for " & CType(gvr.FindControl("lblKPA"), Label).Text)
                    db.RollBackTrans()
                    db = Nothing
                    Exit Sub
                End If
                If CType(gvr.FindControl("txtTarget"), TextBox).Enabled = True And CType(gvr.FindControl("txtTarget"), TextBox).Text = "" Then
                    AlertMessage("Please enter the Target for " & CType(gvr.FindControl("lblKPA"), Label).Text)
                    db.RollBackTrans()
                    db = Nothing
                    Exit Sub
                End If
                '@2022-01-31 Commented as Keshav Request
                ''If CType(gvr.FindControl("txtTarget"), TextBox).Enabled = True And CType(gvr.FindControl("txtTarget"), TextBox).Text <> "" Then
                ''    'If Not IsNumeric(txtTarget.Text) Then
                ''    If Not IsNumeric(TargetValue) Then
                ''        AlertMessage("Target should be numeric for " & CType(gvr.FindControl("lblKPA"), Label).Text)
                ''        db.RollBackTrans()
                ''        db = Nothing
                ''        Exit Sub
                ''    End If
                ''    If TargetValue.Contains(",") Then
                ''        AlertMessage("Target should be numeric for " & CType(gvr.FindControl("lblKPA"), Label).Text)
                ''        db.RollBackTrans()
                ''        db = Nothing
                ''        Exit Sub
                ''    End If
                ''    If TargetValue.Contains("%") Then
                ''        AlertMessage("Target should be numeric for " & CType(gvr.FindControl("lblKPA"), Label).Text)
                ''        db.RollBackTrans()
                ''        db = Nothing
                ''        Exit Sub
                ''    End If
                ''End If
                ''If CType(gvr.FindControl("txtAchieve"), TextBox).Enabled = True Then
                ''    'If Not IsNumeric(txtAchievement.Text) Then
                ''    If Not IsNumeric(AchievementValue) Then
                ''        AlertMessage("Achievement should be numeric for " & CType(gvr.FindControl("lblKPA"), Label).Text)
                ''        db.RollBackTrans()
                ''        db = Nothing
                ''        Exit Sub
                ''    End If
                ''    If AchievementValue.Contains(",") Then
                ''        AlertMessage("Achievement should be numeric for " & CType(gvr.FindControl("lblKPA"), Label).Text)
                ''        db.RollBackTrans()
                ''        db = Nothing
                ''        Exit Sub
                ''    End If
                ''    If AchievementValue.Contains("%") Then
                ''        AlertMessage("Achievement should be numeric for " & CType(gvr.FindControl("lblKPA"), Label).Text)
                ''        db.RollBackTrans()
                ''        db = Nothing
                ''        Exit Sub
                ''    End If
                ''End If
                db.slDataAdd("KpaID", CType(gvr.FindControl("lblId"), Label).Text)
                db.slDataAdd("Target", CType(gvr.FindControl("txtTarget"), TextBox).Text)
                db.slDataAdd("Achievement", CType(gvr.FindControl("txtAchieve"), TextBox).Text)
                db.slDataAdd("FormID", FrmID)
                db.slDataAdd("ProcessId", ProcessId)
                db.slDataAdd("CampaignId", AgentCampaignId)
                db.slDataAdd("MgrComments", CType(gvr.FindControl("txtMeasurement"), TextBox).Text)
                db.Executeproc("usp_SaveMPR_FormData")

            Next

            db.CommitTrans()

            db = New DBAccess("CRM")
            db.BeginTrans()
            If SaveCommonCDP(db) Then
                db.CommitTrans()
                'SuccessMessage("MPR has been saved for " & AgentId)
            Else
                db.RollBackTrans()
                AlertMessage("All CIDP Training are mandatory")
                Return
            End If


            db = New DBAccess("CRM")
            db.BeginTrans()
            If SaveCommonKPA(db) Then
                db.CommitTrans()
                ' SuccessMessage("MPR has been saved for " & AgentId)
            Else
                db.RollBackTrans()
                AlertMessage("All performance drivers are mandatory")
                Return
            End If


            If frmStatus = 1 Then

                SuccessMessage("MPR has been saved for " & lblAgentName.Text)
            ElseIf frmStatus = 2 Then
                SuccessMessage("MPR has been Freezed  for " & lblAgentName.Text)
                FreezeMPRBySupervisor_Mail()
            End If



        Catch ex As Exception
            db.RollBackTrans()
            AlertMessage("All performance drivers are mandatory")
            Return
        Finally
            db = Nothing
        End Try
        ' Response.Redirect("Default.aspx")
    End Sub
    Private Sub ReportQueryString()
        CampaignId = Request.QueryString("CampId")
        lblMonth.Text = Request.QueryString("Month")
        lblyear.Text = Request.QueryString("Year")
        'AgentId = Request.QueryString("AgentId")

        btnSave.Visible = False
        txtTMComments.Enabled = False
    End Sub

    Private Sub ReportQueryString1()
        CampaignId = Request.QueryString("CampId")
        'lblMonth.Text = Request.QueryString("Month")
        'lblyear.Text = Request.QueryString("Year")

        'lblMonth.Text = DateTime.Now.AddMonths(-2).ToString("MMMM")
        'lblyear.Text = DateTime.Now.Year().ToString()



        If ((DateTime.Now.Month.ToString() = "1") Or (DateTime.Now.Month.ToString() = "2")) Then

            lblMonth.Text = DateTime.Now.AddMonths(-2).ToString("MMMM")
            lblyear.Text = Convert.ToDateTime(DateTime.Now.AddYears(-1).ToString()).Year.ToString()

        Else


            lblMonth.Text = DateTime.Now.AddMonths(-2).ToString("MMMM")
            lblyear.Text = DateTime.Now.Year().ToString()

        End If

        'AgentId = Request.QueryString("AgentId")
        btnSave.Visible = True
        txtTMComments.Enabled = True
    End Sub
#End Region
#Region "---- Grid Ops ----"
    Protected Sub gvMPR_RowDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles gvMPR.RowDataBound
        If ReportStatus = 1 Then
            gvMPR.Enabled = False
            gvCommonKPA.BackImageUrl = "~/_assets/img/Frozen.JPG"
            gvCommonKPA.Enabled = False
            GVCDP.Enabled = False
            lblAlert.Enabled = False
            lblVerbal.Enabled = False
            lblpip.Enabled = False
            txtAlertRemarks.Enabled = False
            txtPipRemarks.Enabled = False
            txtverbalRemarks.Enabled = False
            rdbNo.Enabled = False
            rdbYes.Enabled = False
            rdbpipNo.Enabled = False
            rdbpipYes.Enabled = False
            rdbVerbalNo.Enabled = False
            rdbVerbalYes.Enabled = False
            txtAchievSumary.Enabled = False
            txtRptMgrCmnts.Enabled = False
            btnSave.Visible = False
            btnFreeze.Visible = False
            hpAddKPA.Visible = False
            lblStatus.Visible = True
            imgStatus.Visible = True
            lblAcceptance.Visible = True
            btnClose.Visible = False
        Else
            If Status = 0 Then
                Dim dt As New DataTable
                If e.Row.RowType = DataControlRowType.DataRow Then
                    If CType(e.Row.FindControl("lblformula"), Label).Text = "" Then
                        CType(e.Row.FindControl("txtAchieve"), TextBox).Enabled = True
                    Else
                        CType(e.Row.FindControl("txtAchieve"), TextBox).Enabled = True
                        'CType(e.Row.FindControl("txtAchieve"), TextBox).Enabled = False
                    End If
                    CType(e.Row.FindControl("txtTarget"), TextBox).Enabled = True
                End If
                txtAchievSumary.Enabled = True
                txtRptMgrCmnts.Enabled = True
                btnSave.Enabled = True
                lblStatus.Visible = False
                imgStatus.Visible = False
                btnBack.Visible = False
                lblAcceptance.Visible = False
            ElseIf Status = 1 Then
                If e.Row.RowType = DataControlRowType.DataRow Then
                    If CType(e.Row.FindControl("lblformula"), Label).Text = "" Then
                        CType(e.Row.FindControl("txtAchieve"), TextBox).Enabled = True
                    Else
                        CType(e.Row.FindControl("txtAchieve"), TextBox).Enabled = True
                        'CType(e.Row.FindControl("txtAchieve"), TextBox).Enabled = False
                    End If
                    CType(e.Row.FindControl("txtTarget"), TextBox).Enabled = True
                End If
                txtAchievSumary.Enabled = True
                txtRptMgrCmnts.Enabled = True
                btnSave.Enabled = True
                lblStatus.Visible = False
                imgStatus.Visible = False
                btnBack.Visible = False
                lblAcceptance.Visible = False
            ElseIf Status = 2 Then
                gvMPR.Enabled = False
                gvCommonKPA.BackImageUrl = "~/_assets/img/Frozen.JPG"
                gvCommonKPA.Enabled = False
                GVCDP.Enabled = False
                lblAlert.Enabled = False
                lblVerbal.Enabled = False
                lblpip.Enabled = False
                txtAlertRemarks.Enabled = False
                txtPipRemarks.Enabled = False
                txtverbalRemarks.Enabled = False
                rdbNo.Enabled = False
                rdbYes.Enabled = False
                rdbpipNo.Enabled = False
                rdbpipYes.Enabled = False
                rdbVerbalNo.Enabled = False
                rdbVerbalYes.Enabled = False
                txtAchievSumary.Enabled = False
                txtRptMgrCmnts.Enabled = False
                btnSave.Visible = False
                btnFreeze.Visible = False
                hpAddKPA.Visible = False
                lblStatus.Visible = True
                imgStatus.Visible = True
                btnBack.Visible = False
                lblAcceptance.Visible = True
            End If
        End If
    End Sub
    Protected Sub ImageButton1_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton1.Click


        Dim filePath As String = Server.MapPath("~\\myupload\\" & "Training list.xlsx")
        Dim filename As String = Path.GetFileName(filePath)
        Dim fs As FileStream = New FileStream(filePath, FileMode.Open, FileAccess.Read)
        Dim br As BinaryReader = New BinaryReader(fs)
        Dim bytes As Byte() = br.ReadBytes(CType(fs.Length, Int32))
        br.Close()
        Response.Clear()
        Response.AddHeader("Content-Disposition", "inline;filename=Book1.xlsx")
        Response.ContentType = "application/vnd.ms-excel"
        Response.WriteFile(filePath)
        fs.Close()
        Response.[End]()


    End Sub
    Protected Sub gvCommonKPA_RowDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles gvCommonKPA.RowDataBound
        If e.Row.RowType = DataControlRowType.DataRow Then
            Dim rating As String = gvCommonKPA.DataKeys(e.Row.RowIndex).Item("Achievement").ToString
            CType(e.Row.FindControl("txtRemarks"), TextBox).Text = gvCommonKPA.DataKeys(e.Row.RowIndex).Item("Remarks").ToString
            If rating = "0" Then
                CType(e.Row.FindControl("rdbcmNA"), RadioButton).Checked = True
            ElseIf rating = "1" Then
                CType(e.Row.FindControl("rdbcm1"), RadioButton).Checked = True
            ElseIf rating = "2" Then
                CType(e.Row.FindControl("rdbcm2"), RadioButton).Checked = True
            ElseIf rating = "3" Then
                CType(e.Row.FindControl("rdbcm3"), RadioButton).Checked = True
            ElseIf rating = "4" Then
                CType(e.Row.FindControl("rdbcm4"), RadioButton).Checked = True
            End If
        End If
    End Sub

    Protected Sub GVCDP_RowDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles GVCDP.RowDataBound
        If e.Row.RowType = DataControlRowType.DataRow Then
            Dim rating As String = GVCDP.DataKeys(e.Row.RowIndex).Item("Training").ToString
            CType(e.Row.FindControl("txtRemarks"), TextBox).Text = GVCDP.DataKeys(e.Row.RowIndex).Item("Remarks").ToString
            If rating = "1" Then
                CType(e.Row.FindControl("rdbcompleted"), RadioButton).Checked = True
            ElseIf rating = "2" Then
                CType(e.Row.FindControl("rdbinprocess"), RadioButton).Checked = True
            ElseIf rating = "3" Then
                CType(e.Row.FindControl("rdbnotdone"), RadioButton).Checked = True

            End If
        End If
    End Sub
#End Region
#Region "---- Utility ----"
    Private Sub AlertMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMFail"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub
    Private Sub SuccessMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMSuccess"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub
    Public Overrides Sub VerifyRenderingInServerForm(ByVal Control As Control)
    End Sub
#End Region

    Protected Sub GridView1_RowCommand(sender As Object, e As GridViewCommandEventArgs) Handles GridView1.RowCommand
        Try
            If e.CommandName.ToLower = "download" Then
                Dim index As Integer = Convert.ToInt32(e.CommandArgument)

                Dim db As DBAccess = New DBAccess("CRM")

                DownloadFile(index)

            ElseIf e.CommandName.ToLower = "delete" Then

                Dim index As Integer = Convert.ToInt32(e.CommandArgument)
                DeleteFile(index)
                Dim db As DBAccess = New DBAccess("CRM")
                db.slDataAdd("FormID", CType(GridView1.Rows(index).FindControl("lblForm_Id"), Literal).Text)
                Dim dt As DataTable = db.ReturnTable("[usp_Get_MPR_Form_Attachments]")
                db = Nothing

                GridView1.DataSource = dt
                GridView1.DataBind()


            End If
        Catch ex As Exception
            AlertMessage(ex.Message)
        End Try

    End Sub

    Protected Sub DownloadFile(ByVal ID As Integer)


        Try
            Dim fileName As String = "", contentType As String = ""
            Dim bytes As Byte()
            Dim db As DBAccess
            Dim dt As DataTable
            db = New DBAccess("CRM")
            db.slDataAdd("Id", ID)
            dt = db.ReturnTable("[usp_Get_MPR_Form_Attachment]", "", True)
            db = Nothing
            If dt.Rows.Count > 0 Then
                bytes = DirectCast(dt.Rows.Item(0)("Data"), Byte())
                contentType = dt.Rows.Item(0)("ContentType").ToString()
                fileName = dt.Rows.Item(0)("Name").ToString()
            End If
            Response.Clear()
            Response.Buffer = True
            Response.Charset = ""
            Response.Cache.SetCacheability(HttpCacheability.NoCache)
            Response.ContentType = contentType
            Response.AppendHeader("Content-Disposition", "attachment; filename=" + fileName)
            Response.BinaryWrite(bytes)
            Response.Flush()
            Response.End()
        Catch ex As Exception
            AlertMessage(ex.Message)
        End Try

    End Sub


    Protected Sub DeleteFile(ByVal ID As Integer)




        Dim con As New SqlConnection(connCRM)
        Dim cmd As New SqlCommand("", con)
        con.Open()
        cmd.CommandText = "Delete from [tbl_Data_MPR_Attachments] where Id= " & ID
        cmd.CommandType = CommandType.Text
        cmd.ExecuteNonQuery()
        con.Close()

    End Sub





    Protected Sub btnUpload_Click1(sender As Object, e As EventArgs)
        Response.Redirect("Default.aspx")

    End Sub
End Class
