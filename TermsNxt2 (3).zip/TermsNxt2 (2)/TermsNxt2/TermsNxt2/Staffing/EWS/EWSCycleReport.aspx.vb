﻿Imports com.nss.DBAccess
Imports System.Data
Partial Class Staffing_EWS_EWSCycleReport
    Inherits System.Web.UI.Page
#Region "--- Properties ---"
    Property CampaignId() As String
        Get
            Return ViewState("CampaignId")
        End Get
        Set(ByVal value As String)
            ViewState("CampaignId") = value
        End Set
    End Property
    Property ProcessID() As String
        Get
            Return ViewState("ProcessID")
        End Get
        Set(ByVal value As String)
            ViewState("ProcessID") = value
        End Set
    End Property
    Property AgentID() As String
        Get
            Return ViewState("AgentID")
        End Get
        Set(ByVal value As String)
            ViewState("AgentID") = value
        End Set
    End Property
#End Region
#Region "--- Load ---"
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        HumanMessage.Style.Item("visibility") = "hidden"
        If Not IsPostBack Then
            AgentID = Session("AgentId")
            CampaignId = Session("CampaignId")
            FillProcessCampaigns()
            PanelReports.Controls.Add(Common.GetMenu(Request.Url, AgentID, Request.ApplicationPath))
            lblReportName.CurrentPage = "EWS Cycle Report"

        End If
        FillData()
    End Sub
    Private Sub FillProcessCampaigns()
        Common.FillProcesses(CboProcess, AgentID, 0)
        Dim lstprocess As New ListItem
        lstprocess.Value = 0
        lstprocess.Text = "All"
        If CboProcess.Items.Contains(lstprocess) Then
            CboProcess.Items.Remove(lstprocess)
        End If
    End Sub
#End Region
#Region "--- Functions ---"
    Private Sub FillData()
        Dim db As New DBAccess("CRM")
        Dim dt As DataTable
        Try
            db.slDataAdd("ProcessID", CboProcess.SelectedValue)
            dt = db.ReturnTable("usp_getEwsCycle", , True)
            db = Nothing
           
            gdEWSReport.DataSource = dt
            gdEWSReport.DataBind()
        Catch ex As Exception
            AlertMessage(ex.ToString)
        End Try
    End Sub
#End Region
#Region "--- Events ---"
    Protected Sub btnRefresh_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnRefresh.Click
        FillData()
    End Sub
    Protected Sub ImgExport_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImgExport.Click
        FillData()
        GridViewExportUtil.Export(lblReportName.CurrentPage & ".xls", Me.gdEWSReport)
    End Sub
    Protected Sub CboProcess_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles CboProcess.SelectedIndexChanged
        FillData()
    End Sub
#End Region
#Region "--- Utility ---"
    Private Sub AlertMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMFail"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub
    Private Sub SuccessMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMSuccess"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub
#End Region
    Protected Sub gdEWSReport_RowDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles gdEWSReport.RowDataBound
        Dim btnlink As LinkButton
        If e.Row.RowType = DataControlRowType.DataRow Then
            'If IsDate(e.Row.Cells(0).Text) Then
            '    e.Row.Cells(0).Text = String.Format("{0:d}", e.Row.Cells(0).Text)
            'End If
            btnlink = New LinkButton
            btnlink.Text = e.Row.Cells(0).Text
            AddHandler btnlink.Click, AddressOf Me.btnlink_OnClick
            e.Row.Cells(0).Controls.Add(btnlink)
        End If
    End Sub
    Public Sub btnlink_OnClick(ByVal sender As Object, ByVal e As EventArgs)

        Response.Redirect("EWSTrend.aspx?process=" & CboProcess.SelectedValue)

       
    End Sub
    Protected Sub gdEWSReport_RowCreated(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles gdEWSReport.RowCreated
        If e.Row.RowType = DataControlRowType.Header Then

            For i As Integer = 0 To e.Row.Cells.Count - 1
                If e.Row.Cells(i).Text.Contains(" cycle2") Then
                    e.Row.Cells(i).Text = e.Row.Cells(i).Text.Replace(" cycle2", "")
                ElseIf e.Row.Cells(i).Text.Contains(" cycle2") Then
                    e.Row.Cells(i).Text = e.Row.Cells(i).Text.Replace(" cycle3", "")
                ElseIf e.Row.Cells(i).Text.Contains(" cycle3") Then
                    e.Row.Cells(i).Text = e.Row.Cells(i).Text.Replace(" cycle3", "")
                End If
            Next

            Dim headerrow As GridViewRow = New GridViewRow(0, 0, DataControlRowType.Header, DataControlRowState.Insert)
            Dim cell_header As TableCell = New TableCell
            cell_header.Text = ""
            cell_header.HorizontalAlign = HorizontalAlign.Center
            cell_header.ColumnSpan = 1
            headerrow.Cells.Add(cell_header)
            cell_header = New TableCell
            cell_header.Text = "Last Cycle"
            cell_header.HorizontalAlign = HorizontalAlign.Center
            cell_header.ColumnSpan = 3
            cell_header.BorderStyle = BorderStyle.Solid
            cell_header.BorderWidth = 1
            cell_header.BorderColor = Drawing.Color.FromName("#bbd9ee")
            cell_header.Font.Bold = True
            headerrow.Cells.Add(cell_header)
            cell_header = New TableCell
            cell_header.Text = "Last 2 Cycles"
            cell_header.HorizontalAlign = HorizontalAlign.Center
            cell_header.ColumnSpan = 3
            cell_header.BorderStyle = BorderStyle.Solid
            cell_header.BorderWidth = 1
            cell_header.BorderColor = Drawing.Color.FromName("#bbd9ee")
            cell_header.Font.Bold = True
            headerrow.Cells.Add(cell_header)
            cell_header = New TableCell
            cell_header.Text = "Last 3 Cycles"
            cell_header.HorizontalAlign = HorizontalAlign.Center
            cell_header.ColumnSpan = 3
            cell_header.BorderStyle = BorderStyle.Solid
            cell_header.BorderWidth = 1
            cell_header.BorderColor = Drawing.Color.FromName("#bbd9ee")
            cell_header.Font.Bold = True
            headerrow.Cells.Add(cell_header)

            gdEWSReport.Controls(0).Controls.AddAt(0, headerrow)
        End If
    End Sub
End Class
