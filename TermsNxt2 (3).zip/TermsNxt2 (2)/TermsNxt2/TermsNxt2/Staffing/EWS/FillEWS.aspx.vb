﻿Imports com.nss.DBAccess
Imports System.Data
Partial Class Staffing_EWS_FillEWS
    Inherits System.Web.UI.Page
#Region "--- Properties ---"
    Property CurrentDate() As Date
        Get
            Return ViewState("CurrentDate")
        End Get
        Set(ByVal value As Date)
            ViewState("CurrentDate") = value
        End Set
    End Property
    Property CurrentLevel() As Integer
        Get
            Return ViewState("CurrentLevel")
        End Get
        Set(ByVal value As Integer)
            ViewState("CurrentLevel") = value
        End Set
    End Property
    Property SupervisorID() As String
        Get
            Return ViewState("SupervisorID")
        End Get
        Set(ByVal value As String)
            ViewState("SupervisorID") = value
        End Set
    End Property
    Property UserID() As String
        Get
            Return ViewState("UserID")
        End Get
        Set(ByVal value As String)
            ViewState("UserID") = value
        End Set
    End Property
    Property AgentID() As String
        Get
            Return ViewState("AgentID")
        End Get
        Set(ByVal value As String)
            ViewState("AgentID") = value
        End Set
    End Property
    Property UserName() As String
        Get
            Return ViewState("username")
        End Get
        Set(ByVal value As String)
            ViewState("username") = value
        End Set
    End Property
#End Region

#Region "--- Load ---"
    Private Sub LoadData()
        Dim db As New DBAccess("CRM")
        Dim dr As DataRow = db.ReturnRow("SELECT GetDate() AS CurrentDate", False)
        CurrentDate = dr("currentDate")
        db = Nothing
        cboMonth.SelectedValue = CurrentDate.Month
        cboYear.SelectedValue = CurrentDate.Year
    End Sub
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        HumanMessage.Style.Item("visibility") = "hidden"
        If Not IsPostBack Then
            lblReportName.CurrentPage = "Fill EWS"
            CurrentLevel = 2
            'Session("Agentid") = "NSS12108"
            'Session("UserID") = "NSS12108"
            AgentID = Session("Agentid")
            UserID = Session("UserID")
            UserName = Session("username")
            '----------- Check Freezed Status
            LoadData()
            If Not FreezeStatus() Then
                'GdEWS.Enabled = False
                For Each gvr As GridViewRow In GdEWS.Rows
                    gvr.Cells(1).Enabled = True
                    gvr.Cells(2).Enabled = False
                    gvr.Cells(3).Enabled = False
                    gvr.Cells(4).Enabled = False
                    gvr.Cells(5).Enabled = False
                    gvr.Cells(6).Enabled = False
                Next
                btsave.Enabled = False
                btnSubmit.Enabled = False
            Else
                GdEWS.Enabled = True
                btsave.Enabled = True
                btnSubmit.Enabled = True
            End If
            SupervisorID = AgentID
            FillData(SupervisorID)
            link2.Text = UserName & "(" & AgentID & ")"
            PanelReports.Controls.Add(Common.GetMenu(Request.Url, AgentID, Request.ApplicationPath))
            Image3.Visible = False
            Image4.Visible = False
            Image5.Visible = False
            Image6.Visible = False
            Image7.Visible = False
            Image8.Visible = False
        End If
    End Sub
#End Region
    Dim dt As DataTable

#Region "--- Functions ---"
    Private Sub FillData(ByVal SupId As String)
        Dim db As New DBAccess("CRM")
        db.slDataAdd("SupervisorId", SupId)
        db.slDataAdd("Month", cboMonth.SelectedValue)
        db.slDataAdd("Year", cboYear.SelectedValue)
        dt = db.ReturnTable("usp_GetEWSHierarchy", , True)
        db = Nothing
        Dim dtFilled As DataTable
        If dt.Rows.Count > 0 Then
            GdEWS.DataSource = dt
            Dim drFilled() As DataRow = dt.Select("Filled=True")
            If drFilled.Length > 0 Then
                dtFilled = dt.DefaultView.ToTable(True, "AgentName", "AgentId", "IsSuperVisor", "ProcessID", "Filled")
                GdEWS.DataSource = dtFilled.DefaultView
                GdEWS.DataBind()
            Else
                GdEWS.DataSource = dt
                GdEWS.DataBind()
            End If
        Else
            GdEWS.Enabled = True
            btsave.Enabled = True
            btnSubmit.Enabled = True
            GdEWS.DataSource = dt.DefaultView
            ImgMarkedorNot.ImageUrl = "~/_assets/img/why.gif"
            lblEWSFilled.Text = "Not Filled"
        End If
    End Sub
    Private Function Pagevalidate() As Boolean
        For Each row As GridViewRow In GdEWS.Rows
            If CType(row.FindControl("rdRed"), RadioButton).Checked = True Then
                If CType(row.FindControl("lstReason"), ListBox).SelectedIndex = -1 Then
                    AlertMessage("Please fill reason for " & CType(row.FindControl("lblAgentName"), Label).Text)
                    Return False
                End If
                If CType(row.FindControl("lstReason"), ListBox).SelectedItem.Text.ToUpper.Trim = "NA" Then
                    AlertMessage("You can not select reason as 'NA' in Red and Amber for " & CType(row.FindControl("lblAgentName"), Label).Text)
                    Return False
                End If
            End If
            If CType(row.FindControl("rdAmber"), RadioButton).Checked = True Then
                If CType(row.FindControl("lstReason"), ListBox).SelectedIndex = -1 Then
                    AlertMessage("Please fill reason for " & CType(row.FindControl("lblAgentName"), Label).Text)
                    Return False
                End If
                If CType(row.FindControl("lstReason"), ListBox).SelectedItem.Text.ToUpper.Trim = "NA" Then
                    AlertMessage("You can not select reason as 'NA' in Red and Amber for " & CType(row.FindControl("lblAgentName"), Label).Text)
                    Return False
                End If
            End If
        Next
        Return True
    End Function
   
    Private Sub SaveEWSData(ByVal Freeze As Integer)
        Try
            '@Kush 2023-02-23
            ' Dim ISchkSelect As Boolean

            If Pagevalidate() Then
                For Each row As GridViewRow In GdEWS.Rows
                    Dim db As New DBAccess("CRM")

                    '@Kush 2023-02-23
                    'ISchkSelect = CType(row.FindControl("ChkAgentID"), CheckBox).Checked
                    'If ISchkSelect = True Then


                    db.BeginTrans()
                    Dim greenflag As Boolean = False
                    Try
                        db.slDataAdd("AgentID", CType(row.FindControl("lblAgentID"), Label).Text)
                        db.slDataAdd("Month", cboMonth.SelectedValue)
                        db.slDataAdd("Year", cboYear.SelectedValue)
                        db.slDataAdd("ProcessID", GdEWS.DataKeys(row.RowIndex).Item("ProcessId"))
                        If CType(row.FindControl("rdRed"), RadioButton).Checked = True Then
                            db.slDataAdd("Status", 1)
                        End If
                        If CType(row.FindControl("rdAmber"), RadioButton).Checked = True Then
                            db.slDataAdd("Status", 2)
                        End If
                        If CType(row.FindControl("rdGreen"), RadioButton).Checked = True Then
                            db.slDataAdd("Status", 3)
                            greenflag = True
                        End If
                        db.slDataAdd("Freeze", Freeze)
                        db.slDataAdd("Supervisorid", SupervisorID)
                        db.slDataAdd("FilledBy", AgentID)
                        db.slDataAdd("ReasonText", CType(row.FindControl("txtOther"), TextBox).Text)
                        Dim EwsId As Integer = db.ReturnValue("usp_InsertEWSData", True)
                        db.exeSQL("delete from tbl_Data_EWS_Reasons where EwsId=" & EwsId)
                        If greenflag Then
                            SaveReasonText(EwsId, 13, db)
                        Else
                            For Each item As ListItem In CType(row.FindControl("lstReason"), ListBox).Items
                                If item.Selected Then
                                    SaveReasonText(EwsId, item.Value, db)
                                End If
                            Next
                        End If
                        db.CommitTrans()




                    Catch ex As Exception
                        db.RollBackTrans()
                        Throw ex
                    Finally
                        db = Nothing
                    End Try

                    '        Else
                    '       AlertMessage("Please Select TM")


                    ' End If


                Next
                SuccessMessage("EWS Data has been saved Successfully For Month " & cboMonth.Text & "  " & cboYear.Text)
                FillData(SupervisorID)
            End If
        Catch ex As Exception
            AlertMessage(ex.ToString)
        Finally
        End Try
    End Sub
    Private Sub SaveReasonText(ByVal Id As Integer, ByVal ReasonId As Integer, ByVal db As DBAccess)
        Try
            db.slDataAdd("EwsId", Id)
            db.slDataAdd("ReasonID", ReasonId)
            db.Executeproc("usp_InsertEWSReasonData")
        Catch ex As Exception
            AlertMessage(ex.ToString)
        End Try
    End Sub
    Private Function FreezeStatus() As Boolean
        Dim db As New DBAccess("CRM")
        Dim dr As DataRow = db.ReturnRow("SELECT ISNULL(MAX(FreezedMonth),0) AS [Month],ISNULL(MAX(FreezedYear),0) AS [Year]  FROM tbl_EWS_LastFreezedMonth", False)
        db = Nothing
        If dr("Year") > cboYear.SelectedValue Then
            Return False
        Else
            If dr("Month") >= cboMonth.SelectedValue And dr("Year") >= cboYear.SelectedValue Then
                Return False
            End If
        End If
        'If (dr("Month") < cboMonth.SelectedValue And dr("Year") <= cboYear.SelectedValue) Then
        'ElseIf (dr("Year") < cboYear.SelectedValue) Then
        'ElseIf dr("Month") < cboMonth.SelectedValue Then
        '    Return False
        'Else
        '    Return False
        'End If
        Return True
    End Function
    Private Sub ValidDate()
        'GdEWS.Enabled = False
        For Each gvr As GridViewRow In GdEWS.Rows
            gvr.Cells(1).Enabled = True
            gvr.Cells(2).Enabled = False
            gvr.Cells(3).Enabled = False
            gvr.Cells(4).Enabled = False
            gvr.Cells(5).Enabled = False
            gvr.Cells(6).Enabled = False
        Next
        btsave.Enabled = False
        btnSubmit.Enabled = False
    End Sub
  
#End Region
#Region "--- Events ---"
  
    Protected Sub btsave_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btsave.Click
        If GdEWS.Rows.Count > 0 Then
            If Not FreezeStatus() Then
                AlertMessage("Data can not be saved. EWS is Freeze for this Month & Year combination")
            Else
                SaveEWSData(0)
            End If
        Else
            AlertMessage("There is no data to save")
        End If
    End Sub
    Protected Sub btnSubmit_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnSubmit.Click
        If GdEWS.Rows.Count > 0 Then
            If Not FreezeStatus() Then
                AlertMessage("Data can not be saved. EWS is Freeze for this Month & Year combination")
            Else
                SaveEWSData(1)
            End If
        Else
            AlertMessage("There is no data to save")
        End If
    End Sub
    Protected Sub cboMonth_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboMonth.SelectedIndexChanged
        If cboMonth.SelectedValue > CurrentDate.Month And cboYear.SelectedValue >= CurrentDate.Year Then
            AlertMessage("Month & Year combination can not be greater than current")
            cboMonth.SelectedValue = CurrentDate.Month
            ValidDate()
        ElseIf cboYear.SelectedValue > CurrentDate.Year Then
            AlertMessage("Month & Year combination can not be greater than current")
            cboMonth.SelectedValue = CurrentDate.Month
            ValidDate()
        End If
        If Not FreezeStatus() Then
            FillData(SupervisorID)
            'GdEWS.Enabled = False
            For Each gvr As GridViewRow In GdEWS.Rows
                gvr.Cells(1).Enabled = True
                gvr.Cells(2).Enabled = False
                gvr.Cells(3).Enabled = False
                gvr.Cells(4).Enabled = False
                gvr.Cells(5).Enabled = False
                gvr.Cells(6).Enabled = False
            Next
            btsave.Enabled = False
            btnSubmit.Enabled = False
        Else
            FillData(SupervisorID)
        End If
    End Sub
    Protected Sub cboYear_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboYear.SelectedIndexChanged
        If cboMonth.SelectedValue > CurrentDate.Month And cboYear.SelectedValue >= CurrentDate.Year Then
            AlertMessage("Month & Year combination can not be greater than current")
            cboYear.SelectedValue = CurrentDate.Year
            cboMonth.SelectedValue = CurrentDate.Month
            ValidDate()
        ElseIf cboYear.SelectedValue > CurrentDate.Year Then
            AlertMessage("Month & Year combination can not be greater than current")
            cboYear.SelectedValue = CurrentDate.Year
            cboMonth.SelectedValue = CurrentDate.Month
            ValidDate()
        End If
        If Not FreezeStatus() Then
            FillData(SupervisorID)
            'GdEWS.Enabled = False
            For Each gvr As GridViewRow In GdEWS.Rows
                gvr.Cells(1).Enabled = True
                gvr.Cells(2).Enabled = False
                gvr.Cells(3).Enabled = False
                gvr.Cells(4).Enabled = False
                gvr.Cells(5).Enabled = False
                gvr.Cells(6).Enabled = False
            Next
            btsave.Enabled = False
            btnSubmit.Enabled = False
        Else
            FillData(SupervisorID)
        End If

    End Sub

    Protected Sub GdEWS_RowCreated(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles GdEWS.RowCreated
        If e.Row.RowType = DataControlRowType.DataRow Then
            'If CType(e.Row.FindControl("rdGreen"), RadioButton).Checked = True Then
            '    Dim reason As ListBox = CType(e.Row.FindControl("lstReason"), ListBox)
            '    reason.Enabled = False
            'End If 

            ''Dim checkbox As New CheckBox()
            ''checkbox.ID = "chkChecked"
            ''AddHandler checkbox.CheckedChanged, AddressOf Checkbx_CheckedChanged
            ''checkbox.AutoPostBack = True
            ''checkbox.EnableViewState = True

            ''checkbox.Checked = ViewState("checkboxGridviewState")
            ''If ViewState("postbackTrue") = False Then ' 26Mar2016that is when loaded for first time then checkd=True
            ''    checkbox.Checked = True
            ''End If
            ''e.Row.Cells(0).Controls.Add(checkbox)



        End If
    End Sub

    Protected Sub Checkbx_CheckedChanged(ByVal sender As Object, ByVal e As System.EventArgs)
        ' FillWeekRoster_CombineAll() 'rajkumar 21Mar2016 Added
        '   FillWeekRoster_CombineAll_2222() 'rajkumar 21Mar2016 Added

        Dim chk As CheckBox = CType(sender, CheckBox)
        ViewState("checkboxGridviewState") = chk.Checked ''that is true or false

        For j As Integer = 0 To GdEWS.Rows.Count - 1
            CType(GdEWS.Rows(j).FindControl("chkChecked1"), CheckBox).Checked = chk.Checked
        Next
    End Sub

    Protected Sub GdEWS_RowDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles GdEWS.RowDataBound
        '@Kush Issue 2023-02-23
        'If e.Row.RowType = DataControlRowType.Header Then

        '    '@Kush Issue 
        '    Dim checkbox As New CheckBox()
        '    checkbox.ID = "chkChecked"
        '    AddHandler checkbox.CheckedChanged, AddressOf Checkbx_CheckedChanged
        '    checkbox.AutoPostBack = True
        '    checkbox.EnableViewState = True

        '    checkbox.Checked = ViewState("checkboxGridviewState")
        '    If ViewState("postbackTrue") = False Then ' 26Mar2016that is when loaded for first time then checkd=True
        '        checkbox.Checked = True
        '    End If
        '    e.Row.Cells(0).Controls.Add(checkbox)

        'End If


        If e.Row.RowType = DataControlRowType.DataRow Then
            Dim db1 As New DBAccess("CRM")
            Dim dtreason As DataTable
            dtreason = db1.ReturnTable("SELECT * FROM tbl_Config_EWSReasons where active=1 Order by Sequence", False)
            db1 = Nothing


            '@Kush Issue  2023-02-23
            'Dim checkbox As New CheckBox()
            'checkbox.ID = "chkChecked1"
            ''  AddHandler checkbox.CheckedChanged, AddressOf CheckedChaged
            'checkbox.AutoPostBack = False

            'checkbox.Checked = ViewState("checkboxGridviewState")
            'If ViewState("postbackTrue") = False Then ' 26Mar2016that is when loaded for first time then checkd=True
            '    checkbox.Checked = True
            'End If
            'e.Row.Cells(0).Controls.Add(checkbox) 'rajkumar 21Mar2016 Done for Checkbox


            'Dim chkSelect As CheckBox = CType(e.Row.FindControl("ChkAgentID"), CheckBox)
            'chkSelect.AutoPostBack = False

            Dim reason As ListBox = CType(e.Row.FindControl("lstReason"), ListBox)
            reason.DataTextField = "Reason"
            reason.DataValueField = "Id"
            reason.DataSource = dtreason
            reason.DataBind()

            Dim status As Int16
            Dim lblagent As String = CType(e.Row.FindControl("lblAgentID"), Label).Text
            Dim ar() As DataRow = dt.Select("agentid='" & lblagent & "'")
            If ar.Length > 0 Then
                status = ar(0).Item("Status")
                If status = 1 Then
                    CType(e.Row.FindControl("rdRed"), RadioButton).Checked = True
                    CType(e.Row.FindControl("rdAmber"), RadioButton).Checked = False
                    CType(e.Row.FindControl("rdGreen"), RadioButton).Checked = False
                ElseIf status = 2 Then
                    CType(e.Row.FindControl("rdAmber"), RadioButton).Checked = True
                    CType(e.Row.FindControl("rdRed"), RadioButton).Checked = False
                    CType(e.Row.FindControl("rdGreen"), RadioButton).Checked = False
                ElseIf status = 3 Then
                    CType(e.Row.FindControl("rdGreen"), RadioButton).Checked = True
                    CType(e.Row.FindControl("rdAmber"), RadioButton).Checked = False
                    CType(e.Row.FindControl("rdRed"), RadioButton).Checked = False
                End If
            End If
            If GdEWS.DataKeys(e.Row.RowIndex).Item("IsSupervisor").ToString.ToLower = "false" Or lblagent = SupervisorID Then
                CType(e.Row.FindControl("lnkbtagentname"), LinkButton).Visible = False
            Else
                CType(e.Row.FindControl("lblAgentName"), Label).Visible = False
            End If
            If status > 0 Then
                For Each item As ListItem In reason.Items
                    Dim reasonid As Boolean = IIf(dt.Select("AgentID ='" & lblagent & "' and reasonid=" & item.Value).Length > 0, True, False)
                    If reasonid Then
                        item.Selected = True
                        If item.Value = 14 Then
                            Dim pnl As Panel = CType(e.Row.FindControl("pnlother"), Panel)
                            pnl.Attributes.CssStyle.Add("display", "block")
                            Dim dr() As DataRow = dt.Select("reasonid=" & item.Value & " and AgentID ='" & lblagent & "'")
                            CType(e.Row.FindControl("txtOther"), TextBox).Text = dr(0).Item("ReasonText")
                        ElseIf item.Value = 13 Then
                            item.Selected = True
                        End If
                    End If
                Next
                Dim drFreeze() As DataRow = dt.Select("Freeze=False")
                If drFreeze.Length > 0 Then
                    GdEWS.Enabled = True
                    btsave.Enabled = True
                    btnSubmit.Enabled = True
                Else
                    e.Row.Cells(1).Enabled = True
                    e.Row.Cells(2).Enabled = False
                    e.Row.Cells(3).Enabled = False
                    e.Row.Cells(4).Enabled = False
                    e.Row.Cells(5).Enabled = False
                    e.Row.Cells(6).Enabled = False
                End If
                ImgMarkedorNot.ImageUrl = "~/_assets/img/yes.gif"
                lblEWSFilled.Text = "Filled"
            Else
                ImgMarkedorNot.ImageUrl = "~/_assets/img/why.gif"
                lblEWSFilled.Text = "Not Filled"
            End If
        End If
    End Sub

    Protected Sub GdEWS_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles GdEWS.SelectedIndexChanged
        Dim lnk As New LinkButton, img As New Image
        CurrentLevel += 1
        Select Case CurrentLevel
            Case 3
                lnk = link3
                img = Image3
                link2.CssClass = "notselectedlink"
            Case 4
                lnk = Link4
                img = Image4
                link3.CssClass = "notselectedlink"
            Case 5
                lnk = Link5
                img = Image5
                Link4.CssClass = "notselectedlink"
            Case 6
                lnk = Link6
                img = Image6
                Link5.CssClass = "notselectedlink"
            Case 7
                lnk = Link7
                img = Image7
                Link6.CssClass = "notselectedlink"
            Case 8
                lnk = Link8
                img = Image8
                Link7.CssClass = "notselectedlink"
        End Select
        lnk.Text = GdEWS.SelectedDataKey.Item("AgentName").ToString & "(" & GdEWS.SelectedDataKey.Item("AgentID").ToString & ")"
        SupervisorID = GdEWS.SelectedDataKey.Item("AgentID").ToString
        FillData(SupervisorID)

        lnk.Visible = True
        lnk.CssClass = "selectedlink"
        img.Visible = True
    End Sub

    Protected Sub imgfav_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles imgfav.Click
        Common.AddToFav(AgentID, "Fill EWS")
        SuccessMessage("Report has been added to your favourite list")
        FillData(SupervisorID)
    End Sub
#End Region
#Region "--- Side Links ---"
    Private Sub HideAllSideLinks(ByVal ctrl As LinkButton)
        Dim from As Integer
        from = ctrl.ID.ToLower.Replace("link", "")
        CurrentLevel = from

        Select Case from
            Case 2
                link3.Visible = False
                Link4.Visible = False
                Link5.Visible = False
                Link6.Visible = False
                Link7.Visible = False
                Link8.Visible = False

                Image3.Visible = False
                Image4.Visible = False
                Image5.Visible = False
                Image6.Visible = False
                Image7.Visible = False
                Image8.Visible = False
            Case 3
                Link4.Visible = False
                Link5.Visible = False
                Link6.Visible = False
                Link7.Visible = False
                Link8.Visible = False
                Image4.Visible = False
                Image5.Visible = False
                Image6.Visible = False
                Image7.Visible = False
                Image8.Visible = False
            Case 4

                Link5.Visible = False
                Link6.Visible = False
                Link7.Visible = False
                Link8.Visible = False
                Image5.Visible = False
                Image6.Visible = False
                Image7.Visible = False
                Image8.Visible = False
            Case 5

                Link6.Visible = False
                Link7.Visible = False
                Link8.Visible = False
                Image6.Visible = False
                Image7.Visible = False
                Image8.Visible = False
            Case 6
                Link7.Visible = False
                Link8.Visible = False
                Image7.Visible = False
                Image8.Visible = False
            Case 7
                Link8.Visible = False
                Image8.Visible = False
            Case 8
                'do noting
        End Select

    End Sub
    Protected Sub Sidelink_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles link2.Click
        Dim length As Integer
        length = sender.Text.LastIndexOf(")") - sender.Text.LastIndexOf("(")
        SupervisorID = sender.Text.Substring(sender.Text.LastIndexOf("(") + 1, length - 1)
        FillData(SupervisorID)
        HideAllSideLinks(sender)
        sender.CssClass = "selectedlink"
    End Sub
#End Region

#Region "--- Utility ---"
    Private Sub AlertMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMFail"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub
    Private Sub SuccessMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMSuccess"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub

#End Region

End Class
