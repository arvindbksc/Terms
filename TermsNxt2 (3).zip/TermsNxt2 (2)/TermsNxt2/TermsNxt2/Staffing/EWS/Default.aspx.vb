﻿
Partial Class Staffing_EWS_Default
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Response.Redirect("FillEWS.aspx")
    End Sub
End Class
