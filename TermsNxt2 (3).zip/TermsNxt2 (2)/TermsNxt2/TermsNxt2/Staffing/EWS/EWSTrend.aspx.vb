﻿Imports com.nss.DBAccess
Imports System.Data
Partial Class Staffing_EWS_EWSTrend
    Inherits System.Web.UI.Page
#Region "--- Properties ---"
    Property CampaignId() As String
        Get
            Return ViewState("CampaignId")
        End Get
        Set(ByVal value As String)
            ViewState("CampaignId") = value
        End Set
    End Property
    Property AgentID() As String
        Get
            Return ViewState("AgentID")
        End Get
        Set(ByVal value As String)
            ViewState("AgentID") = value
        End Set
    End Property
#End Region
#Region "--- Load ---"
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        HumanMessage.Style.Item("visibility") = "hidden"
        If Not IsPostBack Then
            AgentID = Session("AgentId")
            CampaignId = Session("CampaignId")
            Common.FillProcesses(CboProcess, AgentID, 0)
            CboProcess.SelectedValue = Request.QueryString("process")
            PanelReports.Controls.Add(Common.GetMenu(Request.Url, AgentID, Request.ApplicationPath))
            lblReportName.CurrentPage = "EWS Trend"
            FillData()
        End If
    End Sub
#End Region
#Region "--- Functions ---"
    Private Sub FillData()
        Dim db As New DBAccess("CRM")
        Dim dt As DataTable
        Try
            db.slDataAdd("ProcessID", CboProcess.SelectedValue)
            dt = db.ReturnTable("usp_getEwsTrend", , True)
            db = Nothing

            Dim dt1 As New DataTable
            dt1.Columns.Add("AgentName", System.Type.GetType("System.String"))
            For Each row As DataRow In dt.DefaultView.ToTable(True, "MONTH").Rows
                dt1.Columns.Add(row.Item(0), System.Type.GetType("System.String"))
            Next
            Dim dtagent As DataTable = dt.DefaultView.ToTable(True, "AgentName")
            For Each row As DataRow In dtagent.Rows
                Dim dtrow As DataRow = dt1.NewRow
                dtrow("AgentName") = row("AgentName")
                For Each col As DataColumn In dt1.Columns
                    If col.ColumnName <> "AgentName" Then
                        Dim row2() As DataRow = dt.Select("MONTH='" & col.ColumnName & "' and AgentName='" & row("AgentName") & "'")
                        If row2.Length > 0 Then
                            dtrow(col.ColumnName) = row2(0).Item("Month Status")
                        End If
                    End If
                Next
                dt1.Rows.Add(dtrow)
            Next

            
            'Dim row2() As DataRow = dt.Select("MONTH='" & row.Item(0) & "'")
            'For Each row3 As DataRow In row2
            '    Dim dtrow As DataRow = dt1.NewRow
            '    dtrow(row.Item(0).ToString) = row3.Item("Month Status")
            '    dt1.Rows.Add(dtrow)
            '    'MsgBox(row3.Item("Month Status"))
            '    '  dt1.Columns(row.Item(0)) = row3.Item("Month Status")
            'Next
            'For Each row1 As DataRow In dt.Rows
            '    For Each col As DataColumn In dt1.Columns

            '    Next
            'Next
            gdEWSReport.DataSource = dt1
            gdEWSReport.DataBind()
        Catch ex As Exception
            AlertMessage(ex.ToString)
        End Try
    End Sub
#End Region
#Region "--- Events ---"
    Protected Sub btnRefresh_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnRefresh.Click
        FillData()
    End Sub
    Protected Sub ImgExport_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImgExport.Click
        FillData()
        GridViewExportUtil.Export(lblReportName.CurrentPage & ".xls", Me.gdEWSReport)
    End Sub
    Protected Sub CboProcess_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles CboProcess.SelectedIndexChanged
        FillData()
    End Sub
#End Region
#Region "--- Utility ---"
    Private Sub AlertMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMFail"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub
    Private Sub SuccessMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMSuccess"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub
#End Region
End Class
