﻿Imports com.nss.DBAccess
Imports System.Data
Partial Class Staffing_EWS_EWSReport
    Inherits System.Web.UI.Page
#Region "--- Properties ---"
    Property CampaignId() As String
        Get
            Return ViewState("CampaignId")
        End Get
        Set(ByVal value As String)
            ViewState("CampaignId") = value
        End Set
    End Property
    Property AgentID() As String
        Get
            Return ViewState("AgentID")
        End Get
        Set(ByVal value As String)
            ViewState("AgentID") = value
        End Set
    End Property
#End Region
#Region "--- Load ---"
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        HumanMessage.Style.Item("visibility") = "hidden"
        If Not IsPostBack Then
            AgentID = Session("AgentId")
            CampaignId = Session("CampaignId")
            Common.FillProcesses(CboProcess, AgentID, 0)
            PanelReports.Controls.Add(Common.GetMenu(Request.Url, AgentID, Request.ApplicationPath))
            lblReportName.CurrentPage = "EWS Report"
            cboMonth.SelectedValue = DateTime.Now.Month
            cboYear.SelectedValue = DateTime.Now.Year
            FillData()
        End If
    End Sub
#End Region
#Region "--- Functions ---"
    Private Sub FillData()
        Dim db As New DBAccess("CRM")
        Dim dt As DataTable
        Try
            db.slDataAdd("ProcessID", CboProcess.SelectedValue)
            db.slDataAdd("Month", cboMonth.SelectedValue)
            db.slDataAdd("Year", cboYear.SelectedValue)
            dt = db.ReturnTable("usp_getEwsReport", , True)
            db = Nothing
            gdEWSReport.DataSource = dt
            gdEWSReport.DataBind()
        Catch ex As Exception
            AlertMessage(ex.ToString)
        End Try
    End Sub
#End Region
#Region "--- Events ---"
    Protected Sub cboMonth_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboMonth.SelectedIndexChanged
        FillData()
    End Sub
    Protected Sub cboYear_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboYear.SelectedIndexChanged
        FillData()
    End Sub
    Protected Sub btnRefresh_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnRefresh.Click
        FillData()
    End Sub
    Protected Sub ImgExport_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImgExport.Click
        FillData()
        GridViewExportUtil.Export(lblReportName.CurrentPage & ".xls", Me.gdEWSReport)
    End Sub
    Protected Sub CboProcess_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles CboProcess.SelectedIndexChanged
        FillData()
    End Sub
#End Region
#Region "--- Utility ---"
    Private Sub AlertMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMFail"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub
    Private Sub SuccessMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMSuccess"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub
#End Region
End Class
