﻿Imports com.nss.DBAccess
Imports System.Data
Imports System.Text

Partial Class Staffing_NewJoinee
    Inherits System.Web.UI.Page
#Region "--- Properties ---"
    Private IdCol As Integer
    Private campaign As Integer
    Private FreezeDate1 As DateTime

    Property CurrentDate() As Date
        Get
            Return ViewState("CurrentDate")
        End Get
        Set(ByVal value As Date)
            ViewState("CurrentDate") = value
        End Set
    End Property
    Property MinDate() As Date
        Get
            Return ViewState("MinDate")
        End Get
        Set(ByVal value As Date)
            ViewState("MinDate") = value
        End Set
    End Property
    Property AgentID() As String
        Get
            Return ViewState("AgentID")
        End Get
        Set(ByVal value As String)
            ViewState("AgentID") = value
        End Set
    End Property

    Property CampaignID() As Integer
        Get
            Return ViewState("CampaignID")
        End Get
        Set(ByVal value As Integer)
            ViewState("CampaignID") = value
        End Set
    End Property

    Property UserName() As String
        Get
            Return ViewState("username")
        End Get
        Set(ByVal value As String)
            ViewState("username") = value
        End Set
    End Property
    Property GetCampaign() As Integer
        Get
            Return campaign
        End Get
        Set(ByVal value As Integer)
            campaign = value
        End Set
    End Property
    Property FreezeDate() As DateTime
        Get
            Return FreezeDate1
        End Get
        Set(ByVal value As DateTime)
            FreezeDate1 = value
        End Set
    End Property

    Property LanID() As String
        Get
            Return ViewState("LanID")
        End Get
        Set(ByVal value As String)
            ViewState("LanID") = value
        End Set
    End Property
#End Region
    Dim dtProcess As DataTable
    Dim dtSupervisor As DataTable
    Dim ErrorFlag As Boolean = False
    Dim isSupervisor As Integer = 0
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        HumanMessage.Style.Item("visibility") = "hidden"
        If Not IsPostBack Then
            If Session("AgentID") <> "" Then
                CampaignID = Session("Campaignid")
                AgentID = Session("AgentID")
                UserName = Session("Username")
                PanelReports.Controls.Add(Common.GetMenu(Request.Url, AgentID, Request.ApplicationPath))
                breadcrumbs.CurrentPage = " New Joinee "
            End If
            If ErrorFlag = False Then
                LoadData()
                GetRole()
                BindProcess()
                LanData()
            Else
                Exit Sub
            End If
            If ErrorFlag = False Then
                BindSupervisor()
            Else
                Exit Sub
            End If
        End If
    End Sub

#Region "--- BindSupervisor ---"
    Private Sub BindSupervisor()
        Try
            Dim db As New DBAccess("CRM")
            dtSupervisor = New DataTable
            dtSupervisor = db.ReturnTable("SELECT [agentid], [AgentName] FROM tbl_AgentMaster where Active = 1 AND isSupervisor = 1 order by 2", False)
            cmbSupervisor.DataSource = dtSupervisor
            db = Nothing
            cmbSupervisor.DataTextField = "AgentName"
            cmbSupervisor.DataValueField = "agentid"
            cmbSupervisor.DataBind()
        Catch ex As Exception
            ErrorFlag = True
            Exit Sub
        End Try
    End Sub
#End Region
#Region "--- Validation ---"
    Private Function validdate(ByVal selecteddate As DateTime) As Boolean
        'If selecteddate > CurrentDate Or selecteddate < MinDate Then
        Dim db As New DBAccess("CRM")
        Dim FreezDate As Date = db.ReturnValue("select MAX(FreezeDate) As FreezDate from tbl_LastFreezedDate", False)
        db = Nothing
        If selecteddate > CurrentDate Then
            Return False
        End If
        If FreezDate >= selecteddate Then
            Return False
        End If
        Return True
    End Function
    Private Function fnValidate() As Boolean
        Dim SupervisorEmail As Boolean = False
        If Not validdate(txtDate.value) Then
            AlertMessage("Date not in valid range")
            txtDate.Focus()
            Return False
        End If
        If txtPrefix.Text.Trim = "" Then
            'LblError.Text = "Please Enter Prefix (Like: 'NSS')"
            AlertMessage("Please Enter Prefix (Like: 'NSS')")
            txtPrefix.Focus()
            Return False
        End If
        If txtEmpID.Text.Trim = "" Then
            'LblError.Text = "Please Enter Employee Code"
            AlertMessage("Please Enter Employee Code")
            txtEmpID.Focus()
            Return False
        Else
            If Not IsNumeric(txtEmpID.Text) Then
                'LblError.Text = "Please Enter Numeric Value for Employee Code"
                AlertMessage("Please Enter Numeric Value for Employee Code")
                txtEmpID.Text = ""
                txtEmpID.Focus()
                Return False
            End If
        End If

        If txtFirstName.Text.Trim = "" Then
            ' LblError.Text = "Please Enter First Name"
            AlertMessage("Please Enter First Name")
            txtFirstName.Focus()
            Return False
        End If
        If txtAliasName.Text.Trim = "" Then
            'LblError.Text = "Please Enter Alias Name"
            AlertMessage("Please Enter Alias Name")
            txtAliasName.Focus()
            Return False
        End If
        If txtVcAmount.Text <> "" Then
            If Not IsNumeric(txtVcAmount.Text) Then
                AlertMessage("Please Enter Numeric Value(s) in VC Amount")
                txtVcAmount.Focus()
                Return False
            End If
        End If
     
        If pnlEmail.Visible = True Then
            If txtLanID.Text.Trim = "" Then
                'LblError.Text = "Lan-ID can not be blank for Supervisor!"
                AlertMessage("Lan-ID can not be blank for Supervisor!")
                txtLanID.Focus()
                Return False
            End If
            If txtSupervisorEmail.Text.Trim = "" Then
                'LblError.Text = "Please Enter Supervisor Email"
                AlertMessage("Please Enter Supervisor Email")
                txtSupervisorEmail.Focus()
                Return False
            End If
            SupervisorEmail = chkSupervisorEmail()
            If SupervisorEmail = False Then
                'LblError.Text = "Please Enter correct format for Supervisor Email"
                AlertMessage("Please Enter correct format for Supervisor Email")
                txtSupervisorEmail.Focus()
                Return False
            End If
        End If
        If cmbRole.SelectedValue = 0 Then
            AlertMessage("Please select a Designation")
            Return False
        End If
        Return True
    End Function
#End Region
#Region "--- LoadData ---"
    Private Sub LoadData()
        Dim db As New DBAccess("CRM")
        'Dim dr As DataRow = db.ReturnRow("SELECT dateadd(dd,1,max([FreezeDate])) as mindate  ,getdate() as currentdate  FROM [tbl_LastFreezedDate]")
        Dim dr As DataRow = db.ReturnRow("SELECT getdate() as currentdate")
        CurrentDate = dr("currentDate")
        txtDate.value = CurrentDate
        'MinDate = dr("minDate")
        db = Nothing
    End Sub

    Private Sub LanData()
        Dim dtlan As DataTable
        Dim dblan As New DBAccess("CRM")
        dblan.slDataAdd("AgentId", AgentID)
        dtlan = dblan.ReturnTable("usp_getAgentdetails", , True)
        If dtlan.Rows.Count > 0 Then
            LanID = dtlan.Rows(0).Item("lanId")
            dblan = Nothing
        End If

    End Sub


    Private Sub BindProcess()
        Try
            Dim db As New DBAccess
            dtProcess = New DataTable
            dtProcess = db.ReturnTable("usp_GetPrimaryCampaigns", True)
            cmbProcess.DataSource = dtProcess
            db = Nothing
            cmbProcess.DataTextField = "ProcessName"
            cmbProcess.DataValueField = "campaignID"
            cmbProcess.DataBind()
        Catch ex As Exception
            ErrorFlag = True
            Exit Sub
        End Try
    End Sub
    Private Sub GetRole()
        Dim db As New DBAccess("CRM")
        Dim dtRole As New DataTable
        dtRole = db.ReturnTable("usp_getRoles", , False)
        db = Nothing
        Dim dr As DataRow
        dr = dtRole.NewRow
        dr("Designation") = " "
        dr("Roleid") = 0
        dtRole.Rows.Add(dr)
        cmbRole.DataSource = dtRole
        cmbRole.DataTextField = "Designation"
        cmbRole.DataValueField = "Roleid"
        cmbRole.DataBind()
        cmbRole.SelectedValue = 0
    End Sub
    
#End Region
#Region "--- Event ---"
    Protected Sub txtDate_Changed(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtDate.Changed
        If validdate(txtDate.value) Then
        Else
            AlertMessage("Date not in valid range")
            txtDate.value = CurrentDate
        End If
    End Sub
    Protected Sub btnSave_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnSave.Click
        Dim strdate As String
        strdate = txtDate.Text
        Dim IsValidate As Boolean = False
        If txtAliasName.Text = "" Then
            txtAliasName.Text = txtFirstName.Text
        End If
        IsValidate = fnValidate()
        If IsValidate = False Then
            Exit Sub
        Else
            InsertAgentDetails()
        End If
    End Sub
    Protected Sub CheckBox1_CheckedChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles CheckBox1.CheckedChanged
        If CheckBox1.Checked = True Then
            txtSupervisorEmail.Text = ""
            txtSupervisorEmail.Focus()
            pnlEmail.Visible = True
        Else
            pnlEmail.Visible = False
        End If
    End Sub
    Protected Sub btnReset_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnReset.Click
        Reset()
    End Sub
    Protected Sub cmbRole_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmbRole.SelectedIndexChanged
        If cmbRole.SelectedValue = 1 Or cmbRole.SelectedValue = 2 Or cmbRole.SelectedValue = 3 Or cmbRole.SelectedValue = 4 Or cmbRole.SelectedValue = 5 Then
            CheckBox1.Checked = True
            txtSupervisorEmail.Text = ""
            txtSupervisorEmail.Focus()
            pnlEmail.Visible = True
        Else
            CheckBox1.Checked = False
            txtSupervisorEmail.Text = ""
            pnlEmail.Visible = False
        End If
    End Sub
#End Region
#Region "--- Reset ---"
    Private Sub Reset()
        txtFirstName.Text = ""
        txtLastName.Text = ""
        txtEmpID.Text = ""
        txtLanID.Text = ""
        txtSupervisorEmail.Text = ""
        txtAliasName.Text = ""
        txtAddress.Text = ""
        txtPhoneNo.Text = ""
        txtDate.value = CurrentDate
        CheckBox1.Checked = False
        chkIsHR.Checked = False
        pnlEmail.Visible = False
        BindProcess()
        GetRole()
        BindSupervisor()
    End Sub
#End Region
#Region "--- Function ---"
    Private Sub InsertAgentDetails()
        Dim chkSupervisorVal As Boolean = True
        Dim strLANID As String
        strLANID = LanID & "@coforge.com,"

        Dim db As New DBAccess("CRM") ' Live
        'Dim db As New DBAccess("CRMData") 'Testing
        Try
            AgentID = txtPrefix.Text.Trim & txtEmpID.Text.Trim
            Dim dtAgent As New DataTable
            dtAgent = db.ReturnTable("SELECT * FROM tbl_AgentMaster WHERE agentid = '" & AgentID & "'", False) ' Live
            'dtAgent = db.ReturnTable("SELECT * FROM tbl_AgentMaster_Gau WHERE agentid = '" & AgentID & "'", False) ' Testing
            db = Nothing
            If dtAgent.Rows.Count > 0 Then
                AlertMessage("Agent-ID: " & AgentID & " Already exists!")
                Exit Sub
            Else
                db = New DBAccess("CRM")  ' Live
                'db = New DBAccess("CRMData") ' Testing
                db.slDataAdd("vcagentid", AgentID.ToString.ToUpper)
                db.slDataAdd("vcFName", StrConv(txtFirstName.Text.Trim, VbStrConv.ProperCase))
                db.slDataAdd("vcLName", StrConv(txtLastName.Text.Trim, VbStrConv.ProperCase))
                db.slDataAdd("Gender", cboGender.SelectedValue.Trim)
                db.slDataAdd("vcAliasName", StrConv(txtAliasName.Text.Trim, VbStrConv.ProperCase))
                db.slDataAdd("vclanid", StrConv(txtLanID.Text.Trim, VbStrConv.ProperCase))
                db.slDataAdd("SupervisorID", cmbSupervisor.SelectedValue)
                db.slDataAdd("CampaignID", cmbProcess.SelectedValue)
                db.slDataAdd("DOJ", txtDate.Text)
                db.slDataAdd("LastUpdatedOn", txtDate.value)
                db.slDataAdd("LastUpdatedBy", Session("AgentID"))
                db.slDataAdd("Address", txtAddress.Text)
                db.slDataAdd("Phone", txtPhoneNo.Text)
                '----- For Vc Amount
                If txtVcAmount.Text.Trim <> "" Then
                    Dim strAmount As String = "\d+(\.\d{1,2})?"
                    Dim chkValue As New Regex(strAmount.Trim)
                    If Not chkValue.IsMatch(txtVcAmount.Text.Trim) Then
                        AlertMessage("Please Enter Numeric Value")
                    Else
                        db.slDataAdd("VcAmount", txtVcAmount.Text)
                    End If
                End If
                '---------------------
                If CheckBox1.Checked = True Then
                    db.slDataAdd("IsSupervisor", 1)
                    db.slDataAdd("EmailId", txtSupervisorEmail.Text.ToLower)
                End If
                If chkIsHR.Checked Then
                    db.slDataAdd("IsHR", 1)
                Else
                    db.slDataAdd("IsHR", 0)
                End If
                If cmbRole.SelectedValue <> 0 Then
                    db.slDataAdd("Role", cmbRole.SelectedValue)
                End If
                If chkIsMPR.Checked Then
                    db.slDataAdd("IsMPR", 1)
                Else
                    db.slDataAdd("IsMPR", 0)
                End If
                db.Executeproc("usp_InsertAgentDetails")

                ''''To send Mail
                db = New DBAccess("CRM")
                Dim dt As New DataTable
                Dim strCC As String
                db.slDataAdd("AgentId", txtPrefix.Text.Trim & txtEmpID.Text.Trim)
                dt = db.ReturnTable("usp_SupervisorEmails", , True)
                db = Nothing
                strCC = dt.Rows(0).Item("MailCC")
                'strCC = strCC.ToLower.Replace(",hroperations@niitsmartserve.com", "").Replace("hroperations@niitsmartserve.com", "")
                'If strCC.Trim = "" Then
                '    strCC = "transporthelpdesk@NIITSMARTSERVE.com"
                'End If
                'Dim objWSMail As New ShootMail.Mail
                'Dim objWSMail As New MailSendServiceXX.Service1SoapClient

                Dim strCCUnique As String = ""
                strCCUnique = GetUnique(strCC)




                Dim strFrom As String = System.Configuration.ConfigurationManager.AppSettings("FROM")
                Dim MailSubject As String = "New Joinee Added"
                Dim strMailBody As String = ""
                strMailBody += "<html xmlns='http://www.w3.org/1999/xhtml'>"
                strMailBody += "<body style='font-family: Verdana; font-size: .8em'>"
                strMailBody += "A New Joinee has been added. Details are given below:<br /><br />"
                strMailBody += "<table border='1' width='90%' style='border: 1px solid; border-collapse: collapse; font-family: Verdana; font-size: .8em'>"
                strMailBody += "<tr bgcolor='#B8CCE4'>"
                strMailBody += "<td align='center'><b>Emp. Code</b></td>"
                strMailBody += "<td align='center'><b>Emp. Name</b></td>"
                strMailBody += "<td align='center'><b>Designation</b></td>"
                strMailBody += "<td align='center'><b>Process</b></td>"
                strMailBody += "<td align='center'><b>D.O.J</b></td>"
                strMailBody += "<td align='center'><b>Supervisor</b></td>"
                strMailBody += "<td align='center'><b>Added By</b></td>"
                strMailBody += "</tr>"
                strMailBody += "<tr >"
                strMailBody += "<td align='center'>" & txtPrefix.Text.Trim & txtEmpID.Text.Trim & "</td>"
                strMailBody += "<td align='center'>" & txtFirstName.Text.Trim & " " & txtLastName.Text.Trim & "</td>"
                strMailBody += "<td align='center'>" & cmbRole.SelectedItem.Text.Trim & "</td>"
                strMailBody += "<td align='center'>" & cmbProcess.SelectedItem.Text.Trim & "</td>"
                strMailBody += "<td align='center'>" & txtDate.Text.Trim & "</td>"
                strMailBody += "<td align='center'>" & cmbSupervisor.SelectedItem.Text.Trim & "</td>"
                strMailBody += "<td align='center'>" & UserName & "</td>"
                strMailBody += "</tr>"
                strMailBody += "</table>"

                strMailBody += "<br /><br />"

                strMailBody += "<p>"
                strMailBody += "ISMS assessment link is active now for this new joinee. Please get his ISMS assessment done within 24 working hours of receiving this email."
                strMailBody += "</p>"

                strMailBody += "<p>"
                strMailBody += "Given here is the link to take up the assessment . (Only five attempts allowed to clear the assessment)"
                strMailBody += "</p>"

                strMailBody += "<p>"
                ' strMailBody += "<b>URL : https://niit-applicant.edubrite.com/oltpublish/site/homeNew.do  </b>"
                'strMailBody += "URL : <a href='https://Coforge-applicant.edubrite.com/oltpublish/site/homeNew.do'>https://Coforge-applicant.edubrite.com/oltpublish/site/homeNew.do </a>"

                strMailBody += "URL(incognito mode) : <a href='http://103.47.90.80/isafe/ '>http://103.47.90.80/isafe/</a>"
                strMailBody += "</p>"

                strMailBody += "<p>"
                strMailBody += "HR  will share userID ,password and applicant code  of new Joinee, you will need to raise a ICO ticket along with the assessment score, to generate a new email id for the new joinee"
                strMailBody += "</p>"

                strMailBody += "<p>"
                strMailBody += "Path:  IEngage  – IT – Agile IT Service Desk"
                strMailBody += "</p>"


                strMailBody += "<br /><br /><hr/>This mail was sent using the "
                strMailBody += "<a href='https://termsmonitor.coforge.com/'>TermsMonitor&reg;</a> Mail Service.We request you not to reply this message."
                'strMailBody += "<br /><br />In case you wish to report issues with this mail, please send mail to mailto:helpdesk@coforge.com <br /> "
                strMailBody += "<br />This e-mail is confidential and may also be privileged.If you are not the intended recipient, please notify helpdesk immediately; you should not copy or use it for any purpose,nor disclose its contents to any other person."


                strMailBody += "</body>"
                strMailBody += "</html>"
                ' objWSMail.MailSend("TechClearance@niitsmartserve.com", strMailBody, "", strCC, "Developers@niitsmartserve.com", "New Joinee Added<" & strFrom & ">", MailSubject)
                ' objWSMail.MailSendNewTech("BPO.Transport@NIIT-Tech.com", MailSubject, "New Joinee Added<" & strFrom & ">", "", strMailBody, "", "DLA-GGN@niit-tech.com", "", "")
                ' objWSMail.MailSendNewTech("Techclearance@NIIT-Tech.com", MailSubject, "New Joinee Added<" & strFrom & ">", "", strMailBody, "", strCC, "Developers@niit-tech.com", "")

                ''Live One
                ' objWSMail.MailSendNewTech(System.Configuration.ConfigurationManager.AppSettings("TCL"), MailSubject, "New Joinee Added<" & strFrom & ">", "", strMailBody, "", strCC, System.Configuration.ConfigurationManager.AppSettings("BCC"), "") '' Final


                'If strLANID <> "" Then
                    ' for LH  341/TTC 379 /James villas 361/ Amadeus-ITA-383 /AMEX GBT -378/Tribune Ad-Hub-342 Proceeses  Vertical Head to be Alerted
                If ((cmbProcess.SelectedValue = 341) Or (cmbProcess.SelectedValue = 379) Or (cmbProcess.SelectedValue = 361) Or (cmbProcess.SelectedValue = 383) Or (cmbProcess.SelectedValue = 378) Or (cmbProcess.SelectedValue = 342)) Then
                    strCCUnique = strCCUnique + "," + System.Configuration.ConfigurationManager.AppSettings("TravelHead")

                    Common.SMTPSendMail(System.Configuration.ConfigurationManager.AppSettings("TCL"), MailSubject, "New Joinee Added <" & strFrom & ">", strMailBody, strLANID & strCCUnique, System.Configuration.ConfigurationManager.AppSettings("WSR_PIP_ProcessManager"))

                ElseIf ((cmbProcess.SelectedValue = 205)) Then

                    strCCUnique = strCCUnique + "," + System.Configuration.ConfigurationManager.AppSettings("BFSInvestmentHead")
                    Common.SMTPSendMail(System.Configuration.ConfigurationManager.AppSettings("TCL"), MailSubject, "New Joinee Added <" & strFrom & ">", strMailBody, strLANID & strCCUnique, System.Configuration.ConfigurationManager.AppSettings("WSR_PIP_ProcessManager"))


                ElseIf ((cmbProcess.SelectedValue = 309) Or (cmbProcess.SelectedValue = 305)) Then

                    strCCUnique = strCCUnique + "," + System.Configuration.ConfigurationManager.AppSettings("BFSHead")
                    Common.SMTPSendMail(System.Configuration.ConfigurationManager.AppSettings("TCL"), MailSubject, "New Joinee Added <" & strFrom & ">", strMailBody, strLANID & strCCUnique, System.Configuration.ConfigurationManager.AppSettings("WSR_PIP_ProcessManager"))

                    'for Atrium  159 /Aflac 375  Proceeses  Vertical Head to be Alerted
                ElseIf ((cmbProcess.SelectedValue = 159) Or (cmbProcess.SelectedValue = 375)) Then

                    strCCUnique = strCCUnique + "," + System.Configuration.ConfigurationManager.AppSettings("InsuranceHead")
                    Common.SMTPSendMail(System.Configuration.ConfigurationManager.AppSettings("TCL"), MailSubject, "New Joinee Added <" & strFrom & ">", strMailBody, strLANID & strCCUnique, System.Configuration.ConfigurationManager.AppSettings("WSR_PIP_ProcessManager"))

                Else
                    Common.SMTPSendMail(System.Configuration.ConfigurationManager.AppSettings("TCL"), MailSubject, "New Joinee Added <" & strFrom & ">", strMailBody, strLANID & strCCUnique, System.Configuration.ConfigurationManager.AppSettings("WSR_PIP_ProcessManager"))


                End If


                ''Testing
                'objWSMail.MailSendNewTech("rajkumar.sharma@niit-tech.com", MailSubject, "New Joinee Added<" & strFrom & ">", "", strMailBody, "", "rajkumar.sharma@niit-tech.com", "rajkumar.sharma@niit-tech.com", "") '' Final
                ' objWSMail.MailSendNewTech("To", "Subject", "From", "DisplayName", "Body", "Attach File", "CC", "BCC", "ReplyTo")


                'objWSMail = Nothing
            End If
            SuccessMessage("Agent Details has been saved successfully !")
            Reset()
        Catch ex As Exception
            AlertMessage(ex.ToString)
            Exit Sub
        End Try
    End Sub

    Public Function GetUnique(ByVal sStringToUse As String, Optional ByVal sSeperator As String = ",", Optional ByVal LimitWords As Integer = 0) As String
        Dim sStrings() As String
        Dim sToRet As String = ""
        sStrings = sStringToUse.Split(sSeperator)
        Dim i As Integer = 0
        For Each s As String In sStrings
            Dim sTrimed As String = s.Trim()
            If Not (LimitWords < 1 OrElse i < LimitWords) Then Exit For
            If sToRet.IndexOf(sTrimed, StringComparison.CurrentCultureIgnoreCase) < 0 Then
                i += 1
                sToRet &= sTrimed & ","
            End If
        Next
        If sToRet.Length > 0 Then
            Return sToRet.ToString().Substring(0, sToRet.Length - 1)
        Else
            Return ""
        End If
    End Function

    Private Function chkSupervisorEmail() As Boolean
        Dim RegexEmail As New Regex("\w+([-+.']\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*")
        If RegexEmail.IsMatch(txtSupervisorEmail.Text).ToString Then
            Return True
        Else
            Return False
        End If
        Return True
    End Function
#End Region
#Region "--- Utility ---"
    Private Sub AlertMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMFail"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub

    Private Sub SuccessMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMSuccess"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub
#End Region

End Class
