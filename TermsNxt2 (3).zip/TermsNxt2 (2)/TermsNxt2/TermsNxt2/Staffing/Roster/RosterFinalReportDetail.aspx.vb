﻿Imports com.nss.DBAccess
Imports System.Data
Partial Class Staffing_AttendanceDetail
    Inherits System.Web.UI.Page
#Region "--- Properties ---"
    Property AgentID() As String
        Get
            Return ViewState("AgentID")
        End Get
        Set(ByVal value As String)
            ViewState("AgentID") = value
        End Set
    End Property
#End Region

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            Try
                If Session("AgentID") <> "" Then
                    AgentID = Session("AgentID")
                Else
                    ' Response.Redirect("AttendanceSummary.aspx")
                    Response.Redirect("RosterFinalReport.aspx")
                End If
                If Request.QueryString("MODE") <> "" Then
                    'If Request.QueryString("group") <> "" Then
                    fillgrid()
                Else
                    ' Response.Redirect("AttendanceSummary.aspx")
                    Response.Redirect("RosterFinalReport.aspx")
                End If
                ' PanelReports.Controls.Add(Common.GetMenu(Request.Url, AgentID, Request.ApplicationPath))
            Catch ex As Exception
                ' Response.Redirect("AttendanceSummary.aspx")
                Response.Redirect("RosterFinalReport.aspx")
            End Try
        End If
    End Sub
    Private Sub fillgrid()
        Dim db As New DBAccess
        Dim dt As New DataTable
       
        db.slDataAdd("MODE", Request.QueryString("MODE"))
        db.slDataAdd("MODEVALUE", Request.QueryString("MODEVALUE"))
        'If Request.QueryString("val").Contains("-") Then
        '    db.slDataAdd("val", Request.QueryString("val").Replace("-", "/"))
        'Else
        '    db.slDataAdd("val", Request.QueryString("val"))
        'End If

        db.slDataAdd("FromDate", Request.QueryString("from"))
        db.slDataAdd("ToDate", Request.QueryString("to"))
        ' dt = db.ReturnTable("usp_getAttendancedetail", , True)
        dt = db.ReturnTable("usp_RosterUploadSummaryDetail", , True)

        gdAttendanceDetail.DataSource = dt
        gdAttendanceDetail.DataBind()

        'If Request.QueryString("group") = 3 Then
        '    breadcrumbs.CurrentPage = " Roster Detail for " & dt.Rows(0)(0).ToString
        'ElseIf Request.QueryString("group") = 2 Then
        '    breadcrumbs.CurrentPage = " Roster Detail for " & Request.QueryString("Supervisor")
        'Else
        breadcrumbs.CurrentPage = " Roster Detail for " & Request.QueryString("MODE")
        ' End If

    End Sub
    Protected Sub ImageButton1_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton1.Click
        fillgrid()
        GridViewExportUtil.Export(breadcrumbs.CurrentPage & ".xls", Me.gdAttendanceDetail)
    End Sub

    Protected Sub btnBack_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnBack.Click
        'Response.Redirect("RosterFinalReport.aspx?value=return&Process=" & Request.QueryString("process") & "&group=" & Request.QueryString("group") & "&Period=" & Request.QueryString("Period") & "&filter=" & Request.QueryString("val") & "&FromDate=" & Request.QueryString("from") & "&ToDate=" & Request.QueryString("to"))

        Response.Redirect("RosterFinalReport.aspx?value=return" & "&group=" & Request.QueryString("MODE") & "&Period=" & Request.QueryString("Period") & "&FromDate=" & Request.QueryString("from") & "&ToDate=" & Request.QueryString("to"))

    End Sub
End Class
