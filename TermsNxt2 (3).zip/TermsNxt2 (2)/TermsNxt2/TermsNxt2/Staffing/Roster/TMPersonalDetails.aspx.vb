﻿Imports com.nss.DBAccess
Imports System.Data
Imports System.Globalization

Partial Class Staffing_Roster_TMPersonalDetails
    Inherits System.Web.UI.Page
#Region "-Properties-"
    Private Shared AddressExsist As Boolean
    Private Shared phoneNo As String
    Property AgentID() As String
        Get
            Return ViewState("AgentID")
        End Get
        Set(ByVal value As String)
            ViewState("AgentID") = value
        End Set
    End Property
    Property AgentName() As String
        Get
            Return ViewState("AgentName")
        End Get
        Set(ByVal value As String)
            ViewState("AgentName") = value
        End Set
    End Property
    Property CurrentDate() As Date
        Get
            Return ViewState("CurrentDate")
        End Get
        Set(ByVal value As Date)
            ViewState("CurrentDate") = value
        End Set
    End Property
    Public Shared Property Exsist() As Boolean
        Get
            Return AddressExsist
        End Get
        Set(ByVal value As Boolean)
            AddressExsist = value
        End Set
    End Property
#End Region
#Region "-Functions-"
    Private Sub LoadData()
        Common.FillProcessCampaigns(CboProcess, cboCampaign, Session("AgentID"))
        Dim lstProcess As New ListItem
        lstProcess.Value = 0
        lstProcess.Text = "All"
        If CboProcess.Items.Contains(lstProcess) Then
            CboProcess.Items.Remove(lstProcess)
        End If
        Dim db As New DBAccess("CRM")
        Dim dr As DataRow = db.ReturnRow("SELECT getdate() as currentdate")
        CurrentDate = dr("currentDate")
        db = Nothing
    End Sub
    Private Sub GetAllAgents()
        Dim db As New DBAccess("CRM")
        Dim dtAgents As New DataTable
        db.slDataAdd("ProcessID", CboProcess.SelectedValue)
        dtAgents = db.ReturnTable("usp_GetAgentsPersonalDetails", , True)
        db = Nothing
        gvTMDetails.DataSource = dtAgents
        gvTMDetails.DataBind()
        breadcrumbs.CurrentPage = " Team Member Personal Details "
    End Sub
    Private Sub SetSpecialCab()
        Try
            Dim dbInsert As New DBAccess("CRM")
            dbInsert.slDataAdd("Processid", CboProcess.SelectedValue)
            dbInsert.slDataAdd("AgentId", ViewState("TMID"))
            If ddlReason.SelectedIndex <> 1 Then
                dbInsert.slDataAdd("ScheduleDate", Convert.ToDateTime(ucDateFrom.Text & " " & ddlHr.SelectedValue.ToString & ":" & ddlMin.SelectedValue.ToString & ":00"))
            Else
                dbInsert.slDataAdd("ScheduleDate", CurrentDate)
            End If
            dbInsert.slDataAdd("FilledBy", ViewState("AgentID"))
            dbInsert.slDataAdd("Reason", ddlReason.SelectedItem.Text)
            dbInsert.slDataAdd("Type", ddlType.SelectedItem.Text)
            dbInsert.slDataAdd("Remarks", txtRemarks.Text)
            dbInsert.InsertinTable("tbl_data_SpecialCab")
            dbInsert = Nothing

            Dim db As New DBAccess("CRM")
            Dim dt As New DataTable
            '----------------------- Changed by Rajendra on 05th Dec'13. (Email sent to process AVP Only.)
            'Dim strCC As String
            db.slDataAdd("AgentId", ViewState("TMID"))
            db.slDataAdd("Flag", 0)
            dt = db.ReturnTable("usp_SupervisorEmails", , True)
            db = Nothing
            'strCC = dt.Rows(0).Item("MailCC")
            'strCC = strCC.ToLower.Replace(",hroperations@niitsmartserve.com", "").Replace("hroperations@niitsmartserve.com", "")
            'If strCC.Trim = "" Then
            '    strCC = "transporthelpdesk@NIITSMARTSERVE.com"
            'End If
            Dim strTo As String
            Dim strCC As String
            If dt.Rows.Count > 0 Then

                If Not Session("Lanid") Is Nothing Then
                    strTo = Session("Lanid") + "@Niit-tech.com" + "," + System.Configuration.ConfigurationManager.AppSettings("BPOTPT")
                End If
                strCC = dt.Rows(0).Item("MailCC")
                If strCC.Length > 0 Then
                    strCC = strCC.Substring(0, strCC.IndexOf(","))
                End If

                '  strTo = dt.Rows(0).Item("MailTo")


                'If Not Session("Lanid") Is Nothing Then
                '    strCC = Session("Lanid") + "@Niit-tech.com"
                'End If


                'old
                'Dim objWSMail As New MailSendServiceXX.Service1SoapClient


                Dim strFrom As String = System.Configuration.ConfigurationManager.AppSettings("FROM")
                Dim MailSubject As String = "Special Cab Request"
                Dim strMailBody As String = ""
                strMailBody += "<html xmlns='http://www.w3.org/1999/xhtml'>"
                strMailBody += "<body style='font-family: Verdana; font-size: .8em'>"
                strMailBody += "<strong>Special Cab Request for: " & ViewState("TM") & "</strong><br /><br />"
                strMailBody += "<strong>Requested By: " & AgentName & "</strong><br /><br />"
                strMailBody += "<table border='1' width='90%' style='border: 1px solid; border-collapse: collapse; font-family: Verdana; font-size: .8em'>"
                strMailBody += "<tr bgcolor='#B8CCE4'>"
                strMailBody += "<td align='center'><b>Process Name</b></td>"
                strMailBody += "<td align='center'><b>Emp. Code</b></td>"
                strMailBody += "<td align='center'><b>Emp. Name</b></td>"
                strMailBody += "<td align='center'><b>Address</b></td>"
                strMailBody += "<td align='center'><b>Phone Number</b></td>"
                strMailBody += "<td align='center'><b>Requested Date</b></td>"
                strMailBody += "<td align='center'><b>Requested Time</b></td>"
                strMailBody += "<td align='center'><b>Reason</b></td>"
                strMailBody += "<td align='center'><b>Type</b></td>"
                strMailBody += "<td align='center'><b>Remarks</b></td>"
                strMailBody += "</tr>"
                strMailBody += "<tr >"
                strMailBody += "<td align='center'>" & CboProcess.SelectedItem.Text & "</td>"
                strMailBody += "<td align='center'>" & ViewState("TMID") & "</td>"
                strMailBody += "<td align='center'>" & ViewState("TM") & "</td>"
                strMailBody += "<td align='center'>" & ViewState("Address") & "</td>"
                strMailBody += "<td align='center'>" & ViewState("Phone") & "</td>"
                strMailBody += "<td align='center'>" & ucDateFrom.Text & "</td>"
                'strMailBody += "<td align='center'>" & CurrentDate.Hour & ":" & CurrentDate.Minute & "</td>"
                strMailBody += "<td align='center'>" & ddlHr.SelectedValue.ToString & ":" & ddlMin.SelectedValue.ToString & "</td>"
                strMailBody += "<td align='center'>" & ddlReason.SelectedItem.Text & "</td>"
                strMailBody += "<td align='center'>" & ddlType.SelectedItem.Text & "</td>"
                strMailBody += "<td align='center'>" & txtRemarks.Text & "</td>"
                strMailBody += "</tr></table><br />"
                strMailBody += "<div align='left'>If you are approving authority,"
                ' strMailBody += "<a href='http://termsmonitor.niitsmartserve.com/Staffing/Roster/PendingSpecialCab.aspx'>Click Here To Approve/Reject</a></div>"
                strMailBody += "<a href='http://terms-monitor.niit-tech.com/Staffing/Roster/PendingSpecialCab.aspx?processID=" & CboProcess.SelectedValue & "&day=" & ucDateFrom.yyyymmdd & "'>Click Here To Approve/Reject</a></div>"

                strMailBody += "<br /><br /><hr/>This mail was sent using the "
                strMailBody += "<a href='http://terms-monitor.niit-tech.com/'>TermsMonitor&reg;</a> Mail Service.We request you not to reply this message."
                strMailBody += "<br /><br />In case you wish to report issues with this mail, please send mail to mailto:helpdesk@niitsmartserve.com <br /> "
                strMailBody += "<br />This e-mail is confidential and may also be privileged.If you are not the intended recipient, please notify helpdesk immediately; you should not copy or use it for any purpose,nor disclose its contents to any other person."
                strMailBody += "</body>"
                strMailBody += "</html>"


                'old format for sending Email
                'objWSMail.MailSendNewTech(strTo, MailSubject, strFrom, "Special Cab Request", strMailBody, "", strCC, System.Configuration.ConfigurationManager.AppSettings("BCC"), "") ''11Jan2018

                Common.SMTPSendMail(strTo, MailSubject, "Special Cab Request <" & strFrom & ">", strMailBody, strCC, System.Configuration.ConfigurationManager.AppSettings("WSR_PIP_ProcessManager"))

                'objWSMail = Nothing
                SuccessMessage(" Request for special cab has been sent sucessfully.")
            End If
        Catch ex As Exception
            AlertMessage(ex.ToString())
        End Try
    End Sub
    Private Sub setTime(ByVal flag As Boolean, ByVal CurTime As Boolean, ByVal SelectedIndex As Int16)
        ddlHr.Items.Clear()
        ddlMin.Items.Clear()
        Dim currenthour, currentmin As Integer
        currenthour = 0
        currentmin = 0
        If ucDateFrom.value = CurrentDate.ToShortDateString Then
            flag = False
        Else
            flag = True
        End If
        If Not flag Then
            Dim Getdate As Date
            Dim dbdatetime As New DBAccess("CRM")
            If ddlReason.SelectedIndex = 1 Then
                Getdate = dbdatetime.ReturnValue("SELECT GETDATE()", False)
            Else
                Getdate = dbdatetime.ReturnValue("SELECT DATEADD(hh,2, GETDATE())", False)
            End If
            dbdatetime = Nothing
            currenthour = Getdate.Hour
            currentmin = Getdate.Minute
            ucDateFrom.value = Getdate
        End If
        While currenthour <= 23
            If currenthour < 10 Then
                ddlHr.Items.Add("0" & currenthour.ToString)
            Else
                ddlHr.Items.Add(currenthour.ToString)
            End If
            currenthour = currenthour + 1
        End While
        If Not CurTime Then
            currentmin = 0
        End If
        While currentmin <= 59
            If currentmin < 10 Then
                ddlMin.Items.Add("0" & currentmin.ToString)
            Else
                ddlMin.Items.Add(currentmin.ToString)
            End If
            currentmin = currentmin + 1
        End While
        If SelectedIndex > 0 And flag = False Then
            ddlHr.SelectedIndex = SelectedIndex
        End If
    End Sub
    Private Function validdate(ByVal selecteddate As DateTime) As Boolean
        'If selecteddate < CurrentDate.Date Then
        '    Return False
        'Else
        '    ucDateFrom.value = selecteddate
        'End If
        Return True
    End Function
#End Region

#Region "-Event-"
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        HumanMessage.Style.Item("visibility") = "hidden"
        If Not Page.IsPostBack Then
            AgentID = Session("AgentID")
            AgentName = Session("UserName")
            PanelReports.Controls.Add(Common.GetMenu(Request.Url, AgentID, Request.ApplicationPath))
            LoadData()
            GetAllAgents()
        End If
    End Sub
    Protected Sub CboProcess_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles CboProcess.SelectedIndexChanged
        GetAllAgents()
    End Sub

    Protected Sub gvTMDetails_RowCommand(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewCommandEventArgs) Handles gvTMDetails.RowCommand

        Dim row As GridViewRow = CType(CType(e.CommandSource, Control).NamingContainer, GridViewRow)
        Dim strAgentID As String = e.CommandArgument.ToString
        Dim db As New DBAccess("CRM")
        Dim dtAgents As New DataTable
        Dim strQuery As String
        strQuery = "SELECT CampaignID,AgentID, AgentName, ISNULL(Phone,'') AS [Phone], LTRIM(RTRIM(ISNULL(Address,''))) as address, LTRIM(RTRIM(ISNULL(Gender,''))) as Gender from tbl_AgentMaster where AgentID = '" & strAgentID & "'"
        dtAgents = db.ReturnTable(strQuery, False)
        db = Nothing
        ViewState("TMName") = dtAgents.Rows(0).Item("AgentName") & "(" & dtAgents.Rows(0).Item("AgentID") & ")"
        If e.CommandName = "Cab" Then
            ViewState("TM") = dtAgents.Rows(0).Item("AgentName")
            ViewState("TMID") = dtAgents.Rows(0).Item("AgentID")
            ViewState("Address") = dtAgents.Rows(0).Item("Address")
            ViewState("Phone") = dtAgents.Rows(0).Item("Phone")
            txtRemarks.Text = "Pick From:- " & vbNewLine & vbNewLine & "Drop To:- " & vbNewLine & vbNewLine & "Others:- " & vbNewLine & vbNewLine
            setTime(False, True, 0)
            Dim str As String
            str = "$('#DialogBackground').height($(document).height()-50);$('#DialogBackground').width($(window).width());$('#DialogBackground').css('visibility','visible');$('#pnlCab').css('visibility','visible');" & _
            " $('#pnlCab').css('left',($(window).width() - $('#pnlCab').width())/2); "
            ScriptManager.RegisterStartupScript(Page, Page.GetType(), "pnlCab", str, True)
        End If
        If e.CommandName = "getAddressDetail" Then
            Dim lnk As LinkButton = gvTMDetails.Rows(row.RowIndex).FindControl("lnkAddress")
            If lnk.Text.ToString.StartsWith("Address Change Pending [") Then
                Exsist = True
            Else
                Exsist = False
            End If
            lblAgentID.Text = dtAgents.Rows(0).Item("AgentID")
            lblAgentName.Text = dtAgents.Rows(0).Item("AgentName")
            txtAddress.Text = dtAgents.Rows(0).Item("Address")
            Dim str As String
            str = "$('#DialogBackground').height($(document).height()-10);$('#DialogBackground').width($(window).width());$('#DialogBackground').css('visibility','visible');$('#PnlModify').css('visibility','visible');" & _
            " $('#PnlModify').css('left',($(window).width() - $('#PnlModify').width())/2); "
            ScriptManager.RegisterStartupScript(Page, Page.GetType(), "PnlModify", str, True)
        End If
        If e.CommandName = "getPhoneDetail" Then
            lblAgentIDPhone.Text = dtAgents.Rows(0).Item("AgentID")
            lblAgentNamePhone.Text = dtAgents.Rows(0).Item("AgentName")
            txtPhone.Text = dtAgents.Rows(0).Item("Phone")
            phoneNo = dtAgents.Rows(0).Item("Phone")
            Dim str As String
            str = "$('#DialogBackground').height($(document).height()-10);$('#DialogBackground').width($(window).width());$('#DialogBackground').css('visibility','visible');$('#pnlModifyPhone').css('visibility','visible');" & _
            " $('#pnlModifyPhone').css('left',($(window).width() - $('#pnlModifyPhone').width())/2); "
            ScriptManager.RegisterStartupScript(Page, Page.GetType(), "pnlModifyPhone", str, True)
        End If
        If e.CommandName = "getGenderDetail" Then
            lblAgentIDGender.Text = dtAgents.Rows(0).Item("AgentID")
            lblAgentNameGender.Text = dtAgents.Rows(0).Item("AgentName")
            If Not dtAgents.Rows(0).Item("Gender") = "" Then
                rblGender.SelectedValue = dtAgents.Rows(0).Item("Gender")
            Else
                rblGender.SelectedIndex = -1
            End If
            Dim str As String
            str = "$('#DialogBackground').height($(document).height()-10);$('#DialogBackground').width($(window).width());$('#DialogBackground').css('visibility','visible');$('#pnlModifyGender').css('visibility','visible');" & _
            " $('#pnlModifyGender').css('left',($(window).width() - $('#pnlModifyGender').width())/2); "
            ScriptManager.RegisterStartupScript(Page, Page.GetType(), "pnlModifyGender", str, True)
        End If
        lblRowindex.Text = row.RowIndex
    End Sub
    Protected Sub ucDateFrom_Changed(ByVal sender As Object, ByVal e As System.EventArgs) Handles ucDateFrom.Changed
        setTime(True, True, 0)
        If Not validdate(ucDateFrom.value) Then
            AlertMessage("Date not in valid range.")
            ucDateFrom.value = CurrentDate
            setTime(False, True, 0)
        End If
        Dim str As String
        str = "$('#DialogBackground').height($(document).height()-50);$('#DialogBackground').width($(window).width());$('#DialogBackground').css('visibility','visible');$('#pnlCab').css('visibility','visible');" & _
            " $('#pnlCab').css('left',($(window).width() - $('#pnlCab').width())/2); "
        ScriptManager.RegisterStartupScript(Page, Page.GetType(), "PnlModify", str, True)
    End Sub
    Protected Sub btnUpdate_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnUpdate.Click

        Try

            '' ''Dim db As New DBAccess("CRM")

            '' ''db.slDataAdd("AgentId", lblAgentID.Text)
            '' ''db.slDataAdd("AgentName", lblAgentName.Text)
            '' ''db.slDataAdd("ProcessID", CboProcess.SelectedItem.Value)

            '' ''If Exsist Then
            '' ''    db.slDataAdd("Address", txtAddress.Text.Trim)
            '' ''End If

            '' ''db.slDataAdd("ProcessID", CboProcess.SelectedItem.Value)
            '' ''db.slDataAdd("isBreak", 0)
            '' ''db.slDataAdd("RequestedDate", System.DateTime.Now.ToString()) 'Logging out
            '' ''db.Executeproc("usp_UpdateAgentLog")
            '' ''db = Nothing
            '' ''SuccessMessage(TreeView1.SelectedNode.Text + " Logout Successfully")

            ' '' ''select    AgentID	,AgentName,	Gender,	ProjectName	,TransportSpoc	,Address	,Contact ,	RequestedDate from tbl_RosterAddress

            '' ''Dim db As New DBAccess("CRM")
            '' ''Dim IniitianUpdate As String
            '' ''db.slDataAdd("Address", txtAddress.Text.Trim)


            '' ''db.slDataAdd("RequestedBy", ViewState("AgentID"))
            '' ''If Exsist Then
            '' ''    db.UpdateinTable("tbl_tempAddressUpdate", "AgentID = '" & lblAgentID.Text & "'")
            '' ''Else
            '' ''    db.slDataAdd("AgentID", lblAgentID.Text)
            '' ''    db.slDataAdd("AgentName", lblAgentName.Text)
            '' ''    db.slDataAdd("ProcessID", CboProcess.SelectedItem.Value)
            '' ''    db.InsertinTable("tbl_tempAddressUpdate")
            '' ''End If
            '' ''db = Nothing





            'Dim db As New DBAccess("CRM")
            'Dim IniitianUpdate As String
            'db.slDataAdd("tempAddress", txtAddress.Text.Trim)

            'If chkAddressUpdateIniitian.Checked Then
            '    IniitianUpdate = "Yes"
            '    db.slDataAdd("UpdatedOnIniitian", 1)
            'Else
            '    IniitianUpdate = "No"
            '    db.slDataAdd("UpdatedOnIniitian", 0)
            'End If

            'db.slDataAdd("RequestedBy", ViewState("AgentID"))
            'If Exsist Then
            '    db.UpdateinTable("tbl_tempAddressUpdate", "AgentID = '" & lblAgentID.Text & "'")
            'Else
            '    db.slDataAdd("AgentID", lblAgentID.Text)
            '    db.slDataAdd("AgentName", lblAgentName.Text)
            '    db.slDataAdd("ProcessID", CboProcess.SelectedItem.Value)
            '    db.InsertinTable("tbl_tempAddressUpdate")
            'End If
            'db = Nothing

            Dim HiddenAddress As HiddenField = gvTMDetails.Rows(lblRowindex.Text).FindControl("hiddenAddress")
            '  Dim objWSMail As New Shootmail_New.Service1
            'Dim objWSMail As New MailSendServiceXX.Service1SoapClient

            Dim strFrom As String = System.Configuration.ConfigurationManager.AppSettings("FROM")
            Dim MailSubject As String = "Address Change Request"
            Dim strMailBody As String = ""
            strMailBody += "<html xmlns='http://www.w3.org/1999/xhtml'>"
            strMailBody += "<body style='font-family: Verdana; font-size: .8em'>"
            strMailBody += "<strong>Address change Request for: " & lblAgentName.Text & " (" & lblAgentID.Text & ")</strong><br /><br />"
            strMailBody += "<strong>Requested By: " & AgentName & "</strong><br /><br />"
            strMailBody += "<table border='1' width='90%' style='border: 1px solid; border-collapse: collapse; font-family: Verdana; font-size: .8em'>"
            strMailBody += "<tr bgcolor='#B8CCE4'>"
            strMailBody += "<td align='center'><b>Process Name</b></td>"
            strMailBody += "<td align='center'><b>Emp. Code</b></td>"
            strMailBody += "<td align='center'><b>Emp. Name</b></td>"
            strMailBody += "<td align='center'><b>Previous Address</b></td>"
            strMailBody += "<td align='center'><b>New Address</b></td>"
            strMailBody += "<td align='center'><b>Updated on iniitian</b></td>"
            strMailBody += "</tr>"
            strMailBody += "<tr >"
            strMailBody += "<td align='center'>" & CboProcess.SelectedItem.Text & "</td>"
            strMailBody += "<td align='center'>" & lblAgentID.Text & "</td>"
            strMailBody += "<td align='center'>" & lblAgentName.Text & "</td>"
            strMailBody += "<td align='center'>" & HiddenAddress.Value & "</td>"
            strMailBody += "<td align='center'>" & txtAddress.Text.Trim & "</td>"
            'strMailBody += "<td align='center'>" & IniitianUpdate & "</td>"
            strMailBody += "</tr></table><br />"
            strMailBody += "<div align='left'>If you are approving authority,"
            strMailBody += "<a href='http://termsmonitor.coforge.com/Staffing/Roster/PendingAddressChange.aspx'>Click Here To Approve/Reject</a></div>"
            strMailBody += "<br /><br /><hr/>This mail was sent using the "
            strMailBody += "<a href='http://termsmonitor.coforge.com/'>TermsMonitor&reg;</a> Mail Service.We request you not to reply this message."
            strMailBody += "<br /><br />In case you wish to report issues with this mail, please send mail to mailto:helpdesk@niitsmartserve.com <br /> "
            strMailBody += "<br />This e-mail is confidential and may also be privileged.If you are not the intended recipient, please notify helpdesk immediately; you should not copy or use it for any purpose,nor disclose its contents to any other person."
            strMailBody += "</body>"
            strMailBody += "</html>"
            ' objWSMail.MailSend("transporthelpdesk@NIITSMARTSERVE.com", MailSubject, strFrom, "Address Change Request", strMailBody, "", "", "")
            'objWSMail.MailSend("gauravs@NIITSMARTSERVE.com", MailSubject, strFrom, "Contact Number Update", strMailBody, "", "gauravs@NIITSMARTSERVE.com", "gaurav.srivastava@niit-tech.com")

            '  objWSMail.MailSendNewTech(System.Configuration.ConfigurationManager.AppSettings("BPOHELPDESK"), MailSubject, strFrom, "Address Change Request", strMailBody, "", "", System.Configuration.ConfigurationManager.AppSettings("BCC"), "") ''11Jan2018


            'Common.SMTPSendMail(System.Configuration.ConfigurationManager.AppSettings("BPOHELPDESK"), MailSubject, "Address Change Request <" & strFrom & ">", strMailBody, System.Configuration.ConfigurationManager.AppSettings("WSR_PIP_ProcessManager"), System.Configuration.ConfigurationManager.AppSettings("WSR_PIP_ProcessManager"))

            ' objWSMail = Nothing
            'lnk.Text = lnk.Text.Trim & " (Address Change Pending)"
            SuccessMessage(" Address change request has been sent for: " & lblAgentName.Text & "(" & lblAgentID.Text & ")")
            GetAllAgents()
        Catch ex As Exception
            AlertMessage(ex.Message.ToString)
        End Try
    End Sub
    Protected Sub btnUpdatePhone_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnUpdatePhone.Click
        Try
            Dim db As New DBAccess("CRM")
            Dim dtSupervisorMail As DataTable
            dtSupervisorMail = db.ReturnTable("select EmailId FROM [dbo].[tbl_Config_SupervisorsEmail] WHERE AgentID= '" & Session("AgentID") & "'", , False)
            db = Nothing
            db = New DBAccess("CRM")
            Dim dtAgents As New DataTable
            db.slDataAdd("Phone", txtPhone.Text.Trim)
            db.UpdateinTable("tbl_AgentMaster", "AgentID = '" & lblAgentIDPhone.Text & "'")
            db = Nothing
            '  Dim objWSMail As New Shootmail_New.Service1
            'Dim objWSMail As New MailSendServiceXX.Service1SoapClient

            Dim strFrom As String = System.Configuration.ConfigurationManager.AppSettings("FROM")
            Dim MailSubject As String = "Contact Number Update"
            Dim strMailBody As String = ""
            strMailBody += "<html xmlns='http://www.w3.org/1999/xhtml'>"
            strMailBody += "<body style='font-family: Verdana; font-size: .8em'>"
            strMailBody += "<strong>Contact Number has been Updated for: " & lblAgentNamePhone.Text & " (" & lblAgentIDPhone.Text & ")</strong><br /><br />"
            strMailBody += "<strong>Updated By: " & AgentName & "</strong><br /><br />"
            strMailBody += "<table border='1' width='90%' style='border: 1px solid; border-collapse: collapse; font-family: Verdana; font-size: .8em'>"
            strMailBody += "<tr bgcolor='#B8CCE4'>"
            strMailBody += "<td align='center'><b>Process Name</b></td>"
            strMailBody += "<td align='center'><b>Emp. Code</b></td>"
            strMailBody += "<td align='center'><b>Emp. Name</b></td>"
            strMailBody += "<td align='center'><b>Previous Number</b></td>"
            strMailBody += "<td align='center'><b>New Number</b></td>"
            strMailBody += "</tr>"
            strMailBody += "<tr>"
            strMailBody += "<td align='center'>" & CboProcess.SelectedItem.Text & "</td>"
            strMailBody += "<td align='center'>" & lblAgentIDPhone.Text & "</td>"
            strMailBody += "<td align='center'>" & lblAgentNamePhone.Text & "</td>"
            strMailBody += "<td align='center'>" & phoneNo & "</td>"
            strMailBody += "<td align='center'>" & txtPhone.Text.Trim & "</td>"
            strMailBody += "</tr></table><br />"
            strMailBody += "<br /><br /><hr/>This mail was sent using the "
            strMailBody += "<a href='http://termsmonitor.niitsmartserve.com/'>TermsMonitor&reg;</a> Mail Service.We request you not to reply this message."
            strMailBody += "<br /><br />In case you wish to report issues with this mail, please send mail to mailto:helpdesk@niitsmartserve.com <br /> "
            strMailBody += "<br />This e-mail is confidential and may also be privileged.If you are not the intended recipient, please notify helpdesk immediately; you should not copy or use it for any purpose,nor disclose its contents to any other person."
            strMailBody += "</body>"
            strMailBody += "</html>"
            '  objWSMail.MailSend("transporthelpdesk@NIITSMARTSERVE.com", MailSubject, strFrom, "Contact Number Update", strMailBody, "", dtSupervisorMail.Rows(0)("EmailId").ToString, "")
            'objWSMail.MailSend("gauravs@NIITSMARTSERVE.com", MailSubject, strFrom, "Contact Number Update", strMailBody, "", "gauravs@NIITSMARTSERVE.com", "gaurav.srivastava@niit-tech.com")

            'objWSMail.MailSendNewTech(System.Configuration.ConfigurationManager.AppSettings("BPOTPT"), MailSubject, strFrom, "Contact Number Update", strMailBody, "", dtSupervisorMail.Rows(0)("EmailId").ToString, "", "") ''11Jan2018

            Common.SMTPSendMail(System.Configuration.ConfigurationManager.AppSettings("BPOTPT"), MailSubject, "Contact Number Update <" & strFrom & ">", strMailBody.ToString(), dtSupervisorMail.Rows(0)("EmailId").ToString, System.Configuration.ConfigurationManager.AppSettings("WSR_PIP_ProcessManager"))
            'objWSMail = Nothing
            SuccessMessage(" Data has been updated for: " & ViewState("TMName"))
            GetAllAgents()
        Catch ex As Exception
            AlertMessage(ex.Message.ToString)
        End Try
    End Sub
    Protected Sub btnUpdateGender_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnUpdateGender.Click
        Try
            Dim db As New DBAccess("CRM")
            Dim dtAgents As New DataTable
            db.slDataAdd("Gender", rblGender.SelectedItem.Value)
            db.UpdateinTable("tbl_AgentMaster", "AgentID = '" & lblAgentIDGender.Text & "'")
            db = Nothing
            GetAllAgents()
            SuccessMessage(" Data has been updated for: " & ViewState("TMName"))
        Catch ex As Exception
            AlertMessage(ex.Message.ToString)
        End Try
    End Sub
    Protected Sub btnSpecialCab_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnSpecialCab.Click
        If Not txtRemarks.Text.Trim = "" Then
            SetSpecialCab()
        Else
            AlertMessage("Please fill Remark")
            Dim str As String
            str = "$('#DialogBackground').height($(document).height()-50);$('#DialogBackground').width($(window).width());$('#DialogBackground').css('visibility','visible');$('#pnlCab').css('visibility','visible');" & _
                " $('#pnlCab').css('left',($(window).width() - $('#pnlCab').width())/2); "
            ScriptManager.RegisterStartupScript(Page, Page.GetType(), "PnlModify", str, True)
        End If
    End Sub
    Protected Sub ddlHr_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ddlHr.SelectedIndexChanged
        Dim val As Boolean = True
        If ddlHr.SelectedIndex > 0 Then
            val = False
        End If
        If ucDateFrom.value = CurrentDate.ToShortDateString Then
            setTime(False, val, ddlHr.SelectedIndex)
        End If
        Dim str As String
        str = "$('#DialogBackground').height($(document).height()-50);$('#DialogBackground').width($(window).width());$('#DialogBackground').css('visibility','visible');$('#pnlCab').css('visibility','visible');" & _
            " $('#pnlCab').css('left',($(window).width() - $('#pnlCab').width())/2); "
        ScriptManager.RegisterStartupScript(Page, Page.GetType(), "PnlModify", str, True)
    End Sub
    Protected Sub ddlReason_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ddlReason.SelectedIndexChanged
        If ddlReason.SelectedIndex = 1 Then            ' 1 for Medical emergency
            Label3.Visible = False
            Label12.Visible = False
            Label13.Visible = False
            ddlHr.Visible = False
            ddlMin.Visible = False
            Label1.Visible = False
            Label2.Visible = False
            ucDateFrom.Visible = False
        Else
            Label3.Visible = True
            Label12.Visible = True
            Label13.Visible = True
            ddlHr.Visible = True
            ddlMin.Visible = True
            Label1.Visible = True
            Label2.Visible = True
            ucDateFrom.Visible = True
            Dim val As Boolean = True
            If ddlHr.SelectedIndex > 0 Then
                val = False
            End If
            If ucDateFrom.value = CurrentDate.ToShortDateString Then
                setTime(False, val, ddlHr.SelectedIndex)
            End If
        End If
        Dim str As String
        str = "$('#DialogBackground').height($(document).height()-50);$('#DialogBackground').width($(window).width());$('#DialogBackground').css('visibility','visible');$('#pnlCab').css('visibility','visible');" & _
            " $('#pnlCab').css('left',($(window).width() - $('#pnlCab').width())/2); "
        ScriptManager.RegisterStartupScript(Page, Page.GetType(), "PnlModify", str, True)
    End Sub
#End Region
#Region "--- Utility ---"
    Private Sub AlertMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMFail"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub

    Private Sub SuccessMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMSuccess"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub
#End Region

    'Protected Sub ImageButton1_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton1.Click
    '    GetAllAgents()
    '    GridViewExportUtil.Export(breadcrumbs.CurrentPage & ".xls", Me.gvTMDetails)
    'End Sub
End Class
