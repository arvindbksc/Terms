﻿Imports com.nss.DBAccess
Imports System.Data
Partial Class Staffing_Roster_PendingAddressChange
    Inherits System.Web.UI.Page
#Region "Properties"
    Property CampaignID() As Integer
        Get
            Return ViewState("CampaignID")
        End Get
        Set(ByVal value As Integer)
            ViewState("CampaignID") = value
        End Set
    End Property
    Property AgentID() As String
        Get
            Return ViewState("AgentID")
        End Get
        Set(ByVal value As String)
            ViewState("AgentID") = value
        End Set
    End Property
#End Region
#Region "Functions"
    Private Sub fillgrid()
        Dim db As New DBAccess("CRM")
        Dim dt As DataTable
        dt = db.ReturnTable("usp_getAddressDetails", , True)
        breadcrumbs.CurrentPage = " Pending Address "
        db = Nothing
        GdPendingAddress.DataSource = dt
        GdPendingAddress.DataBind()
        GdPendingAddress.Columns(0).Visible = False
    End Sub
#End Region
#Region "Grid Ops"
    Protected Sub GdPendingAddress_RowCommand(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewCommandEventArgs) Handles GdPendingAddress.RowCommand
        Dim row As GridViewRow = CType(CType(e.CommandSource, Control).NamingContainer, GridViewRow)
        lblRowindex.Text = row.RowIndex
        Dim lbl1 As Label = GdPendingAddress.Rows(lblRowindex.Text).FindControl("lblAgentID")
        Dim lbl2 As Label = GdPendingAddress.Rows(lblRowindex.Text).FindControl("lblAgentName")
        Dim lbl3 As Label = GdPendingAddress.Rows(lblRowindex.Text).FindControl("lblProcess")
        Dim lbl4 As Label = GdPendingAddress.Rows(lblRowindex.Text).FindControl("lblNewAddress")
        Dim lnk As LinkButton = GdPendingAddress.Rows(lblRowindex.Text).FindControl("lnkHiring")
        Dim db As New DBAccess("CRM")
        If e.CommandName = "HiringApprove" Then
            If CampaignID <> 94 Then   ' 94 for Admin
                AlertMessage(" Only Transport / Admin can define Hiring Zone.")
                Exit Sub
            End If
            If CType(row.FindControl("lblAStatus"), Label).Text = "Rejected" Or CType(row.FindControl("lblAStatus"), Label).Text = "Approved" Then
                AlertMessage("Operation can not be performed: HR-Team has already approved the new address")
                Exit Sub
            End If
            lblHiringAgentID.Text = lbl1.Text
            lblHiringAgentName.Text = lbl2.Text
            lblHiringProcess.Text = lbl3.Text
            lblHiringAddress.Text = lbl4.Text
            If lnk.Text = "Pending" Then
                rblHiring.SelectedIndex = -1
            ElseIf lnk.Text = "Yes" Then
                rblHiring.SelectedIndex = 0
            Else
                rblHiring.SelectedIndex = 1
            End If
            Dim str As String
            str = "$('#DialogBackground').height($(document).height()-10);$('#DialogBackground').width($(window).width());$('#DialogBackground').css('visibility','visible');$('#pnlApproveHiringZone').css('visibility','visible');" & _
            " $('#pnlApproveHiringZone').css('left',($(window).width() - $('#pnlApproveHiringZone').width())/2); "
            ScriptManager.RegisterStartupScript(Page, Page.GetType(), "pnlApproveHiringZone", str, True)
        End If
        Dim dbManager As New DBAccess("CRM")
        If e.CommandName = "AddressApprove" Then
            If Not lnk.Text = "Pending" And Not lnk.Text = "No" Then
                Dim IsHR As Boolean = dbManager.ReturnValue("SELECT IsHR FROM tbl_AgentMaster WHERE AgentID = '" & AgentID & "'", False)
                dbManager = Nothing
                'If IsHR Then
                If CampaignID = 94 Then
                    row.FindControl("lnkAddressApprove").Visible = False
                    row.FindControl("lnkAddressReject").Visible = False
                    row.FindControl("lblAStatus").Visible = True
                    CType(row.FindControl("lblAStatus"), Label).Text = "Approved"
                    db.slDataAdd("IsHrApproved", 1)
                    db.slDataAdd("AddressApprovedBy", AgentID)
                    db.UpdateinTable("tbl_tempAddressUpdate", "AgentID = '" & lbl1.Text & "'")

                    Dim db1 As New DBAccess("CRM")
                    db1.slDataAdd("Address", lbl4.Text)
                    db1.UpdateinTable("tbl_AgentMaster", "AgentID = '" & lbl1.Text & "'")
                    db1 = Nothing
                    SuccessMessage(" Address Approved for: " & lbl2.Text & "(" & lbl1.Text & ")")
                Else
                    'AlertMessage(" Only HR can approve this request.")
                    AlertMessage(" Only Admin can approve this request.")
                    Exit Sub
                End If
            Else
                AlertMessage(" Invalid operation: Transport has rejected the Hiring zone or yet not approved")
                Exit Sub
            End If
        ElseIf e.CommandName = "AddressReject" Then
            Dim IsHR As Boolean = dbManager.ReturnValue("SELECT IsHR FROM tbl_AgentMaster WHERE AgentID = '" & AgentID & "'", False)
            dbManager = Nothing
            'If IsHR Then
            If CampaignID = 94 Then
                row.FindControl("lnkAddressApprove").Visible = False
                row.FindControl("lnkAddressReject").Visible = False
                row.FindControl("lblAStatus").Visible = True
                CType(row.FindControl("lblAStatus"), Label).Text = "Rejected"
                db.slDataAdd("IsHrApproved", 0)
                db.slDataAdd("AddressApprovedBy", AgentID)
                db.UpdateinTable("tbl_tempAddressUpdate", "AgentID = '" & lbl1.Text & "'")
                SuccessMessage(" Address Rejected for: " & lbl2.Text & "(" & lbl1.Text & ")")
            Else
                'AlertMessage(" Only HR can reject this request.")
                AlertMessage(" Only Admin can reject this request.")
                Exit Sub
            End If
        End If
        db = Nothing
        fillgrid()
    End Sub
    Protected Sub GdPendingAddress_RowDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles GdPendingAddress.RowDataBound
        If e.Row.RowType = DataControlRowType.DataRow Then
            Dim row As DataRow = CType(e.Row.DataItem, System.Data.DataRowView).Row
            If row("IsHrApproved") = "Approved" Then
                e.Row.FindControl("lnkAddressApprove").Visible = False
                e.Row.FindControl("lnkAddressReject").Visible = False
                e.Row.FindControl("lblAStatus").Visible = True
                CType(e.Row.FindControl("lblAStatus"), Label).Text = "Approved "
            ElseIf row("IsHrApproved").ToString = "Rejected" Then
                e.Row.FindControl("lnkAddressApprove").Visible = False
                e.Row.FindControl("lnkAddressReject").Visible = False
                e.Row.FindControl("lblAStatus").Visible = True
                CType(e.Row.FindControl("lblAStatus"), Label).Text = "Rejected "
            Else
                e.Row.FindControl("lnkAddressApprove").Visible = True
                e.Row.FindControl("lnkAddressReject").Visible = True
            End If

            If row("IsHrApproved") = "Approved" Then
                e.Row.FindControl("lnkAddressApprove").Visible = False
                e.Row.FindControl("lnkAddressReject").Visible = False
                e.Row.FindControl("lblAStatus").Visible = True
                CType(e.Row.FindControl("lblAStatus"), Label).Text = "Approved "
            ElseIf row("IsHrApproved").ToString = "Rejected" Then
                e.Row.FindControl("lnkAddressApprove").Visible = False
                e.Row.FindControl("lnkAddressReject").Visible = False
                e.Row.FindControl("lblAStatus").Visible = True
                CType(e.Row.FindControl("lblAStatus"), Label).Text = "Rejected "
            Else
                e.Row.FindControl("lnkAddressApprove").Visible = True
                e.Row.FindControl("lnkAddressReject").Visible = True
            End If
        End If
    End Sub
#End Region
#Region "Utility"
    Private Sub AlertMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMFail"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub

    Private Sub SuccessMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMSuccess"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub
#End Region
#Region "Events"
    Protected Sub btnUpdateHiring_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnUpdateHiring.Click
        Try
            If rblHiring.SelectedIndex > -1 Then
                Dim db As New DBAccess("CRM")
                Dim dtAgents As New DataTable
                db.slDataAdd("IsHiringZone", rblHiring.SelectedItem.Value)
                db.slDataAdd("HiringApprovedBy", AgentID)
                db.slDataAdd("HiringZoneRemark", txtRemarks.Text.Trim)
                db.UpdateinTable("tbl_tempAddressUpdate", "AgentID = '" & lblHiringAgentID.Text & "'")
                db = Nothing
                fillgrid()
                SuccessMessage(" Hiring Zone has been updated for: " & lblHiringAgentName.Text & "(" & lblHiringAgentID.Text & ")")
            Else
                AlertMessage("Please select the address is Hiring or Not")
            End If
        Catch ex As Exception
            AlertMessage(ex.Message.ToString)
        End Try
    End Sub
    Protected Sub imgfav_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles imgfav.Click
        Common.AddToFav(AgentID, "Pending Address Change")
        SuccessMessage("Report has been added to your favourite list")
        fillgrid()
    End Sub
#End Region
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        HumanMessage.Style.Item("visibility") = "hidden"
        If Not IsPostBack Then
            If Session("AgentID") <> "" Then
                CampaignID = Session("CampaignID")
                AgentID = Session("AgentID")
                PanelReports.Controls.Add(Common.GetMenu(Request.Url, AgentID, Request.ApplicationPath))
                fillgrid()
            End If
        End If
    End Sub

End Class
