﻿Imports com.nss.DBAccess
Imports System.Data
Partial Class PerfSum_GetRoster
    Inherits System.Web.UI.Page
#Region "-----Properties-----"

    Property CurrentDate() As Date
        Get
            Return ViewState("CurrentDate")
        End Get
        Set(ByVal value As Date)
            ViewState("CurrentDate") = value
        End Set
    End Property
    'Property RosterDate() As Date
    '    Get
    '        Return ViewState("RosterDate")
    '    End Get
    '    Set(ByVal value As Date)
    '        ViewState("RosterDate") = value
    '    End Set
    'End Property
    Property RosterDate() As Int64
        Get
            Return ViewState("RosterDate")
        End Get
        Set(ByVal value As Int64)
            ViewState("RosterDate") = value
        End Set
    End Property

    Property MinDate() As Date
        Get
            Return ViewState("MinDate")
        End Get
        Set(ByVal value As Date)
            ViewState("MinDate") = value
        End Set
    End Property

    Property ReportType() As Integer
        Get
            Return ViewState("ReportType")
        End Get
        Set(ByVal value As Integer)
            ViewState("ReportType") = value
        End Set
    End Property

    Property CurrentLevel() As Integer
        Get
            Return ViewState("CurrentLevel")
        End Get
        Set(ByVal value As Integer)
            ViewState("CurrentLevel") = value
        End Set
    End Property
    Property SupervisorID() As String
        Get
            Return ViewState("SupervisorID")
        End Get
        Set(ByVal value As String)
            ViewState("SupervisorID") = value
        End Set
    End Property
    Property UserID() As String
        Get
            Return ViewState("UserID")
        End Get
        Set(ByVal value As String)
            ViewState("UserID") = value
        End Set
    End Property
    Property AgentID() As String
        Get
            Return ViewState("AgentID")
        End Get
        Set(ByVal value As String)
            ViewState("AgentID") = value
        End Set
    End Property
    Property dtprevweek() As DataTable
        Get
            Return ViewState("dtprevweek")
        End Get
        Set(ByVal value As DataTable)
            ViewState("dtprevweek") = value
        End Set
    End Property
#End Region
#Region "Load"
    Private Sub getroster()
        Dim db As New DBAccess("report")
        Dim dt As DataTable
        RosterDate = ucDateFrom.yyyymmdd
        db.slDataAdd("RosterDate", RosterDate)
        If Cboshiftin.SelectedItem.Text = "All" Then
            db.slDataAdd("Shiftin", "0")
        ElseIf Cboshiftin.SelectedItem.Text = "Master Sheet" Then
            db.slDataAdd("Shiftin", "Master")
        Else
            db.slDataAdd("Shiftin", Cboshiftin.SelectedItem.Text.Substring(0, Cboshiftin.SelectedItem.Text.IndexOf("(")))
        End If
        dt = db.ReturnTable("usp_getRoster", , True)
        db = Nothing
        gdroster.AutoGenerateColumns = True
        If dt.Rows.Count > 0 Then
            gdroster.DataSource = dt.DefaultView
            gdroster.DataBind()
        Else
            gdroster.DataSource = Nothing
            gdroster.DataBind()
        End If
    End Sub
    Private Sub getshift()
        Dim db As New DBAccess("CRM")
        Dim dtshift As DataTable
        'dtshift = db.ReturnTable("select ShiftId, Shift +'('+ convert(varchar,TimeIn) + ' To ' +CONVERT(varchar,[TimeOut]) +')' As Shift  from tbl_Config_RosterShift order by shiftid", , False)
        dtshift = db.ReturnTable("usp_getRosterShifts", , True)
        db = Nothing
        Dim dr, dr1 As DataRow
        dr = dtshift.NewRow
        dr("Shift") = "All"
        dr("ShiftId") = 0
        dtshift.Rows.Add(dr)
        dr1 = dtshift.NewRow
        dr1("Shift") = "Master Sheet"
        dr1("ShiftId") = dtshift.Rows.Count + 1
        dtshift.Rows.Add(dr1)
        Cboshiftin.DataTextField = "Shift"
        Cboshiftin.DataValueField = "shiftid"
        Cboshiftin.DataSource = dtshift.DefaultView
        Cboshiftin.DataBind()
    End Sub
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            AgentID = Session("Agentid")
            PanelReports.Controls.Add(Common.GetMenu(Request.Url, AgentID, Request.ApplicationPath))
            SupervisorID = Session("UserID")
            UserID = Session("UserID")
            Dim dbdate As New DBAccess("CRM")
            Dim a As DateTime
            a = dbdate.ReturnValue("select getdate()", False)
            dbdate = Nothing
            ucDateFrom.value = a.ToString("dd-MMM-yyyy")
            getshift()
            getroster()
            lblReportName.CurrentPage = "Roster Detail"
        End If
    End Sub
#End Region
    
#Region "Event"
    Protected Sub btnRefresh_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnRefresh.Click
        getroster()
    End Sub
    Protected Sub ucDateFrom_Changed(ByVal sender As Object, ByVal e As System.EventArgs) Handles ucDateFrom.Changed
        getroster()
    End Sub
    Protected Sub ImageButton1_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton1.Click
        getroster()
        GridViewExportUtil.Export(lblReportName.CurrentPage & ".xls", Me.gdroster)
    End Sub
    Private Sub ExportToexcel()
        Dim tw As New IO.StringWriter()
        Dim hw As New System.Web.UI.HtmlTextWriter(tw)
        'Dim frm As HtmlForm = New HtmlForm()
        Response.ContentType = "application/vnd.ms-excel"
        Response.AddHeader("content-disposition", "attachment;filename=" & lblReportName.CurrentPage & ".xls")
        Response.Charset = ""
        EnableViewState = False
        'Controls.Add(frm)
        gdroster.RenderControl(hw)
        Response.Write(tw.ToString())
        Response.End()
    End Sub
    Protected Sub Cboshiftin_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles Cboshiftin.SelectedIndexChanged
        getroster()
    End Sub
#End Region

    
End Class
