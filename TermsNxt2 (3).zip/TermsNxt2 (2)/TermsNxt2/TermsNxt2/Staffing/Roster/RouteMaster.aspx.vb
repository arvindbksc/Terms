﻿Imports com.nss.DBAccess
Imports System.Data
Partial Class PerfSum_RouteMaster
    Inherits System.Web.UI.Page
#Region "-----Properties-----"

    Property CurrentDate() As Date
        Get
            Return ViewState("CurrentDate")
        End Get
        Set(ByVal value As Date)
            ViewState("CurrentDate") = value
        End Set
    End Property
    Property RosterDate() As Date
        Get
            Return ViewState("RosterDate")
        End Get
        Set(ByVal value As Date)
            ViewState("RosterDate") = value
        End Set
    End Property

    Property MinDate() As Date
        Get
            Return ViewState("MinDate")
        End Get
        Set(ByVal value As Date)
            ViewState("MinDate") = value
        End Set
    End Property

    Property ReportType() As Integer
        Get
            Return ViewState("ReportType")
        End Get
        Set(ByVal value As Integer)
            ViewState("ReportType") = value
        End Set
    End Property

    Property CurrentLevel() As Integer
        Get
            Return ViewState("CurrentLevel")
        End Get
        Set(ByVal value As Integer)
            ViewState("CurrentLevel") = value
        End Set
    End Property
    Property SupervisorID() As String
        Get
            Return ViewState("SupervisorID")
        End Get
        Set(ByVal value As String)
            ViewState("SupervisorID") = value
        End Set
    End Property
    Property UserID() As String
        Get
            Return ViewState("UserID")
        End Get
        Set(ByVal value As String)
            ViewState("UserID") = value
        End Set
    End Property
    Property AgentID() As String
        Get
            Return ViewState("AgentID")
        End Get
        Set(ByVal value As String)
            ViewState("AgentID") = value
        End Set
    End Property
    Property dtprevweek() As DataTable
        Get
            Return ViewState("dtprevweek")
        End Get
        Set(ByVal value As DataTable)
            ViewState("dtprevweek") = value
        End Set
    End Property
#End Region
#Region "Load"
    Private Sub getroute()
        Dim db As New DBAccess("CRM")
        Dim dt As DataTable = db.ReturnTable("select * from tbl_Config_Route", , False)
        If dt.Rows.Count > 0 Then
            gdroute.DataSource = dt.DefaultView
            gdroute.DataBind()
        End If
        gdroute.AutoGenerateColumns = True
        'gdroute.Columns(1).Visible = False
    End Sub
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            AgentID = Session("Agentid")
            PanelReports.Controls.Add(Common.GetMenu(Request.Url, AgentID, Request.ApplicationPath))
            SupervisorID = Session("UserID")
            UserID = Session("UserID")
            getroute()
            lblReportName.CurrentPage = "Route Master"
        End If
    End Sub
#End Region
#Region "Gridops"
    Protected Sub gdroute_RowCommand(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewCommandEventArgs) Handles gdroute.RowCommand
        Dim currentcommand As String = e.CommandName
        Dim currentrowindex As Integer = Int32.Parse(e.CommandArgument)
        Dim routeid As String = gdroute.DataKeys(currentrowindex).Value

        If currentcommand = "Editroute" Then
            Dim str1 As String
            str1 = "$('#DialogBackground').height($(document).height()-10);$('#DialogBackground').width($(window).width());$('#DialogBackground').css('visibility','visible');$('#pnleditroute').css('visibility','visible');" & _
            " $('#pnleditroute').css('left',($(window).width() - $('#pnleditroute').width())/2); "
            ScriptManager.RegisterStartupScript(Page, Page.GetType(), "Movedialog", str1, True)
            Dim db As New DBAccess("CRM")
            Dim dr As DataRow
            Dim strsql As String
            strsql = "select * from tbl_Config_Route where routeid='" & routeid & "'"
            dr = db.ReturnRow(strsql, False)
            db = Nothing
            Label5.Text = routeid
            txteditroute.Text = dr.Item("RouteName").ToString
            txteditroutedesc.Text = dr.Item("Routedesc").ToString
            dr = Nothing
        End If
    End Sub
#End Region
#Region "Event"
    Protected Sub lnkroute_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles lnkroute.Click
        Dim str As String
        str = "$('#DialogBackground').height($(document).height()-10);$('#DialogBackground').width($(window).width());$('#DialogBackground').css('visibility','visible');$('#PanelRoute').css('visibility','visible');" & _
        " $('#PanelRoute').css('left',($(window).width() - $('#PanelRoute').width())/2); "
        ScriptManager.RegisterStartupScript(Page, Page.GetType(), "Movedialog", str, True)
    End Sub
    Protected Sub btnRoute_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnRoute.Click
        Dim db As New DBAccess("CRM")
        Dim dt As DataTable = db.ReturnTable("select * from tbl_Config_Route where routename='" & txtRoute.Text.Trim & "'", , False)
        If dt.Rows.Count > 0 Then
            AlertMessage("Route already exist")
        Else
            db.slDataAdd("RouteName", txtRoute.Text.Trim)
            db.slDataAdd("Routedesc", txtroutedesc.Text.Trim)
            db.InsertinTable("tbl_Config_Route")

        End If
        db = Nothing
        getroute()
    End Sub
    Protected Sub btneditroute_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btneditroute.Click
        Dim db As New DBAccess("CRM")
        db.slDataAdd("RouteName", txteditroute.Text.Trim)
        db.slDataAdd("Routedesc", txteditroutedesc.Text.Trim)
        db.UpdateinTable("tbl_Config_Route", "routeid='" & Label5.Text.Trim & "'")
        db = Nothing
        getroute()
    End Sub
#End Region
#Region "Utility"

    Private Sub AlertMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMFail"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub

    Private Sub SuccessMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMSuccess"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub
    Public Overrides Sub VerifyRenderingInServerForm(ByVal Control As Control)

    End Sub

#End Region
End Class
