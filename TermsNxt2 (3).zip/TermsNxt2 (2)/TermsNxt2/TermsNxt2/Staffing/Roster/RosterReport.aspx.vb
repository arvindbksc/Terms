﻿Imports com.nss.DBAccess
Imports System.Data
Partial Class Staffing_Roster_RosterReport
    Inherits System.Web.UI.Page
    Dim TotalMorning As Int32 = 0
    'Dim TotalJet2 As Int32 = 0
    'Dim TotalB2B As Int32 = 0
    'Dim TotalB2C As Int32 = 0
    Dim TotalING As Int32 = 0

    Dim TotalIbiboTradusin As Int16 = 0
    Dim TotalHR As Int16 = 0
    Dim TotalGoIbibo As Int16 = 0
    Dim TotalJet2 As Int16 = 0
    Dim TotalB2B As Int16 = 0
    Dim TotalHRH As Int16 = 0
    Dim TotalB2C As Int16 = 0
    Dim TotalGordon As Int16 = 0
    Dim TotalSEI As Int16 = 0
    Dim TotalLioness As Int16 = 0
    Dim TotalRoman As Int16 = 0
    Dim TotalSEINight As Int16 = 0
    Dim TotalUBM As Int16 = 0
    Dim TotalMonalisa As Int16 = 0
    Dim TotalNoTPT As Int16 = 0




#Region "--- Properties ---"
    Property AgentID() As String
        Get
            Return ViewState("AgentID")
        End Get
        Set(ByVal value As String)
            ViewState("AgentID") = value
        End Set
    End Property
    Property CampaignID() As Integer
        Get
            Return ViewState("CampaignID")
        End Get
        Set(ByVal value As Integer)
            ViewState("CampaignID") = value
        End Set
    End Property
#End Region
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            If Session("AgentID") <> "" Then
                CampaignID = Session("CampaignID")
                AgentID = Session("AgentID")
                PanelReports.Controls.Add(Common.GetMenu(Request.Url, AgentID, Request.ApplicationPath))
                FillCommonFilters()
                FillGrid()
                UcDateTo.Visible = False
                UcDateFrom.Visible = False
                lblAnd.Visible = False
            End If
        End If
    End Sub
#Region "Event"
    Protected Sub CboPeriod_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles CboPeriod.SelectedIndexChanged
        If CboPeriod.SelectedValue = 10 Then
            UcDateFrom.Visible = True
            UcDateTo.Visible = True
            lblAnd.Visible = True
            FillGrid()
        Else
            UcDateFrom.Visible = False
            UcDateTo.Visible = False
            lblAnd.Visible = False
            FillGrid()
        End If
    End Sub
    Protected Sub CboProcess_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles CboProcess.SelectedIndexChanged
        FillGrid()
    End Sub
    Protected Sub imgfav_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles imgfav.Click
        Common.AddToFav(AgentID, "Roster Report")
        SuccessMessage("Report has been added to your favourite list")
        fillgrid()
    End Sub
    Protected Sub btnRefresh_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnRefresh.Click
        FillGrid()
    End Sub
    Protected Sub ImageButton1_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton1.Click
        fillgrid()
        GridViewExportUtil.Export(breadcrumbs.CurrentPage & ".xls", Me.gvRosterDeatils)
    End Sub
#End Region
#Region "Load"
    Private Sub FillCommonFilters()
        Dim db As New DBAccess
        Dim dt As DataTable = db.ReturnTable("select * from tbl_Reports_DatePeriods")
        db = Nothing
        Dim dr As DataRow = dt.NewRow
        dr(0) = 10
        dr(1) = "Between"
        dt.Rows.Add(dr)
        CboPeriod.DataTextField = "Caption"
        CboPeriod.DataValueField = "Period"
        CboPeriod.DataSource = dt
        CboPeriod.DataBind()
        Common.FillProcessCampaigns(CboProcess, cboCampaigns, AgentID, CampaignID)
    End Sub
    Private Sub FillGrid()
        Dim db As New DBAccess
        Dim startday As Integer, endday As Integer
        If CboPeriod.SelectedValue = 10 Then
            startday = ucDateFrom.yyyymmdd
            endday = UcDateTo.yyyymmdd
        Else
            db = New DBAccess
            db.slDataAdd("Period", CboPeriod.SelectedValue)
            db.slDataAdd("Campaignid", CampaignID)
            Dim dr As DataRow = db.ReturnRow("usp_GetStart_EndDateForAPeriod", True)
            db = Nothing
            startday = dr(0)
            endday = dr(1)
        End If
        db = Nothing
        db = New DBAccess("Report")
        Dim dt As New DataTable
        db.slDataAdd("DateFrom", startday)
        db.slDataAdd("DateTo", endday)
        If CboProcess.SelectedItem.Text = "All" Then
            db.slDataAdd("Process", 0)
        Else
            db.slDataAdd("Process", CboProcess.SelectedValue)
        End If
        dt = db.ReturnTable("usp_GetEmployeeRosterCount", , True)
        db = Nothing
        breadcrumbs.CurrentPage = " Roster Report "
        gvRosterDeatils.DataSource = dt
        gvRosterDeatils.DataBind()
        dt = Nothing
    End Sub
#End Region
#Region "Utility"
    Private Sub AlertMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMFail"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub

    Private Sub SuccessMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMSuccess"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub
#End Region

    Protected Sub gvRosterDeatils_RowDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles gvRosterDeatils.RowDataBound
        If e.Row.RowType = DataControlRowType.DataRow Then
            Dim TotalIbiboTradusin1 As Int16 = 0
            Dim TotalHR1 As Int16 = 0
            Dim TotalGoIbibo1 As Int16 = 0
            Dim TotalJet21 As Int16 = 0
            Dim TotalB2B1 As Int16 = 0
            Dim TotalHRH1 As Int16 = 0
            Dim TotalB2C1 As Int16 = 0
            Dim TotalGordon1 As Int16 = 0
            Dim TotalSEI1 As Int16 = 0
            Dim TotalLioness1 As Int16 = 0
            Dim TotalRoman1 As Int16 = 0
            Dim TotalSEINight1 As Int16 = 0
            Dim TotalUBM1 As Int16 = 0
            Dim TotalMonalisa1 As Int16 = 0
            Dim TotalNoTPT1 As Int16 = 0


            Dim rowIbiboTradusinTotal As Int32 = Convert.ToDecimal(DataBinder.Eval(e.Row.DataItem, "Ibibo_Tradus_in"))
            TotalIbiboTradusin = TotalIbiboTradusin + rowIbiboTradusinTotal
            TotalIbiboTradusin1 = Convert.ToDecimal(DataBinder.Eval(e.Row.DataItem, "Ibibo_Tradus_in"))

            Dim rowHRTotal As Int32 = Convert.ToDecimal(DataBinder.Eval(e.Row.DataItem, "HR"))
            TotalHR = TotalHR + rowHRTotal
            TotalHR1 = Convert.ToDecimal(DataBinder.Eval(e.Row.DataItem, "HR"))

            Dim rowGoIbiboTotal As Int32 = Convert.ToDecimal(DataBinder.Eval(e.Row.DataItem, "Go Ibibo"))
            TotalGoIbibo = TotalGoIbibo + rowGoIbiboTotal
            TotalGoIbibo1 = Convert.ToDecimal(DataBinder.Eval(e.Row.DataItem, "Go Ibibo"))

            Dim rowJet2Total As Int32 = Convert.ToDecimal(DataBinder.Eval(e.Row.DataItem, "Jet2"))
            TotalJet2 = TotalJet2 + rowJet2Total
            TotalJet21 = Convert.ToDecimal(DataBinder.Eval(e.Row.DataItem, "Jet2"))

            Dim rowB2BTotal As Int32 = Convert.ToDecimal(DataBinder.Eval(e.Row.DataItem, "B2B"))
            TotalB2B = TotalB2B + rowB2BTotal
            TotalB2B1 = Convert.ToDecimal(DataBinder.Eval(e.Row.DataItem, "B2B"))

            Dim rowHRHTotal As Int32 = Convert.ToDecimal(DataBinder.Eval(e.Row.DataItem, "HRH"))
            TotalHRH = TotalHRH + rowHRHTotal
            TotalHRH1 = Convert.ToDecimal(DataBinder.Eval(e.Row.DataItem, "HRH"))

            Dim rowB2CTotal As Int32 = Convert.ToDecimal(DataBinder.Eval(e.Row.DataItem, "B2C"))
            TotalB2C = TotalB2C + rowB2CTotal
            TotalB2C1 = Convert.ToDecimal(DataBinder.Eval(e.Row.DataItem, "B2C"))

            Dim rowGordonTotal As Int32 = Convert.ToDecimal(DataBinder.Eval(e.Row.DataItem, "Gordon"))
            TotalGordon = TotalGordon + rowGordonTotal
            TotalGordon1 = Convert.ToDecimal(DataBinder.Eval(e.Row.DataItem, "Gordon"))

            Dim rowSEITotal As Int32 = Convert.ToDecimal(DataBinder.Eval(e.Row.DataItem, "SEI"))
            TotalSEI = TotalSEI + rowSEITotal
            TotalSEI1 = Convert.ToDecimal(DataBinder.Eval(e.Row.DataItem, "SEI"))

            Dim rowLionessTotal As Int32 = Convert.ToDecimal(DataBinder.Eval(e.Row.DataItem, "Lioness"))
            TotalLioness = TotalLioness + rowLionessTotal
            TotalLioness1 = Convert.ToDecimal(DataBinder.Eval(e.Row.DataItem, "Lioness"))

            Dim rowRomanTotal As Int32 = Convert.ToDecimal(DataBinder.Eval(e.Row.DataItem, "Roman"))
            TotalRoman = TotalRoman + rowRomanTotal
            TotalRoman1 = Convert.ToDecimal(DataBinder.Eval(e.Row.DataItem, "Roman"))

            Dim rowSEInightTotal As Int32 = Convert.ToDecimal(DataBinder.Eval(e.Row.DataItem, "SEI Night"))
            TotalSEINight = TotalSEINight + rowSEInightTotal
            TotalSEINight1 = Convert.ToDecimal(DataBinder.Eval(e.Row.DataItem, "SEI Night"))

            Dim rowUBMTotal As Int32 = Convert.ToDecimal(DataBinder.Eval(e.Row.DataItem, "UBM"))
            TotalUBM = TotalUBM + rowUBMTotal
            TotalUBM1 = Convert.ToDecimal(DataBinder.Eval(e.Row.DataItem, "UBM"))

            Dim rowMonalisaTotal As Int32 = Convert.ToDecimal(DataBinder.Eval(e.Row.DataItem, "Monalisa"))
            TotalMonalisa = TotalMonalisa + rowMonalisaTotal
            TotalMonalisa1 = Convert.ToDecimal(DataBinder.Eval(e.Row.DataItem, "Monalisa"))

            Dim rowNoTPTTotal As Int32 = Convert.ToDecimal(DataBinder.Eval(e.Row.DataItem, "No TPT"))
            TotalNoTPT = TotalNoTPT1 + rowNoTPTTotal
            TotalNoTPT1 = Convert.ToDecimal(DataBinder.Eval(e.Row.DataItem, "No TPT"))

            e.Row.Cells(16).Text = TotalIbiboTradusin1 + TotalHR1 + TotalGoIbibo1 + TotalJet21 + TotalB2B1 + TotalHRH1 + TotalHRH1 + TotalB2C1 + TotalGordon1 + TotalSEI1 + TotalLioness1 + TotalRoman1 + TotalSEINight1 + TotalUBM1 + TotalMonalisa1 + TotalNoTPT1
            e.Row.Cells(16).Font.Bold = True
        End If
        If e.Row.RowType = DataControlRowType.Footer Then
            e.Row.Cells(0).Text = "Total:"
            e.Row.Cells(1).Text = TotalIbiboTradusin.ToString
            e.Row.Cells(2).Text = TotalHR.ToString
            e.Row.Cells(3).Text = TotalGoIbibo.ToString
            e.Row.Cells(4).Text = TotalJet2.ToString
            e.Row.Cells(5).Text = TotalB2B.ToString
            e.Row.Cells(6).Text = TotalHRH.ToString
            e.Row.Cells(7).Text = TotalB2C.ToString
            e.Row.Cells(8).Text = TotalGordon.ToString
            e.Row.Cells(9).Text = TotalSEI.ToString
            e.Row.Cells(10).Text = TotalLioness.ToString
            e.Row.Cells(11).Text = TotalRoman.ToString
            e.Row.Cells(12).Text = TotalSEINight.ToString
            e.Row.Cells(13).Text = TotalUBM.ToString
            e.Row.Cells(14).Text = TotalMonalisa.ToString
            e.Row.Cells(15).Text = TotalNoTPT.ToString
        End If
    End Sub
End Class
