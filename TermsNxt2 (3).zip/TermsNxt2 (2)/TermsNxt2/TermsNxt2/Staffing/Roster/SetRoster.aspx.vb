﻿Imports com.nss.DBAccess
Imports System.Data
Partial Class PerfSum_SetRoster
    Inherits System.Web.UI.Page
#Region "-----Properties-----"

    Property CurrentDate() As Date
        Get
            Return ViewState("CurrentDate")
        End Get
        Set(ByVal value As Date)
            ViewState("CurrentDate") = value
        End Set
    End Property
    'Property RosterDate() As Date
    '    Get
    '        Return ViewState("RosterDate")
    '    End Get
    '    Set(ByVal value As Date)
    '        ViewState("RosterDate") = value
    '    End Set
    'End Property
    Property RosterDate() As Int64
        Get
            Return ViewState("RosterDate")
        End Get
        Set(ByVal value As Int64)
            ViewState("RosterDate") = value
        End Set
    End Property
    Property MinDate() As Date
        Get
            Return ViewState("MinDate")
        End Get
        Set(ByVal value As Date)
            ViewState("MinDate") = value
        End Set
    End Property

    Property ReportType() As Integer
        Get
            Return ViewState("ReportType")
        End Get
        Set(ByVal value As Integer)
            ViewState("ReportType") = value
        End Set
    End Property

    Property CurrentLevel() As Integer
        Get
            Return ViewState("CurrentLevel")
        End Get
        Set(ByVal value As Integer)
            ViewState("CurrentLevel") = value
        End Set
    End Property
    Property SupervisorID() As String
        Get
            Return ViewState("SupervisorID")
        End Get
        Set(ByVal value As String)
            ViewState("SupervisorID") = value
        End Set
    End Property
    Property UserID() As String
        Get
            Return ViewState("UserID")
        End Get
        Set(ByVal value As String)
            ViewState("UserID") = value
        End Set
    End Property
    Property AgentID() As String
        Get
            Return ViewState("AgentID")
        End Get
        Set(ByVal value As String)
            ViewState("AgentID") = value
        End Set
    End Property
    Property dtprevweek() As DataTable
        Get
            Return ViewState("dtprevweek")
        End Get
        Set(ByVal value As DataTable)
            ViewState("dtprevweek") = value
        End Set
    End Property
#End Region
    'Public RosterDay As String
    Public dtroute1, dtcab1 As DataTable
    'Public rosterdate As String
    'Public rosterdate1 As DateTime
    Public rosterdate1 As Int64
#Region "Load Data"
    Private Sub getroster()
        'Dim rosterdate As String
        'calfrom.SelectedDate = DateTime.Now()
        'If txtfrom.Text = "" Then
        'rosterdate = calfrom.SelectedDate.ToString
        'Else
        'rosterdate = txtfrom.Text.Substring(6, 4) + txtfrom.Text.Substring(3, 2) + txtfrom.Text.Substring(0, 2)
        'End If

        'Dim rosterdate1 As DateTime
        'rosterdate1 = Convert.ToDateTime(rosterdate)
        'RosterDay = rosterdate1.DayOfWeek.ToString
        'RosterDate = ucDateFrom.value 
        RosterDate = ucDateFrom.yyyymmdd
        Dim db As New DBAccess
        Dim dt As DataTable
        db.slDataAdd("RosterDate", RosterDate)
        db.slDataAdd("Shiftin", Cboshiftin.SelectedItem.Text)
        'db.slDataAdd("shiftout", cboshiftout.SelectedItem.Text)
        dt = db.ReturnTable("usp_getRoster", , True)
        db = Nothing
        gdroster.AutoGenerateColumns = False
        If dt.Rows.Count > 0 Then
            gdroster.DataSource = dt.DefaultView
            gdroster.DataBind()
            btsave.Enabled = True
        Else
            btsave.Enabled = False
            gdroster.DataSource = Nothing
            gdroster.DataBind()
            Return
        End If
        'gdroster.Columns(0).Visible = False
        'gdroster.Columns(2).HeaderText = RosterDay & " In"
        'gdroster.Columns(3).HeaderText = RosterDay & " Out"

    End Sub
    Private Sub getshift()
        Dim db As New DBAccess("CRM")
        Dim dtshift As DataTable
        dtshift = db.ReturnTable("select * from tbl_Config_RosterShift", , False)
        db = Nothing
        Cboshiftin.DataTextField = "Shift"
        Cboshiftin.DataValueField = "shiftid"
        Cboshiftin.DataSource = dtshift.DefaultView
        Cboshiftin.DataBind()
        'cboshiftout.DataTextField = "Shift"
        'cboshiftout.DataValueField = "shiftid"
        'cboshiftout.DataSource = dtshift.DefaultView
        'cboshiftout.DataBind()
    End Sub
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        HumanMessage.Style.Item("visibility") = "hidden"
        If Not IsPostBack Then
            AgentID = Session("Agentid")
            PanelReports.Controls.Add(Common.GetMenu(Request.Url, AgentID, Request.ApplicationPath))
            SupervisorID = Session("UserID")
            UserID = Session("UserID")
            Dim dbdate As New DBAccess
            Dim a As DateTime
            'a = DateTime.Now.AddDays(8 - DateTime.Now.DayOfWeek)
            a = dbdate.ReturnValue("select getdate()", False) 'DateTime.Now
            dbdate = Nothing
            'ucDateFrom.value = a
            'calfrom.SelectedDate = a
            'calfrom.Format = "dd/MM/yyyy"
            'Dim b As String
            'b = a.Month.ToString + "/" + a.Day.ToString + "/" + a.Year.ToString
            ' b = a.ToString("dd/MMM/yyyy")
            'txtStartDate.Text = a.ToString("dd-MMM-yyyy")
            ucDateFrom.value = a.ToString("dd-MMM-yyyy")
            'txtfrom.Text = b           
            getshift()
            getroster()
            lblReportName.CurrentPage = "Set roster"
        End If
    End Sub
    Private Sub getroute()
        'Dim rosterdate As String
        'If txtfrom.Text = "" Then
        '    rosterdate = calfrom.SelectedDate.ToString
        'Else
        '    rosterdate = txtfrom.Text.ToString
        'End If
        'rosterdate = txtfrom.Text.Substring(6, 4) + txtfrom.Text.Substring(3, 2) + txtfrom.Text.Substring(0, 2)
        'RosterDate = ucDateFrom.value 'txtStartDate.Text
        'Dim rosterdate1 As DateTime
        'rosterdate1 = Convert.ToDateTime(rosterdate)
        'RosterDate = ucDateFrom.value
        RosterDate = ucDateFrom.yyyymmdd
        Dim db As New DBAccess
        db.slDataAdd("RosterDate", RosterDate)
        db.slDataAdd("Shiftin", Cboshiftin.SelectedItem.Text)
        'db.slDataAdd("shiftout", cboshiftout.SelectedItem.Text)
        dtroute1 = db.ReturnTable("usp_getRoute", , True)
        db = Nothing
    End Sub
    Private Sub getroutecab()
        Dim db As New DBAccess("CRM")
        dtcab1 = db.ReturnTable("select cabnumber,route from tbl_Data_Cab", , False)
        db = Nothing
    End Sub
#End Region
#Region "GridOps"
    Protected Sub gdroster_RowDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles gdroster.RowDataBound
        If e.Row.RowType = DataControlRowType.DataRow Then
            If Not e.Row.RowType = DataControlRowType.Header And Not e.Row.RowType = DataControlRowType.Footer Then
                Dim db As New DBAccess("CRM")
                Dim dtcab, dtroute As DataTable
                dtcab = db.ReturnTable("select * from tbl_data_cab order by cabnumber", , False)
                db = Nothing
                db = New DBAccess("CRM")
                dtroute = db.ReturnTable("select * from tbl_Config_Route order by RouteName", , False)
                db = Nothing
                getroute()
                getroutecab()
                Dim cbocabin, cbocabout, cboroute As DropDownList
                'For Each row As GridViewRow In gdroster.Rows
                'cbocabin = CType(gdroster.Rows(row.RowIndex).Cells(3).FindControl("cbocabin"), DropDownList)
                cbocabin = CType(e.Row.Cells(3).FindControl("cbocabin"), DropDownList)
                cbocabin.DataSource = dtcab
                cbocabin.DataTextField = "cabnumber"
                cbocabin.DataValueField = "cabnumber"
                cbocabin.DataBind()
                'cbocabout = CType(gdroster.Rows(row.RowIndex).Cells(5).FindControl("cbocabout"), DropDownList)
                cbocabout = CType(e.Row.Cells(5).FindControl("cbocabout"), DropDownList)
                cbocabout.DataSource = dtcab
                cbocabout.DataTextField = "cabnumber"
                cbocabout.DataValueField = "cabnumber"
                cbocabout.DataBind()
                'cboroute = CType(gdroster.Rows(row.RowIndex).Cells(6).FindControl("cboroute"), DropDownList)
                cboroute = CType(e.Row.Cells(6).FindControl("cboroute"), DropDownList)
                cboroute.DataSource = dtroute
                cboroute.DataTextField = "RouteName"
                cboroute.DataValueField = "Routeid"
                cboroute.DataBind()
                'For Each row1 As DataRow In dtroute.Rows
                'MsgBox(row.Cells(0).Text.ToString)
                Dim rowroute As DataRow()
                Dim rowcab As DataRow()
                rowroute = dtroute1.Select("Agentid='" & e.Row.Cells(0).Text.ToString & "'")
                For Each drRoute1 As DataRow In rowroute
                    If Not IsDBNull(drRoute1.Item("route")) Then
                        cboroute.SelectedValue = drRoute1.Item("route")
                        If Not IsDBNull(drRoute1.Item("cabin")) Then
                            cbocabin.SelectedValue = drRoute1.Item("cabin")
                            cbocabout.SelectedValue = drRoute1.Item("cabout")
                        Else
                            rowcab = dtcab1.Select("route='" & drRoute1.Item("route") & "'")
                            For Each drcab1 As DataRow In rowcab
                                cbocabin.SelectedValue = drcab1.Item("cabnumber")
                                cbocabout.SelectedValue = drcab1.Item("cabnumber")
                            Next
                        End If

                    End If
                Next
            End If

        End If
        'Next
        ' Next

    End Sub
#End Region
    
#Region "Event"
    Protected Sub btnRefresh_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnRefresh.Click
        getroster()
    End Sub
    Protected Sub btsave_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btsave.Click
        Dim db As New DBAccess("CRM")
        'Dim rosterdate As String
        'If txtfrom.Text = "" Then
        'rosterdate = calfrom.SelectedDate.ToString
        ' Else
        'rosterdate = txtfrom.Text
        'rosterdate = ucDateFrom.value 'txtStartDate.Text 'ucDateFrom.value.ToString("dd/MMM/yyyy")
        ' End If
        ' Dim rosterdate1 As DateTime
        'rosterdate = ucDateFrom.value 
        RosterDate = ucDateFrom.yyyymmdd
        'rosterdate1 = Convert.ToDateTime(rosterdate)
        rosterdate1 = RosterDate
        'Dim dt As DataTable
        Dim cbocabin, cbocabout, cboroute As DropDownList
        For Each row As GridViewRow In gdroster.Rows
            cbocabin = CType(gdroster.Rows(row.RowIndex).Cells(3).FindControl("cbocabin"), DropDownList)
            cbocabout = CType(gdroster.Rows(row.RowIndex).Cells(5).FindControl("cbocabout"), DropDownList)
            cboroute = CType(gdroster.Rows(row.RowIndex).Cells(6).FindControl("cboroute"), DropDownList)
            db.slDataAdd("agentid", row.Cells(0).Text.ToString)
            db.slDataAdd("rosterdate", RosterDate)
            db.slDataAdd("cabin ", cbocabin.SelectedItem.Text.ToString)
            db.slDataAdd("cabout", cbocabout.SelectedItem.Text.ToString)
            db.slDataAdd("Route", cboroute.SelectedValue)
            db.Executeproc("usp_setRoster")
            'Dim db1 As New DBAccess("CRM")
            'db1.slDataAdd("Route", cboroute.SelectedValue)
            'db1.UpdateinTable("tbl_AgentMaster", "AgentID='" & row.Cells(0).Text.ToString & "'")
            'db1 = Nothing
        Next
        db = Nothing
        SuccessMessage("Roster has been set")
        getroster()
    End Sub
    Protected Sub ucDateFrom_Changed(ByVal sender As Object, ByVal e As System.EventArgs) Handles ucDateFrom.Changed
        getroster()
    End Sub
    Protected Sub Cboshiftin_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles Cboshiftin.SelectedIndexChanged
        getroster()
    End Sub
#End Region
#Region "Utility"

    Private Sub AlertMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMFail"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub

    Private Sub SuccessMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMSuccess"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub

    'Protected Sub ImageButton1_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton1.Click
    '    'fillgrid()
    '    GridViewExportUtil.Export(lblReportName.CurrentPage & "-" & LblError.Text & ".xls", Me.GdAttendance)
    'End Sub


    Public Overrides Sub VerifyRenderingInServerForm(ByVal Control As Control)

    End Sub

#End Region
    
   
End Class
