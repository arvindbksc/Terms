﻿
Imports System.Data.OleDb
Imports System.Data.SqlClient
Imports System.Data
Imports com.nss.DBAccess
Partial Class Custom_FileUploader
    Inherits System.Web.UI.Page
    Dim dt As DataTable
    Dim ds As DataSet
    Public strFileName, strFileExtention, ShowScriptFlag, strPath, strfile1 As String
    Private leadscount As Long = 0
#Region "--- Properties ---"

    Property ProcessID() As Integer
        Get
            Return ViewState("ProcessID")
        End Get
        Set(ByVal value As Integer)
            ViewState("ProcessID") = value
            Session("ProcessID") = value
        End Set
    End Property
    Property CampaignID() As Integer
        Get
            Return ViewState("CampaignID")
        End Get
        Set(ByVal value As Integer)
            ViewState("CampaignID") = value
            Session("CampaignID") = value
        End Set
    End Property
    Property AgentID() As String
        Get
            Return ViewState("AgentID")
        End Get
        Set(ByVal value As String)
            ViewState("AgentID") = value
        End Set
    End Property
    Property valid() As Boolean
        Get
            Return ViewState("valid")
        End Get
        Set(ByVal value As Boolean)
            ViewState("valid") = value
        End Set
    End Property
#End Region
#Region "--- Load ---"
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        HumanMessage.Style.Item("visibility") = "hidden"
        'btnUpload.Attributes.Item("onclick") = "this.value=" & Chr(34) & "Processing..." & Chr(34) & ";this.disabled=true;" & ClientScript.GetPostBackEventReference(btnUpload, Nothing).ToString

        clear2() 'rajkumar Added 14-July-2016
        If Not IsPostBack Then
            'If Session("CampaignID").ToString() = "" Or Session("CampaignID") = Nothing Then
            If Session("AgentID") <> "" Then
                ' CampaignID = 284 'commented it here
                'Else
                ' CampaignID = Session("CampaignID")
                'End If
                AgentID = Session("AgentID")
                PanelReports.Controls.Add(Common.GetMenu(Request.Url, AgentID, Request.ApplicationPath))
                valid = True
            End If
           
        End If
    End Sub
#End Region
#Region "--- Support Functions ---"
    'Private Function opendialog() As Boolean
    '    'OpenFileDialog1.Filter = "Excel  Files (*.xls)|*.xls|CSV  Files (*.csv)|*.csv|Tab Delimited Files (*.txt)|*.txt|Excel  Files (*.xlsx)|*.xlsx"
    '    If FileUpload1.HasFile Then
    '        strfile1 = FileUpload1.PostedFile.FileName
    '        strFileName = strfile1.Substring(strfile1.LastIndexOf("\") + 1)
    '        strFileExtention = strfile1.Substring(strfile1.LastIndexOf(".") + 1)
    '        strPath = System.IO.Path.GetDirectoryName(strfile1)
    '        Return True
    '    Else
    '        AlertMessage("Please choose a file first.")
    '        valid = False
    '        Return False
    '    End If
    'End Function

    Private Function opendialog2() As Boolean
        'OpenFileDialog1.Filter = "Excel  Files (*.xls)|*.xls|CSV  Files (*.csv)|*.csv|Tab Delimited Files (*.txt)|*.txt|Excel  Files (*.xlsx)|*.xlsx"
        If FileUpload2.HasFile Then
            strfile1 = FileUpload2.PostedFile.FileName
            strFileName = strfile1.Substring(strfile1.LastIndexOf("\") + 1)
            strFileExtention = strfile1.Substring(strfile1.LastIndexOf(".") + 1)
            strPath = System.IO.Path.GetDirectoryName(strfile1)
            Return True
        Else
            AlertMessage("Please choose a file first.")
            valid = False
            Return False
        End If
    End Function

    Private Sub FetchDatafromFile()
        Dim conn As New OleDbConnection
        Dim cmd As OleDbCommand

        If strFileExtention = "xls" Then
            conn = New OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0; Data Source=" & strfile1 & ";Extended Properties=""Excel 8.0;HDR=Yes""")
            cmd = New OleDbCommand("Select * from [sheet1$]")
        ElseIf strFileExtention = "txt" Then
            conn = New OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0; Data Source=" & strPath & ";Extended Properties=""text;HDR=Yes;FMT=TabDelimited""")
            cmd = New OleDbCommand("Select * from [" & strFileName & "]")
        ElseIf strFileExtention = "xlsx" Then
            conn = New OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0; Data Source=" & strfile1 & ";Extended Properties=""Excel 12.0;HDR=Yes;""")
            cmd = New OleDbCommand("Select * from [Sheet1$]")
        Else
            conn = New OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0; Data Source=" & strPath & ";Extended Properties=""text;HDR=Yes;FMT=Delimited""")
            cmd = New OleDbCommand("Select * from [" & strFileName & "]")
        End If
        Try
            conn.Open()
        Catch ex As Exception
            'Throw ex
            valid = False
            AlertMessage(ex.ToString)
        End Try

        dt = New DataTable
        ds = New DataSet
        Try
            'Dim type As System.Type
            cmd.Connection = conn
            Dim da As New OleDbDataAdapter(cmd)
            da.Fill(dt)
            da.Fill(ds, "tbl1")

            Dim str As String = ""
            'Dim j As Int16 = 0
            'If Not ds.Tables("tbl1").Columns.Contains("ORIG CREATED DATE") Then
            '    valid = False
            '    AlertMessage("ORIG CREATED DATE is missing in the file")
            '    Exit Sub
            'End If
            'If Not ds.Tables("tbl1").Columns.Contains("CHANGED DATE") Then
            '    valid = False
            '    AlertMessage("CHANGED DATE is missing in the file")
            '    Exit Sub
            'End If
            'If Not ds.Tables("tbl1").Columns.Contains("CHANGED BY") Then
            '    valid = False
            '    AlertMessage("CHANGED BY is missing in the file")
            '    Exit Sub
            'End If
            'If Not ds.Tables("tbl1").Columns.Contains("DOCUMENT NO#") Then
            '    valid = False
            '    AlertMessage("DOCUMENT NO. is missing in the file")
            '    Exit Sub
            'End If
            'If Not ds.Tables("tbl1").Columns.Contains("DOCUMENT YEAR") Then
            '    valid = False
            '    AlertMessage("DOCUMENT YEAR is missing in the file")
            '    Exit Sub
            'End If
            'If Not ds.Tables("tbl1").Columns.Contains("LINE ITEM NO#") Then
            '    valid = False
            '    AlertMessage("LINE ITEM NO. is missing in the file")
            '    Exit Sub
            'End If
            'If Not ds.Tables("tbl1").Columns.Contains("ORIGNAL CREATED TIME") Then
            '    valid = False
            '    AlertMessage("ORIGNAL CREATED TIME is missing in the file")
            '    Exit Sub
            'End If
            'If Not ds.Tables("tbl1").Columns.Contains("ORIGINAL DOCUMENT CREATED BY") Then
            '    valid = False
            '    AlertMessage("ORIGINAL DOCUMENT CREATED BY is missing in the file")
            '    Exit Sub
            'End If
            'If Not ds.Tables("tbl1").Columns.Contains("OLD VALUES") Then
            '    valid = False
            '    AlertMessage("OLD VALUES BY is missing in the file")
            '    Exit Sub
            'End If
            'If Not ds.Tables("tbl1").Columns.Contains("NEW VALUES") Then
            '    valid = False
            '    AlertMessage("NEW VALUES is missing in the file")
            '    Exit Sub
            'End If
            'If Not ds.Tables("tbl1").Columns.Contains("CHANGED TIME") Then
            '    valid = False
            '    AlertMessage("CHANGED TIME is missing in the file")
            '    Exit Sub
            'End If
            
            For Each col As DataColumn In ds.Tables("tbl1").Columns
                str += "[" & col.ColumnName & "] is null and "
            Next
           
            If Not str = "" Then
                str = str.Substring(0, Len(str) - 4)
                Dim dta() As DataRow = ds.Tables("tbl1").Select(str)
                For Each row As DataRow In dta
                    ds.Tables("tbl1").Rows.Remove(row)
                Next
            End If

            ' Dim db As New DBAccess("Leads")
            Dim db As New DBAccess("report")
            ds.Tables("tbl1").Columns.Add("FileName", Type.GetType("System.String"))
            ds.Tables("tbl1").Columns.Add("CreatedBy", Type.GetType("System.String"))

            'It is appended to add two more columns of filename and AgentID
            For i As Integer = 0 To ds.Tables("tbl1").Rows.Count - 1
                ds.Tables("tbl1").Rows(i).Item("FileName") = strFileName
                ds.Tables("tbl1").Rows(i).Item("CreatedBy") = AgentID
            Next
        Catch ex As Exception
            'Throw ex
            AlertMessage(ex.ToString)
            valid = False
        Finally
            conn.Close()
        End Try
    End Sub
    Private Sub UploadToDatabase()
        Dim comment As String = ""
        ' Dim db1 As New DBAccess("Leads")
        Dim db1 As New DBAccess("report")
        leadscount = ds.Tables("tbl1").Rows.Count
        Try
            Dim bulkCopy As SqlBulkCopy = New SqlBulkCopy(db1.ReturnConnection)
            '  bulkCopy.DestinationTableName = "tbl_leadmaster" & CampaignID
            bulkCopy.DestinationTableName = "tbl_Data_RosterUpload"

            bulkCopy.ColumnMappings.Add("ROUTEID", "ROUTEID")
            bulkCopy.ColumnMappings.Add("SHIFT", "SHIFT")
            bulkCopy.ColumnMappings.Add("ROSTERDATE", "ROSTERDATE")
            bulkCopy.ColumnMappings.Add("GUARDROUTE", "GUARDROUTE")
            bulkCopy.ColumnMappings.Add("REPORTINGTIME", "REPORTINGTIME")
            bulkCopy.ColumnMappings.Add("REGION", "REGION")

            bulkCopy.ColumnMappings.Add("CABTYPE", "CABTYPE")
            bulkCopy.ColumnMappings.Add("VENDOR", "VENDOR")
            bulkCopy.ColumnMappings.Add("ROUTECOST", "ROUTECOST")
            bulkCopy.ColumnMappings.Add("EMPLOYEENAME", "EMPLOYEENAME")

            bulkCopy.ColumnMappings.Add("EMPLOYEEID", "EMPLOYEEID")
            bulkCopy.ColumnMappings.Add("PROCESS", "PROCESS")
            bulkCopy.ColumnMappings.Add("GENDER", "GENDER")
            bulkCopy.ColumnMappings.Add("ADDRESS", "ADDRESS")

            bulkCopy.ColumnMappings.Add("LOCATION", "LOCATION")
            bulkCopy.ColumnMappings.Add("PHONENO", "PHONENO")
            bulkCopy.ColumnMappings.Add("PICKUPTIME", "PICKUPTIME")
            bulkCopy.ColumnMappings.Add("REMARK", "REMARK")

            bulkCopy.ColumnMappings.Add("CREATEDBY", "CREATEDBY")
            bulkCopy.ColumnMappings.Add("FILENAME", "FILENAME")

            'bulkCopy.ColumnMappings.Add("CreatedBy", "CreatedBy")
            'bulkCopy.ColumnMappings.Add("FileName", "FileName")

            bulkCopy.WriteToServer(ds.CreateDataReader)
            SuccessMessage("File Uploaded Successfully...")
        Catch ex As Exception
            Throw ex
            '  AlertMessage(ex.ToString)
        Finally
            'db = Nothing
            db1 = Nothing
        End Try
    End Sub
    Private Sub clear()
        strfile1 = ""
        strFileName = ""
        strFileExtention = ""
        strPath = ""
        valid = True
    End Sub

    Private Sub clear2()
        strfile1 = ""
        strFileName = ""
        strFileExtention = ""
        strPath = ""
        ' valid = True
    End Sub
#End Region
#Region "--- Event ---"
    'Protected Sub btnUpload_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnUpload.Click
    '    Try
    '        If opendialog() Then
    '            FetchDatafromFile()
    '            If valid = True Then
    '                UploadToDatabase()
    '            End If
    '            clear()
    '        End If
    '    Catch ex As Exception
    '        AlertMessage(ex.ToString)
    '    End Try
    'End Sub

    Protected Sub btnUP_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnUP.Click
        Try
            If opendialog2() Then
                FetchDatafromFile()
                If valid = True Then
                    UploadToDatabase()
                End If
                clear()
            End If
        Catch ex As Exception
            AlertMessage(ex.ToString)
        End Try
    End Sub

    Protected Sub imgfav_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles imgfav.Click
        Common.AddToFav(AgentID, "Roster File Upload")
        SuccessMessage("Roster File Uploader has been added to your favourite list")
    End Sub
#End Region
#Region "--- Utility ---"
    Private Sub AlertMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMFail"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub
    Private Sub SuccessMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMSuccess"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub
    Private Sub HideMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMSuccess"
        HumanMessage.Style.Item("visibility") = "hidden"
    End Sub
#End Region

   
End Class
