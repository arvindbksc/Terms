﻿Imports com.nss.DBAccess
Imports System.Data
Partial Class Staffing_Roster_PendingSpecialCab
    Inherits System.Web.UI.Page
#Region "--- Properties ---"
    Property CampaignID() As Integer
        Get
            Return ViewState("CampaignID")
        End Get
        Set(ByVal value As Integer)
            ViewState("CampaignID") = value
        End Set
    End Property
    Property AgentID() As String
        Get
            Return ViewState("AgentID")
        End Get
        Set(ByVal value As String)
            ViewState("AgentID") = value
        End Set
    End Property
    Property UserName() As String
        Get
            Return ViewState("UserName")
        End Get
        Set(ByVal value As String)
            ViewState("UserName") = value
        End Set
    End Property

    Property processID() As Integer
        Get
            Return ViewState("processID")
        End Get
        Set(ByVal value As Integer)
            ViewState("processID") = value
        End Set
    End Property

    Property daySpecialCab() As Integer
        Get
            Return ViewState("daySpecialCab")
        End Get
        Set(ByVal value As Integer)
            ViewState("daySpecialCab") = value
        End Set
    End Property


#End Region

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        HumanMessage.Style.Item("visibility") = "hidden"
        If Not IsPostBack Then
            If Session("AgentID") <> "" Then
                CampaignID = Session("CampaignID")
                AgentID = Session("AgentID")
                UserName = Session("UserName")
                Common.FillProcessCampaigns(CboProcess, cboCampaigns, AgentID, CampaignID)
                PanelReports.Controls.Add(Common.GetMenu(Request.Url, AgentID, Request.ApplicationPath))
                FillCommonFilters()

                '''''''''''''''''''''''''Rajkumar start 11-Nov-2014
                'UcDateTo.Visible = False
                'UcDateFrom1.Visible = False
                'lblAnd.Visible = False
                processID = Request.QueryString("processID")
                daySpecialCab = Request.QueryString("day")

                CboProcess.SelectedValue = processID
                If processID <> 0 And daySpecialCab <> 0 Then ' pass it through the link and not direct traversing
                    CboPeriod.SelectedValue = 10
                    UcDateTo.Visible = True
                    UcDateFrom1.Visible = True
                    lblAnd.Visible = True
                    UcDateFrom1.value = Convert.ToDateTime(IntegerToDateString(daySpecialCab)).ToString("dd MMM yyyy")
                    UcDateTo.value = Convert.ToDateTime(IntegerToDateString(daySpecialCab)).ToString("dd MMM yyyy")
                    'UcDateFrom1.value = "12 Mar 2014"
                    'UcDateTo.value = "12 Mar 2014"
                Else
                    UcDateTo.Visible = False
                    UcDateFrom1.Visible = False
                    lblAnd.Visible = False
                End If
                '''''''''''''''''''''''''Rajkumar end 11-Nov-2014

                fillgrid()
                BindVendor()
            End If
        End If
    End Sub
#Region "--- Functions ---"
    Private Sub fillgrid()
        Dim db As New DBAccess
        Dim startday As Integer, endday As Integer
        If CboPeriod.SelectedValue = 10 Then
            startday = UcDateFrom1.yyyymmdd
            endday = UcDateTo.yyyymmdd
        Else
            db = New DBAccess
            db.slDataAdd("Period", CboPeriod.SelectedValue)
            db.slDataAdd("Campaignid", CampaignID)
            Dim dr As DataRow = db.ReturnRow("usp_GetStart_EndDateForAPeriod", True)
            db = Nothing
            startday = dr(0)
            endday = dr(1)
        End If
        db = Nothing
        db = New DBAccess("CRM")
        Dim dtData As New DataTable
        db.slDataAdd("ProcessID", CboProcess.SelectedValue)
        db.slDataAdd("UserCampaign", CampaignID)
        db.slDataAdd("DateFrom", startday)
        db.slDataAdd("DateTo", endday)
        db.slDataAdd("AgentID", AgentID)
        dtData = db.ReturnTable("usp_PendingSpecialCab", , True)
        db = Nothing
        GdPendingCab.Columns(0).Visible = True
        GdPendingCab.Columns(1).Visible = True
        GdPendingCab.Columns(2).Visible = True
        GdPendingCab.DataSource = dtData
        GdPendingCab.DataBind()

        breadcrumbs.CurrentPage = " Cab Request Report "
        GdPendingCab.Columns(0).Visible = False
        GdPendingCab.Columns(1).Visible = False
        GdPendingCab.Columns(2).Visible = False
        GdPendingCab.EnableViewState = True
        'ViewState("dynamicGrid") = True
    End Sub
    Private Sub FillCommonFilters()
        Dim db As New DBAccess
        Dim dt As DataTable = db.ReturnTable("select * from tbl_Reports_DatePeriods")
        db = Nothing
        Dim dr As DataRow = dt.NewRow
        dr(0) = 10
        dr(1) = "Between"
        dt.Rows.Add(dr)
        CboPeriod.DataTextField = "Caption"
        CboPeriod.DataValueField = "Period"
        CboPeriod.DataSource = dt
        CboPeriod.DataBind()
    End Sub
    Private Sub UpdateInvoice()
        Dim db As New DBAccess("CRM")
        db.slDataAdd("InvoiceNo", txtInvoiceNo.Text)
        db.slDataAdd("Amount", txtInvoiceAmount.Text)
        db.slDataAdd("InvoiceUpdatedBy", AgentID)
        db.slDataAdd("InvoiceUdated", 1)
        db.UpdateinTable("tbl_data_SpecialCab", "IdCol=" & lblRowindex.Text)
        db = Nothing
        SuccessMessage("Invoice have been updated successfully...")
        fillgrid()
    End Sub
    Private Sub BindVendor()
        Dim db As New DBAccess("CRM")
        Dim dtvendor As New DataTable
        dtvendor = db.ReturnTable("Select Id,VendorName from tbl_Config_RosterVendorDetail where active=1", True)
        Dim dr As DataRow
        dr = dtvendor.NewRow
        dr("VendorName") = "--- Select Vendor ---"
        dr("ID") = 0
        dtvendor.Rows.Add(dr)
        db = Nothing
        cboVendor.DataTextField = "VendorName"
        cboVendor.DataValueField = "Id"
        cboVendor.DataSource = dtvendor
        cboVendor.DataBind()
        cboVendor.SelectedValue = 0
    End Sub
    Private Sub UpdateVendor()
        If cboVendor.SelectedValue <> "0" Then
            lblVendorError.Text = ""
            Dim db As New DBAccess("CRM")
            db.slDataAdd("Vendor", cboVendor.SelectedItem.Text)
            db.slDataAdd("NoofDuties", txtNoOfDuties.Text)
            db.UpdateinTable("tbl_data_SpecialCab", "IdCol=" & lblRowindex.Text)
            db = Nothing
            SuccessMessage("Updated successfully...")
            fillgrid()
        Else
            lblVendorError.Text = "Please Select Vendor "
            Dim str As String
            str = "$('#DialogBackground').height($(document).height()-30);$('#DialogBackground').width($(window).width());$('#DialogBackground').css('visibility','visible');$('#pnlVendor').css('visibility','visible');" & _
            " $('#pnlVendor').css('left',($(window).width() - $('#pnlVendor').width())/2); "
            ScriptManager.RegisterStartupScript(Page, Page.GetType(), "pnlVendor", str, True)
        End If
       
    End Sub
    Private Function IntegerToDateString(ByVal d As Integer) As String
        Return d.ToString.Substring(0, 4) & "-" & d.ToString.Substring(4, 2) & "-" & d.ToString.Substring(6, 2)
    End Function

#End Region
#Region "--- Grid Ops ---"
    Protected Sub GdPendingCab_RowCommand(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewCommandEventArgs) Handles GdPendingCab.RowCommand
        Dim row As GridViewRow = CType(CType(e.CommandSource, Control).NamingContainer, GridViewRow)
        Dim str1 As String = GdPendingCab.DataKeys(row.RowIndex).Value.ToString
        Dim dbData As New DBAccess("CRM")
        dbData.slDataAdd("ID", str1)
        Dim dtData As New DataTable
        dtData = dbData.ReturnTable("usp_GetSpecialCabDataTMwise", , True)
        dbData = Nothing
        Dim dbManager As New DBAccess("CRM")
        lblRowindex.Text = dtData.Rows(0)("IDColumn").ToString
        lblDTtoCheck.Text = dtData.Rows(0)("DateOnly").ToString
        If e.CommandName = "CabAvailabilityTime" Then
            If CampaignID = 94 Then
                lblRequestedDate.Text = dtData.Rows(0)("DateOnly").ToString
                lblRequestedTime.Text = dtData.Rows(0)("HourMinute").ToString
                ucDateFrom.value = dtData.Rows(0)("DateOnly").ToString
                Dim str As String
                str = "$('#DialogBackground').height($(document).height()-10);$('#DialogBackground').width($(window).width());$('#DialogBackground').css('visibility','visible');$('#PnlTime').css('visibility','visible');" & _
                " $('#PnlTime').css('left',($(window).width() - $('#PnlTime').width())/2); "
                ScriptManager.RegisterStartupScript(Page, Page.GetType(), "PnlTime", str, True)
            Else
                AlertMessage(" Only Transport / Admin can fill Availability Time")
                Exit Sub
            End If
        End If
        '--- For Invoice Update 
        If e.CommandName = "InvoiceUpdate" Then
            If CampaignID = 94 Then
                txtInvoiceNo.Text = ""
                txtInvoiceAmount.Text = ""
                lblCab_Requested_Date.Text = dtData.Rows(0)("DateOnly").ToString
                Dim str As String
                str = "$('#DialogBackground').height($(document).height()-10);$('#DialogBackground').width($(window).width());$('#DialogBackground').css('visibility','visible');$('#pnlInvoice').css('visibility','visible');" & _
                " $('#pnlInvoice').css('left',($(window).width() - $('#pnlInvoice').width())/2); "
                ScriptManager.RegisterStartupScript(Page, Page.GetType(), "pnlInvoice", str, True)
            Else
                AlertMessage(" Only Transport / Admin can fill Invoice data")
                Exit Sub
            End If
        End If
        '------ For Vendor Update 
        If e.CommandName = "UpdateVendor" Then
            If CampaignID = 94 Then
                Dim Vendor As LinkButton = row.FindControl("lnkVendor")
                If Vendor.Text.ToString.Trim.ToLower() <> "update" Then
                    cboVendor.ClearSelection()
                    cboVendor.Items.FindByText(Vendor.Text).Selected = True
                    Dim NoOfDuty As Label = row.FindControl("lblNoofDuties")
                    txtNoOfDuties.Text = NoOfDuty.Text
                Else
                    lblVendorError.Text = ""
                    cboVendor.SelectedValue = 0
                    txtNoOfDuties.Text = ""
                End If
                Dim str As String
                str = "$('#DialogBackground').height($(document).height()-1);$('#DialogBackground').width($(window).width());$('#DialogBackground').css('visibility','visible');$('#pnlVendor').css('visibility','visible');" & _
                " $('#pnlVendor').css('left',($(window).width() - $('#pnlVendor').width())/2); "
                ScriptManager.RegisterStartupScript(Page, Page.GetType(), "pnlVendor", str, True)
            Else
                AlertMessage(" Only Transport / Admin can fill Vendor and No of duties")
                Exit Sub
            End If
        End If
        'If e.CommandName = "EditVendor" Then
        'If CampaignID = 94 Then
        '    lblVendorError.Text = ""
        '    Dim Vendor As LinkButton = row.FindControl("lblVendor")
        '    cboVendor.ClearSelection()
        '    cboVendor.Items.FindByText(Vendor.Text).Selected = True
        '    Dim NoOfDuty As Label = row.FindControl("lblNoofDuties")
        '    txtNoOfDuties.Text = NoOfDuty.Text
        '    Dim str As String
        '    str = "$('#DialogBackground').height($(document).height()-1);$('#DialogBackground').width($(window).width());$('#DialogBackground').css('visibility','visible');$('#pnlVendor').css('visibility','visible');" & _
        '    " $('#pnlVendor').css('left',($(window).width() - $('#pnlVendor').width())/2); "
        '    ScriptManager.RegisterStartupScript(Page, Page.GetType(), "pnlVendor", str, True)
        'Else
        '    AlertMessage(" Only Transport / Admin can Edit Vendor and No of duties")
        '    Exit Sub
        'End If
        'End If
            '-----------------------
            Dim db As New DBAccess("CRM")
            Dim IsManager As Boolean = dbManager.ReturnValue("SELECT IsManager FROM tbl_AgentMaster WHERE AgentID = '" & AgentID & "'", False)
            dbManager = Nothing
            If e.CommandName = "Approve" Then
                If IsManager Then
                    row.FindControl("lnkApprove").Visible = False
                    row.FindControl("lnkReject").Visible = True
                    row.FindControl("lblAStatus").Visible = True
                    CType(row.FindControl("lblAStatus"), Label).Text = "Approved"
                    db.slDataAdd("Flag", 1)
                    db.slDataAdd("ApprovedBy", AgentID)
                    db.slDataAdd("IdColumn", lblRowindex.Text)
                    db.Executeproc("usp_ApproveSpecailCab")
                    db = Nothing
                    fillgrid()
                    sendmail("Approve", dtData.Rows(0)("DateOnly").ToString, dtData.Rows(0)("HourMinute").ToString, row.RowIndex)
                Else
                    AlertMessage(" Only Process AVP can approve this request")
                    Exit Sub
                End If
            ElseIf e.CommandName = "Reject" Then
                If IsManager Then
                    row.FindControl("lnkApprove").Visible = True
                    row.FindControl("lnkReject").Visible = False
                    row.FindControl("lnkCancel").Visible = False
                    row.FindControl("lblAStatus").Visible = True
                    CType(row.FindControl("lblAStatus"), Label).Text = "Rejected"
                    db = New DBAccess("CRM")
                    db.slDataAdd("Flag", 0)
                    db.slDataAdd("ApprovedBy", AgentID)
                    db.slDataAdd("IdColumn", lblRowindex.Text)
                    db.Executeproc("usp_ApproveSpecailCab")
                    db = Nothing
                    fillgrid()
                    sendmail("Reject", dtData.Rows(0)("DateOnly").ToString, dtData.Rows(0)("HourMinute").ToString, row.RowIndex)
                Else
                    AlertMessage(" Only Process AVP can reject this request")
                    Exit Sub
                End If
            ElseIf e.CommandName = "CancelRequest" Then
                If IsManager Then
                    row.FindControl("lnkApprove").Visible = False
                    row.FindControl("lnkReject").Visible = False
                    row.FindControl("lnkCancel").Visible = False
                    row.FindControl("lblAStatus").Visible = True
                    CType(row.FindControl("lblAStatus"), Label).Text = "Cancelled"
                    db = New DBAccess("CRM")
                    db.slDataAdd("Flag", 2)
                    db.slDataAdd("CancelledBy", AgentID)
                    db.slDataAdd("IdColumn", lblRowindex.Text)
                    db.Executeproc("usp_ApproveSpecailCab")
                    db = Nothing
                    fillgrid()
                    sendmail("Cancel", dtData.Rows(0)("DateOnly").ToString, dtData.Rows(0)("HourMinute").ToString, row.RowIndex)
                Else
                    AlertMessage(" Only Process AVP can Cancel this request")
                    Exit Sub
                End If
            End If
    End Sub
    Protected Sub GdPendingCab_RowDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles GdPendingCab.RowDataBound
        If e.Row.RowType = DataControlRowType.DataRow Then
            Dim row As DataRow = CType(e.Row.DataItem, System.Data.DataRowView).Row
            If row("AvailabilityTime") = "Update" Then
                e.Row.FindControl("lnkAvailabilityTime").Visible = True
                e.Row.FindControl("lblAvailabilityTime").Visible = False
                CType(e.Row.FindControl("lnkAvailabilityTime"), LinkButton).Text = row("AvailabilityTime")
            Else
                e.Row.FindControl("lnkAvailabilityTime").Visible = False
                e.Row.FindControl("lblAvailabilityTime").Visible = True
                CType(e.Row.FindControl("lblAvailabilityTime"), Label).Text = row("AvailabilityTime")
            End If
            If row("Invoice") = "Update" Then
                e.Row.FindControl("lnkInvoice").Visible = True
                e.Row.FindControl("lblInvoice").Visible = False
                CType(e.Row.FindControl("lnkInvoice"), LinkButton).Text = row("Invoice")
            Else
                e.Row.FindControl("lnkInvoice").Visible = False
                e.Row.FindControl("lblInvoice").Visible = True
                CType(e.Row.FindControl("lblInvoice"), Label).Text = row("Invoice")
            End If
            If IsDBNull(row("Approved")) Then
                e.Row.FindControl("lnkApprove").Visible = True
                e.Row.FindControl("lnkReject").Visible = True
                e.Row.FindControl("lnkCancel").Visible = False
                e.Row.FindControl("lblAStatus").Visible = False
            ElseIf row("Approved") Then
                e.Row.FindControl("lnkApprove").Visible = False
                e.Row.FindControl("lnkReject").Visible = False
                e.Row.FindControl("lnkCancel").Visible = True
                e.Row.FindControl("lblAStatus").Visible = True
                CType(e.Row.FindControl("lblAStatus"), Label).Text = "Approved"
            Else
                e.Row.FindControl("lnkApprove").Visible = False
                e.Row.FindControl("lnkReject").Visible = False
                e.Row.FindControl("lnkCancel").Visible = False
                e.Row.FindControl("lblAStatus").Visible = True
                CType(e.Row.FindControl("lblAStatus"), Label).Text = "Rejected"
            End If
            If row("Vendor") <> "" Then
                'e.Row.FindControl("lnkVendor").Visible = False
                'CType(e.Row.FindControl("lblVendor"), Label).Visible = True
                'CType(e.Row.FindControl("lblVendor"), Label).Text = row("Vendor").ToString
                'CType(e.Row.FindControl("lblVendor"), LinkButton).Visible = True
                CType(e.Row.FindControl("lnkVendor"), LinkButton).Text = row("Vendor").ToString
            End If

            If row("IsCancelled") Then ' In Case Request Cancelled
                e.Row.FindControl("lnkApprove").Visible = False
                e.Row.FindControl("lnkReject").Visible = False
                e.Row.FindControl("lnkCancel").Visible = False
                e.Row.FindControl("lblAStatus").Visible = True
                CType(e.Row.FindControl("lblAStatus"), Label).Text = "Cancelled"
            End If

            If CType(e.Row.FindControl("lblAStatus"), Label).Text = "Approved" Then
                e.Row.FindControl("lnkInvoice").Visible = True
                e.Row.FindControl("lnkAvailabilityTime").Visible = True
            Else
                e.Row.FindControl("lnkInvoice").Visible = False
                e.Row.FindControl("lnkAvailabilityTime").Visible = False
            End If
           
        End If
    End Sub
#End Region
#Region "--- Events ---"
    Protected Sub btnUpdate_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnUpdate.Click
        If Not txtHr.Text = "" And Not txtMin.Text = "" Then
            Dim db As New DBAccess("CRM")
            If txtMin.Text.ToString.Length < 2 Then
                db.slDataAdd("AvailabilityTime", ucDateFrom.Text & " " & txtHr.Text.ToString & ":0" & txtMin.Text.ToString & ":00")
            ElseIf txtMin.Text.ToString.Length < 2 Then
                db.slDataAdd("AvailabilityTime", ucDateFrom.Text & " 0" & txtHr.Text.ToString & ":" & txtMin.Text.ToString & ":00")
            Else
                db.slDataAdd("AvailabilityTime", ucDateFrom.Text & " " & txtHr.Text.ToString & ":" & txtMin.Text.ToString & ":00")
            End If
            db.UpdateinTable("tbl_data_SpecialCab", "IdCol=" & lblRowindex.Text)
            fillgrid()
            db = Nothing
        Else
            Dim str As String
            str = "$('#DialogBackground').height($(document).height()-10);$('#DialogBackground').width($(window).width());$('#DialogBackground').css('visibility','visible');$('#PnlTime').css('visibility','visible');" & _
            " $('#PnlTime').css('left',($(window).width() - $('#PnlTime').width())/2); "
            ScriptManager.RegisterStartupScript(Page, Page.GetType(), "PnlTime", str, True)
            AlertMessage("Please fill Hr/Min")
        End If
    End Sub
    Protected Sub ImageButton1_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton1.Click
        'fillgrid()
        'GridViewExportUtil.Export(breadcrumbs.CurrentPage & ".xls", Me.GdPendingCab)
        Dim dt As New DataTable
        Dim db As New DBAccess
        Dim startday As Integer, endday As Integer
        If CboPeriod.SelectedValue = 10 Then
            startday = ucDateFrom.yyyymmdd
            endday = UcDateTo.yyyymmdd
        Else
            db = New DBAccess
            db.slDataAdd("Period", CboPeriod.SelectedValue)
            db.slDataAdd("Campaignid", CampaignID)
            Dim dr As DataRow = db.ReturnRow("usp_GetStart_EndDateForAPeriod", True)
            db = Nothing
            startday = dr(0)
            endday = dr(1)
        End If
        db = Nothing
        db = New DBAccess("CRM")
        db.slDataAdd("Flag", 1)
        db.slDataAdd("ProcessID", CboProcess.SelectedValue)
        db.slDataAdd("UserCampaign", CampaignID)
        db.slDataAdd("DateFrom", startday)
        db.slDataAdd("DateTo", endday)
        db.slDataAdd("AgentID", AgentID)
        dt = db.ReturnTable("usp_PendingSpecialCab", , True)
        db = Nothing
        Dim gv As New GridView
        gv.DataSource = dt
        gv.DataBind()
        GridViewExportUtil.Export(breadcrumbs.CurrentPage & ".xls", gv)
    End Sub
    Protected Sub CboPeriod_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles CboPeriod.SelectedIndexChanged
        If CboPeriod.SelectedValue = 10 Then
            UcDateFrom1.Visible = True
            UcDateTo.Visible = True
            lblAnd.Visible = True
            fillgrid()
        Else
            UcDateFrom1.Visible = False
            UcDateTo.Visible = False
            lblAnd.Visible = False
            fillgrid()
        End If
    End Sub
    Protected Sub imgfav_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles imgfav.Click
        Common.AddToFav(AgentID, "Special Cab")
        SuccessMessage("Report has been added to your favourite list")
        fillgrid()
    End Sub
    Protected Sub btnRefresh_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnRefresh.Click
        fillgrid()
    End Sub
    Protected Sub ucDateFrom_Changed(ByVal sender As Object, ByVal e As System.EventArgs) Handles ucDateFrom.Changed
        If ucDateFrom.value < lblDTtoCheck.Text Then
            AlertMessage("Availability Date can not be less than Requestes Date")
        End If
        Dim str As String
        str = "$('#DialogBackground').height($(document).height()-10);$('#DialogBackground').width($(window).width());$('#DialogBackground').css('visibility','visible');$('#PnlTime').css('visibility','visible');" & _
        " $('#PnlTime').css('left',($(window).width() - $('#PnlTime').width())/2); "
        ScriptManager.RegisterStartupScript(Page, Page.GetType(), "PnlTime", str, True)
    End Sub
    Protected Sub CboProcess_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles CboProcess.SelectedIndexChanged
        fillgrid()
    End Sub
    Protected Sub btnUpdateInvoice_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnUpdateInvoice.Click
        UpdateInvoice()
    End Sub
    Protected Sub btnUpdateVendor_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnUpdateVendor.Click
        UpdateVendor()
    End Sub
#End Region
#Region "---Mail Function"
    Private Sub sendmail(ByVal strStatus As String, ByVal strDate As String, ByVal strTime As String, ByVal row As Int16)
        Dim lbl1 As Label = GdPendingCab.Rows(row).FindControl("lblAgentID")
        Dim lbl2 As Label = GdPendingCab.Rows(row).FindControl("lblAgentName")
        Dim lbl3 As Label = GdPendingCab.Rows(row).FindControl("lblProcess")
        Dim lbl4 As Label = GdPendingCab.Rows(row).FindControl("lblAddress")
        Dim lbl5 As Label = GdPendingCab.Rows(row).FindControl("lblReason")
        Dim lbl6 As Label = GdPendingCab.Rows(row).FindControl("lblType")
        Dim lbl7 As Label = GdPendingCab.Rows(row).FindControl("lblRemarks")
        Dim dt As New DataTable
        Dim strCC As String
        Dim db As New DBAccess("CRM")
        db.slDataAdd("AgentId", lbl1.Text)
        dt = db.ReturnTable("usp_SupervisorEmails", , True)
        db = Nothing
        strCC = dt.Rows(0).Item("MailCC")
        strCC = strCC.ToLower.Replace(",hroperations@niit-tech.com", "").Replace("hroperations@niit-tech.com", "")
        If strCC.Trim = "" Then
            strCC = "transporthelpdesk@NIIT-TECH.com"
        End If
        Dim objWSMail As New ServiceReference1.Service1SoapClient
        Dim strFrom As String = System.Configuration.ConfigurationManager.AppSettings("FROM")
        Dim MailSubject As String
        If strStatus = "Reject" Then
            MailSubject = "Special Cab Request Rejected"
        ElseIf strStatus = "Cancel" Then
            MailSubject = "Special Cab Request Cancelled"
        Else
            MailSubject = "Special Cab Request Approved"
        End If
        Dim strMailBody As String = ""
        strMailBody += "<html xmlns='http://www.w3.org/1999/xhtml'>"
        strMailBody += "<body style='font-family: Verdana; font-size: .8em'>"
        If strStatus = "Reject" Then
            strMailBody += "<strong>Special Cab Request Rejected for: " & lbl2.Text & "</strong><br /><br />"
            strMailBody += "<strong>Rejected By: " & UserName & "</strong><br /><br />"
        ElseIf strStatus = "Cancel" Then
            strMailBody += "<strong>Special Cab Request has been Cancelled for: " & lbl2.Text & "</strong><br /><br />"
            strMailBody += "<strong>Cancelled By: " & UserName & "</strong><br /><br />"
        Else
            strMailBody += "<strong>Special Cab Request Approved for: " & lbl2.Text & "</strong><br /><br />"
            strMailBody += "<strong>Approved By: " & UserName & "</strong><br /><br />"
        End If
        strMailBody += "<table border='1' width='90%' style='border: 1px solid; border-collapse: collapse; font-family: Verdana; font-size: .8em'>"
        strMailBody += "<tr bgcolor='#B8CCE4'>"
        strMailBody += "<td align='center'><b>Process Name</b></td>"
        strMailBody += "<td align='center'><b>Emp. Code</b></td>"
        strMailBody += "<td align='center'><b>Emp. Name</b></td>"
        strMailBody += "<td align='center'><b>Address</b></td>"
        strMailBody += "<td align='center'><b>Requested Date & Time</b></td>"
        strMailBody += "<td align='center'><b>Reason</b></td>"
        strMailBody += "<td align='center'><b>Type</b></td>"
        strMailBody += "<td align='center'><b>Remarks</b></td>"
        strMailBody += "<td align='center'><b>Status</b></td>"
        If strStatus = "Reject" Then
            strMailBody += "<td align='center'><b>Rejected By</b></td>"
        ElseIf strStatus = "Cancel" Then
            strMailBody += "<td align='center'><b>Cancelled By</b></td>"
        Else
            strMailBody += "<td align='center'><b>Approved By</b></td>"
        End If
        strMailBody += "</tr>"
        strMailBody += "<tr >"
        strMailBody += "<td align='center'>" & lbl3.Text & "</td>"
        strMailBody += "<td align='center'>" & lbl1.Text & "</td>"
        strMailBody += "<td align='center'>" & lbl2.Text & "</td>"
        strMailBody += "<td align='center'>" & lbl4.Text & "</td>"
        strMailBody += "<td align='center'>" & strDate & " " & strTime & "</td>"
        strMailBody += "<td align='center'>" & lbl5.Text & "</td>"
        strMailBody += "<td align='center'>" & lbl6.Text & "</td>"
        strMailBody += "<td align='center'>" & lbl7.Text & "</td>"
        If strStatus = "Reject" Then
            strMailBody += "<td align='center'>Rejected</td>"
        ElseIf strStatus = "Cancel" Then
            strMailBody += "<td align='center'>Cancelled</td>"
        Else
            strMailBody += "<td align='center'>Approved</td>"
        End If
        strMailBody += "<td align='center'>" & UserName & "</td>"
        strMailBody += "</tr></table><br />"
        strMailBody += "<br /><br /><hr/>This mail was sent using the "
        strMailBody += "<a href='http://termsmonitor.niit-tech.com/'>TermsMonitor&reg;</a> Mail Service.We request you not to reply this message."
        strMailBody += "<br /><br />In case you wish to report issues with this mail, please send mail to mailto:helpdesk@niit-tech.com <br /> "
        strMailBody += "<br />This e-mail is confidential and may also be privileged.If you are not the intended recipient, please notify helpdesk immediately; you should not copy or use it for any purpose,nor disclose its contents to any other person."
        strMailBody += "</body>"
        strMailBody += "</html>"

        objWSMail.MailSend(System.Configuration.ConfigurationManager.AppSettings("TPThelpdesk"), MailSubject, strFrom, "Special Cab Request", strMailBody, "", strCC, System.Configuration.ConfigurationManager.AppSettings("CSSBCC"))
        'objWSMail.MailSend("rajendra.5.rana@niit-tech.com", MailSubject, strFrom, "Special Cab Request", strMailBody, "", "", "")
        objWSMail = Nothing
        If strStatus = "Reject" Then
            SuccessMessage(" Special Cab Request has been Rejected.")
        ElseIf strStatus = "Cancel" Then
            SuccessMessage(" Special Cab Request has been Cancelled.")
        Else
            SuccessMessage(" Special Cab Request has been Approved.")
        End If
    End Sub
#End Region
#Region "--- Utility ---"
    Private Sub AlertMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMFail"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub

    Private Sub SuccessMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMSuccess"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub
#End Region

End Class
