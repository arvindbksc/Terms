﻿Imports com.nss.DBAccess
Imports System.Data
Partial Class Staffing_Roster_GetFinalRoster
    Inherits System.Web.UI.Page

    Private Sub LoadData()

    End Sub
    Private Sub FillCommonFilters()
        Dim db As New DBAccess
        Dim dt As DataTable = db.ReturnTable("select * from tbl_Reports_DatePeriods")
        db = Nothing
        CboPeriod.DataTextField = "Caption"
        CboPeriod.DataValueField = "Period"
        CboPeriod.DataSource = dt
        CboPeriod.DataBind()
    End Sub
End Class
