﻿Imports com.nss.DBAccess
Imports System.Data
Imports System.Text
Partial Class Staffing_Roster_ShiftWiseRoster
    Inherits System.Web.UI.Page
#Region "Properties"
    Property CampaignID() As Integer
        Get
            Return 0 'ViewState("CampaignID")
        End Get
        Set(ByVal value As Integer)
            'ViewState("CampaignID") = value
        End Set
    End Property
    Property AgentID() As String
        Get
            Return ViewState("AgentID")
        End Get
        Set(ByVal value As String)
            ViewState("AgentID") = value
        End Set
    End Property
    Property CurrentDate() As Date
        Get
            Return ViewState("CurrentDate")
        End Get
        Set(ByVal value As Date)
            ViewState("CurrentDate") = value
        End Set
    End Property
#End Region
#Region "Load"
    Private Sub LoadData()
        Dim dbDate As New DBAccess
        CurrentDate = dbDate.ReturnValue("Select GetDate()", False)
        ucDateFrom.value = CurrentDate
        UcDateTo.value = CurrentDate
        dbDate = Nothing
        Common.FillProcessCampaigns(CboProcess, cboCampaigns, AgentID, CampaignID)
        Dim lstProcess As New ListItem
        lstProcess.Value = 0
        lstProcess.Text = "All"
        If CboProcess.Items.Contains(lstProcess) Then
            CboProcess.Items.Remove(lstProcess)
        End If
    End Sub
#End Region
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        HumanMessage.Style.Item("visibility") = "hidden"
        If Not IsPostBack Then
            If Session("AgentID") <> "" Then
                CampaignID = Session("CampaignID")
                AgentID = Session("AgentID")
                PanelReports.Controls.Add(Common.GetMenu(Request.Url, AgentID, Request.ApplicationPath))
                LoadData()
                fillgrid()
            End If
        End If
    End Sub
#Region "Support Functions"
    Private Sub fillgrid()
        Dim startday As Integer, endday As Integer
        Dim startdate As Date, enddate As Date
        startday = ucDateFrom.yyyymmdd
        endday = UcDateTo.yyyymmdd
        breadcrumbs.CurrentPage = " Shift Wise Roster Between " & IntegerToDateString(startday) & "  and " & IntegerToDateString(endday)
        Dim db As DBAccess
        Dim dt As DataTable
        db = New DBAccess
        startdate = db.ReturnValue("select CONVERT(datetime,convert(varchar," & startday & "))", False)
        enddate = db.ReturnValue("select CONVERT(datetime,convert(varchar," & endday & "))", False)
        db = Nothing
        Dim days As Integer
        days = DateDiff(DateInterval.Day, startdate, enddate)
        If days > 30 Then
            AlertMessage("Date not in valid range, It will shows data for 30 days")
            Exit Sub
        End If
        db = New DBAccess("CRM")
        db.slDataAdd("StartDate", startday)
        db.slDataAdd("EndDate", endday)
        db.slDataAdd("processid", CboProcess.SelectedValue)
        db.slDataAdd("AgentWise", 0)
        dt = db.ReturnTable("usp_getRosterReport", , True)
        db = Nothing

        gvRosterReport.AutoGenerateColumns = False
        Dim dtReport As New DataTable
        Dim bouncol As BoundField
        gvRosterReport.Columns.Clear()
        bouncol = New BoundField
        gvRosterReport.Columns.Add(bouncol)
        dtReport.Columns.Add("ShiftIn", System.Type.GetType("System.String"))
        bouncol = New BoundField
        bouncol.HeaderText = "Shift"
        bouncol.DataField = "ShiftIn"
        gvRosterReport.Columns.Add(bouncol)
        While (startdate <= enddate)
            dtReport.Columns.Add(startdate.Month.ToString.PadLeft(2, "0") & startdate.Day.ToString.PadLeft(2, "0"), System.Type.GetType("System.String"))
            bouncol = New BoundField
            bouncol.HeaderText = startdate.Day.ToString.PadLeft(2, "0")
            bouncol.DataField = startdate.Month.ToString.PadLeft(2, "0") & startdate.Day.ToString.PadLeft(2, "0")
            bouncol.NullDisplayText = "."
            gvRosterReport.Columns.Add(bouncol)
            startdate = startdate.AddDays(1)
        End While
        Dim curshiftid As String = ""
        Dim curdate As String = ""
        Dim reporow As DataRow
        For Each row In dt.Rows
            If curshiftid.ToLower <> row("ShiftIn").ToString.ToLower Then
                If curdate.ToLower <> row("Rosterdate").ToString.ToLower Then
                    curshiftid = row("ShiftIn")
                    curdate = row("Rosterdate")
                    reporow = dtReport.NewRow

                    reporow("ShiftIn") = row("ShiftIn")
                    dtReport.Rows.Add(reporow)
                    reporow.Item(row("Rosterdate").ToString.Substring(4)) = row("EmpName")
                Else
                    curshiftid = row("ShiftIn")
                    curdate = row("Rosterdate")
                    reporow = dtReport.NewRow
                    reporow("ShiftIn") = row("ShiftIn")
                    dtReport.Rows.Add(reporow)
                    reporow.Item(row("Rosterdate").ToString.Substring(4)) = row("EmpName")
                End If
            Else
                If curdate.ToLower = row("Rosterdate").ToString.ToLower Then
                    curshiftid = row("ShiftIn")
                    curdate = row("Rosterdate")
                    reporow = dtReport.NewRow
                    reporow("ShiftIn") = row("ShiftIn")
                    dtReport.Rows.Add(reporow)
                    reporow.Item(row("Rosterdate").ToString.Substring(4)) = row("EmpName")
                Else
                    For Each col As DataColumn In dtReport.Columns
                        Dim flag As Boolean = False
                        If col.ColumnName = row("Rosterdate").ToString.Substring(4).ToLower Then
                            For Each row1 As DataRow In dtReport.Rows
                                If IsDBNull(row1.Item(row("Rosterdate").ToString.Substring(4))) And row1.Item("shiftin").ToString = curshiftid Then
                                    row1.Item(row("Rosterdate").ToString.Substring(4)) = row("EmpName")

                                    Exit For
                                Else
                                    For Each row2 As DataRow In dtReport.Rows
                                        If IsDBNull(row2.Item(row("Rosterdate").ToString.Substring(4))) Then
                                            If row2.Item("shiftin").ToString = curshiftid Then
                                                row2.Item(row("Rosterdate").ToString.Substring(4)) = row("EmpName")
                                                flag = False
                                                Exit For
                                            End If

                                        Else
                                            If row2.Item(row("Rosterdate").ToString.Substring(4)) = row("EmpName") Then
                                                flag = False
                                                Exit For
                                            Else
                                                flag = True
                                            End If
                                        End If
                                    Next
                                    If flag = True Then
                                        reporow = dtReport.NewRow
                                        reporow("ShiftIn") = row("ShiftIn")
                                        dtReport.Rows.Add(reporow)
                                        reporow.Item(row("Rosterdate").ToString.Substring(4)) = row("EmpName")
                                        Exit For
                                    Else
                                        Exit For
                                    End If
                                End If
                            Next
                        End If
                    Next
                End If
            End If
        Next
        gvRosterReport.DataSource = dtReport
        gvRosterReport.DataBind()
        dtReport = Nothing
    End Sub
    Private Function IntegerToDateString(ByVal d As Integer) As String
        Return d.ToString.Substring(0, 4) & "-" & d.ToString.Substring(4, 2) & "-" & d.ToString.Substring(6, 2)
    End Function
#End Region
#Region "Events"
    Protected Sub btnRefresh_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnRefresh.Click
        fillgrid()
    End Sub
    Protected Sub imgfav_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles imgfav.Click
        Common.AddToFav(AgentID, "Shift wise Roster")
        SuccessMessage("Report has been added to your favourite list")
        fillgrid()
    End Sub
    Protected Sub CboProcess_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles CboProcess.SelectedIndexChanged
        fillgrid()
    End Sub
    Protected Sub ImageButton1_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton1.Click
        fillgrid()
        GridViewExportUtil.Export(breadcrumbs.CurrentPage & ".xls", Me.gvRosterReport)
    End Sub
    Protected Sub ucDateFrom_Changed(ByVal sender As Object, ByVal e As System.EventArgs) Handles ucDateFrom.Changed
        fillgrid()
    End Sub

    Protected Sub UcDateTo_Changed(ByVal sender As Object, ByVal e As System.EventArgs) Handles UcDateTo.Changed
        fillgrid()
    End Sub
#End Region
#Region "Utility"

    Private Sub AlertMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMFail"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub

    Private Sub SuccessMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMSuccess"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub
    Private Sub HideMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMSuccess"
        HumanMessage.Style.Item("visibility") = "hidden"
    End Sub

#End Region
End Class
