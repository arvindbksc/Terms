﻿Imports com.nss.DBAccess
Imports System.Data
Partial Class Staffing_Roster_RosterReport
    Inherits System.Web.UI.Page

#Region "--- Properties ---"
    Property AgentID() As String
        Get
            Return ViewState("AgentID")
        End Get
        Set(ByVal value As String)
            ViewState("AgentID") = value
        End Set
    End Property
    Property CampaignID() As Integer
        Get
            Return ViewState("CampaignID")
        End Get
        Set(ByVal value As Integer)
            ViewState("CampaignID") = value
        End Set
    End Property
#End Region

#Region "Load"
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            If Session("AgentID") <> "" Then
                CampaignID = Session("CampaignID")
                AgentID = Session("Agentid")
                PanelReports.Controls.Add(Common.GetMenu(Request.Url, AgentID, Request.ApplicationPath))
                FillCommonFilters()

                UcDateTo.Visible = False
                UcDateFrom.Visible = False
                lblAnd.Visible = False

                getshift()
                getroster()
            End If
        End If
    End Sub

    Private Sub FillCommonFilters()
        Dim db As New DBAccess
        Dim dt As DataTable = db.ReturnTable("select * from tbl_Reports_DatePeriods")
        db = Nothing
        Dim dr As DataRow = dt.NewRow
        dr(0) = 10
        dr(1) = "Between"
        dt.Rows.Add(dr)
        CboPeriod.DataTextField = "Caption"
        CboPeriod.DataValueField = "Period"
        CboPeriod.DataSource = dt
        CboPeriod.DataBind()
        Common.FillProcessCampaigns(CboProcess, cboCampaigns, AgentID, CampaignID)
    End Sub

#End Region

#Region "Support Functions"

    Private Sub getroster()
        Dim db As New DBAccess
        Dim startday As Integer, endday As Integer
        If CboPeriod.SelectedValue = 10 Then
            startday = UcDateFrom.yyyymmdd
            endday = UcDateTo.yyyymmdd
        Else
            db = New DBAccess
            db.slDataAdd("Period", CboPeriod.SelectedValue)
            db.slDataAdd("Campaignid", CampaignID)
            Dim dr As DataRow = db.ReturnRow("usp_GetStart_EndDateForAPeriod", True)
            db = Nothing
            startday = dr(0)
            endday = dr(1)
        End If
        db = Nothing
        '----------------------

        db = New DBAccess("report")
        Dim dt As DataTable
        db.slDataAdd("AgentID", AgentID)
        db.slDataAdd("DateFrom", startday)
        db.slDataAdd("DateTo", endday)

        If Cboshiftin.SelectedItem.Text = "All" Then
            db.slDataAdd("Shiftin", "0")
        Else
            db.slDataAdd("Shiftin", Cboshiftin.SelectedItem.Text.Substring(0, Cboshiftin.SelectedItem.Text.IndexOf("(")))
        End If

        If CboProcess.SelectedItem.Text = "All" Then
            db.slDataAdd("Process", 0)
        Else
            db.slDataAdd("Process", CboProcess.SelectedValue)
        End If

        dt = db.ReturnTable("usp_RosterSummary", , True)
        db = Nothing

        gvRosterDeatils.AutoGenerateColumns = True

        breadcrumbs.CurrentPage = "Roster Summary "
        If dt.Rows.Count > 0 Then
            gvRosterDeatils.DataSource = dt.DefaultView
            gvRosterDeatils.DataBind()
        Else
            gvRosterDeatils.DataSource = Nothing
            gvRosterDeatils.DataBind()
        End If
    End Sub

    Private Sub getshift()
        Dim db As New DBAccess("CRM")
        Dim dtshift As DataTable
        'dtshift = db.ReturnTable("select ShiftId, Shift +'('+ convert(varchar,TimeIn) + ' To ' +CONVERT(varchar,[TimeOut]) +')' As Shift  from tbl_Config_RosterShift order by shiftid", , False)
        dtshift = db.ReturnTable("usp_getRosterShifts", , True)
        db = Nothing
        Dim dr As DataRow

        dr = dtshift.NewRow
        dr("Shift") = "All"
        dr("ShiftId") = 0
        dtshift.Rows.Add(dr)

        Cboshiftin.DataTextField = "Shift"
        Cboshiftin.DataValueField = "shiftid"
        Cboshiftin.DataSource = dtshift.DefaultView
        Cboshiftin.DataBind()
    End Sub

#End Region

#Region "Event"
    Protected Sub CboPeriod_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles CboPeriod.SelectedIndexChanged
        If CboPeriod.SelectedValue = 10 Then
            UcDateFrom.Visible = True
            UcDateTo.Visible = True
            lblAnd.Visible = True
            getroster()
        Else
            UcDateFrom.Visible = False
            UcDateTo.Visible = False
            lblAnd.Visible = False
            getroster()
        End If
    End Sub
    Protected Sub CboProcess_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles CboProcess.SelectedIndexChanged
        getroster()
    End Sub
    Protected Sub imgfav_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles imgfav.Click
        Common.AddToFav(AgentID, "Roster Summary")
        SuccessMessage("Report has been added to your favourite list")
        getroster()
    End Sub
    Protected Sub btnRefresh_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnRefresh.Click
        getroster()
    End Sub
    Protected Sub ImageButton1_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton1.Click
        getroster()
        GridViewExportUtil.Export(breadcrumbs.CurrentPage & ".xls", Me.gvRosterDeatils)
    End Sub

    Protected Sub Cboshiftin_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles Cboshiftin.SelectedIndexChanged
        getroster()
    End Sub
    Protected Sub UcDateFrom_Changed(ByVal sender As Object, ByVal e As System.EventArgs) Handles UcDateFrom.Changed
        getroster()
    End Sub

    Protected Sub UcDateTo_Changed(ByVal sender As Object, ByVal e As System.EventArgs) Handles UcDateTo.Changed
        getroster()
    End Sub

#End Region

#Region "Utility"
    Private Sub AlertMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMFail"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub

    Private Sub SuccessMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMSuccess"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub
#End Region

   
End Class
