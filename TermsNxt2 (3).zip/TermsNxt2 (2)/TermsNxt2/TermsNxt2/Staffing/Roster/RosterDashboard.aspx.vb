﻿Imports com.nss.DBAccess
Imports System.Data
Partial Class Staffing_Roster_RosterDashboard
    Inherits System.Web.UI.Page
#Region "--- Properties ---"
    Property AgentID() As String
        Get
            Return ViewState("AgentID")
        End Get
        Set(ByVal value As String)
            ViewState("AgentID") = value
        End Set
    End Property
    Property Currentdate() As String
        Get
            Return ViewState("Currentdate")
        End Get
        Set(ByVal value As String)
            ViewState("Currentdate") = value
        End Set
    End Property
#End Region
#Region "--- Load ---"
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        HumanMessage.Style.Item("visibility") = "hidden"
        If Not IsPostBack Then
            AgentID = Session("AgentID")
            Panelmenu.Controls.Add(Common.GetMenu(Request.Url, AgentID, Request.ApplicationPath))
            Dim dbdate As New DBAccess("CRM")
            Currentdate = dbdate.ReturnValue("select convert(varchar,getdate(),112)", False)
            dbdate = Nothing
            FillCommonFilters()
            'ucDateFrom.value = a.ToString("dd-MMM-yyyy")
            FillProcess()
            GetCutOffTime()
            FillGraph()
            UcDateTo.Visible = False
            ucDateFrom.Visible = False
            lblAnd.Visible = False
        Else
            Panelmenu.Controls.Add(Common.GetMenu(Request.Url, AgentID, Request.ApplicationPath))
        End If
    End Sub
    Private Sub FillCommonFilters()
        Dim db As New DBAccess
        Dim dt As DataTable = db.ReturnTable("select * from tbl_Reports_DatePeriods")
        db = Nothing
        Dim dr As DataRow = dt.NewRow
        dr(0) = 10
        dr(1) = "Between"
        dt.Rows.Add(dr)
        CboPeriod.DataTextField = "Caption"
        CboPeriod.DataValueField = "Period"
        CboPeriod.DataSource = dt
        CboPeriod.DataBind()

    End Sub
    Private Sub FillGraph()
        Dim db As New DBAccess
        Dim startday As Integer, endday As Integer
        If CboPeriod.SelectedValue = 10 Then
            startday = ucDateFrom.yyyymmdd
            endday = UcDateTo.yyyymmdd
        Else
            db = New DBAccess
            db.slDataAdd("Period", CboPeriod.SelectedValue)
            db.slDataAdd("Campaignid", 0)
            Dim dr As DataRow = db.ReturnRow("usp_GetStart_EndDateForAPeriod", True)
            db = Nothing
            startday = dr(0)
            endday = dr(1)
        End If
        ChartContainerInner.Controls.Clear()
        Dim objLink As HyperLink
        Dim objImg As Image
        For ictr = 1 To 4
            objLink = New HyperLink
            'objLink.NavigateUrl = "~/Graphs/EnlargedGraph.aspx?type=roster&groupby=" & ictr & "&KPA=" & ictr & "&GraphSize=200&periodfrom=" & startday & "&periodto=" & endday
            objLink.ID = "lnkKPA" & ictr
            objImg = New Image
            objImg.ImageUrl = "~/Graphs/thumbgraph.aspx?type=roster&groupby=" & ictr & "&KPA=" & ictr & "&GraphSize=200&periodfrom=" & startday & "&periodto=" & endday
            objImg.ID = "imgKPA" & ictr
            objImg.CssClass = "chart"
            objLink.Controls.Add(objImg)
            ChartContainerInner.Controls.Add(objLink)
        Next

    End Sub
#End Region
#Region "--- Events ---"
    Protected Sub btnRefresh_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnRefresh.Click
        FillProcess()
        FillGraph()
    End Sub
    Protected Sub ucDateFrom_Changed(ByVal sender As Object, ByVal e As System.EventArgs) Handles ucDateFrom.Changed
        FillProcess()
        FillGraph()
    End Sub
    Protected Sub imgSet_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles imgSet.Click
        SetCutOfftime()
    End Sub
    Protected Sub CboPeriod_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles CboPeriod.SelectedIndexChanged
        If CboPeriod.SelectedValue = 10 Then
            ucDateFrom.Visible = True
            UcDateTo.Visible = True
            lblAnd.Visible = True
            FillProcess()
            FillGraph()
        Else
            ucDateFrom.Visible = False
            UcDateTo.Visible = False
            lblAnd.Visible = False
            FillProcess()
            FillGraph()
        End If
       
    End Sub
#End Region
#Region "--- Grid Ops ---"
    Protected Sub gvAllProcess_RowCommand(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewCommandEventArgs) Handles gvAllProcess.RowCommand
        Dim row As GridViewRow = CType(CType(e.CommandSource, Control).NamingContainer, GridViewRow)
        If e.CommandName = "Send" Then
            Dim processid As Integer = gvAllProcess.DataKeys(row.RowIndex).Item("Processid").ToString
            SendMail(processid)
        End If
    End Sub
    Protected Sub gvAllProcess_RowDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles gvAllProcess.RowDataBound
        Dim chk As New Boolean
        If e.Row.RowType = DataControlRowType.DataRow Then
            Dim dr As DataRowView = e.Row.DataItem
            chk = gvAllProcess.DataKeys(e.Row.RowIndex).Item("count").ToString
            Dim img As Image
            Dim lbnMail As LinkButton
            If chk = True Then
                img = e.Row.Cells(1).Controls(1)
                lbnMail = e.Row.Cells(2).Controls(1)
                lbnMail.Text = ""
                img.ImageUrl = "~/_assets/img/yes.gif"
            Else
                img = e.Row.Cells(1).Controls(1)
                img.ImageUrl = "~/_assets/img/remove.gif"
            End If
        End If
    End Sub
#End Region

#Region "--- Support functions ---"

    Private Sub GetCutOffTime()
        Dim currenthour, currentmin As Integer
        currenthour = 0
        currentmin = 0
        While currenthour <= 23
            If currenthour < 10 Then
                cboHR.Items.Add("0" & currenthour.ToString)
            Else
                cboHR.Items.Add(currenthour.ToString)
            End If
            currenthour = currenthour + 1
        End While
        While currentmin <= 59
            If currentmin < 10 Then
                cboMnt.Items.Add("0" & currentmin.ToString)
            Else
                cboMnt.Items.Add(currentmin.ToString)
            End If
            currentmin = currentmin + 1
        End While
        Dim db As New DBAccess("CRM")
        Dim Time As String = db.ReturnValue("select SettingValue from tbl_Config_Campaign_Settings where Campaignid=94 and SettingName='CutOffTime'", False)
        db = Nothing

        Dim str() As String = Time.Split(":")
        cboHR.SelectedValue = str(0)
        cboMnt.SelectedValue = str(1)

    End Sub
    Private Sub SetCutOfftime()
        Dim db As New DBAccess("CRM")
        db.slDataAdd("SettingValue", cboHR.Text & ":" & cboMnt.Text)
        db.UpdateinTable("tbl_Config_Campaign_Settings", "Campaignid=94 and SettingName='CutOffTime'")
        db = Nothing
        SuccessMessage("New Cut Off time has been set")
        GetCutOffTime()
    End Sub
    Private Sub FillProcess()
        Dim db As New DBAccess
        Dim dt As New DataTable
        dt = db.ReturnTable("usp_TodaysPendingRoster", , True)
        db = Nothing
        gvAllProcess.DataSource = dt
        gvAllProcess.DataBind()
    End Sub
    Private Sub SendMail(ByVal ProcessId As Integer)
        Try
            Dim objWSMail As New ServiceReference2.MailSoapClient
            Dim strFrom As String = System.Configuration.ConfigurationManager.AppSettings("FROM")
            Dim MailSubject As String = "Roster has not been filled !!"
            Dim strMailBody As String = ""
            strMailBody += "<html xmlns='http://www.w3.org/1999/xhtml'>"
            strMailBody += "<body style='font-family: Verdana; font-size: .8em'>"
            strMailBody += "Hi All,<br /><br />"
            strMailBody += "Roster has not been filled for your process. Kindly fill the same at the earliest <FONT style='font-size:20px'>&#9786</FONT> !!!!<br /><br />"
            strMailBody += "Thanks & Regards,<br />"
            strMailBody += "Transport Helpdesk<br />"
            strMailBody += "(Extn: 3470 / 4388 : Mobile 9560993441)<br />"
            strMailBody += "<br /><br /><hr/><P> This mail was sent using the "
            strMailBody += "<a href='http://termsmonitor.niitsmartserve.com/'>TermsMonitor&reg;</a> Mail Service.We request you not to reply this message.</P>"
            strMailBody += "<br /><br />In case you wish to report issues with this mail, please send mail to mailto:helpdesk@niitsmartserve.com <br /> "
            strMailBody += "<br />This e-mail is confidential and may also be privileged.If you are not the intended recipient, please notify helpdesk immediately; you should not copy or use it for any purpose,nor disclose its contents to any other person."
            strMailBody += "</body>"
            strMailBody += "</html>"

            Dim db As New DBAccess("report")
            Dim dt As New DataTable
            db.slDataAdd("ProcessId", ProcessId)
            dt = db.ReturnTable("usp_getSupervisorEmails", , True)
            db = Nothing
            Dim MailTO = "", MailCC As String = ""
            For Each row As DataRow In dt.Rows
                If row.Item("Supervisors") <> "" Then
                    MailTO += row.Item("Supervisors") & ","
                End If
                If row.Item("Managers") <> "" Then
                    MailCC += row.Item("Managers") & ","
                End If
            Next
            dt = Nothing
            If MailTO = "" And MailCC = "" Then
                AlertMessage("No email-id has been configured for this process !!")
                Exit Sub
            ElseIf MailTO = "" Then
                MailTO = MailCC
            ElseIf MailCC = "" Then
                MailCC = MailTO
            End If
            MailTO = MailTO.Remove(MailTO.Length - 1)
            MailCC += System.Configuration.ConfigurationManager.AppSettings("TPTHELPDESK")

            objWSMail.MailSend(MailTO, strMailBody, "", MailCC, System.Configuration.ConfigurationManager.AppSettings("BCC"), "Roster Alert Mail<" & strFrom & ">", MailSubject)
            'objWSMail.MailSend("jatint@niitsmartserve.com", strMailBody, "", "rajendrar_nss@niitsmartserve.com", "rajendrar_nss@niitsmartserve.com", "Roster Alert Mail<" & strFrom & ">", MailSubject)
            objWSMail = Nothing
            SuccessMessage("Mail has been sent successfully...")
        Catch ex As Exception
            AlertMessage(ex.Message.ToString)
        End Try
    End Sub
#End Region
#Region "--- Utility ---"
    Private Sub AlertMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMFail"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub

    Private Sub SuccessMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMSuccess"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub
#End Region



End Class
