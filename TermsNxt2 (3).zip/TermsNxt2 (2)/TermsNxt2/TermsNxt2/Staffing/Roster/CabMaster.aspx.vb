﻿Imports com.nss.DBAccess
Imports System.Data
Partial Class PerfSum_CabMaster
    Inherits System.Web.UI.Page
#Region "-----Properties-----"

    Property CurrentDate() As Date
        Get
            Return ViewState("CurrentDate")
        End Get
        Set(ByVal value As Date)
            ViewState("CurrentDate") = value
        End Set
    End Property
    Property RosterDate() As Date
        Get
            Return ViewState("RosterDate")
        End Get
        Set(ByVal value As Date)
            ViewState("RosterDate") = value
        End Set
    End Property

    Property MinDate() As Date
        Get
            Return ViewState("MinDate")
        End Get
        Set(ByVal value As Date)
            ViewState("MinDate") = value
        End Set
    End Property

    Property ReportType() As Integer
        Get
            Return ViewState("ReportType")
        End Get
        Set(ByVal value As Integer)
            ViewState("ReportType") = value
        End Set
    End Property

    Property CurrentLevel() As Integer
        Get
            Return ViewState("CurrentLevel")
        End Get
        Set(ByVal value As Integer)
            ViewState("CurrentLevel") = value
        End Set
    End Property
    Property SupervisorID() As String
        Get
            Return ViewState("SupervisorID")
        End Get
        Set(ByVal value As String)
            ViewState("SupervisorID") = value
        End Set
    End Property
    Property UserID() As String
        Get
            Return ViewState("UserID")
        End Get
        Set(ByVal value As String)
            ViewState("UserID") = value
        End Set
    End Property
    Property AgentID() As String
        Get
            Return ViewState("AgentID")
        End Get
        Set(ByVal value As String)
            ViewState("AgentID") = value
        End Set
    End Property
    Property dtprevweek() As DataTable
        Get
            Return ViewState("dtprevweek")
        End Get
        Set(ByVal value As DataTable)
            ViewState("dtprevweek") = value
        End Set
    End Property
#End Region
#Region "Load"
    Private Sub getcab()
        Dim db As New DBAccess("CRM")
        Dim dt As DataTable = db.ReturnTable("usp_GetAllCabs", , True)
        If dt.Rows.Count > 0 Then
            gdcab.DataSource = dt.DefaultView
            gdcab.DataBind()
        End If
        gdcab.AutoGenerateColumns = True
    End Sub
    Private Sub getRoute()
        Dim db As New DBAccess("CRM")
        Dim dt As DataTable = db.ReturnTable("select * from tbl_Config_route", , False)
        If dt.Rows.Count > 0 Then
            cboRoute.DataTextField = "RouteName"
            cboRoute.DataValueField = "Routeid"
            cboRoute.DataSource = dt
            cboRoute.DataBind()
            cboeditroute.DataTextField = "RouteName"
            cboeditroute.DataValueField = "Routeid"
            cboeditroute.DataSource = dt
            cboeditroute.DataBind()
        End If
    End Sub
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        HumanMessage.Style.Item("visibility") = "hidden"
        If Not IsPostBack Then
            AgentID = Session("Agentid")
            SupervisorID = Session("UserID")
            UserID = Session("UserID")
            PanelReports.Controls.Add(Common.GetMenu(Request.Url, AgentID, Request.ApplicationPath))
            getcab()
            getRoute()
            lblReportName.CurrentPage = "Cab Master"
        End If
    End Sub
#End Region
#Region "GridOps"
    Protected Sub gdcab_RowCommand(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewCommandEventArgs) Handles gdcab.RowCommand
        Dim currentcommand As String = e.CommandName
        Dim currentrowindex As Integer = Int32.Parse(e.CommandArgument)
        Dim cabnumber As String = gdcab.DataKeys(currentrowindex).Value
        If currentcommand = "Editcab" Then
            'getRoute()
            Dim str1 As String
            str1 = "$('#DialogBackground').height($(document).height()-10);$('#DialogBackground').width($(window).width());$('#DialogBackground').css('visibility','visible');$('#pnleditcab').css('visibility','visible');" & _
            " $('#pnleditcab').css('left',($(window).width() - $('#pnleditcab').width())/2); "
            ScriptManager.RegisterStartupScript(Page, Page.GetType(), "Movedialog", str1, True)
            Dim db As New DBAccess("CRM")
            Dim dr As DataRow
            Dim strsql As String
            strsql = "select * from tbl_Data_Cab where cabnumber='" & cabnumber & "'"
            dr = db.ReturnRow(strsql, False)
            db = Nothing
            txteditcab.Text = cabnumber
            txtEditDriver.Text = dr.Item("driver").ToString
            Txteditdriverphone.Text = dr.Item("Driver_phone").ToString
            txteditcapacity.Text = dr.Item("capacity").ToString
            cboeditroute.SelectedValue = dr.Item("route").ToString
            dr = Nothing
        End If
    End Sub
#End Region
    
#Region "Event"
    Protected Sub lnkCab_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles lnkCab.Click
        Dim str As String
        str = "$('#DialogBackground').height($(document).height()-10);$('#DialogBackground').width($(window).width());$('#DialogBackground').css('visibility','visible');$('#pnlCab').css('visibility','visible');" & _
        " $('#pnlCab').css('left',($(window).width() - $('#pnlCab').width())/2); "
        ScriptManager.RegisterStartupScript(Page, Page.GetType(), "Movedialog", str, True)

    End Sub
    Protected Sub btncabok_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btncabok.Click
        Dim db As New DBAccess("CRM")
        db.slDataAdd("cabnumber", txtcab.Text)
        db.slDataAdd("Driver", txtDriver.Text)
        db.slDataAdd("Driver_phone", Txtdriverphone.Text)
        db.slDataAdd("Route", cboRoute.SelectedValue)
        db.slDataAdd("Capacity", txtcapacity.Text)
        db.Executeproc("usp_SaveCabDetail")
        'db.InsertinTable("tbl_Data_Cab")
        db = Nothing
        SuccessMessage("Cab detail for cab number " & txtcab.Text & " has been added")
        getcab()
    End Sub
    Protected Sub btnupdatecab_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnupdatecab.Click
        Dim db As New DBAccess("CRM")
        db.slDataAdd("cabnumber", txteditcab.Text.Trim)
        db.slDataAdd("Driver", txtEditDriver.Text.Trim)
        db.slDataAdd("Driver_phone", Txteditdriverphone.Text.Trim)
        db.slDataAdd("Route", cboeditroute.SelectedValue)
        db.slDataAdd("Capacity", txteditcapacity.Text)
        db.Executeproc("usp_SaveCabDetail")
        'db.UpdateinTable("tbl_Data_Cab", "cabnumber='" & txteditcab.Text.Trim & "'")
        db = Nothing
        SuccessMessage("Cab detail for cab number " & txteditcab.Text & " has been updated")
        getcab()
    End Sub
#End Region
#Region "Utility"

    Private Sub AlertMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMFail"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub

    Private Sub SuccessMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMSuccess"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub

    'Protected Sub ImageButton1_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton1.Click
    '    'fillgrid()
    '    GridViewExportUtil.Export(lblReportName.CurrentPage & "-" & LblError.Text & ".xls", Me.GdAttendance)
    'End Sub


    Public Overrides Sub VerifyRenderingInServerForm(ByVal Control As Control)

    End Sub

#End Region
End Class
