﻿Imports com.nss.DBAccess
Imports System.Data
Partial Class Staffing_Roster_AgentRoute
    Inherits System.Web.UI.Page

#Region "----- Properties -----"
    Property dtsummary() As DataTable
        Get
            Return ViewState("dtSummary")
        End Get
        Set(ByVal value As DataTable)
            ViewState("dtSummary") = value
        End Set
    End Property
    Property SupervisorID() As String
        Get
            Return ViewState("SupervisorID")
        End Get
        Set(ByVal value As String)
            ViewState("SupervisorID") = value
        End Set
    End Property
    Property TransID() As Integer
        Get
            Return ViewState("TransID")
        End Get
        Set(ByVal value As Integer)
            ViewState("TransID") = value
        End Set
    End Property
    Property UserID() As String
        Get
            Return ViewState("UserID")
        End Get
        Set(ByVal value As String)
            ViewState("UserID") = value
        End Set
    End Property

    Property CampaignID() As Integer
        Get
            Return 0 'ViewState("CampaignID")
        End Get
        Set(ByVal value As Integer)
            'ViewState("CampaignID") = value
            'Session("CampaignID") = value
        End Set
    End Property

    Property ProcessID() As Integer
        Get
            Return ViewState("ProcessID")
        End Get
        Set(ByVal value As Integer)
            ViewState("ProcessID") = value
            Session("ProcessID") = value
        End Set
    End Property
    Property AgentID() As String
        Get
            Return ViewState("AgentID")
        End Get
        Set(ByVal value As String)
            ViewState("AgentID") = value
        End Set
    End Property
    Property Month() As String
        Get
            Return ViewState("Month")
        End Get
        Set(ByVal value As String)
            ViewState("Month") = value
        End Set
    End Property
    Property Year() As Integer
        Get
            Return ViewState("Year")
        End Get
        Set(ByVal value As Integer)
            ViewState("Year") = value
        End Set
    End Property
    Property UsrID() As Integer
        Get
            Return ViewState("UsrID")
        End Get
        Set(ByVal value As Integer)
            ViewState("UsrID") = value
        End Set
    End Property
    Property LoginID() As Integer
        Get
            Return ViewState("LoginID")
        End Get
        Set(ByVal value As Integer)
            ViewState("LoginID") = value
        End Set
    End Property
    Property CurrentDate() As Date
        Get
            Return ViewState("CurrentDate")
        End Get
        Set(ByVal value As Date)
            ViewState("CurrentDate") = value
        End Set
    End Property
    Property IncentiveMonth() As String
        Get
            Return ViewState("IncentiveMonth")
        End Get
        Set(ByVal value As String)
            ViewState("IncentiveMonth") = value
        End Set
    End Property
    Property IncentiveYear() As Integer
        Get
            Return ViewState("IncentiveYear")
        End Get
        Set(ByVal value As Integer)
            ViewState("IncentiveYear") = value
        End Set
    End Property
    Property dtAgents() As DataTable
        Get
            Return ViewState("dtAgents")
        End Get
        Set(ByVal value As DataTable)
            ViewState("dtAgents") = value
        End Set
    End Property

#End Region

#Region "------- Load --------"

    Private Sub GetData()
        Dim db As New DBAccess
        db.slDataAdd("processid", CboProcess.SelectedValue)
        dtsummary = db.ReturnTable("usp_getAgentRoute", , True)
        db = Nothing
        If CboProcess.SelectedValue = "" Then
        Else
            Dim view As New DataView(dtsummary)
            For Each lst As ListItem In lstSelectedAgent.Items
                view.RowFilter = "EmployeeName='" & lst.Text & "'"
                For Each row As DataRowView In view
                    row.Delete()
                Next
            Next
            'Dim d As New DataBindingCollection
            'Dim row() As DataRow
            'row = dtsummary.Select
            'For Each row2 As DataRow In dtsummary.Rows
            '    For Each row1 As DataRow In dtAgents.Rows
            '        If row2.Item("EmployeeName") = row1.Item("EmployeeName") Then
            '            dtsummary.Rows.Remove(row2)
            '        End If
            '    Next
            'Next
        End If
        If dtsummary.Rows.Count > 0 Then
            lstAllAgents.DataSource = dtsummary
            lstAllAgents.DataTextField = "EmployeeName"
            lstAllAgents.DataValueField = "EmployeeId"
            lstAllAgents.DataBind()
        Else
            lstAllAgents.DataSource = Nothing
            lstAllAgents.DataBind()
        End If

        'GDAgentRoute.DataSource = dtsummary
        'GDAgentRoute.DataBind()
        'If dtsummary.Rows.Count > 0 Then
        '    If IncentiveMonth <> dtsummary.Rows(0).Item("vcMonth") Or IncentiveYear <> cboYear.SelectedValue Then
        '        GridView1.Columns(GridView1.Columns.Count - 1).Visible = False
        '    Else
        '        GridView1.Columns(GridView1.Columns.Count - 1).Visible = True
        '    End If
        'End If
        ' GridView1.Columns(GridView1.Columns.Count - 2).Visible = False

        lblreportname.CurrentPage = "Agent Route Detail"
    End Sub
    Private Sub GetRoute()
        Dim db As New DBAccess("CRM")
        Dim dt As DataTable = db.ReturnTable("select * from tbl_Config_Route", , False)
        db = Nothing
        If dt.Rows.Count > 0 Then
            cboRoute.DataSource = dt
            cboRoute.DataTextField = "Routename"
            cboRoute.DataValueField = "Routeid"
            cboRoute.DataBind()
        End If
        dt = Nothing
    End Sub
    Private Sub GetAgentsRoute()
        lstSelectedAgent.Items.Clear()
        Dim db As New DBAccess("CRM")
        Dim strquery As String = ""
        If CboProcess.SelectedValue = 0 Then
            strquery = "SELECT AgentName AS EmployeeName, AgentID AS EmployeeId" _
            & " FROM tbl_AgentMaster A INNER JOIN tbl_Config_Campaigns B ON A.CampaignID=B.CampaignID AND A.Active=1" _
            & " AND AgentID not like 'Test%' WHERE [Route]= " & cboRoute.SelectedValue
        Else
            strquery = "SELECT AgentName AS EmployeeName, AgentID AS EmployeeId" _
            & " FROM tbl_AgentMaster A INNER JOIN tbl_Config_Campaigns B ON A.CampaignID=B.CampaignID AND A.Active=1" _
            & " WHERE B.ProcessID =" & CboProcess.SelectedValue & " AND AgentID not like 'Test%' AND [Route]= " & cboRoute.SelectedValue
        End If
        dtAgents = db.ReturnTable(strquery, False)
        db = Nothing

        'Dim view As New DataView(dtsummary)
        'For Each lst As ListItem In lstSelectedAgent.Items
        '    view.RowFilter = "EmployeeName='" & lst.Text & "'"
        '    For Each row As DataRowView In view
        '        row.Delete()
        '    Next
        'Next

        'lstAllAgents.DataSource = dtsummary
        'lstAllAgents.DataTextField = "EmployeeName"
        'lstAllAgents.DataValueField = "EmployeeId"
        'lstAllAgents.DataBind()
        If dtAgents.Rows.Count > 0 Then
            lstSelectedAgent.DataSource = dtAgents
            lstSelectedAgent.DataTextField = "EmployeeName"
            lstSelectedAgent.DataValueField = "EmployeeId"
            lstSelectedAgent.DataBind()
        Else
            lstSelectedAgent.DataSource = Nothing
            lstSelectedAgent.DataBind()
        End If

    End Sub
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        HumanMessage.Style.Item("visibility") = "hidden"
        If Not IsPostBack Then
            FillProcessCampaigns()
            GetRoute()
            lblreportname.CurrentPage = "Fill Incentive"
            LblError.Visible = False
            AgentID = Session("Agentid")
            SupervisorID = Session("UserID")
            UserID = Session("UserID")
            PanelReports.Controls.Add(Common.GetMenu(Request.Url, AgentID, Request.ApplicationPath))
            'ReportType = Request.QueryString("ReportType")
            CreateTable()
            GetAgentsRoute()
            GetData()
        End If
    End Sub
#End Region
#Region "--- Support functions ---"
    Private Sub FillProcessCampaigns()
        Common.FillProcessCampaigns(CboProcess, cboCampaigns, AgentID, CampaignID)
    End Sub
    Private Sub AddAgents()
        Dim dtrow As DataRow ' = dtAgents.NewRow
        For Each lst As ListItem In lstAllAgents.Items
            If lst.Selected Then
                dtrow = dtAgents.NewRow
                dtrow("EmployeeName") = lst.Text
                dtrow("EmployeeId") = lst.Value
                dtAgents.Rows.Add(dtrow)
                dtAgents.AcceptChanges()
            End If
        Next

        Dim view As New DataView(dtsummary)
        For Each itm As ListItem In lstAllAgents.Items
            If itm.Selected Then
                view.RowFilter = "EmployeeName='" & itm.Text & "'"
                For Each row As DataRowView In view
                    row.Delete()
                Next
            End If
        Next
        lstAllAgents.DataSource = dtsummary
        lstAllAgents.DataTextField = "EmployeeName"
        lstAllAgents.DataValueField = "EmployeeId"
        lstAllAgents.DataBind()
        'lstAllAgents.Items.RemoveAt(lstAllAgents.SelectedIndex)
        If dtAgents.Rows.Count > 0 Then
            lstSelectedAgent.DataSource = dtAgents
            lstSelectedAgent.DataTextField = "EmployeeName"
            lstSelectedAgent.DataValueField = "EmployeeId"
            lstSelectedAgent.DataBind()
        End If
    End Sub
    Private Sub RemoveAgents()
        Dim dtrow As DataRow
        For Each lstItem As ListItem In lstSelectedAgent.Items
            If lstItem.Selected = True Then
                dtrow = dtsummary.NewRow
                dtrow("EmployeeName") = lstItem.Text
                dtrow("EmployeeId") = lstItem.Value
                dtsummary.Rows.Add(dtrow)
                dtsummary.AcceptChanges()
            End If
        Next
        Dim view As New DataView(dtAgents)
        For Each lst As ListItem In lstSelectedAgent.Items
            If lst.Selected = True Then
                view.RowFilter = "EmployeeName='" & lst.Text & "'"
                For Each row As DataRowView In view
                    row.Delete()
                Next
            End If
        Next

        lstSelectedAgent.DataSource = dtAgents
        lstSelectedAgent.DataTextField = "EmployeeName"
        lstSelectedAgent.DataValueField = "EmployeeId"
        lstSelectedAgent.DataBind()

        lstAllAgents.DataSource = dtsummary
        lstAllAgents.DataTextField = "EmployeeName"
        lstAllAgents.DataValueField = "EmployeeId"
        lstAllAgents.DataBind()

    End Sub
    Private Sub SaveData()
        Dim db As New DBAccess("CRM")
        Try
            If lstSelectedAgent.Items.Count > 0 Then
                For Each id As ListItem In lstSelectedAgent.Items
                    'db.slDataAdd("AgentId", id.Value)
                    db.ReturnTable("UPDATE  tbl_AgentMaster SET [Route]=" & cboRoute.SelectedValue & " WHERE AgentID='" & id.Value & "'")
                Next
                db = Nothing
                SuccessMessage("Route has been Saved !!...")
            Else
                AlertMessage("Please Select Agent First")
            End If
        Catch ex As Exception
            AlertMessage(ex.ToString)
        End Try

    End Sub
    Dim dtAdd As New DataTable
    Private Sub CreateTable()
        dtAdd.Columns.Add("EmployeeName")
        dtAdd.Columns.Add("EmployeeId")
        dtAgents = dtAdd
    End Sub

#End Region
#Region "------ Event ------"
    Protected Sub CboProcess_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles CboProcess.SelectedIndexChanged
        GetAgentsRoute()
        GetData()
    End Sub
    Protected Sub cboRoute_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboRoute.SelectedIndexChanged
        GetAgentsRoute()
        GetData()
    End Sub
    Protected Sub btnAdd_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnAdd.Click
        AddAgents()
    End Sub
    Protected Sub btnRemove_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnRemove.Click
        RemoveAgents()
    End Sub
    Protected Sub btnRefresh_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnRefresh.Click
        GetData()
    End Sub
    Protected Sub btnSave_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnSave.Click
        SaveData()
    End Sub
#End Region

    'Protected Sub GDAgentRoute_RowCancelingEdit(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewCancelEditEventArgs) Handles GDAgentRoute.RowCancelingEdit
    '    GDAgentRoute.EditIndex = -1
    '    GetData()
    '    Dim update, Cancel, edit As LinkButton
    '    update = GDAgentRoute.Rows(e.RowIndex).FindControl("lnkupdate")
    '    Cancel = GDAgentRoute.Rows(e.RowIndex).FindControl("lnkcancel")
    '    edit = GDAgentRoute.Rows(e.RowIndex).FindControl("lnkedit")
    '    update.Visible = False
    '    Cancel.Visible = False
    '    edit.Visible = True
    'End Sub

    
    'Protected Sub GDAgentRoute_RowDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles GDAgentRoute.RowDataBound
    '    Dim drproute As DropDownList = CType(e.Row.Cells(4).FindControl("cboroute"), DropDownList)
    'End Sub

    'Protected Sub GDAgentRoute_RowEditing(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewEditEventArgs) Handles GDAgentRoute.RowEditing
    '    GDAgentRoute.EditIndex = e.NewEditIndex
    '    GetData()
    '    Dim drproute As DropDownList = GDAgentRoute.Rows(e.NewEditIndex).FindControl("cboroute")
    '    Dim db As New DBAccess("CRM")
    '    Dim dt As DataTable = db.ReturnTable("select * from tbl_Config_Route", , False)
    '    If dt.Rows.Count > 0 Then
    '        drproute.DataSource = dt
    '        drproute.DataTextField = "Routename"
    '        drproute.DataValueField = "Routeid"

    '        drproute.DataBind()
    '    End If
    '    Dim update, Cancel, Edit As LinkButton
    '    update = GDAgentRoute.Rows(e.NewEditIndex).FindControl("lnkupdate")
    '    Cancel = GDAgentRoute.Rows(e.NewEditIndex).FindControl("lnkcancel")
    '    Edit = GDAgentRoute.Rows(e.NewEditIndex).FindControl("lnkedit")
    '    update.Visible = True
    '    Cancel.Visible = True
    '    Edit.Visible = False
    'End Sub

    'Protected Sub GDAgentRoute_RowUpdating(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewUpdateEventArgs) Handles GDAgentRoute.RowUpdating
    '    Dim drproute As DropDownList = GDAgentRoute.Rows(e.RowIndex).FindControl("cboroute")
    'End Sub

#Region "Utility"

    Private Sub AlertMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMFail"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub

    Private Sub SuccessMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMSuccess"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub

#End Region
   
End Class
