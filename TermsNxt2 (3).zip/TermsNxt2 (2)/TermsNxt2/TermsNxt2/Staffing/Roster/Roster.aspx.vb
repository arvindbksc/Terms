﻿Imports com.nss.DBAccess
Imports System.Data
Imports System.Drawing.Color
Partial Class PerfSum_Roster
    Inherits System.Web.UI.Page
    Shared rid As Integer = 0
    'Dim ProcessID 
#Region "-----Properties-----"
    Property CurrentDate() As Date
        Get
            Return ViewState("CurrentDate")
        End Get
        Set(ByVal value As Date)
            ViewState("CurrentDate") = value
        End Set
    End Property
    Property ProcessID() As Integer
        Get
            Return ViewState("ProcessID")
        End Get
        Set(ByVal value As Integer)
            ViewState("ProcessID") = value
        End Set
    End Property
    Property RosterDate() As Date
        Get
            Return ViewState("RosterDate")
        End Get
        Set(ByVal value As Date)
            ViewState("RosterDate") = value
        End Set
    End Property
    Property SupervisorID() As String
        Get
            Return ViewState("SupervisorID")
        End Get
        Set(ByVal value As String)
            ViewState("SupervisorID") = value
        End Set
    End Property
    Property Startdate() As String
        Get
            Return ViewState("startdate")
        End Get
        Set(ByVal value As String)
            ViewState("startdate") = value
        End Set
    End Property
    Property Enddate() As String
        Get
            Return ViewState("enddate")
        End Get
        Set(ByVal value As String)
            ViewState("enddate") = value
        End Set
    End Property
    Property AgentID() As String
        Get
            Return ViewState("AgentID")
        End Get
        Set(ByVal value As String)
            ViewState("AgentID") = value
        End Set
    End Property
    Property UserName() As String
        Get
            Return ViewState("UserName")
        End Get
        Set(ByVal value As String)
            ViewState("UserName") = value
        End Set
    End Property
    Public Property dtFillData() As DataTable
        Get
            Return ViewState("dtFillData")
        End Get
        Set(ByVal value As DataTable)
            ViewState("dtFillData") = value
        End Set
    End Property
    Public Property dtAllAgents() As DataTable
        Get
            Return ViewState("dtAllAgents")
        End Get
        Set(ByVal value As DataTable)
            ViewState("dtAllAgents") = value
        End Set
    End Property
    Public Property chkIschecked() As Integer
        Get
            Return ViewState("chkIschecked")
        End Get
        Set(ByVal value As Integer)
            ViewState("chkIschecked") = value
        End Set
    End Property

#End Region
    Private dtfinal As New DataTable
    Private dtshift As DataTable
    Private dtDistinctProcess As DataTable

#Region "--- Load Activities ---"
    Private Sub RosterFillTime()
        Dim dbrosterDt As New DBAccess("CRM")
        'dbrosterDt.slDataAdd("ProcessID", CboProcess.SelectedValue)
        CurrentDate = dbrosterDt.ReturnValue("usp_getrosterMinDate", True)
        'CurrentDate = dbrosterDt.ReturnValue("Select GetDate()", False)
        ucDateFrom.value = CurrentDate
        dbrosterDt = Nothing
    End Sub

    Private Sub GetShifts()
        Dim dbShift As New DBAccess("CRM")
        dtshift = dbShift.ReturnTable("SELECT ShiftId,Shift AS ShiftName, color,TimeIn,TimeOut FROM tbl_Config_RosterShift where active=1 ORDER BY Sequence", , False)
        dbShift = Nothing
        cboShift.DataSource = dtshift
        cboShift.DataTextField = "ShiftName"
        cboShift.DataValueField = "ShiftId"
        cboShift.DataBind()

        'Create Legends for Shifts    'Code by Gaurav Srivastava (29-06-2011)
        PlaceHolder1.Controls.Clear()
        Dim tbl As Table = New Table
        PlaceHolder1.Controls.Add(tbl)
        Dim tr As TableRow = New TableRow()
        Dim tr2 As TableRow = New TableRow()
        Dim tr3 As TableRow = New TableRow()
        For Each row As DataRow In dtshift.Rows
            If Not row.Item("ShiftName").ToString.StartsWith("OFF") Then
                Dim tc1 As TableCell = New TableCell
                Dim tc2 As TableCell = New TableCell
                Dim tc3 As TableCell = New TableCell
                tc1.BorderStyle = BorderStyle.Solid
                tc1.BorderWidth = 1
                tc1.BackColor = System.Drawing.Color.FromName(CStr(row.Item("color").ToString()))
                tc1.Height = 5
                'tc2.Width = 5
                'tc3.Width = 5
                tc2.Text = row.Item("ShiftName")
                tc3.Text = "[" & row.Item("TimeIn").ToString & "] To [" & row.Item("TimeOut").ToString & "]"
                tc2.Font.Bold = True
                tr.Cells.Add(tc1)
                tr2.Cells.Add(tc2)
                tr3.Cells.Add(tc3)
                'tc3.ColumnSpan = 2
            End If
        Next
        tbl.Rows.Add(tr)
        tbl.Rows.Add(tr2)
        tbl.Rows.Add(tr3)
        ViewState("dynamictable") = True
    End Sub
    Protected Overrides Sub LoadViewState(ByVal earlierState As Object)
        MyBase.LoadViewState(earlierState)
        If ViewState("isHierarchy") Then
            ViewState("ProcessID") = 0
        End If
        If ViewState("dynamictable") Then
            GetShifts()
        End If
        If ViewState("dynamicGrid") Then
            'FillRosterGrid()
            FillRosterGridNew()
        End If
    End Sub
    Private Sub LoadData()
        Common.FillProcessCampaigns(CboProcess, cboCampaign, AgentID)
        Dim lstProcess As New ListItem
        lstProcess.Value = 0
        lstProcess.Text = "All"
        If CboProcess.Items.Contains(lstProcess) Then
            CboProcess.Items.Remove(lstProcess)
        End If
        PanelReports.Controls.Add(Common.GetMenu(Request.Url, AgentID, Request.ApplicationPath))
        RosterFillTime()
        GetShifts()
        CheckSatSundayOff()
        CreateDataTable()
        GetSelectedDaysRoster()
    End Sub
#End Region
#Region "--- Load ---"
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        HumanMessage.Style.Item("visibility") = "hidden"
        'btsave.Attributes.Item("onclick") = "this.value=" & Chr(34) & "Processing..." & Chr(34) & ";this.disabled=true;" & ClientScript.GetPostBackEventReference(btsave, Nothing).ToString
        If lstAllAgents.Visible Then
            btsave.Visible = False
            rblisAll.Visible = True
            imgPrev.Visible = False
        Else
            imgPrev.Visible = True
        End If
        If Not Page.IsPostBack Then
            btsave.Attributes.Item("onclick") = "this.value=" & Chr(34) & "Processing..." & Chr(34) & ";this.disabled=true;" & ClientScript.GetPostBackEventReference(btsave, Nothing).ToString
            AgentID = Session("Agentid")
            UserName = Session("Username")
            SupervisorID = Session("Agentid")
            'SupervisorID = "nss47671"
            LoadData()
            lblReportName.CurrentPage = "Roster"
        End If
    End Sub
#End Region
#Region "--- Functions ---"
    Private Sub GetAllAgents()
        Dim db As New DBAccess("CRM")

        db.slDataAdd("RosterDate", ucDateFrom.yyyymmdd)
        If rblisAll.SelectedValue > 0 Then
            db.slDataAdd("SupervisorID", SupervisorID)
        Else
            db.slDataAdd("ProcessID", CboProcess.SelectedValue)
        End If
        dtAllAgents = db.ReturnTable("usp_GetAllAgents_Roster", , True)
        db = Nothing
        If dtAllAgents.Rows.Count > 0 Then
            lstAllAgents.DataSource = dtAllAgents
            lstAllAgents.DataTextField = "AgentName"
            lstAllAgents.DataValueField = "AgentId"
            lstAllAgents.DataBind()
        End If
        lstSelectedAgent.Items.Clear()
        Dim row() As DataRow = dtAllAgents.Select("ShiftIn='" & cboShift.SelectedItem.Text & "'")
        If row.Length > 0 Then
            For Each row1 As DataRow In row
                Dim lst As New ListItem
                lst.Value = row1.ItemArray(0).ToString
                lst.Text = row1.ItemArray(1).ToString
                lstSelectedAgent.Items.Add(lst)
            Next
        End If
    End Sub
    Private Function validatecurrentdate(ByVal selecteddate As DateTime) As Boolean
        Dim dbMinDate As New DBAccess("CRM")
        Dim MaxDate As DateTime
        Dim MinDate As DateTime = Convert.ToDateTime(dbMinDate.ReturnValue("usp_getrosterMinDate", True)).Date
        dbMinDate = Nothing
        If MinDate.DayOfWeek = DayOfWeek.Saturday Then
            MaxDate = MinDate.AddDays(8)
        ElseIf MinDate.DayOfWeek = DayOfWeek.Sunday Then
            MaxDate = MinDate.AddDays(7)
        Else
            If MinDate.DayOfWeek = DayOfWeek.Monday Then
                MaxDate = MinDate.AddDays(6)
            ElseIf MinDate.DayOfWeek = DayOfWeek.Tuesday Then
                MaxDate = MinDate.AddDays(5)
            ElseIf MinDate.DayOfWeek = DayOfWeek.Wednesday Then
                MaxDate = MinDate.AddDays(4)
            ElseIf MinDate.DayOfWeek = DayOfWeek.Thursday Then
                MaxDate = MinDate.AddDays(10)
            ElseIf MinDate.DayOfWeek = DayOfWeek.Friday Then
                MaxDate = MinDate.AddDays(9)
            End If
        End If
        If selecteddate > MaxDate Then
            dbMinDate = Nothing
            Return False
        End If
        If selecteddate >= MinDate Then
            dbMinDate = Nothing
            Return True
        End If
        Return False
    End Function

    Private Sub SaveFinalRoster()
        Dim db As New DBAccess
        Dim strDate As DateTime = lblDateFrom.Text
        Dim intVal As Integer = 0
        Dim inti As Integer
        For inti = 0 To GridView1.Columns.Count - 1
            If Not GridView1.Columns(inti).HeaderText.StartsWith("Agent") And GridView1.Columns(inti).HeaderText.ToLower <> "process" Then
                For Each gvRow As GridViewRow In GridView1.Rows
                    Dim strShiftIn, strAgentID, ProcessId As String
                    strShiftIn = CType(gvRow.FindControl(GridView1.Columns(inti).HeaderText), DropDownList).SelectedItem.Text
                    ProcessId = gvRow.Cells(2).Text
                    strAgentID = gvRow.Cells(0).Text
                    db = New DBAccess("CRM")
                    db.slDataAdd("Agentid", strAgentID)
                    db.slDataAdd("Rosterdate", strDate.ToString("yyyyMMdd"))
                    db.slDataAdd("ShiftIn", strShiftIn)
                    db.slDataAdd("ShiftOut", strShiftIn)
                    db.slDataAdd("ProcessID", ProcessId.Substring(ProcessId.LastIndexOf("[")).Replace("[", "").Replace("]", ""))
                    db.slDataAdd("FilledBy", SupervisorID)
                    db.Executeproc("usp_InsertFinalRoster")
                    db = Nothing
                Next
                strDate = Convert.ToDateTime(strDate).AddDays(1)
            End If
        Next
        SuccessMessage("Roster has been saved successfully.")
        createcounttable()
    End Sub
    Private Sub CheckSatSundayOff()
        Dim dbOff As New DBAccess("CRM")
        Dim dtOff As DataTable
        dtOff = dbOff.ReturnTable("select IsSaturdayOff,IsSundayOff from tbl_Config_Campaigns where ProcessID=" & CboProcess.SelectedValue & "", False)
        dbOff = Nothing
        If dtOff.Rows(0).Item("IsSaturdayOff") = True Then
            chkIsSatOff.Checked = True
        Else
            chkIsSatOff.Checked = False
        End If
        If dtOff.Rows(0).Item("IsSundayOff") = True Then
            chkIsSunOff.Checked = True
        Else
            chkIsSunOff.Checked = False
        End If
    End Sub
    '------- Rajendra 2012/08/04
    Private Sub CreateDataTable()
        dtFillData = New DataTable
        dtFillData.Columns.Add("AgentID")
        dtFillData.Columns.Add("AgentName")
        dtFillData.Columns.Add("Process")
        dtFillData.Columns.Add("ShiftIN")
        'dtFillData.Columns.Add("ShiftOut")
        dtFillData.Columns.Add("Dayname")
        dtFillData.Columns.Add("RosterDate")
    End Sub
    Private Sub FillDataTable()
        Dim Sdate, Edate As DateTime
        Sdate = ucDateFrom.value
        Edate = DateAdd("d", 7 - IIf(Sdate.DayOfWeek = 0, 7, Sdate.DayOfWeek), Sdate)
        While Sdate <= Edate
            For Each lst As ListItem In lstAllAgents.Items
                If lst.Selected Then
                    Dim view As New DataView(dtFillData)
                    view.RowFilter = "AgentID='" & lst.Value & "' and RosterDate='" & Sdate.ToString("yyyyMMdd") & "'"
                    For Each rowView As DataRowView In view
                        dtFillData.Rows.Remove(rowView.Row)
                    Next
                    If dtFillData.Rows.Count > 0 Then
                        Dim dtRow As DataRow = dtFillData.NewRow
                        dtRow("AgentID") = lst.Value
                        dtRow("AgentName") = lst.Text
                        dtRow("Process") = dtAllAgents.Select("AgentId='" & lst.Value & "'")(0).Item("Process") & "[" & dtAllAgents.Select("AgentId='" & lst.Value & "'")(0).Item("ProcessId") & "]"
                        If chkIsSatOff.Checked = True And Sdate.DayOfWeek = DayOfWeek.Saturday Then
                            dtRow("ShiftIN") = "OFF"
                            'dtRow("ShiftOut") = "OFF"
                        ElseIf chkIsSunOff.Checked = True And Sdate.DayOfWeek = DayOfWeek.Sunday Then
                            dtRow("ShiftIN") = "OFF"
                            ' dtRow("ShiftOut") = "OFF"
                        Else
                            dtRow("ShiftIN") = cboShift.SelectedItem.Text
                            'dtRow("ShiftOut") = cboShift.SelectedItem.Text
                        End If
                        dtRow("Dayname") = Sdate.DayOfWeek
                        dtRow("RosterDate") = Sdate.ToString("yyyyMMdd")
                        dtFillData.Rows.Add(dtRow)
                        dtFillData.AcceptChanges()
                    Else
                        Dim dtRow As DataRow = dtFillData.NewRow
                        dtRow("AgentID") = lst.Value
                        dtRow("AgentName") = lst.Text
                        dtRow("Process") = dtAllAgents.Select("AgentId='" & lst.Value & "'")(0).Item("Process") & "[" & dtAllAgents.Select("AgentId='" & lst.Value & "'")(0).Item("ProcessId") & "]"
                        If chkIsSatOff.Checked = True And Sdate.DayOfWeek = DayOfWeek.Saturday Then
                            dtRow("ShiftIN") = "OFF"
                            'dtRow("ShiftOut") = "OFF"
                        Else
                            dtRow("ShiftIN") = cboShift.SelectedItem.Text
                            'dtRow("ShiftOut") = cboShift.SelectedItem.Text
                        End If
                        If chkIsSunOff.Checked = True And Sdate.DayOfWeek = DayOfWeek.Sunday Then
                            dtRow("ShiftIN") = "OFF"
                            'dtRow("ShiftOut") = "OFF"
                        Else
                            dtRow("ShiftIN") = cboShift.SelectedItem.Text
                            'dtRow("ShiftOut") = cboShift.SelectedItem.Text
                        End If
                        dtRow("Dayname") = Sdate.DayOfWeek
                        dtRow("RosterDate") = Sdate.ToString("yyyyMMdd")
                        dtFillData.Rows.Add(dtRow)
                        dtFillData.AcceptChanges()
                    End If
                End If
            Next
            Sdate = Sdate.AddDays(1)
        End While
        If dtFillData.Rows.Count > 0 Then
            Dim dtAgnt As DataTable = dtFillData.DefaultView.ToTable(True, "AgentId", "AgentName")
            lstSelectedAgent.DataSource = dtAgnt
            lstSelectedAgent.DataValueField = "AgentId"
            lstSelectedAgent.DataTextField = "AgentName"
            lstSelectedAgent.DataBind()
        End If
        GetShiftWiseAgent()

    End Sub
    Private Sub GetShiftWiseAgent()
        lstSelectedAgent.Items.Clear()
        Dim row() As DataRow = dtFillData.Select("ShiftIN='" & cboShift.SelectedItem.Text & "' and Rosterdate='" & ucDateFrom.yyyymmdd & "'")
        For Each row1 As DataRow In row
            Dim lst As New ListItem
            lst.Value = row1.Item("AgentId").ToString
            lst.Text = row1.Item("AgentName").ToString
            lstSelectedAgent.Items.Add(lst)
        Next
        SetColor()
    End Sub
    Private Sub SetColor()
        For Each item As ListItem In lstAllAgents.Items
            Dim rows() As DataRow = dtFillData.Select("Rosterdate='" & ucDateFrom.yyyymmdd & "' and agentid='" & item.Value & "'")
            If rows.Length > 0 Then
                item.Attributes.Add("style", "background-color: " & dtshift.Select("ShiftName='" & IIf(IsDBNull(rows(0)("ShiftIN")), "OFF", rows(0)("ShiftIN")) & "'")(0).Item("color"))
            End If
        Next
    End Sub
    Private Sub RemoveFromDt()
        For Each lst As ListItem In lstSelectedAgent.Items
            If lst.Selected Then
                Dim view As New DataView(dtFillData)
                view.RowFilter = "AgentID='" & lst.Value & "'"
                For Each rowView As DataRowView In view
                    dtFillData.Rows.Remove(rowView.Row)
                Next
            End If
        Next
        GetShiftWiseAgent()
    End Sub
    Private Sub FillRosterGridNew()
        'CheckOffRoster()
        PlaceHolder2.Visible = True
        PlaceHolder2.Controls.Clear()
        PlaceHolder2.Controls.Add(GridView1)
        dtfinal = dtFillData.Copy
        Dim db As New DBAccess("CRM")
        Dim intProcessID As Integer
        Dim RosterEndDate, rosterfromdate As String
        If Not ViewState("Enddate") = "" And Not ViewState("FromDate") = "" Then
            RosterEndDate = ViewState("Enddate")
            rosterfromdate = ViewState("FromDate")
            intProcessID = ViewState("ProcessID")
        Else
            RosterEndDate = DateAdd("d", 7 - IIf(RosterDate.DayOfWeek = 0, 7, RosterDate.DayOfWeek), RosterDate).ToString("yyyyMMdd")
            intProcessID = CboProcess.SelectedValue
            ViewState("Enddate") = RosterEndDate
            ViewState("FromDate") = ucDateFrom.yyyymmdd
            ViewState("ProcessID") = CboProcess.SelectedValue
            rosterfromdate = ucDateFrom.yyyymmdd
        End If
        'Dim dtEmp As DataTable = dtFillData

        GridView1.AutoGenerateColumns = False
        GridView1.CellPadding = 0
        GridView1.GridLines = GridLines.None
        GridView1.EmptyDataText = "No Data found for the selected criteria."
        GridView1.CaptionAlign = TableCaptionAlign.Top
        GridView1.HorizontalAlign = HorizontalAlign.Left

        Dim dtDistinctEmp As New DataTable
        dtDistinctEmp = dtFillData.DefaultView.ToTable(True, "AgentID")
        dtDistinctProcess = dtFillData.DefaultView.ToTable(True, "Process")
        If dtfinal.Columns.Count > 0 Then
            dtfinal.Columns.Clear()
        End If
        Dim bField0 As New BoundField
        bField0.HeaderText = "AgentID"
        bField0.DataField = "AgentID"
        GridView1.Columns.Add(bField0)
        dtfinal.Columns.Add("AgentID")
        Dim bField As New BoundField
        bField.HeaderText = "AgentName"
        bField.DataField = "AgentName"
        GridView1.Columns.Add(bField)
        dtfinal.Columns.Add("AgentName")
        Dim bFieldProcess As New BoundField
        bFieldProcess.HeaderText = "Process"
        bFieldProcess.DataField = "Process"
        GridView1.Columns.Add(bFieldProcess)
        dtfinal.Columns.Add("Process")

        Dim dtDay As New DataTable
        dtDay = dtFillData.DefaultView.ToTable(True, "Dayname", "Rosterdate")
        For Each row As DataRow In dtDay.Rows
            Dim TmpCol As New TemplateField()
            TmpCol.HeaderText = row(0).ToString & " (" & IntegerToDateString(row(1)) & ")"  '"(IN)"
            TmpCol.ItemTemplate = New TemplateHandler(row(0).ToString & " (" & IntegerToDateString(row(1)) & ")", "countlbl" & row(0).ToString & " (" & IntegerToDateString(row(1)) & ")") '"(IN)")
            GridView1.Columns.Add(TmpCol)
            dtfinal.Columns.Add(row(0).ToString & " (" & IntegerToDateString(row(1)) & ")") '& "(IN)")
        Next
        Dim EndDate As String = ""
        For Each r As DataRow In dtDistinctEmp.Rows
            Dim newr As DataRow = dtfinal.NewRow
            newr.Item("AgentID") = r.Item("AgentID")
            For Each row As DataRow In dtDay.Rows
                Dim Comprow() As DataRow = dtFillData.Select("AgentId='" & r.Item("AgentID") & "' and Dayname='" & row.Item("Dayname") & "'")
                If Comprow.Length > 0 Then '''''rajkumar 09-Jan-2015 Added
                    newr.Item("AgentName") = Comprow(0).Item("AgentName")
                    newr.Item("Process") = Comprow(0).Item("Process")
                    newr.Item(row.Item("Dayname") & " (" & IntegerToDateString(row(1)) & ")") = Comprow(0).Item("ShiftIn")
                End If '''''rajkumar 09-Jan-2015 Added
                EndDate = row(1).ToString
            Next

            dtfinal.Rows.Add(newr)
            dtfinal.AcceptChanges()
        Next
        For Each emptrow As DataRow In dtfinal.Select
            If emptrow.Item("AgentId").ToString = "" Then
                emptrow.Delete()
                dtfinal.AcceptChanges()
            End If
        Next
        dtfinal.AcceptChanges()
        GridView1.DataSource = dtfinal
        GridView1.DataBind()

        'Dim ColCounter As Integer = 0
        'For Each col As DataColumn In dtfinal.Columns
        '    If ColCounter >= 3 And ColCounter <= dtfinal.Columns.Count Then
        '        Dim lbloffcount As New Label
        '        lbloffcount.ID = "countlbl" & col.ColumnName
        '        lbloffcount.Text = "Count Of OFF:- " & dtfinal.Select("[" & col.ColumnName & "] = 'OFF'").Length
        '        Dim lblRosteredcount As New Label
        '        lblRosteredcount.ID = "Rosteredlbl" & col.ColumnName
        '        lblRosteredcount.Text = "<br />Rostered Count:- " & dtfinal.Select("[" & col.ColumnName & "] <> 'OFF'").Length
        '        Dim lblheaderText As New Label
        '        lblheaderText.ID = "textlbl" & col.ColumnName
        '        lblheaderText.Text = "<br /><br />" & col.ColumnName
        '        GridView1.HeaderRow.Cells(ColCounter).Controls.Add(lbloffcount)
        '        GridView1.HeaderRow.Cells(ColCounter).Controls.Add(lblRosteredcount)
        '        GridView1.HeaderRow.Cells(ColCounter).Controls.Add(lblheaderText)
        '    End If
        '    ColCounter += 1
        'Next

        For i As Integer = 0 To GridView1.Columns.Count - 1
            If i = 0 Then
                GridView1.Columns(i).HeaderStyle.CssClass = "ROgridFirstItem"
                GridView1.Columns(i).ItemStyle.CssClass = "ROgridFirstItem"
            ElseIf i = GridView1.Columns.Count - 1 Then
                GridView1.Columns(i).HeaderStyle.CssClass = "ROgridMidItem"
                GridView1.Columns(i).ItemStyle.CssClass = "ROgridMidItem"
            Else
                GridView1.Columns(i).HeaderStyle.CssClass = "ROgridLastItem"
                GridView1.Columns(i).ItemStyle.CssClass = "ROgridLastItem"
            End If
        Next
        ViewState("dynamicGrid") = True
        pnlDate.Visible = False
        pnlDateRange.Visible = True
        Label1.Text = "Period Between: "
        lblDateFrom.Text = IntegerToDateString(rosterfromdate)
        Label2.Text = " AND "
        lblDateTo.Text = IntegerToDateString(EndDate)
        createcounttable()

    End Sub
    Private Sub createcounttable()
        Dim tblcount As New HtmlTable
        Dim tblrow As New HtmlTableRow
        Dim tblrow1 As New HtmlTableRow
        Dim tblcell As New HtmlTableCell
        Dim tblcell1 As New HtmlTableCell
        Dim ColCounter As Integer = 0
        'For Each col As DataColumn In dtfinal.Columns
        For inti = 3 To GridView1.Columns.Count - 1
            Dim offcount As Integer = 0
            ' If Not GridView1.Columns(inti).HeaderText.StartsWith("Agent") And GridView1.Columns(inti).HeaderText.ToLower <> "process" Then
            tblcell = New HtmlTableCell
            tblcell1 = New HtmlTableCell
            For Each gvRow As GridViewRow In GridView1.Rows
                If CType(gvRow.FindControl(GridView1.Columns(inti).HeaderText), DropDownList).SelectedItem.Text = "OFF" Then
                    offcount += 1
                    CType(gvRow.FindControl(GridView1.Columns(inti).HeaderText), DropDownList).SelectedItem.Attributes.Add("style", "color:red")
                    'gvRow.Cells(inti).BackColor = Red
                Else
                    CType(gvRow.FindControl(GridView1.Columns(inti).HeaderText), DropDownList).BackColor = White
                End If

            Next
            tblcell.InnerHtml = "<b>Count Of OFF:-<b/>" & offcount
            tblcell1.InnerHtml = "<b>Rostered Count:-<b/>" & GridView1.Rows.Count - offcount
            tblrow.Cells.Add(tblcell)
            tblrow1.Cells.Add(tblcell1)
            tblcell.Align = "center"
            tblcell1.Align = "center"
          
        Next
        tblcount.Attributes.Add("class", "ROgridFirstItem")
        tblcount.Rows.Add(tblrow)
        tblcount.Rows.Add(tblrow1)
        PlaceHolder3.Controls.Clear()
        If dtfinal.Columns.Count > 7 Then
            tblcount.Width = "80%"
        ElseIf dtfinal.Columns.Count = 5 Then
            tblcount.Width = "60%"
        ElseIf dtfinal.Columns.Count = 4 Then
            tblcount.Width = "40%"
        Else
            tblcount.Width = "70%"
        End If
        tblcount.Align = "right"
        tblcount.Border = 0
        PlaceHolder3.Controls.Clear()
        PlaceHolder3.Controls.Add(tblcount)

    End Sub
    Private Sub IsSatSundayOFF()
        For Each dr As DataRow In dtFillData.Select("Dayname='Saturday'")
            If chkIsSatOff.Checked = True Then
                dr("ShiftIN") = "OFF"
            Else
                Dim dr1() As DataRow = dtFillData.Select("AgentId='" & dr("AgentId") & "' and Dayname not In ('Saturday','Sunday')")
                If dr1.Length > 0 Then
                    dr("ShiftIN") = dr1(0).Item("ShiftIN")
                End If
            End If
        Next
        For Each dr As DataRow In dtFillData.Select("Dayname='Sunday'")
            If chkIsSunOff.Checked = True Then
                dr("ShiftIN") = "OFF"
            Else
                Dim dr1() As DataRow = dtFillData.Select("AgentId='" & dr("AgentId") & "' and Dayname not In ('Saturday','Sunday')")
                If dr1.Length > 0 Then
                    dr("ShiftIN") = dr1(0).Item("ShiftIN")
                End If
            End If
        Next
        dtFillData.AcceptChanges()
    End Sub
    Private Function IntegerToDateString(ByVal d As Integer) As String
        Return d.ToString.Substring(0, 4) & "/" & (d.ToString.Substring(4, 2)) & "/" & d.ToString.Substring(6, 2)
    End Function
    Private Sub GetLatestRoster()
        Dim db As New DBAccess("CRM")
        Dim dt As DataTable
        Dim Sdate, Edate As DateTime
        dtFillData.Clear()
        db.slDataAdd("Rosterdate", ucDateFrom.yyyymmdd)
        If chkIschecked = 1 Then
            db.slDataAdd("SupervisorID", SupervisorID)
        End If
        db.slDataAdd("ProcessId", CboProcess.SelectedValue)
        db.slDataAdd("HierarchyWise", chkIschecked)
        'db.slDataAdd("WeekWise", weekwise)
        dt = db.ReturnTable("usp_GetLatestRoster_New", , True)
        'dt = db.ReturnTable("usp_GetLatestRoster_New2", , True)
        db = Nothing
        If dt.Rows.Count > 0 Then
            Sdate = ucDateFrom.value
            Edate = DateAdd("d", 7 - IIf(Sdate.DayOfWeek = 0, 7, Sdate.DayOfWeek), Sdate)
            While Sdate <= Edate
                If dtAllAgents.Rows.Count > 0 Then
                    For Each row As DataRow In dt.Rows
                        If dtFillData.Rows.Count > 0 Then
                            Dim dtRow As DataRow = dtFillData.NewRow
                            dtRow("AgentID") = row.Item("AgentID")
                            dtRow("AgentName") = row.Item("AgentName")
                            dtRow("Process") = dtAllAgents.Select("AgentId='" & row.Item("AgentID") & "'")(0).Item("Process") & "[" & dtAllAgents.Select("AgentId='" & row.Item("AgentID") & "'")(0).Item("ProcessId") & "]"
                            If chkIsSatOff.Checked = True And Sdate.DayOfWeek = DayOfWeek.Saturday Then
                                dtRow("ShiftIN") = "OFF"
                                'dtRow("ShiftOut") = "OFF"
                            ElseIf chkIsSunOff.Checked = True And Sdate.DayOfWeek = DayOfWeek.Sunday Then
                                dtRow("ShiftIN") = "OFF"
                                ' dtRow("ShiftOut") = "OFF"
                            Else
                                dtRow("ShiftIN") = row.Item("ShiftIN")
                                'dtRow("ShiftOut") = cboShift.SelectedItem.Text
                            End If
                            dtRow("Dayname") = Sdate.DayOfWeek
                            dtRow("RosterDate") = Sdate.ToString("yyyyMMdd")
                            dtFillData.Rows.Add(dtRow)
                            dtFillData.AcceptChanges()
                        Else
                            Dim dtRow As DataRow = dtFillData.NewRow
                            dtRow("AgentID") = row.Item("AgentID")
                            dtRow("AgentName") = row.Item("AgentName")
                            dtRow("Process") = dtAllAgents.Select("AgentId='" & row.Item("AgentID") & "'")(0).Item("Process") & "[" & dtAllAgents.Select("AgentId='" & row.Item("AgentID") & "'")(0).Item("ProcessId") & "]"
                            If chkIsSatOff.Checked = True And Sdate.DayOfWeek = DayOfWeek.Saturday Then
                                dtRow("ShiftIN") = "OFF"
                                'dtRow("ShiftOut") = "OFF"
                            Else
                                dtRow("ShiftIN") = row.Item("ShiftIN")
                                'dtRow("ShiftOut") = cboShift.SelectedItem.Text
                            End If
                            If chkIsSunOff.Checked = True And Sdate.DayOfWeek = DayOfWeek.Sunday Then
                                dtRow("ShiftIN") = "OFF"
                                'dtRow("ShiftOut") = "OFF"
                            Else
                                dtRow("ShiftIN") = row.Item("ShiftIN")
                                'dtRow("ShiftOut") = cboShift.SelectedItem.Text
                            End If
                            dtRow("Dayname") = Sdate.DayOfWeek
                            dtRow("RosterDate") = Sdate.ToString("yyyyMMdd")
                            dtFillData.Rows.Add(dtRow)
                            dtFillData.AcceptChanges()
                        End If
                    Next
                End If
                Sdate = Sdate.AddDays(1)
            End While
        End If
        GetShiftWiseAgent()
        SetColor()
    End Sub
    Private Sub GetSelectedDaysRoster()
        GetAllAgents()
        Dim Sdate, Edate As DateTime
        Sdate = ucDateFrom.value
        Edate = DateAdd("d", 7 - IIf(Sdate.DayOfWeek = 0, 7, Sdate.DayOfWeek), Sdate)
        While Sdate <= Edate
            For Each row As DataRow In dtAllAgents.Select("Shiftin is not null")
                If dtFillData.Rows.Count > 0 Then
                    Dim dtRow As DataRow = dtFillData.NewRow
                    dtRow("AgentID") = row.Item("AgentID")
                    dtRow("AgentName") = row.Item("AgentName")
                    dtRow("Process") = dtAllAgents.Select("AgentId='" & row.Item("AgentID") & "'")(0).Item("Process") & "[" & dtAllAgents.Select("AgentId='" & row.Item("AgentID") & "'")(0).Item("ProcessId") & "]"
                    If chkIsSatOff.Checked = True And Sdate.DayOfWeek = DayOfWeek.Saturday Then
                        dtRow("ShiftIN") = "OFF"
                        'dtRow("ShiftOut") = "OFF"
                    ElseIf chkIsSunOff.Checked = True And Sdate.DayOfWeek = DayOfWeek.Sunday Then
                        dtRow("ShiftIN") = "OFF"
                        ' dtRow("ShiftOut") = "OFF"
                    Else
                        dtRow("ShiftIN") = row.Item("ShiftIN")
                        'dtRow("ShiftOut") = cboShift.SelectedItem.Text
                    End If
                    dtRow("Dayname") = Sdate.DayOfWeek
                    dtRow("RosterDate") = Sdate.ToString("yyyyMMdd")
                    dtFillData.Rows.Add(dtRow)
                    dtFillData.AcceptChanges()
                Else
                    Dim dtRow As DataRow = dtFillData.NewRow
                    dtRow("AgentID") = row.Item("AgentID")
                    dtRow("AgentName") = row.Item("AgentName")
                    dtRow("Process") = dtAllAgents.Select("AgentId='" & row.Item("AgentID") & "'")(0).Item("Process") & "[" & dtAllAgents.Select("AgentId='" & row.Item("AgentID") & "'")(0).Item("ProcessId") & "]"
                    'If chkIsSatOff.Checked = True And Sdate.DayOfWeek = DayOfWeek.Saturday Then
                    '    dtRow("ShiftIN") = "OFF"

                    'Else
                    '    dtRow("ShiftIN") = row.Item("ShiftIN")

                    'End If
                    'If chkIsSunOff.Checked = True And Sdate.DayOfWeek = DayOfWeek.Sunday Then
                    '    dtRow("ShiftIN") = "OFF"

                    'Else
                    dtRow("ShiftIN") = row.Item("ShiftIN")

                    'End If
                    dtRow("Dayname") = Sdate.DayOfWeek
                    dtRow("RosterDate") = Sdate.ToString("yyyyMMdd")
                    dtFillData.Rows.Add(dtRow)
                    dtFillData.AcceptChanges()
                End If
            Next
            Sdate = Sdate.AddDays(1)
        End While
        GetShiftWiseAgent()
        SetColor()
    End Sub
    Private Sub CheckOffRoster()
        For Each item As ListItem In lstAllAgents.Items
            Dim rows() As DataRow = dtFillData.Select("Rosterdate='" & ucDateFrom.yyyymmdd & "' and AgentId='" & item.Value & "'")
            If rows.Length = 0 Then
                Dim Sdate, Edate As DateTime
                Sdate = ucDateFrom.value
                Edate = DateAdd("d", 7 - IIf(Sdate.DayOfWeek = 0, 7, Sdate.DayOfWeek), Sdate)
                While Sdate <= Edate
                    Dim dr As DataRow = dtFillData.NewRow
                    dr("AgentId") = item.Value
                    dr("AgentName") = item.Text
                    dr("Process") = dtAllAgents.Select("AgentId='" & item.Value & "'")(0).Item("Process") & "[" & dtAllAgents.Select("AgentId='" & item.Value & "'")(0).Item("ProcessId") & "]"
                    dr("ShiftIN") = "OFF"
                    dr("Dayname") = Sdate.DayOfWeek
                    dr("Rosterdate") = Sdate.ToString("yyyyMMdd")
                    dtFillData.Rows.Add(dr)
                    Sdate = Sdate.AddDays(1)
                End While
            End If
        Next
        dtFillData.AcceptChanges()
    End Sub
    Private Sub WeekWiseLatestRoster()
        Dim db As New DBAccess("CRM")
        'Dim dt As DataTable
        'Dim Sdate, Edate As DateTime
        dtFillData.Clear()
        db.slDataAdd("Rosterdate", ucDateFrom.yyyymmdd)
        If chkIschecked = 1 Then
            db.slDataAdd("SupervisorID", SupervisorID)
        End If
        db.slDataAdd("ProcessId", CboProcess.SelectedValue)
        db.slDataAdd("HierarchyWise", chkIschecked)
        db.slDataAdd("WeekWise", 1)
        'dt=db.ReturnTable("usp_GetLatestRoster_New2", , True)
        dtFillData = db.ReturnTable("usp_GetLatestRoster_New2", , True)
        db = Nothing
        'dtFillData = dt.Copy
        GetShiftWiseAgent()
        SetColor()
        'If dt.Rows.Count > 0 Then
        '    Sdate = ucDateFrom.value
        '    Edate = DateAdd("d", 7 - IIf(Sdate.DayOfWeek = 0, 7, Sdate.DayOfWeek), Sdate)
        '    While Sdate <= Edate
        '        If dtAllAgents.Rows.Count > 0 Then
        '            For Each row As DataRow In dt.Rows
        '                If dtFillData.Rows.Count > 0 Then
        '                    Dim dtRow As DataRow = dtFillData.NewRow
        '                    dtRow("AgentID") = row.Item("AgentID")
        '                    dtRow("AgentName") = row.Item("AgentName")
        '                    dtRow("Process") = dtAllAgents.Select("AgentId='" & row.Item("AgentID") & "'")(0).Item("Process") & "[" & dtAllAgents.Select("AgentId='" & row.Item("AgentID") & "'")(0).Item("ProcessId") & "]"
        '                    If chkIsSatOff.Checked = True And Sdate.DayOfWeek = DayOfWeek.Saturday Then
        '                        dtRow("ShiftIN") = "OFF"
        '                        'dtRow("ShiftOut") = "OFF"
        '                    ElseIf chkIsSunOff.Checked = True And Sdate.DayOfWeek = DayOfWeek.Sunday Then
        '                        dtRow("ShiftIN") = "OFF"
        '                        ' dtRow("ShiftOut") = "OFF"
        '                    ElseIf chkIsSunOff.Checked = True And Sdate.DayOfWeek = DayOfWeek.Sunday Then
        '                        dtRow("ShiftIN") = "OFF"
        '                    Else
        '                        dtRow("ShiftIN") = row.Item("ShiftIN")
        '                        'dtRow("ShiftOut") = cboShift.SelectedItem.Text
        '                    End If

        '                    dtRow("Dayname") = Sdate.DayOfWeek
        '                    dtRow("RosterDate") = Sdate.ToString("yyyyMMdd")
        '                    dtFillData.Rows.Add(dtRow)
        '                    dtFillData.AcceptChanges()
        '                Else
        '                    Dim dtRow As DataRow = dtFillData.NewRow
        '                    dtRow("AgentID") = row.Item("AgentID")
        '                    dtRow("AgentName") = row.Item("AgentName")
        '                    dtRow("Process") = dtAllAgents.Select("AgentId='" & row.Item("AgentID") & "'")(0).Item("Process") & "[" & dtAllAgents.Select("AgentId='" & row.Item("AgentID") & "'")(0).Item("ProcessId") & "]"
        '                    If chkIsSatOff.Checked = True And Sdate.DayOfWeek = DayOfWeek.Saturday Then
        '                        dtRow("ShiftIN") = "OFF"
        '                        'dtRow("ShiftOut") = "OFF"
        '                    ElseIf chkIsSunOff.Checked = True And Sdate.DayOfWeek = DayOfWeek.Sunday Then
        '                        dtRow("ShiftIN") = "OFF"
        '                        ' dtRow("ShiftOut") = "OFF"
        '                    ElseIf chkIsSunOff.Checked = True And Sdate.DayOfWeek = DayOfWeek.Sunday Then
        '                        dtRow("ShiftIN") = "OFF"
        '                    Else
        '                        dtRow("ShiftIN") = row.Item("ShiftIN")
        '                        'dtRow("ShiftOut") = cboShift.SelectedItem.Text
        '                    End If
        '                    dtRow("Dayname") = Sdate.DayOfWeek
        '                    dtRow("RosterDate") = Sdate.ToString("yyyyMMdd")
        '                    dtFillData.Rows.Add(dtRow)
        '                    dtFillData.AcceptChanges()
        '                End If
        '            Next
        '        End If
        '        Sdate = Sdate.AddDays(1)
        '    End While
        'End If
        'GetShiftWiseAgent()
        'SetColor()
    End Sub '----Get Week wise Roster
#End Region
#Region "--- Event ---"
    Protected Sub btsave_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btsave.Click
        SaveFinalRoster()
    End Sub
    Protected Sub ucDateFrom_Changed(ByVal sender As Object, ByVal e As System.EventArgs) Handles ucDateFrom.Changed
        If validatecurrentdate(ucDateFrom.value) = False Then
            AlertMessage("Date is not in valid range")
            ucDateFrom.value = CurrentDate
            lstSelectedAgent.Items.Clear()
            dtFillData.Clear()
            dtfinal.Clear()
            lstAllAgents.Items.Clear()
            GetSelectedDaysRoster()

        Else
            CurrentDate = ucDateFrom.value
            lstSelectedAgent.Items.Clear()
            dtFillData.Clear()
            dtfinal.Clear()
            lstAllAgents.Items.Clear()
            GetSelectedDaysRoster()
        End If
    End Sub
    Protected Sub GridView1_RowDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles GridView1.RowDataBound
        If e.Row.RowType = DataControlRowType.DataRow Then
            Dim drdata As DataRow = dtfinal.Select("AgentID='" & e.Row.Cells(0).Text.Trim & "'")(0)
            Dim drShift As DataRow
            Dim str As String

            For Each col As DataColumn In dtfinal.Columns
                Dim cbo As New DropDownList
                If col.ColumnName.ToLower <> "agentid" And col.ColumnName.ToLower <> "agentname" And col.ColumnName.ToLower <> "process" Then
                    Dim drr() As DataRow = dtfinal.Select("AgentID='" & e.Row.Cells(0).Text & "' AND [" & col.ColumnName & "]='" & drdata.Item(col.ColumnName) & "'")
                    If drr.Length > 0 Then
                        drShift = dtshift.Select("ShiftName='" & drdata.Item(col.ColumnName) & "'")(0)
                        CType(e.Row.FindControl(col.ColumnName), DropDownList).SelectedValue = Convert.ToInt16(drShift.Item("ShiftID"))

                    Else
                        drShift = dtshift.Select("ShiftName='OFF'")(0)
                        CType(e.Row.FindControl(col.ColumnName), DropDownList).SelectedValue = Convert.ToInt16(drShift.Item("ShiftID"))
                    End If
                    ' AddHandler CType(e.Row.FindControl(col.ColumnName), DropDownList).SelectedIndexChanged, AddressOf updatecount
                End If
            Next
        End If
        ViewState("dynamicGrid") = True
    End Sub
    'Protected Sub updatecount(ByVal sender As Object, ByVal e As System.EventArgs)
    '    'MsgBox(sender.ID)
    '    Dim lbloffcount, lblrosteredcount As Label
    '    Dim OFFid, rosteredId As String
    '    OFFid = "countlbl" & sender.ID
    '    rosteredId = "Rosteredlbl" & sender.ID
    '    lbloffcount = CType(GridView1.HeaderRow.FindControl(OFFid), Label)
    '    lblrosteredcount = CType(GridView1.HeaderRow.FindControl(rosteredId), Label)
    '    If sender.SelectedValue <> 14 Then
    '        lbloffcount.Text = "Count Of OFF:- " & Convert.ToInt32(lbloffcount.Text.Replace("Count Of OFF:- ", "")) - 1
    '        lblrosteredcount.Text = "<br />Rostered Count:- " & Convert.ToInt32(lblrosteredcount.Text.Replace("<br />Rostered Count:- ", "")) + 1
    '    Else
    '        lbloffcount.Text = "Count Of OFF:- " & Convert.ToInt32(lbloffcount.Text.Replace("Count Of OFF:- ", "")) + 1
    '        lblrosteredcount.Text = "<br />Rostered Count:- " & Convert.ToInt32(lblrosteredcount.Text.Replace("<br />Rostered Count:- ", "")) - 1
    '    End If

    '    'lbloffcount.Text = sender.SelectedValue
    'End Sub
    Protected Sub btnAdd_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnAdd.Click
        FillDataTable()
    End Sub
    Protected Sub btnRemove_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnRemove.Click
        RemoveFromDt() '---- Commented By Rajendra        
    End Sub
    Protected Sub cboShift_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboShift.SelectedIndexChanged
        GetAllAgents()
        GetShiftWiseAgent()
    End Sub
    Protected Sub imgNext_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles imgNext.Click
        If Not CboProcess.SelectedIndex < 0 Then
            ProcessID = Convert.ToInt16(CboProcess.SelectedValue)
        End If
        If Not CheckBox1.Checked Then
            pnlDateRange.Visible = True
            If Label2.Text = "" Then
                Label1.Text = "Date: "
                lblDateFrom.Text = ucDateFrom.yyyymmdd
            End If
            pnlDate.Visible = False
        End If
        IsSatSundayOFF()
        btsave.Visible = True
        rblisAll.Visible = False
        btGetLatestRoster.Visible = False
        btnAdd.Visible = False
        btnRemove.Visible = False
        CheckBox1.Visible = False
        ucDateFrom.Visible = False
        cboShift.Enabled = False
        imgNext.Visible = False
        imgPrev.Visible = True
        lstAllAgents.Visible = False
        lstSelectedAgent.Visible = False
        lblAllAgents.Visible = False
        lblSelectedAgents.Visible = False
        ' PlaceHolder1.Visible = False
        FillRosterGridNew() '-- By Rajendra
        CboProcess.Enabled = False
        chkIsSatOff.Visible = False
        chkIsSunOff.Visible = False
        GridView1.Visible = True
        PlaceHolder3.Visible = True
        chkIschecked = rblisAll.SelectedValue
        If chkIschecked = 0 Then
            rblisAll.SelectedValue = 0
        Else
            rblisAll.SelectedValue = 1
        End If
        btnrefreshcount.Visible = True
        tbllist.Visible = False
    End Sub
    Protected Sub imgPrev_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles imgPrev.Click
        btsave.Visible = False
        rblisAll.Visible = True
        btGetLatestRoster.Visible = True
        btFillWeekRoster.Visible = True
        btnAdd.Visible = True
        btnRemove.Visible = True
        CboProcess.Enabled = True
        pnlDateRange.Visible = False
        pnlDate.Visible = True
        ucDateFrom.Visible = True
        cboShift.Enabled = True
        imgNext.Visible = True
        imgPrev.Visible = False
        lstAllAgents.Visible = True
        lstSelectedAgent.Visible = True
        lblAllAgents.Visible = True
        lblSelectedAgents.Visible = True
        CheckBox1.Visible = True
        PlaceHolder1.Visible = True
        GridView1.Columns.Clear()
        GridView1.DataSource = Nothing
        GridView1.DataBind()
        GridView1.Visible = False
        PlaceHolder2.Visible = False
        ViewState("dynamicGrid") = False
        ViewState("Enddate") = ""
        ViewState("FromDate") = ""
        ViewState("ProcessID") = ""
        'isHierarchy = False
        chkIsSatOff.Visible = True
        chkIsSunOff.Visible = True
        chkIschecked = rblisAll.SelectedValue
        PlaceHolder3.Visible = False
        If chkIschecked = 0 Then
            rblisAll.SelectedValue = 0
            CboProcess.Enabled = True
        Else
            rblisAll.SelectedValue = 1
            CboProcess.Enabled = False
        End If
        GetAllAgents()
        GetShiftWiseAgent() '--- By Rajendra
        btnrefreshcount.Visible = False
        tbllist.Visible = True
    End Sub
    Protected Sub CboProcess_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles CboProcess.SelectedIndexChanged
        dtFillData.Clear()
        dtfinal.Clear()
        lstAllAgents.Items.Clear()
        CheckSatSundayOff()
        GetSelectedDaysRoster()
    End Sub
    Protected Sub btGetLatestRoster_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btGetLatestRoster.Click
        dtFillData.Clear()
        dtfinal.Clear()
        lstAllAgents.Items.Clear()
        GetAllAgents()
        GetLatestRoster()
    End Sub
    Protected Sub rblisAll_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles rblisAll.SelectedIndexChanged
        If rblisAll.SelectedValue = 1 Then
            chkIschecked = 1
            'ViewState("isHierarchy") = True
            CboProcess.Enabled = False
            dtFillData.Clear()
            dtfinal.Clear()
            lstAllAgents.Items.Clear()
            LoadData()
        Else
            chkIschecked = 0
            'ViewState("isHierarchy") = True
            CboProcess.Enabled = True
            dtFillData.Clear()
            dtfinal.Clear()
            lstAllAgents.Items.Clear()
            LoadData()
        End If
    End Sub
    Protected Sub btnrefreshcount_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnrefreshcount.Click
        createcounttable()
    End Sub

    Protected Sub btFillWeekRoster_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btFillWeekRoster.Click
        dtFillData.Clear()
        dtfinal.Clear()
        lstAllAgents.Items.Clear()
        GetAllAgents()
        WeekWiseLatestRoster()

        If Not CboProcess.SelectedIndex < 0 Then
            ProcessID = Convert.ToInt16(CboProcess.SelectedValue)
        End If
        If Not CheckBox1.Checked Then
            pnlDateRange.Visible = True
            If Label2.Text = "" Then
                Label1.Text = "Date: "
                lblDateFrom.Text = ucDateFrom.yyyymmdd
            End If
            pnlDate.Visible = False
        End If
        'IsSatSundayOFF()
        btsave.Visible = True
        rblisAll.Visible = False
        btGetLatestRoster.Visible = False
        btFillWeekRoster.Visible = False
        btnAdd.Visible = False
        btnRemove.Visible = False
        CheckBox1.Visible = False
        ucDateFrom.Visible = False
        cboShift.Enabled = False
        imgNext.Visible = False
        imgPrev.Visible = True
        lstAllAgents.Visible = False
        lstSelectedAgent.Visible = False
        lblAllAgents.Visible = False
        lblSelectedAgents.Visible = False
        FillRosterGridNew()
        CboProcess.Enabled = False
        chkIsSatOff.Visible = False
        chkIsSunOff.Visible = False
        GridView1.Visible = True
        PlaceHolder3.Visible = True
        chkIschecked = rblisAll.SelectedValue
        If chkIschecked = 0 Then
            rblisAll.SelectedValue = 0
        Else
            rblisAll.SelectedValue = 1
        End If
        btnrefreshcount.Visible = True
        tbllist.Visible = False
    End Sub '---- Week wise Roster
#End Region
#Region "--- Utility ---"
    Private Sub AlertMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMFail"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub

    Private Sub SuccessMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMSuccess"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub
#End Region

End Class

Public Class TemplateHandler

    Implements ITemplate
    Sub InstantiateIn(ByVal container As Control) Implements ITemplate.InstantiateIn
        Dim ddl As New DropDownList
        Dim db As New DBAccess("CRM")
        Dim dtshift As New DataTable
        dtshift = db.ReturnTable("select *from tbl_Config_RosterShift where active=1", False)
        db = Nothing
        ddl.CssClass = "combo"
        ddl.ID = id
        ddl.DataSource = dtshift
        ddl.EnableViewState = True
        ddl.DataTextField = "Shift"
        ddl.DataValueField = "Shiftid"
        ddl.DataBind()
        'ddl.AutoPostBack = True
        'ddl.Attributes.Add("OnSelectedIndexChanged", "updatecount()")
        'ddl.Attributes.Add("ABC", lbl)
        container.Controls.Add(ddl)

    End Sub
    
    Dim id As String
    Dim lbl As String

    Public Sub New(ByVal id1 As String, ByVal lblcount As String)
        id = id1
        lbl = lblcount
    End Sub
    
End Class