﻿Imports com.nss.DBAccess
Imports System.Data
Partial Class Staffing_Roster_Default
    Inherits System.Web.UI.Page

    
   
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Response.Redirect("Roster.aspx")
    End Sub
End Class
