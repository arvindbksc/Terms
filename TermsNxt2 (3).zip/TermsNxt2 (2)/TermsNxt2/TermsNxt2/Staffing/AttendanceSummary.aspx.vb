﻿Imports com.nss.DBAccess
Imports System.Data
Imports System.Text
Partial Class Staffing_AttendanceSummary
    Inherits System.Web.UI.Page
#Region "Properties"
    Property ReportType() As Integer
        Get
            Return ViewState("ReportType")
        End Get
        Set(ByVal value As Integer)
            ViewState("ReportType") = value
        End Set
    End Property
    Property CampaignID() As Integer
        Get
            Return 0 'ViewState("CampaignID")
        End Get
        Set(ByVal value As Integer)
            'ViewState("CampaignID") = value
        End Set
    End Property

    Property AgentID() As String
        Get
            Return ViewState("AgentID")
        End Get
        Set(ByVal value As String)
            ViewState("AgentID") = value
        End Set
    End Property
#End Region
    Dim startday As Integer, endday As Integer
    Dim dt As New DataTable
    Dim TotalScheduled, TotalPresent As Integer
#Region "Load"
    Private Sub LoadData()
        'UcDateTo.value = DateTime.Now
        'ucDateFrom.value = DateTime.Now.AddMonths(-1).AddDays(21 - DateTime.Now.Day)
        'lblDate.Text = "Aprroved cases will be processed tomorrow" & DateTime.Now.ToString("dd-MMM-yyyy") & " at 6:30 AM IST."
        FillCommonFilters()
        Common.FillProcessCampaigns(CboProcess, cboCampaigns, AgentID, CampaignID)
    End Sub
    Private Sub FillCommonFilters()
        Dim db As New DBAccess
        Dim dt As DataTable = db.ReturnTable("select * from tbl_Reports_DatePeriods")
        db = Nothing
        Dim dr As DataRow = dt.NewRow
        dr(0) = 10
        dr(1) = "Between"
        dt.Rows.Add(dr)
        CboPeriod.DataTextField = "Caption"
        CboPeriod.DataValueField = "Period"
        CboPeriod.DataSource = dt
        CboPeriod.DataBind()
        dt = Nothing
        db = New DBAccess
        dt = db.ReturnTable("Select Caption,ID from tbl_Reports_GroupBy")
        Dim dtgroup As DataTable = dt.Select("ID<>4").CopyToDataTable
        'dr = dt.NewRow
        'dr(0) = "Questions"
        'dr(1) = 5
        'dt.Rows.Add(dr)
        'dr = dt.NewRow
        'dr(0) = "PostCode"
        'dr(1) = 6
        'dt.Rows.Add(dr)
        db = Nothing
        CboGroup.DataTextField = "Caption"
        CboGroup.DataValueField = "ID"
        CboGroup.DataSource = dtgroup
        CboGroup.DataBind()
    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        HumanMessage.Style.Item("visibility") = "hidden"
        If Not IsPostBack Then
            ReportType = Request.QueryString("ReportType")
            If Session("AgentID") <> "" Then
                CampaignID = Session("CampaignID")
                AgentID = Session("AgentID")
                LoadData()
                UcDateTo.Visible = False
                ucDateFrom.Visible = False
                lblAnd.Visible = False
                If Request.QueryString("value") = "return" Then
                    QueryString()
                End If
                PanelReports.Controls.Add(Common.GetMenu(Request.Url, AgentID, Request.ApplicationPath))
            End If
            CboProcess.SelectedValue = Request.QueryString("process")
            CboPeriod.SelectedValue = Request.QueryString("period")
            CboGroup.SelectedValue = Request.QueryString("groupby")

        End If
        fillgrid()

    End Sub
    Private Sub QueryString() '------------ By Gaurav -----------------------
        CboProcess.SelectedValue = Request.QueryString("Process")
        CboGroup.SelectedValue = Request.QueryString("group")
        If Request.QueryString("period") = 10 Then
            CboPeriod.SelectedValue = Request.QueryString("Period")
            UcDateTo.Visible = True
            ucDateFrom.Visible = True
            lblAnd.Visible = True
            Dim startday As DateTime, endday As DateTime
            Dim dbdate As New DBAccess
            startday = dbdate.ReturnValue("select CONVERT(DateTime,convert(varchar," & Request.QueryString("FromDate").ToString() & ",103))", False)
            dbdate = Nothing
            dbdate = New DBAccess
            endday = dbdate.ReturnValue("select CONVERT(DateTime,convert(varchar," & Request.QueryString("ToDate").ToString() & ",103))", False)
            dbdate = Nothing
            ucDateFrom.value = startday
            UcDateTo.value = endday
        Else
            CboPeriod.SelectedValue = Request.QueryString("period")
        End If
    End Sub
    Private Sub fillgrid()

        'For Each obj In footerval
        '    obj = 0
        'Next
        GridView1.DataSource = Nothing
        'Dim columns As String
        Dim db As DBAccess

        If CboPeriod.SelectedValue = 10 Then
            startday = ucDateFrom.yyyymmdd
            endday = UcDateTo.yyyymmdd
        Else
            db = New DBAccess
            db.slDataAdd("Period", CboPeriod.SelectedValue)
            db.slDataAdd("Campaignid", CampaignID)
            Dim dr As DataRow = db.ReturnRow("usp_GetStart_EndDateForAPeriod", True)
            db = Nothing
            startday = dr(0)
            endday = dr(1)
        End If

        db = New DBAccess
        dt = New DataTable

        db.slDataAdd("StartDate", startday)
        db.slDataAdd("EndDate", endday)
        db.slDataAdd("processid", CboProcess.SelectedValue)
        db.slDataAdd("campaignid", cboCampaigns.SelectedValue)
        db.slDataAdd("userid", AgentID)
        db.slDataAdd("groupBy", CboGroup.SelectedValue)
        If cboFilterBy.SelectedItem.Text <> "None" And txtFilterValue.Text.Trim <> "" Then
            lblFilter.Text = "Filtered for " & cboFilterBy.SelectedItem.Text & " = " & txtFilterValue.Text
            If cboFilterBy.SelectedValue.Contains("String") Then
                'db.slDataAdd("Filterby", "'" & cboFilterBy.SelectedItem.Text & "'")
            End If
            db.slDataAdd("Filterby", cboFilterBy.SelectedItem.Text)
            db.slDataAdd("Filterbyvalue", txtFilterValue.Text)
        End If
        dt = db.ReturnTable("usp_AttendanceSummary", , True)
        'Dim dtime As Date
        'dtime = dr(0).ToString
        breadcrumbs.CurrentPage = " Attendance Summary Between " & IntegerToDateString(startday) & "  and " & IntegerToDateString(endday)
        'LblError.Text = " " & " for " & CboProcess.SelectedItem.Text & " campaign"

        db = Nothing
        GridView1.AutoGenerateColumns = False
        CreateGridColumns(dt.Columns)
        'If dt.Rows.Count > 0 Then
        '    For inCtr = 0 To dt.Columns.Count - 1
        '        Dim bc1 As New BoundField
        '        bc1.DataField = dt.Columns.Item(inCtr).ToString
        '        bc1.HeaderText = dt.Columns.Item(inCtr).ToString
        '        GridView1.Columns.Add(bc1)
        '    Next
        GridView1.DataSource = dt
        GridView1.DataBind()
        ' GridView1.RowStyle.HorizontalAlign = HorizontalAlign.Left
        dt = Nothing
        If CboGroup.SelectedValue = 2 Then
            GridView1.Columns(0).Visible = False
        End If
        If TotalScheduled > TotalPresent Then
            lblPresent.ForeColor = Drawing.Color.Red
        Else
            lblPresent.ForeColor = Drawing.Color.Green
        End If
        lblScheduled.Text = TotalScheduled.ToString
        lblPresent.Text = TotalPresent.ToString
        'Else
        'GridView1.DataSource = Nothing

        'End If

        'System.Threading.Thread.Sleep(100)
    End Sub
    Private Function IntegerToDateString(ByVal d As Integer) As String
        Return d.ToString.Substring(0, 4) & "-" & d.ToString.Substring(4, 2) & "-" & d.ToString.Substring(6, 2)
    End Function
#End Region
#Region "Gridops"
    Private Sub CreateGridColumns(ByVal cols As DataColumnCollection)
        GridView1.Columns.Clear()
        'Dim tempcolumn As TemplateField
        Dim bouncol As BoundField
        Dim objcol As DataColumn

        For Each objcol In cols
            '    If objcol.ColumnName = "Agents" Then
            '        tempcolumn = New TemplateField
            '        Dim tmpagcol As New TemplateAgentName
            '        tempcolumn.HeaderText = "Agents"
            '        'tmpagcol.DataImageField = "AgentStatus"
            '        tmpagcol.DataTextField = objcol.ColumnName
            '        tempcolumn.ItemStyle.HorizontalAlign = HorizontalAlign.Left
            '        tempcolumn.ItemTemplate = tmpagcol
            '        GridView1.Columns.Add(tempcolumn)
            '    Else
            '        If objcol.ColumnName <> "Agentstatus" Then
            bouncol = New BoundField
            bouncol.HeaderText = objcol.ColumnName
            bouncol.DataField = objcol.ColumnName


            GridView1.Columns.Add(bouncol)
            '        End If

            '    End If

        Next
        'Dim MonthCols As BoundField

        'Dim ctr As Integer

        'For ictr As Integer = 0 To ctr
        '    tempcolumn = New TemplateColumn
        '    Dim tmp As New TemplateField

        '    'tempcolumn.ItemTemplate = 
        '    MonthCols = New BoundField
        '    MonthCols.HeaderText = "Month" & ictr + 1
        '    MonthCols.DataField = ""
        '    GridView1.Columns.Add(MonthCols)
        '    'Next

    End Sub
    Protected Sub GridView1_RowCreated(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles GridView1.RowCreated
        If e.Row.RowType = DataControlRowType.DataRow Then
            If IsDate(e.Row.Cells(0).Text) Then
                e.Row.Cells(0).Text = String.Format("dd-MMM-yyyy", e.Row.Cells(0).Text)
            End If
        End If
    End Sub

    Protected Sub GridView1_RowDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles GridView1.RowDataBound
        Dim btnlink As LinkButton
        If e.Row.RowType = DataControlRowType.DataRow Then
            If IsDate(e.Row.Cells(0).Text) Then
                e.Row.Cells(0).Text = String.Format("{0:d}", e.Row.Cells(0).Text)
            End If
            btnlink = New LinkButton
            If CboGroup.SelectedValue = 2 Then
                btnlink.ID = dt.Rows(e.Row.RowIndex)("Group Id").ToString
                btnlink.Text = e.Row.Cells(1).Text
                AddHandler btnlink.Click, AddressOf Me.btnlink_OnClick
                e.Row.Cells(1).Controls.Add(btnlink)
                TotalScheduled += e.Row.Cells(2).Text
                TotalPresent += Convert.ToInt64(e.Row.Cells(3).Text) + Convert.ToInt64(e.Row.Cells(10).Text)
            Else
                btnlink.Text = e.Row.Cells(0).Text
                AddHandler btnlink.Click, AddressOf Me.btnlink_OnClick
                e.Row.Cells(0).Controls.Add(btnlink)
                TotalScheduled += e.Row.Cells(1).Text
                TotalPresent += Convert.ToInt64(e.Row.Cells(2).Text) + Convert.ToInt64(e.Row.Cells(9).Text)

            End If
        End If
    End Sub
    Public Sub btnlink_OnClick(ByVal sender As Object, ByVal e As EventArgs)

        Dim id As String ' = CType(sender, LinkButton).Text
        If CboGroup.SelectedValue = 2 Then
            id = CType(sender, LinkButton).ID
            Response.Redirect("~/Staffing/AttendanceDetail.aspx?process=" & CboProcess.SelectedValue & "&group=" & CboGroup.SelectedItem.Value & "&period=" & CboPeriod.SelectedValue & "&Supervisor=" & CType(sender, LinkButton).Text & "&val=" & id & "&from=" & startday & "&to=" & endday & "&Page=" & "AttendanceSummary")
        Else
            id = CType(sender, LinkButton).Text
            If id.Contains("/") Then
                id = id.Replace("/", "-")
            End If
            Response.Redirect("~/Staffing/AttendanceDetail.aspx?process=" & CboProcess.SelectedValue & "&group=" & CboGroup.SelectedItem.Value & "&period=" & CboPeriod.SelectedValue & "&val=" & id & "&from=" & startday & "&to=" & endday & "&Page=" & "AttendanceSummary")
        End If
        'Dim str As String
        'str = "$('#DialogBackground').height($(document).height()-10);$('#DialogBackground').width($(window).width());$('#DialogBackground').css('visibility','visible');$('#PanelDetail').css('visibility','visible');" & _
        '" $('#PanelDetail').css('left',($(window).width() - $('#PanelDetail').width())/2); "
        'lblText.Text = id
        'ScriptManager.RegisterStartupScript(Page, Page.GetType(), "Movedialog", str, True)
    End Sub
#End Region
#Region "Event"
    Protected Sub CboProcess_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles CboProcess.SelectedIndexChanged
        Common.FillCampaigns(cboCampaigns, AgentID, CboProcess.SelectedValue)
        ' fillgrid()
    End Sub
    Protected Sub cboCampaigns_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboCampaigns.SelectedIndexChanged
        CampaignID = cboCampaigns.SelectedValue
        ' fillgrid()
    End Sub

    Protected Sub ucDateFrom_Changed(ByVal sender As Object, ByVal e As System.EventArgs) Handles ucDateFrom.Changed
        ' fillgrid()
    End Sub
    Protected Sub UcDateTo_Changed(ByVal sender As Object, ByVal e As System.EventArgs) Handles UcDateTo.Changed
        ' fillgrid()
    End Sub

    Protected Sub ImageButton1_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton1.Click
        ' fillgrid()
        GridViewExportUtil.Export(breadcrumbs.CurrentPage & ".xls", Me.GridView1)
    End Sub
    Private Sub ExportToexcel()
        Dim tw As New IO.StringWriter()
        Dim hw As New System.Web.UI.HtmlTextWriter(tw)
        'Dim frm As HtmlForm = New HtmlForm()
        Response.ContentType = "application/vnd.ms-excel"
        Response.AddHeader("content-disposition", "attachment;filename=" & breadcrumbs.CurrentPage & ".xls")
        Response.Charset = ""
        EnableViewState = False
        'Controls.Add(frm)
        GridView1.RenderControl(hw)
        Response.Write(tw.ToString())
        Response.End()
    End Sub
    Protected Sub CboGroup_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles CboGroup.SelectedIndexChanged
        ' fillgrid()
    End Sub

    Protected Sub btnFilter_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnFilter.Click
        'fillgrid()
    End Sub

    Protected Sub btnRefresh_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnRefresh.Click
        'fillgrid()
    End Sub

    Protected Sub CboPeriod_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles CboPeriod.SelectedIndexChanged
        If CboPeriod.SelectedValue = 10 Then
            ucDateFrom.Visible = True
            UcDateTo.Visible = True
            lblAnd.Visible = True
            'fillgrid()
        Else
            ucDateFrom.Visible = False
            UcDateTo.Visible = False
            lblAnd.Visible = False
            'fillgrid()
        End If
    End Sub
#End Region
#Region "Not Use"
    'Dim footerval(12) As Double
    'Protected Sub GridView1_RowDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles GridView1.RowDataBound
    '    Try

    '        If e.Row.RowType = DataControlRowType.DataRow Then
    '            e.Row.Cells(0).HorizontalAlign = HorizontalAlign.Left
    '            For i As Integer = 1 To e.Row.Cells.Count - 1
    '                footerval(i) = footerval(i) + e.Row.Cells(i).Text
    '            Next
    '        ElseIf e.Row.RowType = DataControlRowType.Footer Then
    '            e.Row.Cells(0).Text = "Total: "
    '            For i As Integer = 1 To e.Row.Cells.Count - 1
    '                e.Row.Cells(i).Text = footerval(i)
    '            Next
    '        End If
    '        '
    '    Catch ex As Exception

    '    End Try
    'End Sub
#End Region

    Protected Sub imgfav_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles imgfav.Click
        Common.AddToFav(AgentID, "Attendance Summary")
        SuccessMessage("Report has been added to your favourite list")
        'fillgrid()
    End Sub
#Region "Utility"

    Private Sub AlertMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMFail"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub

    Private Sub SuccessMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMSuccess"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub

    'Protected Sub ImageButton1_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton1.Click
    '    'fillgrid()
    '    GridViewExportUtil.Export(lblReportName.CurrentPage & "-" & LblError.Text & ".xls", Me.GdAttendance)
    'End Sub


    Public Overrides Sub VerifyRenderingInServerForm(ByVal Control As Control)

    End Sub

#End Region
End Class
