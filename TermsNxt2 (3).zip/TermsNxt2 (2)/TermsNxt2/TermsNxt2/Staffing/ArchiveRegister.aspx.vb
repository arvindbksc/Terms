﻿Imports com.nss.DBAccess
Imports System.Data
Imports System.Text
Imports System.Globalization
Partial Class ArchiveAttendance_Register
    Inherits System.Web.UI.Page
#Region "Properties"
    Property ReportType() As Integer
        Get
            Return ViewState("ReportType")
        End Get
        Set(ByVal value As Integer)
            ViewState("ReportType") = value
        End Set
    End Property
    Property CampaignID() As Integer
        Get
            Return 0 'ViewState("CampaignID")
        End Get
        Set(ByVal value As Integer)
            'ViewState("CampaignID") = value
        End Set
    End Property

    Property AgentID() As String
        Get
            Return ViewState("AgentID")
        End Get
        Set(ByVal value As String)
            ViewState("AgentID") = value
        End Set
    End Property
#End Region
    Private Sub LoadData()

        'UcDateTo.value = DateTime.Now
        'ucDateFrom.value = DateTime.Now.AddMonths(-1).AddDays(21 - DateTime.Now.Day)
        FillCommonFilters()
        Common.FillProcessCampaigns(CboProcess, cboCampaigns, AgentID, CampaignID)
        'lblDate.Text = "Aprroved cases will be processed tomorrow" & DateTime.Now.ToString("dd-MMM-yyyy") & " at 6:30 AM IST."

    End Sub

    Private Sub FillCommonFilters()
        Dim db As New DBAccess
        Dim dt As DataTable = db.ReturnTable("select * from tbl_Reports_DatePeriods where period not in (8,9)")
        db = Nothing
        Dim dr As DataRow = dt.NewRow
        dr(0) = 10
        dr(1) = "Between"
        dt.Rows.Add(dr)
        CboPeriod.DataTextField = "Caption"
        CboPeriod.DataValueField = "Period"
        CboPeriod.DataSource = dt
        CboPeriod.DataBind()
    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        HumanMessage.Style.Item("visibility") = "hidden"
        If Not IsPostBack Then
            If Session("AgentID") <> "" Then
                CampaignID = Session("CampaignID")
                AgentID = Session("AgentID")
                'AgentID = "nss47671"
                PanelReports.Controls.Add(Common.GetMenu(Request.Url, AgentID, Request.ApplicationPath))
                LoadData()
                fillgrid()
                UcDateTo.Visible = False
                ucDateFrom.Visible = False
                lblAnd.Visible = False
            End If
        End If
    End Sub

    Private Sub fillgrid()
        Dim startdate As Date, enddate As Date
        'startdate = ucDateFrom.value
        'enddate = UcDateTo.value
        Dim startday As Integer, endday As Integer
        Dim db As DBAccess
        Dim dt As DataTable
        If CboPeriod.SelectedValue = 10 Then
            startday = ucDateFrom.yyyymmdd
            endday = UcDateTo.yyyymmdd
            'startdate = ucDateFrom.value
            'enddate = UcDateTo.value
        Else
            db = New DBAccess
            db.slDataAdd("Period", CboPeriod.SelectedValue)
            db.slDataAdd("Campaignid", CampaignID)
            Dim dr As DataRow = db.ReturnRow("usp_GetStart_EndDateForAPeriod", True)
            db = Nothing
            startday = dr(0)
            endday = dr(1)
            'startdate = dr(0)
            'enddate = dr(1)
        End If
        breadcrumbs.CurrentPage = "Archive Attendance Register For Resigned Staffs Between " & IntegerToDateString(startday) & "  and " & IntegerToDateString(endday)
        db = New DBAccess
        startdate = db.ReturnValue("select CONVERT(datetime,convert(varchar," & startday & "))", False)
        enddate = db.ReturnValue("select CONVERT(datetime,convert(varchar," & endday & "))", False)
        db = Nothing
        'Dim days As Integer
        'days = DateDiff(DateInterval.Day, startdate, enddate)
        'If days > 90 Then
        '    AlertMessage("Date not in valid range, It will shows data for 90 days")
        '    Exit Sub
        'Else
        '    HideMessage("")
        'End If
        db = New DBAccess("CRM")
        db.slDataAdd("StartDate", startday)
        db.slDataAdd("EndDate", endday)
        db.slDataAdd("userid", AgentID)
        db.slDataAdd("processid", CboProcess.SelectedValue)
        db.slDataAdd("campaignid", CampaignID)
        dt = db.ReturnTable("usp_ArchiveAttendanceRegister", , True)


        db = Nothing
        GdAttendance.AutoGenerateColumns = False
        Dim dtReport As New DataTable
        Dim bouncol As BoundField
        GdAttendance.Columns.Clear()
        dtReport.Columns.Add("AgentID", System.Type.GetType("System.String"))
        bouncol = New BoundField
        bouncol.HeaderText = "Agent ID"
        bouncol.DataField = "AgentID"
        GdAttendance.Columns.Add(bouncol)
        dtReport.Columns.Add("AgentName", System.Type.GetType("System.String"))
        bouncol = New BoundField
        bouncol.HeaderText = "Agent Name"
        bouncol.DataField = "AgentName"
        GdAttendance.Columns.Add(bouncol)
        'dtReport.Columns.Add("Campaign", System.Type.GetType("System.String"))
        'bouncol = New BoundField
        'bouncol.HeaderText = "Campaign"
        'bouncol.DataField = "Campaign"
        'GdAttendance.Columns.Add(bouncol)

        ' startdate = Convert.ToDateTime(startday.ToString)
        While (startdate <= enddate)
            dtReport.Columns.Add(startdate.Month.ToString.PadLeft(2, "0") & startdate.Day.ToString.PadLeft(2, "0"), System.Type.GetType("System.String"))
            'dtReport.Columns.Add(startday.ToString.Substring(4, 2) & startday.ToString.Substring(6, 2), System.Type.GetType("System.String"))
            bouncol = New BoundField
            bouncol.HeaderText = startdate.Day.ToString.PadLeft(2, "0") 'startday.ToString.Substring(6, 2)
            bouncol.DataField = startdate.Month.ToString.PadLeft(2, "0") & startdate.Day.ToString.PadLeft(2, "0")
            bouncol.NullDisplayText = "."
            GdAttendance.Columns.Add(bouncol)
            startdate = startdate.AddDays(1)
            'startday=startday.ToString.
        End While
        Dim curagentid As String = ""
        Dim reporow As DataRow
        For Each row In dt.Rows
            If curagentid.ToLower <> row("AgentID").ToString.ToLower Then
                curagentid = row("AgentID")
                reporow = dtReport.NewRow

                reporow("AgentID") = row("AgentID").ToString.ToUpper
                reporow("AgentName") = row("AgentName")
                'reporow("Campaign") = row("Campaign")
                dtReport.Rows.Add(reporow)
            End If
            reporow.Item(row("markeddate").ToString.Substring(4)) = row("markedas")
        Next

        GdAttendance.DataSource = dtReport
        GdAttendance.DataBind()
        dtReport = Nothing
        'GdAttendance.Columns(0).Visible = False
    End Sub
    Protected Sub ucDateFrom_Changed(ByVal sender As Object, ByVal e As System.EventArgs) Handles ucDateFrom.Changed
        fillgrid()
    End Sub

    Protected Sub UcDateTo_Changed(ByVal sender As Object, ByVal e As System.EventArgs) Handles UcDateTo.Changed
        fillgrid()
    End Sub

    Protected Sub ImageButton1_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton1.Click
        fillgrid()
        GridViewExportUtil.Export(breadcrumbs.CurrentPage & ".xls", Me.GdAttendance)
    End Sub
    Protected Sub CboProcess_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles CboProcess.SelectedIndexChanged
        Common.FillCampaigns(cboCampaigns, AgentID, CboProcess.SelectedValue)
        fillgrid()
    End Sub

    Protected Sub cboCampaigns_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboCampaigns.SelectedIndexChanged
        fillgrid()
    End Sub

    Protected Sub CboPeriod_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles CboPeriod.SelectedIndexChanged
        If CboPeriod.SelectedValue = 10 Then
            ucDateFrom.Visible = True
            UcDateTo.Visible = True
            lblAnd.Visible = True
            fillgrid()
        Else
            ucDateFrom.Visible = False
            UcDateTo.Visible = False
            lblAnd.Visible = False
            fillgrid()
        End If
    End Sub
    Private Function IntegerToDateString(ByVal d As Integer) As String
        Return d.ToString.Substring(0, 4) & "-" & d.ToString.Substring(4, 2) & "-" & d.ToString.Substring(6, 2)
    End Function
#Region "Utility"

    Private Sub AlertMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMFail"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub

    Private Sub SuccessMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMSuccess"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub
    Private Sub HideMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMSuccess"
        HumanMessage.Style.Item("visibility") = "hidden"
    End Sub

#End Region

    Protected Sub btnRefresh_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnRefresh.Click
        fillgrid()
    End Sub

    Protected Sub imgfav_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles imgfav.Click
        Common.AddToFav(AgentID, "Attendance Register")
        SuccessMessage("Report has been added to your favourite list")
        fillgrid()
    End Sub
End Class
