﻿using Microsoft.VisualBasic;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using com.nss.DBAccess;
using System.Data.SqlClient;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Web;
using System.Web.Script.Serialization;

public partial class Staffing_OpenFillTTCTravelForm : System.Web.UI.Page
{
    string supervisorid { get; set; }

    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["UserID"] == null)
        {
            if (User.Identity.Name.ToString().Contains("NSS\\"))
            {
                Session["Lanid"] = User.Identity.Name.ToString().Replace("NSS\\", "");
            }
            else
            {
                Session["Lanid"] = User.Identity.Name;
            }
            com.nss.DBAccess.DBAccess db = new com.nss.DBAccess.DBAccess();
            db.slDataAdd("UserId", Session["Lanid"]);
            System.Data.DataRow dr = db.ReturnRow("usp_CheckTermsUser", true);
            db = null;
            if (dr == null)
            {
                Response.Write("There is some problem in authenticating your credentials. Please make sure you are authorized to use this website.");
                return;
            }
            Session["CampaignID"] = dr["campaignid"];
            Session["AgentID"] = dr["AgentID"];
            Session["UserID"] = dr["AgentID"];
            Session["username"] = dr["AgentName"];
            Session["IsVerifier"] = dr["btVerifier"];
            Response.Write(Session["username"]);
            Response.Write(Session["Lanid"]);
            supervisorid = string.Empty;
            

        }
        HumanMessage.Style["visibility"] = "hidden";
        HumanMessage.Visible = false;
        if (!IsPostBack)
        {
            OpenTTCTravelform(); 
    
            lblReportName.CurrentPage = "TTC Travel Form";
             
        }
       
        
    }

    
    
    

    private void AlertMessage(string msg)
    {
        try
        {
            lblHumanMessage.Text = msg;
            HumanMessage.CssClass = "HMFail";
            HumanMessage.Visible = true;
            lblHumanMessage.Visible = true;
            HumanMessage.Style["visibility"] = "visible";
        }
        catch (Exception ex)
        {
 
        }
        

    }

    private void SuccessMessage(string msg)
    {
        try
        {
            lblHumanMessage.Text = msg;
            HumanMessage.CssClass = "HMSuccess";
            HumanMessage.Visible = true;
            lblHumanMessage.Visible = true;
            HumanMessage.Style["visibility"] = "visible";
        }
        catch (Exception ex)
        {
 
        }

    }


    ////Get Agent Record In GridView
    public void OpenTTCTravelform()
    {
        try
        {


            DBAccess db = new DBAccess("Leads");
            DataSet ds = new DataSet();

            ds = db.ReturnDataset("usp_OpenTTCTravelForm", true);
            if (ds.Tables[0].Rows.Count > 0)
            {
                PanlEmployeeGrid.Visible = true;
                gdData.DataSource = ds;
                gdData.DataBind();
                gdData.Visible = true;


            }
            else
            {
                PanlEmployeeGrid.Visible = false;
                gdData.Visible = false;
            }



        }
        catch (Exception ex)
        {
            ex.ToString();

        }
    }
    protected void OnPaging(object sender, GridViewPageEventArgs e)
    {
        try
        {


            DBAccess db = new DBAccess("Leads");
            DataSet ds = new DataSet();

            ds = db.ReturnDataset("usp_OpenTTCTravelForm", true);
            if (ds.Tables[0].Rows.Count > 0)
            {
                PanlEmployeeGrid.Visible = true;
                gdData.DataSource = ds;
                gdData.PageIndex = e.NewPageIndex;
                gdData.DataBind();
                gdData.Visible = true;


            }
            else
            {
                PanlEmployeeGrid.Visible = false;
                gdData.Visible = false;
            }



        }
        catch (Exception ex)
        {
            ex.ToString();

        }

    }

    
    //////Insert and Initiate the Role Change Request
    DBAccess db;
    public void Savedetails(string AgentId)
    {
         db = new DBAccess("Leads");
        DataTable dt = new DataTable();
        try
        {


            if (Session["username"].ToString() != "")
            {

                db.slDataAdd("Id", HdId.Value);
                db.slDataAdd("CustomerName", txtCustName.Text);
                db.slDataAdd("Address1", tbxAddress1.Text);
                db.slDataAdd("Address2", tbxAddress2.Text);
                db.slDataAdd("Address3", tbxAddress3.Text);
                db.slDataAdd("Town", tbxtown.Text);
                db.slDataAdd("County", tbxCountry.Text);
                db.slDataAdd("Postcode", tbxPostCode.Text);
                db.slDataAdd("TelephoneNumber", txtPhoneNo.Text);
                db.slDataAdd("HolidayType", tbxHolidayType.Text);
                db.slDataAdd("BudgetRange", tbxBudgetRange.Text);
                db.slDataAdd("EmailID", tbxEmailID.Text);
                db.slDataAdd("AlternatePhoneNo", tbxAltphoneno.Text);
                db.slDataAdd("GEO", DDLGEO.SelectedValue);
                db.slDataAdd("AgeGroup", tbxAgegroup.Text);
                db.slDataAdd("Gender", DDLGender.SelectedValue);
                db.slDataAdd("PotentialTrip", tbxPotentialTrip.Text);
                db.slDataAdd("TripType", DDLTripType.SelectedValue);
                db.slDataAdd("TripValue", tbxtripValue.Text);
                db.slDataAdd("Followupdate", Convert.ToDateTime(tbxFollowDate.Text));
                db.slDataAdd("DispositionType", DDLDispositionType.SelectedValue);
                db.slDataAdd("PaymentStatus", DDLPaymentStatus.SelectedValue);
                db.slDataAdd("Comments", tbxComments.Text);
                db.slDataAdd("Comments1", "");
                db.slDataAdd("Assignee", "");
                db.slDataAdd("Status", "");
                db.slDataAdd("EmpID", Session["username"].ToString());
                db.slDataAdd("UserName", Session["username"].ToString());
                db.slDataAdd("Timestamp", System.DateTime.Now);

                db.slDataAdd("UserID", Session["AgentID"].ToString());
                db.slDataAdd("CampaignID", Session["CampaignID"].ToString());
               


                 db.Executeproc("[dbo].[usp_Update_TTCTravelForm]");


                      
                      
                    
                SuccessMessage("Data Updated Successfully ");
                db = null;
              
                OpenTTCTravelform(); 
                

            }
            else
            {

                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('User Session has Expired Please login!')", true);

            }


            Getdata(HdId.Value);

            popup.Hide();
        }
        catch (Exception ex)
        {
            AlertMessage(ex.Message);

        }


    }

    // Get Agent Record On POP UP
    public void Getdata3(string Phoneno)
    {
        db = new DBAccess("Leads");
        DataTable dt = new DataTable();
        DataSet ds = new DataSet();
        try
        {


            db.slDataAdd("Phoneno", Phoneno);

            dt = db.ReturnTable("usp_OpenTTCTravelFormPhoneNo", "", true);
            //ds = dt.Rows;
            if (dt.Rows.Count > 0)
            {

                PanlEmployeeGrid.Visible = true;
                gdData.DataSource = dt;
                gdData.DataBind();
                gdData.Visible = true;


            }
            else
            {
                PanlEmployeeGrid.Visible = false;
                gdData.Visible = false;
            }

        }
        catch (Exception e)
        {
        }
    }
  

    // Get Agent Record On POP UP
    public void Getdata2(string Id)
    {
        db = new DBAccess("Leads");
        DataTable dt = new DataTable();
        DataSet ds = new DataSet();
        try
        {


            db.slDataAdd("Id", Id);

            dt = db.ReturnTable("usp_OpenTTCTravelFormId", "", true);
            //ds = dt.Rows;
            if (dt.Rows.Count > 0)
            {

           PanlEmployeeGrid.Visible = true;
                gdData.DataSource = dt;
                gdData.DataBind();
                gdData.Visible = true;


            }
            else
            {
                PanlEmployeeGrid.Visible = false;
                gdData.Visible = false;
            }     
        
        }
        catch (Exception e)
        {
        }
    }
    
    // Get Agent Record On POP UP
    public void Getdata(string Id)
    {
         db = new DBAccess("Leads");
        DataTable dt = new DataTable();
        DataSet ds = new DataSet();
        try
        {


            db.slDataAdd("Id", Id);

            dt = db.ReturnTable("usp_OpenTTCTravelFormId", "", true);
            //ds = dt.Rows;
            if (dt.Rows.Count > 0)
            {

                txtPhoneNo.Text = dt.Rows[0]["Telephone Number"].ToString();
                txtCustName.Text = dt.Rows[0]["CustomerName"].ToString();

                tbxAddress1.Text = dt.Rows[0]["Address1"].ToString();
                tbxAddress2.Text = dt.Rows[0]["Address2"].ToString();
                tbxAddress3.Text = dt.Rows[0]["Address3"].ToString();
                DDLGEO.SelectedValue = dt.Rows[0]["GEO"].ToString();

                tbxtown.Text = dt.Rows[0]["Town"].ToString();
                tbxCountry.Text = dt.Rows[0]["County"].ToString();
                tbxPostCode.Text = dt.Rows[0]["Postcode"].ToString();
                tbxHolidayType.Text = dt.Rows[0]["HolidayType"].ToString();
                tbxBudgetRange.Text = dt.Rows[0]["BudgetRange"].ToString();

                tbxAgegroup.Text = dt.Rows[0]["AgeGroup"].ToString();
                tbxEmailID.Text = dt.Rows[0]["EmailID"].ToString();
                
                tbxAltphoneno.Text = dt.Rows[0]["AlternatePhoneNo"].ToString();
                DDLGEO.SelectedValue = dt.Rows[0]["GEO"].ToString();

                
                DDLGender.SelectedValue = dt.Rows[0]["Gender"].ToString();
                tbxPotentialTrip.Text = dt.Rows[0]["PotentialTrip"].ToString();
                DDLTripType.SelectedValue = dt.Rows[0]["TripType"].ToString();
                tbxtripValue.Text = dt.Rows[0]["TripValue"].ToString();
                tbxComments.Text = dt.Rows[0]["Comments"].ToString();
                DDLPaymentStatus.SelectedValue = dt.Rows[0]["PaymentStatus"].ToString();




                
               
            }
            

        }
        catch (Exception ex)
        {
           AlertMessage(ex.Message);
 
        }

    }


    


   
    protected void btnSave_Click(object sender, EventArgs e)
    {
        try
        {
            Savedetails(HdId.Value);
            popup.Hide();
        }
        catch (Exception ex)
        { 
        }
       
    }

    protected void BtnCancel_Click(object sender, EventArgs e)
    {
        try
        {
            
            popup.Hide();
            Getdata(HdId.Value);
            
        }
        catch (Exception ex)
        {
 
        }
    }
    //protected void gdData_SelectedIndexChanged(object sender, EventArgs e)
    //{
    //    int index = Convert.ToInt16(gdData.SelectedDataKey.Value);
    //    HdId.Value = index.ToString();
    //        Getdata(HdId.Value);

        

    //}
    protected void btnUpdate_Click(object sender, EventArgs e)
    {
        GridViewRow gvRow = (GridViewRow)(sender as Control).Parent.Parent;
        int index = gvRow.RowIndex;
               popup.Show();
               HdId.Value = ((HiddenField)gdData.Rows[index].FindControl("hdnID")).Value;
                    Getdata(HdId.Value);

    }

    protected void gdData_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        //if (e.Row.RowType == DataControlRowType.DataRow)
        //{
        ////    DataRowView drv = e.Row.DataItem as DataRowView;
        ////    string Id = Convert.ToString(drv["Id"].ToString());
        ////    HdId.Value = Id;
        ////    Getdata(HdId.Value);

        //}
    }

    protected void gdData_RowCommand(object sender, GridViewCommandEventArgs e)
    {
       // try
    //    {
    //        if (e.CommandName == "EditRecord" )
    //        {
    //            popup.Show();
    //            int index = Convert.ToInt32(e.CommandArgument);
    //            HdId.Value = ((HiddenField)gdData.Rows[index].FindControl("hdnID")).Value;
    //            Getdata(HdId.Value);



    //        }

    //    }
    //    catch (Exception ex)
    //    {

    //    }

    }



    private void CovidInfo_Mail_Closed(string sTO = "")
    {
        DBAccess db;

        try
        {
            int srno = 0;
            var strMailBody = "";
            db = new DBAccess("CRM");
            db = null;
            strMailBody += "<html xmlns='http://www.w3.org/1999/xhtml'>";
            strMailBody += "<body style='font-family: Verdana; font-size: .8em'>";
            strMailBody += "Dear " + txtCustName.Text + "," + "<br /><br />";
            strMailBody += "Your online consultation request is now complete. The query stands closed...  <br /> <br />";


            //strMailBody += "<div align='left'>If you are approving authority,";
            //strMailBody += "<a href='" + System.Configuration.ConfigurationManager.AppSettings["LiveServerPath"] + "/Staffing/PendingRoleApproval.aspx'>Click Here To Approve/Reject</a></div>";



            strMailBody += "<br /><br /><hr/>Stay Safe and Healthy !! ";
            strMailBody += "<br /><hr/>Thanks and regards";
            strMailBody += "<br/> Coforge Covid help desk ";
            strMailBody += "</body>";
            strMailBody += "</html>";

            MailService("Coforge Covidcare 24x7 Support", strMailBody, HdId.Value, sTO);
        }
        catch (Exception ex)
        {

        }

    }


    private void CovidInfo_Mail_NoResponse(string sTO = "")
    {
        DBAccess db;

        try
        {
            int srno = 0;
            var strMailBody = "";
            db = new DBAccess("CRM");
            db = null;
            strMailBody += "<html xmlns='http://www.w3.org/1999/xhtml'>";
            strMailBody += "<body style='font-family: Verdana; font-size: .8em'>";
            strMailBody += "Dear " + txtCustName.Text + "," + "<br /><br />";
            strMailBody += "We tried to contact you on the number provided and there was no response. We would contact again shortly..  <br /> <br />";


            strMailBody += "<br /><br /><hr/>Stay Safe and Healthy !! ";
            strMailBody += "<br /><hr/>Thanks and regards";
            strMailBody += "<br/> Coforge Covid help desk ";
            strMailBody += "</body>";
            strMailBody += "</html>";

            MailService("Coforge Covidcare 24x7 Support", strMailBody, HdId.Value, sTO);
        }
        catch (Exception ex)
        {

        }

    }

    private void CovidInfo_Mail(string strTo="")
    {
        DBAccess db;

        try
        {
            int srno = 0;
            var strMailBody = "";
            db = new DBAccess("CRM");
            db = null;
            strMailBody += "<html xmlns='http://www.w3.org/1999/xhtml'>";
            strMailBody += "<body style='font-family: Verdana; font-size: .8em'>";
            strMailBody += "<strong>Thank You for Contacting Coforge Covid Care 24X7  </strong><br /><br />";
            strMailBody += "<table border='1' width='70%' style='border: 1px solid; border-collapse: collapse; font-family: Verdana; font-size: .8em'>";
            strMailBody += "<tr>";
            strMailBody += "<td align='center'><b>Sr. No.</b></td>";
            strMailBody += "<td align='center'><b>Employee Code</b></td>";
            strMailBody += "<td align='center'><b>Employee Name</b></td>";
            strMailBody += "<td align='center'><b>Email ID</b></td>";
            strMailBody += "</tr>";


            foreach (GridViewRow dgRow in gdData.Rows)
            {
                srno = srno + 1;

                db = new DBAccess("CRM");
                db = null;
                strMailBody += "<tr>";
                strMailBody += "<td align='center'>" + srno + "</td>";
                strMailBody += "<td align='center'>" + HdId.Value + "</td>";
                strMailBody += "<td align='center'>" + txtCustName.Text + "</td>";
                strMailBody += "<td align='center'>" + tbxEmailID.Text + "</td>";


             strMailBody += "</tr>";

            }
            strMailBody += "</table><br/><br />";

            strMailBody += "<p>";
            strMailBody += "This is an Acknowledgement Mail from Coforge Covidcare 24x7 Support";
            strMailBody += "</p>";

         
            strMailBody += "<br /><br /><hr/>This mail was sent using the ";
            strMailBody += "<a href='" + System.Configuration.ConfigurationManager.AppSettings["LiveServerPath"] + "'>TermsMonitor&reg;</a> Mail Service.We request you not to reply this message.";
            strMailBody += "<br />This e-mail is confidential and may also be privileged.If you are not the intended recipient, please notify Covid helpdesk immediately; you should not copy or use it for any purpose,nor disclose its contents to any other person.";
            strMailBody += "</body>";
            strMailBody += "</html>";

            MailService("Coforge Covidcare 24x7 Support", strMailBody, HdId.Value,strTo);
        }
        catch (Exception ex)
        {

        }

    }


    private void MailService(string Subject, string MailBody, string Agent_ID ,string sTo="")
    {
        try
        {
            //DBAccess db = new DBAccess("CRM");
            //DataTable dt = new DataTable();
            //db.slDataAdd("AgentId", Agent_ID);
            //dt = db.ReturnTable("usp_SupervisorEmails", null, true);
            //db = null;

            MailSendServiceXX.Service1SoapClient objWSMail = new MailSendServiceXX.Service1SoapClient();

            //string strTo = dt.Rows[0]["MailTo"].ToString().Replace("Techclearance@coforge.com", "HROperations@coforge.com");            
            //string strCC = dt.Rows[0]["MailCC"].ToString();
            //string strBcc = dt.Rows[0]["MailBCC"].ToString();
            //int index = strCC.IndexOf(",");
            //string strCCMail = strCC.Remove(index, 1);
            string strBcc = System.Configuration.ConfigurationManager.AppSettings["BCC"];
            string strTo = "";
            if (sTo != "")
                strTo = sTo;
            else
            strTo= tbxEmailID.Text;
            string strFrom = System.Configuration.ConfigurationManager.AppSettings["CovidCare"];
            //Need to Be UnComment/Comment Whenever Required
            //objWSMail.MailSendNewTech(strTo, Subject, strFrom, "TermsMonitor", MailBody, "", strCC, strBcc, "");
            objWSMail.MailSendNewTech(strTo, Subject, strFrom, "Coforge Covid Care", MailBody, "", "", strBcc, "");


            objWSMail = null;
        }
        catch (Exception ex)
        {
            //ex.Message.ToString();
            AlertMessage("Valid Email ID is not existing");

        }
    }

    protected void ddlFilter_SelectedIndexChanged(object sender, EventArgs e)
    {

        txtByReqId.Text = "";
        if (ddlFilter.SelectedValue == "1")
        {
            PanlReqId.Visible = true;
          
        }
    }

    protected void BtnSearch_Click(object sender, EventArgs e)
    {
        if (ddlFilter.SelectedValue == "0")
        {
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Select Filter To Search Accordingly!!')", true);

        }
        else if (ddlFilter.SelectedValue == "1")
        {
            if (txtByReqId.Text == "")
            {
                OpenTTCTravelform();
            

                lblReportName.CurrentPage = "TTC Travel Form";
                          
            }
            else
            {
                Getdata3( txtByReqId.Text);
            }

        }
        
        else
        {
            //BindClientWise(txtpanlLicenseKey.Text, txtClientName.Text, txtFromDate.Text, txtTodate.Text, txtByReqId.Text);
        }

    }

    protected void gdData_RowEditing(object sender, GridViewEditEventArgs e)
    {
        //try
        //{
        //    if (e.CommandName == "EditRecord")
        //    {
        //        popup.Show();
        //        int index = Convert.ToInt32(e.CommandArgument);
        //        HdId.Value = ((HiddenField)gdData.Rows[index].FindControl("hdnID")).Value;
        //        Getdata(HdId.Value);



        //    }

        //}
        //catch (Exception ex)
        //{

        //}


    }
    protected void gdData_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
}