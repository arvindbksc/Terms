﻿using Microsoft.VisualBasic;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using com.nss.DBAccess;
using System.Data.SqlClient;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Web;
using System.Web.Script.Serialization;

public partial class Staffing_OpenFillCovid : System.Web.UI.Page
{
    string supervisorid { get; set; }

    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["UserID"] == null)
        {
            if (User.Identity.Name.ToString().Contains("NSS\\"))
            {
                Session["Lanid"] = User.Identity.Name.ToString().Replace("NSS\\", "");
            }
            else
            {
                Session["Lanid"] = User.Identity.Name;
            }
            com.nss.DBAccess.DBAccess db = new com.nss.DBAccess.DBAccess();
            db.slDataAdd("UserId", Session["Lanid"]);
            System.Data.DataRow dr = db.ReturnRow("usp_CheckTermsUser", true);
            db = null;
            if (dr == null)
            {
                Response.Write("There is some problem in authenticating your credentials. Please make sure you are authorized to use this website.");
                return;
            }
            Session["CampaignID"] = dr["campaignid"];
            Session["AgentID"] = dr["AgentID"];
            Session["UserID"] = dr["AgentID"];
            Session["username"] = dr["AgentName"];
            Session["IsVerifier"] = dr["btVerifier"];
            Response.Write(Session["username"]);
            Response.Write(Session["Lanid"]);
            supervisorid = string.Empty;
            

        }
        HumanMessage.Style["visibility"] = "hidden";
        HumanMessage.Visible = false;
        if (!IsPostBack)
        {
            OpenCovidEmployeeLog(); 
    
            lblReportName.CurrentPage = "Covid HelpLine";
            ddlReasonforCall.SelectedIndex = 0;
            ddlSymptomsType.SelectedIndex= 0;
            ddlFinaloutCome.SelectedIndex = 0;
            ddlUrgentRequired.SelectedIndex = 0;
                //GetCovidSymptoms();
             
        }
       
        
    }

    protected void ddlUrgentRequired_SelectedIndexChanged(object sender, EventArgs e)
    {
        popup.Show();
        if (ddlUrgentRequired.SelectedItem.Value == "1")
        {
            PanlAdditionalInfo.Visible = true;

        }
        else
        {
            PanlAdditionalInfo.Visible = false;

        }
        
    }


    protected void ddlSubReason_SelectedIndexChanged(object sender, EventArgs e)
    {
        popup.Show();
        if (ddlSubReason.SelectedItem.Value == "11")
        {
            PanlUrgentRequired.Visible = true;

        }
        else
        {
            PanlUrgentRequired.Visible = false;

        }
    }


    protected void ddlAffectedPerson_SelectedIndexChanged(object sender, EventArgs e)
    {
        popup.Show();
        if (ddlAffectedPerson.SelectedItem.Value.ToLower() == "teammember" || ddlAffectedPerson.SelectedItem.Value.ToLower() == "familyfriends")
        {
            PanlSecName.Visible = true;

        }
        else
        {
            PanlSecName.Visible = false;

        }

        if (ddlAffectedPerson.SelectedItem.Value.ToLower() == "familyfriends")
        {
            ddlRedirectedTo.SelectedIndex = 6;

        }
     
    }
    
    protected void ddlReasonforCall_SelectedIndexChanged(object sender, EventArgs e)
    {
        popup.Show();
        if (ddlReasonforCall.SelectedItem.Value.ToLower() == "5")
        {
            panlcovidothers.Visible = false;
            panlOthers.Visible = true;
        }
        else
        {
            panlOthers.Visible = false;
            panlcovidothers.Visible = true;
        }

        if (ddlReasonforCall.SelectedItem.Value.ToLower() != "2")
        {
            panlcovidothers.Visible = false;
           
        }
        else
        {
            
            panlcovidothers.Visible = true;
        
        }

          
    }

    protected void ddlTestDone_SelectedIndexChanged(object sender, EventArgs e)
    {
        popup.Show();
        if (ddlTestDone.SelectedValue.ToLower() == "yes")

            PanlTest.Visible = true;

        else
            PanlTest.Visible = false;
          
    }

    protected void ddlFinaloutCome_SelectedIndexChanged(object sender, EventArgs e)
    {
        popup.Show();
        if (ddlFinaloutCome.SelectedValue.ToLower() == "open")

            Panlfollowup.Visible = false;

        else
            Panlfollowup.Visible = true;

    }

    


    private void GetAffectedPerson()
    {
        ddlAffectedPerson.Items.Insert(0, new ListItem("Select Affected Person", "0"));
        ddlAffectedPerson.Items.Add(new ListItem("Other", "Other"));
        ddlAffectedPerson.SelectedValue = "0";

    }

    public void GetCovidSymptoms(object sender, EventArgs e)
    {
        popup.Show();
        
         db = new DBAccess("CRM");
        DataTable dtRole = new DataTable();
        db.slDataAdd("symptoms_ID", ddlSymptomsType.SelectedValue);
        dtRole = db.ReturnTable("usp_GetCovidSymptoms", "", true);
        chklstSymptoms.DataSource = dtRole;
        chklstSymptoms.DataTextField = "symptoms";
        chklstSymptoms.DataValueField = "id";
        chklstSymptoms.DataBind();
        //ddlSymptoms.SelectedValue = "0";

        
      
    }
    
    
    

    private void AlertMessage(string msg)
    {
        try
        {
            lblHumanMessage.Text = msg;
            HumanMessage.CssClass = "HMFail";
            HumanMessage.Visible = true;
            lblHumanMessage.Visible = true;
            HumanMessage.Style["visibility"] = "visible";
        }
        catch (Exception ex)
        {
 
        }
        

    }

    private void SuccessMessage(string msg)
    {
        try
        {
            lblHumanMessage.Text = msg;
            HumanMessage.CssClass = "HMSuccess";
            HumanMessage.Visible = true;
            lblHumanMessage.Visible = true;
            HumanMessage.Style["visibility"] = "visible";
        }
        catch (Exception ex)
        {
 
        }

    }


    //[System.Web.Script.Services.ScriptMethod(UseHttpGet = true)]
    //[System.Web.Services.WebMethod]
    //public static string OpenCovidEmployeeLog()
    //{
    //    //string str = string.Empty;
    //    DBAccess db = new DBAccess("CRM");
    //    //db.slDataAdd("Filter", "HistoryDashBoard");
    //    DataTable dt = new DataTable();
    //    dt = db.ReturnTable("usp_OpenCovidEmployeeLog2", "", true);
    //    JavaScriptSerializer serializer = new JavaScriptSerializer();
    //    List<Dictionary<string, object>> rows = new List<Dictionary<string, object>>();
    //    Dictionary<string, object> row;

    //    foreach (DataRow dr in dt.Rows)
    //    {
    //        row = new Dictionary<string, object>();
    //        foreach (DataColumn col in dt.Columns)
    //        {
    //            row.Add(col.ColumnName, dr[col]);
    //        }
    //        rows.Add(row);
    //    }

    //    string str = serializer.Serialize(rows);
    //    return str;

    //}

    ////Get Agent Record In GridView
    public void OpenCovidEmployeeLog()
    {
        try
        {


            DBAccess db = new DBAccess("CRM");
            DataSet ds = new DataSet();

            ds = db.ReturnDataset("usp_OpenCovidEmployeeLog2", true);
            if (ds.Tables[0].Rows.Count > 0)
            {
                PanlEmployeeGrid.Visible = true;
                gdData.DataSource = ds;
                gdData.DataBind();
                gdData.Visible = true;


            }
            else
            {
                PanlEmployeeGrid.Visible = false;
                gdData.Visible = false;
            }



        }
        catch (Exception ex)
        {
            ex.ToString();

        }
    }
    protected void OnPaging(object sender, GridViewPageEventArgs e)
    {
        try
        {


            DBAccess db = new DBAccess("CRM");
            DataSet ds = new DataSet();

            ds = db.ReturnDataset("usp_OpenCovidEmployeeLog2", true);
            if (ds.Tables[0].Rows.Count > 0)
            {
                PanlEmployeeGrid.Visible = true;
                gdData.DataSource = ds;
                gdData.PageIndex = e.NewPageIndex;
                gdData.DataBind();
                gdData.Visible = true;


            }
            else
            {
                PanlEmployeeGrid.Visible = false;
                gdData.Visible = false;
            }



        }
        catch (Exception ex)
        {
            ex.ToString();

        }

    }

    
    //////Insert and Initiate the Role Change Request
    DBAccess db;
    public void Savedetails(string AgentId)
    {
         db = new DBAccess("CRM");
        DataTable dt = new DataTable();
        try
        {


            if (Session["username"].ToString() != "")
            {

                db.slDataAdd("Id", HdId.Value);
                db.slDataAdd("PersNo", txtEmpID.Text);
                db.slDataAdd("Name", txtName.Text);
                db.slDataAdd("Address", tbxLocation.Text);
                db.slDataAdd("Phone", tbxphoneno.Text);
                db.slDataAdd("Supervisor", tbxSupervisor.Text);
                db.slDataAdd("UserName", Session["username"].ToString());
                db.slDataAdd("AffectedPerson", ddlAffectedPerson.SelectedItem.Text);
                db.slDataAdd("SecName", tbxSecondaryName.Text);

                      db.slDataAdd("ReasonForCall", ddlReasonforCall.SelectedValue);
                      db.slDataAdd("Others", tbxOthers.Text);
                      db.slDataAdd("Symptoms_Type", ddlSymptomsType.SelectedValue);

                      string strsymptoms = "";
                      for (int i = 0; i < chklstSymptoms.Items.Count; i++)
                      {
                          if (chklstSymptoms.Items[i].Selected)
                          {

                              strsymptoms = strsymptoms + chklstSymptoms.Items[i].Text + ",";
                          }

                      }

                if (strsymptoms.Length >0)
                      db.slDataAdd("Symptoms_IDs", strsymptoms.Substring(0, (strsymptoms.Length - 1)));
                else
                    db.slDataAdd("Symptoms_IDs", strsymptoms);

                      db.slDataAdd("TestDone", ddlTestDone.SelectedItem.Text);
                      db.slDataAdd("TestType", ddlTestType.SelectedItem.Text);



                      //if (ddlReasonforCall.SelectedValue == "0")
                      //{
                      //    AlertMessage("Please Select Valid Reason Call  Option !!");
                      //    return;
                      //}

                      //if (ddlSubReason.SelectedValue == "0")
                      //{
                      //    AlertMessage("Please Select Valid Sub Reason Option !!");
                      //    return;
                      //}



                      //if (ddlRedirectedTo.SelectedValue == "0")
                      //{
                      //    AlertMessage("Please Select Valid Redirceted Option !!");
                      //    return;
                      //}

                      //if (ddlUrgentRequired.SelectedValue == "0")
                      //{
                      //    AlertMessage("Please Select Valid Urgent Required Option !!");
                      //    return;
                      //}



                      ////Covid Related, Insurance and Special Assistance
                      //if (ddlReasonforCall.SelectedItem.Value.ToLower() == "2" || ddlReasonforCall.SelectedItem.Value.ToLower() == "3" || ddlReasonforCall.SelectedItem.Value.ToLower() == "4")
                      //{
                      //    // ddlSubReason.SelectedIndex = ddlReasonforCall.Items.IndexOf(ddlReasonforCall.Items.FindByValue("2"));


                      //    if (ddlSubReason.SelectedValue == "0")
                      //    {
                      //        AlertMessage("Please Select Valid Sub Reason !!");
                      //        return;
                      //    }

                      //}
                    

                      db.slDataAdd("SubReason", ddlSubReason.SelectedValue);
                      db.slDataAdd("TestConductedOn",  Convert.ToDateTime( txtDate.Text));
                      db.slDataAdd("ReportStatus", ddlReportStatus.SelectedItem.Text);
                      db.slDataAdd("Comments", tbxIssueComment.Text);
                      db.slDataAdd("RedirectedTo", ddlRedirectedTo.SelectedItem.Text);
                      db.slDataAdd("FinalOutCome", ddlFinaloutCome.SelectedItem.Value);
                      db.slDataAdd("Followup", tbxfollowup.Text);
                      db.slDataAdd("UrgentRequired", ddlUrgentRequired.SelectedItem.Value);
                      db.slDataAdd("AdditionalInfo", Tbxfever.Text);
                      db.slDataAdd("AdditionalInfo2", TbxO2Level.Text);




                      db.Executeproc("[dbo].[usp_Update_Employee_CovidData2]");


                      //if (((ddlSubReason.SelectedValue.ToString() == "1") || (ddlSubReason.SelectedValue.ToString() == "2") || (ddlSubReason.SelectedValue.ToString() == "3") || (ddlSubReason.SelectedValue.ToString() == "4") || (ddlSubReason.SelectedValue.ToString() == "5") || (ddlSubReason.SelectedValue.ToString() == "6") || (ddlSubReason.SelectedValue.ToString() == "7") || (ddlSubReason.SelectedValue.ToString() == "8") || (ddlSubReason.SelectedValue.ToString() == "9") || (ddlSubReason.SelectedValue.ToString() == "10") || (ddlSubReason.SelectedValue.ToString() == "11") || (ddlSubReason.SelectedValue.ToString() == "12") || (ddlSubReason.SelectedValue.ToString() == "13") || (ddlSubReason.SelectedValue.ToString() == "14") || (ddlSubReason.SelectedValue.ToString() == "15") || (ddlSubReason.SelectedValue.ToString() == "16")) && ((ddlFinaloutCome.SelectedItem.Text == "Open")))
                      //{
                      //    CovidInfo_Mail( "");
                      //}

                             //Covid Related and Special Assistance
                      if (ddlReasonforCall.SelectedItem.Value.ToLower() == "2" || ddlReasonforCall.SelectedItem.Value.ToLower() == "4")
                      {

                          //Docto Consultation
                          if (ddlSubReason.SelectedValue.ToString() == "11")
                          {
                              // ddlSubReason.SelectedIndex = ddlReasonforCall.Items.IndexOf(ddlReasonforCall.Items.FindByValue("2"));
                              if (ddlFinaloutCome.SelectedItem.Value == "NORESPONSE")
                              {
                                  CovidInfo_Mail_NoResponse("");
                              }
                              else if  (ddlFinaloutCome.SelectedItem.Value == "Closed")
                              {
                                  CovidInfo_Mail_Closed("");
                              }

                          }
                      }

                    
                SuccessMessage("Data Updated Successfully ");
                db = null;
              
                OpenCovidEmployeeLog(); 
                

            }
            else
            {

                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('User Session has Expired Please login!')", true);

            }


            Getdata(HdId.Value);

            popup.Hide();
        }
        catch (Exception ex)
        {
            AlertMessage(ex.Message);

        }


    }

    // Get Agent Record On POP UP
    public void Getdata2(string Id)
    {
        db = new DBAccess("CRM");
        DataTable dt = new DataTable();
        DataSet ds = new DataSet();
        try
        {


            db.slDataAdd("Id", Id);

            dt = db.ReturnTable("usp_OpenCovidEmployeeIdLog2", "", true);
            //ds = dt.Rows;
            if (dt.Rows.Count > 0)
            {

           PanlEmployeeGrid.Visible = true;
                gdData.DataSource = dt;
                gdData.DataBind();
                gdData.Visible = true;


            }
            else
            {
                PanlEmployeeGrid.Visible = false;
                gdData.Visible = false;
            }     
        
        }
        catch (Exception e)
        {
        }
    }
    
    // Get Agent Record On POP UP
    public void Getdata(string Id)
    {
         db = new DBAccess("CRM");
        DataTable dt = new DataTable();
        DataSet ds = new DataSet();
        try
        {


            db.slDataAdd("Id", Id);

            dt = db.ReturnTable("usp_OpenCovidEmployeeIdLog2", "", true);
            //ds = dt.Rows;
            if (dt.Rows.Count > 0)
            {
                txtEmpID.Text = dt.Rows[0]["PersNo"].ToString();
                txtName.Text = dt.Rows[0]["Name"].ToString();
             
                tbxLocation.Text = dt.Rows[0]["PSADesc"].ToString();
                tbxEmailInfo.Text = dt.Rows[0]["EmailID"].ToString();
                tbxphoneno.Text = dt.Rows[0]["Phone"].ToString();
                tbxSupervisor.Text = dt.Rows[0]["Supervisor"].ToString();
                ddlAffectedPerson.SelectedItem.Text = dt.Rows[0]["AffectedPerson"].ToString();
                tbxSecondaryName.Text = dt.Rows[0]["SecondayName"].ToString();
                ddlReasonforCall.SelectedValue = dt.Rows[0]["ReasonForCall"].ToString();
                tbxOthers.Text = dt.Rows[0]["Others"].ToString();
                ddlSymptomsType.SelectedValue = dt.Rows[0]["Symptoms_Type"].ToString();
                
                DataTable dtRole = new DataTable();
                db.slDataAdd("symptoms_ID", ddlSymptomsType.SelectedValue);
                dtRole = db.ReturnTable("usp_GetCovidSymptoms", "", true);
                chklstSymptoms.DataSource = dtRole;
                chklstSymptoms.DataTextField = "symptoms";
                chklstSymptoms.DataValueField = "id";
                 chklstSymptoms.DataBind();
        

                      for (int i = 0; i < dtRole.Rows.Count; i++)
                      {
                         
                          chklstSymptoms.Items[i].Selected = true;
                         
                      }
               
               
                ddlTestDone.SelectedItem.Text = dt.Rows[0]["TestDone"].ToString();
                ddlTestType.SelectedItem.Text = dt.Rows[0]["TestType"].ToString();
                ddlSubReason.SelectedValue = dt.Rows[0]["SubReason"].ToString();
               // txtDate.Text = dt.Rows[0]["TestConductedOn"].ToString();

                ddlReportStatus.SelectedItem.Text = dt.Rows[0]["ReportStatus"].ToString();
                tbxIssueComment.Text = dt.Rows[0]["Comments"].ToString();
                ddlRedirectedTo.SelectedItem.Text = dt.Rows[0]["RedirectedTo"].ToString();
                ddlFinaloutCome.SelectedItem.Value = dt.Rows[0]["FinalOutCome"].ToString();
                
                tbxfollowup.Text = dt.Rows[0]["Followup"].ToString();
                ddlUrgentRequired.SelectedItem.Value = dt.Rows[0]["UrgentRequired"].ToString();
                Tbxfever.Text = dt.Rows[0]["AdditionalInfo"].ToString();
                TbxO2Level.Text = dt.Rows[0]["AdditionalInfo2"].ToString();
               
            }
            

        }
        catch (Exception ex)
        {
           AlertMessage(ex.Message);
 
        }

    }


    


   
    protected void btnSave_Click(object sender, EventArgs e)
    {
        try
        {
            Savedetails(HdId.Value);
            popup.Hide();
        }
        catch (Exception ex)
        { 
        }
       
    }

    protected void BtnCancel_Click(object sender, EventArgs e)
    {
        try
        {
            
            popup.Hide();
            Getdata(HdId.Value);
            
        }
        catch (Exception ex)
        {
 
        }
    }
    //protected void gdData_SelectedIndexChanged(object sender, EventArgs e)
    //{
    //    int index = Convert.ToInt16(gdData.SelectedDataKey.Value);
    //    HdId.Value = index.ToString();
    //        Getdata(HdId.Value);

        

    //}
    protected void btnUpdate_Click(object sender, EventArgs e)
    {
        GridViewRow gvRow = (GridViewRow)(sender as Control).Parent.Parent;
        int index = gvRow.RowIndex;
               popup.Show();
               HdId.Value = ((HiddenField)gdData.Rows[index].FindControl("hdnID")).Value;
                    Getdata(HdId.Value);

    }

    protected void gdData_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        //if (e.Row.RowType == DataControlRowType.DataRow)
        //{
        ////    DataRowView drv = e.Row.DataItem as DataRowView;
        ////    string Id = Convert.ToString(drv["Id"].ToString());
        ////    HdId.Value = Id;
        ////    Getdata(HdId.Value);

        //}
    }

    protected void gdData_RowCommand(object sender, GridViewCommandEventArgs e)
    {
       // try
    //    {
    //        if (e.CommandName == "EditRecord" )
    //        {
    //            popup.Show();
    //            int index = Convert.ToInt32(e.CommandArgument);
    //            HdId.Value = ((HiddenField)gdData.Rows[index].FindControl("hdnID")).Value;
    //            Getdata(HdId.Value);



    //        }

    //    }
    //    catch (Exception ex)
    //    {

    //    }

    }



    private void CovidInfo_Mail_Closed(string sTO = "")
    {
        DBAccess db;

        try
        {
            int srno = 0;
            var strMailBody = "";
            db = new DBAccess("CRM");
            db = null;
            strMailBody += "<html xmlns='http://www.w3.org/1999/xhtml'>";
            strMailBody += "<body style='font-family: Verdana; font-size: .8em'>";
            strMailBody += "Dear " + txtName.Text + "," + "<br /><br />";
            strMailBody += "Your online consultation request is now complete. The query stands closed...  <br /> <br />";


            //strMailBody += "<div align='left'>If you are approving authority,";
            //strMailBody += "<a href='" + System.Configuration.ConfigurationManager.AppSettings["LiveServerPath"] + "/Staffing/PendingRoleApproval.aspx'>Click Here To Approve/Reject</a></div>";



            strMailBody += "<br /><br /><hr/>Stay Safe and Healthy !! ";
            strMailBody += "<br /><hr/>Thanks and regards";
            strMailBody += "<br/> Coforge Covid help desk ";
            strMailBody += "</body>";
            strMailBody += "</html>";

            MailService("Coforge Covidcare 24x7 Support", strMailBody, HdId.Value, sTO);
        }
        catch (Exception ex)
        {

        }

    }


    private void CovidInfo_Mail_NoResponse(string sTO = "")
    {
        DBAccess db;

        try
        {
            int srno = 0;
            var strMailBody = "";
            db = new DBAccess("CRM");
            db = null;
            strMailBody += "<html xmlns='http://www.w3.org/1999/xhtml'>";
            strMailBody += "<body style='font-family: Verdana; font-size: .8em'>";
            strMailBody += "Dear " + txtName.Text + "," + "<br /><br />";
            strMailBody += "We tried to contact you on the number provided and there was no response. We would contact again shortly..  <br /> <br />";


            strMailBody += "<br /><br /><hr/>Stay Safe and Healthy !! ";
            strMailBody += "<br /><hr/>Thanks and regards";
            strMailBody += "<br/> Coforge Covid help desk ";
            strMailBody += "</body>";
            strMailBody += "</html>";

            MailService("Coforge Covidcare 24x7 Support", strMailBody, HdId.Value, sTO);
        }
        catch (Exception ex)
        {

        }

    }

    private void CovidInfo_Mail(string strTo="")
    {
        DBAccess db;

        try
        {
            int srno = 0;
            var strMailBody = "";
            db = new DBAccess("CRM");
            db = null;
            strMailBody += "<html xmlns='http://www.w3.org/1999/xhtml'>";
            strMailBody += "<body style='font-family: Verdana; font-size: .8em'>";
            strMailBody += "<strong>Thank You for Contacting Coforge Covid Care 24X7  </strong><br /><br />";
            strMailBody += "<table border='1' width='70%' style='border: 1px solid; border-collapse: collapse; font-family: Verdana; font-size: .8em'>";
            strMailBody += "<tr>";
            strMailBody += "<td align='center'><b>Sr. No.</b></td>";
            strMailBody += "<td align='center'><b>Employee Code</b></td>";
            strMailBody += "<td align='center'><b>Employee Name</b></td>";
            strMailBody += "<td align='center'><b>Email ID</b></td>";
            strMailBody += "</tr>";


            foreach (GridViewRow dgRow in gdData.Rows)
            {
                srno = srno + 1;

                db = new DBAccess("CRM");
                db = null;
                strMailBody += "<tr>";
                strMailBody += "<td align='center'>" + srno + "</td>";
                strMailBody += "<td align='center'>" + HdId.Value + "</td>";
                strMailBody += "<td align='center'>" + txtName.Text + "</td>";
                strMailBody += "<td align='center'>" + tbxEmailInfo.Text + "</td>";


             strMailBody += "</tr>";

            }
            strMailBody += "</table><br/><br />";

            strMailBody += "<p>";
            strMailBody += "This is an Acknowledgement Mail from Coforge Covidcare 24x7 Support";
            strMailBody += "</p>";

         
            strMailBody += "<br /><br /><hr/>This mail was sent using the ";
            strMailBody += "<a href='" + System.Configuration.ConfigurationManager.AppSettings["LiveServerPath"] + "'>TermsMonitor&reg;</a> Mail Service.We request you not to reply this message.";
            strMailBody += "<br />This e-mail is confidential and may also be privileged.If you are not the intended recipient, please notify Covid helpdesk immediately; you should not copy or use it for any purpose,nor disclose its contents to any other person.";
            strMailBody += "</body>";
            strMailBody += "</html>";

            MailService("Coforge Covidcare 24x7 Support", strMailBody, HdId.Value,strTo);
        }
        catch (Exception ex)
        {

        }

    }


    private void MailService(string Subject, string MailBody, string Agent_ID ,string sTo="")
    {
        try
        {
            //DBAccess db = new DBAccess("CRM");
            //DataTable dt = new DataTable();
            //db.slDataAdd("AgentId", Agent_ID);
            //dt = db.ReturnTable("usp_SupervisorEmails", null, true);
            //db = null;

            MailSendServiceXX.Service1SoapClient objWSMail = new MailSendServiceXX.Service1SoapClient();

            //string strTo = dt.Rows[0]["MailTo"].ToString().Replace("Techclearance@coforge.com", "HROperations@coforge.com");            
            //string strCC = dt.Rows[0]["MailCC"].ToString();
            //string strBcc = dt.Rows[0]["MailBCC"].ToString();
            //int index = strCC.IndexOf(",");
            //string strCCMail = strCC.Remove(index, 1);
            string strBcc = System.Configuration.ConfigurationManager.AppSettings["BCC"];
            string strTo = "";
            if (sTo != "")
                strTo = sTo;
            else
            strTo= tbxEmailInfo.Text;
            string strFrom = System.Configuration.ConfigurationManager.AppSettings["CovidCare"];
            //Need to Be UnComment/Comment Whenever Required
            //objWSMail.MailSendNewTech(strTo, Subject, strFrom, "TermsMonitor", MailBody, "", strCC, strBcc, "");
            objWSMail.MailSendNewTech(strTo, Subject, strFrom, "Coforge Covid Care", MailBody, "", "", strBcc, "");
            objWSMail = null;
        }
        catch (Exception ex)
        {
            //ex.Message.ToString();
            AlertMessage("Valid Email ID is not existing");

        }
    }

    protected void ddlFilter_SelectedIndexChanged(object sender, EventArgs e)
    {

        txtByReqId.Text = "";
        if (ddlFilter.SelectedValue == "1")
        {
            PanlReqId.Visible = true;
          
        }
    }

    protected void BtnSearch_Click(object sender, EventArgs e)
    {
        if (ddlFilter.SelectedValue == "0")
        {
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Select Filter To Search Accordingly!!')", true);

        }
        else if (ddlFilter.SelectedValue == "1")
        {
            if (txtByReqId.Text == "")
            {
                OpenCovidEmployeeLog();

                lblReportName.CurrentPage = "Covid HelpLine";
                ddlReasonforCall.SelectedIndex = 0;
                ddlSymptomsType.SelectedIndex = 0;
                ddlFinaloutCome.SelectedIndex = 0;
                ddlUrgentRequired.SelectedIndex = 0;
            
            }
            else
            {
                Getdata2( txtByReqId.Text);
            }

        }
        
        else
        {
            //BindClientWise(txtpanlLicenseKey.Text, txtClientName.Text, txtFromDate.Text, txtTodate.Text, txtByReqId.Text);
        }

    }

    protected void gdData_RowEditing(object sender, GridViewEditEventArgs e)
    {
        //try
        //{
        //    if (e.CommandName == "EditRecord")
        //    {
        //        popup.Show();
        //        int index = Convert.ToInt32(e.CommandArgument);
        //        HdId.Value = ((HiddenField)gdData.Rows[index].FindControl("hdnID")).Value;
        //        Getdata(HdId.Value);



        //    }

        //}
        //catch (Exception ex)
        //{

        //}


    }
}