﻿Imports com.nss.DBAccess
Imports System.Data
Partial Class Staffing_Incentive_IncentiveReport
    Inherits System.Web.UI.Page
#Region "Properties"

    Property dtsummary() As DataTable
        Get
            Return ViewState("dtSummary")
        End Get
        Set(ByVal value As DataTable)
            ViewState("dtSummary") = value
        End Set
    End Property
    Property SupervisorID() As String
        Get
            Return ViewState("SupervisorID")
        End Get
        Set(ByVal value As String)
            ViewState("SupervisorID") = value
        End Set
    End Property
    Property TransID() As Integer
        Get
            Return ViewState("TransID")
        End Get
        Set(ByVal value As Integer)
            ViewState("TransID") = value
        End Set
    End Property
    Property UserID() As String
        Get
            Return ViewState("UserID")
        End Get
        Set(ByVal value As String)
            ViewState("UserID") = value
        End Set
    End Property

    Property CampaignID() As Integer
        Get
            Return 0 'ViewState("CampaignID")
        End Get
        Set(ByVal value As Integer)
            'ViewState("CampaignID") = value
            'Session("CampaignID") = value
        End Set
    End Property

    Property ProcessID() As Integer
        Get
            Return ViewState("ProcessID")
        End Get
        Set(ByVal value As Integer)
            ViewState("ProcessID") = value
            Session("ProcessID") = value
        End Set
    End Property
    Property AgentID() As String
        Get
            Return ViewState("AgentID")
        End Get
        Set(ByVal value As String)
            ViewState("AgentID") = value
        End Set
    End Property
    Property Month() As String
        Get
            Return ViewState("Month")
        End Get
        Set(ByVal value As String)
            ViewState("Month") = value
        End Set
    End Property
    Property Year() As Integer
        Get
            Return ViewState("Year")
        End Get
        Set(ByVal value As Integer)
            ViewState("Year") = value
        End Set
    End Property
    Property UsrID() As Integer
        Get
            Return ViewState("UsrID")
        End Get
        Set(ByVal value As Integer)
            ViewState("UsrID") = value
        End Set
    End Property
    Property LoginID() As Integer
        Get
            Return ViewState("LoginID")
        End Get
        Set(ByVal value As Integer)
            ViewState("LoginID") = value
        End Set
    End Property
    Property CurrentDate() As Date
        Get
            Return ViewState("CurrentDate")
        End Get
        Set(ByVal value As Date)
            ViewState("CurrentDate") = value
        End Set
    End Property
    Property IncentiveMonth() As String
        Get
            Return ViewState("IncentiveMonth")
        End Get
        Set(ByVal value As String)
            ViewState("IncentiveMonth") = value
        End Set
    End Property
    Property IncentiveYear() As Integer
        Get
            Return ViewState("IncentiveYear")
        End Get
        Set(ByVal value As Integer)
            ViewState("IncentiveYear") = value
        End Set
    End Property

#End Region
#Region "Data refresh"
    Private Sub LoadData()

        Dim db As New DBAccess("CRM")
        'TODO: change this query to stored procedure
        Dim dr As DataRow = db.ReturnRow("SELECT getdate() as currentdate")
        CurrentDate = dr("currentDate")
        IncentiveMonth = MonthName(DatePart(DateInterval.Month, DateAdd(DateInterval.Month, -1, CurrentDate)))
        IncentiveYear = DatePart(DateInterval.Year, DateAdd(DateInterval.Month, -1, CurrentDate))
        db = Nothing

    End Sub
    Private Sub GetData()
        LoadData()
        Dim db As New DBAccess("CRM")
        'Dim dt As DataTable
        db.slDataAdd("Month", cboMonth.SelectedValue)
        db.slDataAdd("year", cboYear.SelectedValue)
        db.slDataAdd("processid", CboProcess.SelectedValue)
        db.slDataAdd("campaignid", CampaignID)
        dtsummary = db.ReturnTable("[usp_PLIReport4]", , True)
        db = Nothing
        GridView1.DataSource = dtsummary
        GridView1.DataBind()
        'GridView1.Columns(6).Visible = False    ''rajkumar  22-Aug-2014
        'GridView1.Columns(7).Visible = False    ''rajkumar  22-Aug-2014
        'GridView1.Columns(9).Visible = False    ''rajkumar  22-Aug-2014

        'If dtsummary.Rows.Count > 0 Then
        '    If IncentiveMonth <> dtsummary.Rows(0).Item("Month") Or IncentiveYear <> cboYear.SelectedValue Then
        '        GridView1.Columns(GridView1.Columns.Count - 1).Visible = False
        '    Else
        '        GridView1.Columns(GridView1.Columns.Count - 1).Visible = True
        '    End If
        'End If
        ' GridView1.Columns(GridView1.Columns.Count - 2).Visible = False
        'db = New DBAccess("Termsmonitor")
        'UsrID = db.ReturnValue("select usr_id from tbl_workgroup_mst where Dialler_Id='" & SupervisorID & "' and active='Y'", False)
        ' LoginID = db.ReturnValue("select usr_id from tbl_workgroup_mst where Dialler_Id='" & UserID & "' and active='Y'", False)
        ' db = Nothing
        lblreportname.CurrentPage = "Incentive Report for " & cboMonth.SelectedItem.Text & " " & cboYear.SelectedValue
    End Sub
#End Region

#Region "Support functions"
    Private Sub FillProcessCampaigns()
        Common.FillProcessCampaigns(CboProcess, cboCampaigns, AgentID, CampaignID)
        'cboCampaigns.Items.FindByValue(CampaignID).Selected = True

    End Sub

    Private Sub FillMonthYear()
        For ictr = 1 To 12
            cboMonth.Items.Add(New ListItem(MonthName(ictr), ictr))
        Next

        cboMonth.SelectedIndex = cboMonth.Items.IndexOf(cboMonth.Items.FindByValue(DateTime.Now.Month))
        For ictr = DateTime.Now.Year To 2017 Step -1
            cboYear.Items.Add(New ListItem(ictr, ictr))
        Next
        cboYear.SelectedIndex = cboYear.Items.IndexOf(cboYear.Items.FindByValue(DateTime.Now.Year))
    End Sub
#End Region

#Region "Even Handling"

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            If Session("AgentID") <> "" Then
                ProcessID = Session("ProcessID")
                CampaignID = Session("CampaignID")
                AgentID = Session("AgentID")
                SupervisorID = Session("UserID")
                UserID = Session("UserID")
                FillProcessCampaigns()
                FillMonthYear()
                PanelReports.Controls.Add(Common.GetMenu(Request.Url, AgentID, Request.ApplicationPath))
                'FillMenu()
                GetData()
            End If

        End If
    End Sub

    Protected Sub cboCampaigns_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboCampaigns.SelectedIndexChanged
        CampaignID = cboCampaigns.SelectedValue
        GetData()

    End Sub

    Protected Sub CboProcess_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles CboProcess.SelectedIndexChanged
        ProcessID = CboProcess.SelectedValue
        Common.FillCampaigns(cboCampaigns, AgentID, CboProcess.SelectedValue)
        GetData()

    End Sub


    Protected Sub cboYear_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboYear.SelectedIndexChanged
        GetData()

    End Sub

    Protected Sub cboMonth_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboMonth.SelectedIndexChanged
        GetData()

    End Sub

    Protected Sub btnRefresh_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnRefresh.Click
        GetData()

    End Sub
    Protected Sub ImageButton1_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton1.Click
        GetData()
        GridViewExportUtil.Export(lblreportname.CurrentPage & ".xls", Me.GridView1)
    End Sub

#End Region
#Region "gridview Updation"
    Protected Sub GridView1_RowCancelingEdit(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewCancelEditEventArgs) Handles GridView1.RowCancelingEdit
        GridView1.EditIndex = -1
        GetData()
        Dim freeze, Cancel, edit As LinkButton
        freeze = GridView1.Rows(e.RowIndex).FindControl("lnkfreeze")
        Cancel = GridView1.Rows(e.RowIndex).FindControl("lnkcancel")
        edit = GridView1.Rows(e.RowIndex).FindControl("lnkedit")
        freeze.Visible = False
        Cancel.Visible = False
        edit.Visible = True
    End Sub

    'Protected Sub GridView1_RowDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles GridView1.RowDataBound
    '    Dim edit As LinkButton, freeze As Label
    '    For Each row As GridViewRow In GridView1.Rows
    '        If row.RowType = DataControlRowType.DataRow Then
    '            freeze = row.FindControl("lblFreeze")
    '            edit = row.FindControl("lnkedit")
    '            'If freeze.Text = "True" Then
    '            '    edit.Visible = False
    '            'End If
    '        End If
    '    Next

    'End Sub
    Protected Sub GridView1_RowEditing(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewEditEventArgs) Handles GridView1.RowEditing
        GridView1.EditIndex = e.NewEditIndex
        GetData()
        Dim freeze, Cancel, Edit As LinkButton
        freeze = GridView1.Rows(e.NewEditIndex).FindControl("lnkfreeze")
        Cancel = GridView1.Rows(e.NewEditIndex).FindControl("lnkcancel")
        Edit = GridView1.Rows(e.NewEditIndex).FindControl("lnkedit")
        freeze.Visible = True
        Cancel.Visible = True
        Edit.Visible = False
        LblError.Visible = False
        'Dim agentid As String
        'agentid = GridView1.DataKeys(e.NewEditIndex).Item("lblempid")
    End Sub

    Protected Sub GridView1_RowUpdating(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewUpdateEventArgs) Handles GridView1.RowUpdating
        Dim freeze, Cancel, edit As LinkButton

        freeze = GridView1.Rows(e.RowIndex).FindControl("lnkfreeze")
        Cancel = GridView1.Rows(e.RowIndex).FindControl("lnkcancel")
        edit = GridView1.Rows(e.RowIndex).FindControl("lnkedit")
        Dim txt1, txt2, txt3, txt4, txt5, txt6, txt7, txt8 As TextBox, cb1 As DropDownList, lblagentid, lblMonth, lblYear, lblempname As Label

        txt1 = GridView1.Rows(e.RowIndex).FindControl("txtPLI")
        txt2 = GridView1.Rows(e.RowIndex).FindControl("txtQFI")
        txt3 = GridView1.Rows(e.RowIndex).FindControl("txtArrears")
        txt4 = GridView1.Rows(e.RowIndex).FindControl("txtRemarks")
        txt5 = GridView1.Rows(e.RowIndex).FindControl("txtTransport")
        txt6 = GridView1.Rows(e.RowIndex).FindControl("txtRetention")
        txt7 = GridView1.Rows(e.RowIndex).FindControl("txtCovid")
        txt8 = GridView1.Rows(e.RowIndex).FindControl("tbxClientIncentiveAmt")
        cb1 = GridView1.Rows(e.RowIndex).FindControl("cbovc")
        If ValidateControls(txt1.Text, txt2.Text, txt3.Text, txt4.Text, txt5.Text, txt6.Text, cb1.SelectedValue) Then

            lblagentid = GridView1.Rows(e.RowIndex).FindControl("lblempid")
            lblMonth = GridView1.Rows(e.RowIndex).FindControl("lblMonth")
            lblYear = GridView1.Rows(e.RowIndex).FindControl("lblyear")
            lblempname = GridView1.Rows(e.RowIndex).FindControl("lblempname")
            'Dim db As New DBAccess("termsmonitor")
            'db.slDataAdd("UserID", UsrID)
            'db.slDataAdd("supervisorid", SupervisorID)
            'TransID = db.ReturnValue("usp_getTransactionID", True)
            'db = Nothing
            'isUpdatable = CheckForUpdate()           
            Call SaveIncentives(txt1.Text, txt2.Text, txt3.Text, txt4.Text, txt5.Text, txt6.Text, txt7.Text, txt8.Text, cb1.SelectedValue, lblagentid.Text, lblempname.Text, lblMonth.Text, lblYear.Text)
            Call SaveIncentivesLog(txt1.Text, txt2.Text, txt3.Text, txt4.Text, txt5.Text, txt6.Text, txt7.Text, txt8.Text, cb1.SelectedValue, lblagentid.Text, lblempname.Text, lblMonth.Text, lblYear.Text)
            freeze.Visible = False
            Cancel.Visible = False
            edit.Visible = True
            GridView1.EditIndex = -1
            GetData()
            LblError.Visible = False
        End If
        
    End Sub
    Private Sub SaveIncentives(ByVal PLI As String, ByVal QFI As String, ByVal Arrears As String, ByVal remarks As String, ByVal Transport As String, ByVal Retention As String, ByVal Covid As String, clientIncentiveAmt As String, ByVal comtype As Integer, ByVal agentid As String, ByVal agentname As String, ByVal month As String, ByVal year As String)
        Dim dbcampaign As New DBAccess
        Dim CampaignID As Int16 = dbcampaign.ReturnValue("select campaignid from tbl_AgentMaster where AgentID ='" & SupervisorID & "'", False)
        dbcampaign = Nothing
        Dim db As New DBAccess("CRM")

        db.BeginTrans()
        Try
            'db.slDataAdd("TransID", TransID)
            'db.slDataAdd("LoginID", LoginID)
            'db.slDataAdd("UserID", UsrID)
            db.slDataAdd("CampaignID", CampaignID)
            db.slDataAdd("AgentID", agentid)
            db.slDataAdd("AgentName", agentname)
            db.slDataAdd("PLIAmount", PLI)
            db.slDataAdd("QFIAmount", QFI)
            db.slDataAdd("TransportAmount", Transport)
            db.slDataAdd("RetentionAmount", Retention)
            db.slDataAdd("CovidAmount", Covid)
            db.slDataAdd("ClientIncentiveAmt", clientIncentiveAmt)
            db.slDataAdd("CompensationType", comtype)
            db.slDataAdd("Arrears", Arrears)
            db.slDataAdd("Comments", remarks)
            db.slDataAdd("Month", month)
            db.slDataAdd("Year", year)
            db.slDataAdd("isUpdatable", 0)
            db.slDataAdd("Submit", 1)
            db.slDataAdd("Freeze", 1)
            db.slDataAdd("supervisorid", SupervisorID)
            db.slDataAdd("FilledBy", UserID)
            db.Executeproc("usp_InsertIncentives2")


            db.CommitTrans()


        Catch ex As Exception
            db.RollBackTrans()
            LblError.Visible = True
            LblError.Text = ex.Message
        Finally
            db = Nothing
        End Try
    End Sub
    Private Sub SaveIncentivesLog(ByVal PLI As String, ByVal QFI As String, ByVal Arrears As String, ByVal remarks As String, ByVal Transport As String, ByVal Retention As String, ByVal Covid As String, clientIncentiveAmt As String, ByVal comtype As Integer, ByVal agentid As String, ByVal agentname As String, ByVal month As String, ByVal year As String)

        Dim db As New DBAccess("CRM")
        'Dim gridrow As DataGridItem
        db.BeginTrans()
        Try

            'db.slDataAdd("TransID", TransID)
            'db.slDataAdd("LoginID", LoginID)
            'db.slDataAdd("UserID", UsrID)
            db.slDataAdd("AgentId", agentid)
            db.slDataAdd("AgentName", agentname)
            db.slDataAdd("PLIAmount", PLI)
            db.slDataAdd("QFIAmount", QFI)
            db.slDataAdd("TransportAmount", Transport)
            db.slDataAdd("RetentionAmount", Retention)
            db.slDataAdd("CovidAmount", Covid)
            db.slDataAdd("ClientIncentiveAmt", clientIncentiveAmt)
            db.slDataAdd("CompensationType", comtype)
            db.slDataAdd("Arrears", Arrears)
            db.slDataAdd("Comments", remarks)
            db.slDataAdd("Month", month)
            db.slDataAdd("Year", year)
            db.slDataAdd("supervisorid", SupervisorID)
            db.slDataAdd("FilledBy", UserID)
            db.Executeproc("usp_InsertIncentivesLog2")
            db.CommitTrans()
            SuccessMessage("Freezed")
        Catch ex As Exception
            db.RollBackTrans()
            LblError.Visible = True
            LblError.Text = ex.Message
        Finally
            db = Nothing
        End Try
    End Sub
    Private Function ValidateControls(ByVal PLI As String, ByVal QFI As String, ByVal Arrears As String, ByVal remarks As String, ByVal Transport As String, ByVal Retention As String, ByVal comtype As Integer) As Boolean
        ' Dim gridrow As DataGridItem
        'Dim row As GridViewRow


        'TO ENSURE THAT ONLY NUMERIC DATA IS ENTERED 

        ' For Each row In GdAttendance.Rows
        If Not PLI = "" Then
            If Not IsNumeric(PLI) Then
                LblError.Visible = True
                LblError.Text = "Please Enter numeric values for the PLI Amount in the TextBox(es)"
                LblError.ForeColor = Drawing.Color.Red
                Return False
            End If
        End If

        If Not Transport = "" Then
            If Not IsNumeric(Transport) Then
                LblError.Visible = True
                LblError.Text = "Please Enter numeric values for the Transport Amount in the TextBox(es)"
                LblError.ForeColor = Drawing.Color.Red
                Return False
            End If
        End If

        If Not Retention = "" Then
            If Not IsNumeric(Retention) Then
                LblError.Visible = True
                LblError.Text = "Please Enter numeric values for the Retention Amount in the TextBox(es)"
                LblError.ForeColor = Drawing.Color.Red
                Return False
            End If
        End If

        'If Not QFI = "" Then
        '    If Not IsNumeric(QFI) Then
        '        LblError.Visible = True
        '        LblError.Text = "Please Enter numeric values for the QFI Amount in the TextBox(es)"
        '        LblError.ForeColor = Drawing.Color.Red
        '        Return False
        '    End If
        'End If

        If Not Arrears = "" Then
            If Not IsNumeric(Arrears) Then
                LblError.Visible = True
                LblError.Text = "Please Enter numeric values for the Arrears Amount in the TextBox(es)"
                LblError.ForeColor = Drawing.Color.Red
                Return False
            End If
        End If

        If Arrears = "" And Arrears <> "0" Then
            If remarks = "" Then
                LblError.Visible = True
                LblError.Text = "Please Enter the Comments corresponding to the Arrears Filled in"
                LblError.ForeColor = Drawing.Color.Red
                Return False
            End If
        End If



        '  Next

        Return True

    End Function
#End Region

    
#Region "Utility"

    Private Sub AlertMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMFail"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub

    Private Sub SuccessMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMSuccess"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub
    Public Overrides Sub VerifyRenderingInServerForm(ByVal Control As Control)

    End Sub
    Private Sub ExportToexcel()
        Dim tw As New IO.StringWriter()
        Dim hw As New System.Web.UI.HtmlTextWriter(tw)
        'Dim frm As HtmlForm = New HtmlForm()
        Response.ContentType = "application/vnd.ms-excel"
        Response.AddHeader("content-disposition", "attachment;filename=" & lblreportname.CurrentPage & ".xls")
        Response.Charset = ""
        EnableViewState = False
        'Controls.Add(frm)
        GridView1.RenderControl(hw)
        Response.Write(tw.ToString())
        Response.End()
    End Sub
#End Region
End Class
