﻿Imports com.nss.DBAccess
Imports System.Data
Imports System.Text.RegularExpressions
Partial Class Staffing_Incentive_EmpVcDetail
    Inherits System.Web.UI.Page
#Region "--- Properties ---"
    Property AgentId() As String
        Get
            Return ViewState("AgentId")
        End Get
        Set(ByVal value As String)
            ViewState("AgentId") = value
        End Set
    End Property
#End Region
#Region "--- Load ---"
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        HumanMessage.Style.Item("visibility") = "hidden"
        If Not IsPostBack Then
            AgentId = Session("AgentID")
            FillCampaigns()
            FillEmployee()
            FillData()
            CheckVCStatus()
            PanelReports.Controls.Add(Common.GetMenu(Request.Url, AgentID, Request.ApplicationPath))
        End If
    End Sub
#End Region
#Region "--- Events ---"
    Protected Sub cboCampaign_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboCampaign.SelectedIndexChanged
        FillEmployee()
        FillData()
    End Sub
    Protected Sub btnUpdate_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnUpdate.Click
        UpdateVcAmount()
    End Sub
    Protected Sub btnSave_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnSave.Click
        Dim db As New DBAccess("CRM")
        Try
            Dim strAmount As String = "\d+(\.\d{1,2})?"
            Dim chkValue As New Regex(strAmount)
            For Each row As GridViewRow In gvTMDetails.Rows
                If Not chkValue.IsMatch(CType(gvTMDetails.Rows(row.RowIndex).FindControl("txtAmount"), TextBox).Text) Then
                    AlertMessage("Please Enter Only Numeric Value")
                    Exit Sub
                Else
                    Dim ucWEF As Object = gvTMDetails.Rows(row.RowIndex).FindControl("ucWEFDate1")
                    db.slDataAdd("AgentId", CType(gvTMDetails.Rows(row.RowIndex).FindControl("lblEmpId"), Label).Text)
                    db.slDataAdd("Amount", CType(gvTMDetails.Rows(row.RowIndex).FindControl("txtAmount"), TextBox).Text)
                    db.slDataAdd("WEFDate", ucWEF.value)
                    'db.slDataAdd("Amount", CType(gvTMDetails.Rows(row.RowIndex).FindControl("lblAmount"), Label).Text)
                    db.Executeproc("usp_InsertVcAmount")
                End If
            Next
            db = Nothing
            SuccessMessage("VC Amount has been Saved Successfully")
            FillData()
        Catch ex As Exception
            AlertMessage(ex.ToString)
        End Try
    End Sub
    Protected Sub btAddEmp_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btAddEmp.Click
        Dim db As New DBAccess("CRM")
        Try
            If cboEmpList.SelectedValue <> "0" Then
                If txtVcAmount.Text.Trim <> "" Then
                    Dim strAmount As String = "\d+(\.\d{1,2})?"
                    Dim chkValue As New Regex(strAmount)
                    If Not chkValue.IsMatch(txtVcAmount.Text.Trim) Then
                        AlertMessage("Please Enter Only Numeric Value")
                        Exit Sub
                    Else
                        db.slDataAdd("AgentId", cboEmpList.SelectedValue)
                        db.slDataAdd("Amount", txtVcAmount.Text)
                        db.slDataAdd("WEFDate", ucWEFDate.value)
                        db.Executeproc("usp_InsertVcAmount")
                    End If
                    db = Nothing
                    SuccessMessage("VC Amount has been Saved Successfully for [" & cboEmpList.SelectedItem.Text & "]")
                    txtVcAmount.Text = ""
                    cboEmpList.SelectedValue = 0
                    FillData()
                Else
                    AlertMessage("Please Insert Employee VC")
                End If
            Else
                AlertMessage("Please Select an Employee")
            End If
        Catch ex As Exception
            AlertMessage(ex.ToString)
        End Try
    End Sub
    Protected Sub ImageButton1_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton1.Click
        FillData()
        GridViewExportUtil.Export(breadcrumbs.CurrentPage & ".xls", Me.gvTMDetails)
    End Sub
    Protected Sub gvTMDetails_RowCommand(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewCommandEventArgs) Handles gvTMDetails.RowCommand
        Dim row As GridViewRow = CType(CType(e.CommandSource, Control).NamingContainer, GridViewRow)
        If e.CommandName = "Modify" Then
            lblEmployeeId.Text = CType(gvTMDetails.Rows(row.RowIndex).FindControl("lblEmpId"), Label).Text
            lblEmployeeName.Text = CType(gvTMDetails.Rows(row.RowIndex).FindControl("lblTM"), Label).Text
            txtAmount.Text = CType(gvTMDetails.Rows(row.RowIndex).FindControl("txtAmount"), TextBox).Text
            'lblAmount.Text = CType(gvTMDetails.Rows(row.RowIndex).FindControl("lblAmount"), Label).Text
            Dim ucWEF As Object = gvTMDetails.Rows(row.RowIndex).FindControl("ucWEFDate1")
            ucWEFDate2.value = ucWEF.value
            Dim str As String
            str = "$('#DialogBackground').height($(document).height()-50);$('#DialogBackground').width($(window).width());$('#DialogBackground').css('visibility','visible');$('#pnlModifyVc').css('visibility','visible');" & _
            " $('#pnlModifyVc').css('left',($(window).width() - $('#pnlModifyVc').width())/2); "
            ScriptManager.RegisterStartupScript(Page, Page.GetType(), "pnlModifyVc", str, True)
        End If
    End Sub
    Protected Sub ucWEFDate2_Changed(ByVal sender As Object, ByVal e As System.EventArgs) Handles ucWEFDate2.Changed
        Dim str As String
        str = "$('#DialogBackground').height($(document).height()-50);$('#DialogBackground').width($(window).width());$('#DialogBackground').css('visibility','visible');$('#pnlModifyVc').css('visibility','visible');" & _
        " $('#pnlModifyVc').css('left',($(window).width() - $('#pnlModifyVc').width())/2); "
        ScriptManager.RegisterStartupScript(Page, Page.GetType(), "pnlModifyVc", str, True)
    End Sub
#End Region
#Region "--- Functions ---"
    Private Sub CheckVCStatus()
        Dim db As New DBAccess("CRM")
        Dim dr As DataRow = db.ReturnRow("SELECT TOP 1 IsFreezed  FROM tbl_Data_VC", False)
        db = Nothing
        If Not dr Is Nothing Then
            If dr(0) = True Then
                gvTMDetails.Enabled = False
                btnSave.Enabled = False
                pnlAddvc.Enabled = False
            Else
                gvTMDetails.Enabled = True
                btnSave.Enabled = True
                pnlAddvc.Enabled = True
            End If
        End If
    End Sub
    Private Sub FillCampaigns()
        Try
            Dim db As New DBAccess("CRM")
            Dim dt As DataTable = db.ReturnTable("SELECT distinct B.CampaignID,A.Name FROM tbl_Config_Campaigns A INNER JOIN tbl_AgentMaster B ON B.CampaignID=A.CampaignID  WHERE A.Active=1 ORDER BY A.Name", False)
            db = Nothing
            Dim dr As DataRow = dt.NewRow
            dr("Name") = "All"
            dr("CampaignId") = 0
            dt.Rows.Add(dr)
            dt.AcceptChanges()
            cboCampaign.DataTextField = "Name"
            cboCampaign.DataValueField = "CampaignId"
            cboCampaign.DataSource = dt
            cboCampaign.DataBind()
            cboCampaign.SelectedValue = 0
        Catch ex As Exception
            AlertMessage(ex.ToString)
        End Try
    End Sub
    Private Sub FillData()
        Dim db As New DBAccess("CRM")
        Dim dt As DataTable
        Try
            db.slDataAdd("Campaignid", cboCampaign.SelectedValue)
            dt = db.ReturnTable("usp_GetVcDetail", "", True)
            gvTMDetails.DataSource = dt
            gvTMDetails.DataBind()
            db = Nothing
            breadcrumbs.CurrentPage = "Employee Vc Detail"
        Catch ex As Exception
            AlertMessage(ex.ToString)
        End Try
    End Sub
    Private Sub FillEmployee()
        Dim db As New DBAccess("CRM")
        Dim dt As DataTable
        db.slDataAdd("CampaignId", cboCampaign.SelectedValue)
        dt = db.ReturnTable("usp_getAllEmployee", , True)
        Dim dr As DataRow = dt.NewRow
        dr("AgentName") = "--- Select Employee ---"
        dr("AgentId") = 0
        dt.Rows.Add(dr)
        dt.AcceptChanges()
        cboEmpList.DataTextField = "AgentName"
        cboEmpList.DataValueField = "AgentId"
        cboEmpList.DataSource = dt
        cboEmpList.DataBind()
        cboEmpList.SelectedValue = 0
        db = Nothing
    End Sub
    Private Sub UpdateVcAmount()
        Dim db As New DBAccess("CRM")
        Try
            Dim strAmount As String = "\d+(\.\d{1,2})?"
            Dim chkValue As New Regex(strAmount)
            If Not chkValue.IsMatch(txtAmount.Text) Then
                AlertMessage("Please Enter Numeric Value")
            Else
                db.slDataAdd("AgentId", lblEmployeeId.Text)
                db.slDataAdd("Amount", txtAmount.Text)
                db.slDataAdd("WEFDate", ucWEFDate2.value)
                db.Executeproc("usp_InsertVcAmount")
                db = Nothing
                SuccessMessage("Amount Has been Updated Successfully For :  [" & lblEmployeeName.Text & "]")
            End If
            FillData()
        Catch ex As Exception
            AlertMessage(ex.ToString)
        End Try
    End Sub
#End Region
#Region "--- Utility ---"
    Private Sub AlertMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMFail"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub
    Private Sub SuccessMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMSuccess"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub
#End Region
End Class
