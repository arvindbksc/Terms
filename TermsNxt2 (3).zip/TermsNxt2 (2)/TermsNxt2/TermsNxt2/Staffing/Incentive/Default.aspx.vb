﻿Imports com.nss.DBAccess
Imports System.Data
Imports System.Text
Imports System.Globalization
Partial Class Staffing_Incentive_Default
    Inherits System.Web.UI.Page
#Region "-----Properties-----"

    Property CurrentDate() As Date
        Get
            Return ViewState("CurrentDate")
        End Get
        Set(ByVal value As Date)
            ViewState("CurrentDate") = value
        End Set
    End Property
    Property IncentiveMonth() As Integer
        Get
            Return ViewState("IncentiveMonth")
        End Get
        Set(ByVal value As Integer)
            ViewState("IncentiveMonth") = value
        End Set
    End Property
    Property IncentiveYear() As Integer
        Get
            Return ViewState("IncentiveYear")
        End Get
        Set(ByVal value As Integer)
            ViewState("IncentiveYear") = value
        End Set
    End Property
    Property TransID() As Integer
        Get
            Return ViewState("TransID")
        End Get
        Set(ByVal value As Integer)
            ViewState("TransID") = value
        End Set
    End Property

    Property MinDate() As Date
        Get
            Return ViewState("MinDate")
        End Get
        Set(ByVal value As Date)
            ViewState("MinDate") = value
        End Set
    End Property

    Property ReportType() As Integer
        Get
            Return ViewState("ReportType")
        End Get
        Set(ByVal value As Integer)
            ViewState("ReportType") = value
        End Set
    End Property

    Property CurrentLevel() As Integer
        Get
            Return ViewState("CurrentLevel")
        End Get
        Set(ByVal value As Integer)
            ViewState("CurrentLevel") = value
        End Set
    End Property
    Property SupervisorID() As String
        Get
            Return ViewState("SupervisorID")
        End Get
        Set(ByVal value As String)
            ViewState("SupervisorID") = value
        End Set
    End Property
    Property UserID() As String
        Get
            Return ViewState("UserID")
        End Get
        Set(ByVal value As String)
            ViewState("UserID") = value
        End Set
    End Property
    Property UsrID() As Integer
        Get
            Return ViewState("UsrID")
        End Get
        Set(ByVal value As Integer)
            ViewState("UsrID") = value
        End Set
    End Property
    Property LoginID() As Integer
        Get
            Return ViewState("LoginID")
        End Get
        Set(ByVal value As Integer)
            ViewState("LoginID") = value
        End Set
    End Property
    Property AgentID() As String
        Get
            Return ViewState("AgentID")
        End Get
        Set(ByVal value As String)
            ViewState("AgentID") = value
        End Set
    End Property

    Property CampaignID() As String
        Get
            Return ViewState("CampaignID")
        End Get
        Set(ByVal value As String)
            ViewState("CampaignID") = value
        End Set
    End Property


    Private b_Issupervisor As Boolean
    Public Property IsSupervisor() As Boolean
        Get
            Return b_Issupervisor
        End Get
        Set(ByVal value As Boolean)
            b_Issupervisor = value
        End Set
    End Property


    Private b_IsManager As Boolean
    Public Property IsManager() As Boolean
        Get
            Return b_IsManager
        End Get
        Set(ByVal value As Boolean)
            b_IsManager = value
        End Set
    End Property
#End Region
#Region "-----Load Activities-----"

    Private Sub LoadData()

        Dim db As New DBAccess("CRM")
        'TODO: change this query to stored procedure
        Dim dr As DataRow = db.ReturnRow("SELECT getdate() as currentdate")
        CurrentDate = dr("currentDate")
        IncentiveMonth = DatePart(DateInterval.Month, DateAdd(DateInterval.Month, -1, CurrentDate))
        IncentiveYear = DatePart(DateInterval.Year, DateAdd(DateInterval.Month, -1, CurrentDate))
        LblIncentiveDate.Text = "Incentive for :: " & MonthName(IncentiveMonth) & ", " & IncentiveYear
        db = Nothing
        
        'lblDate.Text = "* You can mark the attendance between [" & MinDate.ToString("dd-MMM-yyyy") & "] and [" & CurrentDate.ToString("dd-MMM-yyyy") & "]"
       
    End Sub

    Private Sub FillMenu()
        PanelReports.Controls.Add(Common.GetMenu(Request.Url, AgentID, Request.ApplicationPath))
    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        HumanMessage.Style.Item("visibility") = "hidden"
        If Not IsPostBack Then

            'Session("Agentid") = "NSS47671"
            'Session("UserID") = "NSS47671"

            lblReportName.CurrentPage = "Fill Incentive"
            LblError.Visible = False
            AgentID = Session("Agentid")
            hdnAgentId.Value = AgentID
            PanelReports.Controls.Add(Common.GetMenu(Request.Url, AgentID, Request.ApplicationPath))
            'ReportType = Request.QueryString("ReportType")
            LoadData()
            CurrentLevel = 2
            SupervisorID = Session("UserID")
            UserID = Session("UserID")
            fillgrid(SupervisorID)
            link2.Text = Session("username") & "(" & Session("UserID") & ")"
            Image3.Visible = False
            Image4.Visible = False
            Image5.Visible = False
            Image6.Visible = False
            Image7.Visible = False
            Image8.Visible = False
        End If
        'FillMenu()
    End Sub
#End Region

#Region "----Grid Ops----"
    Private Sub fillgrid(ByVal supervisorid As String)
        'ImgMarkedorNot.ImageUrl = "~/_assets/img/yes.gif"
        GdAttendance.Columns(1).Visible = True
        GdAttendance.Columns(GdAttendance.Columns.Count - 1).Visible = True
        'GdAttendance.Columns(GdAttendance.Columns.Count - 2).Visible = True
        'Dim db As New DBAccess("Termsmonitor")
        'UsrID = db.ReturnValue("select usr_id from tbl_workgroup_mst where Dialler_Id='" & supervisorid & "' and active='Y'", False)
        'LoginID = db.ReturnValue("select usr_id from tbl_workgroup_mst where Dialler_Id='" & UserID & "' and active='Y'", False)
        'db = Nothing
        Dim db As New DBAccess("CRM")

        db.slDataAdd("supervisorid", supervisorid)
        db.slDataAdd("PrevMonth", IncentiveMonth)
        db.slDataAdd("Prevyear", IncentiveYear)
        'db.slDataAdd("userid", UsrID)
        ' Dim dt As DataTable = db.ReturnTable("usp_retrieveAttendanceData", , True)
        Dim dt As DataTable = db.ReturnTable("usp_getIncentiveHierarchy2", , True)
        db = Nothing
        GdAttendance.DataSource = dt.DefaultView
        GdAttendance.DataBind()
        GdAttendance.Columns(4).Visible = False 'QFI
        GdAttendance.Columns(8).Visible = False  'VC/QFI

        db = Nothing
        If dt.Rows.Count < 1 Then
            btsave.Enabled = False
            btSubmit.Enabled = False
            LblMarkedorNot.Text = "Not Filled"
            'btreset.Visible = False
        Else
            btsave.Enabled = True
            If dt.Rows(0)("marked") = 1 Then
                ImgMarkedorNot.ImageUrl = "~/_assets/img/yes.gif"
                LblMarkedorNot.Text = "Filled"
            Else
                ImgMarkedorNot.ImageUrl = "~/_assets/img/why.gif"
                LblMarkedorNot.Text = "Not Filled"
            End If
        End If
        GdAttendance.Columns(1).Visible = False 'Bound Field AgentName Column
        GdAttendance.Columns(GdAttendance.Columns.Count - 1).Visible = False
 

        'GdAttendance.Columns(GdAttendance.Columns.Count - 2).Visible = False
        db = New DBAccess("CRM")
        'db.slDataAdd("UserID", UsrID)
        db.slDataAdd("supervisorid", supervisorid)
        If dt.Rows.Count >= 1 Then
            Dim isfrozen As Boolean = db.ReturnValue("usp_CheckFreeze", True)
            db = Nothing
            GdAttendance.Enabled = Not isfrozen
            btsave.Enabled = Not isfrozen
            btSubmit.Enabled = Not isfrozen
            If isfrozen Then
                GdAttendance.BackImageUrl = "~/_assets/img/Frozen.JPG"
            Else
                GdAttendance.BackImageUrl = ""
            End If
        End If

   

        GetAgentDetail(supervisorid)
        If IsSupervisor = True And IsManager = True Then
            GdAttendance.Columns(5).Visible = True
            GdAttendance.Columns(6).Visible = True
        ElseIf IsSupervisor = True And IsManager = False And hdnAgentId.Value <> supervisorid.Trim Then
            GdAttendance.Columns(5).Visible = True
            GdAttendance.Columns(6).Visible = True
        ElseIf IsSupervisor = True And IsManager = False Then
            GdAttendance.Columns(5).Visible = True
            GdAttendance.Columns(6).Visible = False

        ElseIf IsSupervisor = False And IsManager = True Then
            GdAttendance.Columns(5).Visible = True
            GdAttendance.Columns(6).Visible = True
        ElseIf IsSupervisor = False And IsManager = False Then
            GdAttendance.Columns(5).Visible = False
            GdAttendance.Columns(6).Visible = False
       

            'ElseIf IsSupervisor = True And IsManager = False And AgentID.Trim = supervisorid.Trim Then
            '    GdAttendance.Columns(5).Visible = True
            '    GdAttendance.Columns(6).Visible = False
        End If
        Dim camplist As String
        camplist = System.Configuration.ConfigurationManager.AppSettings("Camplist")
        Dim bln As Boolean = camplist.Contains(CampaignID.ToString())
        If (bln = True) And IsSupervisor = True And IsManager = False And hdnAgentId.Value <> supervisorid.Trim Then
            GdAttendance.Columns(7).Visible = True  'Covid Incentive
        ElseIf IsSupervisor = True And IsManager = True And (bln = True) Then
            GdAttendance.Columns(7).Visible = True

        ElseIf IsSupervisor = True And IsManager = True And (bln = False) Then
            GdAttendance.Columns(7).Visible = False

        ElseIf IsSupervisor = False And IsManager = True And (bln = True) Then
            GdAttendance.Columns(7).Visible = True
        ElseIf IsSupervisor = False And IsManager = True And (bln = False) Then
            GdAttendance.Columns(7).Visible = False


        ElseIf IsSupervisor = False And IsManager = False And (bln = False) Then
            GdAttendance.Columns(7).Visible = False
        End If




    End Sub
    Protected Sub GetAgentDetail(supervisorid As String)
        Dim db As New DBAccess("report")
        Dim dt As New DataTable
        db.slDataAdd("Agentid", supervisorid)
        dt = db.ReturnTable("usp_GetAgentDetails2", "", True)
        If dt.Rows.Count > 0 Then
            IsSupervisor = dt.Rows(0)("IsSupervisor")
            IsManager = dt.Rows(0)("IsManager")
            CampaignID = dt.Rows(0)("CampaignID")
            dt = Nothing
        End If
    End Sub

    Protected Sub GdAttendance_RowDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles GdAttendance.RowDataBound
        If e.Row.RowType = DataControlRowType.DataRow Then
            If e.Row.Cells(e.Row.Cells.Count - 1).Text.ToLower = "false" Or CType(e.Row.FindControl("lblAgentID"), Label).Text = SupervisorID Then
               CType(e.Row.FindControl("lnkbtagentname"), LinkButton).Visible = False
            Else
                CType(e.Row.FindControl("lblAgentName"), Label).Visible = False
            End If
        End If
    End Sub
#End Region
#Region "-----Supervisor change-----"


    Protected Sub GdAttendance_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles GdAttendance.SelectedIndexChanged

        Dim lnk As New LinkButton, img As New Image
        CurrentLevel += 1
        Select Case CurrentLevel
            Case 3
                lnk = link3
                img = Image3
                link2.CssClass = "notselectedlink"
            Case 4
                lnk = Link4
                img = Image4
                link3.CssClass = "notselectedlink"
            Case 5
                lnk = Link5
                img = Image5
                Link4.CssClass = "notselectedlink"
            Case 6
                lnk = Link6
                img = Image6
                Link5.CssClass = "notselectedlink"
            Case 7
                lnk = Link7
                img = Image7
                Link6.CssClass = "notselectedlink"
            Case 8
                lnk = Link8
                img = Image8
                Link7.CssClass = "notselectedlink"
        End Select
        lnk.Text = GdAttendance.SelectedDataKey.Item("AgentName").ToString & "(" & GdAttendance.SelectedDataKey.Item("AgentID").ToString & ")"
        SupervisorID = GdAttendance.SelectedDataKey.Item("AgentID").ToString
        fillgrid(SupervisorID)

        lnk.Visible = True
        lnk.CssClass = "selectedlink"
        img.Visible = True

    End Sub

    Private Sub HideAllSideLinks(ByVal ctrl As LinkButton)
        Dim from As Integer
        from = ctrl.ID.ToLower.Replace("link", "")
        CurrentLevel = from

        Select Case from
            Case 2
                link3.Visible = False
                Link4.Visible = False
                Link5.Visible = False
                Link6.Visible = False
                Link7.Visible = False
                Link8.Visible = False

                Image3.Visible = False
                Image4.Visible = False
                Image5.Visible = False
                Image6.Visible = False
                Image7.Visible = False
                Image8.Visible = False
            Case 3
                Link4.Visible = False
                Link5.Visible = False
                Link6.Visible = False
                Link7.Visible = False
                Link8.Visible = False
                Image4.Visible = False
                Image5.Visible = False
                Image6.Visible = False
                Image7.Visible = False
                Image8.Visible = False
            Case 4

                Link5.Visible = False
                Link6.Visible = False
                Link7.Visible = False
                Link8.Visible = False
                Image5.Visible = False
                Image6.Visible = False
                Image7.Visible = False
                Image8.Visible = False
            Case 5

                Link6.Visible = False
                Link7.Visible = False
                Link8.Visible = False

                Image6.Visible = False
                Image7.Visible = False
                Image8.Visible = False
            Case 6

                Link7.Visible = False
                Link8.Visible = False

                Image7.Visible = False
                Image8.Visible = False
            Case 7

                Link8.Visible = False

                Image8.Visible = False
            Case 8
                'do noting
        End Select




    End Sub

    Protected Sub Sidelink_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles link2.Click

        Dim length As Integer

        length = sender.Text.LastIndexOf(")") - sender.Text.LastIndexOf("(")

        SupervisorID = sender.Text.Substring(sender.Text.LastIndexOf("(") + 1, length - 1)
        fillgrid(SupervisorID)
        HideAllSideLinks(sender)
        sender.CssClass = "selectedlink"
    End Sub

#End Region
#Region "---Save Incentive----"
    Protected Sub btsave_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btsave.Click
        btsave.Enabled = False

        If ValidateControls() Then
            'Dim db As New DBAccess("termsmonitor")
            ''db.slDataAdd("UserID", UsrID)
            'db.slDataAdd("supervisorid", SupervisorID)
            'TransID = db.ReturnValue("usp_getTransactionID", True)
            'db = Nothing
            'Call SaveIncentives(TransID, 0, 0)
            'Call SaveIncentivesLog(TransID)
            Call SaveIncentives(0, 0)
            Call SaveIncentivesLog()
        End If
        btsave.Enabled = True
        btSubmit.Enabled = True
        
    End Sub
    Protected Sub btSubmit_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btSubmit.Click
        '  If validdate(System.DateTime.Now) Then
        If ValidateControls() Then
            'Dim db As New DBAccess("termsmonitor")
            ''db.slDataAdd("UserID", UsrID)
            'db.slDataAdd("supervisorid", SupervisorID)
            'TransID = db.ReturnValue("usp_getTransactionID", True)
            'db = Nothing
            'isUpdatable = CheckForUpdate()

            Call SaveIncentives(1, 0)
            Call SaveIncentivesLog()
            Call SendConfirmationMailToHR()

            'Call SaveEMailToHRDetails()
            btsave.Enabled = False
            btSubmit.Enabled = False
        End If
        'End If
    End Sub
    Private Sub SaveIncentives(ByVal btSubmit As Int16, ByVal btFreeze As Int16)
        'Dim dbcampaign As New DBAccess
        'Dim CampaignID As Int16 = dbcampaign.ReturnValue("select campaignid  from tbl_AgentMaster where AgentID ='" & SupervisorID & "'", False)
        'dbcampaign = Nothing
        Dim db As New DBAccess("CRM")

        db.BeginTrans()
        Try

            Dim txt1, txt2, txt3, txt4, txt5, txt6, txt7, txt8 As TextBox, lbAgentid, lbAgentName As Label, cb1 As DropDownList
            For Each dgRow As GridViewRow In GdAttendance.Rows
                Dim HiddenCampId As HiddenField = dgRow.FindControl("HiddenCampId")
                lbAgentid = dgRow.FindControl("lblAgentID")
                lbAgentName = dgRow.FindControl("lblAgentName")
                txt1 = dgRow.FindControl("txtPLI")
                txt2 = dgRow.FindControl("txtQFI")
                txt3 = dgRow.FindControl("txtArrears")
                txt4 = dgRow.FindControl("txtComments")
                txt5 = dgRow.FindControl("txtTransport")
                txt6 = dgRow.FindControl("txtRetention")
                txt7 = dgRow.FindControl("txtCovid")
                txt8 = dgRow.FindControl("tbxClientIncentive")
                cb1 = dgRow.FindControl("cbovc")

                db.slDataAdd("CampaignID", HiddenCampId.Value)
                db.slDataAdd("AgentID", lbAgentid.Text)
                db.slDataAdd("AgentName", lbAgentName.Text)
                db.slDataAdd("PLIAmount", txt1.Text)
                db.slDataAdd("QFIAmount", txt2.Text)
                db.slDataAdd("TransportAmount", txt5.Text)
                db.slDataAdd("RetentionAmount", txt6.Text)
                db.slDataAdd("CovidAmount", txt7.Text)
                db.slDataAdd("ClientIncentiveAmt", txt8.Text)
                db.slDataAdd("CompensationType", cb1.SelectedValue)
                db.slDataAdd("Arrears", txt3.Text)
                db.slDataAdd("Comments", txt4.Text)
                db.slDataAdd("Month", MonthName(IncentiveMonth))
                db.slDataAdd("Year", IncentiveYear)
                db.slDataAdd("isUpdatable", 0)
                db.slDataAdd("Submit", btSubmit)
                db.slDataAdd("Freeze", btFreeze)
                db.slDataAdd("supervisorid", SupervisorID)
                db.slDataAdd("FilledBy", UserID)
                db.Executeproc("usp_InsertIncentives2")

            Next
            db.CommitTrans()
            fillgrid(SupervisorID)
            SuccessMessage("Saved")

        Catch ex As Exception
            db.RollBackTrans()
            LblError.Visible = True
            LblError.Text = ex.Message
        Finally
            db = Nothing
        End Try
    End Sub
    Private Sub SaveIncentivesLog()
        Dim txt1, txt2, txt3, txt4, txt5, txt6, txt7, txt8 As TextBox, lbAgentid, lbAgentName As Label, cb1 As DropDownList
        Dim db As New DBAccess("CRM")
        'Dim gridrow As DataGridItem
        db.BeginTrans()
        Try
            For Each dgRow As GridViewRow In GdAttendance.Rows
                lbAgentid = dgRow.FindControl("lblAgentID")
                lbAgentName = dgRow.FindControl("lblAgentName")
                txt1 = dgRow.FindControl("txtPLI")
                txt2 = dgRow.FindControl("txtQFI")
                txt3 = dgRow.FindControl("txtArrears")
                txt4 = dgRow.FindControl("txtComments")
                txt5 = dgRow.FindControl("txtTransport")
                txt6 = dgRow.FindControl("txtRetention")
                txt7 = dgRow.FindControl("txtCovid")
                txt8 = dgRow.FindControl("tbxClientIncentive")
                cb1 = dgRow.FindControl("cbovc")

                db.slDataAdd("AgentId", lbAgentid.Text)
                db.slDataAdd("AgentName", lbAgentName.Text)
                db.slDataAdd("PLIAmount", txt1.Text)
                db.slDataAdd("QFIAmount", txt2.Text)
                db.slDataAdd("TransportAmount", txt5.Text)
                db.slDataAdd("RetentionAmount", txt6.Text)
                db.slDataAdd("CovidAmount", txt7.Text)
                db.slDataAdd("ClientIncentiveAmt", txt8.Text)
                db.slDataAdd("CompensationType", cb1.SelectedValue)
                db.slDataAdd("Arrears", txt3.Text)
                db.slDataAdd("Comments", txt4.Text)
                db.slDataAdd("Month", MonthName(IncentiveMonth))
                db.slDataAdd("Year", IncentiveYear)
                db.slDataAdd("supervisorid", SupervisorID)
                db.slDataAdd("FilledBy", UserID)
                db.Executeproc("usp_InsertIncentivesLog2")
            Next
            db.CommitTrans()
        Catch ex As Exception
            db.RollBackTrans()
            LblError.Visible = True
            LblError.Text = ex.Message
        Finally
            db = Nothing
        End Try
    End Sub
    
    'Private Function CheckForUpdate() As Byte
    '    Dim db As New DBAccess("termsmonitor")
    '    Dim isTrue As Byte
    '    db.slDataAdd("UserID", UsrID)
    '    isTrue = db.ExecuteprocSC("usp_CheckForUpdate")
    '    Return isTrue
    '    db = Nothing
    'End Function



    Private Function validdate(ByVal selecteddate As DateTime) As Boolean
        Dim db As New DBAccess("CRM")
        'TODO: change this query to stored procedure
        Dim dr As DataRow = db.ReturnRow("SELECT dateadd(dd,1,max([FreezeDate])) as mindate  ,getdate() as currentdate  FROM [tbl_LastFreezedDate]")
        CurrentDate = dr("currentDate")
        'DateTimePicker3.value = CurrentDate.ToString("dd-MMM-yyyy")
        MinDate = dr("minDate")
        db = Nothing

        db = New DBAccess("CRM")
        db.slDataAdd("agentid", AgentID)
        Dim dtDetails As DataTable = db.ReturnTable("usp_GetAgentDetails", , True)
        db = Nothing

        IsManager = False
        If dtDetails.Rows.Count > 0 Then
            IsManager = CBool(dtDetails.Rows(0).Item("isManager"))
        End If

        lblDate.Text = "* You can Fill incentive for Period between [" & MinDate.ToString("dd-MMM-yyyy") & "] and [" & CurrentDate.ToString("dd-MMM-yyyy") & "]"

        If selecteddate < MinDate Then
            Return False
        End If
        Return True
        'Try
        '    'fromdate = Convert.ToDateTime(21 & "/" & DateAdd(DateInterval.Month, -1, CurrentDate).Month & "/" & DateAdd(DateInterval.Month, -1, CurrentDate).Year)
        '    'todate = Convert.ToDateTime(20 & "/" & CurrentDate.Month & "/" & CurrentDate.Year)
        '    fromdate = DateAdd(DateInterval.Month, -1, CurrentDate)
        '    If selecteddate > CurrentDate.Date Then
        '        Return False
        '    ElseIf selecteddate < fromdate.Date Then
        '        Return False
        '    Else
        '        Return True
        '    End If
        'Catch ex As Exception
        '    LblError.Visible = True
        '    LblError.Text = ex.ToString
        '    'Return False
        'End Try
        Return True
    End Function







    Private Function ValidateControls() As Boolean
        ' Dim gridrow As DataGridItem
        Dim row As GridViewRow


        'TO ENSURE THAT ONLY NUMERIC DATA IS ENTERED 

        For Each row In GdAttendance.Rows
            If Not CType(row.FindControl("txtPLI"), TextBox).Text = "" Then
                If Not IsNumeric(CType(row.FindControl("txtPLI"), TextBox).Text) Then
                    LblError.Visible = True
                    AlertMessage("Please Enter numeric values for the PLI Amount")
                    'LblError.Text = "Please Enter numeric values for the PLI Amount"
                    '  LblError.ForeColor = Drawing.Color.Red
                    Return False
                End If
            End If

            If Not CType(row.FindControl("txtTransport"), TextBox).Text = "" Then
                If Not IsNumeric(CType(row.FindControl("txtTransport"), TextBox).Text) Then
                    LblError.Visible = True
                    AlertMessage("Please Enter numeric values for the Transport Amount")
                    'LblError.Text = "Please Enter numeric values for the PLI Amount"
                    '  LblError.ForeColor = Drawing.Color.Red
                    Return False
                End If
            End If

            If Not CType(row.FindControl("txtRetention"), TextBox).Text = "" Then
                If Not IsNumeric(CType(row.FindControl("txtRetention"), TextBox).Text) Then
                    LblError.Visible = True
                    AlertMessage("Please Enter numeric values for the Retention Amount")
                    'LblError.Text = "Please Enter numeric values for the PLI Amount"
                    '  LblError.ForeColor = Drawing.Color.Red
                    Return False
                End If
            End If

            If Not CType(row.FindControl("txtCovid"), TextBox).Text = "" Then
                If Not IsNumeric(CType(row.FindControl("txtCovid"), TextBox).Text) Then
                    LblError.Visible = True
                    AlertMessage("Please Enter numeric values for the Covid Incentive Amount")
                    'LblError.Text = "Please Enter numeric values for the PLI Amount"
                    '  LblError.ForeColor = Drawing.Color.Red
                    Return False
                End If
            End If

            If Not CType(row.FindControl("tbxClientIncentive"), TextBox).Text = "" Then
                If Not IsNumeric(CType(row.FindControl("tbxClientIncentive"), TextBox).Text) Then
                    LblError.Visible = True
                    AlertMessage("Please Enter numeric values for the Client Incentive Amount")
                    'LblError.Text = "Please Enter numeric values for the PLI Amount"
                    '  LblError.ForeColor = Drawing.Color.Red
                    Return False
                End If
            End If


            'If Not CType(row.FindControl("txtQFI"), TextBox).Text = "" Then
            '    If Not IsNumeric(CType(row.FindControl("txtQFI"), TextBox).Text) Then
            '        LblError.Visible = True
            '        AlertMessage("Please Enter numeric values for the QFI Amount")
            '        ' LblError.Text = "Please Enter numeric values for the QFI Amount"
            '        ' LblError.ForeColor = Drawing.Color.Red
            '        Return False
            '    End If
            'End If

            If Not CType(row.FindControl("txtArrears"), TextBox).Text = "" Then
                If Not IsNumeric(CType(row.FindControl("txtArrears"), TextBox).Text) Then
                    LblError.Visible = True
                    AlertMessage("Please Enter numeric values for the Arrears Amount")
                    ' LblError.Text = "Please Enter numeric values for the Arrears Amount"
                    'LblError.ForeColor = Drawing.Color.Red
                    Return False
                End If
            End If

            If Not CType(row.FindControl("txtArrears"), TextBox).Text = "" And CType(row.FindControl("txtArrears"), TextBox).Text <> "0" Then
                If CType(row.FindControl("txtComments"), TextBox).Text = "" Then
                    LblError.Visible = True
                    AlertMessage("Please Enter the Comments corresponding to the Comment Filled in")
                    'LblError.Text = "Please Enter the Comments corresponding to the Arrears Filled in"
                    'LblError.ForeColor = Drawing.Color.Red
                    Return False
                End If
            End If
        Next

        Return True

    End Function

    Private Sub SendConfirmationMailToHR()
        Dim MailIDSupervisor, TeamMemberName, Body, Subject As String
        Dim db As DBAccess

        db = New DBAccess("CRM")

        '@toremove for any year januray month
        'IncentiveMonth = 0
        'IncentiveYear = 2024

        Dim dtsummary As New DataTable
        db.slDataAdd("Month", IncentiveMonth + 1)
        db.slDataAdd("year", IncentiveYear)
        'db.slDataAdd("campaignid", CampaignID)
        db.slDataAdd("AgentId", SupervisorID)
        dtsummary = db.ReturnTable("[usp_PLIReport3]", , True)
        TeamMemberName = db.ReturnValue("SELECT AgentName FROM tbl_AgentMaster WHERE agentid ='" & SupervisorID & "'")
        Body = ConvertDataTableToHtml(dtsummary)
        'If SupervisorID = UserID Then
        '    Body = " The Incentives for the month of " & MonthName(IncentiveMonth) & " have been plugged in. <Br>"


        'Else
        '    db = New DBAccess("Report") '("termsmonitor")
        '    'TeamMemberName = db.ReturnValue("SELECT Usr_Name FROM User_Mst WHERE Usr_id = " & UsrID)
        '    TeamMemberName = db.ReturnValue("SELECT AgentName FROM tbl_AgentMaster WHERE agentid ='" & SupervisorID & "'")
        '    db = Nothing
        '    Body = " The Incentives for " & TeamMemberName & "'s team for the month of " & MonthName(IncentiveMonth) & " have been plugged in. <Br>"
        'End If


        Subject = "Incentives For the Month Of " & MonthName(IncentiveMonth) & " , " & IncentiveYear & " Filled By  " & TeamMemberName
        'MailIDSupervisor = GetEMailAddress(LoginID)
        MailIDSupervisor = GetEMailAddress(UserID)
        'Dim objWSMail As New ServiceReference2.MailSoapClient

        'Dim objWSMail As New MailSendServiceXX.Service1SoapClient
        Dim MailSubject As String = "Incentives For the Month Of " & MonthName(IncentiveMonth) & " , " & IncentiveYear & " Filled By  " & TeamMemberName

        Dim strCC As String = ""
        Dim strTo As String = ""
        Dim strBCC As String = ""
        strTo = System.Configuration.ConfigurationManager.AppSettings("IncentiveTO")
        strCC = System.Configuration.ConfigurationManager.AppSettings("IncentiveCC")
        strBCC = System.Configuration.ConfigurationManager.AppSettings("IncentiveBCC")
        Dim strFrom As String = MailIDSupervisor

        Dim dt As New DataTable
        db = New DBAccess("CRM")
        db.slDataAdd("AgentId", AgentID)
        dt = db.ReturnTable("usp_SupervisorEmails22", , True)
        db = Nothing
        strCC = dt.Rows(0).Item("MailCC") & "," & System.Configuration.ConfigurationManager.AppSettings("IncentiveCC")
        strBCC = dt.Rows(0).Item("MailBCC")
        strTo = dt.Rows(0).Item("MailTo") & "," & System.Configuration.ConfigurationManager.AppSettings("IncentiveTO")


        ' objWSMail.MailSendNewTech(strCC, MailSubject, strFrom, "TermsMonitor", Body, "", strCC, strBCC, "")
        Common.SMTPSendMail(strTo, MailSubject, strFrom, Body, strCC, System.Configuration.ConfigurationManager.AppSettings("WSR_PIP_ProcessManager"))
        'objWSMail = Nothing
        'Dim Mail As New MailMessage
        
        
    End Sub
    Private Function GetEMailAddress(ByVal UserID As String) As String
        Dim db As New DBAccess("CRM")
        'db.slDataAdd("LoginID", UserID)
        db.slDataAdd("Supervisorid", UserID)
        GetEMailAddress = db.ReturnValue("usp_GetSupervisorEmailAddress", True) 'db.ReturnValue("usp_GetEmailAddress", True)
        db = Nothing
    End Function
    'Private Sub SaveEMailToHRDetails()
    '    Dim MailID As String = GetEMailAddress(LoginID)
    '    Dim db As New DBAccess("TermsMonitor")
    '    db.slDataAdd("LoginID", LoginID)
    '    db.slDataAdd("UserID", UsrID)
    '    db.slDataAdd("From", MailID)
    '    db.slDataAdd("supervisorid", SupervisorID)
    '    db.slDataAdd("FilledBy", UserID)
    '    db.Executeproc("usp_InsertEMailToHRDetails")
    '    db = Nothing
    'End Sub
#End Region
#Region "Utility"

    Private Sub AlertMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMFail"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub

    Private Sub SuccessMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMSuccess"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub
    Public Overrides Sub VerifyRenderingInServerForm(ByVal Control As Control)

    End Sub
#End Region


    Public Shared Function ConvertDataTableToHtml(targetTable As DataTable) As String

        Dim htmlString As String = ""

        Dim htmlBuilder = New StringBuilder()



        '<html xmlns='http://www.w3.org/1999/xhtml'>
        'Create Top Portion of HTML Document
        htmlBuilder.Append("<html xmlns='http://www.w3.org/1999/xhtml'>")
        htmlBuilder.Append("<head>")
        htmlBuilder.Append("<title>")
        htmlBuilder.Append("Page-")
        htmlBuilder.Append(Guid.NewGuid().ToString())
        htmlBuilder.Append("</title>")
        htmlBuilder.Append("</head>")
        htmlBuilder.Append("<body>")
        htmlBuilder.Append("<table border='1' width='90%' style='border: 1px solid; border-collapse: collapse; font-family: Verdana; font-size: .8em'>")

        'Create Header Row <tr bgcolor='#B8CCE4' align='left' valign='top'>       &lt;tr align='left' valign='top'&gt;
        htmlBuilder.Append(" <tr bgcolor='#B8CCE4'> ")

        ' Iterate through the list.
        For Each targetColumn As DataColumn In targetTable.Columns
            htmlBuilder.Append("<td align='Center'>")
            htmlBuilder.Append(targetColumn.ColumnName)
            htmlBuilder.Append("</td>")

        Next

        htmlBuilder.Append("</tr>")

        'Create Data Rows
        For Each myRow As DataRow In targetTable.Rows

            htmlBuilder.Append("<tr align='Center'; >")

            For Each targetColumn As DataColumn In targetTable.Columns

                htmlBuilder.Append("<td align='Center' ;>")
                htmlBuilder.Append(myRow(targetColumn.ColumnName).ToString())
                htmlBuilder.Append("</td>")

            Next
            htmlBuilder.Append("</tr>")

        Next
        'Create Bottom Portion of HTML Document
        htmlBuilder.Append("</table>")
        htmlBuilder.Append("</body>")
        htmlBuilder.Append("</html>")

        'Create String to be Returned
        htmlString = htmlBuilder.ToString()

        Return htmlString

    End Function

    Protected Sub imgfav_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles imgfav.Click
        Common.AddToFav(AgentID, "Fill Incentive")
        fillgrid(SupervisorID)
    End Sub
End Class
