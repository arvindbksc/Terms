﻿using Microsoft.VisualBasic;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using com.nss.DBAccess;
using System.Data.SqlClient;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;


public partial class Staffing_PendingRoleApproval : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["UserID"] == null)
        {
            if (User.Identity.Name.ToString().Contains("NSS\\"))
            {
                Session["Lanid"] = User.Identity.Name.ToString().Replace("NSS\\", "");
            }
            else
            {
                Session["Lanid"] = User.Identity.Name;
            }

            com.nss.DBAccess.DBAccess db = new com.nss.DBAccess.DBAccess();
            
            System.Data.DataRow dr = db.ReturnRow("usp_CheckTermsUser", true);
            db = null;
            if (dr == null)
            {
                Response.Write("There is some problem in authenticating your credentials. Please make sure you are authorized to use this website.");
                return;
            }
            Session["CampaignID"] = dr["campaignid"];
            Session["AgentID"] = dr["AgentID"];
            Session["UserID"] = dr["AgentID"];
            Session["username"] = dr["AgentName"];
            Session["IsVerifier"] = dr["btVerifier"];
            Response.Write(Session["username"]);
            Response.Write(Session["Lanid"]);
        }

        if (!IsPostBack)
        {
            BindGrid();
            lblReportName.CurrentPage = "Pending Role Change";

        }
    }


    public void BindGrid()
    {

        try
        {
            
            DBAccess db = new DBAccess("CRM");
            DataSet ds = new DataSet();
            db.slDataAdd("Type", "Select");
            db.slDataAdd("AgentId", "");
            db.slDataAdd("Agentname", "");
            db.slDataAdd("Role", "");
            db.slDataAdd("NewRole", "");
            db.slDataAdd("RequestedBy", "");
            db.slDataAdd("ConfirmedBy", "");
            db.slDataAdd("ConfirmedSatus", "");
            ds = db.ReturnDataset("usp_GetRoleChangeAgents", true);
            if (ds.Tables[0].Rows.Count > 0)
            {
                
                GdRoleChange.DataSource = ds;
                GdRoleChange.DataBind();
                GdRoleChange.Visible = true;
            }
            else
            {

                GdRoleChange.Visible = false;
            }            
        
        }
        catch (Exception ex)
        {
 
        }
 
    }

    private void AlertMessage(string msg)
    {
        lblHumanMessage.Text = msg;
        HumanMessage.CssClass = "HMFail";
        HumanMessage.Visible = true;
        lblHumanMessage.Visible = true;
        HumanMessage.Style["visibility"] = "visible";

    }

    private void SuccessMessage(string msg)
    {
        lblHumanMessage.Text = msg;
        HumanMessage.CssClass = "HMSuccess";
        HumanMessage.Visible = true;
        lblHumanMessage.Visible = true;
        HumanMessage.Style["visibility"] = "visible";
      

    }
  
    protected void GdRoleChange_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        DBAccess db = new DBAccess("CRM");
        DataTable dt = new DataTable();
       
        if (e.CommandName.ToLower() == ("Approve").ToLower())
        {
            int index = Convert.ToInt32(e.CommandArgument);
            GridViewRow gvrow = GdRoleChange.Rows[index];
            HdnAgentId.Value = (gvrow.FindControl("hdnID") as HiddenField).Value;
            HdnAgentName.Value = (gvrow.FindControl("hdnAgentName") as HiddenField).Value;
            HdnPrevRole.Value = (gvrow.FindControl("hdnPreviousRole") as HiddenField).Value;
            HdnNewRole.Value = (gvrow.FindControl("hdnCurrentRole") as HiddenField).Value;
            LinkButton lnkApprove = (LinkButton)gvrow.FindControl("lnkApprove");
            HdnLinkBtn.Value = lnkApprove.CommandName.ToString();
            db.slDataAdd("Type", "UpdateRole");
            db.slDataAdd("AgentId", HdnAgentId.Value);
            db.slDataAdd("Agentname", "");
            db.slDataAdd("Role", "");
            db.slDataAdd("NewRole", "");
            db.slDataAdd("RequestedBy", "");
            db.slDataAdd("ConfirmedBy", Session["UserID"]);
            db.slDataAdd("ConfirmedSatus", 1);
            dt = db.ReturnTable("usp_GetRoleChangeAgents","", true);
           
        }
        else if (e.CommandName.ToLower() == ("Reject").ToLower())
        {
            int index = Convert.ToInt32(e.CommandArgument);
            GridViewRow gvrow = GdRoleChange.Rows[index];
            HdnAgentId.Value = (gvrow.FindControl("hdnID") as HiddenField).Value;
            HdnAgentName.Value = (gvrow.FindControl("hdnAgentName") as HiddenField).Value;
            HdnPrevRole.Value = (gvrow.FindControl("hdnPreviousRole") as HiddenField).Value;
            HdnNewRole.Value = (gvrow.FindControl("hdnCurrentRole") as HiddenField).Value;
            LinkButton lnkReject = (LinkButton)gvrow.FindControl("lnkReject");
            HdnLinkBtn.Value = lnkReject.ToString();
            db.slDataAdd("Type", "UpdateRole");
            db.slDataAdd("AgentId", HdnAgentId.Value);
            db.slDataAdd("Agentname", "");
            db.slDataAdd("Role", "");
            db.slDataAdd("NewRole", "");
            db.slDataAdd("RequestedBy", "");
            db.slDataAdd("ConfirmedBy", Session["UserID"]);
            db.slDataAdd("ConfirmedSatus", 2);
            dt = db.ReturnTable("usp_GetRoleChangeAgents", "", true);
 
        }
        if (dt != null)
        {
            switch ((dt.Rows[0]["MESSAGE_TYPE"].ToString()))
            {
                case "S":
                    SuccessMessage(dt.Rows[0]["MESSAGE"].ToString());
                    RoleChange_Confirm_Reject();
                    break;

                case "E":
                    AlertMessage(dt.Rows[0]["MESSAGE"].ToString());
                    break;
            }
        }
        
        BindGrid();

    }

    private void RoleChange_Confirm_Reject()
    {
        DBAccess db;        
        int srno = 0;
        var strMailBody = "";        
        db = new DBAccess("CRM");
        db = null;
        strMailBody += "<html xmlns='http://www.w3.org/1999/xhtml'>";
        strMailBody += "<body style='font-family: Verdana; font-size: .8em'>";
        strMailBody += "<strong>Following People's are Confirmed/Reject for Role Changement </strong><br /><br />";
        strMailBody += "<table border='1' width='70%' style='border: 1px solid; border-collapse: collapse; font-family: Verdana; font-size: .8em'>";
        strMailBody += "<tr>";
        strMailBody += "<td align='center'><b>Sr. No.</b></td>";
        strMailBody += "<td align='center'><b>Employee Code</b></td>";
        strMailBody += "<td align='center'><b>Employee Name</b></td>";
        strMailBody += "<td align='center'><b>Previous Designation</b></td>";
        strMailBody += "<td align='center'><b>Current Designation</b></td>";
        if (HdnLinkBtn.Value == "Approve")
        {
            strMailBody += "<td align='center'><b>Confirmed By</b></td>";
        }
        else
        {
            strMailBody += "<td align='center'><b>Rejected By</b></td>"; 
        }
        
        strMailBody += "</tr>";
       
            srno = srno + 1;
            db = new DBAccess("CRM");
            db = null;
            strMailBody += "<tr>";
            strMailBody += "<td align='center'>" + srno + "</td>";
            strMailBody += "<td align='center'>" + HdnAgentId.Value + "</td>";
            strMailBody += "<td align='center'>" + HdnAgentName.Value + "</td>";
            strMailBody += "<td align='center'>" + HdnPrevRole.Value + "</td>";
            strMailBody += "<td align='center'>" + HdnNewRole.Value + "</td>";
            strMailBody += "<td align='center'>" + Session["username"] + "</td>";
            strMailBody += "</tr>";

        
        strMailBody += "</table><br/>";
        strMailBody += "<br /><br /><hr/>This mail was sent using the ";
        strMailBody += "<a href='" + System.Configuration.ConfigurationManager.AppSettings["LiveServerPath"] + "'>TermsMonitor&reg;</a> Mail Service.We request you not to reply this message.";
        strMailBody += "<br />This e-mail is confidential and may also be privileged.If you are not the intended recipient, please notify helpdesk immediately; you should not copy or use it for any purpose,nor disclose its contents to any other person.";
        strMailBody += "</body>";
        strMailBody += "</html>";
        MailService(" Role Change Confirmation/Rejection", strMailBody, HdnAgentId.Value);

        
    }

    private void MailService(string Subject, string MailBody, string Agent_ID)
    {
        DBAccess db = new DBAccess("CRM");
        DataTable dt = new DataTable();
        db.slDataAdd("AgentId", Agent_ID);
        dt = db.ReturnTable("usp_SupervisorEmails", null, true);
        db = null;

        MailSendServiceXX.Service1SoapClient objWSMail = new MailSendServiceXX.Service1SoapClient();
        
        string strTo = dt.Rows[0]["MailTo"].ToString().Replace("Techclearance@NIIT-Tech.com", "HROperations@NIIT-Tech.com");
        string strCC = dt.Rows[0]["MailCC"].ToString();
        string strBcc = dt.Rows[0]["MailBCC"].ToString();
        //int index = strCC.IndexOf(",");
        //string strCCMail = strCC.Remove(index, 1);

        string strFrom = System.Configuration.ConfigurationManager.AppSettings["FROM"];
        //Need to Be UnComment/Comment Whenever Required
        //objWSMail.MailSendNewTech(strTo, Subject, strFrom, "TermsMonitor", MailBody, "", strCC, strBcc, "");
        objWSMail.MailSendNewTech(strTo, Subject, strFrom, "TermsMonitor", MailBody, "", strCC, strBcc, "");              
        objWSMail = null;
       
    }
    
    
}