﻿Imports com.nss.DBAccess
Imports System.Data
Partial Class Staffing_PIP_Default
    Inherits System.Web.UI.Page
#Region " ---- Properties -----"
    Property AgentId() As String
        Get
            Return ViewState("AgentId")
        End Get
        Set(ByVal value As String)
            ViewState("AgentId") = value
        End Set
    End Property
    Property CampaignId() As Integer
        Get
            Return ViewState("CampaignId")
        End Get
        Set(ByVal value As Integer)
            ViewState("CampaignId") = value
        End Set
    End Property
    Property FormId() As Integer
        Get
            Return ViewState("FormId")
        End Get
        Set(ByVal value As Integer)
            ViewState("FormId") = value
        End Set
    End Property
    Property CurrentLevel() As Integer
        Get
            Return ViewState("CurrentLevel")
        End Get
        Set(ByVal value As Integer)
            ViewState("CurrentLevel") = value
        End Set
    End Property
    Property SupervisorID() As String
        Get
            Return ViewState("SupervisorID")
        End Get
        Set(ByVal value As String)
            ViewState("SupervisorID") = value
        End Set
    End Property
    Property UserID() As String
        Get
            Return ViewState("UserID")
        End Get
        Set(ByVal value As String)
            ViewState("UserID") = value
        End Set
    End Property
    Property StartDate() As String
        Get
            Return ViewState("startdate")
        End Get
        Set(ByVal value As String)
            ViewState("startdate") = value
        End Set
    End Property
    Property EndDate() As String
        Get
            Return ViewState("enddate")
        End Get
        Set(ByVal value As String)
            ViewState("enddate") = value
        End Set
    End Property
#End Region
#Region " ---- Load ----"
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            'Session("AgentId") = "nss47671"
            'Session("UserID") = "nss47671"

            AgentId = Session("AgentId")
            SupervisorID = Session("UserID")
            UserID = Session("UserID")
            CurrentLevel = 2

            PanelReports.Controls.Add(Common.GetMenu(Request.Url, AgentId, Request.ApplicationPath))
            FillGrid(SupervisorID)
            lblReportName.CurrentPage = "Fill PIP"
            link2.Text = Session("username") & "(" & Session("UserID") & ")"
            'link2.Text = Session("username") & "(" & UserID & ")"
            Image3.Visible = False
            Image4.Visible = False
            Image5.Visible = False
            Image6.Visible = False
            Image7.Visible = False
            Image8.Visible = False
        End If
    End Sub
#End Region
#Region " ---- Functions ----"
    Private Sub FillGrid(ByVal supervisorid As String)
        GridAgents.Columns(GridAgents.Columns.Count - 1).Visible = True
        Dim db As New DBAccess
        Dim currentdatetime As DateTime = db.ReturnValue("select getdate()", False)
        db = Nothing
        Dim startdt As DateTime = DateTime.Parse(currentdatetime.AddMonths(-1).Year.ToString & "-" & currentdatetime.AddMonths(-1).ToString("MMM") & "-" & "01")
        Dim enddt As DateTime = startdt.AddMonths(1).AddDays(-1)
        StartDate = startdt.ToString("yyyyMMdd")
        EndDate = enddt.ToString("yyyyMMdd")
        db = New DBAccess("CRM")
        Dim dt As DataTable
        db.slDataAdd("SupervisorId", supervisorid)
        ' db.slDataAdd("startDay", StartDate)
        'db.slDataAdd("EndDay", EndDate)
        dt = db.ReturnTable("usp_GetPIPAgents", , True)
        'dt = db.ReturnTable("usp_CalculatePLI", , True)
        GridAgents.DataSource = dt
        GridAgents.DataBind()
        dt = Nothing
        db = Nothing
        GridAgents.Columns(GridAgents.Columns.Count - 1).Visible = False
    End Sub
#End Region
#Region "---- GrdOps ----"
    Protected Sub GridAgents_RowDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles GridAgents.RowDataBound
        If e.Row.RowType = DataControlRowType.DataRow Then
            If e.Row.Cells(e.Row.Cells.Count - 1).Text.ToLower = "false" Or CType(e.Row.FindControl("lblAgentID"), Label).Text = SupervisorID Then
                CType(e.Row.FindControl("lnkbtagentname"), LinkButton).Visible = False
            Else
                CType(e.Row.FindControl("lblAgentName"), Label).Visible = False
            End If
        End If
    End Sub
#End Region
#Region "-----Supervisor change-----"
    Private Sub HideAllSideLinks(ByVal ctrl As LinkButton)
        Dim from As Integer
        from = ctrl.ID.ToLower.Replace("link", "")
        CurrentLevel = from

        Select Case from
            Case 2
                link3.Visible = False
                Link4.Visible = False
                Link5.Visible = False
                Link6.Visible = False
                Link7.Visible = False
                Link8.Visible = False

                Image3.Visible = False
                Image4.Visible = False
                Image5.Visible = False
                Image6.Visible = False
                Image7.Visible = False
                Image8.Visible = False
            Case 3
                Link4.Visible = False
                Link5.Visible = False
                Link6.Visible = False
                Link7.Visible = False
                Link8.Visible = False
                Image4.Visible = False
                Image5.Visible = False
                Image6.Visible = False
                Image7.Visible = False
                Image8.Visible = False
            Case 4

                Link5.Visible = False
                Link6.Visible = False
                Link7.Visible = False
                Link8.Visible = False
                Image5.Visible = False
                Image6.Visible = False
                Image7.Visible = False
                Image8.Visible = False
            Case 5

                Link6.Visible = False
                Link7.Visible = False
                Link8.Visible = False

                Image6.Visible = False
                Image7.Visible = False
                Image8.Visible = False
            Case 6

                Link7.Visible = False
                Link8.Visible = False

                Image7.Visible = False
                Image8.Visible = False
            Case 7

                Link8.Visible = False

                Image8.Visible = False
            Case 8
                'do noting
        End Select




    End Sub
    Protected Sub Sidelink_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles link2.Click

        Dim length As Integer

        length = sender.Text.LastIndexOf(")") - sender.Text.LastIndexOf("(")

        SupervisorID = sender.Text.Substring(sender.Text.LastIndexOf("(") + 1, length - 1)
        FillGrid(SupervisorID)
        HideAllSideLinks(sender)
        sender.CssClass = "selectedlink"
    End Sub
    Protected Sub GridAgents_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles GridAgents.SelectedIndexChanged

        Dim lnk As New LinkButton, img As New Image
        CurrentLevel += 1
        Select Case CurrentLevel
            Case 3
                lnk = link3
                img = Image3
                link2.CssClass = "notselectedlink"
            Case 4
                lnk = Link4
                img = Image4
                link3.CssClass = "notselectedlink"
            Case 5
                lnk = Link5
                img = Image5
                Link4.CssClass = "notselectedlink"
            Case 6
                lnk = Link6
                img = Image6
                Link5.CssClass = "notselectedlink"
            Case 7
                lnk = Link7
                img = Image7
                Link6.CssClass = "notselectedlink"
            Case 8
                lnk = Link8
                img = Image8
                Link7.CssClass = "notselectedlink"
        End Select
        lnk.Text = GridAgents.SelectedDataKey.Item("AgentName").ToString & "(" & GridAgents.SelectedDataKey.Item("AgentID").ToString & ")"
        SupervisorID = GridAgents.SelectedDataKey.Item("AgentID").ToString
        FillGrid(SupervisorID)

        lnk.Visible = True
        lnk.CssClass = "selectedlink"
        img.Visible = True

    End Sub
#End Region
End Class
