﻿Imports Microsoft.VisualBasic
Imports System
Imports System.Collections
Imports System.Collections.Generic
Imports System.Data
Imports System.Diagnostics
Imports com.nss.DBAccess
Imports System.Data.SqlClient
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports System.Configuration
Imports System.Web
Imports System.IO

Partial Public Class Staffing_PIP_FillPIP
    Inherits System.Web.UI.Page

    Private Property supervisorid As String

    Public Property CurrentDate As DateTime
        Get
            Return Convert.ToDateTime(Session("CurrentDate"))
        End Get
        Set(ByVal value As DateTime)
            ViewState("CurrentDate") = value
        End Set
    End Property

    Public Property AgentID As String
        Get
            Return Convert.ToString(ViewState("AgentID"))
        End Get
        Set(ByVal value As String)
            ViewState("AgentID") = value
        End Set
    End Property

    Public Property CampaignID As Int32
        Get
            Return Convert.ToInt32(ViewState("CampaignID"))
        End Get
        Set(ByVal value As Int32)
            ViewState("CampaignID") = value
        End Set
    End Property

    Public Property RoleID As Int32
        Get
            Return Convert.ToInt32(ViewState("RoleID"))
        End Get
        Set(ByVal value As Int32)
            ViewState("RoleID") = value
        End Set
    End Property

    Public Property ProcessID As Int32
        Get
            Return Convert.ToInt32(ViewState("ProcessID"))
        End Get
        Set(ByVal value As Int32)
            ViewState("ProcessID") = value
            Session("ProcessID") = value
        End Set
    End Property
    Property AgentRole() As Integer
        Get
            Return ViewState("AgentRole")
        End Get
        Set(ByVal value As Integer)
            ViewState("AgentRole") = value
        End Set
    End Property
    Property ReportStatus() As Integer
        Get
            Return ViewState("ReportStatus")
        End Get
        Set(ByVal value As Integer)
            ViewState("ReportStatus") = value
        End Set
    End Property
    Property StartDate() As String
        Get
            Return ViewState("startdate")
        End Get
        Set(ByVal value As String)
            ViewState("startdate") = value
        End Set
    End Property
    Property EndDate() As String
        Get
            Return ViewState("enddate")
        End Get
        Set(ByVal value As String)
            ViewState("enddate") = value
        End Set
    End Property

    Property AckStatus() As String
        Get
            Return ViewState("AckStatus")
        End Get
        Set(ByVal value As String)
            ViewState("AckStatus") = value
        End Set
    End Property
    Property FormStatus() As String
        Get
            Return ViewState("FormStatus")
        End Get
        Set(ByVal value As String)
            ViewState("FormStatus") = value
        End Set
    End Property

    Private Sub FillProcessCampaigns()
        Common.FillProcessCampaigns(CboProcess, cboCampaigns, AgentID, CampaignID, ProcessID)
        Dim lstCamp As ListItem = New ListItem()
        lstCamp.Value = "0"
        lstCamp.Text = "All"
        If cboCampaigns.Items.Contains(lstCamp) Then cboCampaigns.Items.Remove(lstCamp)
    End Sub
    Public Shared Sub FillPolicies(ByRef cbopolicies As DropDownList, ByVal AgentID As String, Optional ByVal Processid As Integer = -1)
        Dim db As New DBAccess
        Dim dt As DataTable
        db.slDataAdd("AgentID", AgentID)
        dt = db.ReturnTable("usp_MyProcesses", , True)
        Dim dr As DataRow
        dr = dt.NewRow
        dr("ProcessName") = "All"
        dr("ProcessID") = 0
        dt.Rows.Add(dr)
        db = Nothing
        cbopolicies.DataTextField = "ProcessName"
        cbopolicies.DataValueField = "ProcessID"
        cbopolicies.DataSource = dt
        cbopolicies.DataBind()
        If Processid <> -1 Then
            cbopolicies.Items.FindByValue(Processid).Selected = True

        End If
    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As EventArgs) Handles Me.Load
        'If Not IsPostBack Then

        '    If Session("UserID") <> "" Then
        '        CampaignID = Convert.ToInt32(Session("CampaignID"))
        '        AgentID = Convert.ToString(Session("AgentID"))
        '        FillProcessCampaigns()
        '    End If
        'End If

        HumanMessage.Style("visibility") = "hidden"
        'HumanMessage.Visible = False


        If Not IsPostBack Then
            If Request.QueryString("AgentId") = "" Or Request.QueryString("AgentId") Is Nothing Then
                Server.Transfer("default.aspx")
            End If
            If Session("UserID") <> "" Then
                CampaignID = Convert.ToInt32(Session("CampaignID"))
                AgentID = Convert.ToString(Session("AgentID"))
                FillProcessCampaigns()
            End If

            AgentRole = Request.QueryString("AgentRole")
            AgentID = Request.QueryString("AgentId")
            CampaignID = Request.QueryString("CampId")
            ReportStatus = Request.QueryString("page")
            If Request.QueryString("page") = 1 Then
                ReportQueryString()
                GetAgentDetail()
                GetPreviousFillData()
                GetPreviousFillErrorData()
                GetPreviousFillPolicytableData()
                GetPreviousFillTrainingtableData()
                btnBack.Visible = True
            Else
                GetAgentDetail()
                GetCurrentDate()
                QueryStrings()
                GetPreviousFillData()
                GetPreviousFillErrorData()
                GetPreviousFillPolicytableData()
                GetPreviousFillTrainingtableData()

            End If
        End If

    End Sub
    Property Status() As Integer
        Get
            Return ViewState("Status")
        End Get
        Set(ByVal value As Integer)
            ViewState("Status") = value
        End Set
    End Property
    Property FormId() As String
        Get
            Return ViewState("FormId")
        End Get
        Set(ByVal value As String)
            ViewState("FormId") = value
        End Set
    End Property
    Protected Sub QueryStrings()
        Dim month As Integer = 0
        If (lblMonth.Text.Trim.ToLower() = "january") Then
            month = 1
        ElseIf (lblMonth.Text.Trim.ToLower() = "febuary") Then
            month = 2
        ElseIf (lblMonth.Text.Trim.ToLower() = "March") Then
            month = 3
        ElseIf (lblMonth.Text.Trim.ToLower() = "april") Then
            month = 4
        ElseIf (lblMonth.Text.Trim.ToLower() = "may") Then
            month = 5
        ElseIf (lblMonth.Text.Trim.ToLower() = "june") Then
            month = 6
        ElseIf (lblMonth.Text.Trim.ToLower() = "july") Then
            month = 7
        ElseIf (lblMonth.Text.Trim.ToLower() = "august") Then
            month = 8
        ElseIf (lblMonth.Text.Trim.ToLower() = "september") Then
            month = 9
        ElseIf (lblMonth.Text.Trim.ToLower() = "october") Then
            month = 10
        ElseIf (lblMonth.Text.Trim.ToLower() = "november") Then
            month = 11
        ElseIf (lblMonth.Text.Trim.ToLower() = "december") Then
            month = 12
        End If

        Dim dt As DataTable
        Dim db As New DBAccess("CRM")
        'Dim db As New DBAccess
        Dim str As String
        str = "select FormStatus,formId from tbl_Data_PIP_FormMaster where agentid='" & AgentID & "' and MM='" & month & "'"
        str += " and YYYY='" & lblyear.Text & "' and processid='" & ProcessID & "'"
        dt = db.ReturnTable(str, False)
        If dt.Rows.Count > 0 Then
            Status = dt.Rows(0).Item("FormStatus")
            FormId = dt.Rows(0).Item("formId")
            GetPreviousFillData()
        Else
            Status = 0
            FormId = 0
            lblMonth.Text = Date.Today.AddMonths(-1).ToString("MMMM")

        End If
    End Sub
    Protected Sub btnBack_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnBack.Click
        Response.Redirect("viewPIP.aspx?Process=" & Request.QueryString("ProcessId") & "&Month=" & lblMonth.Text & "&Year=" & lblyear.Text & "&back=1")
    End Sub
    Protected Sub GetPreviousFillData()
        Dim month As Integer = 0
        If (lblMonth.Text.Trim.ToLower() = "january") Then
            month = 1
        ElseIf (lblMonth.Text.Trim.ToLower() = "febuary") Then
            month = 2
        ElseIf (lblMonth.Text.Trim.ToLower() = "March") Then
            month = 3
        ElseIf (lblMonth.Text.Trim.ToLower() = "april") Then
            month = 4
        ElseIf (lblMonth.Text.Trim.ToLower() = "may") Then
            month = 5
        ElseIf (lblMonth.Text.Trim.ToLower() = "june") Then
            month = 6
        ElseIf (lblMonth.Text.Trim.ToLower() = "july") Then
            month = 7
        ElseIf (lblMonth.Text.Trim.ToLower() = "august") Then
            month = 8
        ElseIf (lblMonth.Text.Trim.ToLower() = "september") Then
            month = 9
        ElseIf (lblMonth.Text.Trim.ToLower() = "october") Then
            month = 10
        ElseIf (lblMonth.Text.Trim.ToLower() = "november") Then
            month = 11
        ElseIf (lblMonth.Text.Trim.ToLower() = "december") Then
            month = 12
        End If

        Dim db As New DBAccess("CRM")
        Dim dt As New DataTable
        Dim strQuery As String = "Select * from tbl_Data_PIP_FormMaster where Agentid='" & AgentID & "' and MM='" & month & "' and [YYYY]=" & lblyear.Text & " and processid='" & ProcessID & "'"
        dt = db.ReturnTable(strQuery, False)
        If dt.Rows.Count > 0 Then
            tbxInitiationDate.Text = dt.Rows(0)("IssueDate").ToString
            tbxReviewDate.Text = dt.Rows(0)("ReviewDate").ToString
            tbxReviewperiod.Text = dt.Rows(0)("Period").ToString
            tbxClosureDate.Text = dt.Rows(0)("ReviewDate").ToString
            DDLPIPReason.SelectedValue = dt.Rows(0)("Reason").ToString
            DDLevel.SelectedValue = dt.Rows(0)("Level").ToString

            ProcessID = dt.Rows(0)("ProcessID").ToString
            AckStatus = dt.Rows(0)("AcknowledgmentStatus").ToString
            FormStatus = dt.Rows(0).Item("FormStatus")
            FormId = dt.Rows(0).Item("FormID")
        End If
        dt = Nothing
        db = Nothing

    End Sub
    Protected Sub GetPreviousFillErrorData()
        Dim db As New DBAccess("CRM")
        Dim dt As New DataTable
        Dim strQuery As String = "Select * from tbl_Data_PIPError where Formid='" & FormId & "'"
        dt = db.ReturnTable(strQuery, True)
        gvRotDataDetail.DataSource = dt
        gvRotDataDetail.DataBind()

        dt = Nothing
        db = Nothing

    End Sub
    Protected Sub GetPreviousFillPolicytableData()
        Dim db As New DBAccess("CRM")
        Dim dt As New DataTable
        Dim strQuery As String = "Select * from tbl_Data_PIPPolicyTable where Formid='" & FormId & "'"
        dt = db.ReturnTable(strQuery, True)
        gvPolicyTable.DataSource = dt
        gvPolicyTable.DataBind()

        dt = Nothing
        db = Nothing

    End Sub
    Protected Sub GetPreviousFillTrainingtableData()
        Dim db As New DBAccess("CRM")
        Dim dt As New DataTable
        Dim strQuery As String = "Select * from tbl_Data_PIPTraining where Formid='" & FormId & "'"
        dt = db.ReturnTable(strQuery, True)
        gvTrainingTable.DataSource = dt
        gvTrainingTable.DataBind()

        dt = Nothing
        db = Nothing

    End Sub
    Private Sub GetCurrentDate()
        Dim db As New DBAccess
        Dim currentdatetime As DateTime = db.ReturnValue("select getdate()", False)
        db = Nothing
        lblMonth.Text = currentdatetime.AddMonths(-1).ToString("MMMM")
        lblyear.Text = currentdatetime.AddMonths(-1).Year.ToString
        Dim startdt As DateTime = DateTime.Parse(currentdatetime.AddMonths(-1).Year.ToString & "-" & currentdatetime.AddMonths(-1).ToString("MMM") & "-" & "01")
        Dim enddt As DateTime = startdt.AddMonths(1).AddDays(-1)
        StartDate = startdt.ToString("yyyyMMdd")
        EndDate = enddt.ToString("yyyyMMdd")

    End Sub
    Private Sub ReportQueryString()
        CampaignID = Request.QueryString("CampId")
        tbxEmpCode.Text = AgentID
    End Sub
    Protected Sub GetAgentDetail()

        Dim db As DBAccess = New DBAccess("CRM")
        Dim ds As DataSet = New DataSet()
        db.slDataAdd("Type", "AgentSpecific")

        If AgentID <> "" Then
            db.slDataAdd("AgentId", AgentID)
            db.slDataAdd("Agentname", "")
        End If

        db.slDataAdd("Role", "")
        db.slDataAdd("NewRole", "")
        db.slDataAdd("RequestedBy", "")
        db.slDataAdd("ConfirmedBy", "")
        db.slDataAdd("ConfirmedSatus", "")
        ds = db.ReturnDataset("usp_GetPIPInitiationStage", True)

        If ds.Tables(0).Rows.Count > 0 Then
            tbxEmpCode.Text = ds.Tables(0).Rows(0)("AgentID").ToString()
            tbxName.Text = ds.Tables(0).Rows(0)("AgentName").ToString()
            tbxDesignation.Text = ds.Tables(0).Rows(0)("Designation").ToString()
            RoleID = ds.Tables(0).Rows(0)("RoleID").ToString()
            tbxDateofJoin.Text = ds.Tables(0).Rows(0)("DOJ").ToString()
            tbxReportingManager.Text = ds.Tables(0).Rows(0)("Supervisor").ToString()
            tbxProcess.Text = ds.Tables(0).Rows(0)("ProcessName").ToString()
            tbkCampaign.Text = ds.Tables(0).Rows(0)("CampaignName").ToString()
            tbxIssuer.Text = ds.Tables(0).Rows(0)("AgentName").ToString()
        Else
            lblMessage.Text = "No Employee Code or name in the Term"
            lblMessage.Visible = True
        End If



    End Sub

    <System.Web.Script.Services.ScriptMethod()>
    <System.Web.Services.WebMethod(EnableSession:=True)>
    Public Shared Function GetCompletionList(ByVal prefixText As String, ByVal count As Integer) As List(Of String)
        Return BindAutoFill(prefixText, "AgentId")
    End Function

    Public Shared Function BindAutoFill(ByVal AgentId As String, ByVal AgentName As String) As List(Of String)
        Dim db As DBAccess = New DBAccess("CRM")
        Dim ds As DataSet = New DataSet()
        Dim listDesc As List(Of String) = New List(Of String)()
        db.slDataAdd("Type", "All")
        db.slDataAdd("AgentId", AgentId)
        db.slDataAdd("AgentName", "")
        db.slDataAdd("Role", "")
        db.slDataAdd("NewRole", "")
        db.slDataAdd("RequestedBy", "")
        db.slDataAdd("ConfirmedBy", "")
        db.slDataAdd("ConfirmedSatus", "")
        ds = db.ReturnDataset("usp_GetPIPInitiationStage", True)
        Dim drc As DataRowCollection

        If ds.Tables(0).Rows.Count > 0 Then
            drc = ds.Tables(0).Rows

            For Each dr As DataRow In drc
                listDesc.Add(dr(0).ToString())
            Next

            Return listDesc
        Else
            listDesc.Add("")
            Return listDesc
        End If
    End Function

    Private Sub AlertMessage(ByVal msg As String)
        Try
            lblHumanMessage.Text = msg
            HumanMessage.CssClass = "HMFail"
            HumanMessage.Visible = True
            lblHumanMessage.Visible = True
            HumanMessage.Style("visibility") = "visible"
        Catch ex As Exception
        End Try
    End Sub

    Private Sub SuccessMessage(ByVal msg As String)
        Try
            lblHumanMessage.Text = msg
            HumanMessage.CssClass = "HMSuccess"
            HumanMessage.Visible = True
            lblHumanMessage.Visible = True
            HumanMessage.Style("visibility") = "visible"
        Catch ex As Exception
        End Try
    End Sub

    Public Sub getagents(ByVal agentCode As String)
        Try
            Dim EmpCode As String = ""
            Dim EmpName As String = ""

            If agentCode <> "" Then

                If agentCode.Contains(")") Then
                    Dim strcode As String() = agentCode.Split(New String() {"("}, StringSplitOptions.None)
                    EmpCode = strcode(1).Replace(")", "")
                    Dim strName As String() = agentCode.Split(New String() {"("}, StringSplitOptions.None)
                    EmpName = strcode(0).Replace(".", "")
                End If

                Dim db As DBAccess = New DBAccess("CRM")
                Dim ds As DataSet = New DataSet()
                db.slDataAdd("Type", "AgentSpecific")

                If EmpCode <> "" Then
                    db.slDataAdd("AgentId", EmpCode)
                    db.slDataAdd("Agentname", "")
                ElseIf EmpName <> "" Then
                    db.slDataAdd("AgentId", " ")
                    db.slDataAdd("Agentname", EmpName)
                Else
                    db.slDataAdd("AgentId", agentCode)
                End If

                db.slDataAdd("Role", "")
                db.slDataAdd("NewRole", "")
                db.slDataAdd("RequestedBy", "")
                db.slDataAdd("ConfirmedBy", "")
                db.slDataAdd("ConfirmedSatus", "")
                ds = db.ReturnDataset("usp_GetPIPInitiationStage", True)

                If ds.Tables(0).Rows.Count > 0 Then
                    tbxEmpCode.Text = ds.Tables(0).Rows(0)("AgentID").ToString()
                    tbxName.Text = ds.Tables(0).Rows(0)("AgentName").ToString()
                    tbxDesignation.Text = ds.Tables(0).Rows(0)("Designation").ToString()
                    RoleID = ds.Tables(0).Rows(0)("RoleID").ToString()
                    tbxDateofJoin.Text = ds.Tables(0).Rows(0)("DOJ").ToString()
                    tbxReportingManager.Text = ds.Tables(0).Rows(0)("Supervisor").ToString()
                    tbxProcess.Text = ds.Tables(0).Rows(0)("ProcessName").ToString()
                    tbkCampaign.Text = ds.Tables(0).Rows(0)("CampaignName").ToString()
                    tbxIssuer.Text = ds.Tables(0).Rows(0)("AgentName").ToString()
                Else
                    lblMessage.Text = "No Employee Code or name in the Term"
                    lblMessage.Visible = True
                End If
            Else
                lblMessage.Font.Bold = True
                lblMessage.Text = "Enter Employee Code or name in the Text"
                lblMessage.Visible = True
            End If

        Catch ex As Exception
            ex.ToString()
        End Try
    End Sub

    Protected Sub tbxFromDate_TextChanged(ByVal sender As Object, ByVal e As EventArgs)
        Try

            If tbxFromDate.Text <> "" Then
                Dim Issuedate As DateTime = DateTime.ParseExact(tbxFromDate.Text, "dd-MM-yyyy", System.Globalization.CultureInfo.InvariantCulture)
                tbxFromDate.Text = Issuedate.ToString("dd-MM-yyyy")
            End If

        Catch ex As Exception
            Throw ex
        End Try
    End Sub

    Protected Sub tbxToDate_TextChanged(ByVal sender As Object, ByVal e As EventArgs)
        Try

            If tbxToDate.Text <> "" Then
                Dim Issuedate As DateTime = DateTime.ParseExact(tbxToDate.Text, "dd-MM-yyyy", System.Globalization.CultureInfo.InvariantCulture)
                tbxToDate.Text = Issuedate.ToString("dd-MM-yyyy")
            End If

        Catch ex As Exception
            Throw ex
        End Try
    End Sub
    Protected Sub tbxInitiationDate_TextChanged(ByVal sender As Object, ByVal e As EventArgs)
        Try

            If tbxInitiationDate.Text <> "" Then
                Dim Issuedate As DateTime = DateTime.ParseExact(tbxInitiationDate.Text, "dd-MM-yyyy", System.Globalization.CultureInfo.InvariantCulture)
                tbxInitiationDate.Text = Issuedate.ToString("dd-MM-yyyy")
            End If

        Catch ex As Exception
            Throw ex
        End Try
    End Sub


    Protected Sub tbxRevieweDate_TextChanged(ByVal sender As Object, ByVal e As EventArgs)
        Try

            If tbxReviewDate.Text <> "" Then
                Dim Reviewdate As DateTime = DateTime.ParseExact(tbxReviewDate.Text, "dd-MM-yyyy", System.Globalization.CultureInfo.InvariantCulture)
                tbxReviewDate.Text = Reviewdate.ToString("dd-MM-yyyy")
            End If

        Catch ex As Exception
            Throw ex
        End Try
    End Sub

    Protected Sub tbxClosureDate_TextChanged(ByVal sender As Object, ByVal e As EventArgs)
        Try

            If tbxClosureDate.Text <> "" Then
                Dim Issuedate As DateTime = DateTime.ParseExact(tbxClosureDate.Text, "dd-MM-yyyy", System.Globalization.CultureInfo.InvariantCulture)
                tbxClosureDate.Text = Issuedate.ToString("dd-MM-yyyy")
                tbxReviewperiod.Text = DateDiff(DateInterval.Day, Date.ParseExact(tbxReviewDate.Text, "dd-MM-yyyy", Nothing), Date.ParseExact(tbxClosureDate.Text, "dd-MM-yyyy", Nothing))
            End If

        Catch ex As Exception
            Throw ex
        End Try
    End Sub
    Protected Sub tbxEmpCode_TextChanged(ByVal sender As Object, ByVal e As EventArgs)
        Try

            If tbxEmpCode.Text <> "" Then
                lblMessage.Visible = False
                getagents(tbxEmpCode.Text)
            Else
                lblMessage.Font.Bold = True
                lblMessage.Text = "Enter Employee Code or name in the Text"
                lblMessage.Visible = True
            End If

        Catch ex As Exception
        End Try
    End Sub

    Public Sub Reset()
    End Sub

    Private Sub OpenDialog()
        Dim str As String
        str = "$('#DialogBackground').height($(document).height()-2);$('#DialogBackground').width($(window).width());$('#DialogBackground').css('visibility','visible');$('#PanelIDPForm').css('visibility','visible'); $('#PanelIDPForm').css('left',($(window).width() - $('#PanelIDPForm').width())/2); "
        ScriptManager.RegisterStartupScript(Page, Page.[GetType](), "Movedialog", str, True)
    End Sub
    Private Sub OpenDialog1()
        Dim str As String
        str = "$('#DialogBackground').height($(document).height()-2);$('#DialogBackground').width($(window).width());$('#DialogBackground').css('visibility','visible');$('#PanelIDPForm1').css('visibility','visible'); $('#PanelIDPForm1').css('left',($(window).width() - $('#PanelIDPForm1').width())/2); "
        ScriptManager.RegisterStartupScript(Page, Page.[GetType](), "Movedialog", str, True)
    End Sub
    Private Sub OpenDialog2()
        Dim str As String
        str = "$('#DialogBackground').height($(document).height()-2);$('#DialogBackground').width($(window).width());$('#DialogBackground').css('visibility','visible');$('#PanelIDPForm2').css('visibility','visible'); $('#PanelIDPForm2').css('left',($(window).width() - $('#PanelIDPForm2').width())/2); "
        ScriptManager.RegisterStartupScript(Page, Page.[GetType](), "Movedialog", str, True)
    End Sub
    'Protected Sub btnAddPIPError_Click(sender As Object, e As EventArgs)
    '    Try
    '        OpenDialog()
    '    Catch ex As Exception
    '        AlertMessage(ex.Message)
    '    End Try
    'End Sub

    'Protected Sub btnSaveError_Click(ByVal sender As Object, ByVal e As EventArgs)
    '    Try
    '        Dim pipId As Integer = -1
    '        Dim pipUpdateFlag As Integer = 0
    '        If (btnSaveError.Text = "Update") Then
    '            pipId = Convert.ToInt32(btnSaveError.CommandArgument)
    '            pipUpdateFlag = 1
    '        End If
    '        SavePIPError_NEW(1)


    '    Catch ex As Exception
    '        AlertMessage("Error in btnSaveError_Click. description :- " & ex.Message)
    '    End Try
    'End Sub


    Protected Sub BtnCancel_Click(ByVal sender As Object, ByVal e As EventArgs)
        Try
            Reset()
        Catch ex As Exception
        End Try
    End Sub

    Private Sub MailService(ByVal Subject As String, ByVal MailBody As String, ByVal Agent_ID As String)
        Try
            Dim db As DBAccess = New DBAccess("CRM")
            Dim dt As DataTable = New DataTable()
            db.slDataAdd("AgentId", Agent_ID)
            dt = db.ReturnTable("usp_SupervisorEmails", Nothing, True)
            db = Nothing
            Dim objWSMail As MailSendServiceXX.Service1SoapClient = New MailSendServiceXX.Service1SoapClient()
            Dim strTo As String = dt.Rows(0)("MailTo").ToString().Replace("Techclearance@NIIT-Tech.com", "HROperations@NIIT-Tech.com")
            Dim strCC As String = dt.Rows(0)("MailCC").ToString()
            Dim strBcc As String = dt.Rows(0)("MailBCC").ToString()
            Dim strFrom As String = System.Configuration.ConfigurationManager.AppSettings("FROM")
            objWSMail.MailSendNewTech(strTo, Subject, strFrom, "TermsMonitor", MailBody, "", strCC, strBcc, "")
            objWSMail = Nothing
        Catch ex As Exception
            ex.Message.ToString()
        End Try
    End Sub


    Private Sub SavePIP_NEW(ByVal frmStatus As Integer)

        Dim db As New DBAccess("CRM")
        Dim currentdatetime As DateTime = db.ReturnValue("select getdate()", False)
        Dim FrmID As String
        Try
            db.BeginTrans()
            db.slDataAdd("AgentID", tbxEmpCode.Text.Trim)
            db.slDataAdd("YYYY", Convert.ToInt32(currentdatetime.Year.ToString()))
            db.slDataAdd("MM", Convert.ToInt32(currentdatetime.Month().ToString()))
            db.slDataAdd("ProcessId", ProcessID)
            db.slDataAdd("CampaignId", CampaignID)
            If DDLvertical.SelectedIndex <> -1 Then
                db.slDataAdd("Vertical", DDLvertical.SelectedValue)
            Else
                db.slDataAdd("Vertical", "-1")
            End If

            db.slDataAdd("FromDate", tbxFromDate.Text.Trim())
            db.slDataAdd("ToDate", tbxToDate.Text.Trim())
            db.slDataAdd("IssueDate", tbxInitiationDate.Text.Trim())
            db.slDataAdd("ReviewDate", tbxReviewDate.Text.Trim())
            db.slDataAdd("Period", tbxReviewperiod.Text.Trim)
            If DDLPIPReason.SelectedIndex <> -1 Then
                db.slDataAdd("Reason", DDLPIPReason.SelectedValue)
            Else
                db.slDataAdd("Reason", "-1")
            End If
            db.slDataAdd("ClosureDate", tbxClosureDate.Text.Trim())

            If DDLPIPReason.SelectedIndex <> "-1" Then
                db.slDataAdd("Level", DDLevel.SelectedValue)
            Else
                db.slDataAdd("Level", "-1")
            End If

            db.slDataAdd("Status", 0)

            db.slDataAdd("PIPErrorID", 0)
            db.slDataAdd("PIPPolicyID", 0)
            db.slDataAdd("PIPTrainingID", 0)
            db.slDataAdd("FilledOn", DateTime.Now())
            db.slDataAdd("FilledBy", Session("UserID").ToString())
            db.slDataAdd("FilledDate", DateTime.Now())
            db.slDataAdd("FormStatus", frmStatus)
            db.slDataAdd("TMComment", "")
            db.slDataAdd("AcknowledgmentStatus", 0)
            db.slDataAdd("AcknowledgmentDate", DateTime.Now())
            db.slDataAdd("ModeOfFeedback", 0)

            FrmID = db.ReturnValue("usp_SavePIP_New", True)
            db.CommitTrans()
            If frmStatus = 1 Then
                SuccessMessage("PIP has been saved for " & tbxEmpCode.Text.Trim)
            ElseIf frmStatus = 2 Then
                SuccessMessage("PIP has been Freezed  for " & tbxEmpCode.Text.Trim)
            End If



        Catch ex As Exception
            db.RollBackTrans()
            AlertMessage("All performance drivers are mandatory")
            Return
        Finally
            db = Nothing
        End Try
        ' Response.Redirect("Default.aspx")
    End Sub

    Private Function sendPIPIssuedMailToHR(Optional ByVal AgentN As String = "", Optional ByVal AgentId As String = "", Optional ByVal FromDate As String = "", Optional ByVal ToDate As String = "", Optional ByVal issuedDate As String = "", Optional ByVal ClosureDate As String = "", Optional ByVal ReviewDate As String = "", Optional ByVal ReviewDate1 As String = "", Optional ByVal ReviewDate2 As String = "", Optional ByVal EffectiveDate As String = "", Optional ByVal processName As String = "", Optional ByVal monthName As String = "", Optional ByVal byWhom As String = "", Optional ByVal agentsCSV As String = "") As Boolean
        Try
            'Dim objWSMail As New ServiceReference2.MailSoapClient
            Dim objWSMail As New MailSendServiceXX.Service1SoapClient
            'As New MailSendServiceXX.Service1SoapClient
            Dim strFrom As String = System.Configuration.ConfigurationManager.AppSettings("FROM")
            Dim MailSubject As String = "PIP Issued (" & processName & ")"
            Dim strMailBody As String = ""
            Dim _index As Integer = 1

            Dim AgentName As New StringBuilder


            strMailBody += "<html xmlns='http://www.w3.org/1999/xhtml'>"
            strMailBody += "<body style='font-family: Verdana; font-size: .8em'>"
            strMailBody += "Hi " & AgentN & " (" & AgentId & " )""!!:<br />"
            strMailBody += "<br /><br />"
            strMailBody += "As Discussed on  " & issuedDate & ".:<br /><br />"
            strMailBody += "looking at your performance trends for  from " & FromDate & " To " & ToDate & " we are putting you in PIP 1 effective from " & EffectiveDate & ":<br />"
            strMailBody += "Your performance will be monitored /reviewed on the basis of below mentioned parameters throughout next two weeks.   :<br /> "
            strMailBody += "100% transactions processed would be monitored and you need to keep 100% quality during PIP failing which could lead to next level of PIP (i.e. PIP-2)..   :<br /> <br />"


            strMailBody += "Note - Your Review Dates are  " & ReviewDate1 & " to " & ReviewDate2 & "  :<br /> "
            strMailBody += "Your performance will be monitored and reviewed from " & issuedDate & "and the first review date is " & ReviewDate & "and the date of closure is " & ClosureDate & "   :<br /> "

            strMailBody += "<br /><br />"

            strMailBody += "<table border='1' width='90%' style='border: 1px solid; border-collapse: collapse; font-family: Verdana; font-size: .8em'>"
            strMailBody += "<tr bgcolor='#B8CCE4'>"
            strMailBody += "<td align='center'><b>Focus Area</b></td>"
            strMailBody += "<td align='center'><b>Performance/Observation</b></td>"
            strMailBody += "<td align='center'><b>PIP Target</b></td>"
            strMailBody += "<td align='center'><b>Measure Frequency</b></td>"
            strMailBody += "<td align='center'><b>Support to be Provided</b></td>"
            strMailBody += "<td align='center'><b>Completion Date</b></td>"
            strMailBody += "</tr>"
            strMailBody += "<tr >"
            strMailBody += "<td align='center'>  ??  </td>"
            strMailBody += "<td align='center'>   ??  </td>"
            strMailBody += "<td align='center'>    ?? </td>"
            strMailBody += "<td align='center'> ?? </td>"
            strMailBody += "<td align='center'>  ?? </td>"
            strMailBody += "<td align='center'>  ?? </td>"
            strMailBody += "</tr>"
            strMailBody += "</table>"


            ''strMailBody += "<table border='1' width='90%' style='border: 1px solid; border-collapse: collapse; font-family: Verdana; font-size: .8em'>"
            ''strMailBody += "<tr  bgcolor='#B8CCE4'> "
            ''strMailBody += "<td align='center'><b>Agent  Detail Info</b></td>"
            ''strMailBody += "</tr>"
            ''strMailBody += "<tr>"
            ' ''For Each agent In agentsCSV.Split(",")
            ' ''    AgentName.Append(Convert.ToString(_index) & "). " & agent & ".")
            ' ''    AgentName.Append("</ br>")

            ' ''    _index = _index + 1
            ' ''Next
            ' ''strMailBody += "<td align='center'>" & AgentName.ToString() & "</td>"
            ''strMailBody += "</tr>"
            ''strMailBody += "</table>"

            strMailBody += "<br /><br />"

            'Performance Report for last 3 months and till 15th Nov’19 
            'strMailBody += "<table border='1' width='90%' style='border: 1px solid; border-collapse: collapse; font-family: Verdana; font-size: .8em'>"
            'strMailBody += "<tr bgcolor='#B8CCE4'>"
            'strMailBody += "<td align='center'><b>Month</b></td>"
            'strMailBody += "</tr>"
            'strMailBody += "<tr >"
            'strMailBody += "<td align='center'>  ??  </td>"
            'strMailBody += "</tr>"
            'strMailBody += "</table>"




            strMailBody += "<p>"
            strMailBody += "Thank You."
            strMailBody += "</p>"



            strMailBody += "</body>"
            strMailBody += "</html>"



            ''Live One
            objWSMail.MailSendNewTech(System.Configuration.ConfigurationManager.AppSettings("WSR_PIP_ProcessManager"), MailSubject, "PIP Issue <" & strFrom & ">", "", strMailBody.ToString(), "", "", System.Configuration.ConfigurationManager.AppSettings("BCC"), "") '' Final

            objWSMail = Nothing

            Return True
        Catch ex As Exception
            AlertMessage("Error in sendPIPIssuedMailToHR. description :- " & ex.Message)
            Return False
        End Try
    End Function

    Private Sub SavePolicyTable_NEW(ByVal frmStatus As Integer)
        Dim db As New DBAccess("CRM")

        Dim FrmID As String = ""
        Try
            db.BeginTrans()

            'db.slDataAdd("AgentID", tbxEmpCode.Text.Trim)
            db.slDataAdd("ProcessId", ProcessID)
            db.slDataAdd("CampaignId", CampaignID)
            db.slDataAdd("FormID", FormId)
            db.slDataAdd("ActionPlan", tbxActionPlan.Text.Trim.ToString())
            db.slDataAdd("Target", tbxTarget.Text.Trim.ToString())
            db.slDataAdd("MileStone", tbxMileStone.Text.Trim.ToString())
            db.slDataAdd("PLIImpact", tbxPLIImpact.Text.Trim.ToString())
            db.ReturnValue("usp_SavePIPPolicyTable", True)
            db.CommitTrans()
            db = Nothing


        Catch ex As Exception
            db.RollBackTrans()
            AlertMessage("All Fields  are mandatory")
            Return
        Finally
            db = Nothing
        End Try
        Response.Redirect("Default.aspx")
    End Sub

    Private Sub SaveTrainingTable_NEW(ByVal frmStatus As Integer)
        Dim db As New DBAccess("CRM")

        Dim FrmID As String = ""
        Try
            db.BeginTrans()

            db.slDataAdd("ProcessId", ProcessID)
            db.slDataAdd("CampaignId", CampaignID)
            db.slDataAdd("FormID", FormId)
            db.slDataAdd("TrainingArea", tbxtrainigArea.Text.Trim.ToString())
            db.slDataAdd("TrainingTimeline", tbxTimeline.Text.Trim.ToString())
            db.slDataAdd("Disclaimer", tbxDisclaimer.Text.Trim.ToString())
            db.ReturnValue("usp_SavePIPTrainingTable", True)
            db.CommitTrans()
            db = Nothing


        Catch ex As Exception
            db.RollBackTrans()
            AlertMessage("All Fields  are mandatory")
            Return
        Finally
            db = Nothing
        End Try
        Response.Redirect("Default.aspx")
    End Sub


    Private Sub SavePIPError_NEW(ByVal frmStatus As Integer)
        Dim db As New DBAccess("CRM")
        'Dim db As New DBAccess
        Dim FrmID As String = ""
        Try
            db.BeginTrans()

            db.slDataAdd("ProcessId", ProcessID)
            db.slDataAdd("CampaignId", CampaignID)
            db.slDataAdd("FormID", FormId)
            db.slDataAdd("ErrorDate", ucPIPStartDate.Text.Trim())
            db.slDataAdd("Target", tbxTarget.Text.Trim.ToString())
            db.slDataAdd("Actual", tbxActual.Text.Trim.ToString())
            db.slDataAdd("DetailError", tbxDetailError.Text.Trim.ToString())
            db.ReturnValue("usp_SavePIPError", True)
            db.CommitTrans()
            db = Nothing
        Catch ex As Exception
            db.RollBackTrans()
            AlertMessage("All Fields  are mandatory")
            Return
        Finally
            db = Nothing
        End Try
        Response.Redirect("Default.aspx")
    End Sub
    Protected Sub btnadd_Click(sender As Object, e As EventArgs) Handles btnadd.Click
        Try
            OpenDialog()
        Catch ex As Exception
            AlertMessage(ex.Message)
        End Try
    End Sub

    Protected Sub btnaddTraining_Click(sender As Object, e As EventArgs) Handles btnaddTrainingTable.Click
        Try
            OpenDialog2()
        Catch ex As Exception
            AlertMessage(ex.Message)
        End Try
    End Sub
    Protected Sub btnaddPolicy_Click(sender As Object, e As EventArgs) Handles btnaddPolicyTable.Click
        Try
            OpenDialog1()
        Catch ex As Exception
            AlertMessage(ex.Message)
        End Try
    End Sub


    Protected Sub btnSavePolicyTable_click(sender As Object, e As EventArgs) Handles btnSavePolicyTable.Click
        Try
            Dim pipId As Integer = -1
            Dim pipUpdateFlag As Integer = 0
            If (btnSaveError.Text = "Update") Then
                pipId = Convert.ToInt32(btnSaveError.CommandArgument)
                pipUpdateFlag = 1
            End If
            SavePolicyTable_NEW(1)


        Catch ex As Exception
            AlertMessage("Error in btnSavePolicyTable_Click. description :- " & ex.Message)
        End Try
    End Sub

    Protected Sub btnSaveTrainingTable_click(sender As Object, e As EventArgs) Handles btnSaveTrainingTable.Click
        Try
            Dim pipId As Integer = -1
            Dim pipUpdateFlag As Integer = 0
            If (btnSaveError.Text = "Update") Then
                pipId = Convert.ToInt32(btnSaveError.CommandArgument)
                pipUpdateFlag = 1
            End If
            SaveTrainingTable_NEW(1)


        Catch ex As Exception
            AlertMessage("Error in btnSavePolicyTable_Click. description :- " & ex.Message)
        End Try
    End Sub
    Protected Sub btnSavePIP_Click(sender As Object, e As EventArgs) Handles btnSavePIP.Click
        Try
            Dim pipId As Integer = -1
            Dim pipUpdateFlag As Integer = 0
            If (btnSavePIP.Text = "Update") Then
                pipId = Convert.ToInt32(btnSavePIP.CommandArgument)
                pipUpdateFlag = 1
            End If
            SavePIP_NEW(1)


        Catch ex As Exception
            AlertMessage("Error in btnSavePIP_Click. description :- " & ex.Message)
        End Try
    End Sub



    Protected Sub btnSaveError_Click(sender As Object, e As EventArgs) Handles btnSaveError.Click
        Try
            Dim pipId As Integer = -1
            Dim pipUpdateFlag As Integer = 0
            If (btnSaveError.Text = "Update") Then
                pipId = Convert.ToInt32(btnSaveError.CommandArgument)
                pipUpdateFlag = 1
            End If
            SavePIPError_NEW(1)


        Catch ex As Exception
            AlertMessage("Error in btnSaveError_Click. description :- " & ex.Message)
        End Try
    End Sub
    Private Function ReadWordDoc(filename As String) As Byte()
        Dim fs As New System.IO.FileStream(filename, IO.FileMode.Open, IO.FileAccess.Read)
        Dim br As New System.IO.BinaryReader(fs)
        Dim data() As Byte = br.ReadBytes(CType(fs.Length, Int32))


        'Dim filename As String = Path.GetFileName(filePath)
        'Dim fs As FileStream = New FileStream(filePath, FileMode.Open, FileAccess.Read)
        'Dim br As BinaryReader = New BinaryReader(fs)
        'Dim bytes As Byte() = br.ReadBytes(CType(fs.Length, Int32))
        'br.Close()



        ''Dim data As Byte() = New Byte(fs.Length - 1) {}
        ''fs.Read(data, 0, System.Convert.ToInt32(fs.Length))

        br.Close()
        fs.Close()
        Return data
    End Function
    Private Sub WriteWordDoc(filename As String, data As Byte())
        Dim fs As New System.IO.FileStream(filename, IO.FileMode.Create)

        'Dim data2 As Byte() = New Byte(fs.Length - 1) {}
        'fs.Write(data, 0, System.Convert.ToInt32(fs.Length))



        Dim bw As New System.IO.BinaryWriter(fs)
        bw.Write(data)
        bw.Close()

        fs.Close()
    End Sub
    Protected Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click

        'Dim connCRM As String = Common.connCRM
        'Dim con As New SqlConnection(connCRM)
        'Dim cmd As New SqlCommand("", con)
        ''Dim file As String = "E:\ArvindKumar\temp\Quality and Policy Document\C&R US - Quality and Productivity Policy - V1.1.doc"
        'Dim file As String = "E:\ArvindKumar\temp\Errors Policy\Atrium - Internal and External Errors Policy - Ver 4.0.pdf"




        'Dim doc() As Byte = ReadWordDoc(file)
        'cmd.CommandText = "INSERT INTO tbl_WordDocs (FileName,WordDoc) VALUES(@FILE,@DOC)"
        'cmd.Parameters.AddWithValue("@FILE", file)
        'cmd.Parameters.AddWithValue("@DOC ", doc)
        'con.Open()
        'cmd.ExecuteNonQuery()
        'con.Close()




        '       Dim connCRM As String = Common.connCRM
        '       Dim con As New SqlConnection(connCRM)
        '       Dim cmd As New SqlCommand("", con)
        '       'Dim file As String = "E:\ArvindKumar\temp\Quality and Policy Document\C&R US - Quality and Productivity Policy - V1.1.doc"
        '       Dim filepath As String = "E:\ArvindKumar\temp\Errors Policy\Atrium - Internal and External Errors Policy - Ver 4.0.pdf"

        '       [PolicyId] [int] IDENTITY(1,1) NOT FOR REPLICATION NOT NULL,
        '       [PIPPolicyID]()
        '[FormId] [int] NOT NULL,
        '[FileName] [varchar](max)  NULL,
        '[FilePath] [varchar](max)  NULL,
        '[ContentType] [nvarchar](max) NOT NULL,
        '[Data] [varbinary](max) NOT NULL,
        '[ProcessId] Int NULL,
        '[CampaignId] int NULL,



        '       Dim doc() As Byte = ReadWordDoc(filepath)
        '       cmd.CommandText = "INSERT INTO tbl_Data_PIPPolicy (PIPPolicyID,FormID,Filename,FilePath) VALUES(@FILE,@DOC)"
        '       cmd.Parameters.AddWithValue("@FILE", file)
        '       cmd.Parameters.AddWithValue("@DOC ", doc)
        '       con.Open()
        '       cmd.ExecuteNonQuery()
        '       con.Close()



    End Sub


    Protected Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        'Dim connCRM As String = Common.connCRM
        'Dim con As New SqlConnection(connCRM)
        'Dim cmd As New SqlCommand("", con)
        ''Dim file As String = "E:\ArvindKumar\temp\Quality and Policy Document\C&R US - Quality and Productivity Policy - V1.1.doc"
        'Dim file As String = "E:\ArvindKumar\temp\Errors Policy\Atrium - Internal and External Errors Policy - Ver 4.0.pdf"
        'cmd.CommandText = "SELECT * FROM tbl_WordDocs WHERE FileName = @FILE"
        'cmd.Parameters.AddWithValue("@FILE", file)
        'con.Open()
        'Dim rdr As SqlDataReader = cmd.ExecuteReader
        'If rdr.Read Then
        '    WriteWordDoc(file, rdr("WordDoc"))
        'Else
        '    MsgBox(file & " not found")
        'End If
        'rdr.Close()
        'con.Close()



    End Sub
    Protected Sub View(sender As Object, e As EventArgs)
        Dim embed As String = "<object data=""{0}"" type=""application/pdf"" width=""500px"" height=""300px"">"
        embed += "If you are unable to view file, you can download from <a href = ""{0}"">here</a>"
        embed += " or download <a target = ""_blank"" href = ""http://get.adobe.com/reader/"">Adobe PDF Reader</a> to view the file."
        embed += "</object>"
        'ltEmbed.Text = String.Format(embed, ResolveUrl("~/Files/Mudassar_Khan.pdf"))
        ' ltEmbed.Text = String.Format(embed, ResolveUrl(Server.MapPath("~\\myupload\\" & "Atrium - Internal and External Errors Policy - Ver 4.0.pdf")))
        ' Server.MapPath("~\\myupload\\" & "Training list.xlsx")
    End Sub

    Protected Sub Upload(sender As Object, e As EventArgs)
        Dim FileName As String = String.Empty
        Dim FileSize As String = String.Empty
        Dim extension As String = String.Empty
        Dim FilePath As String = String.Empty

        If (FileUpload1.HasFile) Then

            Dim contentType As String = FileUpload1.PostedFile.ContentType
            extension = Path.GetExtension(FileUpload1.FileName)

            FileName = Path.GetFileName(FileUpload1.PostedFile.FileName)
            FileSize = FileName.Length.ToString() + " Bytes"
            FileUpload1.PostedFile.SaveAs(Server.MapPath("~/Files/" + FileName.Trim()))
            FilePath = "~/Files/" + FileName.Trim().ToString()



            Using fs As Stream = FileUpload1.PostedFile.InputStream
                Using br As BinaryReader = New BinaryReader(fs)

                    Dim bytes As Byte() = br.ReadBytes(Convert.ToInt32(fs.Length))

                    Dim db As New DBAccess("CRM")

                    db.slDataAdd("Name", FileName)
                    db.slDataAdd("ContentType", contentType)
                    db.slDataAdd("Data", bytes)
                    db.slDataAdd("FormID", FormId)
                    db.Executeproc("[usp_Save_MPR_Form_Attachments]")
                    db = Nothing


                End Using


            End Using


        Else

            Label1.Text = "No File Uploaded"





        End If

        Response.Redirect(Request.Url.AbsoluteUri)

    End Sub

    Protected Sub DownloadFile(sender As Object, e As EventArgs)

    End Sub

    Protected Sub btnSubmitPIP_Click(sender As Object, e As EventArgs) Handles btnFreeze.Click

        Try
            Dim pipId As Integer = -1
            Dim pipUpdateFlag As Integer = 0
            If (btnFreeze.Text = "Update") Then
                pipId = Convert.ToInt32(btnFreeze.CommandArgument)
                pipUpdateFlag = 1
            End If
            SavePIP_NEW(2)

            sendPIPIssuedMailToHR(tbxName.Text, tbxEmpCode.Text, tbxFromDate.Text, tbxToDate.Text, tbxInitiationDate.Text, tbxReviewDate.Text, tbxReviewDate.Text, tbxReviewDate.Text, tbxReviewDate.Text, CboProcess.SelectedItem.Text, lblMonth.Text, tbxReportingManager.Text, "")
        Catch ex As Exception
            AlertMessage("Error in btnSubmitPIP_Click. description :- " & ex.Message)
        End Try
    End Sub
End Class
