﻿Imports com.nss.DBAccess
Imports System.Data
Imports System.Text
Partial Class Attendance_MovementLog
    Inherits System.Web.UI.Page
#Region "Properties"
    Property ReportType() As Integer
        Get
            Return ViewState("ReportType")
        End Get
        Set(ByVal value As Integer)
            ViewState("ReportType") = value
        End Set
    End Property
    Property CampaignID() As Integer
        Get
            Return ViewState("CampaignID")
        End Get
        Set(ByVal value As Integer)
            ViewState("CampaignID") = value
        End Set
    End Property

    Property AgentID() As String
        Get
            Return ViewState("AgentID")
        End Get
        Set(ByVal value As String)
            ViewState("AgentID") = value
        End Set
    End Property
#End Region
    Private Sub LoadData()
        FillCommonFilters()

    End Sub

    Private Sub FillCommonFilters()
        Dim db As New DBAccess
        Dim dt As DataTable = db.ReturnTable("select * from tbl_Reports_DatePeriods")
        db = Nothing
        Dim dr As DataRow = dt.NewRow
        dr(0) = 10
        dr(1) = "Between"
        dt.Rows.Add(dr)
        CboPeriod.DataTextField = "Caption"
        CboPeriod.DataValueField = "Period"
        CboPeriod.DataSource = dt
        CboPeriod.DataBind()
    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        HumanMessage.Style.Item("visibility") = "hidden"
        If Not IsPostBack Then
            If Session("AgentID") <> "" Then
                CampaignID = Session("CampaignID")
                AgentID = Session("AgentID")
                PanelReports.Controls.Add(Common.GetMenu(Request.Url, AgentID, Request.ApplicationPath))
                LoadData()
                fillgrid()
                UcDateTo.Visible = False
                ucDateFrom.Visible = False
                lblAnd.Visible = False
            End If
        End If
    End Sub

    Private Sub fillgrid()
        Dim db As DBAccess
        Dim startday As Integer, endday As Integer
        If CboPeriod.SelectedValue = 10 Then
            startday = ucDateFrom.yyyymmdd
            endday = UcDateTo.yyyymmdd
        Else
            db = New DBAccess
            db.slDataAdd("Period", CboPeriod.SelectedValue)
            db.slDataAdd("Campaignid", CampaignID)
            Dim dr As DataRow = db.ReturnRow("usp_GetStart_EndDateForAPeriod", True)
            db = Nothing
            startday = dr(0)
            endday = dr(1)
        End If
       
        db = New DBAccess
        Dim dt As DataTable
        db.slDataAdd("startday", startday)
        db.slDataAdd("endDay", endday)
        dt = db.ReturnTable("usp_MovementHistory", , True)

        breadcrumbs.CurrentPage = " Movement History between " & startday & " and " & endday
        'LblError.Text = "Between " & IntegerToDateString(dr(0)) & "  and " & IntegerToDateString(dr(1))
        
        db = Nothing

        GdAttendance.DataSource = dt
        GdAttendance.DataBind()
        'System.Threading.Thread.Sleep(100)
    End Sub

    Protected Sub CboPeriod_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles CboPeriod.SelectedIndexChanged
        If CboPeriod.SelectedValue = 10 Then
            ucDateFrom.Visible = True
            UcDateTo.Visible = True
            lblAnd.Visible = True
            fillgrid()
        Else
            ucDateFrom.Visible = False
            UcDateTo.Visible = False
            lblAnd.Visible = False
            fillgrid()
        End If
    End Sub

    Protected Sub GdAttendance_RowCommand(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewCommandEventArgs) Handles GdAttendance.RowCommand
        Dim row As GridViewRow = CType(CType(e.CommandSource, Control).NamingContainer, GridViewRow)
        If e.CommandName = "Approve" Then
            row.FindControl("lnkApprove").Visible = False
            row.FindControl("lnkReject").Visible = False
            row.FindControl("lblStatus").Visible = True
            CType(row.FindControl("lblStatus"), Label).Text = "Approved"
        ElseIf e.CommandName = "Reject" Then
            row.FindControl("lnkApprove").Visible = False
            row.FindControl("lnkReject").Visible = False
            row.FindControl("lblStatus").Visible = True
            CType(row.FindControl("lblStatus"), Label).Text = "Rejected"
        End If
        CType(row.FindControl("lblApprovedBy"), Label).Text = "You"
        CType(row.FindControl("lblYesNo"), Label).Text = "Pending"
    End Sub

    Protected Sub ucDateFrom_Changed(ByVal sender As Object, ByVal e As System.EventArgs) Handles ucDateFrom.Changed
        fillgrid()
    End Sub
    Protected Sub UcDateTo_Changed(ByVal sender As Object, ByVal e As System.EventArgs) Handles UcDateTo.Changed
        fillgrid()
    End Sub

    Protected Sub imgfav_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles imgfav.Click
        Common.AddToFav(AgentID, "Movement Log")
        SuccessMessage("Report has been added to your favourite list")
        fillgrid()
    End Sub
    Protected Sub ImageButton1_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton1.Click
        fillgrid()
        GridViewExportUtil.Export(breadcrumbs.CurrentPage & ".xls", Me.GdAttendance)
    End Sub
#Region "Utility"

    Private Sub AlertMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMFail"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub

    Private Sub SuccessMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMSuccess"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub

    'Protected Sub ImageButton1_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton1.Click
    '    'fillgrid()
    '    GridViewExportUtil.Export(lblReportName.CurrentPage & "-" & LblError.Text & ".xls", Me.GdAttendance)
    'End Sub


    Public Overrides Sub VerifyRenderingInServerForm(ByVal Control As Control)

    End Sub

#End Region
End Class
