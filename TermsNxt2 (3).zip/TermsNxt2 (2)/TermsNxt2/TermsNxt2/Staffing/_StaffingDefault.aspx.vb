﻿Imports com.nss.DBAccess
Imports LibFolder.TermsNxt2

Public Class StaffingDefault
    Inherits System.Web.UI.Page

    'Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

    'End Sub

#Region "Properties"

    Property CampaignID() As Integer
        Get
            Return ViewState("CampaignID")
        End Get
        Set(ByVal value As Integer)
            ViewState("CampaignID") = value
        End Set
    End Property

    Property AgentID() As String
        Get
            Return ViewState("AgentID")
        End Get
        Set(ByVal value As String)
            ViewState("AgentID") = value
        End Set
    End Property
    Property ChartPeriod() As Integer
        Get
            Return ViewState("ChartPeriod")
        End Get
        Set(ByVal value As Integer)
            ViewState("ChartPeriod") = value
        End Set
    End Property
#End Region
    Private Sub CreateChartPreview()
        Dim chart As Panel, img As Image
        Dim ictr As Integer
        ChartContainerInner.Style.Item("width") = 3200
    End Sub
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        If Not IsPostBack Then
            If Session("AgentID") <> "" Then
                CampaignID = Session("CampaignID")
                AgentID = Session("AgentID")
                Redirect()
                'Panelmenu.Controls.Add(Common.GetMenu(Request.Url, AgentID,Request.ApplicationPath))
                'Todaynotmarkedattendance()
                'FillProcessCampaigns()
                ''FillFilters()
                'FillGraph()
            End If

        End If
    End Sub
    Private Sub Redirect()
        Dim db As New DBAccess
        db.slDataAdd("agentid", AgentID)
        db.slDataAdd("module", 1)
        Dim url As String = db.ReturnValue("usp_getTop1ReportTerm2", True)
        db = Nothing
        Dim page() As String = url.Split("/")
        Response.Redirect(page(1))
    End Sub
    Private Sub Todaynotmarkedattendance()
        Dim db As New DBAccess
        db.slDataAdd("agentid", AgentID)
        Dim dt As DataTable = db.ReturnTable("usp_GetAttendanceMarkedAlert", , True)
        db = Nothing
        gridview1.DataSource = dt
        gridview1.DataBind()
        dt = Nothing
    End Sub
    'Private Sub FillFilters()
    '    Common.FillDatePeriod(cboChartPeriod)
    'End Sub

    Private Sub FillProcessCampaigns()
        Common.FillProcessCampaigns(CboProcess, cboCampaigns, AgentID, CampaignID)
    End Sub
    'Protected Sub cboChartPeriod_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboChartPeriod.SelectedIndexChanged
    '    FillGraph()
    'End Sub

    Private Sub FillGraph()
        ChartContainerInner.Controls.Clear()
        Dim objLink As HyperLink
        Dim objImg As Image
        For ictr = 0 To 2
            objLink = New HyperLink
            objLink.NavigateUrl = "../Graphs/EnlargedGraph.aspx?type=Attendance&KPA=" & ictr + 1 & "&GraphSize=200&CampaignID=" & cboCampaigns.SelectedValue & "&GroupBy=" & cboGroupby.SelectedValue & "&period=" & cboChartPeriod.SelectedValue
            objLink.ID = "lnkKPA" & ictr + 1
            objImg = New Image
            objImg.ImageUrl = "../Graphs/thumbgraph.aspx?type=Attendance&KPA=" & ictr + 1 & "&GraphSize=200&CampaignID=" & cboCampaigns.SelectedValue & "&GroupBy=" & cboGroupby.SelectedValue & "&period=" & cboChartPeriod.SelectedValue
            objImg.ID = "imgKPA" & ictr + 1
            objImg.CssClass = "chart"
            objLink.Controls.Add(objImg)
            ChartContainerInner.Controls.Add(objLink)
        Next

    End Sub

    Protected Sub cboCampaigns_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboCampaigns.SelectedIndexChanged
        Panelmenu.Controls.Add(Common.GetMenu(Request.Url, AgentID, Request.ApplicationPath))
        Todaynotmarkedattendance()
        FillGraph()
    End Sub

    'Protected Sub cboGraphType_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboGraphType.SelectedIndexChanged
    '    Panelmenu.Controls.Add(Common.GetMenu(Request.Url, AgentID,Request.ApplicationPath))
    '    Todaynotmarkedattendance()
    '    FillGraph()
    'End Sub

    Protected Sub cboGroupby_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboGroupby.SelectedIndexChanged
        Panelmenu.Controls.Add(Common.GetMenu(Request.Url, AgentID, Request.ApplicationPath))
        Todaynotmarkedattendance()
        FillGraph()
    End Sub

    Protected Sub cboChartPeriod_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboChartPeriod.SelectedIndexChanged
        ChartPeriod = cboChartPeriod.SelectedValue
        'If ChartPeriod = 0 Then
        '    ChartGroupBy = 4
        'Else
        '    ChartGroupBy = 3
        'End If
        FillGraph()
    End Sub

    Protected Sub btnRefresh_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnRefresh.Click
        Panelmenu.Controls.Add(Common.GetMenu(Request.Url, AgentID, Request.ApplicationPath))
        Todaynotmarkedattendance()
        FillGraph()
    End Sub

End Class