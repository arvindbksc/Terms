﻿Imports com.nss.DBAccess
Imports System.Data
Imports System.Text
Partial Class Staffing_AttendanceHistory
    Inherits System.Web.UI.Page
#Region "Properties"
    Property ReportType() As Integer
        Get
            Return ViewState("ReportType")
        End Get
        Set(ByVal value As Integer)
            ViewState("ReportType") = value
        End Set
    End Property
    Property CampaignID() As Integer
        Get
            Return 0 'ViewState("CampaignID")
        End Get
        Set(ByVal value As Integer)
            'ViewState("CampaignID") = value
        End Set
    End Property

    Property AgentID() As String
        Get
            Return ViewState("AgentID")
        End Get
        Set(ByVal value As String)
            ViewState("AgentID") = value
        End Set
    End Property
#End Region
    Private Sub LoadData()
        UcDateTo.value = DateTime.Now
        ucDateFrom.value = DateTime.Now.AddMonths(-1).AddDays(21 - DateTime.Now.Day)
        Common.FillProcessCampaigns(CboProcess, cboCampaigns, AgentID, CampaignID)
        'lblDate.Text = "Aprroved cases will be processed tomorrow" & DateTime.Now.ToString("dd-MMM-yyyy") & " at 6:30 AM IST."

    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            If Session("AgentID") <> "" Then
                CampaignID = Session("CampaignID")
                AgentID = Session("AgentID")
                LoadData()
                fillData()
                PanelReports.Controls.Add(Common.GetMenu(Request.Url, AgentID, Request.ApplicationPath))
            End If
        End If
    End Sub
    Private Sub fillData()
        Dim startdate As Date, enddate As Date
        startdate = ucDateFrom.value
        enddate = UcDateTo.value
        Dim db As New DBAccess
        Dim dt As DataTable
        db.slDataAdd("StartDate", ucDateFrom.yyyymmdd)
        db.slDataAdd("EndDate", UcDateTo.yyyymmdd)
        db.slDataAdd("userid", AgentID)
        dt = db.ReturnTable("usp_AttendanceHistoryCampaign", , True)
        db = Nothing
        lblReportName.Text = " Attendance History "
        campaign.DataSource = dt
        campaign.DataBind()
        dt = Nothing
    End Sub
    
    Protected Sub ucDateFrom_Changed(ByVal sender As Object, ByVal e As System.EventArgs) Handles ucDateFrom.Changed
        fillData()
    End Sub

    Protected Sub UcDateTo_Changed(ByVal sender As Object, ByVal e As System.EventArgs) Handles UcDateTo.Changed
        fillData()
    End Sub

    Protected Sub ImageButton1_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton1.Click
        fillData()
        'GridViewExportUtil.Export(lblReportName.Text & "-" & LblError.Text & ".xls", Me.dgdata)
    End Sub


    Public Overrides Sub VerifyRenderingInServerForm(ByVal Control As Control)

    End Sub

    Protected Sub CboProcess_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles CboProcess.SelectedIndexChanged
        Common.FillCampaigns(cboCampaigns, AgentID, CboProcess.SelectedValue)
        fillData()
    End Sub

    Protected Sub cboCampaigns_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboCampaigns.SelectedIndexChanged
        fillData()
    End Sub

    Protected Sub campaign_ItemDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.RepeaterItemEventArgs) Handles campaign.ItemDataBound
        Dim lblcampid As Label = e.Item.FindControl("lblcampid")
        Dim db As New DBAccess
        Dim startdate As Date, enddate As Date
        startdate = ucDateFrom.value
        enddate = UcDateTo.value
        Dim dt As DataTable
        db.slDataAdd("StartDate", ucDateFrom.yyyymmdd)
        db.slDataAdd("EndDate", UcDateTo.yyyymmdd)
        db.slDataAdd("userid", AgentID)
        db.slDataAdd("campaignid", lblcampid.Text)
        dt = db.ReturnTable("usp_AttendanceHistory", , True)
        Dim dgdata As GridView = e.Item.FindControl("GdAttendance")
        db = Nothing
        dgdata.AutoGenerateColumns = False
        If dt.Rows.Count > 0 Then
            For inCtr = 3 To dt.Columns.Count - 3
                ' tpending = tpending + drPackage("Files in Que") + drPackage("Files Pending")
                Dim bc1 As New BoundField
                bc1.DataField = dt.Columns.Item(inCtr).ToString
                bc1.HeaderText = dt.Columns.Item(inCtr).ToString
                'bc1.SortExpression = drPackage.GetName(inCtr)
                dgdata.Columns.Add(bc1)
            Next
        Else

        End If
        AddHandler dgdata.RowDataBound, AddressOf dgdata_RowCreated
        dgdata.DataSource = dt
        dgdata.DataBind()
    End Sub
    Protected Sub dgdata_RowCreated(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs)
        Try
            Dim dgdata As GridView = sender

            Dim footerval(dgdata.Columns.Count - 1) As Integer
            If e.Row.RowType = DataControlRowType.Footer Then
                For Each row As GridViewRow In dgdata.Rows
                    For i As Integer = 1 To footerval.Length - 1
                        footerval(i) += row.Cells(i).Text
                    Next
                Next
                e.Row.Cells(0).Text = "Total: "
                For i As Integer = 1 To footerval.Length - 1
                    e.Row.Cells(i).Text = footerval(i)
                Next

            End If

        Catch ex As Exception

        End Try

    End Sub
End Class
