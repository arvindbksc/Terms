﻿Imports com.nss.DBAccess
Imports System.Data
Partial Class Staffing_AttendanceDetail
    Inherits System.Web.UI.Page
#Region "--- Properties ---"
    Property AgentID() As String
        Get
            Return ViewState("AgentID")
        End Get
        Set(ByVal value As String)
            ViewState("AgentID") = value
        End Set
    End Property
#End Region

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            Try
                If Session("AgentID") <> "" Then
                    AgentID = Session("AgentID")
                Else
                    Response.Redirect("AttendanceSummary.aspx")
                End If
                If Request.QueryString("group") <> "" And Request.QueryString("Page") = "AttendanceSummary" Then
                    fillgridAttendanceSummary()

                ElseIf Request.QueryString("CampaignID") <> "" And Request.QueryString("Page") = "AttendanceTracker" Then
                    fillgridAttendanceTracker()

                Else
                    Response.Redirect("AttendanceSummary.aspx")
                End If
                PanelReports.Controls.Add(Common.GetMenu(Request.Url, AgentID, Request.ApplicationPath))
            Catch ex As Exception
                Response.Redirect("AttendanceSummary.aspx")
            End Try
        End If
    End Sub

    Private Sub fillgridAttendanceTracker()
        Dim db As New DBAccess("CRM")
        Dim dt As New DataTable

        db.slDataAdd("StartDate", Request.QueryString("from"))
        db.slDataAdd("EndDate", Request.QueryString("to"))
        db.slDataAdd("UserID", Request.QueryString("AgentID"))
        db.slDataAdd("ProcessID", Request.QueryString("processID"))
        db.slDataAdd("CampaignID", Request.QueryString("CampaignID"))

             dt = db.ReturnTable("usp_AttendanceRegister", , True)
        gdAttendanceDetail.DataSource = dt
        gdAttendanceDetail.DataBind()
        'If Request.QueryString("group") = 3 Then
        '    breadcrumbs.CurrentPage = " Attendance Detail for " & dt.Rows(0)(0).ToString
        'ElseIf Request.QueryString("group") = 2 Then
        '    breadcrumbs.CurrentPage = " Attendance Detail for " & Request.QueryString("Supervisor")
        'Else
        '    breadcrumbs.CurrentPage = " Attendance Detail for " & Request.QueryString("val")
        'End If

    End Sub
    Private Sub fillgridAttendanceSummary()
        Dim db As New DBAccess
        Dim dt As New DataTable

        db.slDataAdd("Process", Request.QueryString("process"))
        db.slDataAdd("Group", Request.QueryString("group"))
        If Request.QueryString("val").Contains("-") Then
            db.slDataAdd("val", Request.QueryString("val").Replace("-", "/"))
        Else
            db.slDataAdd("val", Request.QueryString("val"))
        End If

        db.slDataAdd("FromDate", Request.QueryString("from"))
        db.slDataAdd("ToDate", Request.QueryString("to"))
        dt = db.ReturnTable("usp_getAttendancedetail", , True)
        gdAttendanceDetail.DataSource = dt
        gdAttendanceDetail.DataBind()
        If Request.QueryString("group") = 3 Then
            breadcrumbs.CurrentPage = " Attendance Detail for " & dt.Rows(0)(0).ToString
        ElseIf Request.QueryString("group") = 2 Then
            breadcrumbs.CurrentPage = " Attendance Detail for " & Request.QueryString("Supervisor")
        Else
            breadcrumbs.CurrentPage = " Attendance Detail for " & Request.QueryString("val")
        End If

    End Sub
    Protected Sub ImageButton1_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton1.Click
        fillgridAttendanceSummary()
        GridViewExportUtil.Export(breadcrumbs.CurrentPage & ".xls", Me.gdAttendanceDetail)
    End Sub

    Protected Sub btnBack_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnBack.Click
        Response.Redirect("AttendanceSummary.aspx?value=return&Process=" & Request.QueryString("process") & "&group=" & Request.QueryString("group") & "&Period=" & Request.QueryString("Period") & "&filter=" & Request.QueryString("val") & "&FromDate=" & Request.QueryString("from") & "&ToDate=" & Request.QueryString("to"))
    End Sub
End Class
