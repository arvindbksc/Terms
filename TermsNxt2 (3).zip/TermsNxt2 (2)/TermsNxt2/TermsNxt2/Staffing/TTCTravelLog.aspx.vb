﻿Imports com.nss.DBAccess
Imports System.Data
Imports System.Text
Imports System.IO

Partial Class Staffing_TTCTravelLog
    Inherits System.Web.UI.Page
#Region "Properties"

    Property ProcessID() As Integer
        Get
            Return ViewState("ProcessID")
        End Get
        Set(ByVal value As Integer)
            ViewState("ProcessID") = value
            Session("ProcessID") = value
        End Set
    End Property

    Property CampaignID() As Integer
        Get
            Return ViewState("CampaignID")
        End Get
        Set(ByVal value As Integer)
            ViewState("CampaignID") = value
        End Set
    End Property

    Property AgentID() As String
        Get
            Return ViewState("AgentID")
        End Get
        Set(ByVal value As String)
            ViewState("AgentID") = value
        End Set
    End Property
#End Region
    Private Sub LoadData()
        FillCommonFilters()
        FillAgents()
        FillProcessCampaigns()
    End Sub
    Private Sub FillCommonFilters()
        Dim db As New DBAccess
        Dim dt As DataTable = db.ReturnTable("select * from tbl_Reports_DatePeriods")
        db = Nothing
        Dim dr As DataRow = dt.NewRow
        dr(0) = 10
        dr(1) = "Between"
        dt.Rows.Add(dr)
        CboPeriod.DataTextField = "Caption"
        CboPeriod.DataValueField = "Period"
        CboPeriod.DataSource = dt
        CboPeriod.DataBind()
        dt = Nothing

    End Sub
    Protected Sub FillAgents()
        Dim db As New DBAccess("CRM")
        Dim dt As DataTable
        db.slDataAdd("campaignid", CampaignID)
        'db.slDataAdd("UserId", AgentID)
        dt = db.ReturnTable("usp_GetAgentsOfTheProcess", , True)
        db = Nothing
        Dim dr1 As DataRow = dt.NewRow
        dr1(2) = "All"
        dr1(0) = "0"
        dt.Rows.Add(dr1)
        CboAgent.DataTextField = "Agent Name"
        CboAgent.DataValueField = "agentid"
        CboAgent.DataSource = dt
        CboAgent.DataBind()
        dt = Nothing
    End Sub
    Private Sub FillProcessCampaigns()
        Common.FillProcessCampaigns(CboProcess, cboCampaigns, AgentID, CampaignID)
    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        HumanMessage.Style.Item("visibility") = "hidden"
        If Not IsPostBack Then
            If Session("AgentID") <> "" Then
                'ucDateFrom.Text = DateTime.Now.ToString("dd-MMM-yyyy")
                'UcDateTo.Text = DateTime.Now.ToString("dd-MMM-yyyy")
                CampaignID = Session("CampaignID")
                AgentID = Session("AgentID")
                PanelReports.Controls.Add(Common.GetMenu(Request.Url, AgentID, Request.ApplicationPath))
                LoadData()
                fillgrid()
                UcDateTo.Visible = False
                ucDateFrom.Visible = False
                lblAnd.Visible = False
            End If
        End If
    End Sub
    Protected Sub cboCampaigns_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboCampaigns.SelectedIndexChanged
        CampaignID = cboCampaigns.SelectedValue
        FillAgents()
        fillgrid()
    End Sub
    Protected Sub ImageButton1_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton1.Click
        fillgrid()
        GridViewExportUtil.Export(lblReportName.Text & "-" & LblError.Text & ".xls", Me.GridView1)
    End Sub

    Private Sub ExportToexcel()
        Dim tw As New IO.StringWriter()
        Dim hw As New System.Web.UI.HtmlTextWriter(tw)
        'Dim frm As HtmlForm = New HtmlForm()
        Response.ContentType = "application/vnd.ms-excel"
        Response.AddHeader("content-disposition", "attachment;filename=" & lblReportName.Text & ".xls")
        Response.Charset = ""
        EnableViewState = False
        'Controls.Add(frm)
        GridView1.RenderControl(hw)
        Response.Write(tw.ToString())
        Response.End()
    End Sub
    Protected Sub btnRefresh_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnRefresh.Click
        fillgrid()
    End Sub
    Protected Sub CboPeriod_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles CboPeriod.SelectedIndexChanged
        If CboPeriod.SelectedValue = 10 Then
            ucDateFrom.Visible = True
            UcDateTo.Visible = True
            lblAnd.Visible = True
            fillgrid()
        Else
            ucDateFrom.Visible = False
            UcDateTo.Visible = False
            lblAnd.Visible = False
            fillgrid()
        End If
    End Sub
    Private Sub fillgrid()
        'Dim columns As String
        Dim db As New DBAccess
        Dim startday As Integer, endday As Integer
        If CboPeriod.SelectedValue = 10 Then
            startday = ucDateFrom.yyyymmdd
            endday = UcDateTo.yyyymmdd
        Else
            db = New DBAccess
            db.slDataAdd("Period", CboPeriod.SelectedValue)
            db.slDataAdd("Campaignid", CampaignID)
            Dim dr As DataRow = db.ReturnRow("usp_GetStart_EndDateForAPeriod", True)
            db = Nothing
            startday = dr(0)
            endday = dr(1)
        End If

        db = New DBAccess("Leads")
        Dim dt As New DataTable
        db.slDataAdd("startday", startday)
        db.slDataAdd("endDay", endday)

        db.slDataAdd("AgentId", CboAgent.SelectedValue)
        db.slDataAdd("Campaignid", cboCampaigns.SelectedValue)
        dt = db.ReturnTable("usp_TTCTravelLog", , True)
        lblReportName.Text = "TTC Travel Log Summary "
        LblError.Text = "Between " & IntegerToDateString(startday) & "  and " & IntegerToDateString(endday) & " "

        db = Nothing
        GridView1.AutoGenerateColumns = False
        CreateGridColumns(dt.Columns)

        
        GridView1.DataSource = dt
        GridView1.DataBind()

        dt = Nothing
    End Sub
    Public Function ReadCsvToTable(ByVal filename As String) As DataTable
        Dim sr As StreamReader = File.OpenText(filename)

        Dim values As New Collections.Specialized.StringCollection
        values.AddRange(sr.ReadLine.Split(","))

        Dim table As New DataTable("table")
        Dim enumerator As Collections.Specialized.StringEnumerator
        enumerator = values.GetEnumerator()
        While enumerator.MoveNext
            table.Columns.Add(New DataColumn(enumerator.Current, GetType(String)))
        End While

        Dim row As DataRow
        Dim ordinal As Byte
        Dim buffer As New StringBuilder()
        Do While sr.EndOfStream = False
            If buffer.Length > 0 Then
                buffer.Remove(0, buffer.Length - 1) 'clear the buffer
            End If
            values.Clear() 'clear the values
            buffer.Append(sr.ReadLine()) 'read a line 
            values.AddRange(buffer.ToString().Split(","))

            row = table.NewRow()
            enumerator = values.GetEnumerator()
            ordinal = 0
            While enumerator.MoveNext
                row(ordinal) = enumerator.Current
                ordinal += 1
            End While
            table.Rows.Add(row)
        Loop

        Return table
    End Function
    Private Sub CreateGridColumns(ByVal cols As DataColumnCollection)
        GridView1.Columns.Clear()
        Dim tempcolumn As TemplateField
        Dim bouncol As BoundField
        Dim objcol As DataColumn
        For Each objcol In cols
            If objcol.ColumnName = "Agents" Then
                tempcolumn = New TemplateField
                Dim tmpagcol As New TemplateAgentName
                tempcolumn.HeaderText = "Agents"
                tmpagcol.DataImageField = "AgentStatus"
                tmpagcol.DataTextField = objcol.ColumnName
                tempcolumn.ItemStyle.HorizontalAlign = HorizontalAlign.Left
                tempcolumn.ItemTemplate = tmpagcol
                GridView1.Columns.Add(tempcolumn)
            Else
                If objcol.ColumnName <> "Agentstatus" Then
                    bouncol = New BoundField
                    bouncol.HeaderText = objcol.ColumnName
                    bouncol.DataField = objcol.ColumnName


                    GridView1.Columns.Add(bouncol)
                End If

            End If

        Next


    End Sub
    Private Function IntegerToDateString(ByVal d As Integer) As String
        Return d.ToString.Substring(0, 4) & "-" & d.ToString.Substring(4, 2) & "-" & d.ToString.Substring(6, 2)
    End Function

    Protected Sub CboAgent_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles CboAgent.SelectedIndexChanged
        fillgrid()
    End Sub
    Protected Sub GridView1_RowDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles GridView1.RowDataBound
        If e.Row.RowType = DataControlRowType.DataRow Then
            If e.Row.Cells(2).Text.Contains("1900") Then
                e.Row.Cells(2).Text = "NA"
                e.Row.Cells(3).Text = "NA"
            End If
            If e.Row.Cells(4).Text = "True" Then
                e.Row.BackColor = Drawing.Color.LightGray
                e.Row.Cells(4).ForeColor = Drawing.Color.Black
            End If
        End If
    End Sub

    Protected Sub imgfav_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles imgfav.Click
        Common.AddToFav(AgentID, "TTC Travel Agent Log Summary")
        SuccessMessage("Report has been added to your favourite list")
        fillgrid()
    End Sub
#Region "Utility"

    Private Sub AlertMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMFail"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub

    Private Sub SuccessMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMSuccess"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub

    'Protected Sub ImageButton1_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton1.Click
    '    'fillgrid()
    '    GridViewExportUtil.Export(lblReportName.CurrentPage & "-" & LblError.Text & ".xls", Me.GdAttendance)
    'End Sub


    Public Overrides Sub VerifyRenderingInServerForm(ByVal Control As Control)

    End Sub

#End Region
    Protected Sub Page_PreRender(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.PreRender
        ucDateFrom.Attributes.Add("readonly", "true")
        UcDateTo.Attributes.Add("readonly", "true")
    End Sub

    Protected Sub ucDateFrom_Changed(ByVal sender As Object, ByVal e As System.EventArgs) Handles ucDateFrom.Changed
        fillgrid()
    End Sub

    Protected Sub UcDateTo_Changed(ByVal sender As Object, ByVal e As System.EventArgs) Handles UcDateTo.Changed
        fillgrid()
    End Sub
End Class
