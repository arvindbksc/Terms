﻿using Microsoft.VisualBasic;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using com.nss.DBAccess;
using System.Data.SqlClient;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Web;

public partial class Staffing_RoleChanges : System.Web.UI.Page
{
    string supervisorid { get; set; }

    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["UserID"] == null)
        {
            if (User.Identity.Name.ToString().Contains("NSS\\"))
            {
                Session["Lanid"] = User.Identity.Name.ToString().Replace("NSS\\", "");
            }
            else
            {
                Session["Lanid"] = User.Identity.Name;
            }
            com.nss.DBAccess.DBAccess db = new com.nss.DBAccess.DBAccess();
            db.slDataAdd("UserId", Session["Lanid"]);
            System.Data.DataRow dr = db.ReturnRow("usp_CheckTermsUser", true);
            db = null;
            if (dr == null)
            {
                Response.Write("There is some problem in authenticating your credentials. Please make sure you are authorized to use this website.");
                return;
            }
            Session["CampaignID"] = dr["campaignid"];
            Session["AgentID"] = dr["AgentID"];
            Session["UserID"] = dr["AgentID"];
            Session["username"] = dr["AgentName"];
            Session["IsVerifier"] = dr["btVerifier"];
            Response.Write(Session["username"]);
            Response.Write(Session["Lanid"]);
            supervisorid = string.Empty;
            

        }
        HumanMessage.Style["visibility"] = "hidden";
        HumanMessage.Visible = false;
        if (!IsPostBack)
        {
            GetRole();
            NewChangeRole();
            lblReportName.CurrentPage = "Role Change";

            
            
 
        }
    }
   

    private void GetRole()
    {
        DBAccess db = new DBAccess("CRM");
        DataTable dtRole = new DataTable();
        dtRole = db.ReturnTable("usp_getRoles", "", false);
        ddlPrevDesignation.DataSource = dtRole;
        ddlPrevDesignation.DataTextField = "Designation";
        ddlPrevDesignation.DataValueField = "Roleid";
        ddlPrevDesignation.DataBind();        
        ddlPrevDesignation.SelectedValue = "0";
    }


    private void NewChangeRole()
    {
        DBAccess db = new DBAccess("CRM");
        DataTable dtRole = new DataTable();
        dtRole = db.ReturnTable("usp_getRoles", "", false);
        ddlDesignation.DataSource = dtRole;
        ddlDesignation.DataTextField = "Designation";
        ddlDesignation.DataValueField = "Roleid";
        ddlDesignation.DataBind();
        ddlDesignation.Items.Insert(0, new ListItem("Select Designation", "0"));
        ddlDesignation.Items.Add(new ListItem("Other", "Other"));
        ddlDesignation.SelectedValue = "0";
        
    }

    [System.Web.Script.Services.ScriptMethod()]
    [System.Web.Services.WebMethod(EnableSession = true)]
    public static List<string> GetCompletionList(string prefixText, int count)
   {
     
       return BindAutoFill(prefixText, "AgentId");

    }

    //Get Agent Names And Agent Id in TextBox for Search
    public static List<string> BindAutoFill(string AgentId, string AgentName)
    {
        //string SupervisorID = HttpContext.Current.Session["AgentID"].ToString();
        DBAccess db = new DBAccess("CRM");
        DataSet ds = new DataSet();
        List<string> listDesc = new List<string>();
        db.slDataAdd("Type", "AllAgentnames");
        db.slDataAdd("AgentId", AgentId); 
        db.slDataAdd("AgentName", "");
        //db.slDataAdd("SupervisorID", SupervisorID);
        db.slDataAdd("Role", "");
        db.slDataAdd("NewRole", "");
        db.slDataAdd("RequestedBy", "");
        db.slDataAdd("ConfirmedBy", "");
        db.slDataAdd("ConfirmedSatus", "");
        ds = db.ReturnDataset("usp_GetRoleChangeAgents", true);
        DataRowCollection drc;
        if (ds.Tables[0].Rows.Count > 0)
        {
            drc = ds.Tables[0].Rows;
            foreach (DataRow dr in drc)
            {
                listDesc.Add(dr[0].ToString());
               

            }
            
            return listDesc;
        }
        else
        {
            listDesc.Add("");
            return listDesc;
        }
    }


    private void AlertMessage(string msg)
    {
        try
        {
            lblHumanMessage.Text = msg;
            HumanMessage.CssClass = "HMFail";
            HumanMessage.Visible = true;
            lblHumanMessage.Visible = true;
            HumanMessage.Style["visibility"] = "visible";
        }
        catch (Exception ex)
        {
 
        }
        

    }

    private void SuccessMessage(string msg)
    {
        try
        {
            lblHumanMessage.Text = msg;
            HumanMessage.CssClass = "HMSuccess";
            HumanMessage.Visible = true;
            lblHumanMessage.Visible = true;
            HumanMessage.Style["visibility"] = "visible";
        }
        catch (Exception ex)
        {
 
        }

    }
    //Get Agent Record In GridView
    public void getagents(string agentCode)
    {
        try
        {
            string EmpCode = "";
            string EmpName = "";

            if (agentCode != "")
            {
                if (agentCode.Contains(")"))
                {
                    String[] strcode = agentCode.Split(new string[] { "(" }, StringSplitOptions.None);
                    EmpCode = strcode[1].Replace(")", "");

                    String[] strName = agentCode.Split(new string[] { "(" }, StringSplitOptions.None);
                    EmpName = strcode[0].Replace(".", "");
                }


                DBAccess db = new DBAccess("CRM");
                DataSet ds = new DataSet();
                db.slDataAdd("Type", "AgentInfoGrid");
                if (EmpCode != "")
                {
                    db.slDataAdd("AgentId", EmpCode);
                    db.slDataAdd("Agentname", "");
                }
                else if (EmpName != "")
                {
                    db.slDataAdd("AgentId", " ");
                    db.slDataAdd("Agentname", EmpName);
                }
                else
                {
                    db.slDataAdd("AgentId", agentCode);
                }

                db.slDataAdd("Role", "");
                db.slDataAdd("NewRole", "");
                //db.slDataAdd("SupervisorID", Session["AgentID"]);
                db.slDataAdd("RequestedBy", "");
                db.slDataAdd("ConfirmedBy", "");
                db.slDataAdd("ConfirmedSatus", "");
                ds = db.ReturnDataset("usp_GetRoleChangeAgents", true);
                if (ds.Tables[0].Rows.Count > 0)
                {
                    PanlEmployeeGrid.Visible = true;
                    gdData.DataSource = ds;
                    gdData.DataBind();
                    gdData.Visible = true;
                }
                else
                {
                    PanlEmployeeGrid.Visible = false;
                    gdData.Visible = false;
                }

            }
            else 
            {
                lblmsg.Font.Bold = true;
                lblmsg.Text = "Enter Employee Code or name in the Text";
                lblmsg.Visible = true;
            }
            
        }
        catch (Exception ex)
        {
            ex.ToString();
 
        }
    }

    
    //Insert and Initiate the Role Change Request
    public void Savedetails(string AgentId)
    {
        DBAccess db = new DBAccess("CRM");
        DataTable dt = new DataTable();  
        try
        {
           
                if (ddlDesignation.SelectedValue != "0")
                {
                    HdSelectedDesignation.Value = ddlDesignation.SelectedValue;
                    db.slDataAdd("Type", "InsertDesignation");
                    db.slDataAdd("AgentName", "");
                    db.slDataAdd("AgentId", HdId.Value);
                    db.slDataAdd("RequestedBy", Session["username"].ToString());
                    db.slDataAdd("ConfirmedBy", "");
                    if (HdSelectedDesignation.Value == "Other")
                    {

                        db.slDataAdd("Role", txtNewDesgnatn.Text);
                        db.slDataAdd("NewRole", "");
                        panlNewDesignation.Visible = true;

                    }
                    else
                    {
                        db.slDataAdd("NewRole", HdSelectedDesignation.Value);
                        db.slDataAdd("Role", ddlPrevDesignation.SelectedValue);

                    }
                    db.slDataAdd("ConfirmedSatus", "");
                    dt = db.ReturnTable("usp_GetRoleChangeAgents", "", true);
                    if (dt != null)
                    {
                        switch ((dt.Rows[0]["MESSAGE_TYPE"].ToString()))
                        {
                            case "S":
                                SuccessMessage(dt.Rows[0]["MESSAGE"].ToString());
                                Role_Change_Mail();
                                break;

                            case "E":
                                AlertMessage(dt.Rows[0]["MESSAGE"].ToString());
                                break;

                            case "Alert":
                                //SuccessMessage(dt.Rows[0]["MESSAGE"].ToString());
                                lblmsg.Visible = true;
                                lblmsg.Font.Bold = true;
                                lblmsg.Text = "**Role Change Request has already been Requested For This Agent";
                                break;
                        }
                    }

                }
                else
                {
                    
                    ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Select Designation!')", true);
 
                }         
           
                
                Getdata(HdId.Value);
          
            popup.Hide();
        }
        catch (Exception ex)
        {
            AlertMessage(ex.Message);
 
        }

 
    }
    
    // Get Agent Record On POP UP
    public void Getdata(string AgentId)
    {
        DBAccess db = new DBAccess("CRM");
        DataTable dt = new DataTable();
        DataSet ds = new DataSet();
        try
        {


            db.slDataAdd("Type", "AgentInfoGrid");            
            db.slDataAdd("AgentName", "");
            db.slDataAdd("AgentId", AgentId);
            db.slDataAdd("Role", "");
            db.slDataAdd("NewRole", "");
            db.slDataAdd("RequestedBy", "");
            db.slDataAdd("ConfirmedBy", "");
            db.slDataAdd("ConfirmedSatus", "");
            dt = db.ReturnTable("usp_GetRoleChangeAgents", "", true);
            //ds = dt.Rows;
            if (dt.Rows.Count > 0)
            {
                txtEmpID.Text = dt.Rows[0]["AgentID"].ToString();
                txtName.Text = dt.Rows[0]["AgentName"].ToString();
                ddlPrevDesignation.SelectedValue = dt.Rows[0]["RoleID"].ToString();
            }
            

        }
        catch (Exception ex)
        {
           AlertMessage(ex.Message);
 
        }

    }


    protected void txtEmpCode_TextChanged(object sender, EventArgs e)
    {
        try
        {
            if (txtEmpCode.Text != "")
            {
                lblmsg.Visible = false; ;
                getagents(txtEmpCode.Text);
            }
            else
            { 
                lblmsg.Font.Bold = true;
                lblmsg.Text = "Enter Employee Code or name in the Text";
                lblmsg.Visible = true;
                PanlEmployeeGrid.Visible = false;
                gdData.Visible = false;
            }
        }
        catch (Exception ex)
        {
 
        }
        
    }
  


    public void Reset()
    {
        ddlDesignation.SelectedValue = "0";
        txtNewDesgnatn.Text = "";
        //Getdata(HdId.Value);
        panlNewDesignation.Visible = false;
    }
   
    protected void btnSave_Click(object sender, EventArgs e)
    {
        try
        {
            Savedetails(HdId.Value);
            popup.Hide();
        }
        catch (Exception ex)
        { 
        }
       
    }

    protected void BtnCancel_Click(object sender, EventArgs e)
    {
        try
        {
            Reset();
            popup.Hide();
            Getdata(HdId.Value);
            
        }
        catch (Exception ex)
        {
 
        }
    }

    protected void gdData_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        try
        {
            if (e.CommandName == "EditRecord")
            {
                popup.Show();
                int index = Convert.ToInt32(e.CommandArgument);
                HdId.Value = ((HiddenField)gdData.Rows[index].FindControl("hdnID")).Value;
                Getdata(HdId.Value);
                Reset();
            }
        }
        catch (Exception ex)
        { 

        }

    }

   
    protected void ddlDesignation_SelectedIndexChanged(object sender, EventArgs e)
    {       
        try
        {
            popup.Show();
            if (ddlDesignation.SelectedValue == "Other")
            {
                panlNewDesignation.Visible = true;
            }
            else
            {
                panlNewDesignation.Visible = false;

            }
        }
        catch (Exception ex)
        {
 
        }
        
    }
    

    private void Role_Change_Mail()
    {
        DBAccess db;

        try
        {
            int srno = 0;
            var strMailBody = "";
            db = new DBAccess("CRM");
            db = null;
            strMailBody += "<html xmlns='http://www.w3.org/1999/xhtml'>";
            strMailBody += "<body style='font-family: Verdana; font-size: .8em'>";
            strMailBody += "<strong>Following People's are Initiated for Role Changement </strong><br /><br />";
            strMailBody += "<table border='1' width='70%' style='border: 1px solid; border-collapse: collapse; font-family: Verdana; font-size: .8em'>";
            strMailBody += "<tr>";
            strMailBody += "<td align='center'><b>Sr. No.</b></td>";
            strMailBody += "<td align='center'><b>Employee Code</b></td>";
            strMailBody += "<td align='center'><b>Employee Name</b></td>";
            strMailBody += "<td align='center'><b>Previous Designation</b></td>";
            strMailBody += "<td align='center'><b>Current Designation</b></td>";
            strMailBody += "<td align='center'><b>Requested By</b></td>";
            strMailBody += "</tr>";


            foreach (GridViewRow dgRow in gdData.Rows)
            {
                srno = srno + 1;

                db = new DBAccess("CRM");
                db = null;
                strMailBody += "<tr>";
                strMailBody += "<td align='center'>" + srno + "</td>";
                strMailBody += "<td align='center'>" + HdId.Value + "</td>";
                strMailBody += "<td align='center'>" + txtName.Text + "</td>";
                strMailBody += "<td align='center'>" + ddlPrevDesignation.SelectedItem.Text + "</td>";
                if (HdSelectedDesignation.Value == "Other")
                {
                    strMailBody += "<td align='center'>" + txtNewDesgnatn.Text + "</td>";
                }
                else
                {
                    strMailBody += "<td align='center'>" + ddlDesignation.SelectedItem.Text + "</td>";
                }

                strMailBody += "<td align='center'>" + Session["username"].ToString() + "</td>";
                strMailBody += "</tr>";

            }
            strMailBody += "</table><br/>";
            strMailBody += "<div align='left'>If you are approving authority,";
            strMailBody += "<a href='" + System.Configuration.ConfigurationManager.AppSettings["LiveServerPath"] + "/Staffing/PendingRoleApproval.aspx'>Click Here To Approve/Reject</a></div>";
            strMailBody += "<br /><br /><hr/>This mail was sent using the ";
            strMailBody += "<a href='" + System.Configuration.ConfigurationManager.AppSettings["LiveServerPath"] + "'>TermsMonitor&reg;</a> Mail Service.We request you not to reply this message.";
            strMailBody += "<br />This e-mail is confidential and may also be privileged.If you are not the intended recipient, please notify helpdesk immediately; you should not copy or use it for any purpose,nor disclose its contents to any other person.";
            strMailBody += "</body>";
            strMailBody += "</html>";

            MailService(" Role Change", strMailBody, HdId.Value);
        }
        catch (Exception ex)
        {
 
        }

    }
   

    private void MailService(string Subject, string MailBody, string Agent_ID)
    {
        try
        {
            DBAccess db = new DBAccess("CRM");
            DataTable dt = new DataTable();
            db.slDataAdd("AgentId", Agent_ID);
            dt = db.ReturnTable("usp_SupervisorEmails", null, true);
            db = null;

            MailSendServiceXX.Service1SoapClient objWSMail = new MailSendServiceXX.Service1SoapClient();
            
            string strTo = dt.Rows[0]["MailTo"].ToString().Replace("Techclearance@NIIT-Tech.com", "HROperations@NIIT-Tech.com");            
            string strCC = dt.Rows[0]["MailCC"].ToString();
            string strBcc = dt.Rows[0]["MailBCC"].ToString();
            //int index = strCC.IndexOf(",");
            //string strCCMail = strCC.Remove(index, 1);
            string strFrom = System.Configuration.ConfigurationManager.AppSettings["FROM"];
            //Need to Be UnComment/Comment Whenever Required
            //objWSMail.MailSendNewTech(strTo, Subject, strFrom, "TermsMonitor", MailBody, "", strCC, strBcc, "");
            objWSMail.MailSendNewTech(strTo, Subject, strFrom, "TermsMonitor", MailBody, "", strCC, strBcc, "");               
            objWSMail = null;
        }
        catch (Exception ex)
        {
            ex.Message.ToString();
 
        }
    }
   
}