﻿using Microsoft.VisualBasic;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using com.nss.DBAccess;
using System.Data.SqlClient;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Web;

public partial class Staffing_FillCovid : System.Web.UI.Page
{
    string supervisorid { get; set; }

    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["UserID"] == null)
        {
            if (User.Identity.Name.ToString().Contains("NSS\\"))
            {
                Session["Lanid"] = User.Identity.Name.ToString().Replace("NSS\\", "");
            }
            else
            {
                Session["Lanid"] = User.Identity.Name;
            }
            com.nss.DBAccess.DBAccess db = new com.nss.DBAccess.DBAccess();
            db.slDataAdd("UserId", Session["Lanid"]);
            System.Data.DataRow dr = db.ReturnRow("usp_CheckTermsUser", true);
            db = null;
            if (dr == null)
            {
                Response.Write("There is some problem in authenticating your credentials. Please make sure you are authorized to use this website.");
                return;
            }
            Session["CampaignID"] = dr["campaignid"];
            Session["AgentID"] = dr["AgentID"];
            Session["UserID"] = dr["AgentID"];
            Session["username"] = dr["AgentName"];
            Session["IsVerifier"] = dr["btVerifier"];
            Response.Write(Session["username"]);
            Response.Write(Session["Lanid"]);
            supervisorid = string.Empty;
            

        }
        HumanMessage.Style["visibility"] = "hidden";
        HumanMessage.Visible = false;
        if (!IsPostBack)
        {
          
    
            lblReportName.CurrentPage = "Covid HelpLine";
            ddlReasonforCall.SelectedIndex = 0;
            ddlSymptomsType.SelectedIndex= 0;
            ddlFinaloutCome.SelectedIndex = 0;
            ddlUrgentRequired.SelectedIndex = 0;
                //GetCovidSymptoms();
            
        }
       
        
    }

    protected void ddlUrgentRequired_SelectedIndexChanged(object sender, EventArgs e)
    {
        popup.Show();
        if (ddlUrgentRequired.SelectedItem.Value.ToLower() == "1" )
        {
            PanlAdditionalInfo.Visible = true;
          
        }
        else
        {
            PanlAdditionalInfo.Visible = false;
           
        }
         }


    protected void ddlSubReason_SelectedIndexChanged(object sender, EventArgs e)
    {
        popup.Show();
        if (ddlSubReason.SelectedItem.Value == "11")
        {
            PanlUrgentRequired.Visible = true;

        }
        else
        {
            PanlUrgentRequired.Visible = false;

        }
    }


    protected void ddlAffectedPerson_SelectedIndexChanged(object sender, EventArgs e)
    {
        popup.Show();
        if (ddlAffectedPerson.SelectedItem.Value.ToLower() == "teammember" || ddlAffectedPerson.SelectedItem.Value.ToLower() == "familyfriends")
        {
            PanlSecName.Visible = true;

        }
        else
        {
            PanlSecName.Visible = false;

        }

        if (ddlAffectedPerson.SelectedItem.Value.ToLower() == "familyfriends")
        {
            ddlRedirectedTo.SelectedIndex = 6;

        }
     
    }
   
    protected void ddlReasonforCall_SelectedIndexChanged(object sender, EventArgs e)
    {
        popup.Show();
        if (ddlReasonforCall.SelectedItem.Value.ToLower() == "5")
        {
            panlcovidothers.Visible = false;
            panlOthers.Visible = true;
        }
        else
        {
            panlOthers.Visible = false;
            panlcovidothers.Visible = true;
        }

        if (ddlReasonforCall.SelectedItem.Value.ToLower() != "2")
        {
            panlcovidothers.Visible = false;
           
        }
        else
        {
            
            panlcovidothers.Visible = true;
        
        }

          
    }

    protected void ddlTestDone_SelectedIndexChanged(object sender, EventArgs e)
    {
        popup.Show();
        if (ddlTestDone.SelectedValue.ToLower() == "yes")

            PanlTest.Visible = true;

        else
            PanlTest.Visible = false;
          
    }

    protected void ddlFinaloutCome_SelectedIndexChanged(object sender, EventArgs e)
    {
        popup.Show();
        if (ddlFinaloutCome.SelectedValue.ToLower() == "open")

            Panlfollowup.Visible = false;

        else
            Panlfollowup.Visible = true;

    }

    


    private void GetAffectedPerson()
    {
        ddlAffectedPerson.Items.Insert(0, new ListItem("Select Affected Person", "0"));
        ddlAffectedPerson.Items.Add(new ListItem("Other", "Other"));
        ddlAffectedPerson.SelectedValue = "0";

    }

    public void GetCovidSymptoms(object sender, EventArgs e)
    {
        popup.Show();
        
         db = new DBAccess("CRM");
        DataTable dtRole = new DataTable();
        db.slDataAdd("symptoms_ID", ddlSymptomsType.SelectedValue);
        dtRole = db.ReturnTable("usp_GetCovidSymptoms", "", true);
        chklstSymptoms.DataSource = dtRole;
        chklstSymptoms.DataTextField = "symptoms";
        chklstSymptoms.DataValueField = "id";
        chklstSymptoms.DataBind();
        //ddlSymptoms.SelectedValue = "0";

        
      
    }
    
    
    [System.Web.Script.Services.ScriptMethod()]
    [System.Web.Services.WebMethod(EnableSession = true)]
    public static List<string> GetCompletionList(string prefixText, int count)
   {
     
       return BindAutoFill(prefixText, "AgentId");

    }

    //Get Agent Names And Agent Id in TextBox for Search
    public static List<string> BindAutoFill(string AgentId, string AgentName)
    {
        //string SupervisorID = HttpContext.Current.Session["AgentID"].ToString();
        DBAccess db = new DBAccess("CRM");
        DataSet ds = new DataSet();
        List<string> listDesc = new List<string>();
        db.slDataAdd("Type", "AllAgentnames");
        db.slDataAdd("Name", "");
        db.slDataAdd("PersNo", AgentId); 
       
         ds = db.ReturnDataset("usp_CovidSymptomsEmployee2", true);
        DataRowCollection drc;
        if (ds.Tables[0].Rows.Count > 0)
        {
            drc = ds.Tables[0].Rows;
            foreach (DataRow dr in drc)
            {
                listDesc.Add(dr[0].ToString());
               

            }
            
            return listDesc;
        }
        else
        {
            listDesc.Add("");
            return listDesc;
        }
    }


    private void AlertMessage(string msg)
    {
        try
        {
            lblHumanMessage.Text = msg;
            HumanMessage.CssClass = "HMFail";
            HumanMessage.Visible = true;
            lblHumanMessage.Visible = true;
            HumanMessage.Style["visibility"] = "visible";
        }
        catch (Exception ex)
        {
 
        }
        

    }

    private void SuccessMessage(string msg)
    {
        try
        {
            lblHumanMessage.Text = msg;
            HumanMessage.CssClass = "HMSuccess";
            HumanMessage.Visible = true;
            lblHumanMessage.Visible = true;
            HumanMessage.Style["visibility"] = "visible";
        }
        catch (Exception ex)
        {
 
        }

    }
    //Get Agent Record In GridView
    public void getagents(string agentCode)
    {
        try
        {
            string EmpCode = "";
            string EmpName = "";

            if (agentCode != "")
            {
                if (agentCode.Contains(")"))
                {
                    String[] strcode = agentCode.Split(new string[] { "(" }, StringSplitOptions.None);
                    EmpCode = strcode[1].Replace(")", "");

                    String[] strName = agentCode.Split(new string[] { "(" }, StringSplitOptions.None);
                    EmpName = strcode[0].Replace(".", "");
                }


                DBAccess db = new DBAccess("CRM");
                DataSet ds = new DataSet();
                db.slDataAdd("Type", "AgentInfoGrid");
                if (EmpCode != "")
                {
                    db.slDataAdd("PersNo", EmpCode);
                    db.slDataAdd("Name", "");
                }
                else if (EmpName != "")
                {
                    db.slDataAdd("PersNo", " ");
                    db.slDataAdd("Name", EmpName);
                }
                else
                {
                    db.slDataAdd("PersNo", agentCode);
                }

                  ds = db.ReturnDataset("usp_CovidSymptomsEmployee2", true);
                if (ds.Tables[0].Rows.Count > 0)
                {
                    PanlEmployeeGrid.Visible = true;
                    gdData.DataSource = ds;
                    gdData.DataBind();
                    gdData.Visible = true;

                   
                }
                else
                {
                    PanlEmployeeGrid.Visible = false;
                    gdData.Visible = false;
                  //  AlertMessage("Final Outcome as Open already exists for this Employee ,please close them First >>> "+"(" + agentCode + ")");
                }

            }
            else 
            {
                lblmsg.Font.Bold = true;
                lblmsg.Text = "Enter Employee Code or name in the Text";
                lblmsg.Visible = true;
            }
            
        }
        catch (Exception ex)
        {
            ex.ToString();
 
        }
    }

    
    //////Insert and Initiate the Role Change Request
    DBAccess db;
    int iTicketNo;
    public void Savedetails(string AgentId)
    {
         db = new DBAccess("CRM");
        DataTable dt = new DataTable();
        try
        {


            if (Session["username"].ToString() != "")
            {
                
                
                db.slDataAdd("PersNo", HdId.Value);
                db.slDataAdd("Name", txtName.Text);
                db.slDataAdd("Address", tbxArea.Text);
                db.slDataAdd("Phone", tbxphoneno.Text);
                db.slDataAdd("Supervisor", tbxSupervisor.Text);
                db.slDataAdd("UserName", Session["username"].ToString());
                db.slDataAdd("AffectedPerson", ddlAffectedPerson.SelectedItem.Text);
                db.slDataAdd("SecName", tbxSecondaryName.Text);

                if (ddlReasonforCall.SelectedValue == "0")
                    AlertMessage("Please Select Valid Reason  for Call!!");

                      db.slDataAdd("ReasonForCall", ddlReasonforCall.SelectedValue);
                      
                      db.slDataAdd("Others", tbxOthers.Text);
                      db.slDataAdd("Symptoms_Type", ddlSymptomsType.SelectedValue);

                      string strsymptoms = "";
                      for (int i = 0; i < chklstSymptoms.Items.Count; i++)
                      {
                          if (chklstSymptoms.Items[i].Selected)
                          {

                              strsymptoms = strsymptoms + chklstSymptoms.Items[i].Value + ",";
                          }

                      }

                    

                      //if (strsymptoms.Length > 0)
                      //    db.slDataAdd("Symptoms_IDs", strsymptoms.Substring(0, (strsymptoms.Length - 1)));
                      //else
                      //    db.slDataAdd("Symptoms_IDs", strsymptoms);

                      db.slDataAdd("Symptoms_IDs", strsymptoms);

                      db.slDataAdd("TestDone", ddlTestDone.SelectedItem.Text);
                      db.slDataAdd("TestType", ddlTestType.SelectedItem.Text);



                      //if (ddlReasonforCall.SelectedValue == "0")
                      //{
                      //    AlertMessage("Please Select Valid Reason Call  Option !!");
                      //    return;
                      //}

                      //if (ddlSubReason.SelectedValue == "0")
                      //{
                      //    AlertMessage("Please Select Valid Sub Reason Option !!");
                      //    return;
                      //}



                      //if (ddlRedirectedTo.SelectedValue == "0")
                      //{
                      //    AlertMessage("Please Select Valid Redirceted Option !!");
                      //    return;
                      //}

                      //if (ddlUrgentRequired.SelectedValue == "0")
                      //{
                      //    AlertMessage("Please Select Valid Urgent Required Option !!");
                      //    return;
                      //}




                      ////Covid Related, Insurance and Special Assistance
                      //if (ddlReasonforCall.SelectedItem.Value.ToLower() == "2" || ddlReasonforCall.SelectedItem.Value.ToLower() == "3" || ddlReasonforCall.SelectedItem.Value.ToLower() == "4")
                      //{
                      //    // ddlSubReason.SelectedIndex = ddlReasonforCall.Items.IndexOf(ddlReasonforCall.Items.FindByValue("2"));


                      //    if (ddlSubReason.SelectedValue == "0")
                      //    {
                      //        AlertMessage("Please Select Valid Sub Reason !!");
                      //        return;
                      //    }

                      //}
                    
                
                      db.slDataAdd("SubReason", ddlSubReason.SelectedValue);
                       db.slDataAdd("TestConductedOn",  Convert.ToDateTime( txtDate.Text));
                      db.slDataAdd("ReportStatus", ddlReportStatus.SelectedItem.Text);
                      db.slDataAdd("Comments", tbxIssueComment.Text);
                      db.slDataAdd("RedirectedTo", ddlRedirectedTo.SelectedItem.Text);
                      db.slDataAdd("FinalOutCome", ddlFinaloutCome.SelectedItem.Value);
                      db.slDataAdd("Followup", tbxfollowup.Text);
                      db.slDataAdd("UrgentRequired", ddlUrgentRequired.SelectedItem.Value);
                      db.slDataAdd("AdditionalInfo", Tbxfever.Text);
                      db.slDataAdd("AdditionalInfo2", TbxO2Level.Text);




                      iTicketNo = Convert.ToInt32(db.ReturnValue("[dbo].[usp_Add_Employee_CovidData2]", true));


                      if (((ddlSubReason.SelectedValue.ToString() == "1") || (ddlSubReason.SelectedValue.ToString() == "2") || (ddlSubReason.SelectedValue.ToString() == "3") || (ddlSubReason.SelectedValue.ToString() == "4") || (ddlSubReason.SelectedValue.ToString() == "5") || (ddlSubReason.SelectedValue.ToString() == "6") || (ddlSubReason.SelectedValue.ToString() == "7") || (ddlSubReason.SelectedValue.ToString() == "8") || (ddlSubReason.SelectedValue.ToString() == "9") || (ddlSubReason.SelectedValue.ToString() == "10") || (ddlSubReason.SelectedValue.ToString() == "11") || (ddlSubReason.SelectedValue.ToString() == "12") || (ddlSubReason.SelectedValue.ToString() == "13") || (ddlSubReason.SelectedValue.ToString() == "14") || (ddlSubReason.SelectedValue.ToString() == "15") || (ddlSubReason.SelectedValue.ToString() == "16")) && ((ddlFinaloutCome.SelectedItem.Value == "Open")))
                      {
                          CovidInfo_Mail(iTicketNo, "");
                      }

                          //Covid Related and Special Assistance
                      else if (ddlReasonforCall.SelectedItem.Value.ToLower() == "2" || ddlReasonforCall.SelectedItem.Value.ToLower() == "4")
                      {

                          //Docto Consultation
                          if (ddlSubReason.SelectedValue.ToString() == "11")
                          {
                              // ddlSubReason.SelectedIndex = ddlReasonforCall.Items.IndexOf(ddlReasonforCall.Items.FindByValue("2"));
                              if (ddlFinaloutCome.SelectedItem.Value == "NORESPONSE")
                              {
                                  CovidInfo_Mail_NoResponse( "");
                              }
                              else if (ddlFinaloutCome.SelectedItem.Value == "Closed")
                              {
                                  CovidInfo_Mail_Closed("");
                              }


                          }
                      }




                      SuccessMessage("Data Added Successfully ");
                      db = null;


                //else if (((ddlSubReason.SelectedValue.ToString() == "11")) && ((ddlFinaloutCome.SelectedItem.Text == "Open")))
                //{
                //    string stTO = "Manisha Chopra - HRO <Manisha.Chopra@coforge.com>; Neha Dalal <Neha.Dalal@coforge.com>; Shahnaaz Karim <Shahnaaz.Karim@coforge.com>; Sushil Behera <Sushil.Behera@coforge.com>";
                //    CovidInfo_Mail(stTO);
                //}

                //else if (((ddlFinaloutCome.SelectedItem.Text == "Closed")))
                //{

                //    CovidInfo_Mail("");
                //}
                

               
                

            }
            else
            {

                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Select Designation!')", true);

            }


            Getdata(HdId.Value);

            popup.Hide();
        }
        catch (Exception ex)
        {
            AlertMessage(ex.Message);

        }


    }
    
    // Get Agent Record On POP UP
    public void Getdata(string AgentId)
    {
         db = new DBAccess("CRM");
        DataTable dt = new DataTable();
        DataSet ds = new DataSet();
        try
        {


            db.slDataAdd("Type", "AgentInfoGrid");            
            db.slDataAdd("Name", "");
            db.slDataAdd("PersNo", AgentId);
          
            dt = db.ReturnTable("usp_CovidSymptomsEmployee2", "", true);
            //ds = dt.Rows;
            if (dt.Rows.Count > 0)
            {
                txtEmpID.Text = dt.Rows[0]["PersNo"].ToString();
                txtName.Text = dt.Rows[0]["Name"].ToString();
                tbxArea.Text = dt.Rows[0]["PSADesc"].ToString();
                tbxEmailInfo.Text = dt.Rows[0]["EmailID"].ToString();
            
            }
            

        }
        catch (Exception ex)
        {
           AlertMessage(ex.Message);
 
        }

    }


    protected void txtEmpCode_TextChanged(object sender, EventArgs e)
    {
        try
        {
            if (txtEmpCode.Text != "")
            {
                lblmsg.Visible = false; ;
                getagents(txtEmpCode.Text);

               
            }
            else
            { 
                lblmsg.Font.Bold = true;
                lblmsg.Text = "Enter Employee Code or name in the Text";
                lblmsg.Visible = true;
                PanlEmployeeGrid.Visible = false;
                gdData.Visible = false;
            }
        }
        catch (Exception ex)
        {
 
        }
        
    }
  


   
    protected void btnSave_Click(object sender, EventArgs e)
    {
        try
        {
            Savedetails(HdId.Value);
            popup.Hide();
        }
        catch (Exception ex)
        { 
        }
       
    }

    protected void BtnCancel_Click(object sender, EventArgs e)
    {
        try
        {
            
            popup.Hide();
            Getdata(HdId.Value);
            
        }
        catch (Exception ex)
        {
 
        }
    }

    protected void gdData_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        try
        {
            if (e.CommandName == "EditRecord")
            {
                popup.Show();
                int index = Convert.ToInt32(e.CommandArgument);
                HdId.Value = ((HiddenField)gdData.Rows[index].FindControl("hdnID")).Value;
                Getdata(HdId.Value);



            }

        }
        catch (Exception ex)
        {

        }

    }



    private void CovidInfo_Mail_Closed(string sTO = "")
    {
        DBAccess db;

        try
        {
            int srno = 0;
            var strMailBody = "";
            db = new DBAccess("CRM");
            db = null;
            strMailBody += "<html xmlns='http://www.w3.org/1999/xhtml'>";
            strMailBody += "<body style='font-family: Verdana; font-size: .8em'>";
            strMailBody += "Dear " + txtName.Text + "," + "<br /><br />";
            strMailBody += "Your online consultation request is now complete. The query stands closed...  <br /> <br />";

            
            //strMailBody += "<div align='left'>If you are approving authority,";
            //strMailBody += "<a href='" + System.Configuration.ConfigurationManager.AppSettings["LiveServerPath"] + "/Staffing/PendingRoleApproval.aspx'>Click Here To Approve/Reject</a></div>";



            strMailBody += "<br /><br /><hr/>Stay Safe and Healthy !! ";
            strMailBody += "<br /><hr/>Thanks and regards";
            strMailBody += "<br/> Coforge Covid help desk ";
            strMailBody += "</body>";
            strMailBody += "</html>";

            MailService("Coforge Covidcare 24x7 Support", strMailBody, HdId.Value, sTO);
        }
        catch (Exception ex)
        {

        }

    }


    private void CovidInfo_Mail_NoResponse( string sTO = "")
    {
        DBAccess db;

        try
        {
            int srno = 0;
            var strMailBody = "";
            db = new DBAccess("CRM");
            db = null;
            strMailBody += "<html xmlns='http://www.w3.org/1999/xhtml'>";
            strMailBody += "<body style='font-family: Verdana; font-size: .8em'>";
            strMailBody += "Dear " + txtName.Text + "," + "<br /><br />";
            strMailBody += "We tried to contact you on the number provided and there was no response. We would contact again shortly..  <br /> <br />";
            
           
            strMailBody += "<br /><br /><hr/>Stay Safe and Healthy !! ";
            strMailBody += "<br /><hr/>Thanks and regards";
            strMailBody += "<br/> Coforge Covid help desk ";
            strMailBody += "</body>";
            strMailBody += "</html>";

            MailService("Coforge Covidcare 24x7 Support", strMailBody, HdId.Value, sTO);
        }
        catch (Exception ex)
        {

        }

    }


    private void CovidInfo_Mail(int iTicketNo,string sTO="" )
    {
        DBAccess db;

        try
        {
            int srno = 0;
            var strMailBody = "";
            db = new DBAccess("CRM");
            db = null;
            strMailBody += "<html xmlns='http://www.w3.org/1999/xhtml'>";
            strMailBody += "<body style='font-family: Verdana; font-size: .8em'>";
            strMailBody += "Dear " + txtName.Text +","+ "<br /><br />";
            strMailBody += "This is an auto generated email. The organisation stands with you in these challenging times and is determined to assist in the best possible way.  <br /> <br />";
            strMailBody += "We have received your request and the advised team is working on it. An update would be shared shortly.  <br />";
            strMailBody += "PFB the details of your request:  <br />  <br />";

            strMailBody += "<table border='1' width='90%' style='border: 1px solid; border-collapse: collapse; font-family: Verdana; font-size: .8em'>";
            strMailBody += "<tr>";
            strMailBody += "<td align='center'><b>Requestor Name</b></td>";
            strMailBody += "<td align='center'><b>Employee ID</b></td>";
            strMailBody += "<td align='center'><b>Reason for Contact</b></td>";
            strMailBody += "<td align='center'><b>Request Id</b></td>";
            strMailBody += "</tr>";


            foreach (GridViewRow dgRow in gdData.Rows)
            {


                db = new DBAccess("CRM");
                db = null;
                strMailBody += "<tr>";
                strMailBody += "<td align='center'>" + txtName.Text + "</td>";
                strMailBody += "<td align='center'>" + HdId.Value + "</td>";
                strMailBody += "<td align='center'>" + ddlSubReason.SelectedItem.Text + "</td>";
                strMailBody += "<td align='center'>" + iTicketNo.ToString() + "</td>";


                //strMailBody += "<td align='center'>" + ddlPrevDesignation.SelectedItem.Text + "</td>";
                //if (HdSelectedDesignation.Value == "Other")
                //{
                //    strMailBody += "<td align='center'>" + txtNewDesgnatn.Text + "</td>";
                //}
                //else
                //{
                //    strMailBody += "<td align='center'>" + ddlDesignation.SelectedItem.Text + "</td>";
                //}

               // strMailBody += "<td align='center'>" + Session["username"].ToString() + "</td>";
                strMailBody += "</tr>";

            }
            strMailBody += "</table><br/>";

            strMailBody += "<p>";
            strMailBody += "Thank You";
            strMailBody += "</p>";
            
            //strMailBody += "<div align='left'>If you are approving authority,";
            //strMailBody += "<a href='" + System.Configuration.ConfigurationManager.AppSettings["LiveServerPath"] + "/Staffing/PendingRoleApproval.aspx'>Click Here To Approve/Reject</a></div>";
            


            strMailBody += "<br /><br /><hr/>Stay Home, Stay safe and Stay healthy. ";
            strMailBody += "<br /><hr/>Thanks and regards";
            strMailBody += "<br/> Coforge Covid help desk ";
            strMailBody += "</body>";
            strMailBody += "</html>";

            MailService("Coforge Covidcare 24x7 Support", strMailBody, HdId.Value,sTO);
        }
        catch (Exception ex)
        {

        }

    }


    private void MailService(string Subject, string MailBody, string Agent_ID, string sTo="")
    {
        try
        {
            //DBAccess db = new DBAccess("CRM");
            //DataTable dt = new DataTable();
            //db.slDataAdd("AgentId", Agent_ID);
            //dt = db.ReturnTable("usp_SupervisorEmails", null, true);
            //db = null;

            MailSendServiceXX.Service1SoapClient objWSMail = new MailSendServiceXX.Service1SoapClient();
            
            //string strTo = dt.Rows[0]["MailTo"].ToString().Replace("Techclearance@coforge.com", "HROperations@coforge.com");            
            //string strCC = dt.Rows[0]["MailCC"].ToString();
            //string strBcc = dt.Rows[0]["MailBCC"].ToString();
            //int index = strCC.IndexOf(",");
            //string strCCMail = strCC.Remove(index, 1);
            //string strTo = tbxEmailInfo.Text;
            string strBcc = System.Configuration.ConfigurationManager.AppSettings["BCC"];
             string strTo = "";
             if (sTo != "")
                 strTo = sTo;
             else
                 strTo = tbxEmailInfo.Text;
            string strFrom = System.Configuration.ConfigurationManager.AppSettings["CovidCare"];
            //Need to Be UnComment/Comment Whenever Required
            //objWSMail.MailSendNewTech(strTo, Subject, strFrom, "TermsMonitor", MailBody, "", strCC, strBcc, "");
            objWSMail.MailSendNewTech(strTo, Subject, strFrom, "Coforge Covid Care", MailBody, "", "", strBcc, "");               
            objWSMail = null;
        }
        catch (Exception ex)
        {
            //ex.Message.ToString();
            AlertMessage("Valid Email ID is not existing");
 
        }
    }

    protected void gdData_RowEditing(object sender, GridViewEditEventArgs e)
    {
        //try
        //{
        //    if (e.CommandName == "EditRecord")
        //    {
        //        popup.Show();
        //        int index = Convert.ToInt32(e.CommandArgument);
        //        HdId.Value = ((HiddenField)gdData.Rows[index].FindControl("hdnID")).Value;
        //        Getdata(HdId.Value);



        //    }

        //}
        //catch (Exception ex)
        //{

        //}


    }
}