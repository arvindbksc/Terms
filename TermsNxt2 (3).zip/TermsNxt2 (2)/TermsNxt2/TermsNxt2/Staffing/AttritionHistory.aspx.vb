﻿Imports com.nss.DBAccess
Imports System.Data
Imports System.Text
Partial Class Staffing_AttritionHistory
    Inherits System.Web.UI.Page
#Region "Properties"
    Property ReportType() As Integer
        Get
            Return ViewState("ReportType")
        End Get
        Set(ByVal value As Integer)
            ViewState("ReportType") = value
        End Set
    End Property
    Property CampaignID() As Integer
        Get
            Return 0 'ViewState("CampaignID")
        End Get
        Set(ByVal value As Integer)
            'ViewState("CampaignID") = value
        End Set
    End Property
    Property AgentID() As String
        Get
            Return ViewState("AgentID")
        End Get
        Set(ByVal value As String)
            ViewState("AgentID") = value
        End Set
    End Property
    Property CurrentDate() As Date
        Get
            Return ViewState("CurrentDate")
        End Get
        Set(ByVal value As Date)
            ViewState("CurrentDate") = value
        End Set
    End Property
    Property UserName() As String
        Get
            Return ViewState("UserName")
        End Get
        Set(ByVal value As String)
            ViewState("UserName") = value
        End Set
    End Property
#End Region

#Region "Preapre/Load"

    Private Sub LoadData()
        'UcDateTo.value = DateTime.Now
        'ucDateFrom.value = DateTime.Now.AddMonths(-1).AddDays(21 - DateTime.Now.Day) 'UcDateTo.value 'DateTime.Now.Year & "-" & DateTime.Now.Month - 1 & "-21"
        FillCommonFilters()
        Common.FillProcessCampaigns(CboProcess, cboCampaigns, AgentID, CampaignID)
    End Sub
    Private Sub FillCommonFilters()
        Dim db As New DBAccess
        Dim dt As DataTable = db.ReturnTable("select * from tbl_Reports_DatePeriods")
        db = Nothing
        Dim dr As DataRow = dt.NewRow
        dr(0) = 10
        dr(1) = "Between"
        dt.Rows.Add(dr)
        CboPeriod.DataTextField = "Caption"
        CboPeriod.DataValueField = "Period"
        CboPeriod.DataSource = dt
        CboPeriod.DataBind()
        dt = Nothing
        
       
    End Sub
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        HumanMessage.Style.Item("visibility") = "hidden"
        If Not IsPostBack Then
            If Session("AgentID") <> "" Then
                Dim db As New DBAccess()
                CurrentDate = db.ReturnValue("Select GetDate()", False)
                db = Nothing
                CampaignID = Session("CampaignID")
                AgentID = Session("AgentID")
                UserName = Session("username")
                PanelReports.Controls.Add(Common.GetMenu(Request.Url, AgentID, Request.ApplicationPath))
                LoadData()
                fillgrid()
                FillDate()
                CheckAccess()
                UcDateTo.Visible = False
                ucDateFrom.Visible = False
                lblAnd.Visible = False
            End If
        End If
    End Sub

    '------------ By Rajendra ------------
    Private Sub CheckAccess()
        Dim db As New DBAccess
        Dim rptAccess As DataTable
        db.slDataAdd("agentid", AgentID)
        rptAccess = db.ReturnTable("usp_GetAgentDetails", , True)
        db = Nothing
        Dim IsHr, IsAdmin As Boolean
        IsHr = rptAccess.Rows(0).Item("IsHR")
        IsAdmin = rptAccess.Rows(0).Item("IsAdmin")
        If GdAttendance.Rows.Count > 0 Then
            If IsAdmin = True Or IsHr = True Then
                GdAttendance.Columns(0).Visible = True
            Else
                GdAttendance.Columns(0).Visible = False
            End If
        End If
    End Sub
    Private Sub FillDate()
        Dim db As New DBAccess
        Dim currentDate As Date = db.ReturnValue("select GetDate()", False)
        db = Nothing
        cboDay.Items.Clear()
        For day As Integer = 1 To 31
            cboDay.Items.Add(day)
        Next
        cboDay.Items.FindByText(currentDate.Day).Selected = True
        cboMonth.Items.Clear()
        For mnth As Integer = 1 To 12
            cboMonth.Items.Add(MonthName(mnth, True))
        Next
        cboMonth.Items.FindByText(MonthName(currentDate.Month, True)).Selected = True
        cboYear.Items.Clear()
        For year As Integer = 2009 To 2031
            cboYear.Items.Add(year)
        Next
        cboYear.Items.FindByText(currentDate.Year).Selected = True
    End Sub
    '-------------------------------------
#End Region

#Region "Grid Manipulation"

    Private Sub fillgrid()
        GdAttendance.DataSource = Nothing
        Dim startday As Integer, endday As Integer
        Dim db As DBAccess
        If CboPeriod.SelectedValue = 10 Then
            startday = ucDateFrom.yyyymmdd
            endday = UcDateTo.yyyymmdd
        Else
            db = New DBAccess
            db.slDataAdd("Period", CboPeriod.SelectedValue)
            db.slDataAdd("Campaignid", CampaignID)
            Dim dr As DataRow = db.ReturnRow("usp_GetStart_EndDateForAPeriod", True)
            db = Nothing
            startday = dr(0)
            endday = dr(1)
        End If
        'or report
        db = New DBAccess
        Dim dt As DataTable
        db.slDataAdd("DateFrom", startday)
        db.slDataAdd("DateTo", endday)
        db.slDataAdd("UserId", AgentID)
        db.slDataAdd("campaignid", CampaignID)
        db.slDataAdd("processid", CboProcess.SelectedValue)
        dt = db.ReturnTable("usp_GetNSSAttrition", , True)
        breadcrumbs.CurrentPage = " Attrition History Between " & IntegerToDateString(startday) & "  and " & IntegerToDateString(endday) & " for " & CboProcess.SelectedItem.Text & " campaign"

        db = Nothing
        GdAttendance.AutoGenerateColumns = True
        GdAttendance.DataSource = dt
        GdAttendance.DataBind()
        dt = Nothing

        CheckAccess()
    End Sub
    Private Function IntegerToDateString(ByVal d As Integer) As String
        Return d.ToString.Substring(0, 4) & "-" & d.ToString.Substring(4, 2) & "-" & d.ToString.Substring(6, 2)
    End Function
    '------------ By Rajendra ----------------
    Private Sub Reset()
        RbResign.Checked = False
        RbAOD.Checked = False
        RbTransfer.Checked = False
        RbTermination.Checked = False
       
    End Sub
    Protected Sub GdAttendance_RowCommand(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewCommandEventArgs) Handles GdAttendance.RowCommand
        Dim row As GridViewRow = CType(CType(e.CommandSource, Control).NamingContainer, GridViewRow)
        If e.CommandName = "change" Then
            lblAgentName.Text = row.Cells(2).Text
            lblEmpProcess.Text = row.Cells(3).Text
            lblResignAgent.Text = row.Cells(1).Text
            lblPrevReleivingDate.Text = row.Cells(5).Text
            lblPrevStatus.Text = row.Cells(4).Text

            Dim CurrentStatus As String = row.Cells(4).Text
            Dim relivingDate As Date = row.Cells(5).Text
            cboDay.ClearSelection()
            cboDay.Items.FindByValue(relivingDate.Day).Selected = True
            cboMonth.ClearSelection()
            cboMonth.Items.FindByText(MonthName(relivingDate.Month, True)).Selected = True
            cboYear.ClearSelection()
            cboYear.Items.FindByValue(relivingDate.Year).Selected = True
            If CurrentStatus.ToLower.Trim = "resigned" Then
                Reset()
                RbResign.Checked = True
            ElseIf CurrentStatus.ToLower.Trim = "aod" Then
                Reset()
                RbAOD.Checked = True
            ElseIf CurrentStatus.ToLower.Trim = "transferred" Then
                Reset()
                RbTransfer.Checked = True
            ElseIf CurrentStatus.ToLower.Trim = "termination" Then
                Reset()
                RbTermination.Checked = True
            End If
            Dim str As String
            str = "$('#DialogBackground').height($(document).height()- 6);$('#DialogBackground').width($(window).width());$('#DialogBackground').css('visibility','visible');$('#PanelResign').css('visibility','visible');" & _
            " $('#PanelResign').css('left',($(window).width() - $('#PanelResign').width())/2); "
            ScriptManager.RegisterStartupScript(Page, Page.GetType(), "Resigndialog", str, True)
        End If
        If e.CommandName = "revoke" Then
            Revoke(row.Cells(1).Text)
            Dim Text As String = "<strong>Following People's Resignation / AOD / Transfer / Termination have been Revoked </strong>"
            Mail("revoke", Text, row.Cells(1).Text, row.Cells(2).Text, row.Cells(3).Text, "", "")
        End If
    End Sub
    Private Sub Revoke(ByVal EmpCode As String)
        Dim db As New DBAccess("CRM")
        db.slDataAdd("AgentId", EmpCode)
        db.slDataAdd("Comment", "Revoked / Chanded By " & AgentID & " On :")
        db.slDataAdd("CurrentStatus", "revoke")
        db.slDataAdd("LastUpdatedBy", AgentID)
        db.Executeproc("usp_Change_AODResign")
        db = Nothing
        SuccessMessage("Resign / AOD has been revoked successfully. ")
        fillgrid()
    End Sub
    '-----------------------------------------
    Protected Sub GdAttendance_RowDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles GdAttendance.RowDataBound
        'Nothing for now
        'If GdAttendance.Rows.Count > 0 Then
        If e.Row.RowType = DataControlRowType.DataRow Then
            If e.Row.Cells(6).Text.Length = 8 Then
                'Dim row As DataRow = CType(e.Row.DataItem, System.Data.DataRowView).Row
                Dim d As Date = e.Row.Cells(6).Text.ToString.Insert(6, "-").Insert(4, "-")
                e.Row.Cells(6).Text = d.ToString("dd-MMM-yyyy")
            End If
            If e.Row.Cells(5).Text.Length = 8 Then
                Dim d1 As Date = e.Row.Cells(5).Text.ToString.Insert(6, "-").Insert(4, "-")
                e.Row.Cells(5).Text = d1.ToString("dd-MMM-yyyy")
                If e.Row.Cells(8).Text = "True" Then
                    e.Row.Cells(0).Controls.Clear()
                Else
                    Dim lnkbtn As LinkButton = CType(e.Row.FindControl("lbnRevoke"), LinkButton)
                    lnkbtn.Attributes.Add("onclick", "javascript:return  confirm('Do you really want to revoke? ')")
                End If
            End If

        End If
        'End If
        If e.Row.RowType <> DataControlRowType.EmptyDataRow Then
            e.Row.Cells(8).Visible = False
        End If

    End Sub
#End Region

#Region "Events"

    Protected Sub ucDateFrom_Changed(ByVal sender As Object, ByVal e As System.EventArgs) Handles ucDateFrom.Changed
        fillgrid()
        CheckAccess()
    End Sub
    Protected Sub UcDateTo_Changed(ByVal sender As Object, ByVal e As System.EventArgs) Handles UcDateTo.Changed
        fillgrid()
        CheckAccess()
    End Sub
    Protected Sub ImageButton1_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton1.Click
        'Excel Export
        fillgrid()
        GridViewExportUtil.Export(breadcrumbs.CurrentPage & ".xls", Me.GdAttendance)
    End Sub
    Protected Sub CboProcess_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles CboProcess.SelectedIndexChanged
        Common.FillCampaigns(cboCampaigns, AgentID, CboProcess.SelectedValue)
        fillgrid()
        CheckAccess()
    End Sub
    Protected Sub cboCampaigns_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboCampaigns.SelectedIndexChanged
        CheckAccess()
        fillgrid()
    End Sub
    Protected Sub CboPeriod_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles CboPeriod.SelectedIndexChanged
        If CboPeriod.SelectedValue = 10 Then
            ucDateFrom.Visible = True
            UcDateTo.Visible = True
            lblAnd.Visible = True
            CheckAccess()
            fillgrid()
        Else
            ucDateFrom.Visible = False
            UcDateTo.Visible = False
            lblAnd.Visible = False
            CheckAccess()
            fillgrid()
        End If
    End Sub
    Protected Sub btnRefresh_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnRefresh.Click
        fillgrid()
    End Sub
    Protected Sub imgfav_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles imgfav.Click
        Common.AddToFav(AgentID, "Attrition History")
        SuccessMessage("Report has been added to your favourite list")
        fillgrid()
    End Sub
    ' ------------ Change Resign /AOD ----------------

    Protected Sub btnSave_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnSave.Click
        Try
            Dim status As String
            If RbResign.Checked = True Then
                status = "Resigned"
            ElseIf RbAOD.Checked = True Then
                status = "AOD"
            ElseIf RbTransfer.Checked = True Then
                status = "Transferred"
            ElseIf RbTermination.Checked = True Then
                status = "Termination"
            Else
                AlertMessage("Please select a status")
                Exit Sub
            End If
            '------ Attendance Date ------------
            Dim dbPayDate As New DBAccess("CRM")
            Dim FreezedDate As Date = dbPayDate.ReturnValue("select MAX(FreezeDate) As FreezeDate from tbl_LastFreezedDate", False)
            dbPayDate = Nothing
            '------ Date of Joning Date --------
            Dim doj As New DBAccess("CRM")
            Dim dojDate As Date = doj.ReturnValue("select doj from tbl_agentmaster where agentid='" & lblResignAgent.Text.Trim & "'", False)
            doj = Nothing

            Dim relievingDate As Integer = Convert.ToDateTime(cboYear.SelectedValue.Trim & cboMonth.SelectedValue.Trim & cboDay.SelectedValue.Trim).ToString("yyyyMMdd")
            If relievingDate > CurrentDate.ToString("yyyyMMdd") Then
                AlertMessage("Since Relieving Date is greater than current date so you need to revoke")
                Exit Sub
            ElseIf relievingDate < DateAdd(DateInterval.Day, 1, FreezedDate).ToString("yyyyMMdd") Then
                AlertMessage("Relieving Date should  be greater than [" & FreezedDate.ToString("yyyy-MMM-dd") & "]")
                Exit Sub
            ElseIf relievingDate < dojDate.ToString("yyyyMMdd") Then
                AlertMessage("Relieving Date should  be greater than [" & DateAdd(DateInterval.Day, -1, dojDate).ToString("yyyy-MMM-dd") & "]")
                Exit Sub
            Else
                Dim db As New DBAccess("CRM")
                db.slDataAdd("AgentId", lblResignAgent.Text.Trim)
                db.slDataAdd("RelievingDate", relievingDate)
                db.slDataAdd("Status", status)
                db.slDataAdd("Comment", "Revoked / Changed By " & AgentID & " On :")
                db.slDataAdd("LastUpdatedBy", AgentID)
                db.slDataAdd("CurrentStatus", "change")
                db.Executeproc("usp_Change_AODResign")
                db = Nothing
                Dim text = "Releving Date / Status has been changed"
                Dim lastday As String = Convert.ToDateTime(cboYear.SelectedValue.Trim & cboMonth.SelectedValue.Trim & cboDay.SelectedValue.Trim).ToString("dd-MMM-yyyy")
                Mail("change", text, lblResignAgent.Text.Trim, lblAgentName.Text, lblEmpProcess.Text, status, lastday)
                SuccessMessage("Relieving Date has been changed successfully. ")
            End If
            fillgrid()
        Catch ex As Exception
            AlertMessage(ex.ToString())
        End Try
    End Sub
    Protected Sub btnCancel_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnCancel.Click
        fillgrid()
    End Sub
#End Region
#Region "Mail"

    Private Sub Mail(ByVal status As String, ByVal HeaderText As String, ByVal EmpId As String, ByVal EmpName As String, ByVal EmpProcess As String, ByVal regstatus As String, ByVal relevingdate As String)
        Dim srno As Int16 = 0
        Dim strMailBody = "", Subject As String = ""
        strMailBody += "<html xmlns='http://www.w3.org/1999/xhtml'>"
        strMailBody += "<body style='font-family: Verdana; font-size: .8em'>"
        strMailBody += HeaderText & "<br /><br />"
        strMailBody += "<table border='1' width='70%' style='border: 1px solid; border-collapse: collapse; font-family: Verdana; font-size: .8em'>"
        If status.ToUpper.Trim = "REVOKE" Then
            Subject = "Resigned / AOD / Transferred / Termination Revoked"
            strMailBody += "<tr>"
            strMailBody += "<td align='center'><b>Agent Name</b></td>"
            strMailBody += "<td align='center'><b>Emp. Code</b></td>"
            strMailBody += "<td align='center'><b>Campaign</b></td>"
            strMailBody += "</tr>"
            strMailBody += "<tr>"
            strMailBody += "<td colspan='3'>"
            strMailBody += "ON " & CurrentDate.ToString("dd/MM/yyyy") & "  by  " & UserName & "</td></tr>"

            strMailBody += "<tr>"
            strMailBody += "<td align='center'>" & EmpName & "</td>"
            strMailBody += "<td align='center'>" & EmpId & "</td>"
            strMailBody += "<td align='center'>" & EmpProcess & "</td>"
            strMailBody += "</tr>"
        ElseIf status.ToUpper.Trim = "CHANGE" Then
            Subject = "Releving Date / Status changed"
            strMailBody += "<tr>"
            strMailBody += "<td align='center'><b>Agent Name</b></td>"
            strMailBody += "<td align='center'><b>Emp. Code</b></td>"
            strMailBody += "<td align='center'><b>Campaign</b></td>"
            strMailBody += "<td align='center'><b>Previous Status</b></td>"
            strMailBody += "<td align='center'><b>Current Status</b></td>"
            strMailBody += "<td align='center'><b>Previous Releving Date</b></td>"
            strMailBody += "<td align='center'><b>Current Releving Date</b></td>"
            strMailBody += "</tr>"
            strMailBody += "<tr>"
            strMailBody += "<td colspan='5'>"
            strMailBody += "ON " & CurrentDate.ToString("dd/MM/yyyy") & "  by  " & UserName & "</td></tr>"

            strMailBody += "<tr>"
            strMailBody += "<td align='center'>" & EmpName & "</td>"
            strMailBody += "<td align='center'>" & EmpId & "</td>"
            strMailBody += "<td align='center'>" & EmpProcess & "</td>"
            strMailBody += "<td align='center'>" & lblPrevStatus.Text & "</td>"
            strMailBody += "<td align='center'>" & regstatus & "</td>"
            strMailBody += "<td align='center'>" & lblPrevReleivingDate.Text & "</td>"
            strMailBody += "<td align='center'>" & relevingdate & "</td>"
            strMailBody += "</tr>"
        End If
        strMailBody += "</table>"
        strMailBody += "<br /><br /><hr/>This mail was sent using the "
        strMailBody += "<a href='http://terms-monitor.niit-tech.com/'>TermsMonitor&reg;</a> Mail Service.We request you not to reply this message."
        strMailBody += "<br /><br />In case you wish to report issues with this mail, please send mail to mailto:helpdesk@niitsmartserve.com <br /> "
        strMailBody += "<br />This e-mail is confidential and may also be privileged.If you are not the intended recipient, please notify helpdesk immediately; you should not copy or use it for any purpose,nor disclose its contents to any other person."
        strMailBody += "</body>"
        strMailBody += "</html>"
        '----------------------------------------------------------
        Dim db As New DBAccess("CRM")
        Dim dt As New DataTable
        db.slDataAdd("AgentId", EmpId)
        dt = db.ReturnTable("usp_SupervisorEmails", , True)
        db = Nothing

        Dim strTo As String = dt.Rows(0).Item("MailTO")
        Dim strCC As String = dt.Rows(0).Item("MailCC")
        Dim strBcc As String = dt.Rows(0).Item("MailBCC")
        Dim strFrom As String = System.Configuration.ConfigurationManager.AppSettings("FROM")

        Dim objMail As New ServiceReference2.MailSoapClient
        objMail.MailSend(strTo, strMailBody, "", strCC, strBcc, strFrom, Subject)
        'objMail.MailSend("developers@niitsmartserve.com", strMailBody, "", "rajendrar_nss@niitsmartserve.com", "rajendrar_nss@niitsmartserve.com", strFrom, Subject)
        objMail = Nothing

    End Sub
#End Region
#Region "Utility"

    Private Sub AlertMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMFail"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub

    Private Sub SuccessMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMSuccess"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub

#End Region

    
End Class
