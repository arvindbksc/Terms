﻿Imports com.nss.DBAccess
Imports System.Data
Imports System.Text
Imports System.Globalization
Partial Class Staffing_Hierarchy_Inactive
    Inherits System.Web.UI.Page

#Region "Properties"
    Property dtHierarchy() As DataTable
        Get
            Return ViewState("dtHierarchy")
        End Get
        Set(ByVal value As DataTable)
            ViewState("dtHierarchy") = value
        End Set
    End Property
    Property ReportType() As Integer
        Get
            Return ViewState("ReportType")
        End Get
        Set(ByVal value As Integer)
            ViewState("ReportType") = value
        End Set
    End Property
    Property CampaignID() As Integer
        Get
            Return 0 'ViewState("CampaignID")
        End Get
        Set(ByVal value As Integer)
            'ViewState("CampaignID") = value
        End Set
    End Property

    Property AgentID() As String
        Get
            Return ViewState("AgentID")
        End Get
        Set(ByVal value As String)
            ViewState("AgentID") = value
        End Set
    End Property
    Property Supervisorslist() As String
        Get
            Return ViewState("Supervisorslist")
        End Get
        Set(ByVal value As String)
            ViewState("Supervisorslist") = value
        End Set
    End Property
#End Region
#Region "-----Load Activities-----"

    Private Sub LoadData()
        Common.FillProcessCampaigns(CboProcess, cboCampaigns, AgentID, CampaignID)
        filldata()
    End Sub
    Private Sub filldata()
        Dim db As New DBAccess
        db.slDataAdd("agentid", AgentID)
        db.slDataAdd("ProcessId", CboProcess.SelectedValue)
        dtHierarchy = db.ReturnTable("usp_CurrentHierarchyList_Inactive", , True)
        db = Nothing
    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        HumanMessage.Style.Item("visibility") = "hidden"
        If Not IsPostBack Then

            ReportType = Request.QueryString("ReportType")
            If Session("AgentID") <> "" Then
                CampaignID = Session("CampaignID")
                AgentID = Session("AgentID")
                PanelReports.Controls.Add(Common.GetMenu(Request.Url, AgentID, Request.ApplicationPath))
                LoadData()
                FillSupervisors()
                fillgrid()
                SupervisorsName()
            End If
        End If
    End Sub
    Private Sub fillgrid()

        Dim db As DBAccess
        Dim dt As New DataTable
        dt = dtHierarchy.Clone
        Dim row() As DataRow
        If CboProcess.SelectedValue <> 0 And cboSupervisors.SelectedValue <> "%" Then
            row = dtHierarchy.Select("ProcessID='" & CboProcess.SelectedValue & "' and supervisorid='" & cboSupervisors.SelectedValue & "'", "ProcessName,AgentName")
        ElseIf CboProcess.SelectedValue = 0 And cboSupervisors.SelectedValue <> "%" Then
            row = dtHierarchy.Select("supervisorid='" & cboSupervisors.SelectedValue & "'", "ProcessName,AgentName")
        ElseIf CboProcess.SelectedValue <> 0 And cboSupervisors.SelectedValue = "%" Then
            row = dtHierarchy.Select("ProcessID='" & CboProcess.SelectedValue & "'", "ProcessName,AgentName")
        Else
            row = dtHierarchy.Select("", "ProcessName,SupervisorName,AgentName")
        End If

        For Each row1 As DataRow In row
            dt.ImportRow(row1)
        Next
        ' dt = db.ReturnTable("usp_AttendanceSummary", , True)

        breadcrumbs.CurrentPage = " Process Team Member List for " & CboProcess.SelectedItem.Text
        'LblError.Text = " " & " for " & CboProcess.SelectedItem.Text & " campaign"

        db = Nothing
        dt.Columns.Remove("processid")
        dt.Columns.Remove("Supervisorid")
        If cboSupervisors.SelectedValue <> "%" Then
            dt.Columns.Remove("SupervisorName")
        End If

        'GridView1.AutoGenerateColumns = False
        'CreateGridColumns(dt.Columns)
        GridView1.DataSource = dt
        GridView1.DataBind()
        dt = Nothing

    End Sub
#End Region
#Region "Event"
    Protected Sub CboProcess_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles CboProcess.SelectedIndexChanged
        Common.FillCampaigns(cboCampaigns, AgentID, CboProcess.SelectedValue)
        filldata()
        FillSupervisors()
        fillgrid()
        SupervisorsName()
    End Sub
    Protected Sub cboSupervisors_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboSupervisors.SelectedIndexChanged
        fillgrid()
        SupervisorsName()
    End Sub
    Protected Sub ImageButton1_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton1.Click
        fillgrid()
        GridViewExportUtil.Export(breadcrumbs.CurrentPage & ".xls", Me.GridView1)
    End Sub
    Protected Sub btnRefresh_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnRefresh.Click
        fillgrid()
        SupervisorsName()
    End Sub
    Protected Sub imgfav_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles imgfav.Click
        Common.AddToFav(AgentID, "Current Hierarchy")
        SuccessMessage("Report has been added to your favourite list")
        fillgrid()
    End Sub
#End Region
#Region "Support Function"
    Private Sub FillSupervisors()
        Dim str() As String = {"SupervisorId", "SupervisorName"}
        Dim dtSup As DataTable = dtHierarchy.DefaultView.ToTable(True, str)
        Dim row As DataRow = dtSup.NewRow
        row("SupervisorName") = "All"
        row("SupervisorId") = "%"
        dtSup.Rows.InsertAt(row, 0)
        cboSupervisors.DataSource = dtSup
        cboSupervisors.DataTextField = "SupervisorName"
        cboSupervisors.DataValueField = "SupervisorId"
        cboSupervisors.DataBind()

    End Sub
    Private Sub ExportToexcel()
        Dim tw As New IO.StringWriter()
        Dim hw As New System.Web.UI.HtmlTextWriter(tw)
        'Dim frm As HtmlForm = New HtmlForm()
        Response.ContentType = "application/vnd.ms-excel"
        Response.AddHeader("content-disposition", "attachment;filename=" & breadcrumbs.CurrentPage & ".xls")
        Response.Charset = ""
        EnableViewState = False
        'Controls.Add(frm)
        GridView1.RenderControl(hw)
        Response.Write(tw.ToString())
        Response.End()
    End Sub
    Private Sub SupervisorsName()
        If Not cboSupervisors.SelectedValue = "%" Then
            Dim db As New DBAccess
            db.slDataAdd("SupervisorId", cboSupervisors.SelectedValue)
            Supervisorslist = db.ReturnValue("usp_SupervisorNames", True)
            db = Nothing
            lblSupervisorlist.Text = Supervisorslist
        Else
            lblSupervisorlist.Text = ""
        End If
    End Sub
#End Region
#Region "Utility"

    Private Sub AlertMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMFail"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub

    Private Sub SuccessMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMSuccess"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub

    'Protected Sub ImageButton1_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton1.Click
    '    'fillgrid()
    '    GridViewExportUtil.Export(lblReportName.CurrentPage & "-" & LblError.Text & ".xls", Me.GdAttendance)
    'End Sub


    Public Overrides Sub VerifyRenderingInServerForm(ByVal Control As Control)

    End Sub

#End Region

End Class
