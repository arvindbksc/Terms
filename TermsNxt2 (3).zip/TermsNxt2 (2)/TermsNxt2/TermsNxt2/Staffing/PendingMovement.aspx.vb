﻿Imports com.nss.DBAccess
Imports System.Data
Imports System.Text
Partial Class Attendance_PendingMovement
    Inherits System.Web.UI.Page
#Region "Properties"
    Property ReportType() As Integer
        Get
            Return ViewState("ReportType")
        End Get
        Set(ByVal value As Integer)
            ViewState("ReportType") = value
        End Set
    End Property
    Property CampaignID() As Integer
        Get
            Return ViewState("CampaignID")
        End Get
        Set(ByVal value As Integer)
            ViewState("CampaignID") = value
        End Set
    End Property

    Property AgentID() As String
        Get
            Return ViewState("AgentID")
        End Get
        Set(ByVal value As String)
            ViewState("AgentID") = value
        End Set
    End Property
#End Region
    Private Sub LoadData()
        FillCommonFilters()
        lblDate.Text = "Aprroved cases will be processed tomorrow " & DateTime.Now.ToString("dd-MMM-yyyy") & " at 6:30 AM IST."

    End Sub

    Private Sub FillCommonFilters()
        'Dim db As New DBAccess
        'Dim dt As DataTable = db.ReturnTable("select * from tbl_Reports_DatePeriods")
        'db = Nothing
        'CboPeriod.DataTextField = "Caption"
        'CboPeriod.DataValueField = "Period"
        'CboPeriod.DataSource = dt
        'CboPeriod.DataBind()
    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        HumanMessage.Style.Item("visibility") = "hidden"
        If Not IsPostBack Then
            If Session("AgentID") <> "" Then
                CampaignID = Session("CampaignID")
                AgentID = Session("AgentID")
                PanelReports.Controls.Add(Common.GetMenu(Request.Url, AgentID, Request.ApplicationPath))
                LoadData()
                fillgrid()

            End If
        End If
    End Sub

    Private Sub fillgrid()
        Dim db As New DBAccess("CRM")
        Dim dt As DataTable
        dt = db.ReturnTable("usp_PendingMovement", , True)
        breadcrumbs.CurrentPage = " Pending Movements "
        db = Nothing
        GdAttendance.DataSource = dt
        GdAttendance.DataBind()
        GdAttendance.Columns(0).Visible = False
    End Sub



    Protected Sub GdAttendance_RowCommand(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewCommandEventArgs) Handles GdAttendance.RowCommand
        Dim row As GridViewRow = CType(CType(e.CommandSource, Control).NamingContainer, GridViewRow)
        Dim db As New DBAccess("CRM")
        If e.CommandName = "Approve" Then
            row.FindControl("lnkApprove").Visible = False
            row.FindControl("lnkReject").Visible = True
            row.FindControl("lblStatus").Visible = True
            CType(row.FindControl("lblStatus"), Label).Text = "Approved"
            db.slDataAdd("Confirmed", 1)
        ElseIf e.CommandName = "Reject" Then
            row.FindControl("lnkApprove").Visible = True
            row.FindControl("lnkReject").Visible = False
            row.FindControl("lblStatus").Visible = True
            CType(row.FindControl("lblStatus"), Label).Text = "Rejected"
            db.slDataAdd("Confirmed", 0)
        End If
        db.slDataAdd("ID", row.Cells(0).Text)
        db.slDataAdd("ConfirmedBy", AgentID)
        db.Executeproc("usp_ApproveMovement")
        db = Nothing
        'CType(row.FindControl("lblApprovedBy"), Label).Text = "You"
        'CType(row.FindControl("lblYesNo"), Label).Text = "Pending"
    End Sub

    Protected Sub GdAttendance_RowDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles GdAttendance.RowDataBound
        If e.Row.RowType = DataControlRowType.DataRow Then
            Dim row As DataRow = CType(e.Row.DataItem, System.Data.DataRowView).Row
            Dim d As Date = row("moveon").ToString.Insert(6, "-").Insert(4, "-")
            CType(e.Row.FindControl("lblmoveon"), Label).Text = d.ToString("dd-MMM-yyyy")
            If Not IsDBNull(row("ConfirmedBy")) Then



                If row("Confirmed") = True Then
                    e.Row.FindControl("lnkApprove").Visible = False
                    e.Row.FindControl("lnkReject").Visible = True
                    e.Row.FindControl("lblStatus").Visible = True
                    CType(e.Row.FindControl("lblStatus"), Label).Text = "Approved By " & row("ConfirmedBy") & " "

                Else
                    e.Row.FindControl("lnkApprove").Visible = True
                    e.Row.FindControl("lnkReject").Visible = False
                    e.Row.FindControl("lblStatus").Visible = True
                    CType(e.Row.FindControl("lblStatus"), Label).Text = "Rejected By " & row("ConfirmedBy") & " "

                End If
            End If
        End If
    End Sub

    Protected Sub imgfav_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles imgfav.Click
        Common.AddToFav(AgentID, "Pending Movement")
        SuccessMessage("Report has been added to your favourite list")
        fillgrid()
    End Sub
#Region "Utility"

    Private Sub AlertMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMFail"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub

    Private Sub SuccessMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMSuccess"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub

    'Protected Sub ImageButton1_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton1.Click
    '    'fillgrid()
    '    GridViewExportUtil.Export(lblReportName.CurrentPage & "-" & LblError.Text & ".xls", Me.GdAttendance)
    'End Sub


    Public Overrides Sub VerifyRenderingInServerForm(ByVal Control As Control)

    End Sub

#End Region
End Class
