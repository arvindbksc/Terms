﻿Imports com.nss.DBAccess
Imports System.Data
Imports System.Text
Imports System.Globalization

Partial Class Attendance_MarkAttendance
    Inherits System.Web.UI.Page

#Region "-----Properties-----"
    
    Property CurrentDate() As Date
        Get
            Return ViewState("CurrentDate")
        End Get
        Set(ByVal value As Date)
            ViewState("CurrentDate") = value
        End Set
    End Property

    Property MinDate() As Date
        Get
            Return ViewState("MinDate")
        End Get
        Set(ByVal value As Date)
            ViewState("MinDate") = value
        End Set
    End Property

    Property ReportType() As Integer
        Get
            Return ViewState("ReportType")
        End Get
        Set(ByVal value As Integer)
            ViewState("ReportType") = value
        End Set
    End Property

    Property CurrentLevel() As Integer
        Get
            Return ViewState("CurrentLevel")
        End Get
        Set(ByVal value As Integer)
            ViewState("CurrentLevel") = value
        End Set
    End Property
    Property CampaignID() As Integer
        Get
            Return ViewState("CampaignID")
        End Get
        Set(ByVal value As Integer)
            ViewState("CampaignID") = value
        End Set
    End Property
    Property SupervisorID() As String
        Get
            Return ViewState("SupervisorID")
        End Get
        Set(ByVal value As String)
            ViewState("SupervisorID") = value
        End Set
    End Property
    Property UserID() As String
        Get
            Return ViewState("UserID")
        End Get
        Set(ByVal value As String)
            ViewState("UserID") = value
        End Set
    End Property
    Property AgentID() As String
        Get
            Return ViewState("AgentID")
        End Get
        Set(ByVal value As String)
            ViewState("AgentID") = value
        End Set
    End Property
    Property UserName() As String
        Get
            Return ViewState("username")
        End Get
        Set(ByVal value As String)
            ViewState("username") = value
        End Set
    End Property


    Property isManager() As Boolean
        Get
            Return ViewState("isManager")
        End Get
        Set(ByVal value As Boolean)
            ViewState("isManager") = value
        End Set
    End Property



#End Region

#Region "-----Load Activities-----"

    Private Sub LoadData()
        Dim db As New DBAccess("CRM")
        'TODO: change this query to stored procedure
        Dim dr As DataRow = db.ReturnRow("SELECT dateadd(dd,1,max([FreezeDate])) as mindate  ,getdate() as currentdate  FROM [tbl_LastFreezedDate]")
        CurrentDate = dr("currentDate")
        DateTimePicker3.value = CurrentDate.ToString("dd-MMM-yyyy")
        MinDate = dr("minDate")
        db = Nothing

        db = New DBAccess("CRM")
        db.slDataAdd("agentid", AgentID)
        Dim dtDetails As DataTable = db.ReturnTable("usp_GetAgentDetails", , True)
        db = Nothing

        isManager = False
        If dtDetails.Rows.Count > 0 Then
            isManager = CBool(dtDetails.Rows(0).Item("isManager"))
        End If

        lblDate.Text = "* You can mark the attendance between [" & MinDate.ToString("dd-MMM-yyyy") & "] and [" & CurrentDate.ToString("dd-MMM-yyyy") & "]"
        FillAllSupervisors()
        FillMovementPurpose()
        FillAllCampaigns()

        cboDay.Items.Clear()
        CboDayM.Items.Clear()
        For ictr As Integer = 1 To 31
            cboDay.Items.Add(ictr)
            CboDayM.Items.Add(ictr)
        Next
        cboDay.Items.FindByText(CurrentDate.Day).Selected = True
        CboDayM.Items.FindByText(CurrentDate.Day).Selected = True
        cboMonth.Items.Clear()
        CboMonthM.Items.Clear()
        For ictr As Integer = 1 To 12
            cboMonth.Items.Add(MonthName(ictr, True))
            CboMonthM.Items.Add(MonthName(ictr, True))
        Next
        cboMonth.Items.FindByText(MonthName(CurrentDate.Month, True)).Selected = True
        CboMonthM.Items.FindByText(MonthName(CurrentDate.Month, True)).Selected = True
        cboYear.Items.Clear()
        CboYearM.Items.Clear()
        For ictr As Integer = 2020 To 2030
            cboYear.Items.Add(ictr)
            CboYearM.Items.Add(ictr)
        Next
        cboYear.Items.FindByText(CurrentDate.Year).Selected = True
        CboYearM.Items.FindByText(CurrentDate.Year).Selected = True
    End Sub
    Private Sub FillAllSupervisors()
        Dim db As New DBAccess("CRM")
        Dim dt As DataTable
        dt = db.ReturnTable("usp_getAllSupervisors", , True)
        cboSupervisors.DataSource = dt
        cboSupervisors.DataTextField = "AgentName"
        cboSupervisors.DataValueField = "AgentID"
        cboSupervisors.DataBind()
        db = Nothing
    End Sub

    Private Sub FillMovementPurpose()
        'Dim db As New DBAccess("Dev1Attendance")
        'Dim dt As DataTable
        'dt = db.ReturnTable("usp_getMovementPurpose", , True)
        'cboSupervisors.DataSource = dt
        'cboSupervisors.DataTextField = "Caption"
        'cboSupervisors.DataValueField = "Code"
        'cboSupervisors.DataBind()
        'db = Nothing
        cboReason.Items.Add("Supervisor Change")
        cboReason.Items.Add("Process Change")
        cboReason.Items.Add("Ramp Down")
        cboReason.Items.Add("Ramp Up")
    End Sub

    Private Sub FillAllCampaigns()
        Dim db As New DBAccess '("Dev1Attendance")
        Dim dt As DataTable
        dt = db.ReturnTable("usp_GetPrimaryCampaigns", , True)
        CboMoveToCampaign.DataSource = dt
        CboMoveToCampaign.DataTextField = "processname"
        CboMoveToCampaign.DataValueField = "CampaignID"
        CboMoveToCampaign.DataBind()
        db = Nothing

    End Sub

    'Private Sub FillMenu()
    '    Dim strPath() As String
    '    strPath = Request.Url.Segments()
    '    Dim db As New DBAccess
    '    db.slDataAdd("agentid", AgentID)
    '    db.slDataAdd("module", strPath(strPath.Length - 2) & strPath(strPath.Length - 1))
    '    Dim dt As DataTable = db.ReturnTable("usp_getUserMenu", , True)
    '    Dim row As DataRow
    '    Dim tbl As New HtmlTable
    '    tbl.Attributes.Add("class", "menu")
    '    tbl.CellPadding = 4
    '    tbl.CellSpacing = 4
    '    Dim tr As HtmlTableRow
    '    Dim td As HtmlTableCell
    '    For Each row In dt.Rows
    '        '-------'
    '        tr = New HtmlTableRow
    '        td = New HtmlTableCell
    '        td.InnerHtml = "<a href='" & row("shorturl") & "'><div class='item'><span class='left'>" & _
    '                    row("name") & "</span><span class='right'><img src='../_assets/img/graygo.PNG' /></span></div></a>"
    '        tr.Cells.Add(td)
    '        tbl.Rows.Add(tr)

    '    Next
    '    PanelReports.Controls.Add(tbl)
    'End Sub
   
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        HumanMessage.Style.Item("visibility") = "hidden"
        'btsave.Attributes.Add("onclick", "this.disabled=true;" + Page.ClientScript.GetPostBackEventReference(btsave, "").ToString())

        If Not IsPostBack Then
            lblReportName.CurrentPage = "Mark Attendance"
            LblError.Visible = False

            'Session("Agentid") = "NSS64793"
            'Session("UserID") = "NSS64793"
            'Session("UserName") = "Sameer Kumar"


            AgentID = Session("Agentid")
            CampaignID = Session("Campaignid")
            PanelReports.Controls.Add(Common.GetMenu(Request.Url, AgentID, Request.ApplicationPath))
            'ReportType = Request.QueryString("ReportType")
            LoadData()
            CurrentLevel = 2
            SupervisorID = Session("UserID")
            UserID = Session("UserID")
            UserName = Session("username")
            fillgrid(SupervisorID, CDate(DateTimePicker3.value).ToString("yyyyMMdd"))
            link2.Text = Session("username") & "(" & Session("UserID") & ")"
            Image3.Visible = False
            Image4.Visible = False
            Image5.Visible = False
            Image6.Visible = False
            Image7.Visible = False
            Image8.Visible = False
            GetAverageLogintime()
        End If
        'FillMenu()
         End Sub

    Private Sub GetAverageLogintime()
        Dim startday As Integer, endday As Integer
        Dim db As New DBAccess("Report")
        db.slDataAdd("Period", 3)
        Dim dr As DataRow = db.ReturnRow("usp_GetStart_EndDateForAPeriod", True)
        db = Nothing
        startday = dr(0)
        endday = dr(1)

        db = New DBAccess("Report")
        Dim dtAvfAtte As New DataTable
        db.slDataAdd("AgentID", UserID)
        db.slDataAdd("DateFrom", startday)
        db.slDataAdd("DateTo", endday)
        dtAvfAtte = db.ReturnTable("usp_GetStaffTimeSummary", , True)

        For Each row As DataRow In dtAvfAtte.Rows
            Dim col As String = row.Item("Whose").ToString
            If col.ToLower = "team" Then
                If row.Item("hour") < "09:00:00" Then
                    lblTeamAvgAtte.ForeColor = Drawing.Color.Red
                Else
                    lblTeamAvgAtte.ForeColor = Drawing.Color.Green
                End If
                lblTeamAvgAtte.Text = row.Item("hour").ToString
            ElseIf col.ToLower = "yours" Then
                If row.Item("hour") < "09:00:00" Then
                    lblUserAvgAtte.ForeColor = Drawing.Color.Red
                Else
                    lblUserAvgAtte.ForeColor = Drawing.Color.Green
                End If
                lblUserAvgAtte.Text = row.Item("hour").ToString
            End If
        Next
        db = Nothing
        dtAvfAtte = Nothing
        '=================
        db = New DBAccess("Report")
        db.slDataAdd("Period", 2)
        Dim dr1 As DataRow = db.ReturnRow("usp_GetStart_EndDateForAPeriod", True)
        db = Nothing
        startday = dr1(0)
        endday = dr1(1)

        db = New DBAccess("Report")
        db.slDataAdd("AgentID", UserID)
        db.slDataAdd("DateFrom", startday)
        db.slDataAdd("DateTo", endday)
        dtAvfAtte = db.ReturnTable("usp_GetStaffTimeSummary", , True)
        For Each row As DataRow In dtAvfAtte.Rows
            Dim col As String = row.Item("Whose").ToString
            If col.ToLower = "team" Then
                If row.Item("hour") < "09:00:00" Then
                    lblTeamWeek.ForeColor = Drawing.Color.Red
                Else
                    lblTeamWeek.ForeColor = Drawing.Color.Green
                End If
                lblTeamWeek.Text = row.Item("hour").ToString
            ElseIf col.ToLower = "yours" Then
                If row.Item("hour") < "09:00:00" Then
                    lblUserWeek.ForeColor = Drawing.Color.Red
                Else
                    lblUserWeek.ForeColor = Drawing.Color.Green
                End If
                lblUserWeek.Text = row.Item("hour").ToString
            End If
        Next
        db = Nothing
        dtAvfAtte = Nothing

        Dim str As String
        str = "$('#DialogBackground').height($(document).height()-10);$('#DialogBackground').width($(window).width());$('#DialogBackground').css('visibility','visible');$('#pnlAttendanceSummary').css('visibility','visible');" & _
        " $('#pnlAttendanceSummary').css('left',($(window).width() - $('#pnlAttendanceSummary').width())/2); "
        ScriptManager.RegisterStartupScript(Page, Page.GetType(), "Movedialog", str, True)
    End Sub

#End Region

#Region "----Grid Ops----"
    Private Sub fillgrid(ByVal supervisorid As String, ByVal retrieveDate As String)
        'ImgMarkedorNot.ImageUrl = "~/_assets/img/yes.gif"
        GdAttendance.Columns(1).Visible = True
        GdAttendance.Columns(GdAttendance.Columns.Count - 1).Visible = True
        GdAttendance.Columns(GdAttendance.Columns.Count - 2).Visible = True
        ' GdAttendance.Columns(GdAttendance.Columns.Count - 4).Visible = True  '''' For Roster Shift

        Dim db As New DBAccess("CRM")

        db.slDataAdd("supervisorid", supervisorid)
        db.slDataAdd("markedDate", retrieveDate)
        ' Dim dt As DataTable = db.ReturnTable("usp_retrieveAttendanceData", , True)
        Dim dt As DataTable = db.ReturnTable("usp_getHierarchy", , True)
        'Dim dt As DataTable = db.ReturnTable("usp_getHierarchy_Test", , True)

        ' Dim dt As DataTable = db.ReturnTable("usp_getHierarchy_12_Aug_2016", , True)

        GdAttendance.DataSource = dt.DefaultView
        GdAttendance.DataBind()
        db = Nothing
        If dt.Rows.Count < 1 Then
            btsave.Enabled = False
            'btreset.Visible = False
        Else
            btsave.Enabled = True
            For Each row As DataRow In dt.Rows
                If row.Item("Marked") = 0 Then
                    ImgMarkedorNot.ImageUrl = "~/_assets/img/why.gif"
                    LblMarkedorNot.Text = "Not Marked"
                    Exit For
                Else
                    ImgMarkedorNot.ImageUrl = "~/_assets/img/yes.gif"
                    LblMarkedorNot.Text = "Marked"
                End If
            Next

            'If dt.Rows(0)("marked") = 1 Then
            '    ImgMarkedorNot.ImageUrl = "~/_assets/img/yes.gif"
            '    LblMarkedorNot.Text = "Marked"
            'Else
            '    ImgMarkedorNot.ImageUrl = "~/_assets/img/why.gif"
            '    LblMarkedorNot.Text = "Not Marked"
            'End If
        End If
        GdAttendance.Columns(1).Visible = False
        GdAttendance.Columns(GdAttendance.Columns.Count - 1).Visible = False
        GdAttendance.Columns(GdAttendance.Columns.Count - 2).Visible = False
        ' GdAttendance.Columns(GdAttendance.Columns.Count - 4).Visible = False  '''' For Roster Shift


    End Sub
    Private Function IntegerToDateString(ByVal d As Integer) As String
        Return d.ToString.Substring(0, 4) & "-" & d.ToString.Substring(4, 2) & "-" & d.ToString.Substring(6, 2)
    End Function
    Protected Sub GdAttendance_RowDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles GdAttendance.RowDataBound
        If e.Row.RowType = DataControlRowType.DataRow Then
            If e.Row.Cells(e.Row.Cells.Count - 1).Text.ToLower = "false" Or CType(e.Row.FindControl("lblAgentID"), Label).Text = SupervisorID Then
                'Dim btagent As New Label
                'btagent.Text = e.Row.Cells(1).Text
                'e.Row.Cells(0).Text = ""
                'e.Row.Cells(0).Controls.Clear()
                'e.Row.Cells(0).Controls.Add(btagent)
                CType(e.Row.FindControl("lnkbtagentname"), LinkButton).Visible = False

            Else
                CType(e.Row.FindControl("lblAgentName"), Label).Visible = False
            End If


            Select Case e.Row.Cells(e.Row.Cells.Count - 2).Text ' i.e. the attendance status 1,2,3,4
                Case 1
                    CType(e.Row.FindControl("rdpresent"), RadioButton).Checked = True
                Case 2
                    CType(e.Row.FindControl("rdLWP"), RadioButton).Checked = True
                Case 3
                    CType(e.Row.FindControl("rdAbsent"), RadioButton).Checked = True
                Case 4
                    CType(e.Row.FindControl("rdleave"), RadioButton).Checked = True
                Case 11
                    CType(e.Row.FindControl("rdmleave"), RadioButton).Checked = True
                Case 12
                    CType(e.Row.FindControl("rdpleave"), RadioButton).Checked = True
                Case 13
                    CType(e.Row.FindControl("rdbleave"), RadioButton).Checked = True
                Case 14
                    CType(e.Row.FindControl("rdmisleave"), RadioButton).Checked = True
                Case 5
                    CType(e.Row.FindControl("rdHalfDay"), RadioButton).Checked = True
                Case 6
                    CType(e.Row.FindControl("rdLWPHalfDay"), RadioButton).Checked = True
                Case 7
                    CType(e.Row.FindControl("rdWeeklyoff"), RadioButton).Checked = True
                Case 8
                    CType(e.Row.FindControl("rdWorkingOutOfOffice"), RadioButton).Checked = True
                Case 9
                    CType(e.Row.FindControl("rdUnschedule"), RadioButton).Checked = True
                Case 10
                    CType(e.Row.FindControl("rdUnscheduleHD"), RadioButton).Checked = True
                Case ""
                    CType(e.Row.FindControl("rdpresent"), RadioButton).Checked = True
                Case Else
                    CType(e.Row.FindControl("rdpresent"), RadioButton).Checked = True
            End Select

            If Not isManager Then
                Select Case CType(e.Row.FindControl("lblRoster"), Label).Text '''' Roster Shift in Label
                    Case "OFF" '''' Leave,LWP,HalfDayLWP
                        CType(e.Row.FindControl("rdpresent"), RadioButton).Enabled = False '-C
                        CType(e.Row.FindControl("rdleave"), RadioButton).Enabled = True
                        CType(e.Row.FindControl("rdmleave"), RadioButton).Enabled = True
                        CType(e.Row.FindControl("rdpleave"), RadioButton).Enabled = True
                        CType(e.Row.FindControl("rdmisleave"), RadioButton).Enabled = True
                        CType(e.Row.FindControl("rdbleave"), RadioButton).Enabled = True
                        CType(e.Row.FindControl("rdAbsent"), RadioButton).Enabled = False
                        CType(e.Row.FindControl("rdLWP"), RadioButton).Enabled = True

                        CType(e.Row.FindControl("rdHalfDay"), RadioButton).Enabled = True '@20210122 fix for Pramod half day Leave 
                        CType(e.Row.FindControl("rdLWPHalfDay"), RadioButton).Enabled = True
                        CType(e.Row.FindControl("rdWeeklyoff"), RadioButton).Enabled = True ''to be Changed
                        CType(e.Row.FindControl("rdWorkingOutOfOffice"), RadioButton).Enabled = True ''C
                        CType(e.Row.FindControl("rdUnschedule"), RadioButton).Enabled = True ''C
                        CType(e.Row.FindControl("rdUnscheduleHD"), RadioButton).Enabled = True ''A

                    Case "WO" '''' Leave,LWP,HalfDayLWP,WO   ---- Changes on 12-Aug-2016
                        CType(e.Row.FindControl("rdpresent"), RadioButton).Enabled = False '-C
                        CType(e.Row.FindControl("rdleave"), RadioButton).Enabled = False
                        CType(e.Row.FindControl("rdmleave"), RadioButton).Enabled = True
                        CType(e.Row.FindControl("rdpleave"), RadioButton).Enabled = True
                        CType(e.Row.FindControl("rdmisleave"), RadioButton).Enabled = True
                        CType(e.Row.FindControl("rdbleave"), RadioButton).Enabled = True
                        CType(e.Row.FindControl("rdAbsent"), RadioButton).Enabled = False
                        CType(e.Row.FindControl("rdLWP"), RadioButton).Enabled = False

                        CType(e.Row.FindControl("rdHalfDay"), RadioButton).Enabled = False
                        CType(e.Row.FindControl("rdLWPHalfDay"), RadioButton).Enabled = False
                        CType(e.Row.FindControl("rdWeeklyoff"), RadioButton).Enabled = True ''to be Changed
                        CType(e.Row.FindControl("rdWorkingOutOfOffice"), RadioButton).Enabled = False ''C
                        CType(e.Row.FindControl("rdUnschedule"), RadioButton).Enabled = False ''C
                        CType(e.Row.FindControl("rdUnscheduleHD"), RadioButton).Enabled = False ''A


                    Case "NA" '' All Enabled
                        CType(e.Row.FindControl("rdpresent"), RadioButton).Enabled = False '-C
                        CType(e.Row.FindControl("rdLWP"), RadioButton).Enabled = True
                        CType(e.Row.FindControl("rdAbsent"), RadioButton).Enabled = True
                        CType(e.Row.FindControl("rdleave"), RadioButton).Enabled = True
                        CType(e.Row.FindControl("rdmleave"), RadioButton).Enabled = True
                        CType(e.Row.FindControl("rdpleave"), RadioButton).Enabled = True
                        CType(e.Row.FindControl("rdmisleave"), RadioButton).Enabled = True
                        CType(e.Row.FindControl("rdbleave"), RadioButton).Enabled = True
                        CType(e.Row.FindControl("rdHalfDay"), RadioButton).Enabled = True
                        CType(e.Row.FindControl("rdLWPHalfDay"), RadioButton).Enabled = True
                        CType(e.Row.FindControl("rdWeeklyoff"), RadioButton).Enabled = True
                        CType(e.Row.FindControl("rdWorkingOutOfOffice"), RadioButton).Enabled = True
                        CType(e.Row.FindControl("rdUnschedule"), RadioButton).Enabled = True
                        CType(e.Row.FindControl("rdUnscheduleHD"), RadioButton).Enabled = True ''A
                    Case "NO TPT" '' same as shift sent
                        CType(e.Row.FindControl("rdpresent"), RadioButton).Enabled = False '-C
                        CType(e.Row.FindControl("rdLWP"), RadioButton).Enabled = True ''C
                        CType(e.Row.FindControl("rdAbsent"), RadioButton).Enabled = True
                        CType(e.Row.FindControl("rdleave"), RadioButton).Enabled = True
                        CType(e.Row.FindControl("rdmleave"), RadioButton).Enabled = True
                        CType(e.Row.FindControl("rdpleave"), RadioButton).Enabled = True
                        CType(e.Row.FindControl("rdmisleave"), RadioButton).Enabled = True
                        CType(e.Row.FindControl("rdbleave"), RadioButton).Enabled = True
                        CType(e.Row.FindControl("rdHalfDay"), RadioButton).Enabled = True
                        CType(e.Row.FindControl("rdLWPHalfDay"), RadioButton).Enabled = True
                        CType(e.Row.FindControl("rdWeeklyoff"), RadioButton).Enabled = False ''C
                        CType(e.Row.FindControl("rdWorkingOutOfOffice"), RadioButton).Enabled = True
                        CType(e.Row.FindControl("rdUnschedule"), RadioButton).Enabled = True
                        CType(e.Row.FindControl("rdUnscheduleHD"), RadioButton).Enabled = True ''A

                    Case "SELF" ''considered as Roster has been sent with predefined shifts e.g. A1.A2.M1,M2 etc
                        CType(e.Row.FindControl("rdpresent"), RadioButton).Enabled = True '-C
                        CType(e.Row.FindControl("rdLWP"), RadioButton).Enabled = True ''C
                        CType(e.Row.FindControl("rdAbsent"), RadioButton).Enabled = True
                        CType(e.Row.FindControl("rdleave"), RadioButton).Enabled = True
                        CType(e.Row.FindControl("rdmleave"), RadioButton).Enabled = True
                        CType(e.Row.FindControl("rdpleave"), RadioButton).Enabled = True
                        CType(e.Row.FindControl("rdmisleave"), RadioButton).Enabled = True
                        CType(e.Row.FindControl("rdbleave"), RadioButton).Enabled = True
                        CType(e.Row.FindControl("rdHalfDay"), RadioButton).Enabled = True
                        CType(e.Row.FindControl("rdLWPHalfDay"), RadioButton).Enabled = True
                        CType(e.Row.FindControl("rdWeeklyoff"), RadioButton).Enabled = True ''C
                        CType(e.Row.FindControl("rdWorkingOutOfOffice"), RadioButton).Enabled = True
                        CType(e.Row.FindControl("rdUnschedule"), RadioButton).Enabled = True
                        CType(e.Row.FindControl("rdUnscheduleHD"), RadioButton).Enabled = True ''A

                    Case Else ''considered as Roster has been sent with predefined shifts e.g. A1.A2.M1,M2 etc
                        CType(e.Row.FindControl("rdpresent"), RadioButton).Enabled = False '-C
                        CType(e.Row.FindControl("rdLWP"), RadioButton).Enabled = True ''C
                        CType(e.Row.FindControl("rdAbsent"), RadioButton).Enabled = True
                        CType(e.Row.FindControl("rdleave"), RadioButton).Enabled = True
                        CType(e.Row.FindControl("rdmleave"), RadioButton).Enabled = False
                        CType(e.Row.FindControl("rdpleave"), RadioButton).Enabled = False
                        CType(e.Row.FindControl("rdmisleave"), RadioButton).Enabled = False
                        CType(e.Row.FindControl("rdbleave"), RadioButton).Enabled = False
                        CType(e.Row.FindControl("rdHalfDay"), RadioButton).Enabled = True
                        CType(e.Row.FindControl("rdLWPHalfDay"), RadioButton).Enabled = True
                        CType(e.Row.FindControl("rdWeeklyoff"), RadioButton).Enabled = False ''C
                        CType(e.Row.FindControl("rdWorkingOutOfOffice"), RadioButton).Enabled = True
                        CType(e.Row.FindControl("rdUnschedule"), RadioButton).Enabled = True
                        CType(e.Row.FindControl("rdUnscheduleHD"), RadioButton).Enabled = True ''A
                End Select
            End If

            If Not CboMoveToCampaign.Items.FindByText(CType(e.Row.FindControl("lblprocess"), Label).Text) Is Nothing Then
                CboMoveToCampaign.SelectedValue = CboMoveToCampaign.Items.FindByText(CType(e.Row.FindControl("lblprocess"), Label).Text).Value
            End If

        End If

    End Sub
#End Region

#Region "-----Date movement-----"

   

    Private Function validdate(ByVal selecteddate As DateTime) As Boolean
        If selecteddate > CurrentDate Or selecteddate < MinDate Then
            Return False
        End If
        Return True
        'Try
        '    'fromdate = Convert.ToDateTime(21 & "/" & DateAdd(DateInterval.Month, -1, CurrentDate).Month & "/" & DateAdd(DateInterval.Month, -1, CurrentDate).Year)
        '    'todate = Convert.ToDateTime(20 & "/" & CurrentDate.Month & "/" & CurrentDate.Year)
        '    fromdate = DateAdd(DateInterval.Month, -1, CurrentDate)
        '    If selecteddate > CurrentDate.Date Then
        '        Return False
        '    ElseIf selecteddate < fromdate.Date Then
        '        Return False
        '    Else
        '        Return True
        '    End If
        'Catch ex As Exception
        '    LblError.Visible = True
        '    LblError.Text = ex.ToString
        '    'Return False
        'End Try
        Return True
    End Function

    Protected Sub btnrefresh_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnrefresh.Click
        If validdate(Date.ParseExact(DateTimePicker3.value, "yyyyMMdd", System.Globalization.DateTimeFormatInfo.InvariantInfo).ToString("dd/MMM/yyyy")) Then

            ' DateTimePicker3.value = DateAdd(DateInterval.Day, -1, CDate(DateTimePicker3.value))
            fillgrid(SupervisorID, DateTimePicker3.value)
        Else
            AlertMessage("Date is not in valid range.")

        End If
    End Sub

    Protected Sub btdatedecrease_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btdatedecrease.Click
        If validdate(DateAdd(DateInterval.Day, -1, CDate(DateTimePicker3.value))) Then
            DateTimePicker3.value = DateAdd(DateInterval.Day, -1, CDate(DateTimePicker3.value))
            fillgrid(SupervisorID, CDate(DateTimePicker3.value).ToString("yyyyMMdd"))
        Else
            AlertMessage("Date not in valid range.")

        End If
    End Sub

    Protected Sub btdateincrease_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btdateincrease.Click

        If validdate(DateAdd(DateInterval.Day, 1, CDate(DateTimePicker3.value))) Then
            DateTimePicker3.value = DateAdd(DateInterval.Day, 1, CDate(DateTimePicker3.value))
            fillgrid(SupervisorID, CDate(DateTimePicker3.value).ToString("yyyyMMdd"))
        Else
            AlertMessage("Date not in valid range.")
        End If
    End Sub

    'Protected Sub txtDate_Changed(ByVal sender As Object, ByVal e As System.EventArgs) Handles DateTimePicker3.Changed
    '    If validdate(CDate(DateTimePicker3.value).ToString("yyyyMMdd")) Then
    '        fillgrid(SupervisorID, CDate(DateTimePicker3.value).ToString("yyyyMMdd"))
    '    Else
    '        AlertMessage("Date not in valid range")
    '        CDate(DateTimePicker3.value).ToString("yyyyMMdd") = CurrentDate
    '        fillgrid(SupervisorID, CDate(DateTimePicker3.value).ToString("yyyyMMdd"))
    '    End If
    'End Sub
#End Region

#Region "-----Supervisor change-----"


    Protected Sub GdAttendance_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles GdAttendance.SelectedIndexChanged

        Dim lnk As New LinkButton, img As New Image
        CurrentLevel += 1
        Select Case CurrentLevel
            Case 3
                lnk = link3
                img = Image3
                link2.CssClass = "notselectedlink"
            Case 4
                lnk = Link4
                img = Image4
                link3.CssClass = "notselectedlink"
            Case 5
                lnk = Link5
                img = Image5
                Link4.CssClass = "notselectedlink"
            Case 6
                lnk = Link6
                img = Image6
                Link5.CssClass = "notselectedlink"
            Case 7
                lnk = Link7
                img = Image7
                Link6.CssClass = "notselectedlink"
            Case 8
                lnk = Link8
                img = Image8
                Link7.CssClass = "notselectedlink"
        End Select
        lnk.Text = GdAttendance.SelectedDataKey.Item("AgentName").ToString & "(" & GdAttendance.SelectedDataKey.Item("AgentID").ToString & ")"
        SupervisorID = GdAttendance.SelectedDataKey.Item("AgentID").ToString
        fillgrid(SupervisorID, CDate(DateTimePicker3.value).ToString("yyyyMMdd"))

        lnk.Visible = True
        lnk.CssClass = "selectedlink"
        img.Visible = True

    End Sub

    Private Sub HideAllSideLinks(ByVal ctrl As LinkButton)
        Dim from As Integer
        from = ctrl.ID.ToLower.Replace("link", "")
        CurrentLevel = from

        Select Case from
            Case 2
                link3.Visible = False
                Link4.Visible = False
                Link5.Visible = False
                Link6.Visible = False
                Link7.Visible = False
                Link8.Visible = False

                Image3.Visible = False
                Image4.Visible = False
                Image5.Visible = False
                Image6.Visible = False
                Image7.Visible = False
                Image8.Visible = False
            Case 3
                Link4.Visible = False
                Link5.Visible = False
                Link6.Visible = False
                Link7.Visible = False
                Link8.Visible = False
                Image4.Visible = False
                Image5.Visible = False
                Image6.Visible = False
                Image7.Visible = False
                Image8.Visible = False
            Case 4

                Link5.Visible = False
                Link6.Visible = False
                Link7.Visible = False
                Link8.Visible = False
                Image5.Visible = False
                Image6.Visible = False
                Image7.Visible = False
                Image8.Visible = False
            Case 5

                Link6.Visible = False
                Link7.Visible = False
                Link8.Visible = False

                Image6.Visible = False
                Image7.Visible = False
                Image8.Visible = False
            Case 6

                Link7.Visible = False
                Link8.Visible = False

                Image7.Visible = False
                Image8.Visible = False
            Case 7

                Link8.Visible = False

                Image8.Visible = False
            Case 8
                'do noting
        End Select
    End Sub

    Protected Sub Sidelink_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles link2.Click

        Dim length As Integer

        length = sender.Text.LastIndexOf(")") - sender.Text.LastIndexOf("(")

        SupervisorID = sender.Text.Substring(sender.Text.LastIndexOf("(") + 1, length - 1)
        fillgrid(SupervisorID, CDate(DateTimePicker3.value).ToString("yyyyMMdd"))
        HideAllSideLinks(sender)
        sender.CssClass = "selectedlink"
    End Sub

#End Region

    Protected Sub btsave_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btsave.Click
        btsave.Enabled = False
        Dim db As New DBAccess("CRM")
        Dim resign = "", aod = "", Transfer = "", Move = "", Terminated = "", revoke As String = ""
        Dim inStatusID As Short
        Dim markedDate As String
        Dim rb1, rb2, rb3, rb4, rb5, rb6, rb7, rb8, rb9, rb10, rb11, rb12, rb13, rb14 As RadioButton, lbAgentid As Label


        ' Dim regex As Regex = New Regex("(((0|1)[0-9]|2[0-9]|3[0-1])\/(0[1-9]|1[0-2])\/((19|20)\d\d))$")
        'Verify whether date entered in dd/MM/yyyy format.
       ' Dim isValid As Boolean = regex.IsMatch(DateTimePicker3.value.Trim)

        Dim isValid As Boolean '
        'Verify whether entered date is Valid date.
        Dim dt As DateTime
        isValid = DateTime.TryParseExact(DateTimePicker3.value.Trim, "yyyyMMdd", New CultureInfo("en-GB"), DateTimeStyles.None, dt)
        If isValid Then
            markedDate = CDate(Date.ParseExact(DateTimePicker3.value, "yyyyMMdd", System.Globalization.DateTimeFormatInfo.InvariantInfo, DateTimeStyles.None)).ToString("yyyyMMdd")

        Else
            markedDate = CDate(DateTimePicker3.value).ToString("yyyyMMdd")
        End If

            'markedDate = Date.ParseExact(DateTimePicker3.value, "yyyyMMdd", System.Globalization.DateTimeFormatInfo.InvariantInfo).ToString("dd/MMM/yyyy")
        For Each dgRow As GridViewRow In GdAttendance.Rows
            db.slDataAdd("markeddate", markedDate)
            lbAgentid = dgRow.FindControl("lblAgentID")
            db.slDataAdd("agentid", lbAgentid.Text)

            rb1 = dgRow.FindControl("rdpresent")
            rb2 = dgRow.FindControl("rdleave")
            rb3 = dgRow.FindControl("rdAbsent")
            rb4 = dgRow.FindControl("rdLWP")
            rb5 = dgRow.FindControl("rdHalfDay")
            rb6 = dgRow.FindControl("rdLWPHalfDay")
            rb7 = dgRow.FindControl("rdWeeklyoff")
            rb9 = dgRow.FindControl("rdUnschedule") '''''rajkumar added 29-July-2016
            rb10 = dgRow.FindControl("rdUnscheduleHD") '''''rajkumar added 29-July-2016
            rb8 = dgRow.FindControl("rdWorkingOutOfOffice")
            rb11 = dgRow.FindControl("rdmleave")
            rb12 = dgRow.FindControl("rdpleave")
            rb13 = dgRow.FindControl("rdbleave")
            rb14 = dgRow.FindControl("rdmisleave")
            ''Commented Below 10-Aug-2016
            'If rb1.Checked = True Then
            '    inStatusID = 1
            'Else

            If rb2.Checked = True Then
                inStatusID = 4
            ElseIf rb4.Checked = True Then
                inStatusID = 2
            ElseIf rb5.Checked = True Then
                inStatusID = 5
            ElseIf rb6.Checked = True Then
                inStatusID = 6
            ElseIf rb7.Checked = True Then
                inStatusID = 7
            ElseIf rb8.Checked = True Then
                inStatusID = 8
            ElseIf rb9.Checked = True Then
                inStatusID = 9
            ElseIf rb10.Checked = True Then
                inStatusID = 10
            ElseIf rb11.Checked = True Then
                inStatusID = 11
            ElseIf rb12.Checked = True Then
                inStatusID = 12
            ElseIf rb13.Checked = True Then
                inStatusID = 13
            ElseIf rb14.Checked = True Then
                inStatusID = 14

            ElseIf rb3.Checked = True Then
                inStatusID = 3
            ElseIf rb1.Checked = True Then  ' for Present '' As present is last option and will be disbled so put as the last option
                inStatusID = 1
            Else
                'error message
            End If



            Dim moveunder As String = CType(dgRow.FindControl("lnkmove"), LinkButton).Text.Replace("Under", "").Trim
            'moveunder = CType(dgRow.FindControl("lnkmove"), LinkButton).Text.Replace("Under", "").Trim
            moveunder = moveunder.Replace("Move", "").Trim()
            If moveunder <> "" Then
                If moveunder.Contains("Pending") Then
                    'do nothing
                ElseIf moveunder.Contains("Revoke") Then
                    db.slDataAdd("moveunder", moveunder.Trim)
                    Move = "Revoke"
                Else
                    Move = "Move"
                    Dim reason As String = CType(dgRow.FindControl("lblMoveInfo"), Label).Text.Replace("*", "")
                    Dim newcampaign As String = reason.Substring(reason.LastIndexOf("CampaignID:")).Replace("CampaignID:", "")
                    reason = reason.Substring(0, reason.LastIndexOf("CampaignID:"))

                    db.slDataAdd("newcampaign", newcampaign)
                    db.slDataAdd("moveunder", moveunder.Substring(0, moveunder.ToLower.IndexOf(" on")).Trim)
                    db.slDataAdd("reason", reason)
                    db.slDataAdd("moveon", moveunder.Substring(moveunder.ToLower.IndexOf(" on ") + 4).Trim)
                End If

            End If
            Dim resigned As String = CType(dgRow.FindControl("lnkChangeStatus"), LinkButton).Text
            resigned = resigned.Replace("Change", "").Trim()
            'If resigned <> "" And Not resigned.ToLower.Contains("pending") And Not resigned.ToLower.Contains("resigned on") Then
            If resigned.ToLower.Contains("marked as") Or resigned.ToLower.Contains("revoke") Then
                resigned = resigned.ToLower.Replace("marked as ", "")
                If resigned.ToLower.StartsWith("revoke") Then
                    db.slDataAdd("Status", "Revoke")
                    revoke = "Revoke"
                ElseIf resigned.ToLower.StartsWith("aod on") Then
                    db.slDataAdd("Status", "AOD")
                    aod = "AOD"
                    resigned = resigned.ToLower.Replace("aod on", "").Trim
                ElseIf resigned.ToLower.StartsWith("resigned on") Then
                    db.slDataAdd("Status", "Resigned")
                    resign = "Resigned"
                    resigned = resigned.ToLower.Replace("resigned on", "").Trim
                ElseIf resigned.ToLower.StartsWith("terminated on") Then
                    db.slDataAdd("Status", "Termination")
                    Terminated = "Terminated"
                    resigned = resigned.ToLower.Replace("terminated on", "").Trim
                ElseIf resigned.ToLower.StartsWith("transferred on") Then
                    db.slDataAdd("Status", "Transferred")
                    Transfer = "Transferred"
                    resigned = resigned.ToLower.Replace("transferred on", "").Trim
                End If
                db.slDataAdd("ResignedOn", resigned)
            End If

            db.slDataAdd("markedas", inStatusID)
            db.slDataAdd("markedby", UserID)
            db.slDataAdd("BySystem", 0)
            db.Executeproc("usp_saveAttendanceData")
        Next


        If resign.ToLower.StartsWith("resigned") Then
            Resigned_AODMail()
        ElseIf aod.ToLower.StartsWith("aod") Then
            Resigned_AODMail()
        ElseIf Transfer.ToLower.StartsWith("transferred") Then
            Resigned_AODMail()
        ElseIf Terminated.ToLower.StartsWith("terminated") Then
            Resigned_AODMail()
        End If
        If revoke.ToLower.StartsWith("revoke") Then
            Resigned_AOD_RevokeMail()
            ' ElseIf moveunder <> "" And moveunder <> "Revoke" Then
        End If
        If Move.ToLower.StartsWith("move") Or Move.ToLower.StartsWith("revoke") Then
            HierarchyMovmentMail()
        End If
        fillgrid(SupervisorID, CDate(DateTimePicker3.value).ToString("yyyyMMdd"))
        SuccessMessage("Saved")
        btsave.Enabled = True
    End Sub

#Region "Movement & Resign"
    Protected Sub GdAttendance_RowCommand(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewCommandEventArgs) Handles GdAttendance.RowCommand
        Dim row As GridViewRow = CType(CType(e.CommandSource, Control).NamingContainer, GridViewRow)
        'AlertMessage(row.Cells(GdAttendance.Columns.Count - 1).Text)
        'Return
        If e.CommandName = "Move" Then

            Dim moveunder As String = CType(row.FindControl("lnkmove"), LinkButton).Text
            If moveunder.Contains("Under") Then
                btnRevokeMovement.Visible = True
                btnMoveOK.Visible = False
                lblUnder.Visible = False
                CboMoveToCampaign.Visible = False
                lblMoveToCampaign.Visible = False
                cboSupervisors.Visible = False
                lblMoveReason.Visible = False
                cboReason.Visible = False
                CboDayM.Visible = False
                CboMonthM.Visible = False
                CboYearM.Visible = False
                lblMoveon.Visible = False
                lblMoveAgent.Text = "Revoke movement of  Employee: " & e.CommandArgument & "?"
            Else
                lblMoveAgent.Text = "Move Employee: " & e.CommandArgument
                btnRevokeMovement.Visible = False
                btnMoveOK.Visible = True
                lblUnder.Visible = True
                cboSupervisors.Visible = True
                lblMoveReason.Visible = True
                cboReason.Visible = True
                CboMoveToCampaign.Visible = True
                lblMoveToCampaign.Visible = True
                CboDayM.Visible = True
                CboMonthM.Visible = True
                CboYearM.Visible = True
                lblMoveon.Visible = True
            End If
            lblRowindex.Text = row.RowIndex

            Dim str As String
            str = "$('#DialogBackground').height($(document).height()-10);$('#DialogBackground').width($(window).width());$('#DialogBackground').css('visibility','visible');$('#PanelMove').css('visibility','visible');" & _
            " $('#PanelMove').css('left',($(window).width() - $('#PanelMove').width())/2); "
            ScriptManager.RegisterStartupScript(Page, Page.GetType(), "Movedialog", str, True)

        ElseIf e.CommandName = "Resign" Then

            Dim status As String = CType(row.FindControl("lnkChangeStatus"), LinkButton).Text
            Dim dbstatus As String = CType(row.FindControl("lblStatusInfo"), Label).Text
            If status = "Change" Then
                lblResignAgent.Text = "Mark Employee: " & e.CommandArgument & " as "
                cboDay.Visible = True
                cboMonth.Visible = True
                cboYear.Visible = True
                btnResignOK.Visible = True
                RbAOD.Visible = True
                RbResign.Visible = True
                RbTransfer.Visible = True
                RbTermination.Visible = True
                lblreon.Visible = True
                btnRevokeResign.Visible = False
                'show dialog
            ElseIf status.Contains("Pending") Or dbstatus.Trim = "Change" Then
                'show revoke
                cboDay.Visible = False
                cboMonth.Visible = False
                cboYear.Visible = False
                btnResignOK.Visible = False
                RbAOD.Visible = False
                RbResign.Visible = False
                RbTransfer.Visible = False
                RbTermination.Visible = False
                lblreon.Visible = False
                btnRevokeResign.Visible = True
                lblResignAgent.Text = "Revoke Resigantion/AOD/Transfer/Termination of Employee: " & e.CommandArgument & "?"

            Else
                'Show you can do anything
                AlertMessage("No Action possible. Employee: " & e.CommandArgument & " already marked as Resigned/AOD/Transfer/Termination.")
                Return
                'lblResignAgent.Text = "Employee: " & e.CommandArgument & " already marked as Resigned/AOD"
            End If
            lblRowIndexR.Text = row.RowIndex

            Dim str As String
            str = "$('#DialogBackground').height($(document).height()- 6);$('#DialogBackground').width($(window).width());$('#DialogBackground').css('visibility','visible');$('#PanelResign').css('visibility','visible');" & _
            " $('#PanelResign').css('left',($(window).width() - $('#PanelResign').width())/2); "
            ScriptManager.RegisterStartupScript(Page, Page.GetType(), "Resigndialog", str, True)
        End If
    End Sub

    Protected Sub btnMoveOK_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnMoveOK.Click
        Dim moveondate As String = CboYearM.SelectedValue.ToString & (CboMonthM.SelectedIndex + 1).ToString.PadLeft(2, "0") & CboDayM.SelectedValue.ToString.PadLeft(2, "0")
        If moveondate < CurrentDate.ToString("yyyyMMdd") Then
            AlertMessage("Movement date can not be less than current date")
            Exit Sub
        End If

        Dim lnk As LinkButton = GdAttendance.Rows(lblRowindex.Text).FindControl("lnkMove") '.Cells(10).Controls(0)
        lnk.Text = "Under " & cboSupervisors.SelectedValue & " On " & moveondate


        Dim lbl As Label = GdAttendance.Rows(lblRowindex.Text).FindControl("lblMoveinfo")

        If lbl.Text.Trim = "" Then
            lbl.Text = "*"
        End If
        If lbl.Text.Contains("*") Then
            lbl.Text = "*" & cboReason.SelectedItem.Text & "CampaignID:" & CboMoveToCampaign.SelectedValue
        Else
            lbl.Text = cboReason.SelectedItem.Text & "CampaignID:" & CboMoveToCampaign.SelectedValue
        End If
    End Sub
    Protected Sub btnRevokeMovement_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnRevokeMovement.Click
        Dim lnk As LinkButton = GdAttendance.Rows(lblRowindex.Text).FindControl("lnkMove")
        'If lnk.Text.Contains("Pending") Then
        lnk.Text = "Revoke"
        'Else
        '    lnk.Text = "Move"
        'End If
        Dim lbl As Label = GdAttendance.Rows(lblRowindex.Text).FindControl("lblMoveinfo")
        If lbl.Text.Contains("*") Then
            lbl.Text = ""
            lnk.Text = "Move"
        Else
            lnk.Text = "Revoke"
        End If

    End Sub
    Protected Sub btnRevokeResign_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnRevokeResign.Click
        Dim lnk As LinkButton = GdAttendance.Rows(lblRowIndexR.Text).FindControl("lnkChangeStatus")
        Dim dbstatus As String = CType(GdAttendance.Rows(lblRowIndexR.Text).FindControl("lblStatusInfo"), Label).Text
        If dbstatus.Contains("Change") Then
            lnk.Text = "Change"
        Else
            lnk.Text = "Revoke"

        End If

    End Sub
    Protected Sub btnResignOK_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnResignOK.Click
        Dim lnk As LinkButton = GdAttendance.Rows(lblRowIndexR.Text).FindControl("lnkChangeStatus")
        Dim reaod As String
        If RbAOD.Checked Then
            reaod = "Marked as AOD"
        ElseIf RbTransfer.Checked Then
            reaod = "Marked as Transferred"
        ElseIf RbTermination.Checked Then
            reaod = "Marked as Terminated"
        Else
            reaod = "Marked as Resigned"
        End If

        If IsDate(cboYear.SelectedItem.Text & "-" & (cboMonth.SelectedIndex + 1).ToString.PadLeft(2, "0") & "-" & cboDay.SelectedItem.Text.PadLeft(2, "0")) Then
            Dim redate As Date = cboYear.SelectedItem.Text & "-" & (cboMonth.SelectedIndex + 1).ToString.PadLeft(2, "0") & "-" & cboDay.SelectedItem.Text.PadLeft(2, "0")

            If redate >= MinDate Then
                lnk.Text = reaod & " on " & cboYear.SelectedItem.Text & (cboMonth.SelectedIndex + 1).ToString.PadLeft(2, "0") & cboDay.SelectedItem.Text.PadLeft(2, "0")
            Else
                AlertMessage("Can not mark " & reaod & " prior to " & MinDate.ToString("d") & ".")
            End If
        Else
            AlertMessage(reaod & " date is not valid.")
        End If

    End Sub

#End Region

#Region "Utility"

    Private Sub AlertMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMFail"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub

    Private Sub SuccessMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMSuccess"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub

    'Protected Sub ImageButton1_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton1.Click
    '    'fillgrid()
    '    GridViewExportUtil.Export(lblReportName.CurrentPage & "-" & LblError.Text & ".xls", Me.GdAttendance)
    'End Sub


    Public Overrides Sub VerifyRenderingInServerForm(ByVal Control As Control)
        
    End Sub

#End Region


#Region "==== Mail ===="
    Dim Agent As String

    Private Sub Resigned_AODMail()
        Dim db As DBAccess
        Dim MarkedDate, RelievingDate As DateTime
        Dim srno As Int16 = 0
        Dim strMailBody = "", strMailAODBody = "", MarkedAs As String = ""
        Dim strMailAODRows As String = ""
        Dim status As String = ""
        Dim rb1, rb2, rb3, rb4, rb5, rb6, rb7, rb9, rb10 As RadioButton
        db = New DBAccess("CRM")
        MarkedDate = db.ReturnValue("select convert(datetime,convert(varchar," & CDate(DateTimePicker3.value).ToString("yyyyMMdd") & "))", False)
        db = Nothing
        strMailBody += "<html xmlns='http://www.w3.org/1999/xhtml'>"
        strMailBody += "<body style='font-family: Verdana; font-size: .8em'>"
        strMailBody += "<strong>Following people have been marked as Resigned / AOD / Transferred / Termination </strong><br /><br />"
        strMailBody += "<table border='1' width='90%' style='border: 1px solid; border-collapse: collapse; font-family: Verdana; font-size: .8em'>"
        strMailBody += "<tr>"
        strMailBody += "<td align='center'><b>Sr. No.</b></td>"
        strMailBody += "<td align='center'><b>Agent Name</b></td>"
        strMailBody += "<td align='center'><b>Emp. Code</b></td>"
        strMailBody += "<td align='center'><b>Process</b></td>"
        strMailBody += "<td align='center'><b>Marked As</b></td>"
        strMailBody += "<td align='center'><b>Resigned As</b></td>"
        strMailBody += "<td align='center'><b>Relieving Date</b></td></tr>"
        strMailBody += "<tr><td colspan='7'>"
        'strMailBody += "ON " & Convert.ToDateTime(MarkedDate).ToString("dd/MM/yyyy") & "  by  " & Session("username") & "</td></tr>"
        strMailBody += "ON " & CurrentDate.ToString("dd/MM/yyyy") & "  by  " & UserName & "</td></tr>"

        'FOR AOD Case'

        strMailAODBody += "<strong>Attendance Summary after relieving date for AOD case </strong><br /><br />"
        strMailAODBody += "<table border='1' width='90%' style='border: 1px solid; border-collapse: collapse; font-family: Verdana; font-size: .8em'>"
        strMailAODBody += "<tr>"
        strMailAODBody += "<td align='center'><b>Agent Name</b></td>"
        strMailAODBody += "<td align='center'><b>Emp. Code</b></td>"
        strMailAODBody += "<td align='center'><b>Date</b></td>"
        strMailAODBody += "<td align='center'><b>Marked As</b></td>"
        strMailAODBody += "<td align='center'><b>Marked By</b></td></tr>"
        '**************'

        For Each dgRow As GridViewRow In GdAttendance.Rows

            status = CType(dgRow.FindControl("lnkChangeStatus"), LinkButton).Text
            If status.ToLower.Contains("marked as") Then
                status = status.ToLower.Replace("marked as ", "")
                If status.ToLower.StartsWith("aod on") Then
                    status = status.Replace(CDate(DateTimePicker3.value).ToString("yyyyMMdd"), "").ToUpper.Trim
                    status = "AOD"
                ElseIf status.ToLower.StartsWith("transferred on") Then
                    status = status.Replace(CDate(DateTimePicker3.value).ToString("yyyyMMdd"), "").ToUpper.Trim
                    status = "TRANSFERRED"
                ElseIf status.ToLower.StartsWith("terminated on") Then
                    status = status.Replace(CDate(DateTimePicker3.value).ToString("yyyyMMdd"), "").ToUpper.Trim
                    status = "TERMINATION"
                ElseIf status.ToLower.StartsWith("resigned on") Then
                    status = status.Replace(CDate(DateTimePicker3.value).ToString("yyyyMMdd"), "").ToUpper.Trim
                    status = "RESIGNED"
                End If
            End If
            Dim resigned As String = CType(dgRow.FindControl("lnkChangeStatus"), LinkButton).Text
            resigned = resigned.Replace("Change", "").Trim()
            'If resigned <> "" And Not resigned.Contains("Pending") Then
            If resigned.ToLower.Contains("marked as") Then
                resigned = resigned.ToLower.Replace("marked as ", "")
                If resigned.ToLower.StartsWith("revoke") Then
                ElseIf resigned.ToLower.StartsWith("aod on") Then
                    resigned = resigned.ToLower.Replace("aod on", "").Trim
                ElseIf resigned.ToLower.StartsWith("transferred on") Then
                    resigned = resigned.ToLower.Replace("transferred on", "").Trim
                ElseIf resigned.ToLower.StartsWith("terminated on") Then
                    resigned = resigned.ToLower.Replace("terminated on", "").Trim
                ElseIf resigned.ToLower.StartsWith("resigned on") Then
                    resigned = resigned.ToLower.Replace("resigned on", "").Trim
                End If
                If resigned.ToLower <> "revoke" Then
                    db = New DBAccess("CRM")
                    RelievingDate = db.ReturnValue("select convert(datetime,convert(varchar," & resigned & "))", False)
                    db = Nothing
                End If
            End If

            If status.ToUpper.Trim = "AOD" Or status.ToUpper.Trim = "RESIGNED" Or status.ToUpper.Trim = "TRANSFERRED" Or status.ToUpper.Trim = "TERMINATION" Then
                Agent = CType(dgRow.FindControl("lblAgentID"), Label).Text
                srno = srno + 1
                db = New DBAccess("CRM")
                Dim Process = db.ReturnValue("select B.Name  from tbl_AgentMaster A INNER JOIN tbl_Config_Campaigns  B ON A.CampaignID=B.CampaignID where A.AgentID ='" & CType(dgRow.FindControl("lblAgentID"), Label).Text & "'", False)
                db = Nothing
                rb1 = dgRow.FindControl("rdpresent")
                rb2 = dgRow.FindControl("rdleave")
                rb3 = dgRow.FindControl("rdAbsent")
                rb4 = dgRow.FindControl("rdLWP")
                rb5 = dgRow.FindControl("rdHalfDay")
                rb6 = dgRow.FindControl("rdLWPHalfDay")
                rb7 = dgRow.FindControl("rdWeeklyoff")
                rb9 = dgRow.FindControl("rdUnschedule") '''''rajkumar added 29-July-2016
                rb10 = dgRow.FindControl("rdUnscheduleHD") '''''rajkumar added 29-July-2016

                If rb1.Checked = True Then
                    MarkedAs = "Present"
                ElseIf rb2.Checked = True Then
                    MarkedAs = "Leave"
                ElseIf rb3.Checked = True Then
                    MarkedAs = "Absent"
                ElseIf rb4.Checked = True Then
                    MarkedAs = "LWP"
                ElseIf rb5.Checked = True Then
                    MarkedAs = "Half Day LWP"
                ElseIf rb6.Checked = True Then
                    MarkedAs = "Half Day LWP"
                ElseIf rb7.Checked = True Then
                    MarkedAs = "Weekly Off"
                ElseIf rb9.Checked = True Then '''''rajkumar added 29-July-2016
                    MarkedAs = "Unschedule"
                ElseIf rb10.Checked = True Then '''''rajkumar added 29-July-2016
                    MarkedAs = "Unschedule HalfDay"
                End If

                strMailBody += "<tr>"
                strMailBody += "<td align='center'>" & srno & "</td>"
                strMailBody += "<td align='center'>" & CType(dgRow.FindControl("lblAgentName"), Label).Text & "</td>"
                strMailBody += "<td align='center'>" & CType(dgRow.FindControl("lblAgentID"), Label).Text & "</td>"
                strMailBody += "<td align='center'>" & Process & "</td>"
                strMailBody += "<td align='center'>" & MarkedAs & "</td>"
                strMailBody += "<td align='center'>" & status & "</td>"
                strMailBody += "<td align='center'>" & Convert.ToDateTime(RelievingDate).ToString("dd/MM/yyyy") & "</td>"
                strMailBody += "</tr>"
                If status.ToUpper.Trim = "AOD" Then
                    'strMailAODRows = ""
                    Dim dbAODattendance As New DBAccess("CRM")
                    Dim dtAODAttendance As New DataTable
                    dbAODattendance.slDataAdd("agentid", CType(dgRow.FindControl("lblAgentID"), Label).Text)
                    dbAODattendance.slDataAdd("LWD", Convert.ToDateTime(RelievingDate).ToString("yyyyMMdd"))
                    dtAODAttendance = dbAODattendance.ReturnTable("usp_getAfterLWDAttendance", , True)
                    dbAODattendance = Nothing
                    For Each row As DataRow In dtAODAttendance.Rows
                        strMailAODRows += "<tr>"
                        strMailAODRows += "<td align='center'>" & row.Item("AgentName") & "</td>"
                        strMailAODRows += "<td align='center'>" & row.Item("AgentID") & "</td>"
                        strMailAODRows += "<td align='center'>" & Convert.ToDateTime(row.Item("Date")).ToString("dd/MM/yyyy") & "</td>"
                        strMailAODRows += "<td align='center'>" & row.Item("markedas") & "</td>"
                        strMailAODRows += "<td align='center'>" & row.Item("MarkedBy") & "</td>"
                        strMailAODRows += "</tr>"
                    Next
                End If
            End If
        Next
        strMailBody += "</table>"
        If strMailAODRows <> "" Then
            strMailAODBody += strMailAODRows + "</table>"
            strMailBody += "<br /><br />" + strMailAODBody
        End If
        strMailBody += "<br /><br /><hr/>This mail was sent using the "
        strMailBody += "<a href='" & System.Configuration.ConfigurationManager.AppSettings("LiveServerPath") & "'>TermsMonitor&reg;</a> Mail Service.We request you not to reply this message."
        'strMailBody += "<br /><br />In case you wish to report issues with this mail, please send mail to mailto:helpdesk@niitsmartserve.com <br /> "
        strMailBody += "<br />This e-mail is confidential and may also be privileged.If you are not the intended recipient, please notify helpdesk immediately; you should not copy or use it for any purpose,nor disclose its contents to any other person."
        strMailBody += "</body>"
        strMailBody += "</html>"
        MailService("Resigned / AOD / Transferred / Termination", strMailBody, Agent)

    End Sub

    Private Sub Resigned_AOD_RevokeMail()
        Dim db As DBAccess
        Dim MarkedDate As DateTime
        Dim srno As Int16 = 0
        Dim strMailBody = "", status As String
        db = New DBAccess("CRM")
        MarkedDate = db.ReturnValue("select convert(datetime,convert(varchar," & CDate(DateTimePicker3.value).ToString("yyyyMMdd") & "))", False)
        db = Nothing
        strMailBody += "<html xmlns='http://www.w3.org/1999/xhtml'>"
        strMailBody += "<body style='font-family: Verdana; font-size: .8em'>"
        strMailBody += "<strong>Following People's Resignation / AOD / Transfer / Termination have been Revoked </strong><br /><br />"
        strMailBody += "<table border='1' width='70%' style='border: 1px solid; border-collapse: collapse; font-family: Verdana; font-size: .8em'>"
        strMailBody += "<tr>"
        strMailBody += "<td align='center'><b>Sr. No.</b></td>"
        strMailBody += "<td align='center'><b>Agent Name</b></td>"
        strMailBody += "<td align='center'><b>Emp. Code</b></td>"
        strMailBody += "<td align='center'><b>Process</b></td>"
        strMailBody += "</tr>"
        strMailBody += "<tr>"
        strMailBody += "<td colspan='4'>"
        'strMailBody += "ON " & Convert.ToDateTime(MarkedDate).ToString("dd/MM/yyyy") & "  by  " & Session("username") & "</td></tr>"
        strMailBody += "ON " & CurrentDate.ToString("dd/MM/yyyy") & "  by  " & UserName & "</td></tr>"

        For Each dgRow As GridViewRow In GdAttendance.Rows
            status = CType(dgRow.FindControl("lnkChangeStatus"), LinkButton).Text
            If status.ToLower.StartsWith("revoke") Then
                status = status.Replace(CDate(DateTimePicker3.value).ToString("yyyyMMdd"), "").ToUpper.Trim
                status = "REVOKE"
            End If
            If status.ToUpper.Trim = "REVOKE" Then
                srno = srno + 1
                Agent = CType(dgRow.FindControl("lblAgentID"), Label).Text
                db = New DBAccess("CRM")
                Dim Process = db.ReturnValue("select B.Name  from tbl_AgentMaster A INNER JOIN tbl_Config_Campaigns  B ON A.CampaignID=B.CampaignID where A.AgentID ='" & CType(dgRow.FindControl("lblAgentID"), Label).Text & "'", False)
                db = Nothing
                strMailBody += "<tr>"
                strMailBody += "<td align='center'>" & srno & "</td>"
                strMailBody += "<td align='center'>" & CType(dgRow.FindControl("lblAgentName"), Label).Text & "</td>"
                strMailBody += "<td align='center'>" & CType(dgRow.FindControl("lblAgentID"), Label).Text & "</td>"
                strMailBody += "<td align='center'>" & Process & "</td>"
                strMailBody += "</tr>"
            End If
        Next
        strMailBody += "</table>"
        strMailBody += "<br /><br /><hr/>This mail was sent using the "
        strMailBody += "<a href='" & System.Configuration.ConfigurationManager.AppSettings("LiveServerPath") & "'>TermsMonitor&reg;</a> Mail Service.We request you not to reply this message."
        'strMailBody += "<br /><br />In case you wish to report issues with this mail, please send mail to mailto:helpdesk@niitsmartserve.com <br /> "
        strMailBody += "<br />This e-mail is confidential and may also be privileged.If you are not the intended recipient, please notify helpdesk immediately; you should not copy or use it for any purpose,nor disclose its contents to any other person."
        strMailBody += "</body>"
        strMailBody += "</html>"
        MailService(" Resigned / AOD / Transferred / Termination Revoked", strMailBody, Agent)
    End Sub

    Private Sub HierarchyMovmentMail()
        Dim db As DBAccess
        Dim dt As New DataTable
        Try


            Dim AgentId = "", CurrentSupervisor = "", NewSupervisorID = "", MovedOn As String = ""
            Dim SuperVisorArray As New ArrayList
            Dim srno As Int16
            Dim strMailBody = "", status = "", CurrentProcess = "", NewProcess = "", supervisor = "", strCC = "", MailSubject As String = Nothing

            strMailBody += "<html xmlns='http://www.w3.org/1999/xhtml'>"
            strMailBody += "<body style='font-family: Verdana; font-size: .8em'>"
            strMailBody += "<strong>Following Team Member/s Hierarchy have been Changed/Revoked by: " & UserName & "</strong><br /><br />"
            strMailBody += "<table border='1' width='90%' style='border: 1px solid; border-collapse: collapse; font-family: Verdana; font-size: .8em'>"
            strMailBody += "<tr>"
            strMailBody += "<td align='center'><b>Sr. No.</b></td>"
            strMailBody += "<td align='center'><b>Emp. Code</b></td>"
            strMailBody += "<td align='center'><b>Agent Name</b></td>"
            strMailBody += "<td align='center'><b>Current Process</b></td>"
            strMailBody += "<td align='center'><b>New Supervisor</b></td>"
            strMailBody += "<td align='center'><b>New Process</b></td>"
            strMailBody += "<td align='center'><b>Purpose of Movement</b></td>"
            strMailBody += "<td align='center'><b>Move On</b></td>"
            strMailBody += "</tr>"
            For Each dgRow As GridViewRow In GdAttendance.Rows
                status = CType(dgRow.FindControl("lnkMove"), LinkButton).Text
                If status.ToLower.Contains("under") Then
                    Dim moveunder As String = CType(dgRow.FindControl("lnkmove"), LinkButton).Text.Replace("Under", "").Trim
                    moveunder = moveunder.Replace("Move", "").Trim()
                    AgentId = CType(dgRow.FindControl("lblAgentID"), Label).Text
                    Dim reason As String = CType(dgRow.FindControl("lblMoveInfo"), Label).Text.Replace("*", "")
                    Dim newcampaign As String = reason.Substring(reason.LastIndexOf("CampaignID:")).Replace("CampaignID:", "")
                    reason = reason.Substring(0, reason.LastIndexOf("CampaignID:"))
                    NewSupervisorID = CType(dgRow.FindControl("lnkmove"), LinkButton).Text.ToLower.Replace("under", "").Trim
                    If NewSupervisorID.ToLower.Contains("pending") Then
                        Continue For
                    End If
                    NewSupervisorID = NewSupervisorID.Replace("Move", "")
                    NewSupervisorID = NewSupervisorID.Substring(0, NewSupervisorID.ToLower.IndexOf(" on")).Trim

                    If SuperVisorArray.Contains(NewSupervisorID) Then
                    Else
                        SuperVisorArray.Add(NewSupervisorID)
                    End If
                    MailSubject = "Team Member/s Moved."
                    srno = srno + 1
                    strMailBody += "<tr>"
                    strMailBody += "<td align='center'>" & srno & "</td>"
                    strMailBody += "<td align='center'>" & CType(dgRow.FindControl("lblAgentID"), Label).Text & "</td>"
                    strMailBody += "<td align='center'>" & CType(dgRow.FindControl("lblAgentName"), Label).Text & "</td>"
                    db = New DBAccess("CRM")
                    CurrentProcess = db.ReturnValue("SELECT B.Name FROM tbl_AgentMaster A INNER JOIN tbl_Config_Campaigns B ON A.CampaignID=B.CampaignID WHERE A.AgentID='" & CType(dgRow.FindControl("lblAgentID"), Label).Text & "'", False)
                    db = Nothing
                    strMailBody += "<td align='center'>" & CurrentProcess.ToString & "</td>"
                    db = New DBAccess("CRM")
                    dt = db.ReturnTable("SELECT A.AgentName,B.EmailId FROM tbl_AgentMaster A Inner join tbl_Config_SupervisorsEmail B On A.AgentID=B.AgentID  WHERE A.AgentID='" & NewSupervisorID & "'", False)
                    db = Nothing
                    If dt.Rows.Count > 0 Then
                        supervisor = dt.Rows(0).Item("AgentName")
                        strCC += IIf(IsDBNull(dt.Rows(0).Item("EmailId")), "", dt.Rows(0).Item("EmailId") & ",")
                    Else
                        supervisor = ""
                        strCC = ""
                    End If
                    strMailBody += "<td align='center'>" & supervisor.ToString & "</td>"
                    db = New DBAccess("CRM")
                    NewProcess = db.ReturnValue("SELECT Name FROM tbl_Config_Campaigns WHERE CampaignID='" & newcampaign & "'", False)
                    db = Nothing
                    strMailBody += "<td align='center'>" & NewProcess.ToString & "</td>"
                    strMailBody += "<td align='center'>" & reason & "</td>"
                    strMailBody += "<td align='center'>" & IntegerToDateString(moveunder.Substring(moveunder.ToLower.IndexOf(" on ") + 4).Trim()) & "</td>"
                    strMailBody += "</tr>"
                End If
                If status.ToLower.Contains("revoke") Then
                    MailSubject = "Team Member/s Movement Revoked."
                    AgentId = CType(dgRow.FindControl("lblAgentID"), Label).Text

                    srno = srno + 1
                    strMailBody += "<tr style='font-family: Verdana;'>"
                    strMailBody += "<td align='center'>" & srno & "</td>"
                    strMailBody += "<td align='center'>" & CType(dgRow.FindControl("lblAgentID"), Label).Text & "</td>"
                    strMailBody += "<td align='center'>" & CType(dgRow.FindControl("lblAgentName"), Label).Text & "</td>"
                    db = New DBAccess("CRM")
                    CurrentProcess = db.ReturnValue("SELECT B.Name FROM tbl_AgentMaster A INNER JOIN tbl_Config_Campaigns B ON A.CampaignID=B.CampaignID WHERE A.AgentID='" & CType(dgRow.FindControl("lblAgentID"), Label).Text & "'", False)
                    db = Nothing
                    strMailBody += "<td align='center'>" & CurrentProcess.ToString & "</td>"
                    strMailBody += "<td align='center'>NA</td>"
                    strMailBody += "<td align='center'>NA</td>"
                    strMailBody += "<td align='center'>Revoked</td>"
                    strMailBody += "</tr>"
                End If
            Next


            strMailBody += "</tr></table><br />"
            strMailBody += "<div align='left'>If you are approving authority,"
            strMailBody += "<a href='" & System.Configuration.ConfigurationManager.AppSettings("LiveServerPath") & "/Staffing/PendingMovement.aspx'>Click Here To Approve/Reject</a></div>"
            strMailBody += "<br /><br /><hr/>This mail was sent using the "
            strMailBody += "<a href='" & System.Configuration.ConfigurationManager.AppSettings("LiveServerPath") & "'>TermsMonitor&reg;</a> Mail Service.We request you not to reply this message."
            'strMailBody += "<br /><br />In case you wish to report issues with this mail, please send mail to mailto:helpdesk@niitsmartserve.com <br /> "
            strMailBody += "<br />This e-mail is confidential and may also be privileged.If you are not the intended recipient, please notify helpdesk immediately; you should not copy or use it for any purpose,nor disclose its contents to any other person."
            strMailBody += "</body>"
            strMailBody += "</html>"

            Dim i As Integer
            For i = 0 To SuperVisorArray.Count - 1
                db = New DBAccess("CRM")
                dt = New DataTable
                db.slDataAdd("AgentId", SuperVisorArray(i).ToString)
                'db.slDataAdd("AgentId", NewSupervisorID )
                dt = db.ReturnTable("usp_SupervisorEmails", , True)
                strCC += "," & dt.Rows(0).Item("MailCC")
                dt = Nothing
                db = Nothing
            Next
            db = New DBAccess("CRM")
            dt = New DataTable
            db.slDataAdd("AgentId", AgentId)
            dt = db.ReturnTable("usp_SupervisorEmails", , True)
            strCC += "," & dt.Rows(0).Item("MailCC")

            Dim strCCUnique As String = ""
            strCCUnique = GetUnique(strCC)

            'Dim objWSMail As New ShootMail.Mail

            '   Dim objWSMail As New MailSendServiceXX.Service1SoapClient
            Try



                Dim strFrom As String = System.Configuration.ConfigurationManager.AppSettings("FROM")

                db = Nothing
                dt = Nothing
                'objWSMail.MailSend("HROperations@niitsmartserve.com", strMailBody, "", strCCUnique, "Developers@niitsmartserve.com", strFrom, MailSubject)
                ' objWSMail.MailSend("HROperations@NIIT-Tech.com", strMailBody, "", strCCUnique, "Developers@NIIT-Tech.com", strFrom, MailSubject) ''11Jan2018

                'objWSMail.MailSendNewTech(System.Configuration.ConfigurationManager.AppSettings("HROP"), MailSubject, strFrom, "TermsMonitor", strMailBody, "", strCCUnique, System.Configuration.ConfigurationManager.AppSettings("BCC"), "") ''11Jan2018

                ' for LH  341/TTC 379 /James villas 361/ Amadeus-ITA-383 /AMEX GBT -378/Tribune Ad-Hub-342 Proceeses  Vertical Head to be Alerted
                If ((CampaignID = 341) Or (CampaignID = 379) Or (CampaignID = 361) Or (CampaignID = 383) Or (CampaignID = 378) Or (CampaignID = 342)) Then
                    strCCUnique = strCCUnique + "," + System.Configuration.ConfigurationManager.AppSettings("TravelHead")
                    Common.SMTPSendMail(System.Configuration.ConfigurationManager.AppSettings("HROP"), MailSubject, "Terms Movement Form <" & strFrom & ">", strMailBody, strCCUnique, System.Configuration.ConfigurationManager.AppSettings("WSR_PIP_ProcessManager"))

                    'for SEI  205 Proceeses  Vertical Head to be Alerted
                ElseIf ((CampaignID = 205)) Then
                    strCCUnique = strCCUnique + "," + System.Configuration.ConfigurationManager.AppSettings("BFSInvestmentHead")
                    Common.SMTPSendMail(System.Configuration.ConfigurationManager.AppSettings("HROP"), MailSubject, "Terms Movement Form <" & strFrom & ">", strMailBody, strCCUnique, System.Configuration.ConfigurationManager.AppSettings("WSR_PIP_ProcessManager"))

                    'for zions 309 /Tulip 305 Proceeses  Vertical Head to be Alerted
                ElseIf ((CampaignID = 309) Or (CampaignID = 305)) Then
                    strCCUnique = strCCUnique + "," + System.Configuration.ConfigurationManager.AppSettings("BFSHead")
                    Common.SMTPSendMail(System.Configuration.ConfigurationManager.AppSettings("HROP"), MailSubject, "Terms Movement Form <" & strFrom & ">", strMailBody, strCCUnique, System.Configuration.ConfigurationManager.AppSettings("WSR_PIP_ProcessManager"))


                    'for Atrium  159 /Aflac 375  Proceeses  Vertical Head to be Alerted
                ElseIf ((CampaignID = 159) Or (CampaignID = 375)) Then
                    strCCUnique = strCCUnique + "," + System.Configuration.ConfigurationManager.AppSettings("InsuranceHead")
                    Common.SMTPSendMail(System.Configuration.ConfigurationManager.AppSettings("HROP"), MailSubject, "Terms Movement Form <" & strFrom & ">", strMailBody, strCCUnique, System.Configuration.ConfigurationManager.AppSettings("WSR_PIP_ProcessManager"))


                Else
                    strCCUnique = strCCUnique
                    Common.SMTPSendMail(System.Configuration.ConfigurationManager.AppSettings("HROP"), MailSubject, "Terms Movement Form <" & strFrom & ">", strMailBody, strCCUnique, System.Configuration.ConfigurationManager.AppSettings("WSR_PIP_ProcessManager"))
                End If


            Catch ex As Exception
                'objWSMail = Nothing
                AlertMessage(ex.Message.ToString())


            End Try

            'objWSMail.MailSend("rajendrar_nss@niitsmartserve.com", strMailBody, "", "jatint@niitsmartserve.com", "jatint@niitsmartserve.com", strFrom, MailSubject)
            'objWSMail = Nothing
        Catch ex As Exception

            'objWSMail = Nothing
        End Try
    End Sub

    Private Sub MailService(ByVal Subject As String, ByVal MailBody As String, ByVal Agent_ID As String)
        Dim db As New DBAccess("CRM")
        Dim dt As New DataTable
        db.slDataAdd("AgentId", Agent_ID)
        dt = db.ReturnTable("usp_SupervisorEmails", , True)
        db = Nothing
        'Dim objWSMail As New ShootMail.Mail
        'Dim objWSMail As New MailSendServiceXX.Service1SoapClient
        Dim strHRO As String = System.Configuration.ConfigurationManager.AppSettings("HRO")

        Dim strTo As String = dt.Rows(0).Item("MailTO")
        Dim strCC As String = dt.Rows(0).Item("MailCC")
        'If strCC.Length > 0 Then
        '    strCC += ",Ranjeev.Anand@niit-tech.com"
        'Else
        '    strCC += "Ranjeev.Anand@niit-tech.com"
        'End If

        If strCC.Length > 0 Then
            strCC += "," + strHRO
        Else
            strCC += strHRO
        End If

        Dim strBcc As String = dt.Rows(0).Item("MailBCC")
        Dim strFrom As String = System.Configuration.ConfigurationManager.AppSettings("FROM")
        'objWSMail.MailSend(strTo, MailBody, "", strCC, strBcc, strFrom, Subject)
        'objWSMail.MailSendNewTech(strTo, Subject, strFrom, "TermsMonitor", MailBody, "", strCC, strBcc, "") ''11Jan2018

        If ((CampaignID = 341) Or (CampaignID = 379) Or (CampaignID = 361) Or (CampaignID = 383) Or (CampaignID = 378) Or (CampaignID = 342) Or (CampaignID = 32)) Then

            strCC = strCC + "," + System.Configuration.ConfigurationManager.AppSettings("TravelHead")
            Common.SMTPSendMail(strTo, Subject, "TermsMonitor <" & strFrom & ">", MailBody, strCC, System.Configuration.ConfigurationManager.AppSettings("WSR_PIP_ProcessManager"))

        ElseIf ((CampaignID = 205)) Then
            strCC = strCC + "," + System.Configuration.ConfigurationManager.AppSettings("BFSInvestmentHead")
            Common.SMTPSendMail(strTo, Subject, "TermsMonitor <" & strFrom & ">", MailBody, strCC, System.Configuration.ConfigurationManager.AppSettings("WSR_PIP_ProcessManager"))

        ElseIf ((CampaignID = 309) Or (CampaignID = 305)) Then
            strCC = strCC + "," + System.Configuration.ConfigurationManager.AppSettings("BFSHead")
            Common.SMTPSendMail(strTo, Subject, "TermsMonitor <" & strFrom & ">", MailBody, strCC, System.Configuration.ConfigurationManager.AppSettings("WSR_PIP_ProcessManager"))

            'for Atrium  159 /Aflac 375  Proceeses  Vertical Head to be Alerted
        ElseIf ((CampaignID = 159) Or (CampaignID = 375)) Then
            strCC = strCC + "," + System.Configuration.ConfigurationManager.AppSettings("InsuranceHead")
            Common.SMTPSendMail(strTo, Subject, "TermsMonitor <" & strFrom & ">", MailBody, strCC, System.Configuration.ConfigurationManager.AppSettings("WSR_PIP_ProcessManager"))

        Else
            Common.SMTPSendMail(strTo, Subject, "TermsMonitor <" & strFrom & ">", MailBody, strCC, System.Configuration.ConfigurationManager.AppSettings("WSR_PIP_ProcessManager"))

        End If
        'objWSMail.MailSend("satyendrac@niitsmartserve.com", MailBody, "", "jatint@niitsmartserve.com", "satyendrac@niitsmartserve.com", strFrom, Subject)
        'objWSMail = Nothing
    End Sub
    Public Function GetUnique(ByVal sStringToUse As String, Optional ByVal sSeperator As String = ",", Optional ByVal LimitWords As Integer = 0) As String
        Dim sStrings() As String
        Dim sToRet As String = ""
        sStrings = sStringToUse.Split(sSeperator)
        Dim i As Integer = 0
        For Each s As String In sStrings
            Dim sTrimed As String = s.Trim()
            If Not (LimitWords < 1 OrElse i < LimitWords) Then Exit For
            If sToRet.IndexOf(sTrimed, StringComparison.CurrentCultureIgnoreCase) < 0 Then
                i += 1
                sToRet &= sTrimed & ","
            End If
        Next
        If sToRet.Length > 0 Then
            Return sToRet.ToString().Substring(0, sToRet.Length - 1)
        Else
            Return ""
        End If
    End Function

#End Region

    Protected Sub imgfav_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles imgfav.Click
        Common.AddToFav(AgentID, "Mark Attendance")
        SuccessMessage("Report has been added to your favourite list")
        fillgrid(SupervisorID, CDate(DateTimePicker3.value).ToString("yyyyMMdd"))
    End Sub
End Class
