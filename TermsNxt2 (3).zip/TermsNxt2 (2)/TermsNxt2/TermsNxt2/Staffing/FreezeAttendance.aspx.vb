﻿Imports com.nss.DBAccess
Imports System.Data
Partial Class Staffing_FreezeAttendance
    Inherits System.Web.UI.Page
#Region "-----Properties-----"

    Property CurrentDate() As Date
        Get
            Return ViewState("CurrentDate")
        End Get
        Set(ByVal value As Date)
            ViewState("CurrentDate") = value
        End Set
    End Property

    Property MinDate() As Date
        Get
            Return ViewState("MinDate")
        End Get
        Set(ByVal value As Date)
            ViewState("MinDate") = value
        End Set
    End Property

    Property MinDatePLI() As Date
        Get
            Return ViewState("MinDatePLI")
        End Get
        Set(ByVal value As Date)
            ViewState("MinDatePLI") = value
        End Set
    End Property

    Property ReportType() As Integer
        Get
            Return ViewState("ReportType")
        End Get
        Set(ByVal value As Integer)
            ViewState("ReportType") = value
        End Set
    End Property

    Property CurrentLevel() As Integer
        Get
            Return ViewState("CurrentLevel")
        End Get
        Set(ByVal value As Integer)
            ViewState("CurrentLevel") = value
        End Set
    End Property
    Property SupervisorID() As String
        Get
            Return ViewState("SupervisorID")
        End Get
        Set(ByVal value As String)
            ViewState("SupervisorID") = value
        End Set
    End Property
    Property UserID() As String
        Get
            Return ViewState("UserID")
        End Get
        Set(ByVal value As String)
            ViewState("UserID") = value
        End Set
    End Property
    Property AgentID() As String
        Get
            Return ViewState("AgentID")
        End Get
        Set(ByVal value As String)
            ViewState("AgentID") = value
        End Set
    End Property
#End Region
#Region "--- Load ---"
    Private Sub LoadData()
        Dim db As New DBAccess("CRM")
        Dim dr As DataRow = db.ReturnRow("SELECT dateadd(dd,1,max([FreezeDate])) as mindate  ,getdate()-1 as currentdate  FROM [tbl_LastFreezedDate]")
        CurrentDate = dr("currentDate")
        txtDate.value = CurrentDate
        MinDate = dr("minDate")
        db = Nothing
        lblReportName.CurrentPage = "Freeze Attendance Ans Freeze EWS"
        '----------------- For EWS ----------------------
        db = New DBAccess("CRM")
        Dim dr1 As DataRow = db.ReturnRow("SELECT ISNULL(MAX(FreezedMonth),0) AS [Max Month],ISNULL(MAX(FreezedYear),0) AS [Max Year]  FROM tbl_EWS_LastFreezedMonth", False)
        cboMonth.SelectedValue = dr1("Max Month")
        cboYear.SelectedValue = dr1("Max Year")
        db = Nothing
    End Sub
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        HumanMessage.Style.Item("visibility") = "hidden"
        If Not IsPostBack Then
            'ReportType = Request.QueryString("ReportType")
            If Session("AgentID") <> "" Then
                AgentID = Session("AgentID")
                PanelReports.Controls.Add(Common.GetMenu(Request.Url, AgentID, Request.ApplicationPath))
                LoadData()
                fillgrid()
                fillgrid_PLI()
                FillEWS()
                GetVCStatus()
            End If
        End If
    End Sub
   

    Private Sub FreezeAttendance_Mail(Mailsub As String)
        Dim db As DBAccess
        Dim MarkedDate As DateTime
        Dim srno As Int16 = 0
        Dim strMailBody = "", status As String
        db = New DBAccess("CRM")
        MarkedDate = db.ReturnValue("select convert(datetime,convert(varchar," & txtDate.yyyymmdd & "))", False)
        db = Nothing
        strMailBody += "<html xmlns='http://www.w3.org/1999/xhtml'>"
        strMailBody += "<body style='font-family: Verdana; font-size: .8em'>"
        ' strMailBody += "<strong>Attendance Cycle have been Freezed  </strong><br /><br />"

        strMailBody += "<strong>" & Mailsub & "</strong><br /><br />"
        strMailBody += "<table border='1' width='70%' style='border: 1px solid; border-collapse: collapse; font-family: Verdana; font-size: .8em'>"
        strMailBody += "<tr>"
        strMailBody += "<td align='center'><b>Last CutOff Date</b></td>"
        strMailBody += "<td align='center'><b>Freezed Done by</b></td>"
        'strMailBody += "<td align='center'><b>Freezed Date</b></td>"
        strMailBody += "<td align='center'><b>Freezed At</b></td>"
        strMailBody += "</tr>"
        strMailBody += "<tr>"
        strMailBody += "<td colspan='4'>"
        'strMailBody += "ON " & Convert.ToDateTime(MarkedDate).ToString("dd/MM/yyyy") & "  by  " & Session("username") & "</td></tr>"
        strMailBody += "ON " & CurrentDate.ToString("dd/MM/yyyy") & "  by  " & Session("username") & "</td></tr>"

        For Each dgRow As GridViewRow In GridViewPLI.Rows

            strMailBody += "<tr>"
            strMailBody += "<td align='center'>" & CType(dgRow.FindControl("lblLastCutoffDate"), Label).Text & "</td>"
            strMailBody += "<td align='center'>" & CType(dgRow.FindControl("lblDoneBy"), Label).Text & "</td>"
            strMailBody += "<td align='center'>" & CType(dgRow.FindControl("lblDoneAt"), Label).Text & "</td>"

            strMailBody += "</tr>"

        Next
        strMailBody += "</table>"
        strMailBody += "<br /><br /><hr/>This mail was sent using the "
        strMailBody += "<a href='" & System.Configuration.ConfigurationManager.AppSettings("LiveServerPath") & "'>TermsMonitor&reg;</a> Mail Service.We request you not to reply this message."
        'strMailBody += "<br /><br />In case you wish to report issues with this mail, please send mail to mailto:helpdesk@niitsmartserve.com <br /> "
        strMailBody += "<br />This e-mail is confidential and may also be privileged.If you are not the intended recipient, please notify helpdesk immediately; you should not copy or use it for any purpose,nor disclose its contents to any other person."
        strMailBody += "</body>"
        strMailBody += "</html>"
        MailService(Mailsub, strMailBody, AgentID)
    End Sub

#End Region
#Region "--- Functions ---"
    Private Sub getLastFreezedate()
        Dim db As New DBAccess("CRM")
        Dim dr As DataRow = db.ReturnRow("SELECT dateadd(dd,1,max([FreezeDate])) as mindate FROM [tbl_LastFreezedDate]")
        MinDate = dr("minDate")
        db = Nothing
    End Sub
    Private Sub getLastFreezedatePLI()
        Dim db As New DBAccess("CRM")
        Dim dr As DataRow = db.ReturnRow("SELECT dateadd(dd,1,max([FreezeDate])) as mindate FROM [tbl_LastFreezedPLIDate]")
        MinDatePLI = dr("minDate")
        db = Nothing
    End Sub


    Private Sub fillgrid()
        Dim db As New DBAccess("CRM")
        Dim dt As DataTable
        dt = db.ReturnTable("usp_getLastFreezeAttendnace", , True)
        db = Nothing
        GdAttendance.DataSource = dt
        GdAttendance.DataBind()
        dt = Nothing
    End Sub
    Private Sub fillgrid_PLI()
        Dim db As New DBAccess("CRM")
        Dim dt As DataTable
        dt = db.ReturnTable("usp_getLastFreezePLI", , True)
        db = Nothing
        GridViewPLI.DataSource = dt
        GridViewPLI.DataBind()
        dt = Nothing
    End Sub
    Private Sub FillEWS()
        Try
            Dim db As New DBAccess("CRM")
            Dim dt As DataTable
            dt = db.ReturnTable("usp_LastFreezeEWS", , True)
            db = Nothing
            GdEWS.DataSource = dt
            GdEWS.DataBind()
        Catch ex As Exception
            AlertMessage(ex.ToString)
        End Try

    End Sub
    Private Function validdate(ByVal selecteddate As DateTime) As Boolean
        If selecteddate > CurrentDate Or selecteddate < MinDate Then
            Return False
        End If
        Return True
    End Function
    Private Sub GetVCStatus()
        Dim db As New DBAccess("CRM")
        Dim dr As DataRow = db.ReturnRow("SELECT TOP 1 IsFreezed  FROM tbl_Data_VC", False)
        db = Nothing
        If Not dr Is Nothing Then
            If dr(0) = True Then
                btFreezeVC.Text = "Unfreeze VC"
            Else
                btFreezeVC.Text = "Freeze VC"
            End If
        End If
    End Sub
    Private Sub Freeze_UnFreezeVC()
        Try
            Dim db As New DBAccess("CRM")
            If btFreezeVC.Text.ToLower = "unfreeze vc" Then
                db.exeSQL("UPDATE tbl_Data_VC SET IsFreezed=0")
                SuccessMessage("VC Detail has been Unfreeze Successfully")
            ElseIf btFreezeVC.Text.ToLower = "freeze vc" Then
                db.exeSQL("UPDATE tbl_Data_VC SET IsFreezed=1")
                SuccessMessage("VC Detail has been Freeze Successfully")
            End If
            db = Nothing
        Catch ex As Exception
            AlertMessage(ex.ToString)
        End Try
    End Sub
#End Region
#Region "--- Events ---"

    Protected Sub btdatedecreasePLI_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btdatedecrease.Click
        getLastFreezedatePLI()
        If validdate(DateAdd(DateInterval.Day, -1, txtDatePLI.value)) Then
            txtDatePLI.value = DateAdd(DateInterval.Day, -1, txtDate.value)
        Else
            AlertMessage("Date not in valid range.")
        End If
        fillgrid_PLI()

    End Sub
    Protected Sub btdateincreasePLI_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btdateincrease.Click
        getLastFreezedatePLI()
        If validdate(DateAdd(DateInterval.Day, 1, txtDatePLI.value)) Then
            txtDatePLI.value = DateAdd(DateInterval.Day, 1, txtDatePLI.value)
        Else
            AlertMessage("Date not in valid range.")
        End If
        fillgrid_PLI()
    End Sub
    Protected Sub txtDatePLI_Changed(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtDate.Changed
        getLastFreezedatePLI()
        If validdate(txtDatePLI.value) Then
            fillgrid_PLI()
        Else
            AlertMessage("Date not in valid range")
            txtDatePLI.value = CurrentDate
            fillgrid_PLI()
        End If
    End Sub


    Protected Sub btdatedecrease_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btdatedecrease.Click
        getLastFreezedate()
        If validdate(DateAdd(DateInterval.Day, -1, txtDate.value)) Then
            txtDate.value = DateAdd(DateInterval.Day, -1, txtDate.value)
        Else
            AlertMessage("Date not in valid range.")
        End If
        fillgrid()

    End Sub
    Protected Sub btdateincrease_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btdateincrease.Click
        getLastFreezedate()
        If validdate(DateAdd(DateInterval.Day, 1, txtDate.value)) Then
            txtDate.value = DateAdd(DateInterval.Day, 1, txtDate.value)
        Else
            AlertMessage("Date not in valid range.")
        End If
        fillgrid()
    End Sub
    Protected Sub txtDate_Changed(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtDate.Changed
        getLastFreezedate()
        If validdate(txtDate.value) Then
            fillgrid()
        Else
            AlertMessage("Date not in valid range")
            txtDate.value = CurrentDate
            fillgrid()
        End If
    End Sub
    Protected Sub btsave_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btsave.Click
        btsave.Enabled = False
        Dim db As New DBAccess("CRM")
        db.slDataAdd("FreezeDate", txtDate.value)
        db.slDataAdd("FreezedBy", AgentID)
        db.Executeproc("usp_SaveFreezeAttendance")
        db = Nothing
        SuccessMessage("Attendance freezed upto " & txtDate.Text)
        fillgrid()
        FillEWS()
        getLastFreezedate()
        btsave.Enabled = True
        FreezeAttendance_Mail(" Attendance Cycle have been Freezed ")
    End Sub


    Protected Sub btnFreezeIncentive_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnFreezeIncentive.Click
        btsave.Enabled = False
        Dim db As New DBAccess("CRM")
        db.slDataAdd("FreezeDate", txtDatePLI.value)
        db.slDataAdd("FreezedBy", AgentID)
        db.Executeproc("usp_FreezedPLI")
        db = Nothing
        fillgrid_PLI()
        getLastFreezedatePLI()
        SuccessMessage("Incentive cycle freezed upto " & txtDate.Text)
        btsave.Enabled = True
        FreezeAttendance_Mail(" Incentive Cycle have been Freezed ")
    End Sub

    Private Sub MailService(ByVal Subject As String, ByVal MailBody As String, ByVal Agent_ID As String)
        Dim db As New DBAccess("CRM")
        Dim dt As New DataTable
        db.slDataAdd("AgentId", Agent_ID)
        dt = db.ReturnTable("usp_SupervisorEmails3", , True)
        db = Nothing
        'Dim objWSMail As New ShootMail.Mail
        'Dim objWSMail As New MailSendServiceXX.Service1SoapClient
        Dim strHRO As String = System.Configuration.ConfigurationManager.AppSettings("HRO")

        Dim strTo As String = dt.Rows(0).Item("MailTO")
        Dim strCC As String = dt.Rows(0).Item("MailCC")


        If strCC.Length > 0 Then
            strCC += "," + strHRO
        Else
            strCC += strHRO
        End If

        Dim strBcc As String = dt.Rows(0).Item("MailBCC")
        Dim strFrom As String = System.Configuration.ConfigurationManager.AppSettings("FROM")

        'Live
        Common.SMTPSendMail(strTo, Subject, "Incentive Fill Form <" & strFrom & ">", MailBody, strCC, System.Configuration.ConfigurationManager.AppSettings("WSR_PIP_ProcessManager"))

        'Dev
        '  Common.SMTPSendMail(System.Configuration.ConfigurationManager.AppSettings("WSR_PIP_ProcessManager"), Subject, "Incentive Fill Form <" & strFrom & ">", MailBody, System.Configuration.ConfigurationManager.AppSettings("WSR_PIP_ProcessManager"), System.Configuration.ConfigurationManager.AppSettings("WSR_PIP_ProcessManager"))


    End Sub
    Protected Sub imgfav_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles imgfav.Click
        Common.AddToFav(AgentID, "Freeze Attendance")
        SuccessMessage("Report has been added to your favourite list")
        fillgrid()
    End Sub
    Protected Sub btSaveEWS_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btSaveEWS.Click
        Try
            Dim db As New DBAccess("CRM")
            db.slDataAdd("Month", cboMonth.SelectedValue)
            db.slDataAdd("Year", cboYear.SelectedValue)
            db.slDataAdd("FreezedBy", AgentID)
            db.Executeproc("usp_FreezeEWS")
            db = Nothing
            SuccessMessage("EWS freezed upto upto " & cboMonth.Text & "  " & cboYear.SelectedValue)
            FillEWS()
            fillgrid()
        Catch ex As Exception
            AlertMessage(ex.ToString)
        End Try
    End Sub
    Protected Sub btFreezeVC_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btFreezeVC.Click
        Freeze_UnFreezeVC()
        GetVCStatus()
        fillgrid()
        FillEWS()
    End Sub
#End Region
#Region "Utility"

    Private Sub AlertMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMFail"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub

    Private Sub SuccessMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMSuccess"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub

    'Protected Sub ImageButton1_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton1.Click
    '    'fillgrid()
    '    GridViewExportUtil.Export(lblReportName.CurrentPage & "-" & LblError.Text & ".xls", Me.GdAttendance)
    'End Sub


    Public Overrides Sub VerifyRenderingInServerForm(ByVal Control As Control)

    End Sub

#End Region



End Class
