﻿Imports System.Data
Imports com.nss.DBAccess
Partial Class Staffing_DownTime_DetailView
    Inherits System.Web.UI.Page
    Dim footerval(10) As Double
#Region "--- Properties ---"
    Property CampaignId() As Integer
        Get
            Return ViewState("CampaidnId")
        End Get
        Set(ByVal value As Integer)
            ViewState("CampaidnId") = value
        End Set
    End Property
    Property GroupBy() As String
        Get
            Return ViewState("GroupBy")
        End Get
        Set(ByVal value As String)
            ViewState("GroupBy") = value
        End Set
    End Property
    Property ViewBy() As String
        Get
            Return ViewState("ViewBy")
        End Get
        Set(ByVal value As String)
            ViewState("ViewBy") = value
        End Set
    End Property
    Property StartDay() As Integer
        Get
            Return ViewState("StartDay")
        End Get
        Set(ByVal value As Integer)
            ViewState("StartDay") = value
        End Set
    End Property
    Property EndDay() As Integer
        Get
            Return ViewState("EndDay")
        End Get
        Set(ByVal value As Integer)
            ViewState("EndDay") = value
        End Set
    End Property
    Property AgentId() As String
        Get
            Return ViewState("AgentId")
        End Get
        Set(ByVal value As String)
            ViewState("AgentId") = value
        End Set
    End Property
    Property LoggedUser() As String
        Get
            Return ViewState("LoggedUser")
        End Get
        Set(ByVal value As String)
            ViewState("LoggedUser") = value
        End Set
    End Property
    Property Period() As Integer
        Get
            Return ViewState("Period")
        End Get
        Set(ByVal value As Integer)
            ViewState("Period") = value
        End Set
    End Property
    Property Process() As Integer
        Get
            Return ViewState("Process")
        End Get
        Set(ByVal value As Integer)
            ViewState("Process") = value
        End Set
    End Property

#End Region

#Region "------ Load ------"
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            LoggedUser = Session("AgentID")
            QueryString()
            FillGrid()
            PanelReports.Controls.Add(Common.GetMenu(Request.Url, LoggedUser, Request.ApplicationPath))
        End If
    End Sub
#End Region
#Region "------ Event ------"
    Protected Sub gvDetailView_RowDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles gvDetailView.RowDataBound
        If e.Row.RowType = DataControlRowType.DataRow Then
            footerval(1) = footerval(1) + (e.Row.Cells(8).Text * 60)
            e.Row.Cells(8).Text = Common.TimeString(e.Row.Cells(8).Text * 60)
        ElseIf e.Row.RowType = DataControlRowType.Footer Then
            e.Row.Cells(7).Text = "Total: "
            e.Row.Cells(8).Text = Common.TimeString(footerval(1))
        End If
    End Sub
    Protected Sub btnBack_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnBack.Click
        Response.Redirect("DownTimeReport.aspx?back=yes&CampId=" & CampaignId & "&GroupBy=" & GroupBy & "&Period=" & Period & "&DateFrom=" & StartDay & "&DateTo=" & EndDay & "&Process=" & Process)
    End Sub
    Protected Sub ImgExport_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImgExport.Click
        FillGrid()
        GridViewExportUtil.Export(lblReportName.Text & ".xls", Me.gvDetailView)
    End Sub
#End Region
#Region "------ Functions ------"
    Private Sub QueryString()
        If Request.QueryString("CampId").ToString <> "" Then
            CampaignId = Request.QueryString("CampId")
        ElseIf Request.QueryString("Process") <> 0 Then
            CampaignId = Request.QueryString("Process")
        End If
        GroupBy = Request.QueryString("GroupBy").Trim
        ViewBy = Request.QueryString("View")
        StartDay = Request.QueryString("StartDay")
        EndDay = Request.QueryString("EndDay")
        Period = Request.QueryString("Period")
        Process = Request.QueryString("Process")
        If GroupBy = 1 Then
            AgentId = ViewBy.Split("(")(1)
            AgentId = AgentId.Remove(AgentId.Length - 1)
        ElseIf GroupBy = 3 Then
            Dim viewdate As Date = ViewBy
            ViewBy = viewdate.ToString("yyyyMMdd")
        End If
    End Sub
    Private Sub FillGrid()
        Dim db As New DBAccess
        Dim dt As New DataTable
        Try
            db.slDataAdd("CampaignId", CampaignId)
            db.slDataAdd("AgentId", AgentId)
            If ViewBy <> Nothing Or ViewBy <> "" Then
                db.slDataAdd("Team", ViewBy.ToLower)
            End If
            db.slDataAdd("GroupBy", GroupBy)
            db.slDataAdd("StartDay", StartDay)
            db.slDataAdd("EndDay", EndDay)
            dt = db.ReturnTable("usp_DownTimeDetailView", , True)
            db = Nothing
            gvDetailView.DataSource = dt
            gvDetailView.DataBind()
            dt = Nothing
        Catch ex As Exception
            Throw ex
        End Try
    End Sub
    Private Function IntegerToDateString(ByVal d As Integer) As String
        Return d.ToString.Substring(0, 4) & "-" & d.ToString.Substring(4, 2) & "-" & d.ToString.Substring(6, 2)
    End Function

#End Region

End Class
