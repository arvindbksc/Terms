﻿Imports com.nss.DBAccess
Imports System.Data
Imports System.Text
Imports System.Globalization
Partial Class Staffing_Shift_Down_Time_Default
    Inherits System.Web.UI.Page

#Region "-----Properties-----"

    Property CurrentDate() As Date
        Get
            Return ViewState("CurrentDate")
        End Get
        Set(ByVal value As Date)
            ViewState("CurrentDate") = value
        End Set
    End Property
    Property IncentiveMonth() As Integer
        Get
            Return ViewState("IncentiveMonth")
        End Get
        Set(ByVal value As Integer)
            ViewState("IncentiveMonth") = value
        End Set
    End Property
    Property IncentiveYear() As Integer
        Get
            Return ViewState("IncentiveYear")
        End Get
        Set(ByVal value As Integer)
            ViewState("IncentiveYear") = value
        End Set
    End Property
    Property TransID() As Integer
        Get
            Return ViewState("TransID")
        End Get
        Set(ByVal value As Integer)
            ViewState("TransID") = value
        End Set
    End Property

    Property MinDate() As Date
        Get
            Return ViewState("MinDate")
        End Get
        Set(ByVal value As Date)
            ViewState("MinDate") = value
        End Set
    End Property

    Property ReportType() As Integer
        Get
            Return ViewState("ReportType")
        End Get
        Set(ByVal value As Integer)
            ViewState("ReportType") = value
        End Set
    End Property

    Property CurrentLevel() As Integer
        Get
            Return ViewState("CurrentLevel")
        End Get
        Set(ByVal value As Integer)
            ViewState("CurrentLevel") = value
        End Set
    End Property
    Property SupervisorID() As String
        Get
            Return ViewState("SupervisorID")
        End Get
        Set(ByVal value As String)
            ViewState("SupervisorID") = value
        End Set
    End Property
    Property UserID() As String
        Get
            Return ViewState("UserID")
        End Get
        Set(ByVal value As String)
            ViewState("UserID") = value
        End Set
    End Property
    Property UsrID() As Integer
        Get
            Return ViewState("UsrID")
        End Get
        Set(ByVal value As Integer)
            ViewState("UsrID") = value
        End Set
    End Property
    Property LoginID() As Integer
        Get
            Return ViewState("LoginID")
        End Get
        Set(ByVal value As Integer)
            ViewState("LoginID") = value
        End Set
    End Property
    Property AgentID() As String
        Get
            Return ViewState("AgentID")
        End Get
        Set(ByVal value As String)
            ViewState("AgentID") = value
        End Set
    End Property
    Property CampaignID() As Integer
        Get
            Return ViewState("CampaignID")
        End Get
        Set(ByVal value As Integer)
            ViewState("CampaignID") = value
        End Set
    End Property
#End Region

#Region "-----Load Activities-----"

    Private Sub LoadData()

        Dim db As New DBAccess("CRM")
        'TODO: change this query to stored procedure
        Dim dr As DataRow = db.ReturnRow("SELECT getdate() as currentdate")
        CurrentDate = dr("currentDate")
        txtDate.value = CurrentDate
        db = Nothing
        fillcause()
        'lblDate.Text = "* You can mark the attendance between [" & MinDate.ToString("dd-MMM-yyyy") & "] and [" & CurrentDate.ToString("dd-MMM-yyyy") & "]"
        'fillhour()
    End Sub
    Private Sub fillcause()
        Dim db As New DBAccess("CRM")
        Dim dt As DataTable = db.ReturnTable("select * from tbl_Config_DownTimeCause", , False)
        db = Nothing
        cbocause.DataTextField = "Description"
        cbocause.DataValueField = "ID"
        cbocause.DataSource = dt
        cbocause.DataBind()
        dt = Nothing
    End Sub
    Private Sub FillMenu()
        PanelReports.Controls.Add(Common.GetMenu(Request.Url, AgentID, Request.ApplicationPath))
    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        HumanMessage.Style.Item("visibility") = "hidden"
        If Not IsPostBack Then

            lblReportName.CurrentPage = "Fill Down Time"
            LblError.Visible = False
            AgentID = Session("Agentid")
            PanelReports.Controls.Add(Common.GetMenu(Request.Url, AgentID, Request.ApplicationPath))
            'ReportType = Request.QueryString("ReportType")
            LoadData()
            CurrentLevel = 2

            SupervisorID = Session("UserID")
            UserID = Session("UserID")

            'SupervisorID = "nss47671"
            'UserID = "nss47671"

            fillgrid(SupervisorID)
            link2.Text = Session("username") & "(" & Session("UserID") & ")"
            Image3.Visible = False
            Image4.Visible = False
            Image5.Visible = False
            Image6.Visible = False
            Image7.Visible = False
            Image8.Visible = False
        End If
        'FillMenu()
    End Sub
#End Region

#Region "----Grid Ops----"
    Private Sub fillgrid(ByVal supervisorid As String)
        Dim dbdowntime As New DBAccess
        dbdowntime.slDataAdd("AgentID", AgentID)
        CampaignID = dbdowntime.ReturnValue("usp_GetAgentCampaign", True)
        dbdowntime = Nothing
        GdAttendance.Columns(1).Visible = True
        GdAttendance.Columns(GdAttendance.Columns.Count - 1).Visible = True
        
        Dim db As New DBAccess("CRM")

        db.slDataAdd("supervisorid", supervisorid)
        db.slDataAdd("campaignid", CampaignID)
        db.slDataAdd("dateFrom", txtDate.value.ToString("yyyyMMdd"))
        db.slDataAdd("causeid", cbocause.SelectedValue)
        ' Dim dt As DataTable = db.ReturnTable("usp_retrieveAttendanceData", , True)
        Dim dt As DataTable = db.ReturnTable("usp_getDownTImeHierarchy", , True)
        db = Nothing
        If dt.Rows.Count > 0 Then
            Panel1.Visible = True
            btSubmit.Enabled = True
            btreset.Enabled = True
            GdAttendance.DataSource = dt.DefaultView
            GdAttendance.DataBind()
            Dim totalduration As Integer
            Dim count As Integer = 0
            For Each row As GridViewRow In GdAttendance.Rows
                Dim hdDuration As HiddenField = CType(row.FindControl("hdDuration"), HiddenField)
                If hdDuration.Value <> "" And hdDuration.Value <> "0" Then
                    count = count + 1
                    totalduration += Convert.ToInt64(hdDuration.Value)
                End If
            Next
            Dim thr As Integer = Math.Floor(totalduration / 60)
            Dim tmin As Integer = totalduration Mod 60
            lbltduration.Text = thr.ToString + " hour" + " " + tmin.ToString + " mins"
            lblaffectedtm.Text = count
            txtcomment.Text = dt.Rows(0).Item("Comments").ToString
            txttechTM.Text = dt.Rows(0).Item("techTM").ToString
            If dt.Rows.Count < 1 Then
                btreset.Enabled = False
                btSubmit.Enabled = False
                'btreset.Visible = False
            Else
                btreset.Enabled = True
            End If
            dt = Nothing
            GdAttendance.Columns(1).Visible = False
            GdAttendance.Columns(GdAttendance.Columns.Count - 1).Visible = False
        Else
            btSubmit.Enabled = False
            btreset.Enabled = False
            GdAttendance.DataSource = dt.DefaultView
            GdAttendance.DataBind()
            GdAttendance.Columns(1).Visible = False
            GdAttendance.Columns(GdAttendance.Columns.Count - 1).Visible = False
            Panel1.Visible = False
        End If
        
        'GdAttendance.Columns(GdAttendance.Columns.Count - 2).Visible = False


    End Sub
    Protected Sub GdAttendance_RowDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles GdAttendance.RowDataBound
        Dim dateFrom, dateTo As DateTime
        
        If e.Row.RowType = DataControlRowType.DataRow Then

            Dim cboHourfrom As DropDownList = CType(e.Row.FindControl("cboHourfrom"), DropDownList)
            Dim cboMinfrom As DropDownList = CType(e.Row.FindControl("cboMinfrom"), DropDownList)
            Dim cboHourto As DropDownList = CType(e.Row.FindControl("cboHourto"), DropDownList)
            Dim cboMinto As DropDownList = CType(e.Row.FindControl("cboMinto"), DropDownList)
            Dim hdDuration As HiddenField = CType(e.Row.FindControl("hdDuration"), HiddenField)
            Dim lblDuration As Label = CType(e.Row.FindControl("lblDuration"), Label)
            Dim CampId As HiddenField = CType(e.Row.FindControl("HiddenCampId"), HiddenField)
            Dim i As Integer = 0
            Dim hour As String
            'cboHourfrom.Items.Add("HRS")
            'cboHourto.Items.Add("HRS")
            For i = 0 To 23
                If i < 10 Then
                    hour = "0" & i.ToString()
                Else
                    hour = i.ToString
                End If
                cboHourfrom.Items.Add(hour)
                cboHourto.Items.Add(hour)

            Next

            Dim min As String
            For j As Integer = 0 To 59
                If j < 10 Then
                    min = "0" & j.ToString
                Else
                    min = j.ToString
                End If

                cboMinfrom.Items.Add(min)
                cboMinto.Items.Add(min)
            Next
            cboHourfrom.SelectedValue = GdAttendance.DataKeys(e.Row.RowIndex)("hrfrom").ToString
            cboMinfrom.SelectedValue = GdAttendance.DataKeys(e.Row.RowIndex)("minfrom").ToString
            cboHourto.SelectedValue = GdAttendance.DataKeys(e.Row.RowIndex)("hrto").ToString
            cboMinto.SelectedValue = GdAttendance.DataKeys(e.Row.RowIndex)("minto").ToString
            CampId.Value = GdAttendance.DataKeys(e.Row.RowIndex)("campaignid")
            dateFrom = CType(txtDate.value & " " & cboHourfrom.SelectedValue & ":" & cboMinfrom.SelectedValue, DateTime)
            dateTo = CType(txtDate.value & " " & cboHourto.SelectedValue & ":" & cboMinto.SelectedValue, DateTime)
            Dim difDate As Integer = DateDiff(DateInterval.Minute, dateFrom, dateTo)

            hdDuration.Value = ""
            If difDate > 0 Then
                Dim hr As Integer = Math.Floor(difDate / 60)
                Dim minutes As Integer = difDate Mod 60
                hdDuration.Value = difDate
                lblDuration.Text = hr.ToString + " hour" + " " + minutes.ToString + " mins"
            Else
                lblDuration.Text = ""
                hdDuration.Value = ""
            End If

            

            
            If e.Row.Cells(e.Row.Cells.Count - 1).Text.ToLower = "false" Or CType(e.Row.FindControl("lblAgentID"), Label).Text = SupervisorID Then
                CType(e.Row.FindControl("lnkbtagentname"), LinkButton).Visible = False
            Else
                CType(e.Row.FindControl("lblAgentName"), Label).Visible = False
            End If

        End If
        
    End Sub
    Private Sub getduration(ByVal datefrom As DateTime, ByVal dateto As DateTime, ByVal hdDuration As HiddenField, ByVal lblDuration As Label)
        Dim difDate As Integer = DateDiff(DateInterval.Minute, datefrom, dateto)
        Dim count As Integer = 0
        hdDuration.Value = ""
        If difDate > 0 Then
            Dim hr As Integer = Math.Floor(difDate / 60)
            Dim min As Integer = difDate Mod 60
            hdDuration.Value = difDate
            lblDuration.Text = hr.ToString + " hour" + " " + min.ToString + " mins"
        Else
            lblDuration.Text = ""
            hdDuration.Value = ""
        End If
        Dim totalduration As Integer
        For Each row As GridViewRow In GdAttendance.Rows
            If hdDuration.Value <> "" And hdDuration.Value <> "0" Then
                count = count + 1
                totalduration += Convert.ToInt64(hdDuration.Value)
            End If

        Next
        Dim thr As Integer = Math.Floor(totalduration / 60)
        Dim tmin As Integer = totalduration Mod 60
        lbltduration.Text = thr.ToString + " hour" + " " + tmin.ToString + " mins"
        lblaffectedtm.Text = count
    End Sub
    Protected Sub ddl_SelectedindexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)
        'MsgBox(sender.ToString)
        Dim dateFrom, dateTo As DateTime
        Dim count As Integer = 0
        Dim gvRow As GridViewRow = CType(CType(sender, Control).NamingContainer, GridViewRow)

        dateFrom = CType(txtDate.value & " " & CType(gvRow.FindControl("cboHourfrom"), DropDownList).SelectedValue & ":" & CType(gvRow.FindControl("cboMinfrom"), DropDownList).SelectedValue, DateTime)
        dateTo = CType(txtDate.value & " " & CType(gvRow.FindControl("cboHourTo"), DropDownList).SelectedValue & ":" & CType(gvRow.FindControl("cboMinTo"), DropDownList).SelectedValue, DateTime)
        'getduration(dateFrom, dateTo, CType(gvRow.FindControl("hdduration"), HiddenField), CType(gvRow.FindControl("lblDuration"), Label))
        Dim difDate As Integer = DateDiff(DateInterval.Minute, dateFrom, dateTo)

        CType(gvRow.FindControl("hdduration"), HiddenField).Value = ""
        If difDate > 0 Then
            Dim hr As Integer = Math.Floor(difDate / 60)
            Dim min As Integer = difDate Mod 60
            CType(gvRow.FindControl("hdduration"), HiddenField).Value = difDate
            CType(gvRow.FindControl("lblDuration"), Label).Text = hr.ToString + " hour" + " " + min.ToString + " mins"
        Else
            CType(gvRow.FindControl("lblDuration"), Label).Text = ""
            CType(gvRow.FindControl("hdduration"), HiddenField).Value = ""
        End If
        Dim totalduration As Integer
        For Each row As GridViewRow In GdAttendance.Rows
            If CType(row.FindControl("hdduration"), HiddenField).Value <> "" And CType(row.FindControl("hdduration"), HiddenField).Value <> "0" Then
                count = count + 1
                totalduration += Convert.ToInt64(CType(row.FindControl("hdduration"), HiddenField).Value)
            End If

        Next
        Dim thr As Integer = Math.Floor(totalduration / 60)
        Dim tmin As Integer = totalduration Mod 60
        lbltduration.Text = thr.ToString + " hour" + " " + tmin.ToString + " mins"
        lblaffectedtm.Text = count
        ' MsgBox(dateFrom)
        ' MsgBox(CType(gvRow.FindControl("cboHourfrom"), DropDownList).SelectedValue)
    End Sub

#End Region

#Region "-----Supervisor change-----"


    Protected Sub GdAttendance_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles GdAttendance.SelectedIndexChanged

        Dim lnk As New LinkButton, img As New Image
        CurrentLevel += 1
        Select Case CurrentLevel
            Case 3
                lnk = link3
                img = Image3
                link2.CssClass = "notselectedlink"
            Case 4
                lnk = Link4
                img = Image4
                link3.CssClass = "notselectedlink"
            Case 5
                lnk = Link5
                img = Image5
                Link4.CssClass = "notselectedlink"
            Case 6
                lnk = Link6
                img = Image6
                Link5.CssClass = "notselectedlink"
            Case 7
                lnk = Link7
                img = Image7
                Link6.CssClass = "notselectedlink"
            Case 8
                lnk = Link8
                img = Image8
                Link7.CssClass = "notselectedlink"
        End Select
        lnk.Text = GdAttendance.SelectedDataKey.Item("AgentName").ToString & "(" & GdAttendance.SelectedDataKey.Item("AgentID").ToString & ")"
        SupervisorID = GdAttendance.SelectedDataKey.Item("AgentID").ToString
        fillgrid(SupervisorID)

        lnk.Visible = True
        lnk.CssClass = "selectedlink"
        img.Visible = True

    End Sub

    Private Sub HideAllSideLinks(ByVal ctrl As LinkButton)
        Dim from As Integer
        from = ctrl.ID.ToLower.Replace("link", "")
        CurrentLevel = from

        Select Case from
            Case 2
                link3.Visible = False
                Link4.Visible = False
                Link5.Visible = False
                Link6.Visible = False
                Link7.Visible = False
                Link8.Visible = False

                Image3.Visible = False
                Image4.Visible = False
                Image5.Visible = False
                Image6.Visible = False
                Image7.Visible = False
                Image8.Visible = False
            Case 3
                Link4.Visible = False
                Link5.Visible = False
                Link6.Visible = False
                Link7.Visible = False
                Link8.Visible = False
                Image4.Visible = False
                Image5.Visible = False
                Image6.Visible = False
                Image7.Visible = False
                Image8.Visible = False
            Case 4

                Link5.Visible = False
                Link6.Visible = False
                Link7.Visible = False
                Link8.Visible = False
                Image5.Visible = False
                Image6.Visible = False
                Image7.Visible = False
                Image8.Visible = False
            Case 5

                Link6.Visible = False
                Link7.Visible = False
                Link8.Visible = False

                Image6.Visible = False
                Image7.Visible = False
                Image8.Visible = False
            Case 6

                Link7.Visible = False
                Link8.Visible = False

                Image7.Visible = False
                Image8.Visible = False
            Case 7

                Link8.Visible = False

                Image8.Visible = False
            Case 8
                'do noting
        End Select




    End Sub

    Protected Sub Sidelink_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles link2.Click

        Dim length As Integer

        length = sender.Text.LastIndexOf(")") - sender.Text.LastIndexOf("(")

        SupervisorID = sender.Text.Substring(sender.Text.LastIndexOf("(") + 1, length - 1)
        fillgrid(SupervisorID)
        HideAllSideLinks(sender)
        sender.CssClass = "selectedlink"
    End Sub

#End Region
#Region "-----Date movement-----"


    Private Function validdate(ByVal selecteddate As DateTime) As Boolean
        If selecteddate > CurrentDate Then
            Return False
        End If
        Return True
    End Function
    Protected Sub btdatedecrease_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btdatedecrease.Click
        If validdate(DateAdd(DateInterval.Day, -1, txtDate.value)) Then
            txtDate.value = DateAdd(DateInterval.Day, -1, txtDate.value)
            fillgrid(SupervisorID)
        Else
            AlertMessage("Date not in valid range.")
        End If


    End Sub

    Protected Sub btdateincrease_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btdateincrease.Click

        If validdate(DateAdd(DateInterval.Day, 1, txtDate.value)) Then
            txtDate.value = DateAdd(DateInterval.Day, 1, txtDate.value)
            fillgrid(SupervisorID)
        Else

            AlertMessage("Date not in valid range.")

        End If


    End Sub

    Protected Sub txtDate_Changed(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtDate.Changed
        If validdate(txtDate.value) Then
            fillgrid(SupervisorID)
        Else
            AlertMessage("Date not in valid range")
            txtDate.value = CurrentDate
            fillgrid(SupervisorID)
        End If
    End Sub
#End Region
#Region "---Save Down Time----"
    'Protected Sub btsave_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btsave.Click
    '    btsave.Enabled = False

    '    If ValidateControls() Then

    '    End If
    '    btsave.Enabled = True
    '    btSubmit.Enabled = True

    'End Sub
    Protected Sub btreset_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btreset.Click
        Dim hdduration As HiddenField, lblDuration As Label, cbhrfrom, cbminfrom, cbhrto, cbminto As DropDownList
        For Each dgRow As GridViewRow In GdAttendance.Rows
            hdduration = dgRow.FindControl("hdduration")
            cbhrfrom = dgRow.FindControl("cboHourfrom")
            cbminfrom = dgRow.FindControl("cboMinfrom")
            cbhrto = dgRow.FindControl("cboHourto")
            cbminto = dgRow.FindControl("cboMinto")
            lblDuration = dgRow.FindControl("lblDuration")
            lblDuration.Text = ""
            hdduration.Value = ""
            cbhrfrom.SelectedValue = "00"
            cbminfrom.SelectedValue = "00"
            cbhrto.SelectedValue = "00"
            cbminto.SelectedValue = "00"
        Next
        lblaffectedtm.Text = ""
        lbltduration.Text = ""
        txtcomment.Text = ""
    End Sub
    Protected Sub btSubmit_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btSubmit.Click
        If ValidateControls() Then
            btreset.Enabled = False
            btSubmit.Enabled = False
            'Dim dbdowntime As New DBAccess("CRM")
            'CampaignID = dbdowntime.ReturnValue("select campaignid  from tbl_AgentMaster where AgentID ='" & SupervisorID & "'", False)
            'dbdowntime = Nothing
            Dim db As New DBAccess("CRM")

            db.BeginTrans()
            Try
                Dim dateFrom, dateTo As DateTime
                Dim CampId As HiddenField
                Dim hdduration As HiddenField, lbAgentid, lbAgentName As Label, cbhrfrom, cbminfrom, cbhrto, cbminto As DropDownList
                For Each dgRow As GridViewRow In GdAttendance.Rows
                    hdduration = dgRow.FindControl("hdduration")
                    lbAgentid = dgRow.FindControl("lblAgentID")
                    lbAgentName = dgRow.FindControl("lblAgentName")
                    cbhrfrom = dgRow.FindControl("cboHourfrom")
                    cbminfrom = dgRow.FindControl("cboMinfrom")
                    cbhrto = dgRow.FindControl("cboHourto")
                    cbminto = dgRow.FindControl("cboMinto")
                    CampId = dgRow.FindControl("HiddenCampId")
                    dateFrom = CType(txtDate.value & " " & cbhrfrom.SelectedValue & ":" & cbminfrom.SelectedValue, DateTime)
                    dateTo = CType(txtDate.value & " " & cbhrto.SelectedValue & ":" & cbminto.SelectedValue, DateTime)
                    db.slDataAdd("CampaignID", CampId.Value)
                    db.slDataAdd("causeid", cbocause.SelectedValue)
                    db.slDataAdd("Agentid", lbAgentid.Text)
                    db.slDataAdd("DateFrom", dateFrom)
                    db.slDataAdd("DateTo", dateTo)
                    db.Executeproc("usp_DeletePreviousFilledDownTime")
                    If hdduration.Value <> "" And hdduration.Value <> "0" Then
                        db.slDataAdd("CampaignID", CampId.Value)
                        db.slDataAdd("causeid", cbocause.SelectedValue)
                        db.slDataAdd("Agentid", lbAgentid.Text)
                        db.slDataAdd("DateFrom", dateFrom)
                        db.slDataAdd("DateTo", dateTo)
                        db.slDataAdd("TimeFrom", cbhrfrom.SelectedValue & ":" & cbminfrom.SelectedValue)
                        db.slDataAdd("TimeTo", cbhrto.SelectedValue & ":" & cbminto.SelectedValue)
                        db.slDataAdd("Duration", hdduration.Value)
                        db.slDataAdd("FilledBy", UserID)
                        db.slDataAdd("Comment", txtcomment.Text.Trim)
                        db.slDataAdd("supervisorid", SupervisorID)
                        db.slDataAdd("TechTM", txttechTM.Text.Trim)
                        db.Executeproc("usp_InsertDownTime")
                    End If
                Next
                db.CommitTrans()
                fillgrid(SupervisorID)
                SuccessMessage("Saved")
                btreset.Enabled = True
                btSubmit.Enabled = True
            Catch ex As Exception
                db.RollBackTrans()
                LblError.Visible = True
                LblError.Text = ex.Message
            Finally
                db = Nothing
            End Try
        End If
        For Each row As GridViewRow In GdAttendance.Rows
            
        Next

    End Sub

    Private Function ValidateControls() As Boolean
        ' Dim gridrow As DataGridItem
        'Dim row As GridViewRow


        'TO ENSURE THAT ONLY NUMERIC DATA IS ENTERED 
        'If txtcomment.Text.Length > 10 Then
        '    LblError.Text = "Comment should not be more then 10 chars"
        '    LblError.Visible = True
        '    Return False
        'End If
        'For Each row In GdAttendance.Rows
        '    If Not CType(row.FindControl("txtPLI"), TextBox).Text = "" Then
        '        If Not IsNumeric(CType(row.FindControl("txtPLI"), TextBox).Text) Then
        '            LblError.Visible = True
        '            AlertMessage("Please Enter numeric values for the PLI Amount")
        '            'LblError.Text = "Please Enter numeric values for the PLI Amount"
        '            '  LblError.ForeColor = Drawing.Color.Red
        '            Return False
        '        End If
        '    End If

        '    If Not CType(row.FindControl("txtQFI"), TextBox).Text = "" Then
        '        If Not IsNumeric(CType(row.FindControl("txtQFI"), TextBox).Text) Then
        '            LblError.Visible = True
        '            AlertMessage("Please Enter numeric values for the QFI Amount")
        '            ' LblError.Text = "Please Enter numeric values for the QFI Amount"
        '            ' LblError.ForeColor = Drawing.Color.Red
        '            Return False
        '        End If
        '    End If

        '    If Not CType(row.FindControl("txtArrears"), TextBox).Text = "" Then
        '        If Not IsNumeric(CType(row.FindControl("txtArrears"), TextBox).Text) Then
        '            LblError.Visible = True
        '            AlertMessage("Please Enter numeric values for the Arrears Amount")
        '            ' LblError.Text = "Please Enter numeric values for the Arrears Amount"
        '            'LblError.ForeColor = Drawing.Color.Red
        '            Return False
        '        End If
        '    End If

        '    If Not CType(row.FindControl("txtArrears"), TextBox).Text = "" And CType(row.FindControl("txtArrears"), TextBox).Text <> "0" Then
        '        If CType(row.FindControl("txtComments"), TextBox).Text = "" Then
        '            LblError.Visible = True
        '            AlertMessage("Please Enter the Comments corresponding to the Arrears Filled in")
        '            'LblError.Text = "Please Enter the Comments corresponding to the Arrears Filled in"
        '            'LblError.ForeColor = Drawing.Color.Red
        '            Return False
        '        End If
        '    End If
        'Next

        Return True
    End Function
#End Region
#Region "Utility"

    Private Sub AlertMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMFail"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub

    Private Sub SuccessMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMSuccess"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub
    Public Overrides Sub VerifyRenderingInServerForm(ByVal Control As Control)

    End Sub

#End Region


    Protected Sub imgfav_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles imgfav.Click
        Common.AddToFav(AgentID, "Fill Down Time")
        fillgrid(SupervisorID)
    End Sub

    Protected Sub cbocause_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cbocause.SelectedIndexChanged
        fillgrid(SupervisorID)
    End Sub
End Class
