﻿
Partial Class Attendance_testusrcontrol
    Inherits System.Web.UI.Page

    Protected Sub ucDatePicker1_Changed(ByVal sender As Object, ByVal e As System.EventArgs) Handles ucDatePicker1.Changed
        Response.Write(ucDatePicker1.yyyymmdd)
    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            ucDatePicker1.value = Date.Now.Date
        End If
    End Sub
End Class
