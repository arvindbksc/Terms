﻿Imports System.Data
Imports System.Text
Imports System.Data.Sql
Imports System.Data.SqlClient
Imports System.IO

Partial Class PerfSum_TransactionData
    Inherits System.Web.UI.Page
    Dim footerval(12) As Integer
    Dim dt, dt1 As DataTable

    'Dim connCRM As String = Common.connCRM
    'Dim connLeads As String = Common.connLeads
    'Dim connreport As String = Common.connreport
    Dim connAttendance As String = "Server=GGN-NSS-DEV;user id=TestAttendance;Password=password1;database=Attendance"
    Dim conn As SqlConnection
    Dim cmd As SqlCommand
#Region "Properties"

    Property ProcessID() As Integer
        Get
            Return ViewState("ProcessID")
        End Get
        Set(ByVal value As Integer)
            ViewState("ProcessID") = value
            Session("ProcessID") = value
        End Set
    End Property
    Property Campaigntype() As Integer
        Get
            Return ViewState("Campaigntype")
        End Get
        Set(ByVal value As Integer)
            ViewState("Campaigntype") = value
            'Session("ProcessID") = value
        End Set
    End Property
    Property ReportType() As Integer
        Get
            Return ViewState("ReportType")
        End Get
        Set(ByVal value As Integer)
            ViewState("ReportType") = value
        End Set
    End Property
    Property CampaignID() As Integer
        Get
            Return ViewState("CampaignID")
        End Get
        Set(ByVal value As Integer)
            ViewState("CampaignID") = value
        End Set
    End Property

    Property AgentID() As String
        Get
            Return ViewState("AgentID")
        End Get
        Set(ByVal value As String)
            ViewState("AgentID") = value
        End Set
    End Property
    Property startday() As Integer
        Get
            Return ViewState("startday")
        End Get
        Set(ByVal value As Integer)
            ViewState("startday") = value
        End Set
    End Property
    Property endday() As Integer
        Get
            Return ViewState("endday")
        End Get
        Set(ByVal value As Integer)
            ViewState("endday") = value
        End Set
    End Property
#End Region
#Region "Load Data"
    Private Sub LoadData()
        FillCardHolder()
    End Sub
    Private Sub FillCardHolder()
        Try
            Using con As New SqlConnection(connAttendance)
                Using cmd As New SqlCommand("usp_getAccessCardEmployees_Demo")
                    cmd.CommandType = CommandType.StoredProcedure
                    cmd.Connection = con
                    con.Open()
                    ddlHolderNumber.DataSource = cmd.ExecuteReader()
                    ddlHolderNumber.DataTextField = "Employee"
                    ddlHolderNumber.DataValueField = "EmpID"
                    ddlHolderNumber.DataBind()
                    con.Close()
                End Using
            End Using
        Catch ex As Exception
            lblErrorMessage.Text = ex.Message
        End Try
    End Sub
#End Region

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            LoadData()
        End If
    End Sub
    Public Sub Test()
        Try
            Dim strFile As String = "D:\Gaurav\Company Document\PunchData5.csv"

            Dim reader As StreamReader = New System.IO.StreamReader(File.OpenRead(strFile))
            Dim listA As New List(Of String)()
            If System.IO.File.Exists(strFile) = True Then
                '    File.Delete(strFile)
                Dim sw As New StreamWriter(strFile)
                Dim s As String = String.Empty

                While reader.Peek() >= 0
                    Dim line As String = reader.ReadLine()
                    Dim values As String() = line.Split(";"c)
                    listA.Add(values(0))
                    s = s + line + Chr(10)
                End While
                reader.Close()
                sw.Write(s)
                sw.Close()
            End If

        Catch ex As Exception
            lblErrorMessage.Text = ex.Message
        End Try

    End Sub

    Protected Sub btn1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btn1.Click
        Try

            'Dim stLine As String = ""
            'Dim objWriter As IO.StreamWriter = IO.File.AppendText(_strCustomerCSVPath)
            'If IO.File.Exists(_strCustomerCSVPath) Then
            '    objWriter.Write(_CustomerID & ",")
            '    objWriter.Write(_FirstName & ",")
            '    objWriter.Write(_LastName & ",")
            '    objWriter.Write(_Email & ",")

            '    'If value contains comma in the value then you have to perform this opertions
            '    Dim append = If(_Msg.Contains(","), String.Format("""{0}""", _Msg), _Msg)
            '    stLine = String.Format("{0}{1},", stLine, append)
            '    objWriter.Write(stLine)

            '    objWriter.Write(_Phone)
            '    objWriter.Write(Environment.NewLine)
            'End If
            'objWriter.Close()



            'Dim strFile As String = "D:\Gaurav\Company Document\PunchData6.csv"
            Dim reader As StreamReader = New System.IO.StreamReader(File.OpenRead("D:\Gaurav\Company Document\PunchData8.csv"))
            Dim listA As New List(Of String)()
            If System.IO.File.Exists("D:\Gaurav\Company Document\PunchData8.csv") = True Then
                '    File.Delete(strFile)
                Using sw As StreamWriter = New StreamWriter("D:\Gaurav\Company Document\PunchData8.csv")
                    'Dim sw As New StreamWriter("D:\Gaurav\Company Document\PunchData7.csv", False, System.Text.Encoding.UTF8)
                    Dim s As String = String.Empty

                    While reader.Peek() >= 0
                        Dim line As String = reader.ReadLine()
                        Dim values As String() = line.Split(";"c)
                        listA.Add(values(0))
                        s = s + line + Chr(10)
                    End While
                    reader.Close()
                    sw.Write(s)
                    sw.Close()
                End Using
            End If

            'Test()
            'conn = New SqlConnection(connreport)
            'cmd = New SqlCommand()
            'cmd.Parameters.AddWithValue("IOGateNo", Label1.Text)
            'cmd.Parameters.AddWithValue("IOGateName", btn1.Text)
            'cmd.Parameters.AddWithValue("IOStatus", lbl1.Text)
            'cmd.Parameters.AddWithValue("EmployeeID", ddlHolderNumber.SelectedItem.Value)
            'cmd.Connection = conn
            'cmd.CommandType = CommandType.StoredProcedure
            'cmd.CommandText = "usp_InsertAccessCard_Demo"

            'conn.Open()
            'cmd.ExecuteNonQuery()
            'conn.Close()
            'cmd = Nothing
        Catch ex As Exception
            lblErrorMessage.Text = ex.Message
        End Try
    End Sub

    Protected Sub btn2_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btn2.Click
        Try
            conn = New SqlConnection(connAttendance)
            cmd = New SqlCommand()
            cmd.Parameters.AddWithValue("IOGateNo", Label2.Text)
            cmd.Parameters.AddWithValue("IOGateName", btn2.Text)
            cmd.Parameters.AddWithValue("IOStatus", lbl2.Text)
            cmd.Parameters.AddWithValue("EmployeeID", ddlHolderNumber.SelectedItem.Value)
            cmd.Connection = conn
            cmd.CommandType = CommandType.StoredProcedure
            cmd.CommandText = "usp_InsertAccessCard_Demo"

            conn.Open()
            cmd.ExecuteNonQuery()
            conn.Close()
            cmd = Nothing
        Catch ex As Exception
            lblErrorMessage.Text = ex.Message
        End Try
    End Sub

    Protected Sub btn3_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btn3.Click
        Try
            conn = New SqlConnection(connAttendance)
            cmd = New SqlCommand()
            cmd.Parameters.AddWithValue("IOGateNo", Label3.Text)
            cmd.Parameters.AddWithValue("IOGateName", btn3.Text)
            cmd.Parameters.AddWithValue("IOStatus", lbl3.Text)
            cmd.Parameters.AddWithValue("EmployeeID", ddlHolderNumber.SelectedItem.Value)
            cmd.Connection = conn
            cmd.CommandType = CommandType.StoredProcedure
            cmd.CommandText = "usp_InsertAccessCard_Demo"

            conn.Open()
            cmd.ExecuteNonQuery()
            conn.Close()
            cmd = Nothing
        Catch ex As Exception
            lblErrorMessage.Text = ex.Message
        End Try
    End Sub

    Protected Sub btn4_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btn4.Click
        Try
            conn = New SqlConnection(connAttendance)
            cmd = New SqlCommand()
            cmd.Parameters.AddWithValue("IOGateNo", Label4.Text)
            cmd.Parameters.AddWithValue("IOGateName", btn4.Text)
            cmd.Parameters.AddWithValue("IOStatus", lbl4.Text)
            cmd.Parameters.AddWithValue("EmployeeID", ddlHolderNumber.SelectedItem.Value)
            cmd.Connection = conn
            cmd.CommandType = CommandType.StoredProcedure
            cmd.CommandText = "usp_InsertAccessCard_Demo"

            conn.Open()
            cmd.ExecuteNonQuery()
            conn.Close()
            cmd = Nothing
        Catch ex As Exception
            lblErrorMessage.Text = ex.Message
        End Try
    End Sub

    Protected Sub btn5_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btn5.Click
        Try
            conn = New SqlConnection(connAttendance)
            cmd = New SqlCommand()
            cmd.Parameters.AddWithValue("IOGateNo", Label5.Text)
            cmd.Parameters.AddWithValue("IOGateName", btn5.Text)
            cmd.Parameters.AddWithValue("IOStatus", lbl5.Text)
            cmd.Parameters.AddWithValue("EmployeeID", ddlHolderNumber.SelectedItem.Value)
            cmd.Connection = conn
            cmd.CommandType = CommandType.StoredProcedure
            cmd.CommandText = "usp_InsertAccessCard_Demo"

            conn.Open()
            cmd.ExecuteNonQuery()
            conn.Close()
            cmd = Nothing
        Catch ex As Exception
            lblErrorMessage.Text = ex.Message
        End Try
    End Sub

    Protected Sub btn6_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btn6.Click
        Try
            conn = New SqlConnection(connAttendance)
            cmd = New SqlCommand()
            cmd.Parameters.AddWithValue("IOGateNo", Label6.Text)
            cmd.Parameters.AddWithValue("IOGateName", btn6.Text)
            cmd.Parameters.AddWithValue("IOStatus", lbl6.Text)
            cmd.Parameters.AddWithValue("EmployeeID", ddlHolderNumber.SelectedItem.Value)
            cmd.Connection = conn
            cmd.CommandType = CommandType.StoredProcedure
            cmd.CommandText = "usp_InsertAccessCard_Demo"

            conn.Open()
            cmd.ExecuteNonQuery()
            conn.Close()
            cmd = Nothing
        Catch ex As Exception
            lblErrorMessage.Text = ex.Message
        End Try
    End Sub
End Class
