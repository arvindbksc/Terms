﻿Imports com.nss.DBAccess
Imports System.Data

Partial Class SSat_EusatSummary
    Inherits System.Web.UI.Page
    Dim dtEusat As DataTable
#Region " --- Properties ---"

    Property CampaignID() As Integer
        Get
            Return 0 'ViewState("CampaignID")
        End Get
        Set(ByVal value As Integer)
            'ViewState("CampaignID") = value
        End Set
    End Property

    Property AgentID() As String
        Get
            Return ViewState("AgentID")
        End Get
        Set(ByVal value As String)
            ViewState("AgentID") = value
        End Set
    End Property
#End Region

#Region " --- Load ---"

    Private Sub LoadData()
        FillCommonFilters()
        Common.FillProcessCampaigns(CboProcess, cboCampaigns, AgentID, CampaignID)
        Dim lstCamp As New ListItem
        lstCamp.Value = 0
        lstCamp.Text = "All"
        If cboCampaigns.Items.Contains(lstCamp) Then
            cboCampaigns.Items.Remove(lstCamp)
        End If
    End Sub
    Private Sub FillCommonFilters()
        Dim db As New DBAccess
        Dim dt As DataTable = db.ReturnTable("select * from tbl_Reports_DatePeriods")
        db = Nothing
        Dim dr As DataRow = dt.NewRow
        dr(0) = 10
        dr(1) = "Between"
        dt.Rows.Add(dr)
        CboPeriod.DataTextField = "Caption"
        CboPeriod.DataValueField = "Period"
        CboPeriod.DataSource = dt
        CboPeriod.DataBind()
        dt = Nothing
        db = Nothing
    End Sub

    

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            If Session("AgentId") <> "" Then
                CampaignID = Session("CampaignID")
                AgentID = Session("AgentID")
                PanelReports.Controls.Add(Common.GetMenu(Request.Url, AgentID, Request.ApplicationPath))
                LoadData()
                GetEusatData()
                UcDateTo.Visible = False
                ucDateFrom.Visible = False
                lblAnd.Visible = False
            End If
        End If
        GetEusatData()
        Dim btnlink As New LinkButton()
    End Sub
#End Region

#Region "--- Functions ---"
    Private Sub GetEusatData()
        breadcrumbs.CurrentPage = "Eusat Summary Report"
        Dim startday As Integer, endday As Integer
        Dim db As DBAccess
        dtEusat = New DataTable
        If CboPeriod.SelectedValue = 10 Then
            startday = ucDateFrom.yyyymmdd
            endday = UcDateTo.yyyymmdd
        Else
            db = New DBAccess
            db.slDataAdd("Period", CboPeriod.SelectedValue)
            db.slDataAdd("Campaignid", CampaignID)
            Dim dr As DataRow = db.ReturnRow("usp_GetStart_EndDateForAPeriod", True)
            db = Nothing
            startday = dr(0)
            endday = dr(1)
        End If
        db = New DBAccess
        db.slDataAdd("campid", cboCampaigns.SelectedValue)
        db.slDataAdd("datefrom", startday)
        db.slDataAdd("dateto", endday)
        dtEusat = db.ReturnTable("usp_GetEUSATData", , True)
        db = Nothing
        gdEusatSummary.DataSource = dtEusat
        gdEusatSummary.DataBind()
    End Sub

#End Region

#Region " --- Event ---"
    Protected Sub CboPeriod_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles CboPeriod.SelectedIndexChanged
        If CboPeriod.SelectedValue = 10 Then
            ucDateFrom.Visible = True
            UcDateTo.Visible = True
            lblAnd.Visible = True
            GetEusatData()
        Else
            ucDateFrom.Visible = False
            UcDateTo.Visible = False
            lblAnd.Visible = False
            GetEusatData()
        End If
    End Sub
    Protected Sub cboCampaigns_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboCampaigns.SelectedIndexChanged
        GetEusatData()
    End Sub
    Protected Sub btnRefresh_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnRefresh.Click
        GetEusatData()
    End Sub
    Protected Sub ImageButton1_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton1.Click
        GetEusatData()
        GridViewExportUtil.Export(breadcrumbs.CurrentPage & ".xls", Me.gdEusatSummary)
    End Sub
    Protected Sub ucDateFrom_Changed(ByVal sender As Object, ByVal e As System.EventArgs) Handles ucDateFrom.Changed
        GetEusatData()
    End Sub
    Protected Sub UcDateTo_Changed(ByVal sender As Object, ByVal e As System.EventArgs) Handles UcDateTo.Changed
        GetEusatData()
    End Sub
    Protected Sub gdEusatSummary_RowDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles gdEusatSummary.RowDataBound
        Dim btnlink As LinkButton
        If e.Row.RowType = DataControlRowType.DataRow Then
            If gdEusatSummary.HeaderRow.Cells.Item(4).Text = "Transid" Then
                btnlink = New LinkButton
                btnlink.ID = dtEusat.Rows(e.Row.RowIndex)("transid").ToString
                btnlink.Text = dtEusat.Rows(e.Row.RowIndex)("transid").ToString
                AddHandler btnlink.Click, AddressOf Me.btnlink_OnClick
                e.Row.Cells(dtEusat.Columns.Count - 1).Controls.Add(btnlink)
            End If
        End If
    End Sub
    Public Sub btnlink_OnClick(ByVal sender As Object, ByVal e As EventArgs)
        gvTransactiondetail.Visible = True
        Dim Transactionid As String = CType(sender, LinkButton).ID
        Dim Str As String = "$('#DialogBackground').height($(document).height()-10);$('#DialogBackground').width($(window).width());$('#DialogBackground').css('visibility','visible');$('#pnlTransactionDetails').css('visibility','visible');" & _
            " $('#pnlTransactionDetails').css('left',($(window).width() - $('#pnlTransactionDetails').width())/2); "
        ScriptManager.RegisterStartupScript(Page, Page.GetType(), "pnlTransactionDetails", Str, True)
        Dim db As New DBAccess("CRM")
        db.slDataAdd("transid", Convert.ToInt32(Transactionid))
        Dim dt As DataTable = db.ReturnTable("usp_GetCMFTransactionDetails", , True)
        db = Nothing
        gvTransactiondetail.DataSource = dt
        gvTransactiondetail.DataBind()
    End Sub
    Protected Sub imgExit_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles imgExit.Click
        gvTransactiondetail.Visible = False
        Dim Str As String = "$('#DialogBackground').height($(document).height()-10);$('#DialogBackground').width($(window).width());$('#DialogBackground').css('visibility','hidden');$('#pnlTransactionDetails').css('visibility','hidden');" & _
           " $('#pnlTransactionDetails').css('left',($(window).width() - $('#pnlTransactionDetails').width())/2); "
        ScriptManager.RegisterStartupScript(Page, Page.GetType(), "pnlTransactionDetails", Str, True)
    End Sub
#End Region
End Class
