﻿Imports com.nss.DBAccess
Imports System.Data

Partial Class SSat_HourlyEusatReport
    Inherits System.Web.UI.Page

#Region "--- Properties ---"

    Property CampaignId() As Integer
        Get
            Return ViewState("Campaignid")
        End Get
        Set(ByVal value As Integer)
            ViewState("Campaignid") = value
        End Set
    End Property
    Property AgentID() As String
        Get
            Return ViewState("AgentID")
        End Get
        Set(ByVal value As String)
            ViewState("AgentID") = value
        End Set
    End Property
#End Region

#Region "--- Load ---"
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            If Session("AgentID") <> "" Then
                AgentID = Session("AgentID")
                PanelReports.Controls.Add(Common.GetMenu(Request.Url, AgentID, Request.ApplicationPath))
                breadcrumbs.CurrentPage = " EUSAT Hourly Report"
                FillCampaigns()
            End If
        End If
    End Sub
    Private Sub FillCampaigns()
        FillCommonFilters()
        Common.FillProcessCampaigns(CboProcess, cboCampaigns, AgentID, CampaignId)
        Dim lstCamp As New ListItem
        lstCamp.Value = 0
        lstCamp.Text = "All"
        If cboCampaigns.Items.Contains(lstCamp) Then
            cboCampaigns.Items.Remove(lstCamp)
        End If
        UcDateTo.Visible = False
        ucDateFrom.Visible = False
        lblAnd.Visible = False
    End Sub
    Private Sub FillCommonFilters()
        Dim db As New DBAccess
        Dim dt As DataTable = db.ReturnTable("select * from tbl_Reports_DatePeriods")
        db = Nothing
        Dim dr As DataRow = dt.NewRow
        dr(0) = 10
        dr(1) = "Between"
        dt.Rows.Add(dr)
        CboPeriod.DataTextField = "Caption"
        CboPeriod.DataValueField = "Period"
        CboPeriod.DataSource = dt
        CboPeriod.DataBind()
        dt = Nothing
        db = Nothing
    End Sub
#End Region

#Region "--- Function ---"
    Private Sub GetEusatHourlyData()
        breadcrumbs.CurrentPage = " EUSAT Hourly Report"
        Dim startday As Integer, endday As Integer
        Dim db As DBAccess
        Dim dtEusatData As DataTable
        If CboPeriod.SelectedValue = 10 Then
            startday = ucDateFrom.yyyymmdd
            endday = UcDateTo.yyyymmdd
        Else
            db = New DBAccess
            db.slDataAdd("Period", CboPeriod.SelectedValue)
            db.slDataAdd("Campaignid", CampaignId)
            Dim dr As DataRow = db.ReturnRow("usp_GetStart_EndDateForAPeriod", True)
            db = Nothing
            startday = dr(0)
            endday = dr(1)
        End If
        db = New DBAccess
        db.slDataAdd("campid", CampaignId) ' cboCampaigns.SelectedValue)
        db.slDataAdd("datefrom", startday)
        'db.slDataAdd("dateto", endday)
        dtEusatData = db.ReturnTable("usp_Hourly_EusatData", , True)
        db = Nothing
        gdEUSATHourly.DataSource = dtEusatData
        gdEUSATHourly.DataBind()
    End Sub

#End Region

#Region "--- Events ---"
    Protected Sub CboPeriod_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles CboPeriod.SelectedIndexChanged
        If CboPeriod.SelectedValue = 10 Then
            ucDateFrom.Visible = True
            UcDateTo.Visible = True
            lblAnd.Visible = True
            GetEusatHourlyData()
        Else
            ucDateFrom.Visible = False
            UcDateTo.Visible = False
            lblAnd.Visible = False
            GetEusatHourlyData()
        End If
    End Sub
    Protected Sub cboCampaigns_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboCampaigns.SelectedIndexChanged
        CampaignId = cboCampaigns.SelectedValue
        GetEusatHourlyData()
    End Sub
    Protected Sub btnRefresh_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnRefresh.Click
        GetEusatHourlyData()
    End Sub
    Protected Sub ImageButton1_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton1.Click
        GetEusatHourlyData()
        GridViewExportUtil.Export(breadcrumbs.CurrentPage & ".xls", Me.gdEUSATHourly)
    End Sub
    Protected Sub ucDateFrom_Changed(ByVal sender As Object, ByVal e As System.EventArgs) Handles ucDateFrom.Changed
        GetEusatHourlyData()
    End Sub
    Protected Sub UcDateTo_Changed(ByVal sender As Object, ByVal e As System.EventArgs) Handles UcDateTo.Changed
        GetEusatHourlyData()
    End Sub
#End Region
End Class
