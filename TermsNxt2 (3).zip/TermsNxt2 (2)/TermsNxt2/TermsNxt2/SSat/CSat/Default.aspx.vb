﻿Imports com.nss.DBAccess
Imports System.Data
Imports System.Text
Partial Class SSat_CSat_Default
    Inherits System.Web.UI.Page
#Region "Properties"
    Property ReportType() As Integer
        Get
            Return ViewState("ReportType")
        End Get
        Set(ByVal value As Integer)
            ViewState("ReportType") = value
        End Set
    End Property
    Property CampaignID() As Integer
        Get
            Return 0 'ViewState("CampaignID")
        End Get
        Set(ByVal value As Integer)
            'ViewState("CampaignID") = value
        End Set
    End Property

    Property AgentID() As String
        Get
            Return ViewState("AgentID")
        End Get
        Set(ByVal value As String)
            ViewState("AgentID") = value
        End Set
    End Property
    Property SurveyID() As Integer
        Get
            Return ViewState("SurveyID")
        End Get
        Set(ByVal value As Integer)
            ViewState("SurveyID") = value
        End Set
    End Property
    Property SurveyStartTime() As DateTime
        Get
            Return ViewState("SurveyStartTime")
        End Get
        Set(ByVal value As DateTime)
            ViewState("SurveyStartTime") = value
        End Set
    End Property
#End Region
#Region "Load"
   
    Private Sub getAvailSurvey()
        Dim db As New DBAccess("CRM")
        db.slDataAdd("Agentid", AgentID)
        Dim dt As DataTable = db.ReturnTable("usp_CSSGetAvailableSurvey", , True)
        db = Nothing
        GdSurvey.DataSource = dt
        GdSurvey.DataBind()
        dt = Nothing
    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        HumanMessage.Style.Item("visibility") = "hidden"
        If Not IsPostBack Then
            ReportType = Request.QueryString("ReportType")
            If Session("AgentID") <> "" Then
                CampaignID = Session("CampaignID")
                AgentID = Session("AgentID")
                PanelReports.Controls.Add(Common.GetMenu(Request.Url, AgentID, Request.ApplicationPath))
                getAvailSurvey()
                'fillgrid()
            End If
        End If
    End Sub
    Private Sub fillgrid()
        'GridView1.DataSource = Nothing
        Dim db As New DBAccess("CRM")
        db.slDataAdd("SurveyID", SurveyID)
        Dim dt As DataTable = db.ReturnTable("usp_CSSGetSurveyRating", , True)
        db = Nothing
        db = New DBAccess("CRM")
        db.slDataAdd("SurveyID", SurveyID)
        Dim dtsurveysheet As DataTable = db.ReturnTable("usp_CSSGetSurveySheet", , True)
        db = Nothing
        For Each row As DataRow In dt.Rows
            dtsurveysheet.Columns.Add(row.Item(1))
        Next
        For Each row1 As DataRow In dtsurveysheet.Rows
            For Each row2 As DataRow In dt.Rows
                row1.Item(row2.Item(1)) = row2.Item(0)
            Next
        Next
        'For Each col As DataColumn In dtsurveysheet.Columns
        For Each row As DataRow In dt.Rows
            'If Not col.ColumnName.Contains("QuestionId") And Not col.ColumnName.Contains("Description") And Not col.ColumnName.Contains("Sequence") And Not col.ColumnName.Contains("OverallQ") Then
            Dim tempfield As New TemplateField()
            tempfield.HeaderText = row(1).ToString
            tempfield.HeaderStyle.CssClass = "ROgridMidItem"
            tempfield.ItemStyle.CssClass = "ROgridMidItem"

            tempfield.ItemTemplate = New GridViewTemplate(DataControlRowType.DataRow, row(1).ToString)
            GridView1.Columns.Add(tempfield)
            ' End If
        Next
        Dim tempcmntfield As New TemplateField()
        tempcmntfield.HeaderText = "Comment"
        tempcmntfield.HeaderStyle.CssClass = "ROgridMidItem"
        tempcmntfield.ItemStyle.CssClass = "ROgridMidItem"
        tempcmntfield.ItemTemplate = New GridViewTemplateComment(DataControlRowType.DataRow)
        GridView1.Columns.Add(tempcmntfield)
        ' Next
        GridView1.DataSource = dtsurveysheet
        GridView1.DataBind()
        dtsurveysheet = Nothing
        '' Gaurav
        ViewState("dynamicGrid") = True
    End Sub
   
#End Region
#Region "Event"
    Protected Sub lnk_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Dim gvRow As GridViewRow = CType(CType(sender, Control).NamingContainer, GridViewRow)
        SurveyID = GdSurvey.DataKeys(gvRow.RowIndex)("SurveyID").ToString()
        GdSurvey.Visible = False
        tblcomment.Visible = True
        fillgrid()
        GridView1.Visible = True
        ViewState("dynamicGrid") = True
        Dim db As New DBAccess
        SurveyStartTime = db.ReturnValue("select getdate()", False)
    End Sub
    Protected Sub btSave_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btSave.Click
        Dim strMsg As String
        Dim score As Integer
        Dim i As Integer = 1
        strMsg = ""
        For Each gvRow1 As GridViewRow In GridView1.Rows
            Dim flag As Boolean = False
            Dim lbl As Label = CType(gvRow1.FindControl("lblquestion"), Label)
            For inti As Integer = 2 To GridView1.Columns.Count - 2
                Dim rb As HtmlInputRadioButton = CType(gvRow1.FindControl(GridView1.Columns(inti).HeaderText), HtmlInputRadioButton)
                If rb.Checked Then
                    flag = True
                    score = rb.Value
                End If
            Next
            If flag = False Then
                strMsg = strMsg + i.ToString + "." + lbl.Text & "<br>"
                i = i + 1
            End If
        Next
        If strMsg <> "" Then
            lblnotfilledquestion.Text = strMsg
            Dim str As String
            str = "$('#DialogBackground').height($(document).height()-10);$('#DialogBackground').width($(window).width());$('#DialogBackground').css('visibility','visible');$('#Pnlsurvey').css('visibility','visible');" & _
            " $('#Pnlsurvey').css('left',($(window).width() - $('#Pnlsurvey').width())/2); "
            ScriptManager.RegisterStartupScript(Page, Page.GetType(), "Movedialog", str, True)
        Else
            SaveSurvey()
        End If
    End Sub
    Protected Sub imgfav_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles imgfav.Click
        Common.AddToFav(AgentID, "CSS")
        SuccessMessage("CSS has been added to your favourite list")
        fillgrid()
    End Sub
#End Region
#Region "Support Function"
    Protected Overrides Sub LoadViewState(ByVal earlierState As Object)
        MyBase.LoadViewState(earlierState)
        If ViewState("dynamicGrid") Then
            fillgrid()
        End If
    End Sub
    Private Sub SaveSurvey()
        Dim db As New DBAccess("CRM")
        Dim sheetid As Integer
        db.BeginTrans()
        Dim endtime As DateTime = db.ReturnValue("select getdate()", False)
        db.slDataAdd("StartTime", SurveyStartTime)
        db.slDataAdd("EndTime", endtime)
        db.slDataAdd("AgentID", AgentID)
        db.slDataAdd("OverallComment", txtOcomment.Text.Trim)
        db.slDataAdd("SurveyId", SurveyID)
        sheetid = db.ReturnValue("usp_InsertCSSSheetMst", True)
        For Each gvRow1 As GridViewRow In GridView1.Rows
            Dim rating As Integer = 0

            Dim questionid As HiddenField = CType(gvRow1.FindControl("questionid"), HiddenField)
            Dim seqid As HiddenField = CType(gvRow1.FindControl("SeqId"), HiddenField)
            Dim comment As TextBox = CType(gvRow1.FindControl("txtQComment"), TextBox)
            db.slDataAdd("SheetId", sheetid)
            db.slDataAdd("QuestionId", questionid.Value)
            db.slDataAdd("SeqId", seqid.Value)
            For inti As Integer = 2 To GridView1.Columns.Count - 2
                Dim rb As HtmlInputRadioButton = CType(gvRow1.FindControl(GridView1.Columns(inti).HeaderText), HtmlInputRadioButton)
                If rb.Checked Then
                    rating = rb.Value

                    'Else
                    '    
                End If
            Next
            If rating = 0 Then
                db.slDataAdd("Rating", 0)
            Else
                db.slDataAdd("Rating", rating)
            End If
            db.slDataAdd("Comments", comment.Text.Trim)
            db.slDataAdd("SurveyId", SurveyID)
            db.Executeproc("usp_InsertCSSSheetData")
        Next
        db.CommitTrans()
        Dim msg As String = ""
        msg = "<b>Survey Successfully Completed.</b><br /><b>Thank You for your valuable feedback.</b>"
        SuccessMessage(msg)
        reset()
        SendConfirmationMail()
        getAvailSurvey()
    End Sub
    Private Sub SendConfirmationMail()
        Dim Body, Subject As String
        Subject = "CSS Completed"

        Body = "CSS Completed by: " & Session("Username")
        'Dim objWSMail As New ShootMail.Mail
        Dim objWSMail As New ServiceReference1.Service1SoapClient

        Dim strTo As String = System.Configuration.ConfigurationManager.AppSettings("CSSTO")
        Dim strCC As String = System.Configuration.ConfigurationManager.AppSettings("CSSCC")
        Dim strBcc As String = System.Configuration.ConfigurationManager.AppSettings("CSSCC")
        Dim strFrom As String = "TermsMonitor@corforgetech.com"
        'objWSMail.MailSend(strTo, Body, "", strCC, strBcc, strFrom, Subject)
        objWSMail.MailSendNew(strTo, Subject, strFrom, "TermsMonitor", Body, "", strCC, strBcc, "")

        objWSMail = Nothing
    End Sub
    Protected Sub brtclose_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles brtclose.Click
        reset()

    End Sub

    Protected Sub btnOK_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnOK.Click
        SaveSurvey()
        
    End Sub
    Private Sub reset()
        GdSurvey.Visible = True
        GridView1.DataSource = Nothing
        GridView1.Visible = False
        tblcomment.Visible = False
        ViewState("dynamicGrid") = False
        GridView1.Columns.Clear()
    End Sub
#End Region
#Region "Utility"

    Private Sub AlertMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMFail"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub

    Private Sub SuccessMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMSuccess"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub
    Public Overrides Sub VerifyRenderingInServerForm(ByVal Control As Control)

    End Sub

#End Region
   
    Protected Sub GdSurvey_RowDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles GdSurvey.RowDataBound
        If e.Row.RowType = DataControlRowType.DataRow Then
            Dim lblavlsurvey As Label = CType(e.Row.FindControl("lblavlsurvey"), Label)
            Dim lnksurvey As LinkButton = CType(e.Row.FindControl("lnksurvey"), LinkButton)
            If e.Row.Cells(4).Text = "Completed" Then
                lblavlsurvey.Visible = True
                lnksurvey.Visible = False
            Else
                lblavlsurvey.Visible = False
                lnksurvey.Visible = True
            End If
        End If
    End Sub

   
End Class
Public Class GridViewTemplate
    Implements ITemplate
    Private templateType As DataControlRowType
    Private columnName, ColumnID As String
    Dim id As String

    Sub New(ByVal type As DataControlRowType, ByVal colname As String)
        templateType = type
        columnName = colname
        id = colname
        'ColumnID = colid
    End Sub

    Sub InstantiateIn(ByVal container As Control) Implements ITemplate.InstantiateIn

        ' Create the content for the different row types.
        'Dim rd As New RadioButton
        'AddHandler rd.DataBinding, AddressOf rd_DataBinding
        'container.Controls.Add(rd)
        Dim rdb As New HtmlInputRadioButton
        AddHandler rdb.DataBinding, AddressOf rdb_databinding
        container.Controls.Add(rdb)
    End Sub
    Private Sub rdb_databinding(ByVal sender As Object, ByVal e As System.EventArgs)
        Dim ldb As HtmlInputRadioButton
        ldb = sender

        Dim row As GridViewRow = CType(ldb.NamingContainer, GridViewRow)
        ldb.Value = DataBinder.Eval(row.DataItem, columnName).ToString()
        'ldb.ID = DataBinder.Eval(row.DataItem, ColumnID).ToString()
        ldb.ID = id

        ldb.Name = "rating"
    End Sub
    'Private Sub BindLiteralControl(ByVal sender As Object, ByVal e As System.EventArgs)
    '    Dim lc As LiteralControl
    '    lc = sender

    '    Dim row As GridViewRow = CType(lc.NamingContainer, GridViewRow)
    '    lc.Text = DataBinder.Eval(row.DataItem, columnName).ToString()
    'End Sub
    Private Sub rd_DataBinding(ByVal sender As Object, ByVal e As EventArgs)

        ' Get the Label control to bind the value. The Label control
        ' is contained in the object that raised the DataBinding 
        ' event (the sender parameter).
        Dim l As RadioButton = CType(sender, RadioButton)

        ' Get the GridViewRow object that contains the Label control. 
        Dim row As GridViewRow = CType(l.NamingContainer, GridViewRow)
        l.GroupName = "rating"
        l.ID = id
        ' Get the field value from the GridViewRow object and 
        ' assign it to the Text property of the Label control.
        l.Text = DataBinder.Eval(row.DataItem, columnName).ToString()
        'l.Text = DataBinder.Eval(row.DataItem, "au_rd").ToString()

    End Sub



End Class
Public Class GridViewTemplateComment
    Implements ITemplate
    'Private templateType As DataControlRowType
    'Private columnName, ColumnID As String
    Dim id As String

    Sub New(ByVal type As DataControlRowType)
        'templateType = type
        'columnName = colname
        id = "txtQComment"
        'ColumnID = colid
    End Sub

    Sub InstantiateIn(ByVal container As Control) Implements ITemplate.InstantiateIn

        Dim cmnt As New TextBox
        cmnt.ID = id
        cmnt.TextMode = TextBoxMode.MultiLine
        cmnt.Rows = 3
        'AddHandler cmnt.DataBinding, AddressOf cmnt_databinding
        container.Controls.Add(cmnt)
    End Sub
    'Private Sub cmnt_databinding(ByVal sender As Object, ByVal e As System.EventArgs)
    '    Dim ldb As HtmlInputRadioButton
    '    ldb = sender

    '    Dim row As GridViewRow = CType(ldb.NamingContainer, GridViewRow)
    '    ldb.Value = DataBinder.Eval(row.DataItem, columnName).ToString()
    '    'ldb.ID = DataBinder.Eval(row.DataItem, ColumnID).ToString()
    '    ldb.ID = id

    '    ldb.Name = "rating"
    'End Sub
End Class

