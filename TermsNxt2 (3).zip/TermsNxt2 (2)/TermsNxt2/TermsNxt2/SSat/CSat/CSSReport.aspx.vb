﻿Imports com.nss.DBAccess
Imports System.Data
Partial Class SSat_CSat_CSSReport
    Inherits System.Web.UI.Page
#Region "Properties"

    Property ProcessID() As Integer
        Get
            Return ViewState("ProcessID")
        End Get
        Set(ByVal value As Integer)
            ViewState("ProcessID") = value
            Session("ProcessID") = value
        End Set
    End Property
    Property Campaigntype() As Integer
        Get
            Return ViewState("Campaigntype")
        End Get
        Set(ByVal value As Integer)
            ViewState("Campaigntype") = value
            'Session("ProcessID") = value
        End Set
    End Property
    Property ReportType() As Integer
        Get
            Return ViewState("ReportType")
        End Get
        Set(ByVal value As Integer)
            ViewState("ReportType") = value
        End Set
    End Property
    Property CampaignID() As Integer
        Get
            Return ViewState("CampaignID")
        End Get
        Set(ByVal value As Integer)
            ViewState("CampaignID") = value
        End Set
    End Property

    Property AgentID() As String
        Get
            Return ViewState("AgentID")
        End Get
        Set(ByVal value As String)
            ViewState("AgentID") = value
        End Set
    End Property
#End Region
    Private Sub LoadData()
        FillSurvey()
        FillSurveyProcess()
        FillSurveyUser()
    End Sub
    Private Sub FillSurvey()
        Dim db As New DBAccess("CRM")
        Dim strsql = "select SurveyId,Description from tbl_Config_CSSSurvey order by SurveyId desc"
        Dim dt As New DataTable
        dt = db.ReturnTable(strsql, , False)
        db = Nothing
        CboSurvey.DataTextField = "Description"
        CboSurvey.DataValueField = "SurveyID"
        CboSurvey.DataSource = dt
        CboSurvey.DataBind()
        dt = Nothing
    End Sub
    Private Sub FillSurveyProcess()
        Dim db As New DBAccess
        Dim dt As New DataTable
        db.slDataAdd("Surveyid", CboSurvey.SelectedValue)
        dt = db.ReturnTable("usp_getSurveyProcessUser", , True)
        db = Nothing
        Dim dr As DataRow
        dr = dt.NewRow
        dr("ProcessName") = "All"
        dr("ProcessID") = 0
        dt.Rows.Add(dr)
        'Dim arr() As String = {"ProcessId", "ProcessName"}
        'dt = dt.DefaultView().ToTable(True, arr)
        CboProcess.DataTextField = "ProcessName"
        CboProcess.DataValueField = "processid"
        CboProcess.DataSource = dt
        CboProcess.DataBind()
        If ProcessID <> -1 Then
            CboProcess.Items.FindByValue(ProcessID).Selected = True
        End If
        dt = Nothing
    End Sub
    Private Sub FillSurveyUser()
        Dim db As New DBAccess
        Dim dt As New DataTable
        db.slDataAdd("Surveyid", CboSurvey.SelectedValue)
        db.slDataAdd("processid", CboProcess.SelectedValue)
        dt = db.ReturnTable("usp_getSurveyUser", , True)
        db = Nothing
        Dim dr As DataRow
        dr = dt.NewRow
        dr("AgentName") = "All"
        dr("AgentiD") = "%"
        dt.Rows.Add(dr)
        'Dim arr() As String = {"AgentiD", "AgentName"}
        'dt = dt.DefaultView().ToTable(True, arr)
        Cbouser.DataTextField = "AgentName"
        Cbouser.DataValueField = "AgentiD"
        Cbouser.DataSource = dt
        Cbouser.DataBind()
        Cbouser.SelectedValue = "%"
        'If AgentID <> "-1" Then
        '    Cbouser.Items.FindByValue(AgentID).Selected = True
        'End If
        dt = Nothing
    End Sub
    Private Sub fillgrid()
        'GdSurvey.Columns.Clear()
        'GdSurvey.DataSource = Nothing
        Dim db As New DBAccess
        db.slDataAdd("SurveyId", CboSurvey.SelectedValue)
        db.slDataAdd("ProcessId", CboProcess.SelectedValue)
        db.slDataAdd("AgentId", Cbouser.SelectedValue)
        db.slDataAdd("filterBy", cboFilterBy.SelectedValue)
        Dim dt As DataTable = db.ReturnTable("usp_getCSSResult", , True)
        db = Nothing
        If dt.Rows.Count > 0 Then
            'MsgBox(GdSurvey.Columns.Count)
            While GdSurvey.Columns.Count > 2
                GdSurvey.Columns.RemoveAt(GdSurvey.Columns.Count - 1)
            End While
            'If GdSurvey.Columns.Count > 2 Then
            '    For i As Integer = 2 To GdSurvey.Columns.Count
            '        If i = 2 Then
            '            'If GdSurvey.Columns.Count > 2 Then
            '            GdSurvey.Columns.RemoveAt(i)
            '            'End If
            '        End If
            'If GdSurvey.Columns.Count = 2 Then
            '    i = 0
            '    Exit For
            'Else
            '    i -= 1
            'End If
            '    Next
            'End If

            Dim bouncol As BoundField
            'If Not IsPostBack Then
            'Dim i As Integer = 2
            For Each col As DataColumn In dt.Columns
                bouncol = New BoundField
                If col.ColumnName.ToLower <> "qseqid" And col.ColumnName.ToLower <> "questionid" And col.ColumnName.ToLower <> "description" Then
                    'If GdSurvey.Columns.Count > 2 And IsPostBack Then
                    '    GdSurvey.Columns.RemoveAt(i)
                    'End If
                    bouncol.HeaderText = col.ColumnName
                    bouncol.DataField = col.ColumnName
                    GdSurvey.Columns.Add(bouncol)
                    'i += 1
                End If
            Next
            'End If
            GdSurvey.DataSource = dt
            GdSurvey.DataBind()
            dt = Nothing
            ViewState("dynamicGrid") = True
        End If
    End Sub
    Protected Overrides Sub LoadViewState(ByVal earlierState As Object)
        MyBase.LoadViewState(earlierState)
        If ViewState("dynamicGrid") Then
            LoadData()
            fillgrid()
        End If
    End Sub
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        HumanMessage.Style.Item("visibility") = "hidden"
        If Not IsPostBack Then
            ReportType = Request.QueryString("ReportType")
            If Session("AgentID") <> "" Then
                CampaignID = Session("CampaignID")
                AgentID = Session("AgentID")
                PanelReports.Controls.Add(Common.GetMenu(Request.Url, AgentID, Request.ApplicationPath))
                LoadData()
                fillgrid()
            End If
        End If
    End Sub

    Protected Sub CboSurvey_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles CboSurvey.SelectedIndexChanged
        FillSurveyProcess()
        FillSurveyUser()
        fillgrid()
    End Sub

    Protected Sub CboProcess_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles CboProcess.SelectedIndexChanged
        FillSurveyUser()
        fillgrid()
    End Sub

    Protected Sub Cbouser_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles Cbouser.SelectedIndexChanged
        fillgrid()
    End Sub
    Dim footerval(10) As Double

    Protected Sub GdSurvey_RowCommand(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewCommandEventArgs) Handles GdSurvey.RowCommand
        If e.CommandName = "select" Then
            Dim db As New DBAccess("CRM")
            Dim strsql As String = ""
            strsql = "select AM.AgentName as Customer,B.Comments as [Question Comments] from tbl_Data_CSSSheetMst A inner join tbl_Data_CSSSheet B on A.SheetId=B.SheetId"
            strsql = strsql + " inner join tbl_AgentMaster AM on AM.AgentID=A.AgentID where A.SurveyId='" & CboSurvey.SelectedValue & "' and B.QuestionId='" & e.CommandArgument & "'"
            Dim dt As DataTable = db.ReturnTable(strsql, , False)
            db = Nothing
            GridView1.DataSource = dt
            GridView1.DataBind()
            dt = Nothing
            Dim str As String
            str = "$('#DialogBackground').height($(document).height()-10);$('#DialogBackground').width($(window).width());$('#DialogBackground').css('visibility','visible');$('#Pnlremarks').css('visibility','visible');" & _
            " $('#Pnlremarks').css('left',($(window).width() - $('#Pnlremarks').width())/2); "
            ScriptManager.RegisterStartupScript(Page, Page.GetType(), "Movedialog", str, True)
        End If
    End Sub
    Protected Sub GdSurvey_RowDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles GdSurvey.RowDataBound
        'Dim colcount As Integer   
        If e.Row.RowType = DataControlRowType.Header Then
            For i As Integer = 0 To footerval.Length - 1
                footerval(i) = 0
            Next
        End If
        If e.Row.RowType = DataControlRowType.DataRow Then
            'MsgBox(e.Row.Cells.Count)
            For i As Integer = 2 To e.Row.Cells.Count - 1
                footerval(i) = footerval(i) + e.Row.Cells(i).Text
            Next
            For i As Integer = 3 To e.Row.Cells.Count - 1
                e.Row.Cells(i).Text = e.Row.Cells(i).Text + ", " + Math.Round((e.Row.Cells(i).Text / e.Row.Cells(2).Text) * 100, 2).ToString + "%"
            Next
        End If
        If e.Row.RowType = DataControlRowType.Footer Then
            e.Row.Cells(1).Text = "[Total , Overall Percentage]"
            e.Row.Cells(1).ForeColor = Drawing.Color.Red
            For i As Integer = 2 To e.Row.Cells.Count - 1
                e.Row.Cells(i).Text = footerval(i)
            Next
            For i As Integer = 3 To e.Row.Cells.Count - 1
                e.Row.Cells(i).Text = footerval(i).ToString + ", " + Math.Round((footerval(i) / e.Row.Cells(2).Text) * 100, 2).ToString + "%"
            Next
        End If
    End Sub
    
    Protected Sub lnkOverallcomment_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles lnkOverallcomment.Click
        Dim db As New DBAccess("CRM")
        Dim strsql As String = ""
        strsql = "select AM.AgentName as Customer,A.OverallComment as [Overall Comments] from tbl_Data_CSSSheetMst A"
        strsql = strsql + " inner join tbl_AgentMaster AM on AM.AgentID=A.AgentID where A.SurveyId='" & CboSurvey.SelectedValue & "'"
        Dim dt As DataTable = db.ReturnTable(strsql, , False)
        db = Nothing
        GridView1.DataSource = dt
        GridView1.DataBind()
        dt = Nothing
        Dim str As String
        str = "$('#DialogBackground').height($(document).height()-10);$('#DialogBackground').width($(window).width());$('#DialogBackground').css('visibility','visible');$('#Pnlremarks').css('visibility','visible');" & _
        " $('#Pnlremarks').css('left',($(window).width() - $('#Pnlremarks').width())/2); "
        ScriptManager.RegisterStartupScript(Page, Page.GetType(), "Movedialog", str, True)
    End Sub

    Protected Sub cboFilterBy_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboFilterBy.SelectedIndexChanged
        ' For Each row As GridViewRow In GdSurvey.Rows
        'For i As Integer = 2 To GdSurvey.Columns.Count - 1
        '    GdSurvey.Columns.RemoveAt(i)
        'Next
        ' Next
        'MsgBox(GdSurvey.Columns.Count)
        fillgrid()
    End Sub

    Protected Sub imgfav_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles imgfav.Click
        Common.AddToFav(AgentID, "CSS report")
        SuccessMessage("CSS report has been added to your favourite list")
        FillSurveyProcess()
        FillSurveyUser()
        fillgrid()
    End Sub
#Region "Utility"

    Private Sub AlertMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMFail"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub

    Private Sub SuccessMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMSuccess"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub
    Public Overrides Sub VerifyRenderingInServerForm(ByVal Control As Control)

    End Sub

#End Region

    Protected Sub ImageButton1_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton1.Click
        fillgrid()
        GridViewExportUtil.Export(lblReportName.Text & "-" & LblError.Text & ".xls", Me.GdSurvey)
    End Sub
End Class
