﻿Imports System.Data
Imports com.nss.DBAccess
Partial Class SSat_CSat_NewCSSReport
    Inherits System.Web.UI.Page
#Region "--- Properties ---"
    Property ProcessID() As Integer
        Get
            Return ViewState("ProcessID")
        End Get
        Set(ByVal value As Integer)
            ViewState("ProcessID") = value
            Session("ProcessID") = value
        End Set
    End Property
    Property CampaignID() As Integer
        Get
            Return ViewState("CampaignID")
        End Get
        Set(ByVal value As Integer)
            ViewState("CampaignID") = value
        End Set
    End Property
    Property AgentID() As String
        Get
            Return ViewState("AgentID")
        End Get
        Set(ByVal value As String)
            ViewState("AgentID") = value
        End Set
    End Property
#End Region

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        HumanMessage.Style.Item("visibility") = "hidden"
        If Not IsPostBack Then
            If Session("AgentID") <> "" Then
                CampaignID = Session("CampaignID")
                AgentID = Session("AgentID")
                PanelReports.Controls.Add(Common.GetMenu(Request.Url, AgentID, Request.ApplicationPath))
                LoadData()
                FillData()
            End If
        End If
    End Sub
#Region "--- Support Function ---"
    Private Sub LoadData()
        FillSurvey()
        FillSurveyProcess()
        FillSurveyUser()
    End Sub
    Private Sub FillSurvey()
        Dim db As New DBAccess("CRM")
        Dim strsql = "SELECT [CSSID],[Name] FROM tbl_CSS_Mst WHERE Active=1 ORDER BY CSSID desc"
        Dim dt As New DataTable
        dt = db.ReturnTable(strsql, , False)
        db = Nothing
        Dim dr As DataRow
        dr = dt.NewRow
        dr("Name") = "All"
        dr("CSSID") = 0
        dt.Rows.Add(dr)
        CboSurvey.DataTextField = "Name"
        CboSurvey.DataValueField = "CSSID"
        CboSurvey.DataSource = dt
        CboSurvey.DataBind()
        dt = Nothing
    End Sub
    Private Sub FillSurveyProcess()
        Dim db As New DBAccess("CRM")
        Dim dt As New DataTable
        db.slDataAdd("Surveyid", CboSurvey.SelectedValue)
        dt = db.ReturnTable("usp_CSS_GetSurveyProcessUser", , True)
        db = Nothing
        Dim dr As DataRow
        dr = dt.NewRow
        dr("ProcessName") = "All"
        dr("processid") = 0
        dt.Rows.Add(dr)
        CboProcess.DataTextField = "ProcessName"
        CboProcess.DataValueField = "processid"
        CboProcess.DataSource = dt
        CboProcess.DataBind()
        'If ProcessID <> -1 Then
        '    CboProcess.Items.FindByValue(ProcessID).Selected = True
        'End If
        dt = Nothing
    End Sub
    Private Sub FillSurveyUser()
        Dim db As New DBAccess("CRM")
        Dim dt As New DataTable
        db.slDataAdd("Surveyid", CboSurvey.SelectedValue)
        db.slDataAdd("processid", CboProcess.SelectedValue)
        dt = db.ReturnTable("usp_CSS_GetSurveyUser", , True)
        db = Nothing
        Dim dr As DataRow
        dr = dt.NewRow
        dr("AgentName") = "All"
        dr("AgentiD") = "%"
        dt.Rows.Add(dr)
        Cbouser.DataTextField = "AgentName"
        Cbouser.DataValueField = "AgentiD"
        Cbouser.DataSource = dt
        Cbouser.DataBind()
        Cbouser.SelectedValue = "%"
        dt = Nothing
    End Sub
    Private Sub FillData()
        Dim db As New DBAccess("CRM")
        Dim dt As New DataTable
        db.slDataAdd("CssID", CboSurvey.SelectedValue)
        db.slDataAdd("ProcessId", CboProcess.SelectedValue)
        db.slDataAdd("AgentId", Cbouser.SelectedValue)
        dt = db.ReturnTable("usp_CSS_SurveyReport", , True)
        db = Nothing
        GdSurvey.DataSource = dt
        GdSurvey.DataBind()
    End Sub
#End Region
#Region "--- Events ---"
    Protected Sub CboProcess_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles CboProcess.SelectedIndexChanged
        FillSurveyUser()
        FillData()
    End Sub
    Protected Sub CboSurvey_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles CboSurvey.SelectedIndexChanged
        FillSurveyProcess()
        FillSurveyUser()
        FillData()
    End Sub
    Protected Sub Cbouser_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles Cbouser.SelectedIndexChanged
        FillData()
    End Sub
    Protected Sub imgfav_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles imgfav.Click
        Common.AddToFav(AgentID, "CSS report")
        SuccessMessage("CSS Report has been added to your favourite list")
        FillSurvey()
        FillSurveyProcess()
        FillSurveyUser()
        FillData()
    End Sub
    Protected Sub ImageButton1_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton1.Click
        FillData()
        GridViewExportUtil.Export(lblReportName.Text & "-" & LblError.Text & ".xls", Me.GdSurvey)
    End Sub
#End Region

#Region "--- Utility ---"
    Private Sub AlertMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMFail"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub
    Private Sub SuccessMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMSuccess"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub
#End Region

   
End Class
