﻿Imports com.nss.DBAccess
Imports System.Data
Imports System.Text
Partial Class SSat_CSat_CSS
    Inherits System.Web.UI.Page
    'Dim dt As DataTable
#Region "Properties"
    Property CSSID() As Integer
        Get
            Return ViewState("CSSID")
        End Get
        Set(ByVal value As Integer)
            ViewState("CSSID") = value
        End Set
    End Property
    Property AgentID() As String
        Get
            Return ViewState("AgentID")
        End Get
        Set(ByVal value As String)
            ViewState("AgentID") = value
        End Set
    End Property
    Property SurveyStartTime() As DateTime
        Get
            Return ViewState("SurveyStartTime")
        End Get
        Set(ByVal value As DateTime)
            ViewState("SurveyStartTime") = value
        End Set
    End Property
    Property dt() As DataTable
        Get
            Return ViewState("dt")
        End Get
        Set(ByVal value As DataTable)
            ViewState("dt") = value
        End Set
    End Property
#End Region
    Private Sub getAvailSurvey()
        Dim db As New DBAccess("CRM")
        db.slDataAdd("Agentid", AgentID)
        Dim dt As DataTable = db.ReturnTable("usp_CSSGetSurveyList", , True)
        db = Nothing
        GdSurvey.DataSource = dt
        GdSurvey.DataBind()
        dt = Nothing
        btSave.Visible = False
        brtclose.Visible = False
        reptcss.Visible = False
        GdSurvey.Visible = True
    End Sub
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        HumanMessage.Style.Item("visibility") = "hidden"
        btSave.Attributes.Add("onclick", " this.disabled = true; " + ClientScript.GetPostBackEventReference(btSave, Nothing) + ";")
        If Not IsPostBack Then
            If Session("AgentID") <> "" Then
                AgentID = Session("AgentID")
                getAvailSurvey()
                'fillgrid()
            End If
        End If
    End Sub
    Private Sub fillgrid()
        Dim db As New DBAccess("CRM")
        db.slDataAdd("CSSID", CSSID)
        dt = db.ReturnTable("usp_getCSSSurvey", , True)
        db = Nothing
        Dim col() As String = {"ParamId", "ParamText"}
        Dim dtparam As DataTable = dt.DefaultView.ToTable(True, col)
        reptcss.DataSource = dtparam
        reptcss.DataBind()
    End Sub
    Protected Sub reptcss_ItemDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.RepeaterItemEventArgs) Handles reptcss.ItemDataBound
        If e.Item.ItemType <> ListItemType.Header And e.Item.ItemType <> ListItemType.Footer Then
            Dim rblList As RadioButtonList = e.Item.FindControl("RdbListSubAns")
            Dim questionid As HiddenField = e.Item.FindControl("questionid")
            Dim ShowPnlAnsID As HiddenField = e.Item.FindControl("ShowPnlAnsID")
            Dim cboanswer As DropDownList = e.Item.FindControl("cboanswer")
            Dim col() As String = {"AnsId", "AnsText"}
            If dt.Select("ParamId=" & questionid.Value).Length > 0 Then
                Dim dtans As DataTable = dt.Select("ParamId=" & questionid.Value).CopyToDataTable()
                dtans = dtans.DefaultView.ToTable(True, col)
                cboanswer.DataTextField = "AnsText"
                cboanswer.DataValueField = "Ansid"
                cboanswer.DataSource = dtans
                cboanswer.DataBind()
                Dim i As New ListItem
                i.Text = ""
                i.Value = -1
                cboanswer.Items.Insert(0, i)

            End If
            'AddHandler cboanswer.SelectedIndexChanged, AddressOf cboselectindexchange
            'If dt.Select("ParamId=" & questionid.Value & " and subansid <> 0").Length > 0 Then
            '    Dim col1() As String = {"SubAnsId", "SubAnsText", "Ansid"}
            '    Dim dtSubans As DataTable = dt.Select("ParamId=" & questionid.Value & " and subansid <> 0").CopyToDataTable.DefaultView.ToTable(True, col1)
            '    rblList.DataTextField = "SubAnsText"
            '    rblList.DataValueField = "SubAnsId"
            '    rblList.DataSource = dtSubans
            '    rblList.DataBind()
            '    ShowPnlAnsID.Value = questionid.Value.ToString & dtSubans.Rows(0)("Ansid").ToString
            'End If

        End If
    End Sub
    Protected Sub cboselectindexchange(ByVal sender As Object, ByVal e As System.EventArgs)
        'Dim cbo As DropDownList = reptcss.FindControl("cboanswer")
        Dim rblList As RadioButtonList = sender.parent.FindControl("RdbListSubAns")
        Dim questionid As HiddenField = sender.parent.FindControl("questionid")
        Dim ShowPnlAnsID As HiddenField = sender.parent.FindControl("ShowPnlAnsID")
        Dim pnlCSS As Panel = sender.parent.FindControl("pnlCSS")
        If dt.Select("ParamId=" & questionid.Value & " and ansid=" & sender.SelectedValue & " and subansid <> 0").Length > 0 Then
            Dim col1() As String = {"SubAnsId", "SubAnsText", "Ansid", "sequence"}
            Dim dtSubans As DataTable = dt.Select("ParamId=" & questionid.Value & "  and ansid=" & sender.SelectedValue & " and subansid <> 0", "sequence").CopyToDataTable.DefaultView.ToTable(True, col1)

            rblList.DataTextField = "SubAnsText"
            rblList.DataValueField = "SubAnsId"
            rblList.DataSource = dtSubans
            rblList.DataBind()
            ShowPnlAnsID.Value = dtSubans.Rows(0)("Ansid").ToString
            'If sender.SelectedValue = ShowPnlAnsID.Value Then
            pnlCSS.Attributes.Add("style", "display:block")
            'End If
        Else
            pnlCSS.Attributes.Add("style", "display:none")
        End If
    End Sub

    Protected Sub lnk_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Dim gvRow As GridViewRow = CType(CType(sender, Control).NamingContainer, GridViewRow)
        CSSID = GdSurvey.DataKeys(gvRow.RowIndex)("CSSID").ToString()
        GdSurvey.Visible = False
        'tblcomment.Visible = True
        btSave.Visible = True
        brtclose.Visible = True
        fillgrid()
        reptcss.Visible = True
        Dim db As New DBAccess
        SurveyStartTime = db.ReturnValue("select getdate()", False)
    End Sub

    Protected Sub btSave_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btSave.Click
        Dim strMsg As String
        Dim i As Integer = 1
        Dim counter As Integer = 1
        Dim str1 As String = "", str2 As String = ""
        strMsg = ""
        Dim optionflag = False, otherflag As Boolean = False
       
        For Each RepeaterItem As RepeaterItem In reptcss.Items
            Dim flag As Boolean = False
            Dim lbl As Label = RepeaterItem.FindControl("lblquestion")
            Dim cboAns As DropDownList = RepeaterItem.FindControl("cboanswer")
            Dim ShowPnlAnsID As HiddenField = RepeaterItem.FindControl("ShowPnlAnsID")
            Dim questionid As HiddenField = RepeaterItem.FindControl("questionid")
            Dim pnlcss As Panel = RepeaterItem.FindControl("pnlCSS")
            If cboAns.SelectedValue = -1 Then
                flag = True
                strMsg = strMsg + i.ToString + "." + lbl.Text & "<br>"
                i = i + 1
            End If
            If ShowPnlAnsID.Value = cboAns.SelectedValue Then 'questionid.Value & cboAns.SelectedValue Then
                pnlcss.Style.Add("display", "block")
            End If
            If cboAns.SelectedValue <> -1 Then
                If ShowPnlAnsID.Value = cboAns.SelectedValue Then
                    pnlcss.Style.Add("display", "block")
                    Dim rblList As RadioButtonList = RepeaterItem.FindControl("RdbListSubAns")
                    Dim comment As TextBox = RepeaterItem.FindControl("txtcomment")
                    If rblList.SelectedValue = "" Then
                        If optionflag = False Then
                            optionflag = True
                            str1 += counter.ToString & ","
                        Else
                            str1 += counter.ToString & ","
                        End If
                    ElseIf rblList.SelectedItem.Text.Trim = """Other"" Pl add your comments" Then
                        If comment.Text.Trim = "" Then
                            otherflag = True
                            str2 += counter.ToString & ","
                        End If
                    End If
                End If
            End If
            counter = counter + 1
        Next
        If str1.Length > 1 Then
            str1 = str1.Remove(str1.Length - 1)
        End If
        If str2.Length > 1 Then
            str2 = str2.Remove(str2.Length - 1)
        End If

        If optionflag Then
            AlertMessage("Please select an option for Question " & str1.ToString)
        ElseIf otherflag Then
            AlertMessage("Please add your comments for Question " & str2.ToString)
        Else
            If strMsg <> "" Then
                lblnotfilledquestion.Text = strMsg
                Dim str As String
                str = "$('#DialogBackground').height($(document).height()-10);$('#DialogBackground').width($(window).width());$('#DialogBackground').css('visibility','visible');$('#Pnlsurvey').css('visibility','visible');" & _
                " $('#Pnlsurvey').css('left',($(window).width() - $('#Pnlsurvey').width())/2); "
                ScriptManager.RegisterStartupScript(Page, Page.GetType(), "Movedialog", str, True)
            Else
                SaveSurvey()
            End If
        End If
    End Sub
    Private Sub SaveSurvey()
        Dim db As New DBAccess("CRM")
        Try
            Dim strMsg As String = ""
            Dim i As Integer = 1
            db.BeginTrans()
            db.slDataAdd("CssId", CSSID)
            db.slDataAdd("AgentId", AgentID)
            Dim LatestVal As Integer = db.ReturnValue("usp_CSSInsertSurveyMaster", True)
            Dim flag As Boolean = False
            For Each RepeaterItem As RepeaterItem In reptcss.Items
                Dim lblQuestion As Label = RepeaterItem.FindControl("lblquestion")
                Dim pnlcss As Panel = RepeaterItem.FindControl("pnlCSS")
                Dim cboAns As DropDownList = RepeaterItem.FindControl("cboanswer")
                Dim ShowPnlAnsID As HiddenField = RepeaterItem.FindControl("ShowPnlAnsID")
                Dim questionid As HiddenField = RepeaterItem.FindControl("questionid")
                If cboAns.SelectedValue <> -1 Then
                    db.slDataAdd("SurveyID", LatestVal)
                    db.slDataAdd("ParamID", questionid.Value)
                    db.slDataAdd("AnsID", cboAns.SelectedValue)
                    If ShowPnlAnsID.Value = cboAns.SelectedValue Then 'questionid.Value & cboAns.SelectedValue Then
                        pnlcss.Style.Add("display", "block")
                        Dim rblList As RadioButtonList = RepeaterItem.FindControl("RdbListSubAns")
                        If rblList.SelectedValue = "" Then
                            If flag = False Then
                                flag = True
                            End If
                        End If
                        Dim comment As TextBox = RepeaterItem.FindControl("txtcomment")
                        db.slDataAdd("SubAnsID", rblList.SelectedValue)
                        db.slDataAdd("SubComment", comment.Text)
                    End If
                    db.Executeproc("usp_CSSInsertSurveyData")
                End If
            Next
            If Not flag Then
                db.CommitTrans()
                Dim dbsurvey As New DBAccess("CRM")
                dbsurvey.slDataAdd("agentid", AgentID)
                dbsurvey.slDataAdd("CSSID", CSSID)
                dbsurvey.Executeproc("usp_CSSUpdateUserSurveyStatus")
                SendConfirmationMail()
                getAvailSurvey()
                SuccessMessage("<b>Survey Successfully Completed.</b><br /><b>Thank You for your valuable feedback.</b>")
            Else
                db.RollBackTrans()
                AlertMessage("Please Select an option or Other field is mandatory")
            End If
        Catch ex As Exception
            db.RollBackTrans()
            AlertMessage(ex.ToString)
        Finally
            db = Nothing
        End Try
    End Sub
    Protected Sub GdSurvey_RowDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles GdSurvey.RowDataBound
        If e.Row.RowType = DataControlRowType.DataRow Then
            Dim lblavlsurvey As Label = CType(e.Row.FindControl("lblavlsurvey"), Label)
            Dim lnksurvey As LinkButton = CType(e.Row.FindControl("lnksurvey"), LinkButton)
            If e.Row.Cells(4).Text = "Completed" Then
                lblavlsurvey.Visible = True
                lnksurvey.Visible = False
            Else
                lblavlsurvey.Visible = False
                lnksurvey.Visible = True
            End If
        End If
    End Sub
    Protected Sub brtclose_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles brtclose.Click
        reptcss.Visible = False
        GdSurvey.Visible = True
        btSave.Visible = False
        btnCancel.Visible = False
    End Sub
    Dim objWSMail As New ServiceReference1.Service1SoapClient
    Private Sub SendConfirmationMail()
        Dim Body, Subject As String
        Subject = "CSS Completed"
        Body = "CSS Completed by: " & Session("Username")
        'Dim objWSMail As New ShootMail.Mail
        Dim objWSMail As New ServiceReference1.Service1SoapClient

        Dim strTo As String = System.Configuration.ConfigurationManager.AppSettings("CSSTO")
        Dim strCC As String = ""
        Dim strBcc As String = System.Configuration.ConfigurationManager.AppSettings("CSSBCC")
        Dim strFrom As String = System.Configuration.ConfigurationManager.AppSettings("FROM")
        ' objWSMail.MailSend(strTo, Body, "", strCC, strBcc, strFrom, Subject)

        ' objWSMail.MailSendNewTech(strTo, Subject, strFrom, "TermsMonitor", Body, "", strCC, strBcc, "")
        objWSMail.MailSendNew(strTo, Subject, strFrom, "TermsMonitor", Body, "", strCC, strBcc, "") ''26Feb2018

        objWSMail = Nothing
    End Sub
#Region "Utility"

    Private Sub AlertMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMFail"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub

    Private Sub SuccessMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMSuccess"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub


#End Region

    Protected Sub btnOK_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnOK.Click
        SaveSurvey()
    End Sub

    Protected Sub imgfav_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles imgfav.Click
        Common.AddToFav(AgentID, "CSS")
        SuccessMessage("Survey link has been added to your favourite list")
        fillgrid()
    End Sub
End Class
