﻿Imports System.Data
Imports com.nss.DBAccess

Partial Class Staffing_MPR_TMreview
    Inherits System.Web.UI.Page
#Region "---- Properties ----"
    Property FormId() As String
        Get
            Return ViewState("FormId")
        End Get
        Set(ByVal value As String)
            ViewState("FormId") = value
        End Set
    End Property
    Property CampaignId() As Int16
        Get
            Return ViewState("CampaignId")
        End Get
        Set(ByVal value As Int16)
            ViewState("CampaignId") = value
        End Set
    End Property
    Property AgentCampaignId() As Int16
        Get
            Return ViewState("AgentCampaignId")
        End Get
        Set(ByVal value As Int16)
            ViewState("AgentCampaignId") = value
        End Set
    End Property
    Property ProcessId() As Int16
        Get
            Return ViewState("ProcessId")
        End Get
        Set(ByVal value As Int16)
            ViewState("ProcessId") = value
        End Set
    End Property
    Property AgentId() As String
        Get
            Return ViewState("AgentId")
        End Get
        Set(ByVal value As String)
            ViewState("AgentId") = value
        End Set
    End Property
    Property UserID() As String
        Get
            Return ViewState("UserID")
        End Get
        Set(ByVal value As String)
            ViewState("UserID") = value
        End Set
    End Property
    Property AckStatus() As Integer
        Get
            Return ViewState("AckStatus")
        End Get
        Set(ByVal value As Integer)
            ViewState("AckStatus") = value
        End Set
    End Property
    Property StartDate() As String
        Get
            Return ViewState("startdate")
        End Get
        Set(ByVal value As String)
            ViewState("startdate") = value
        End Set
    End Property
    Property EndDate() As String
        Get
            Return ViewState("enddate")
        End Get
        Set(ByVal value As String)
            ViewState("enddate") = value
        End Set
    End Property
    Property AgentRole() As Integer
        Get
            Return ViewState("AgentRole")
        End Get
        Set(ByVal value As Integer)
            ViewState("AgentRole") = value
        End Set
    End Property
    Property Month() As String
        Get
            Return ViewState("Month")
        End Get
        Set(ByVal value As String)
            ViewState("Month") = value
        End Set
    End Property
    Property Year() As String
        Get
            Return ViewState("Year")
        End Get
        Set(ByVal value As String)
            ViewState("Year") = value
        End Set
    End Property

    Property ModeOfFeedback() As Integer
        Get
            Return ViewState("ModeOfFeedback")
        End Get
        Set(ByVal value As Integer)
            ViewState("ModeOfFeedback") = value
        End Set
    End Property

#End Region
#Region "---- Load ---- "
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        HumanMessage.Style.Item("visibility") = "hidden"
        If Not IsPostBack Then
            If Request.QueryString("page") = 2 Then
                QueryStringTMDashboard()
                UserID = Session("AgentId")
            Else
                UserID = Session("AgentId")
                AgentId = Session("AgentId")
                CampaignId = Session("Campaignid")
                GetCurrentDate()
                Month = lblMonth.Text
                Year = Convert.ToInt32(lblyear.Text)
            End If
            GetAgentDetail()
            GetPreviousFillData()
            'BindCommonKPA()
            txtTMComments.Focus()
            lblName.Text = Session("AgentName")
        End If
    End Sub
#End Region
#Region "--- Event ----"
    Protected Sub btnSave_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnSave.Click
        AgentAcknowledgement()
    End Sub
    Protected Sub btnCancel_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnCancel.Click
        Response.Redirect("TMDashboard.aspx")
    End Sub
#End Region
#Region "---- Funcations ----"
    Private Sub QueryStringTMDashboard()
        ProcessId = Request.QueryString("ProcessId")
        CampaignId = Request.QueryString("Campaignid")
        Month = Request.QueryString("Month")
        Year = Request.QueryString("Year")
        AgentId = Request.QueryString("AgentId")
        lblMonth.Text = Month
        lblyear.Text = Year
        If Request.QueryString("St") = 3 Then
            txtTMComments.Enabled = False
        Else
            txtTMComments.Enabled = True
        End If
    End Sub
    Private Sub GetCurrentDate()
        Dim db As New DBAccess("CRM")
        Dim currentdatetime As DateTime = db.ReturnValue("select getdate()", False)
        db = Nothing
        lblMonth.Text = currentdatetime.AddMonths(-1).ToString("MMMM")
        lblyear.Text = currentdatetime.AddMonths(-1).Year.ToString
        Dim startdt As DateTime = DateTime.Parse(currentdatetime.AddMonths(-1).Year.ToString & "-" & currentdatetime.AddMonths(-1).ToString("MMM") & "-" & "01")
        Dim enddt As DateTime = startdt.AddMonths(1).AddDays(-1)
        StartDate = startdt.ToString("yyyyMMdd")
        EndDate = enddt.ToString("yyyyMMdd")
    End Sub
    Protected Sub GetAgentDetail()
        Dim db As New DBAccess("report")
        Dim dt As New DataTable
        db.slDataAdd("Agentid", AgentId)
        dt = db.ReturnTable("usp_GetAgentDetails", "", True)
        If dt.Rows.Count > 0 Then
            lblAgentId.Text = dt.Rows(0)("AgentID")
            lblAgentName.Text = dt.Rows(0)("AgentName")
            lblSupId.Text = dt.Rows(0)("SupervisorID")
            lblSupName.Text = dt.Rows(0)("SupervisorName")
            lblProcess.Text = dt.Rows(0)("ProcessName")
            dt = Nothing
        End If
    End Sub
    Protected Sub BindKPA()
        gvMPR.BackImageUrl = ""
        gvMPR.Enabled = True
        Dim db As New DBAccess("CRM")
        Dim dt As New DataTable
        db.slDataAdd("Agentid", AgentId)
        db.slDataAdd("AgentRole", AgentRole)
        db.slDataAdd("processid", ProcessId)
        db.slDataAdd("campaignid", CampaignId)
        db.slDataAdd("UserId", UserID)
        db.slDataAdd("Month", lblMonth.Text.Trim)
        db.slDataAdd("year", Convert.ToInt32(lblyear.Text.Trim))
        db.slDataAdd("AgentCampaignid", AgentCampaignId)
        dt = db.ReturnTable("usp_getKPA", , True)
        db = Nothing
        If dt.Rows.Count > 0 Then
            gvMPR.DataSource = dt
            gvMPR.DataBind()
        Else
            gvMPR.DataSource = Nothing
            gvMPR.DataBind()
            txtAchievSumary.Text = ""
            txtRptMgrCmnts.Text = ""
        End If
        dt = Nothing
    End Sub
    'Private Sub BindCommonKPA()
    '    Dim db As New DBAccess("CRM")
    '    Dim dt As DataTable
    '    db.slDataAdd("AgentId", AgentId)
    '    db.slDataAdd("processid", ProcessId)
    '    db.slDataAdd("campaignid", CampaignId)
    '    db.slDataAdd("Month", lblMonth.Text.Trim)
    '    db.slDataAdd("year", Convert.ToInt32(lblyear.Text.Trim))
    '    dt = db.ReturnTable("usp_GetCommonKPA", , True)
    '    db = Nothing
    '    gvCommonKPA.DataSource = dt
    '    gvCommonKPA.DataBind()
    'End Sub
    Protected Sub GetPreviousFillData()
        Dim db As New DBAccess("CRM")
        Dim dt As New DataTable
        Dim strQuery As String = "Select * from tbl_Data_MPR_FormMaster where Agentid='" & AgentId & "' and Period='" & lblMonth.Text & "' and [year]=" & lblyear.Text & ""
        dt = db.ReturnTable(strQuery, False)
        If dt.Rows.Count > 0 Then
            txtAchievSumary.Text = dt.Rows(0)("AchievementSummary").ToString
            txtRptMgrCmnts.Text = dt.Rows(0)("RepMgrComments").ToString
            txtTMComments.Text = dt.Rows(0)("TMComment").ToString
            ProcessId = dt.Rows(0)("ProcessId").ToString
            AckStatus = dt.Rows(0)("AcknowledgmentStatus").ToString
            AgentRole = dt.Rows(0).Item("AgentRole")
            ModeOfFeedback = IIf(IsDBNull(dt.Rows(0).Item("ModeOfFeedback")), 0, dt.Rows(0).Item("ModeOfFeedback"))
        Else
            AckStatus = 0
            ModeOfFeedback = 0
        End If
        dt = Nothing
        db = Nothing

        Dim dbData As New DBAccess("CRM")
        Dim dtfrmData As New DataTable
        dbData.slDataAdd("Agentid", AgentId)
        dbData.slDataAdd("AgentRole", AgentRole)
        dbData.slDataAdd("processid", ProcessId)
        dbData.slDataAdd("UserId", UserID)
        dbData.slDataAdd("Month", Month)
        dbData.slDataAdd("year", Convert.ToInt32(Year))
        dtfrmData = dbData.ReturnTable("usp_getKPA", , True)
        dbData = Nothing
        If dtfrmData.Rows.Count > 0 Then
            gvMPR.DataSource = dtfrmData
            gvMPR.DataBind()
        Else
            gvMPR.DataSource = Nothing
            gvMPR.DataBind()
            'txtAchievSumary.Text = ""
            'txtRptMgrCmnts.Text = ""
        End If
        If AckStatus = 1 Then
            rdoTmreview.SelectedValue = 1
            LblMarkedorNot.Text = "Accepted"
            ImgMarkedorNot.ImageUrl = "~/_assets/img/yes.gif"
            btnSave.Enabled = False
            ' btnCancel.Enabled = False
            rdoTmreview.Enabled = False
        ElseIf AckStatus = 2 Then
            rdoTmreview.SelectedValue = 2
            LblMarkedorNot.Text = "Rejected"
            ImgMarkedorNot.ImageUrl = "~/_assets/img/remove.gif"
            btnSave.Enabled = False
            'btnCancel.Enabled = False
            rdoTmreview.Enabled = False
        Else
            LblMarkedorNot.Text = "Pending"
            ImgMarkedorNot.ImageUrl = "~/_assets/img/why.gif"
            btnSave.Enabled = True
            'btnCancel.Enabled = True
            rdoTmreview.Enabled = True
        End If


        ''''----------For feedback
        If ModeOfFeedback = 1 Then
            rdlistFeedback.SelectedValue = 1
            rdlistFeedback.Enabled = False
        ElseIf ModeOfFeedback = 2 Then
            rdlistFeedback.SelectedValue = 2
            rdlistFeedback.Enabled = False
        ElseIf ModeOfFeedback = 3 Then
            rdlistFeedback.SelectedValue = 3
            rdlistFeedback.Enabled = False
        Else
            rdlistFeedback.Enabled = True
        End If

    End Sub
    Private Sub AgentAcknowledgement()
        Try
            Dim db As New DBAccess("CRM")
            Dim Accept As String
            If rdoTmreview.SelectedValue = "1" Then
                Accept = 1
            ElseIf rdoTmreview.SelectedValue = "2" Then
                If txtTMComments.Text.Trim = "" Then
                    AlertMessage("Please fill the Comment section")
                    Return
                    txtTMComments.Focus()
                End If
                Accept = 2
            Else
                AlertMessage("Please Select Option First")
                Return
            End If

            '-------------------------For feedback
            If rdlistFeedback.SelectedValue = "" Then
                AlertMessage("Please select Mode of Feedback option.")
                Return
            End If
            '----------------------------------------------

            db.slDataAdd("AckStatus", Accept)
            db.slDataAdd("TMComment", txtTMComments.Text.Trim)
            db.slDataAdd("AgentId", AgentId)
            db.slDataAdd("Period", lblMonth.Text.Trim)
            db.slDataAdd("Year", lblyear.Text.Trim)
            db.slDataAdd("ModeOfFeedback", rdlistFeedback.SelectedValue)
            db.Executeproc("usp_MPR_AgentAcknowledgement")
            'db.UpdateinTable("tbl_Data_MPR_FormMaster", "Agentid='" + AgentId + "' and Period='" + lblMonth.Text.Trim + "' and [year]=" + lblyear.Text.Trim + "")
            db = Nothing
            Response.Redirect("TMDashboard.aspx")
            'GetPreviousFillData()
        Catch ex As Exception
            AlertMessage(ex.ToString)
        End Try
    End Sub
#End Region
#Region "---- Grid Ops ----"
    'Protected Sub gvCommonKPA_RowDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles gvCommonKPA.RowDataBound
    '    If e.Row.RowType = DataControlRowType.DataRow Then
    '        Dim rating As String = gvCommonKPA.DataKeys(e.Row.RowIndex).Item("Achievement").ToString
    '        CType(e.Row.FindControl("txtRemarks"), TextBox).Text = gvCommonKPA.DataKeys(e.Row.RowIndex).Item("Remarks").ToString
    '        If rating = "1" Then
    '            CType(e.Row.FindControl("rdbcm1"), RadioButton).Checked = True
    '        ElseIf rating = "2" Then
    '            CType(e.Row.FindControl("rdbcm2"), RadioButton).Checked = True
    '        ElseIf rating = "3" Then
    '            CType(e.Row.FindControl("rdbcm3"), RadioButton).Checked = True
    '        ElseIf rating = "4" Then
    '            CType(e.Row.FindControl("rdbcm4"), RadioButton).Checked = True
    '        End If
    '    End If
    'End Sub
#End Region
#Region "---- Utility ----"
    Private Sub AlertMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMFail"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub
    Private Sub SuccessMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMSuccess"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub
    Public Overrides Sub VerifyRenderingInServerForm(ByVal Control As Control)
    End Sub
#End Region

End Class
