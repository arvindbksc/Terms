﻿using System;
using System.Data;
using System.Linq;
using System.Web;
using Microsoft.VisualBasic;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using com.nss.DBAccess;
using System.Data.SqlClient;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Web.Services;
using System.Windows.Forms;
using System.Text;

public partial class CMF_CMF_UserBasedMapping : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            //Displaying the Data  
            showData();
            LblTotalCount.Visible = false;
            GetCMFSearchBy();
            //Adding an Attribute to Server Control(i.e. btnDeleteRecord)  
            btnDelete.Attributes.Add("onclick", "javascript:return DeleteConfirm()");
        }
      
    }

    //Method for Displaying Data  
    protected void showData()
    {
        DataTable dt = new DataTable();
        DBAccess db = new DBAccess("CRM");
        try
        {
            db.slDataAdd("Type", "SELECT");
            dt = db.ReturnTable("CMF_INSERT_MAPPING", "", true);
            db = null;
            gdData.DataSource = dt;
            LblTotalCount.Visible = true; ;
            LblTotalCount.Text = "Total Records :"+dt.Rows.Count.ToString();
            gdData.DataBind();
            gdData.Visible = true;
            
        }

        catch (Exception Ex)
        { }
        
    }
    //Method for Deleting Record  
    protected void DeleteRecord(string ID)
    {
        DBAccess db = new DBAccess("CRM");
        DataTable dt = default(DataTable);
        try
        {


            db.slDataAdd("ID", ID);
            db.slDataAdd("Type", "DELETE");
            dt = db.ReturnTable("CMF_INSERT_MAPPING", "", true);
            db = null;
            if ((dt != null))
            {
                switch ((dt.Rows[0]["MESSAGE_TYPE"].ToString()))
                {
                    case "S":
                        SuccessMessage(dt.Rows[0]["MESSAGE"].ToString());
                        break;

                    case "E":
                        AlertMessage(dt.Rows[0]["MESSAGE"].ToString());
                        break;
                }
            }
            //showData();
        }
        catch (Exception ex)
        {
            SuccessMessage(ex.ToString());
        }
    }

    protected void btnDelete_Click(object sender, EventArgs e)
    {
        
        foreach (GridViewRow grow in gdData.Rows)
        {
            //Searching CheckBox("chkDel") in an individual row of Grid  
            System.Web.UI.WebControls.CheckBox chkInsert = (System.Web.UI.WebControls.CheckBox)grow.FindControl("chkRow");
            //System.Web.UI.WebControls.TextBox TxtQuestionScore = (System.Web.UI.WebControls.TextBox)grow.FindControl("TxtQS");
            System.Web.UI.WebControls.HiddenField QID = (System.Web.UI.WebControls.HiddenField)grow.FindControl("hdnID");
            //System.Web.UI.WebControls.TextBox TxtQuestionSeq = (System.Web.UI.WebControls.TextBox)grow.FindControl("TxtQseq");
            //If CheckBox is checked than delete the record with particular empid  
            if (chkInsert.Checked)
            {
                string ID = (QID.Value.ToString());
                  DeleteRecord(ID);
            }
        }

        //Displaying the Data in GridView  
        showData();
        ddlSearchBy.SelectedIndex = 0;
    }
    protected void OnPageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        gdData.PageIndex = e.NewPageIndex;
        gdData.DataBind();
        showData();
    }
    protected void ddlSearchBy_SelectedIndexChanged(object sender, EventArgs e)
    {
        BindSearchByGrid();
    }
    /// <summary>
    /// Bind grid according to the select
    /// </summary>
    private void BindSearchByGrid()
    {
        DBAccess db = new DBAccess("CRM");
        DataTable dt = default(DataTable);
        try
        {
            db.slDataAdd("ID", ddlSearchBy.SelectedValue);
            db.slDataAdd("Type", "CMFSELECTSEARCHBY");
            dt = db.ReturnTable("CMF_INSERT_MAPPING", "", true);
            db = null;
            gdData.DataSource = dt;
            gdData.DataBind();
            if (dt.Rows.Count < 0)
            {
                AlertMessage("Record Not Found");
            }

        }
        catch (Exception ex)
        {
            //AlertMessage(ex.ToString);
        }



    }
    private void GetCMFSearchBy()
    {
        DBAccess db = new DBAccess("CRM");
        DataTable dt = default(DataTable);
        try
        {

            //db.slDataAdd("ID", "");
            //db.slDataAdd("CategoryName", "");
            db.slDataAdd("Type", "CMFSELECT");
            dt = db.ReturnTable("CMF_INSERT_MAPPING", "", true);
            db = null;
            db = null;
            ddlSearchBy.DataTextField = "VALUES";
            ddlSearchBy.DataValueField = "ID";
            ddlSearchBy.DataSource = dt;
            ddlSearchBy.DataBind();
            ddlSearchBy.Items.Insert(0, new ListItem("--select--", "0"));
            ddlSearchBy.SelectedIndex = 0;

        }

        catch (Exception ex)
        {
            //AlertMessage(ex.ToString);
        }
    }
    #region "--- Utility ---"
    private void AlertMessage(string msg)
    {
        lblHumanMessage.Text = msg;
        HumanMessage.CssClass = "HMFail";
        HumanMessage.Visible = true;
        lblHumanMessage.Visible = true;
        HumanMessage.Style["visibility"] = "visible";

    }
    private void SuccessMessage(string msg)
    {
        lblHumanMessage.Text = msg;
        HumanMessage.CssClass = "HMSuccess";
        HumanMessage.Visible = true;
        lblHumanMessage.Visible = true;
        HumanMessage.Style["visibility"] = "visible";


    }

    protected void HumanMsgbtn_Click(object sender, EventArgs e)
    {

        HumanMessage.Visible = false;
        lblHumanMessage.Text = "";
        HumanMessage.Style["visibility"] = "";

    }




    #endregion

}