﻿using Microsoft.VisualBasic;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using com.nss.DBAccess;
using System.Data.SqlClient;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Web.Services;




public partial class CMF_CMF_SubcategoryMaster : System.Web.UI.Page
{
    #region "----Property Declaration-------"


    public string UserID
    {
        get { return ViewState["UserID"].ToString(); }
        set { ViewState["UserID"] = value; }
    }
    public string AgentID
    {
        get { return ViewState["AgentID"].ToString(); }
        set { ViewState["AgentID"] = value; }
    }
    public string UserName
    {
        get { return ViewState["username"].ToString(); }
        set { ViewState["username"] = value; }
    }

    #endregion

    protected void Page_Load(object sender, EventArgs e)
    {

        HumanMessage.Style["visibility"] = "hidden";
        HumanMessage.Visible = false;
        if (!this.IsPostBack)
        {
            this.GetSubCategory();
            GetSubCategorySearchBy();
            lblReportName.CurrentPage = "SubCategory Master";
        }

        
     
        

    }

    #region "--- Functions ---"

    private void GetSubCategory()
    {
        DBAccess db = new DBAccess("CRM");
        DataTable dt = default(DataTable);
        try
        {
            
            db.slDataAdd("ID", "");
            db.slDataAdd("SubCategoryName", "");
            db.slDataAdd("Type", "SELECT");
            dt = db.ReturnTable("CMF_GET_SubCategoryMaster", "", true);
            db = null;
            gdData.DataSource = dt;
            gdData.DataBind();
            if (dt.Rows.Count > 0)
            {
               
                btnAddFirst.Visible = false;
            }
            else
            {
                btnAddFirst.Visible = true;
            }

        }
        catch (Exception ex)
        {
            //AlertMessage(ex.ToString);
        }
    }


    /// <summary>
    /// Bind the Subcategory dropdown
    /// </summary>
    private void GetSubCategorySearchBy()
    {
        DBAccess db = new DBAccess("CRM");
        DataTable dt = default(DataTable);
        try
        {

            db.slDataAdd("ID", "");
            db.slDataAdd("SubCategoryName", "");
            db.slDataAdd("Type", "SELECT");
            dt = db.ReturnTable("CMF_GET_SubCategoryMaster", "", true);
            db = null;
            db = null;
            ddlSearchBy.DataTextField = "SubCategoryName";
            ddlSearchBy.DataValueField = "SubCategoryID";
            ddlSearchBy.DataSource = dt;
            ddlSearchBy.DataBind();
            ddlSearchBy.Items.Insert(0, new ListItem("--select--", "0"));
            ddlSearchBy.SelectedIndex = 0;

        }

        catch (Exception ex)
        {
            //AlertMessage(ex.ToString);
        }
    }
    /// <summary>
    /// Bind grid according to the select
    /// </summary>
    private void BindCategorySearchByGrid()
    {
        DBAccess db = new DBAccess("CRM");
        DataTable dt = default(DataTable);
        try
        {
            db.slDataAdd("ID", ddlSearchBy.SelectedValue);
            db.slDataAdd("SubCategoryName", "");
            db.slDataAdd("Type", "SEARCHBY");
            dt = db.ReturnTable("CMF_GET_SubCategoryMaster", "", true);
            db = null;
            gdData.DataSource = dt;
            gdData.DataBind();
            if (dt.Rows.Count < 0)
            {
                AlertMessage("Record Not Found");
            }

        }
        catch (Exception ex)
        {
            //AlertMessage(ex.ToString);
        }



    }

    /// <summary>
    /// POPUP DISPLAY
    /// </summary>
    public void OpenDialog()
    {

        try
        {
            string str = null;
            str = "$('#DialogBackground').height($(document).height()-5);$('#DialogBackground').width($(window).width());$('#DialogBackground').css('visibility','visible');$('#PanelIDPForm').css('visibility','visible');" + " $('#PanelIDPForm').css('left',($(window).width() - $('#PanelIDPForm').width())/2); ";
           // ClientScript.RegisterStartupScript(Page.GetType(), "script", str, true);
            ScriptManager.RegisterClientScriptBlock(Page, typeof(System.Web.UI.Page), "redirect", str, true);
        }
        catch (Exception ex)
        { }

    }
    /// <summary>
    /// Save SUBCATEGORY
    /// </summary>
    /// <param name="CategoryName"></param>
    /// <param name="Type"></param>
    /// <param name="Id"></param>
    public void SaveSubCategory(string SubCategoryName, string Type, int Id)
    {
        try
        {
            DBAccess db = new DBAccess("CRM");
            DataTable dt = default(DataTable);
            db.slDataAdd("SubCategoryName", SubCategoryName);
            db.slDataAdd("ID", Id);
            db.slDataAdd("Type", Type);
            dt = db.ReturnTable("CMF_GET_SubCategoryMaster", "", true);
            db = null;
            if ((dt != null))
            {
                switch ((dt.Rows[0]["MESSAGE_TYPE"].ToString()))
                {
                    case "S":
                        SuccessMessage(dt.Rows[0]["MESSAGE"].ToString());
                        break;

                    case "E":
                        AlertMessage(dt.Rows[0]["MESSAGE"].ToString());
                        break;
                }
            }
        }
        catch (Exception ex)
        {
            SuccessMessage(ex.ToString());
        }
    }


    #endregion

    #region "--- Events ---"



    protected void btnSave_Click(object sender, EventArgs e)
    {

        string SubCatName = null;
        string type = "";
        SubCatName = TxtSubcat.Text;
        try
        {
            if ((btnSave.Text == "save"))
            {
                type = "INSERT";
                SaveSubCategory(SubCatName, type, 0);
            }


            GetSubCategory();
        }
        catch (Exception Ex)
        { }

    }


    protected void gdData_RowCommand(object sender, System.Web.UI.WebControls.GridViewCommandEventArgs e)
    {
        if ((e.CommandName == "AddToCart"))
        {
            int index = Convert.ToInt32(e.CommandArgument);
            GridViewRow row = gdData.Rows[index];
        }

        if (e.CommandName.ToLower() == "addnew")
        {
        }

    }


    protected void AddNew_Click(object sender, EventArgs e)
    {
        try
        {
            string txtSubcat = "";
            //string HdncaID = "";
            GridViewRow gvRow = (GridViewRow)((System.Web.UI.Control)sender).Parent.Parent;
            int index = gvRow.RowIndex;
            txtSubcat = (gvRow.FindControl("TxtSubCatFooter2") as System.Web.UI.WebControls.TextBox).Text;
            //HdncaID = (gvRow.FindControl("hdnID") as System.Web.UI.WebControls.HiddenField).Value;
            //categoryID = (gvRow.FindControl("lblRowNumber") as System.Web.UI.WebControls.Label).Text;
            //if (categoryID.ToString() != null)
            //{ SaveCategory(txtcat, "INSERT", null); }
            //else
            //{ SaveCategory(txtcat, "INSERT", 0,txtcat); }

            SaveSubCategory(txtSubcat, "INSERT", 0);
            GetSubCategory();
        }
        catch (Exception ex)
        { }



    }


    protected void gdData_RowEditing(object sender, GridViewEditEventArgs e)
    {
        btnSave.Text = "Update";
        int index = Convert.ToInt32(e.NewEditIndex);
        hdnPanelRoleprocessMapid.Value = ((System.Web.UI.WebControls.HiddenField)gdData.Rows[index].FindControl("hdnID")).Value;
        OpenDialog();
    }



    protected void OnPageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        gdData.PageIndex = e.NewPageIndex;
        gdData.DataBind();
        GetSubCategory();
    }

    protected void btnaddfirst_click(object sender, EventArgs e)
    {
        btnSave.Text = "save";
        OpenDialog();

    }

    #endregion


    #region "--- Utility ---"
    private void AlertMessage(string msg)
    {
        lblHumanMessage.Text = msg;
        HumanMessage.CssClass = "HMFail";
        HumanMessage.Visible = true;
        lblHumanMessage.Visible = true;
        HumanMessage.Style["visibility"] = "visible";
        // HumanMessage.Style.Item("visibility") = "visible";

    }
    private void SuccessMessage(string msg)
    {
        lblHumanMessage.Text = msg;
        HumanMessage.CssClass = "HMSuccess";
        HumanMessage.Visible = true;
        lblHumanMessage.Visible = true;
        HumanMessage.Style["visibility"] = "visible";
        //HumanMessage.Item["visibility"].tostring() = "visible";

    }

    protected void HumanMsgbtn_Click(object sender, EventArgs e)
    {
        // HumanMessage.Style["visibility"].ToString() = "";
        HumanMessage.Visible = false;
        lblHumanMessage.Text = "";
        HumanMessage.Style["visibility"] = "";

    }

    #endregion
    protected void ddlSearchBy_SelectedIndexChanged(object sender, EventArgs e)
    {
        BindCategorySearchByGrid();
    }
}