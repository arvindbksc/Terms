﻿using System;
using System.Data;
using System.Linq;
using System.Web;
using Microsoft.VisualBasic;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using com.nss.DBAccess;
using System.Data.SqlClient;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Web.Services;
using System.Windows.Forms;
using System.Text;
public partial class CMF_CMF_Mapping : System.Web.UI.Page
{
    SqlDataAdapter da;  
    DataSet ds = new DataSet();  
    StringBuilder htmlTable = new StringBuilder();
    System.Web.UI.WebControls.CheckBox chkInsert;
    System.Web.UI.WebControls.TextBox TxtQuestionScore;
    System.Web.UI.WebControls.HiddenField QID;
    System.Web.UI.WebControls.TextBox TxtQuestionSeq;
    
  
    #region "----Property Declaration-------"

    public string UserID { get; set; }
    public string AgentID { get; set; }
    public string UserName { get; set; }
    public DataTable Dtcampaign { get; set; }
    public DataTable Dtcat { get; set; }
    public DataTable DtSubcat { get; set; }
    public DataTable DataTableNew { get; set; }
    public int ProcessID { get; set; }
    static string Question { get; set; }


    #endregion
    #region "--- Functions ---"

    private bool IsInputNumeric(string input)
    {
        //If String.IsNullOrWhiteSpace(input) Then Return False

        //if (IsNumeric(input))
        //    return true;
        //string[] parts = input.Split('/');
        //if (parts.Length != 2)
        //    return false;
        //return IsNumeric(parts(0)) && IsNumeric(parts(1));

        int i; bool Result=false;
        if (!int.TryParse(input, out i))
        {
            Result = true;
        }
        return Result;
        
    }
    private string GETMAXCMFID()
    {
        string Cmfid = null;
        DBAccess db = new DBAccess("CRM");
        db.slDataAdd("Type", "MAXCMF_MAP");
        DataTable DT = db.ReturnTable("CMF_INSERT_MAPPING", "", true);
        Cmfid = DT.Rows[0][0].ToString();
        return Cmfid;


    }
    protected void OnPageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        gdData.PageIndex = e.NewPageIndex;
        gdData.DataBind();
        //GetQuestion();
    }

    protected void AddNew1_Click(object sender, EventArgs e)
    {
        try
        {
            //Reset();
            string txtCMFID = "";
            string txtCMFIDText = "";
            string DdlCampaign = "";

            GridViewRow gvRow = (GridViewRow)((System.Web.UI.Control)sender).Parent.Parent;
            //int index = gvRow.RowIndex;
            txtCMFID = (gvRow.FindControl("TxtCMFIDFooter1") as System.Web.UI.WebControls.TextBox).Text;
            txtCMFIDText = (gvRow.FindControl("TxtCMFTextFooter1") as System.Web.UI.WebControls.TextBox).Text;
            DdlCampaign = (gvRow.FindControl("DdlCampaigntFooter1") as System.Web.UI.WebControls.DropDownList).SelectedValue;
            if (DdlCampaign == "0")
            {
                // AlertMessageCamp("Message: Please select Campaign.");
                return;
            }
            if (txtCMFIDText == "")
            {
                //AlertMessageCamp("Message: Please enter CMF Name.");
                return;
            }
            SaveCampaignCMF(txtCMFID, "INSERT", DdlCampaign, txtCMFIDText);
            //GetCampaignCMF();


        }

        catch (Exception ex)
        { }
    }


    protected void btnAddFirst_Click(object sender, EventArgs e)
    {

    }




    /// <summary>
    /// Save CAMPAIGNCMFID
    /// </summary>
    /// <param name="CategoryName"></param>
    /// <param name="Type"></param>
    /// <param name="Id"></param>
    public void SaveCampaignCMF(string CMFID, string Type, string CampaignID, string campaignText)
    {
        try
        {
            DBAccess db = new DBAccess("CRM");
            DataTable dt = default(DataTable);
            db.slDataAdd("CategoryName", CampaignID);
            db.slDataAdd("paramID", "");
            db.slDataAdd("SubCategoryName", "");
            db.slDataAdd("ProcessID", "");
            db.slDataAdd("CMFTEXT", campaignText);
            db.slDataAdd("ID", CMFID);
            db.slDataAdd("Type", Type);
            dt = db.ReturnTable("CMF_GET_CMFCampaign_Mapping", "", true);
            db = null;
            if ((dt != null))
            {
                switch ((dt.Rows[0]["MESSAGE_TYPE"].ToString()))
                {
                    case "S":
                        SuccessMessage(dt.Rows[0]["MESSAGE"].ToString());
                        break;

                    case "E":
                        AlertMessage(dt.Rows[0]["MESSAGE"].ToString());
                        break;
                }
            }
        }
        catch (Exception ex)
        {
            SuccessMessage(ex.ToString());
        }
    }
    #endregion
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {

            this.PopulateQuestion();
            PopulateCategory();
            PopulateSubCategory();
            TxtCmfID.Text = GETMAXCMFID();
            GridQuestion.Visible = false;

        }
    }
    /// <summary>
    /// Function to get max CMF ID
    /// </summary>
    /// <param name="DT"></param>
    /// <returns></returns>
 
    private void PopulateQuestion()
    {

        DBAccess db = new DBAccess("CRM");
        DataTable dt = default(DataTable);
        try
        {

            db.slDataAdd("ID", "");
            db.slDataAdd("QuestionText", "");
            db.slDataAdd("Type", "SELECT");
            db.slDataAdd("QuestionType", "");
            dt = db.ReturnTable("CMF_GET_QuestionMaster", "", true);
            db = null;
            lstQuestion.DataSource = dt;
            lstQuestion.DataTextField = "ParmText";
            lstQuestion.DataValueField = "ParamID";
            lstQuestion.DataBind();
            //lstQuestion.Items.Add(new ListItem("Select All", "0"));
          
           // ListItem item = new ListItem();
          
            //while (dt.Rows.Count > 0)
            //{
            //    item.Text = dt.Columns["ParmText"].ToString();
            //    item.Value = dt.Columns["ParamID"].ToString();
            //    //item.Selected = Convert.ToBoolean(sdr["IsSelected"]);
            //    lstQuestion.Items.Add(item);
            //}
           
                //item.Text = dt.Columns["ParmText"].ToString();
                //item.Value = dt.Columns["ParamID"].ToString();
                //item.Selected = Convert.ToBoolean(sdr["IsSelected"]);
               
           
            //lstQuestion.Items.Add();
           
        }

        catch (Exception ex)
        {

        }
    }

    private void PopulateCategory()
    {
        DBAccess db = new DBAccess("CRM");
        DataTable dt = default(DataTable);
        try
        {

            db.slDataAdd("ID", "");
            db.slDataAdd("CategoryName", "");
            db.slDataAdd("Type", "SELECT");
            dt = db.ReturnTable("CMF_GET_CategoryMaster", "", true);
            db = null;
            ddlCat.DataTextField = "CategoryName";
            ddlCat.DataValueField = "CategoryID";
            ddlCat.DataSource = dt;
            ddlCat.DataBind();
            ddlCat.Items.Insert(0, new ListItem("--select--", "0"));
            ddlCat.SelectedIndex = 0;
        }
        catch (Exception ex)
        { }
    }

    private void PopulateSubCategory()
    {
        DBAccess db = new DBAccess("CRM");
        DataTable dt = default(DataTable);
        try
        {

            db.slDataAdd("ID", "");
            db.slDataAdd("SubCategoryName", "");
            db.slDataAdd("Type", "SELECT");
            dt = db.ReturnTable("CMF_GET_SubCategoryMaster", "", true);
            db = null;
            ddlSubCat.DataTextField = "SubCategoryName";
            ddlSubCat.DataValueField = "SubCategoryID";
            ddlSubCat.DataSource = dt;
            ddlSubCat.DataBind();
            ddlSubCat.Items.Insert(0, new ListItem("--select--", "0"));
            ddlSubCat.SelectedIndex = 0;

        }

        catch (Exception ex)
        {
            //AlertMessage(ex.ToString);
        }
    }



    protected void BtnCreateTable(object sender, EventArgs e)
    {
      
        //string message = "";
        DataTable dt = new DataTable();
        dt.Columns.AddRange(
           new DataColumn[4] { new DataColumn("Id", typeof(int)),
           new DataColumn("Question", typeof(string)),
           new DataColumn("QuestionSequence",typeof(string)),
           new DataColumn("QuestionScore",typeof(string)),
        });


        foreach (ListItem item in lstQuestion.Items)
        {
            if (item.Selected)
            {
                //message += item.Text + " " + item.Value + "\\n";
                dt.Rows.Add(item.Value, item.Text, "", "");
            }
        }
        ViewState["DataTableNew"] = dt;
        GridQuestion.DataSource = dt;
        GridQuestion.DataBind();
        GridQuestion.Visible = true;
        gdData.Visible = false;
        btnSubmit.Visible = true;
       // ClientScript.RegisterClientScriptBlock(this.GetType(), "alert", "alert('" + message + "');", true);

        

        }


    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        //validate
          int flag = 0; int counter = 0;
         
      
        foreach (GridViewRow grow in GridQuestion.Rows)
        {
            //Searching CheckBox("chkDel") in an individual row of Grid  
            chkInsert = (System.Web.UI.WebControls.CheckBox)grow.FindControl("chkRow");
            TxtQuestionScore = (System.Web.UI.WebControls.TextBox)grow.FindControl("TxtQS");
            QID = (System.Web.UI.WebControls.HiddenField)grow.FindControl("hdnID");
            TxtQuestionSeq = (System.Web.UI.WebControls.TextBox)grow.FindControl("TxtQseq");

          
            //If CheckBox is checked than Insert the record with particular empid  
            if (chkInsert.Checked)
            {
                counter = counter + 1;
                if (TxtQuestionScore.Text.ToString() == "")
                {
                    flag = 1;
                    //lblIsValidInput.Text = "Please Enter Option Text ";
                    AlertMessage("Please Enter Question Score");
                    //return;
                }

                else if (IsInputNumeric(TxtQuestionScore.Text.ToString()) == true)
                {
                  
                    flag = 1;
                    AlertMessage("Please Enter Numeric Fields only");
                    //lblIsValidInput.Visible = true;
                    //lblIsValidInput.Text = "Please Enter Numeric Fields only";
                    //return;
                }
                else if (TxtQuestionSeq.Text.ToString() == "")
                {
                    flag = 1;
                    //lblIsValidInput.Text = "Please Enter Option Text ";
                    AlertMessage("Please Enter Question Sequence");
                    //return;
                }
                else if (IsInputNumeric(TxtQuestionSeq.Text.ToString()) == true)
                {
                    
                    flag = 1;
                    AlertMessage("Please Enter Numeric Fields only");
                    //lblIsValidInput.Visible = true;
                    //lblIsValidInput.Text = "Please Enter Numeric Fields only";
                    //return;
                } 
               
            
            }
        }
        if (counter > 0)
        {
            if (flag == 1)
            {
                //AlertMessage("Please Fill Values");
                //return;
                AlertMessage("Please Fill Values");
                //return;
                //lblIsValidInput.Text = "Please Fill Values";
            }
            
          
            else
            {
              if  (ddlCat.SelectedIndex == 0)
            {
                AlertMessage("Please Select Category");
                //lblIsValidInput.Text = "Please Select Category";
                //return;
            }
            else if (ddlSubCat.SelectedIndex == 0)
            {
               AlertMessage("Please Select SubCategory");
                //lblIsValidInput.Visible = true;
                //lblIsValidInput.Text = "Please Select SubCategory";
                //return;
            }

                SaveData();


            }

        }
        else
        {
            AlertMessage("Please Select atleast one row");
        }


    }

    protected void SaveData()
    {

        foreach (GridViewRow grow in GridQuestion.Rows)
        {

            chkInsert = (System.Web.UI.WebControls.CheckBox)grow.FindControl("chkRow");
            if (chkInsert.Checked)
            {

                var ID = (QID.Value.ToString());
                var QuestionSequence = (TxtQuestionSeq.Text);
                var QuestionScore = (TxtQuestionScore.Text);
                InsertRecord(ID, QuestionSequence, QuestionScore);
            }


        }



    }

    //Method for Inserting Record  
    protected void InsertRecord(string ID, string Qseq, string QScore)
    {
        try
        {
            DBAccess db = new DBAccess("CRM");
            DataTable dt = default(DataTable);
            db.slDataAdd("CMFID",TxtCmfID.Text);
            db.slDataAdd("CategoryID",ddlCat.SelectedValue);
            db.slDataAdd("SubCategoryID",ddlSubCat.SelectedValue);
            db.slDataAdd("ParamID", ID);
            db.slDataAdd("ParamScore", QScore);
            db.slDataAdd("SubParamId",0);
            db.slDataAdd("sequence", Qseq);
            db.slDataAdd("active",1);
            db.slDataAdd("Type", "INSERT");
            dt = db.ReturnTable("CMF_INSERT_MAPPING", "", true);
            db = null;
            if ((dt != null))
            {
                switch ((dt.Rows[0]["MESSAGE_TYPE"].ToString()))
                {
                    case "S":
                        SuccessMessage(dt.Rows[0]["MESSAGE"].ToString());
                        showData();
                        break;

                    case "E":
                        AlertMessage(dt.Rows[0]["MESSAGE"].ToString());
                        showData();
                        break;
                }
            }
        }
        catch (Exception ex)
        {
            SuccessMessage(ex.ToString());
        }


    }

    protected void showData()
    {
        DataTable dt = new DataTable();
        DBAccess db = new DBAccess("CRM");
        try
        {

            db.slDataAdd("Type", "SELECT");
            dt = db.ReturnTable("CMF_INSERT_MAPPING", "", true);
            db = null;
            gdData.DataSource = dt;
            gdData.DataBind();
            gdData.Visible = true;
            btnBack.Visible = true;
            GridQuestion.Visible = false;
            btnSubmit.Visible = true;
        }

        catch (Exception Ex)
        { }
        
    }
    protected void datagrid_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        gdData.PageIndex = e.NewPageIndex;
        gdData.DataBind();
        showData();
    }


    protected void btnBack_Click(object sender, EventArgs e)
    {
        DivInput.Visible = true;
        ddlCat.SelectedIndex = 0;
        ddlSubCat.SelectedIndex = 0;
        gdData.Visible = false;
        GridQuestion.Visible = false;
        btnSubmit.Visible = false;
        PopulateQuestion();
        btnBack.Visible = false;
    }

    #region "--- Utility ---"
    private void AlertMessage(string msg)
    {
        lblHumanMessage.Text = msg;
        HumanMessage.CssClass = "HMFail";
        HumanMessage.Visible = true;
        lblHumanMessage.Visible = true;
        HumanMessage.Style["visibility"] = "visible";

    }
    private void SuccessMessage(string msg)
    {
        lblHumanMessage.Text = msg;
        HumanMessage.CssClass = "HMSuccess";
        HumanMessage.Visible = true;
        lblHumanMessage.Visible = true;
        HumanMessage.Style["visibility"] = "visible";


    }

    protected void HumanMsgbtn_Click(object sender, EventArgs e)
    {

        HumanMessage.Visible = false;
        lblHumanMessage.Text = "";
        HumanMessage.Style["visibility"] = "";

    }




    #endregion







}

