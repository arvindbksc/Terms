﻿using System;
using System.Data;
using System.Linq;
using System.Web;
using Microsoft.VisualBasic;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using com.nss.DBAccess;
using System.Data.SqlClient;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Web.Services;
using System.Windows.Forms;
using System.Text;
using System.Text.RegularExpressions;


public partial class CMF_CMFQuestionAnsMapping : System.Web.UI.Page
{
    SqlDataAdapter da;
    DataSet ds = new DataSet();
    StringBuilder htmlTable = new StringBuilder();

    System.Web.UI.WebControls.CheckBox chkInsert;
    System.Web.UI.WebControls.TextBox TxtOptionScore;
    System.Web.UI.WebControls.HiddenField QID;
    System.Web.UI.WebControls.TextBox TxtOptionSeq;
    System.Web.UI.WebControls.TextBox TxtOptionText;
    System.Web.UI.WebControls.TextBox TxtIsPassed;
    System.Web.UI.WebControls.TextBox TxtIsApplicable;

    #region "----Property Declaration-------"

    public string UserID { get; set; }
    public string AgentID { get; set; }
    public string UserName { get; set; }
    public DataTable Dtcampaign { get; set; }
    public DataTable Dtcat { get; set; }
    public DataTable DtSubcat { get; set; }
    public DataTable DataTableNew { get; set; }
    public int ProcessID { get; set; }
    static string Question { get; set; }


    #endregion
    #region "--- Functions ---"

    private bool IsInputNumeric(string input)
    {


        int i; bool Result = false;
        if (!int.TryParse(input, out i))
        {
            Result = true;
        }
        return Result;

    }

    private bool IsAlpha(string input)
    {

        bool Result = false;
        Regex r = new Regex(@"\d");
        if (r.IsMatch(input))
        {
            Result = true;

        }
        return Result;
    }



    protected void OnPageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        gdData.PageIndex = e.NewPageIndex;
        gdData.DataBind();
        //GetQuestion();
    }

    protected void AddNew1_Click(object sender, EventArgs e)
    {
        try
        {
            //Reset();
            string txtCMFID = "";
            string txtCMFIDText = "";
            string DdlCampaign = "";

            GridViewRow gvRow = (GridViewRow)((System.Web.UI.Control)sender).Parent.Parent;
            //int index = gvRow.RowIndex;
            txtCMFID = (gvRow.FindControl("TxtCMFIDFooter1") as System.Web.UI.WebControls.TextBox).Text;
            txtCMFIDText = (gvRow.FindControl("TxtCMFTextFooter1") as System.Web.UI.WebControls.TextBox).Text;
            DdlCampaign = (gvRow.FindControl("DdlCampaigntFooter1") as System.Web.UI.WebControls.DropDownList).SelectedValue;
            if (DdlCampaign == "0")
            {
                // AlertMessageCamp("Message: Please select Campaign.");
                return;
            }
            if (txtCMFIDText == "")
            {
                //AlertMessageCamp("Message: Please enter CMF Name.");
                return;
            }


        }

        catch (Exception ex)
        { }
    }



    #endregion
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            PopulateQuestion();
            GridQuestion.Visible = false;

        }
    }
    private void PopulateQuestion()
    {

        DBAccess db = new DBAccess("CRM");
        DataTable dt = default(DataTable);
        try
        {

            db.slDataAdd("ID", "");
            db.slDataAdd("QuestionText", "");
            db.slDataAdd("Type", "SELECT");
            db.slDataAdd("QuestionType", "");
            dt = db.ReturnTable("CMF_GET_QuestionMaster", "", true);
            db = null;
            lstQuestion.DataSource = dt;
            lstQuestion.DataTextField = "ParmText";
            lstQuestion.DataValueField = "ParamID";
            lstQuestion.DataBind();


        }

        catch (Exception ex)
        {

        }
    }



    protected void BtnCreateTable(object sender, EventArgs e)
    {

        //string message = "";
        DataTable dt = new DataTable();
        dt.Columns.AddRange(
           new DataColumn[7] { new DataColumn("ParamID", typeof(int)),
           new DataColumn("Question", typeof(string)),
           new DataColumn("TxtOpText",typeof(string)),
           new DataColumn("TxtOpScore",typeof(string)),
           new DataColumn("IsPassed", typeof(string)),
           new DataColumn("IsApplicable",typeof(string)),
           new DataColumn("Sequence",typeof(string)),
        });


        foreach (ListItem item in lstQuestion.Items)
        {
            if (item.Selected)
            {
                //message += item.Text + " " + item.Value + "\\n";
                for (int i = 0; i < 3; i++)
                {
                    dt.Rows.Add(item.Value, item.Text, "", "");
                }
                //dt.Rows.Add(item.Value, item.Text, "", "");
                //dt.Rows.Add(item.Value, item.Text, "", "");
                //dt.Rows.Add(item.Value, item.Text, "", "");
            }
        }
        ViewState["DataTableNew"] = dt;
        GridQuestion.DataSource = dt;
        GridQuestion.DataBind();
        GridQuestion.Visible = true;
        gdData.Visible = false;
        btnSubmit.Visible = true;

    }


    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        int flag = 0; int counter = 0;
        foreach (GridViewRow grow in GridQuestion.Rows)
        {
            

            //Searching CheckBox("chkDel") in an individual row of Grid  
            chkInsert = (System.Web.UI.WebControls.CheckBox)grow.FindControl("chkRow");
            TxtOptionScore = (System.Web.UI.WebControls.TextBox)grow.FindControl("TxtOptionScore");
            QID = (System.Web.UI.WebControls.HiddenField)grow.FindControl("hdnID");
            TxtOptionSeq = (System.Web.UI.WebControls.TextBox)grow.FindControl("TxtOS");
            TxtOptionText = (System.Web.UI.WebControls.TextBox)grow.FindControl("TxtOptionText");
            TxtIsPassed = (System.Web.UI.WebControls.TextBox)grow.FindControl("TxtIsPass");
            TxtIsApplicable = (System.Web.UI.WebControls.TextBox)grow.FindControl("TxtIsApp");

            //lblIsValidInput.Visible = true;
            //If CheckBox is checked than Insert the record with particular empid  
            if (chkInsert.Checked)
            {
                counter = counter + 1;
                //validation Start
                if (TxtOptionText.Text.ToString() == "")
                {
                    flag = 1;
                    //lblIsValidInput.Text = "Please Enter Option Text ";
                    AlertMessage("Please Enter Option Text");
                    //return;
                }
                else if (IsAlpha(TxtOptionText.Text.ToString()) == true)
                {

                    flag = 1;
                    //lblIsValidInput.Text = "Please Enter Alpha Fields only in Option Text in Row ";
                    AlertMessage("Please Enter Alpha Fields only in Option Text");
                    //return;

                }
                else if (TxtOptionScore.Text.ToString() == "")
                {
                    flag = 1;
                    //lblIsValidInput.Text = "Please Enter Option Score in Row ";
                    AlertMessage("Please Enter Option Score");
                    //return;
                }

                else if (IsInputNumeric(TxtOptionScore.Text.ToString()) == true)
                {

                    flag = 1;
                    AlertMessage("Please Enter Numeric Fields only in Option Score");
                    //lblIsValidInput.Text = "Please Enter Numeric Fields only in Option Score ";
                    //return;
                }
                else if (TxtIsPassed.Text.ToString() == "")
                {
                    flag = 1;
                    AlertMessage("Please Enter IsPassed");
                    //lblIsValidInput.Text = "Please Enter IsPassed in Row ";
                    //return;
                }


                else if (IsInputNumeric(TxtIsPassed.Text.ToString()) == true)
                {
                    flag = 1;
                    AlertMessage("Please Enter Numeric Fields only in IsPassed");
                    //lblIsValidInput.Text = "Please Enter Numeric Fields only in IsPassed ";
                   // return;
                }
                else if (TxtIsApplicable.Text.ToString() == "")
                {
                    flag = 1;
                    AlertMessage("Please Enter IsApplicable");
                    //lblIsValidInput.Text = "Please Enter IsApplicable in Row :" + GridQuestion.Rows;
                    return;
                }

                else if (IsInputNumeric(TxtIsApplicable.Text.ToString()) == true)
                {
                    flag = 1;
                    AlertMessage("Please Enter Numeric Fields only in IsApplicable ");
                    //lblIsValidInput.Text = "Please Enter Numeric Fields only in IsApplicable ";
                    //return;
                }
                else if (TxtOptionSeq.Text.ToString() == "")
                {
                    flag = 1;
                    AlertMessage("Please Enter Option Sequence");
                    //lblIsValidInput.Text = "Please Enter Option Sequence in Row ";
                    //return;
                }

                else if (IsInputNumeric(TxtOptionSeq.Text.ToString()) == true)
                {
                    flag = 1;
                    AlertMessage("Please Enter Numeric Fields only in Option Sequence");
                    //lblIsValidInput.Text = "Please Enter Numeric Fields only in Option Sequence ";
                    //return;
                }
                //else
                //{


                //}


            }
           
        }
        if (counter > 0)
        {
            if (flag == 1)
            {
                //AlertMessage("Please Fill Values");
                //return;
                AlertMessage("Please Fill Values");
                //return;
                //lblIsValidInput.Text = "Please Fill Values";
            }
            else
            {
                //if (flag == 0) 
                //{
                //    AlertMessage("Please Fill Values");
                //    return;

                //}

                SaveData();


            }

        }
        else
        {
            AlertMessage("Please Select atleast one row");
        }
            
           
    }





    protected void SaveData()
    {

        foreach (GridViewRow grow in GridQuestion.Rows)
        {

            chkInsert = (System.Web.UI.WebControls.CheckBox)grow.FindControl("chkRow");
            if (chkInsert.Checked)
            {

                var TxtOptionScore1 = ((System.Web.UI.WebControls.TextBox)grow.FindControl("TxtOptionScore")).Text.ToString();
                var QID1 = ((System.Web.UI.WebControls.HiddenField)grow.FindControl("hdnID")).Value.ToString();
                var TxtOptionSeq1 = ((System.Web.UI.WebControls.TextBox)grow.FindControl("TxtOS")).Text.ToString();
                var TxtOptionText1 = ((System.Web.UI.WebControls.TextBox)grow.FindControl("TxtOptionText")).Text.ToString();
                var TxtIsPassed1 = ((System.Web.UI.WebControls.TextBox)grow.FindControl("TxtIsPass")).Text.ToString();
                var TxtIsApplicable1 = ((System.Web.UI.WebControls.TextBox)grow.FindControl("TxtIsApp")).Text.ToString();


                InsertRecord(QID1, TxtOptionSeq1, TxtOptionScore1, TxtOptionText1, TxtIsPassed1, TxtIsApplicable1);
            }
            
           
        }
       
        

    }


    //Method for Inserting Record  
    protected void InsertRecord(string ID, string Oseq, string OScore, string OText, string Ispassed, string Isapplicable)
    {
        try
        {
            DBAccess db = new DBAccess("CRM");
            DataTable dt = default(DataTable);

            db.slDataAdd("ParamID", ID);
            db.slDataAdd("OptionScore", OScore);
            db.slDataAdd("OptionText", OText);
            db.slDataAdd("sequence", Oseq);
            db.slDataAdd("IsApplicable", Isapplicable);
            db.slDataAdd("IsPassed", Ispassed);

            db.slDataAdd("Type", "INSERTQUESANS_MAP");
            dt = db.ReturnTable("CMF_INSERT_QUESTANS_MAPPING", "", true);
            db = null;
            if ((dt != null))
            {
                switch ((dt.Rows[0]["MESSAGE_TYPE"].ToString()))
                {
                    case "S":
                        SuccessMessage(dt.Rows[0]["MESSAGE"].ToString());
                        showData();
                        break;

                    case "E":
                        AlertMessage(dt.Rows[0]["MESSAGE"].ToString());
                        showData();
                        break;
                }
            }
        }
        catch (Exception ex)
        {
            SuccessMessage(ex.ToString());
        }


    }

    protected void showData()
    {
        DataTable dt = new DataTable();
        DBAccess db = new DBAccess("CRM");
        try
        {

            db.slDataAdd("Type", "SELECTQUESANS_MAP");
            dt = db.ReturnTable("CMF_INSERT_QUESTANS_MAPPING", "", true);
            db = null;
            gdData.DataSource = dt;
            gdData.DataBind();
            gdData.Visible = true;
            btnBack.Visible = true;
            GridQuestion.Visible = false;
            btnSubmit.Visible = true;
        }

        catch (Exception Ex)
        { }

    }
    protected void datagrid_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        gdData.PageIndex = e.NewPageIndex;
        gdData.DataBind();
        showData();
    }


    protected void btnBack_Click(object sender, EventArgs e)
    {
        DivInput.Visible = true;
        //ddlCat.SelectedIndex = 0;
        //ddlSubCat.SelectedIndex = 0;
        gdData.Visible = false;
        GridQuestion.Visible = false;
        btnSubmit.Visible = false;
        PopulateQuestion();
        btnBack.Visible = false;
      
    }

    #region "--- Utility ---"
    private void AlertMessage(string msg)
    {
        lblHumanMessage.Text = msg;
        HumanMessage.CssClass = "HMFail";
        HumanMessage.Visible = true;
        lblHumanMessage.Visible = true;
        HumanMessage.Style["visibility"] = "visible";

    }
    private void SuccessMessage(string msg)
    {
        lblHumanMessage.Text = msg;
        HumanMessage.CssClass = "HMSuccess";
        HumanMessage.Visible = true;
        lblHumanMessage.Visible = true;
        HumanMessage.Style["visibility"] = "visible";


    }

    protected void HumanMsgbtn_Click(object sender, EventArgs e)
    {

        HumanMessage.Visible = false;
        lblHumanMessage.Text = "";
        HumanMessage.Style["visibility"] = "";
       // showData();
    }




    #endregion


}