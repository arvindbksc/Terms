﻿using Microsoft.VisualBasic;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using com.nss.DBAccess;
using System.Data.SqlClient;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Web.Services;


public partial class CMF_CMF_QuestionMaster : System.Web.UI.Page
{
    #region "----Property Declaration-------"


    public string UserID
    {
        get { return ViewState["UserID"].ToString(); }
        set { ViewState["UserID"] = value; }
    }
    public string AgentID
    {
        get { return ViewState["AgentID"].ToString(); }
        set { ViewState["AgentID"] = value; }
    }
    public string UserName
    {
        get { return ViewState["username"].ToString(); }
        set { ViewState["username"] = value; }
    }
    public string DatatableQuestionType
    {
        get { return ViewState["DatatableQuestionType"].ToString(); }
        set { ViewState["DatatableQuestionType"] = value; }
    }

    #endregion
    protected void Page_Load(object sender, EventArgs e)
    { 
        HumanMessage.Style["visibility"] = "hidden";
        HumanMessage.Visible = false;
        if (!this.IsPostBack)
        {
            this.GetQuestion();
            GetQuestionSearchBy();
            lblReportName.CurrentPage = "Question Master";
        }



    }


    #region "--- Functions ---"

    private void GetQuestion()
    {
        DBAccess db = new DBAccess("CRM");
        DataTable dt = default(DataTable);
        try
        {
           
            db.slDataAdd("ID", "");
            db.slDataAdd("QuestionText", "");
            db.slDataAdd("Type", "SELECT");
            db.slDataAdd("QuestionType", "");
            dt = db.ReturnTable("CMF_GET_QuestionMaster", "", true);
            db = null;
            gdData.DataSource = dt;
            gdData.DataBind();
            if (dt.Rows.Count > 0)
            {
                btnAddFirst.Visible = true;
            }
            else
            {
                btnAddFirst.Visible = true;
            }

        }
        catch (Exception ex)
        {
            //AlertMessage(ex.ToString);
        }
    }
    /// <summary>
    /// Bind the Question dropdown
    /// </summary>
    private void GetQuestionSearchBy()
    {
        DBAccess db = new DBAccess("CRM");
        DataTable dt = default(DataTable);
        try
        {

            db.slDataAdd("ID", "");
            db.slDataAdd("QuestionText", "");
            db.slDataAdd("Type", "SELECT");
            db.slDataAdd("QuestionType", "");
            dt = db.ReturnTable("CMF_GET_QuestionMaster", "", true);
            db = null;
            db = null;
            ddlSearchBy.DataTextField = "ParmText";
            ddlSearchBy.DataValueField = "ParamID";
            ddlSearchBy.DataSource = dt;
            ddlSearchBy.DataBind();
            ddlSearchBy.Items.Insert(0, new ListItem("--select--", "0"));
            ddlSearchBy.SelectedIndex = 0;

        }

        catch (Exception ex)
        {
           
        }
    }
    /// <summary>
    /// Bind grid according to the select
    /// </summary>
    private void BindQuestionSearchByGrid()
    {
        DBAccess db = new DBAccess("CRM");
        DataTable dt = default(DataTable);
        try
        {
            
            db.slDataAdd("ID", ddlSearchBy.SelectedValue);
            db.slDataAdd("QuestionText", "");
            db.slDataAdd("Type", "SEARCHBY");
            db.slDataAdd("QuestionType", "");
            dt = db.ReturnTable("CMF_GET_QuestionMaster", "", true);
            db = null;
            gdData.DataSource = dt;
            gdData.DataBind();
            if (dt.Rows.Count < 0)
            {
                AlertMessage("Record Not Found");
            }

        }
        catch (Exception ex)
        {
           
        }



    }

    public void OpenDialog()
    {

        try
        {
            string str = null;
            str = "$('#DialogBackground').height($(document).height()-10);$('#DialogBackground').width($(window).width());$('#DialogBackground').css('visibility','visible');$('#PanelIDPForm').css('visibility','visible');" + " $('#PanelIDPForm').css('left',($(window).width() - $('#PanelIDPForm').width())/2); ";
            ScriptManager.RegisterClientScriptBlock(Page, typeof(System.Web.UI.Page), "redirect", str, true);
        }
        catch (Exception ex)
        { }

    }

    public void SaveCategory(string QuestionText, string Type, int Id,string QuestionType)
    {
        try
        {
            DBAccess db = new DBAccess("CRM");
            DataTable dt = default(DataTable);
            db.slDataAdd("ID", Id);
            db.slDataAdd("QuestionText", QuestionText);
            db.slDataAdd("Type", Type);
            db.slDataAdd("QuestionType", QuestionType);
            dt = db.ReturnTable("CMF_GET_QuestionMaster", "", true);
            db = null;
            if ((dt != null))
            {
                switch ((dt.Rows[0]["MESSAGE_TYPE"].ToString()))
                {
                    case "S":
                        SuccessMessage(dt.Rows[0]["MESSAGE"].ToString());
                        break;

                    case "E":
                        AlertMessage(dt.Rows[0]["MESSAGE"].ToString());
                        break;
                }
            }
        }
        catch (Exception ex)
        {
            SuccessMessage(ex.ToString());
        }
    }


    #endregion

    #region "--- Events ---"



    protected void btnSave_Click(object sender, EventArgs e)
    {

        string QuestionName = null;
        string QuestionType = null;
        string type = "";
        QuestionName = TxtQuest.Text;
        QuestionType=ddlQuestype.SelectedValue.ToString();
        try
        {
            if ((btnSave.Text == "save"))
            {
                type = "INSERT";
                SaveCategory(QuestionName, type, 0, QuestionType);
            }

            GetQuestion();
        }
        catch (Exception Ex)
        { }

    }


    protected void gdData_RowCommand(object sender, System.Web.UI.WebControls.GridViewCommandEventArgs e)
    {
        if ((e.CommandName == "AddToCart"))
        {
            int index = Convert.ToInt32(e.CommandArgument);
            GridViewRow row = gdData.Rows[index];
        }

        if (e.CommandName.ToLower() == "addnew")
        {
        }

    }


    protected void AddNew_Click(object sender, EventArgs e)
    {
        try
        {
            Reset();
            string txtQuestion1 = "";
            string DdlQuestionType="";
            
            GridViewRow gvRow = (GridViewRow)((System.Web.UI.Control)sender).Parent.Parent;
            //int index = gvRow.RowIndex;
            txtQuestion1 = (gvRow.FindControl("TxtQuesFooter2") as System.Web.UI.WebControls.TextBox).Text;
            DdlQuestionType =(gvRow.FindControl("DdlQuesTypeFooter1") as System.Web.UI.WebControls.DropDownList).SelectedValue;

            SaveCategory(txtQuestion1, "INSERT", 0, DdlQuestionType);
            GetQuestion();
        }
        catch (Exception ex)
        { }
    }


    
    
    public void Reset()
    {
        TxtQuest.Text = "";
        
    }


    protected void gdData_RowEditing(object sender, GridViewEditEventArgs e)
    {
        btnSave.Text = "Update";
        int index = Convert.ToInt32(e.NewEditIndex);
        hdnPanelRoleprocessMapid.Value = ((System.Web.UI.WebControls.HiddenField)gdData.Rows[index].FindControl("hdnID")).Value;
        OpenDialog();
    }



    protected void OnPageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        gdData.PageIndex = e.NewPageIndex;
        gdData.DataBind();
        GetQuestion();
    }


    #endregion


    #region "--- Utility ---"
    private void AlertMessage(string msg)
    {
        lblHumanMessage.Text = msg;
        HumanMessage.CssClass = "HMFail";
        HumanMessage.Visible = true;
        lblHumanMessage.Visible = true;
        HumanMessage.Style["visibility"] = "visible";
        // HumanMessage.Style.Item("visibility") = "visible";

    }
    private void SuccessMessage(string msg)
    {
        lblHumanMessage.Text = msg;
        HumanMessage.CssClass = "HMSuccess";
        HumanMessage.Visible = true;
        lblHumanMessage.Visible = true;
        HumanMessage.Style["visibility"] = "visible";
        //HumanMessage.Item["visibility"].tostring() = "visible";

    }

    protected void HumanMsgbtn_Click(object sender, EventArgs e)
    {
        // HumanMessage.Style["visibility"].ToString() = "";
        HumanMessage.Visible = false;
        lblHumanMessage.Text = "";
        HumanMessage.Style["visibility"] = "";

    }

    #endregion

   
    
    protected void btnAddFirst_Click(object sender, EventArgs e)
    {
        btnSave.Text = "save";
        OpenDialog();

    }
    protected void ddlSearchBy_SelectedIndexChanged(object sender, EventArgs e)
    {
        BindQuestionSearchByGrid();
    }


    protected void gdData_RowDataBound(object sender, GridViewRowEventArgs e)
    {

        try
        {

            //if (e.Row.RowType == DataControlRowType.DataRow)
            //{

            //    DropDownList DdlKpaEdit1 = (DropDownList)e.Row.FindControl("DdlKpaEdit1");
            //    if ((DdlKpaEdit1 != null))
            //    {
            //        DdlKpaEdit1.DataTextField = "TEXTVALUE";
            //        DdlKpaEdit1.DataValueField = "ID";
            //        DdlKpaEdit1.DataSource = dtkpa;
            //        DdlKpaEdit1.DataBind();
            //        DdlKpaEdit1.SelectedItem.Text = ((HiddenField)e.Row.FindControl("HdnDdlKpaEdit1")).Value.ToString;


            //    }



            //    DropDownList DdlCatEdit1 = (DropDownList)e.Row.FindControl("DdlCatEdit1");
            //    if ((DdlCatEdit1 != null))
            //    {
            //        DdlCatEdit1.DataTextField = "TEXTVALUE";
            //        DdlCatEdit1.DataValueField = "ID";
            //        DdlCatEdit1.DataSource = dtcat;
            //        DdlCatEdit1.DataBind();
            //        DdlCatEdit1.SelectedItem.Text = ((HiddenField)e.Row.FindControl("HdnddlCatEdit1")).Value.ToString;
            //        //End If
            //    }

            //}

            //if (e.Row.RowType == DataControlRowType.Footer)
            //{

            //    DropDownList DdlQuestionFooter1 = (DropDownList)e.Row.FindControl("DdlQuesTypeFooter1");
            //    if ((DdlQuestionFooter1 != null))
            //    {
            //        DdlQuestionFooter1.DataTextField = "TEXTVALUE";
            //        DdlQuestionFooter1.DataValueField = "ID";
            //        DdlQuestionFooter1.DataSource = DatatableQuestionType;
            //        DdlQuestionFooter1.DataBind();
            //        DdlQuestionFooter1.Items.Insert(0, new ListItem("--select--", "0"));
            //        DdlQuestionFooter1.SelectedIndex = 0;

            //    }

            //    DropDownList DdlKpaFooter1 = (DropDownList)e.Row.FindControl("DdlKpaFooter1");
            //    if ((DdlKpaFooter1 != null))
            //    {
            //        DdlKpaFooter1.DataTextField = "TEXTVALUE";
            //        DdlKpaFooter1.DataValueField = "ID";
            //        DdlKpaFooter1.DataSource = dtkpa;
            //        DdlKpaFooter1.DataBind();
            //        DdlKpaFooter1.Items.Insert(0, new ListItem("--select--", "0"));
            //        DdlKpaFooter1.SelectedIndex = 0;

            //    }


            //}


        }
        catch (Exception ex)
        {
            AlertMessage(ex.Message + "T");
        }



    }
}
