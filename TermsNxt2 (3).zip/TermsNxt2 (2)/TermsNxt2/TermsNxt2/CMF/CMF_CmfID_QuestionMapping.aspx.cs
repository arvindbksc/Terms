﻿using System;
using System.Data;
using System.Linq;
using System.Web;
using Microsoft.VisualBasic;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using com.nss.DBAccess;
using System.Data.SqlClient;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Web.Services;
using System.Windows.Forms;
using System.Configuration;



public partial class CMF_CMF_CmfID_QuestionMapping : System.Web.UI.Page
{
    #region "----Property Declaration-------"

    public string UserID { get; set; }
    public string AgentID { get; set; }
    public string UserName { get; set; }
    public DataTable Dtcampaign { get; set; }
    public DataTable Dtcat { get; set; }
    public DataTable DtSubcat { get; set; }
    public int ProcessID { get; set; }

    #endregion
    #region "--- Functions ---"

    private void GetCampaignCMF()
    {
        DBAccess db = new DBAccess("CRM");
        DataTable dt = default(DataTable);
        try
        {

            db.slDataAdd("ID", "");
            db.slDataAdd("CategoryName", "");
            db.slDataAdd("Type", "SELECT_CAMPAIGN_CMFID");
            db.slDataAdd("paramID", "");
            db.slDataAdd("SubCategoryName", "");
            db.slDataAdd("ProcessID", cboProcess.SelectedValue);
            dt = db.ReturnTable("CMF_GET_CMFCampaign_Mapping", "", true);
            db = null;
            gdData.DataSource = dt;
            gdData.DataBind();
            if (dt.Rows.Count > 0)
            {
                btnAddFirstCMF.Visible = true;
            }
            else
            {
                btnAddFirstCMF.Visible = true;
            }

        }
        catch (Exception ex)
        {
            //AlertMessage(ex.ToString);
        }
    }



    public static void FillProcesses(ref DropDownList cboprocess, string AgentID)
    {
        //Processid="-1";
        DBAccess db = new DBAccess();
        DataTable dt = default(DataTable);
        db.slDataAdd("AgentID", AgentID);
        dt = db.ReturnTable("usp_MyProcesses", "", true);
        DataRow dr = default(DataRow);
        dr = dt.NewRow();
        dr["ProcessName"] = "All";
        dr["ProcessID"] = 0;
        dt.Rows.Add(dr);
        db = null;
        cboprocess.DataTextField = "ProcessName";
        cboprocess.DataValueField = "ProcessID";
        cboprocess.DataSource = dt;
        cboprocess.DataBind();
        //if (Processid != "-1") {
        //    cboprocess.Items.FindByValue("Processid").Selected=true;

        //}
    }


    private void getCampaign_ddl()
    {
        DBAccess db = new DBAccess("crm");

        try
        {
            db.slDataAdd("ID", "");
            db.slDataAdd("CategoryName", "");
            db.slDataAdd("Type", "DDLCAMPAIGN");
            db.slDataAdd("paramID", "");
            db.slDataAdd("SubCategoryName", "");
            db.slDataAdd("ProcessID", cboProcess.SelectedValue);
            Dtcampaign = db.ReturnTable("CMF_GET_CMFCampaign_Mapping", "", true);
            db = null;
            if (Dtcampaign.Rows.Count > 0)
            {
                ddlcampaign.DataTextField = "TEXTVALUE";
                ddlcampaign.DataValueField = "ID";
                ddlcampaign.DataSource = Dtcampaign;
                ddlcampaign.DataBind();
                ddlcampaign.Items.Insert(0, new ListItem("--select--", "0"));
                ddlcampaign.SelectedIndex = 0;
            }
        }
        catch (Exception ex)
        {
            //AlertMessage(ex.ToString);
        }
    }

    private void getCategory_ddl()
    {
        DBAccess db = new DBAccess("crm");

        try
        {
            db.slDataAdd("ID", "");
            db.slDataAdd("CategoryName", "");
            db.slDataAdd("Type", "DDLCATEGORY");
            db.slDataAdd("paramID", "");
            db.slDataAdd("SubCategoryName", "");
            db.slDataAdd("ProcessID", cboProcess.SelectedValue);
            Dtcat = db.ReturnTable("CMF_GET_CMFCampaign_Mapping", "", true);
            //db = null;
            //if (Dtcampaign.Rows.Count > 0)
            //{
            //    ddlCatFooter1.DataTextField = "TEXTVALUE";
            //    ddlCatFooter1.DataValueField = "ID";
            //    ddlCatFooter1.DataSource = Dtcampaign;
            //    ddlCatFooter1.DataBind();
            //    ddlCatFooter1.Items.Insert(0, new ListItem("--select--", "0"));
            //    ddlCatFooter1.SelectedIndex = 0;
            //}
        }
        catch (Exception ex)
        {
            //AlertMessage(ex.ToString);
        }
    }

    private void getSubCategory_ddl()
    {
        DBAccess db = new DBAccess("crm");

        try
        {
            db.slDataAdd("ID", "");
            db.slDataAdd("CategoryName", "");
            db.slDataAdd("Type", "DDLSUBCATEGORY");
            db.slDataAdd("paramID", "");
            db.slDataAdd("SubCategoryName", "");
            db.slDataAdd("ProcessID", cboProcess.SelectedValue);
            DtSubcat = db.ReturnTable("CMF_GET_CMFCampaign_Mapping", "", true);
            //db = null;
            //if (Dtcampaign.Rows.Count > 0)
            //{
            //    ddlCatFooter1.DataTextField = "TEXTVALUE";
            //    ddlCatFooter1.DataValueField = "ID";
            //    ddlCatFooter1.DataSource = Dtcampaign;
            //    ddlCatFooter1.DataBind();
            //    ddlCatFooter1.Items.Insert(0, new ListItem("--select--", "0"));
            //    ddlCatFooter1.SelectedIndex = 0;
            //}
        }
        catch (Exception ex)
        {
            //AlertMessage(ex.ToString);
        }
    }


    protected void OnPageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        gdData.PageIndex = e.NewPageIndex;
        gdData.DataBind();
        //GetQuestion();
    }
    protected void AddNew_Click(object sender, EventArgs e)
    {
        //try
        //{
        //    Reset();
        //    string txtQuestion1 = "";
        //    string DdlQuestionType = "";

        //    GridViewRow gvRow = (GridViewRow)((System.Web.UI.Control)sender).Parent.Parent;
        //    //int index = gvRow.RowIndex;
        //    txtQuestion1 = (gvRow.FindControl("TxtQuesFooter2") as System.Web.UI.WebControls.TextBox).Text;
        //    DdlQuestionType = (gvRow.FindControl("DdlQuesTypeFooter1") as System.Web.UI.WebControls.DropDownList).SelectedValue;

        //    SaveCategory(txtQuestion1, "INSERT", 0, DdlQuestionType);
        //    GetQuestion();
        //}
        //catch (Exception ex)
        //{ }
    }

    protected void AddNew1_Click(object sender, EventArgs e)
    {
        try
        {
            //Reset();
            string txtCMFID = "";
            string txtCMFIDText = "";
            string DdlCampaign = "";

            GridViewRow gvRow = (GridViewRow)((System.Web.UI.Control)sender).Parent.Parent;
            //int index = gvRow.RowIndex;
            txtCMFID = (gvRow.FindControl("TxtCMFIDFooter1") as System.Web.UI.WebControls.TextBox).Text;
            txtCMFIDText = (gvRow.FindControl("TxtCMFTextFooter1") as System.Web.UI.WebControls.TextBox).Text;
            DdlCampaign = (gvRow.FindControl("DdlCampaigntFooter1") as System.Web.UI.WebControls.DropDownList).SelectedValue;
            if (DdlCampaign == "0")
            {
                AlertMessageCamp("Message: Please select Campaign.");
                return;
            }
            if (txtCMFIDText == "")
            {
                AlertMessageCamp("Message: Please enter CMF Name.");
                return;
            }
            SaveCampaignCMF(txtCMFID, "INSERT", DdlCampaign, txtCMFIDText);
            GetCampaignCMF();


            //GridView1.Visible = true;

            GetCampaignCMFMapping();
        }

        catch (Exception ex)
        { }
    }

    public void OpenDialog()
    {

        try
        {
            string str = null;
            str = "$('#DialogBackground').height($(document).height()-10);$('#DialogBackground').width($(window).width());$('#DialogBackground').css('visibility','visible');$('#PanelIDPForm').css('visibility','visible');" + " $('#PanelIDPForm').css('left',($(window).width() - $('#PanelIDPForm').width())/2); ";
            ScriptManager.RegisterClientScriptBlock(Page, typeof(System.Web.UI.Page), "redirect", str, true);
        }
        catch (Exception ex)
        { }

    }

    /// <summary>
    /// Save CAMPAIGNCMFID
    /// </summary>
    /// <param name="CategoryName"></param>
    /// <param name="Type"></param>
    /// <param name="Id"></param>
    public void SaveCampaignCMF(string CMFID, string Type, string CampaignID, string campaignText)
    {
        try
        {
            DBAccess db = new DBAccess("CRM");
            DataTable dt = default(DataTable);
            db.slDataAdd("CategoryName", CampaignID);
            db.slDataAdd("paramID", "");
            db.slDataAdd("SubCategoryName", "");
            db.slDataAdd("ProcessID", "");
            db.slDataAdd("CMFTEXT", campaignText);
            db.slDataAdd("ID", CMFID);
            db.slDataAdd("Type", Type);
            dt = db.ReturnTable("CMF_GET_CMFCampaign_Mapping", "", true);
            db = null;
            if ((dt != null))
            {
                switch ((dt.Rows[0]["MESSAGE_TYPE"].ToString()))
                {
                    case "S":
                        SuccessMessage(dt.Rows[0]["MESSAGE"].ToString());
                        break;

                    case "E":
                        AlertMessage(dt.Rows[0]["MESSAGE"].ToString());
                        break;
                }
            }
        }
        catch (Exception ex)
        {
            SuccessMessage(ex.ToString());
        }
    }
    #endregion
    protected void Page_Load(object sender, EventArgs e)
    {
        DBAccess db = new DBAccess("CRM");

        if ((!Page.IsPostBack))
        {
            lblReportName.CurrentPage = "CMF Category SubCategory Question Mapping";

            db = null;
            //AgentID = Session["AgentID"].ToString();
            //ProcessID = cboProcess.SelectedValue;
            FillProcesses(ref cboProcess, "nss65909");

            Btnadd.Visible = false;
            GetCampaignCMF();
            getCampaign_ddl();


        }
        else
        {
            //FillData("Select");
        }


    }





    protected void cboProcess_SelectedIndexChanged(object sender, EventArgs e)
    {
        GetCampaignCMF();
    }



    protected void gdData_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        DBAccess db = new DBAccess("CRM");
        try
        {
            if (e.Row.RowType == DataControlRowType.Footer)
            {

                db.slDataAdd("ID", "");
                db.slDataAdd("CategoryName", "");
                db.slDataAdd("Type", "DDLCAMPAIGN");
                db.slDataAdd("paramID", "");
                db.slDataAdd("SubCategoryName", "");
                db.slDataAdd("ProcessID", cboProcess.SelectedValue);
                Dtcampaign = db.ReturnTable("CMF_GET_CMFCampaign_Mapping", "", true);


                DropDownList DdlCampaigntFooter1 = (DropDownList)e.Row.FindControl("DdlCampaigntFooter1");
                if ((DdlCampaigntFooter1 != null) && (Dtcampaign.Rows.Count > 0))
                {
                    DdlCampaigntFooter1.DataTextField = "TEXTVALUE";
                    DdlCampaigntFooter1.DataValueField = "ID";
                    DdlCampaigntFooter1.DataSource = Dtcampaign;
                    DdlCampaigntFooter1.DataBind();
                    DdlCampaigntFooter1.Items.Insert(0, new ListItem("--select--", "0"));
                    DdlCampaigntFooter1.SelectedIndex = 0;

                }

                DataTable dt = new DataTable();
                DataTable dtNew = new DataTable();
                System.Web.UI.WebControls.TextBox TxtmaxCMFID = e.Row.FindControl("TxtCMFIDFooter1") as System.Web.UI.WebControls.TextBox;
                dtNew = GETMAXCMFID(dt);
                TxtmaxCMFID.Text = dtNew.Rows[0]["MaxCMFID"].ToString();

            }


        }
        catch (Exception ex)
        {

        }


    }




    /// <summary>
    /// Function to get max CMF ID
    /// </summary>
    /// <param name="DT"></param>
    /// <returns></returns>
    private DataTable GETMAXCMFID(DataTable DT)
    {
        DBAccess db = new DBAccess("CRM");
        db.slDataAdd("ID", "");
        db.slDataAdd("CategoryName", "");
        db.slDataAdd("Type", "MAXCMF");
        db.slDataAdd("paramID", "");
        db.slDataAdd("SubCategoryName", "");
        db.slDataAdd("ProcessID", cboProcess.SelectedValue);
        DT = db.ReturnTable("CMF_GET_CMFCampaign_Mapping", "", true);
        return DT;


    }


    #region "--- Utility ---"
    private void AlertMessage(string msg)
    {
        lblHumanMessage.Text = msg;
        HumanMessage.CssClass = "HMFail";
        HumanMessage.Visible = true;
        lblHumanMessage.Visible = true;
        HumanMessage.Style["visibility"] = "visible";

    }
    private void SuccessMessage(string msg)
    {
        lblHumanMessage.Text = msg;
        HumanMessage.CssClass = "HMSuccess";
        HumanMessage.Visible = true;
        lblHumanMessage.Visible = true;
        HumanMessage.Style["visibility"] = "visible";


    }

    protected void HumanMsgbtn_Click(object sender, EventArgs e)
    {

        HumanMessage.Visible = false;
        lblHumanMessage.Text = "";
        HumanMessage.Style["visibility"] = "";

    }

    #endregion


    protected void btnAddFirstCMF_Click(object sender, EventArgs e)
    {

        btnSaveCMF.Text = "save";
        OpenDialog();
    }

    protected void btnSaveCMF_Click(object sender, EventArgs e)
    {


        string Campaign = null;
        string type = null;
        string CMFText = null;
        DataTable dt = new DataTable();
        DataTable dtnew = GETMAXCMFID(dt);
        cmfid.Text = dtnew.Rows[0][0].ToString();
        //CMFText = TxtCMFText.Text;
        Campaign = ddlcampaign.SelectedValue.ToString();
        try
        {
            if ((btnSaveCMF.Text == "save"))
            {
                type = "INSERT";

                SaveCampaignCMF(cmfid.Text, type, Campaign, CMFText);
            }

            GetCampaignCMF();
        }
        catch (Exception Ex)
        { }

    }
    protected void GridView1_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        DBAccess db = new DBAccess("CRM");
        try
        {
            if (e.Row.RowType == DataControlRowType.Footer)
            {

                //db.slDataAdd("ID", "");
                //db.slDataAdd("CategoryName", "");
                //db.slDataAdd("Type", "DDLCAMPAIGN");
                //db.slDataAdd("paramID", "");
                //db.slDataAdd("SubCategoryName", "");
                //db.slDataAdd("ProcessID", cboProcess.SelectedValue);
                //Dtcampaign = db.ReturnTable("CMF_GET_CMFCampaign_Mapping", "", true);


                DropDownList DdlCatFooter1 = (DropDownList)e.Row.FindControl("ddlCategoryFooter1");
                if ((DdlCatFooter1 != null) && (Dtcat.Rows.Count > 0))
                {
                    DdlCatFooter1.DataTextField = "TEXTVALUE";
                    DdlCatFooter1.DataValueField = "ID";
                    DdlCatFooter1.DataSource = Dtcat;
                    DdlCatFooter1.DataBind();
                    DdlCatFooter1.Items.Insert(0, new ListItem("--select--", "0"));
                    DdlCatFooter1.SelectedIndex = 0;

                }

                DropDownList ddlsubcatFooter1 = (DropDownList)e.Row.FindControl("ddlsubcatFooter1");
                if ((ddlsubcatFooter1 != null) && (DtSubcat.Rows.Count > 0))
                {
                    ddlsubcatFooter1.DataTextField = "TEXTVALUE";
                    ddlsubcatFooter1.DataValueField = "ID";
                    ddlsubcatFooter1.DataSource = DtSubcat;
                    ddlsubcatFooter1.DataBind();
                    ddlsubcatFooter1.Items.Insert(0, new ListItem("--select--", "0"));
                    ddlsubcatFooter1.SelectedIndex = 0;

                }
                DropDownList DdlQuestion = (DropDownList)e.Row.FindControl("DdlQuestion");
                if ((DdlQuestion != null) && (DtSubcat.Rows.Count > 0))
                {
                    DdlQuestion.DataTextField = "TEXTVALUE";
                    DdlQuestion.DataValueField = "ID";
                    DdlQuestion.DataSource = DtSubcat;
                    DdlQuestion.DataBind();
                    DdlQuestion.Items.Insert(0, new ListItem("--select--", "0"));
                    DdlQuestion.SelectedIndex = 0;

                }



                //DataTable dt = new DataTable();
                //DataTable dtNew = new DataTable();
                //System.Web.UI.WebControls.TextBox TxtmaxCMFID = e.Row.FindControl("TxtCMFIDFooter1") as System.Web.UI.WebControls.TextBox;
                //dtNew = GETMAXCMFID(dt);
                //TxtmaxCMFID.Text = dtNew.Rows[0]["MaxCMFID"].ToString();



            }
        }
        catch (Exception ex)
        {

        }

    }
    #region "--- Utility ---"
    private void AlertMessageCamp(string msg)
    {
        lblHumanMessageCamp.Text = msg;
        HumanMessage.CssClass = "HMFail";
        HumanMessage.Visible = true;
        lblHumanMessageCamp.Visible = true;
        HumanMessage.Style["visibility"] = "visible";
        // HumanMessage.Style.Item("visibility") = "visible";

    }
    private void SuccessMessageCamp(string msg)
    {
        lblHumanMessageCamp.Text = msg;
        HumanMsgBtnCamp.CssClass = "HMSuccess";
        HumanMsgBtnCamp.Visible = true;
        lblHumanMessageCamp.Visible = true;
        HumanMsgBtnCamp.Style["visibility"] = "visible";
        //HumanMessage.Item["visibility"].tostring() = "visible";

    }

    protected void HumanMsgBtnCamp_Click(object sender, EventArgs e)
    {
        // HumanMessage.Style["visibility"].ToString() = "";
        HumanMsgBtnCamp.Visible = false;
        lblHumanMessageCamp.Text = "";
        HumanMsgBtnCamp.Style["visibility"] = "";

    }

    #endregion

   
   
    [WebMethod]
    public static string[] GetCategory(string Category)
    {
        List<string> CategoryList = new List<string>();
        using (SqlConnection conn = new SqlConnection("Data Source=GGN-NSS-SQL2;Integrated Security=true;Initial Catalog=CRMDev"))
        {

            //SELECT CategoryID ,Caption FROM [dbo].[tbl_Quality_Category_Mst] WHERE Caption LIKE '%'+@CategoryName+'%'
            using (SqlCommand cmd = new SqlCommand("SELECT CategoryID ,Caption FROM [dbo].[tbl_Quality_Category_Mst] WHERE Caption LIKE @CategoryName+'%'", conn))
            {
                
                conn.Open();
                cmd.Parameters.AddWithValue("@CategoryName", Category);
                using (SqlDataReader sdr = cmd.ExecuteReader())
                {
                    while (sdr.Read())
                    {
                        CategoryList.Add(string.Format("{0}-{1}", sdr["Caption"], sdr["CategoryID"]));
                    }
                }
                conn.Close();
            }
        }
        return CategoryList.ToArray();
    }

    [WebMethod]
    public static string[] GetSubCategory(string SubCategory)
    {
        List<string> SubCategoryList = new List<string>();
 
        using (SqlConnection conn = new SqlConnection("Data Source=GGN-NSS-SQL2;Integrated Security=true;Initial Catalog=CRMDev"))
        {

            //SELECT CategoryID ,Caption FROM [dbo].[tbl_Quality_Category_Mst] WHERE Caption LIKE '%'+@CategoryName+'%'
            using (SqlCommand cmd = new SqlCommand("SELECT SubCategoryID,Caption FROM [tbl_Quality_SubCategory_Mst] WHERE Caption LIKE @SubCategory+'%'", conn))

            {
                
                conn.Open();
                cmd.Parameters.AddWithValue("@SubCategoryName", SubCategory);
                using (SqlDataReader sdr = cmd.ExecuteReader())
                {
                    while (sdr.Read())
                    {
                        SubCategoryList.Add(string.Format("{0}-{1}", sdr["Caption"], sdr["SubCategoryID"]));
                    }
                }
                conn.Close();
            }
        }
        return SubCategoryList.ToArray();
    }


    //[WebMethod]
    //public static string[] GetQuestion(string Question)
    //{
    //    List<string> SubCategoryList = new List<string>();

    //    using (SqlConnection conn = new SqlConnection("Data Source=GGN-NSS-SQL2;Integrated Security=true;Initial Catalog=CRMDev"))
    //    {

    //        //SELECT CategoryID ,Caption FROM [dbo].[tbl_Quality_Category_Mst] WHERE Caption LIKE '%'+@CategoryName+'%'
    //        using (SqlCommand cmd = new SqlCommand("SELECT SubCategoryID,Caption FROM [tbl_Quality_SubCategory_Mst] WHERE Caption LIKE @SubCategory+'%'", conn))
    //        {

    //            conn.Open();
    //            cmd.Parameters.AddWithValue("@SubCategoryName", Question);
    //            using (SqlDataReader sdr = cmd.ExecuteReader())
    //            {
    //                while (sdr.Read())
    //                {
    //                    SubCategoryList.Add(string.Format("{0}-{1}", sdr["Caption"], sdr["SubCategoryID"]));
    //                }
    //            }
    //            conn.Close();
    //        }
    //    }
    //    return SubCategoryList.ToArray();
    //}


    private void GetCampaignCMFMapping()
    {
        DBAccess db = new DBAccess("CRM");
        DataTable dt = default(DataTable);
        try
        {

            db.slDataAdd("ID", "");
            db.slDataAdd("CategoryName", "");
            db.slDataAdd("Type", "SELECT_CAMPAIGN_CMFID_MAPPING");
            db.slDataAdd("paramID", "");
            db.slDataAdd("SubCategoryName", "");
            db.slDataAdd("ProcessID", cboProcess.SelectedValue);
            dt = db.ReturnTable("CMF_GET_CMFCampaign_Mapping", "", true);
            db = null;
            GridView1.DataSource = dt;
            GridView1.Visible = true;
            GridView1.DataBind();
            if (dt.Rows.Count > 0)
            {
                Btnadd.Visible = true;
            }
            else
            {
                Btnadd.Visible = true;
            }

        }
        catch (Exception ex)
        {
            //AlertMessage(ex.ToString);
        }
    }
}





    //public DataTable FetchCATEGORYList()
    //{
    //    DBAccess db = new DBAccess("crm");

    //    try
    //    {
    //        db.slDataAdd("ID", "");
    //        db.slDataAdd("CategoryName", "");
    //        db.slDataAdd("Type", "DDLCAMPAIGN");
    //        db.slDataAdd("paramID", "");
    //        db.slDataAdd("SubCategoryName", "");
    //        db.slDataAdd("ProcessID", cboProcess.SelectedValue);
    //        Dtcampaign = db.ReturnTable("CMF_GET_CMFCampaign_Mapping", "", true);
    //        db = null;
    //        //if (Dtcampaign.Rows.Count > 0)
    //        //{
    //        //    ddlcampaign.DataTextField = "TEXTVALUE";
    //        //    ddlcampaign.DataValueField = "ID";
    //        //    ddlcampaign.DataSource = Dtcampaign;
    //        //    ddlcampaign.DataBind();
    //        //    ddlcampaign.Items.Insert(0, new ListItem("--select--", "0"));
    //        //    ddlcampaign.SelectedIndex = 0;
    //        //}
           
    //    }
    //    catch (Exception E)
    //    { }
    //    return Dtcampaign;
    //}


