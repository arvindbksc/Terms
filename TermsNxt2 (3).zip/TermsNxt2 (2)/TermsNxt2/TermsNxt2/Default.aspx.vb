﻿Imports com.nss.DBAccess
Imports System.Data
Partial Class _Default
    Inherits System.Web.UI.Page

    'Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
    '    If Authenticate() Then
    '        Response.Redirect("TMDashboard.aspx")
    '    Else
    '        Response.Redirect("weblogin.aspx?web=true")
    '        'Response.Write("There is some problem in authenticating your credentials. Please make sure you are authorized to use this website.")
    '    End If

    'End Sub
    'Public Function Authenticate() As Boolean
    '    'Dim str As String = My.User.CurrentPrincipal.Identity.Name
    '    'If str.Contains("\") Then
    '    '    str = str.Substring(str.LastIndexOf("\") + 1)
    '    'End If
    '    If Session("Lanid") <> "" Then
    '        Dim db As New DBAccess("CRM")
    '        Dim dr As DataRow
    '        If Session("Lanid") = "" Then
    '            Session("Lanid") = "&&"
    '        End If
    '        db.slDataAdd("LanID", Session("Lanid"))
    '        dr = db.ReturnRow("usp_GetAgentDetails", True)
    '        db = Nothing

    '        If Not dr Is Nothing Then
    '            Session("AgentID") = dr("AgentID")
    '            Session("Campaignid") = dr("Campaignid")
    '            Session("AgentName") = dr("AgentName")
    '            Return True
    '        Else
    '            Return False
    '        End If
    '    Else

    '        Return False
    '    End If

    'End Function

#Region "Properties"
    Property AgentID() As String
        Get
            Return ViewState("AgentID")
        End Get
        Set(ByVal value As String)
            ViewState("AgentID") = value
        End Set
    End Property
#End Region
    Protected Sub Page_PreLoad(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.PreLoad

        Dim serverpath As String
        If Request.Url.Host = "localhost" Then
            serverpath = HttpContext.Current.Request.ApplicationPath
        Else
            ' serverpath = "http://terms-monitor.niit-tech.com"
            serverpath = System.Configuration.ConfigurationManager.AppSettings("LiveServerPath")

        End If
        AgentID = Session("AgentID")
        If AgentID <> "" Then
            Response.Redirect(serverpath & "/Data/^Sitemap")
        Else
            Response.Redirect(serverpath & "/^weblogin")

        End If

    End Sub
End Class
