﻿
function resize() {
    var myWidth = 0, myHeight = 0, reduceby=0;
    reduceby = $("#header").height() + $("#footer").height();
    myHeight = $(window).height();
    myWidth = $(window).width();
    
    $("#content").height(myHeight - reduceby);
    $('#footer').css('visibility', 'visible');
//    alert($("#ChartContainerOuter").width());
//    alert($("#ChartContainerInner").width());
//    alert($("#ChartContainerHeader").width());
//    $('#waitdive').css('top', (myHeight - $('#waitdive').height()) / 2);
    //    $('#waitdive').css('left', (myWidth - $('#waitdive').width()) / 2);
    //alert(myHeight + "reduceby:" + reduceby + "Content:" + $("#content").height() + " footer:" + $("#footer").height() + " header: " + $("#header").height())
}

function CallPrint(strid) {
    var prtContent = document.getElementById(strid);
    var WinPrint = window.open('', '', 'left=0,top=0,width=900,height=600,toolbar=1,scrollbars=1,status=0');
    WinPrint.document.write('<HEAD><link href="../_assets/css/print.css" rel="stylesheet" type="text/css" /> </HEAD> ');
    WinPrint.document.write(prtContent.innerHTML);
    WinPrint.document.close();
    WinPrint.focus();
    WinPrint.print();
    WinPrint.close();
}


var done = true;
function HideControl() {
    $get('HumanMessage').style.visibility = 'hidden'
    done = true;
}
function window_onmousemove() {

    var ctrl;
    ctrl = document.getElementById("HumanMessage")


    if (ctrl != null) {
        if ($get('HumanMessage').style.visibility == 'hidden') return;
        if (done == true) {
            done = false;
            
            var delay = function() { HideControl(); };
            setTimeout(delay, 2000);
        }
    }
}
function initEverything() {

    //$('input.numeric').numeric();
    $(function() {
        $('.button,.addnew').button();
    });
    $(function() {
        $("input[class='date']").datepicker({ showAnim: '', showOn: 'both', buttonImage: '../_assets/img/dtppicknew.GIF', buttonImageOnly: true, autoSize: true, dateFormat: 'dd-M-yy' });
    });

}
function pageLoad(sender, args) {
    initEverything();
    if (args.get_isPartialLoad()) {
        //Specific code for partial postbacks can go in here.
    }
    else {


    }    
}
    