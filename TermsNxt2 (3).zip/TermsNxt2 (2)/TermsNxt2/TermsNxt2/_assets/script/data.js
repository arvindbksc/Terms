﻿var datefrom = ""; var dateto = ""; var curmonthNew = "";
var date = new Date();
var curdate = date.getDate();
var curdatefix = date.getDate();
var curmonth = date.getMonth();
var curmonthfix = date.getMonth();
var curyear = date.getFullYear();
var curyearfix = date.getFullYear();
var firstday, lastday;
var weekdate;
var first = date.getDate() - date.getDay() + 1;
var last = first + 6;
var ProcessId = '';
var AgentId = $('#hdnAgentId').val();
var UserId = '';
var RadioBtnVal = ''; //Commented by Gaurav Dutt $("input[id=rdByProcess]:checked").val();
var SelectedAgentId = '';
var CampaignID = '';//Commented by Gaurav Dutt $('#hdnCampaignId').val();

var ProcessName = ''; //Added by Gaurav Dutt 28/Dec/2015.
var SelectedCampaignId = ''; //Added by Gaurav Dutt 28/Dec/2015.


curmonthNew = curmonth + 1;
var monthNames = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
var shortmonth = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
var WeekDays = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
var groupby = 0;
$(document).ready(function () {
    // ----- For Loading data
    $('#DisableDiv').fadeTo('slow', .6);
    $('#DisableDiv').append('<div style="background-color:#E6E6E6;position: absolute;top:0;left:0;width: 100%;height:110%;z-index:1001;-moz-opacity: 0.8;opacity:.80;filter: alpha(opacity=80);"><img src="../_assets/img/loading1.gif" style="position:fixed;top:40%;left:46%;width:120px;"/></div>');
    setTimeout(function () { }, 100);
    //------------------   
    if (curmonthNew < 10) {
        curmonthNew = "0" + curmonthNew;
    }
    $("#CampaignData").UseAccessibleHeader = true;
    $(".gvAgents").UseAccessibleHeader = true;
    FillProcess();
    $("#cboProcess").val(ProcessId);
    $("#cboCampaigns").val(CampaignID);
    ProcessId = $('#hdnProcessId').val();
    UserId  = $('#hdnUserId').val();
    load();
});
function load() {
    if ($("#cboperiod").val() == "1") {
        groupby = 1;
        $('#txtdate').val(monthNames[curmonth] + " " + curyear);
        var daysInMonth = new Date(curyear, curmonthNew, 1, -1).getDate();
        datefrom = curyear.toString() + curmonthNew.toString() + "01";
        dateto = curyear.toString() + curmonthNew.toString() + daysInMonth;
        $("#time").html('<span>time by day</span>');
    }
    else if ($("#cboperiod").val() == "3") {
        groupby = 3;
        date = new Date();
        curdate=date.getDate();
        if (curdate < 10) {       
            curdate = "0" + curdate;
        }
        datefrom = curyear.toString() + curmonthNew.toString() + curdate;
        dateto = curyear.toString() + curmonthNew.toString() + curdate;
        $('#txtdate').val(curdate + " " + monthNames[curmonth] + " " + curyear);
        $("#time").html('<span>time by hours</span>');
    }
    else if ($("#cboperiod").val() == "2") {
        groupby = 2;
         curmonthNew = curmonth + 1;
            
        weekdate = new Date();
       // weekdate.setDate(weekdate.getDate());
            first = weekdate.getDate() - weekdate.getDay() + 1;
           first= Math.abs(first);
            firstday = new Date(weekdate.setDate(first)).toDateString();
       
        weekdate.setDate(weekdate.getDate() + 6);
        last = weekdate.getDate();
        var newmonth=weekdate.getMonth() + 1 ;
        lastday = new Date(weekdate.setDate(last)).toDateString();

        if (first < 10) {
            first = "0" + first;
             //first = first;
        }
        if (last < 10) {
            last = "0" + last;
             //last = last;
        }
         $('#txtdate').val(shortmonth[curmonth] + ' ' + first + " - " + shortmonth[newmonth-1] + ' ' + last + "," + curyear);
        if(newmonth < 10)
        {
        newmonth="0" + newmonth;
        }
        if(curmonthNew < 10)
        {
        curmonthNew="0" + curmonthNew;
        }
        datefrom = curyear.toString() + curmonthNew.toString() + first;
        dateto = curyear.toString() + newmonth.toString() + last;
        
        $("#time").html('<span>time by week</span>');
    }
    // ----- For Loading data
    $('#DisableDiv').fadeTo('slow', .6);
    $('#DisableDiv').append('<div style="background-color:#E6E6E6;position: absolute;top:0;left:0;width: 100%;height:110%;z-index:1001;-moz-opacity: 0.8;opacity:.80;filter: alpha(opacity=80);"><img src="../_assets/img/loading1.gif" style="position:fixed;top:40%;left:46%;width:120px;"/></div>');
    setTimeout(function () { }, 100);
    //------------------     
    var str = new Array();
    GetData(datefrom, dateto, groupby, ProcessId);
    var str1 = "";
    GetGridData(datefrom, dateto, ProcessId);

}

function GetData(datefrom, dateto, groupby, CampaignID) {
debugger; 
    var hv = $('#hdnProcessId').val();
    var hv02 = $('#hdnCampaignId').val();
    $.ajax({
        url: "ActivityDashboard.aspx/GetData",
        dataType: "json",
        type: "POST",
        data: "{'datefrom':'" + datefrom + "','dateto':'" + dateto + "','groupby':'" + groupby + "','process':'" + hv + "','AgentId':'" + SelectedAgentId + "','CampaignID':'" + hv02 + "'}",
        contentType: "application/json; charset=utf-8",
        success: getdataresponse,
        error: function (XHR, errStatus, errorThrown) {
            var err = JSON.parse(XHR.responseText);
            errorMessage = err.Message;
            alert("Error: " + errorMessage);
        },
        failure: function (response) {
            alert(response.responseText);
        },
    });
}
function getdataresponse(response) {
    str = response.d;
    getTotalLoginHrs(str);
    plotdonut(str);
    getTotalProductiveHrs(str);
    getcateogry(str);
    if (groupby == 2) {
        plotWithOptionsweekly(str);
    }
    else {
        plotWithOptions(str);
    }
    plotcategory1(str);
    plotcategory2(str);
    plotcategory3(str);
    $('#DisableDiv').html("");
}
var previousPoint = null,
    previousLabel = null;
function getTotalLoginHrs(str) {
    var data = jQuery.parseJSON(str[0]);
    var d1 = data[0].TotalDuration;
    if (d1 != null) {
        var d2 = d1.split(":");
        $("#lbltotallogin").text(d2[0] + "h " + d2[1] + "m");
    }
}
function plotdonut(str) {
    var data = jQuery.parseJSON(str[1]);
    if (data == null) {
        $("#div1").hide();
    }
    else {
        $("#div1").show();
    }
    if (data != null) {
        $.plot($("#chart5"), data,
        {
            series:
            {
                pie:
                {
                    show: true, innerRadius: .7, label: false,
                },
            },
            grid:
            {
                hoverable: true,
            },
            legend:
            {
                show: false,
            },
        });
        $("#chart5").bind("plothover", pieHover);

    }
}
function pieHover(event, pos, obj) {
    if (obj) {
        percent = parseFloat(obj.series.percent).toFixed(2);
        if (obj.series.color == "#00008B") {
            obj.series.label = 'Non Productive Break';
        }
        else if (obj.series.color == "#ADD8E6") {
            obj.series.label = 'Productive Break';
        }
        $("#hover").html('<span style="font-weight: bold; color: ' + obj.series.color + '">' + obj.series.label + ' (' + percent + '%)</span>');
    }
    else {
        $("#hover").html('');
    }
}
function getTotalProductiveHrs(str) {
    var data = jQuery.parseJSON(str[3]);
    var d1 = data[0].Duration;
    $("#divprodhrs").text(d1);
}
function getcateogry(str) {
    var catdata = jQuery.parseJSON(str[1]);
    if (catdata != null) {
        var datalength = catdata.length;
        var d1 = [];
        var abc = ""
        $("#ulcat").empty();
        for (var i = 0; i <= datalength - 1; i += 1) {
            var catDuration = catdata[i].data;
            var Cat = catdata[i].label;
            var color = catdata[i].color;
            var dID = catdata[i].CatID;
            if (color == "#00008B") {
                Cat = 'Non Productive Break';
            }
            else if (color == "#ADD8E6") {
                Cat = 'Productive Break';
            }
            var design = "";
            design = "<li><p> <span style='border:solid 1px #ccc; border-image: none; padding:5px; color:#000;'>" + catDuration + "%</span><a href='#' onclick='CatIDName(" + dID + ',' + '"' + Cat + '"' + ")'>" + Cat + "</a></p>";
            design = design + "<div class='progress progress-xs'>";
            design = design + "<div class='progress' role='progressbar' aria-valuenow=" + catDuration + " aria-valuemin='0' aria-valuemax='100' style='background-color:" + color + "; width:" + catDuration + "%'></div></div></li>";
            $('#divcat ul').append(design);
        }
    }
}
function GetGridData1(catId,catname) {
        // ----- For Loading data
        $('#DisableDiv').fadeTo('slow', .6);
        $('#DisableDiv').append('<div style="background-color:#E6E6E6;position: absolute;top:0;left:0;width: 100%;height:110%;z-index:1001;-moz-opacity: 0.8;opacity:.80;filter: alpha(opacity=80);"><img src="../_assets/img/loading1.gif" style="position:fixed;top:40%;left:46%;width:120px;"/></div>');
        setTimeout(function () { }, 100);
        //------------------   
         var hdval = $("#hdnProcessId").val();
         $("#spanstatus").text(catname + " - Details");
        $.ajax({
            url: "ActivityDashboard.aspx/BindGrid1",
            dataType: "json",
            type: "POST",
            data: "{'datefrom':'" + datefrom + "','dateto':'" + dateto + "','processid':'" + hdval + "','CategoryID':'" + catId + "','Agentid':'" + SelectedAgentId + "'}",
            contentType: "application/json; charset=utf-8",
            success: bindresponse1,
            error: function (XHR, errStatus, errorThrown) {
                var err = JSON.parse(XHR.responseText);
                errorMessage = err.Message;
                alert("Error: " + errorMessage);
            },
            failure: function (response) {
                alert(response.responseText);
            },
        });
     }
     function bindresponse1(response) {
        str2 = response.d;
        Bindgrid1(str2);
    }
     function Bindgrid1(str2) {
         $("#AppDetails").empty();
         if (str2 != "") {
             $("#AppDetails").empty();
             var data = jQuery.parseJSON(str2);
             var strname = "";
             if (data != null) {
                 var datalength = data.length;
                 var gvcol = "";
                 gvcol = "<thead><tr >";
                 gvcol = gvcol + "<th>Select</th>";
                 for (strname in data[0]) {
                     if (strname != "BreakType") {
                         gvcol = gvcol + "<th>" + strname + "</th>";
                     }
                     else {
                         gvcol = gvcol + "<th style='display: none;'>" + strname + "</th>";
                     }
                 }
                 gvcol = gvcol + "</tr></thead>";
                 $("#AppDetails").append(gvcol);
                 gvrow = "<tbody>";
                 for (var i = 0; i <= datalength; i += 1) {
                     var gvrow = "";
                     gvrow = gvrow + "<tr >";
                     if (data[i] != null) {
                         gvrow = gvrow + "<td data-title=" + '"' + "Select" + '"' + " ><input id='Checkbox1' type='checkbox' /></td>"
                     }
                     for (strname in data[i]) {

                         if (data[i][strname] == null) {
                             gvrow = gvrow + "<td data-title=" + '"' + strname + '"' + ">0</td>";
                         }

                         else {
                             if (strname == "Duration") {
                                 gvrow = gvrow + "<td data-title=" + '"' + strname + '"' + ">" + convertsecond(data[i][strname]) + "</td>";

                             }
                             else if (strname == "AppName") {
                                 gvrow = gvrow + "<td data-title=" + '"' + strname + '"' + " >" + (data[i][strname]) + "</td>";
                             }
                                 //else if (strname == "BreakType") {
                                 //    gvrow = gvrow + "<td data-title=" + '"' + strname + '"' + " style='display: none;'>" + (data[i][strname]) + "</td>";
                                 //}


                             else {

                                 gvrow = gvrow + "<td data-title=" + '"' + strname + '"' + ">" + (data[i][strname]) + "</td>";
                             }
                         }
                     }
                     gvrow = gvrow + "</tr>";
                     $("#AppDetails").append(gvrow);
                 }
                 gvrow = gvrow + "</tbody></table>";

                 $('#DetailDialog').modal('show')
             }
         }
         $('#DisableDiv').html("");
     }
function plotWithOptions(str) {
    var data = jQuery.parseJSON(str[2]);
    if (data != null && data.length>0) {
        var datalength = data.length;
        var d1 = []; var d2 = [];
        for (var i = 0; i <= datalength - 1; i += 1) {
            if (data[i].isproductive == 1) {
                d1.push([data[i].Day, data[i].duration]);
            }
            else {
                d2.push([data[i].Day, -data[i].duration]);
            }
        }
        var dataset;
        dataset = [
            {
                label: "Productive Hrs",
                data: d1,
                //yaxis: { min: 0, max: 0, tickLength: 0, ticks: 0, showticks: false },
                //xaxis: { min: 0, max: 50, ticks: 1 },
                color: "#90EE90",
                //points: { symbol: "circle", fillColor: "#FF0000", show: true },
                lines: { show: false }
            },
            {
                label: "Non Productive Hrs",
                data: d2,
                //yaxis: { min: 0, max: 0, tickLength: 0, ticks: 0, showticks: false },
                //xaxis: { min: 0, max: 50, ticks: 1 },
                color: "#F08080",
                //points: { symbol: "triangle", fillColor: "#0062FF", show: true },
                lines: { show: false }
            }
        ];


        var stack = 0, bars = true, lines = false, steps = false;
// Stop bar chart not in use.        
//        $.plot($("#bar-chart"), dataset, {
//            series: {
//                stack: stack,
//                lines: { show: false },
//                bars: { show: true, barWidth: 0.2, order: 1, }
//            },
//            xaxis: { min: 1,axisLabelUseCanvas: true, },
//            yaxis: {
//                show: false,
//                ticks: 0,
//                axisLabelUseCanvas: true,
//            },
//            grid: {
//                hoverable: true,
//                borderWidth: 0,
//                backgroundColor: null,
//                tickColor: "rgba(0,0,0,0)",
//                markings: [{ xaxis: { from: 0, to: 31 }, yaxis: { from: 0, to: 0 }, color: "#000" }]
//            },
//            bars: {
//                show: true,
//                lineWidth: 0,
//                fill: true,
//                fillColor: { colors: [{ opacity: 0.9 }, { opacity: 0.8 }] },
//            },
//            legend:
//                {
//                    show: false,
//                },
//            valueLabels: {
//                show: true
//            }
//        });
//        $("#bar-chart").bind("plothover", barHover);
    }
}
function plotWithOptionsweekly(str) {
    var data = jQuery.parseJSON(str[2]);
    if (data != null && data.length>0) {
        var datalength = data.length;
        var d1 = []; var d2 = [];
        for (var i = 0; i <= datalength - 1; i += 1) {
            if (data[i].isproductive == 1) {
                d1.push([data[i].Day, data[i].duration]);
            }
            else {
                d2.push([data[i].Day, -data[i].duration]);
            }
        }
        var dataset;
        dataset = [
        {
            label: "Productive Hrs",
            data: d1,
            color: "#90EE90",
            lines: { show: false }
        },
        {
            label: "Non Productive Hrs",
            data: d2,
            color: "#F08080",
            lines: { show: false }
        }
        ];
        var stack = 0, bars = true, lines = false, steps = false;
        $.plot($("#bar-chart"), dataset, {
            series: {
                stack: stack,
                lines: { show: false },
                bars: { show: true, barWidth: 0.2, order: 1, }
            },
            xaxis: {
                min: 1.0,
                max: 7.0,
                //mode: null,
                ticks: [[1.0, "Mon"], [2.0, "Tue"], [3.0, "Wed"], [4.0, "Thu"], [5.0, "Fri"], [6.0, "Sat"], [7.0, "Sun"]],
                tickLength: 0, // hide gridlines
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial, Helvetica, Tahoma, sans-serif',
                axisLabelPadding: 5
            },
            yaxis: {
                show: false,
                ticks: 0
            },
            grid: {
                hoverable: true,
                borderWidth: 0,
                backgroundColor: null,
                tickColor: "rgba(0,0,0,0)",
                markings: [{ xaxis: { from: 0, to: 31 }, yaxis: { from: 0, to: 0 }, color: "#000" }
                ]
            },
            bars: {
                show: true,
                lineWidth: 0,
                fill: true,
                fillColor: { colors: [{ opacity: 0.9 }, { opacity: 0.8 }] },
            },
            legend:
                {
                    show: false,
                },
            valueLabels: {
                show: true
            }
        });
        $("#bar-chart").bind("plothover", barHover);
    }
}
function showTooltip(x, y, color, contents) {
    $('<div id="tooltip">' + contents + '</div>').css({
        position: 'absolute',
        display: 'none',
        top: y - 40,
        left: x - 60,
        border: '2px solid ' + color,
        padding: '3px',
        'font-size': '9px',
        'border-radius': '5px',
        'background-color': '#fff',
        'font-family': 'Verdana, Arial, Helvetica, Tahoma, sans-serif',
        'text-align': 'center',
        opacity: 0.9
    }).appendTo("body").fadeIn(200);
}
function barHover(event, pos, item) {
    if (item) {
        if ((previousLabel != item.series.label) || (previousPoint != item.dataIndex)) {
            previousPoint = item.dataIndex;
            previousLabel = item.series.label;
            percent = parseFloat(item.series.percent).toFixed(2);

            $("#tooltip").remove();

            var x = item.datapoint[0];
            var y = item.datapoint[1].toString();
            y = y.replace("-", "");
            var color = item.series.color;
            var str = "";
            if (groupby == 1) {
                str = "<strong> Day " + x + "</strong><br>"
            }
            else if (groupby == 3) {
                str = "<strong> Hour " + x + "</strong><br>"
            }
            showTooltip(item.pageX, item.pageY, color,
            str +
             "<strong>" + item.series.label + "</strong>: <strong>" + y + "</strong>");
        }
    } else {
        $("#tooltip").remove();
        previousPoint = null;
    }
}
function plotcategory1(str) {

    var catdata = jQuery.parseJSON(str[4]);
    
    if (catdata == null) {
        $("#divspot").hide();
    }
    else {
        $("#divspot").show();
    }
    if (catdata != null) {
        var datalength = catdata.length;
        var d1 = [];
        var abc = "";
        $("#ul1info").empty();
        for (var i = 0; i <= datalength - 1; i += 1) {
            d1.push([catdata[i].ID, catdata[i].Duration]);
            var catsr = catdata[i].ID;
            var appname = catdata[i].AppName;
            $("#cat1info ul").append("<li class = 'aap-list'><span class='cat1info'>" + catsr + "</span><span class='appinfo'>" + ChangeToProperCase(appname) + "</span></li>");
        }
        
        var dataset = [
            {
                label: "",
                data: d1,
                color: "#90EE90",
//                lines: { show: false }
            } ];

        var stack = 0, bars = true, lines = false, steps = false;
        $.plot($("#cat1"), dataset, {
            series: {
                //label:"Time By Day",                   
                stack: stack,
                lines: { show: false },
                bars: { show: bars, barWidth: .5, label: false, }
            },
            xaxis: {
                ticks: 0, min: 1, max: 6,
            },
           // yaxis:{ axisLabelUseCanvas: true,},
            grid: {
                hoverable: true,
                borderWidth: 0,
                aboveData: false,
                backgroundColor: null,
                tickColor: "rgba(0,0,0,0)",
                markings: [{ xaxis: { from: 0, to: 40 }, yaxis: { from: 0, to: 0 }, color: "#000" }]
            },
            bars:
             {
                 show: true,
                 lineWidth: 0,
                 fill: true,
                 fillColor: { colors: [{ opacity: 0.9 }, { opacity: 0.8 }] }
             },
            legend:
             {
                 show: false,
             },
            valueLabels:
            {
                show: true
            }
        });
        $("#cat1").bind("plothover", CategorybarHover);
    }
}
function plotcategory2(str) {
    var catdata = jQuery.parseJSON(str[5]);
    if (catdata == null) {
        $("#divspot").hide();
    }
    else {
        $("#divspot").show();
    }
    if (catdata != null) {
        var datalength = catdata.length;
        var d1 = [];
        $("#ul2info").empty();
        for (var i = 0; i <= datalength - 1; i += 1) {
            d1.push([catdata[i].ID, catdata[i].Duration]);
            var catsr = catdata[i].ID;
            var appname = catdata[i].AppName;
            $('#cat2info ul').append("<li class = 'aap-list'><span class='cat2info'>" + catsr + "</span><span class='appinfo'>" + ChangeToProperCase(appname) + "</span></li>");
        }
        var dataset = [
        {
            label: "",
            data: d1,
            color: "#90EE90",
            lines: { show: false }
        }
        ];
        var stack = 0, bars = true, lines = false, steps = false;
        $.plot($("#cat2"), dataset, {
            series:
            {
                //label:"Time By Day",                   
                stack: stack,
                lines: { show: false },
                bars: { show: bars, barWidth: .5,axisLabelUseCanvas: true, }
            },
            xaxis:
            {
                ticks: 0, min: 1, max: 6, axisLabelUseCanvas: true,
            },
            yaxis: { ticks: 0, show: false, axisLabelUseCanvas: true,},
            grid: {
                hoverable: true,
                borderWidth: 0,
                aboveData: false,
                backgroundColor: null,
                tickColor: "rgba(0,0,0,0)",
                markings: [{ xaxis: { from: -10, to: 40 }, yaxis: { from: 0, to: 0 }, color: "#000" }]
            },
            bars:
            {
                show: true,
                lineWidth: 0,
                fill: true,
                fillColor: { colors: [{ opacity: 0.9 }, { opacity: 0.8 }] }
            }
        });
        $("#cat2").bind("plothover", CategorybarHover);
    }
}
function plotcategory3(str) {
    //var datadoc = response.d;
    var catdata = jQuery.parseJSON(str[6]);
    if (catdata == null) {
        $("#divspot").hide();
    }
    else {
        $("#divspot").show();
    }
    if (catdata != null) {
        var datalength = catdata.length;
        var d1 = [];
        var abc = ""
        $("#ul3info").empty();
        for (var i = 0; i <= datalength - 1; i += 1) {
            d1.push([catdata[i].ID, catdata[i].Duration]);
            var catsr = catdata[i].ID;
            var appname = catdata[i].AppName;
            $('#cat3info ul').append("<li class = 'aap-list'><span class='cat3info'>" + catsr + "</span><span class='appinfo'>" + ChangeToProperCase(appname) + "</span></li>");
        }

        var dataset = [
                {
                    label: "",
                    data: d1,
                    color: "#808080",
                    lines: { show: false }
                }
        ];
        var stack = 0, bars = true, lines = false, steps = false;
        $.plot($("#cat3"), dataset, {
            series: {
                //label:"Time By Day",                   
                stack: stack,
                lines: { show: false },
                bars: { show: bars, barWidth: .5 }
            },
            xaxis: {
                ticks: 0, min: 1, max: 6,
            },
            yaxis: { ticks: 0, show: false, },
            grid: {
                hoverable: true,
                borderWidth: 0,
                aboveData: false,
                backgroundColor: null,
                tickColor: "rgba(0,0,0,0)",
                markings: [{ yaxis: { from: 0, to: 0 }, color: "#000" }]
            },
            bars: {
                show: true,
                lineWidth: 0,
                fill: true,
                fillColor: { colors: [{ opacity: 0.9 }, { opacity: 0.8 }] }
            }
        });
        $("#cat3").bind("plothover", CategorybarHover);
    }
}
function ChangeToProperCase(str) {
    var val = str.toLowerCase(), newVal = '';
    val = val.split(' ');
    for (var c = 0; c < val.length; c++) {
        if (c > 0 && val[c] == "is" || c > 0 && val[c] == "to" || c > 0 && val[c] == "the") {
            newVal += val[c] + ' ';
        } else newVal += val[c].substring(0, 1).toUpperCase() + val[c].substring(1, val[c].length) + (c + 1 == val.length ? '' : ' ');
    }
    return newVal;
}
function CategorybarHover(event, pos, item) {
    if (item) {
        if ((previousLabel != item.series.label) || (previousPoint != item.dataIndex)) {
            previousPoint = item.dataIndex;
            previousLabel = item.series.label;
            percent = parseFloat(item.series.percent).toFixed(2);
            $("#tooltip").remove();
            var x = item.datapoint[0];
            var y = item.datapoint[1].toString();
            y = y.replace("-", "");
            var color = item.series.color;
            var str = "";
            showTooltip(item.pageX, item.pageY, color,
            //str + "<strong>" + item.series.label + "</strong>: <strong>" + y + "</strong> %");
            str + "<strong> Hour :" + y + "</strong> %");
        }
    }
    else {
        $("#tooltip").remove();
        previousPoint = null;
    }
}
function convertsecond(totalSeconds) {
    var hours = Math.floor(totalSeconds / 3600);
    if (hours < 10) {
        hours = "0" + hours;
    }
    totalSeconds %= 3600;
    var minutes = Math.floor(totalSeconds / 60);
    if (minutes < 10) {
        minutes = "0" + minutes;
    }
    var seconds = totalSeconds % 60;
    if (seconds < 10) {
        seconds = "0" + seconds;
    }
    var strsec = hours + ":" + minutes + ":" + seconds;
    return strsec;
}
function GetGridData(datefrom, dateto, ProcessId, CampaignID) {
    var hdval = $("#hdnProcessId").val();
    var hdval02 = $("#hdnCampaignId").val();
    var hdval03 = SelectedAgentId;
    $.ajax({
        url: "ActivityDashboard.aspx/BindGrid",
        dataType: "json",
        type: "POST",
        data: "{'datefrom':'" + datefrom + "','dateto':'" + dateto + "','process':'" + hdval + "','Agent':'" + SelectedAgentId + "','CampaignID':'" + hdval02 + "'}",
        contentType: "application/json; charset=utf-8",
        success: bindresponse,
        error: function (XHR, errStatus, errorThrown) {
            var err = JSON.parse(XHR.responseText);
            errorMessage = err.Message;
            alert("Error: " + errorMessage);
        },
        failure: function (response) {
            alert(response.responseText);
        },
    });
}
function bindresponse(response) {
    str1 = response.d;
    Bindgrid(str1);
    $('#DisableDiv').html("");
}
function Bindgrid(str1) {   
    $("#CampaignData").empty();

    if (str1 != "") {
        var data = jQuery.parseJSON(str1);
        var strname = "";
        var footername = [];
        var footer = [];
        var loginhrs = 0,TransTime=0,ProdBreak=0;
        if (data != null) {
            var datalength = data.length;
            var gvcol = "";
            gvcol = "<thead><tr>";
            for (strname in data[0]) {
                gvcol = gvcol + "<th>" + strname + "</th>";
                footername.push(strname);
            }
            gvcol = gvcol + "</tr></thead>";
            $("#CampaignData").append(gvcol);
            gvrow = "<tbody>";
            for (j = 1; j <= footername.length; j++) {
                footer[j] = 0;
            }
            var utilization = 0.0,production = 0.0 ;
            for (var i = 0; i <= datalength; i += 1) {
                var gvrow = "";
                gvrow = gvrow + "<tr>";
                for (strname in data[i]) {
                    if (data[i][strname] == null) {
                        gvrow = gvrow + "<td data-title=" + '"' + strname + '"' + ">00:00:00</td>";
                    }

                    else {
                        if (strname != "Agent" && strname != "Utilization %" && strname != "Production %") {
                            for (j = 1; j <= footername.length - 2; j++) {
                                if (strname == footername[j]) {
                                    footer[j] += data[i][strname];
                                   // loginhrs += data[i][strname];
                                }
                            }
                            if (strname == "Transaction Time") {
                                TransTime += data[i][strname];
                            }
                            if (strname == "Login Hrs") {
                                loginhrs += data[i][strname];
                            }
                            if (strname == "Productive Break") {
                                ProdBreak += data[i][strname];
                            }
                            
                            
                            if (isNaN(data[i][strname])==true) {  // it is not a number
                            gvrow = gvrow + "<td data-title=" + '"' + strname + '"' + ">" + data[i][strname] + "</td>";
                            }
                            else { //// it is a number
                            gvrow = gvrow + "<td data-title=" + '"' + strname + '"' + ">" + convertsecond(data[i][strname]) + "</td>";
                            //alert("afsf: " + data[i][strname]);                                                       
                            }   
                            
                            
                        }
                        else {
                            gvrow = gvrow + "<td data-title=" + '"' + strname + '"' + ">" + data[i][strname] + "</td>";
                           
                        }
                    }
                }
                gvrow = gvrow + "</tr>";
                $("#CampaignData").append(gvrow);
            }
            var gvrow = "";    
            utilization = parseFloat((TransTime + ProdBreak) * 100.00 / loginhrs).toPrecision(4);
            production = parseFloat(TransTime  * 100.00 / loginhrs).toPrecision(4);

            if (datalength > 0) {
                gvrow = gvrow + "<tr>";
                gvrow = gvrow + "<td >Total</td>";
                for (var i = 1; i <= footername.length - 3; i += 1) {                
                gvrow = gvrow + "<td data-title=" + '"' + footername[i] + '"' + ">" + convertsecond(footer[i]) + "</td>";
                }
                gvrow = gvrow + "<td data-title='Utilization'>" + utilization + "</td>";
                gvrow = gvrow + "<td data-title='Production'>" + production + "</td>";
                gvrow = gvrow + "</tr>";
                $("#CampaignData").append(gvrow);
            }
            gvrow = gvrow + "</tbody>";
        }
    }
    SetDefaultSortOrder();
    $('#CampaignData').tablesorter();
}
function Sort(cell, sortOrder) {
    var sorting = [[cell.cellIndex, sortOrder]];
    $("#CampaignData").trigger("sorton", [sorting]);
    if (sortOrder == 0) {
        sortOrder = 1;
        cell.className = "sortDesc";
    }
    else {
        sortOrder = 0;
        cell.className = "sortAsc";
    }
    cell.setAttribute("onclick", "Sort(this, " + sortOrder + ")");
    cell.onclick = function () { Sort(this, sortOrder); };
    document.getElementById("Gridcontainer").scrollTop = 0;
}
function SetDefaultSortOrder() {
    var headers = CampaignData.getElementsByTagName("th");
    for (var i = 0; i < headers.length; i++) {
        headers[i].className = "sortDesc";
    }
}
$("#btnPopUp").click(function () {
    var rd = $('input:radio[id=rdByProcess]').attr('checked', true);
    $('input:radio[name=Fill2]').attr('checked', false);
    if ($("#rdByAgents").checked == true) {
        alert('test');
    }

    //$('#cboAgentName').empty();
    var strAgent = "";
    FillProcess();
    $("#cboProcess").val(ProcessId);
    GetFilter(UserId);
});
function FillProcess() {
    var hdnAgent = $('#hdnUserId').val();
    $.ajax({
        type: "POST",
        url: "ActivityDashboard.aspx/BindProcess",
        contentType: "application/json; charset=utf-8",
        dataType: "JSON",
        async: false,
        data: "{'AgentId':'" + hdnAgent + "'}",
        success: FillLoggedUserProcess,
        error: function (XHR, errStatus, errorThrown) {
            var err = JSON.parse(XHR.responseText);
            errorMessage = err.Message;
            alert("Error: " + errorMessage);
        },
        failure: function (response) {
            alert(response.responseText);
        },
    });
}
var strAgent = "";
function FillLoggedUserProcess(response) {
    strAgent = response.d;
    if (strAgent != "") {
        var Process = jQuery.parseJSON(strAgent);
        $('#cboProcess').empty();
        if (Process != null) {
        
            $('#cboProcess').append($('<option>').text("Select process").attr('value', -1));
            var datalength = Process.length;
            for (var i = 0; i <= datalength - 1; i++) {
                $('#cboProcess').append($('<option>').text(Process[i].ProcessName).attr('value', Process[i].Processid));
            }
        }
    }
   
}

/* Start: Added by Gaurav Dutt 15 Dec 2015 */
function FillCampaigns(ProcessId) {
    var hdnAgent = $('#hdnUserId').val();
    var hdnProcess = ProcessId;
    $.ajax({
        type: "POST",
        url: "ActivityDashboard.aspx/BindCampaigns",
        contentType: "application/json; charset=utf-8",
        dataType: "JSON",
        async: false, 
        data: "{'AgentId':'" + hdnAgent + "','ProcessID':" + ProcessId + "}",
        success: FillLoggedUserCampaigns,
        error: function (XHR, errStatus, errorThrown) {
            var err = JSON.parse(XHR.responseText);
            errorMessage = err.Message;
            alert("Error: " + errorMessage);
        },
        failure: function (response) {
            alert(response.responseText);
        },
    });
}
var strResult = "";
function FillLoggedUserCampaigns(response) {
    strResult = response.d;
    if (strResult != "") {
        var Campaigns = jQuery.parseJSON(strResult);
        $('#cboCampaigns').empty();
        if (Campaigns != null) {
            $('#cboCampaigns').append($('<option>').text("All").attr('value', -1));
            var datalength = Campaigns.length;
            for (var i = 0; i <= datalength - 1; i++) {
                $('#cboCampaigns').append($('<option>').text(Campaigns[i].Name).attr('value', Campaigns[i].campaignid));
            }
        }
    }
}

$("#cboCampaigns").change(function () {
    var strAgent = "";
    if ($('#cboCampaigns').val() == -1) {
//        alert("Please Select Campaign");
//        $('#cboAgentName').empty();
//        return false;
        GetAgentsOfProcess($("#cboProcess").val());
    }
    else{
    GetAgentsOfCampaign($("#cboCampaigns").val());
    }
});

function GetAgentsOfCampaign(CampaignId) {
    $.ajax({
        url: "ActivityDashboard.aspx/BindAgent",
        dataType: "json",
        async: false,
        type: "POST",
        data: "{'CampaignId':'" + CampaignId + "'}",
        contentType: "application/json; charset=utf-8",
        success: BindProcessAgents,
        error: function (XHR, errStatus, errorThrown) {
            var err = JSON.parse(XHR.responseText);
            errorMessage = err.Message;
            alert("Error: " + errorMessage);
        },
        failure: function (response) {
            alert(response.responseText);
        },
    });
}
function BindProcessAgents(response) {
    strAgent = response.d;
    if (strAgent != "") {
        var Process = jQuery.parseJSON(strAgent);
        $('#cboAgentName').empty();
        if (Process != null) {
            $('#cboAgentName').append($('<option>').text("All").attr('value', -1));
            var datalength = Process.length;
            for (var i = 0; i <= datalength - 1; i++) {
                $('#cboAgentName').append($('<option>').text(Process[i].AgentName).attr('value', Process[i].AgentId));
            }
        }
    }
    else
    {
        // Added by Gaurav Dutt 28/Dec/2015 when no agent found in campaign.
        $('#cboAgentName').empty();
        $('#cboAgentName').append($('<option>').text("Please Select Agent Name").attr('value', 1));
    }
}
$("#cboProcess").change(function () {
    var strAgent = "";
    if ($('#cboProcess').val() == -1) {
        alert("Please Select ProcessId");
        $('#cboAgentName').empty();
        return false;
    }
    FillCampaigns($("#cboProcess").val());
    GetAgentsOfProcess($("#cboProcess").val());
});






/* End: Added by Gaurav Dutt 15 Dec 2015 */

//$("#btnPopUp").click(function () {
//    var rd = $('input:radio[id=rdByProcess]').attr('checked', true);
//    $('input:radio[name=Fill2]').attr('checked', false);
//    if ($("#rdByAgents").checked == true) {
//        alert('test');
//    }

//    $('#cboAgentName').empty();
//    var strAgent = "";
//    FillProcess();
//    $("#cboProcess").val(ProcessId);
//});
function GetAgentsOfProcess(ProcessId) {
    $.ajax({
        url: "ActivityDashboard.aspx/BindAgentGrid",
        dataType: "json",
        type: "POST",
        data: "{'ProcessId':'" + ProcessId + "'}",
        contentType: "application/json; charset=utf-8",
        success: BindProcessAgents,
        error: function (XHR, errStatus, errorThrown) {
            var err = JSON.parse(XHR.responseText);
            errorMessage = err.Message;
            alert("Error: " + errorMessage);
        },
        failure: function (response) {
            alert(response.responseText);
        },
    });
}
//function BindProcessAgents(response) {
//    strAgent = response.d;
//    if (strAgent != "") {
//        var Process = jQuery.parseJSON(strAgent);
//        $('#cboAgentName').empty();
//        if (Process != null) {
//            $('#cboAgentName').append($('<option>').text("All").attr('value', -1));
//            var datalength = Process.length;
//            for (var i = 0; i <= datalength - 1; i++) {
//                $('#cboAgentName').append($('<option>').text(Process[i].AgentName).attr('value', Process[i].AgentId));
//            }
//        }
//    }
//}

//---- For Loading 
$("#btnGet").click(function () {
    if (RadioBtnVal == 1) {
        if ($('#cboProcess').val() == -1) {
            alert("Please Select ProcessId");
            return false;
        }
        var ProId = $("#cboProcess").val();
        ProcessName = $("#cboProcess option:selected").text();
        var ProName = $("#cboProcess option:selected").text();
        var CampName = $("#cboCampaigns option:selected").text();
        SelectedAgentId = ''
        $('#hdnProcessId').val(ProId);
        //$('#spnProcessName').text(ProName);
        $('#spnProcessName').text(""+ ProName +"'s");
        $('#spnCampaignName').text(" [" + CampName +"]");
        
        $('#hdnCampaignId').val($("#cboCampaigns").val());
        SelectedCampaignId = $("#cboCampaigns").val(); 

        SaveFilter(UserId, RadioBtnVal, ProId, SelectedAgentId, SelectedCampaignId);

        var str = new Array();
        GetData(datefrom, dateto, groupby, ProId, SelectedCampaignId);
        var str1 = "";
        var str = "";
        GetGridData(datefrom, dateto, ProId, SelectedCampaignId);

        $('#DisableDiv').fadeTo('slow', .6);
        $('#DisableDiv').append('<div style="background-color:#E6E6E6;position: absolute;top:0;left:0;width: 100%;height:110%;z-index:1001;-moz-opacity: 0.8;opacity:.80;filter: alpha(opacity=80);"><img src="../_assets/img/loading1.gif" style="position:fixed;top:40%;left:46%; width:120px;"/></div>');
        setTimeout(function () {
        }, 100)
    }
    if (RadioBtnVal == 2) {
        if ($('#cboProcess').val() == -1) {
            alert("Please Select ProcessId");
            return false;
        }
        if ($('#cboAgentName').text() == "Please Select Agent Name") {
            alert("Please Select Agent Name");
            return false;
        }
//Commented by Gaurav Dutt 17 Dec 2015 for Agent drop down All item.        
        
//        if ($('#cboAgentName').val() == -1) {
//            alert("Please Select Agent");
//            return false;
//        }
        var ProId = $("#cboProcess").val();
        ProcessName = $("#cboProcess option:selected").text();
        var ProName = $("#cboProcess option:selected").text();
        var CampName = $("#cboCampaigns option:selected").text();
        var AgentName = $("#cboAgentName option:selected").text();
        $('#hdnCampaignId').val($("#cboCampaigns").val()); 
        SelectedCampaignId = $("#cboCampaigns").val(); 
        SelectedAgentId = $("#cboAgentName").val();
        SaveFilter(UserId, RadioBtnVal, ProId, SelectedAgentId, SelectedCampaignId);

        $('#hdnProcessId').val(ProId);
        $('#spnProcessName').text(ProName);
        $('#spnCampaignName').text("[" + CampName + " - "+ AgentName + "]");
        //$('#spnCampaignName').text(AgentName);
        
        var str = new Array();
        GetData(datefrom, dateto, groupby, ProId, SelectedAgentId, SelectedCampaignId);
        var str1 = "";
        var str = "";
        GetGridData(datefrom, dateto, ProId, SelectedAgentId, SelectedCampaignId);

        $('#DisableDiv').fadeTo('slow', .6);
        $('#DisableDiv').append('<div style="background-color:#E6E6E6;position: absolute;top:0;left:0;width: 100%;height:110%;z-index:1001;-moz-opacity: 0.8;opacity:.80;filter: alpha(opacity=80);"><img src="../_assets/img/loading1.gif" style="position:fixed;top:40%;left:46%; width:120px;"/></div>');
        setTimeout(function () {
        }, 100)
    }
});

$("#rdByAgents").click(function () {
    RadioBtnVal = $("input[id=rdByAgents]:checked").val();
    $("#lblAgents").css('display', 'block');
    $("#cboAgentName").css('display', 'block');
});

$("#rdByProcess").click(function () {
    RadioBtnVal = $("input[id=rdByProcess]:checked").val();
    $("#lblAgents").css('display', 'none');
    $("#cboAgentName").css('display', 'none');
});

function SaveFilter(Userid, Filter, Process, SelectedAgent, SelectedCampaignId) {
    $.ajax({
        url: "ActivityDashboard.aspx/SaveFilter",
        dataType: "json",
        type: "POST",
        data: "{'UserId':'" + Userid + "','SelectedFilter':" + Filter + ",'SelectedProcess':" + Process + ",'SelectedAgent':'" + SelectedAgent + "','SelectedCampaignId':'" + SelectedCampaignId + "'}",
        contentType: "application/json; charset=utf-8",
        error: function (XHR, errStatus, errorThrown) {
            var err = JSON.parse(XHR.responseText);
            errorMessage = err.Message;
            alert("Error: " + errorMessage);
        },
        failure: function (response) {
            alert(response.responseText);
        },
    });
};
function GetFilter(Userid) {
    $.ajax({
        url: "ActivityDashboard.aspx/GetUserFilter",
        dataType: "json",
        type: "POST",
        data: "{'UserId':'"+ UserId+"'}",
        contentType: "application/json; charset=utf-8",
        success: SetFilterValue,
        error: function (XHR, errStatus, errorThrown) {
            var err = JSON.parse(XHR.responseText);
            errorMessage = err.Message;
            alert("Error: " + errorMessage);
        },
        failure: function (response) {
            alert(response.responseText);
        },
    });
};
function SetFilterValue(response) {
    strAgent = response.d;
    if (strAgent != "") {
        var Process = jQuery.parseJSON(strAgent);
        $('#hdnProcessId').val(ProcessId);
        $('#spnProcessName').text(ProcessName);
        //Set value in hidden fileds.
        $('#hdnProcessId').val(Process[0].ProcessId);
        ProcessId = Process[0].ProcessId;
        $('#hdnCampaignId').val(Process[0].CampaignId);
        $('#hdnAgentId').val(Process[0].SelectedAgent);
    
        if (Process[0].SelectedFilter == 1){
            $("#rdByProcess").prop( "checked", true );
            RadioBtnVal = "1";
            RadioBtnVal = $("input[id=rdByProcess]:checked").val();
            $("#lblAgents").css('display', 'none');
            $("#cboAgentName").css('display', 'none');
            $('#spnProcessName').text(""+ Process[0].ProcessName +"'s");
            $('#spnCampaignName').text(" [" + Process[0].CampaignName +"]");
            FillCampaigns(Process[0].ProcessId);
            $("#cboProcess").val(Process[0].ProcessId);
            $("#cboCampaigns").val(Process[0].CampaignId);
        }
        else if (Process[0].SelectedFilter == 2){
            $("#rdByAgents").prop( "checked", true );
            RadioBtnVal = "2";
            RadioBtnVal = $("input[id=rdByAgents]:checked").val();
            $("#lblAgents").css('display', 'block');
            $("#cboAgentName").css('display', 'block');
            $('#spnProcessName').text(Process[0].ProcessName);
            $('#spnCampaignName').text("[" + Process[0].CampaignName + " - "+ Process[0].SelectedAgentName + "]");
            FillCampaigns(Process[0].ProcessId);
            if (Process[0].SelectedAgent.trim() == "-1")
            {
                GetAgentsOfProcess(Process[0].ProcessId);
            }
            else
            {
                GetAgentsOfCampaign(Process[0].CampaignId);
            }
            $("#cboProcess").val(Process[0].ProcessId);
            $("#cboCampaigns").val(Process[0].CampaignId);
            $("#cboAgentName").val(Process[0].SelectedAgent);
        }
        
    }
}
$(".prev").click(function() {
        if ($("#cboperiod").val() == "1") {
            groupby = 1;
            if (curmonth == 0) {
                curyear = curyear - 1;
                curmonth = 11;
            }
            else {
                curmonth = curmonth - 1;
            }
            $('#txtdate').val(monthNames[curmonth] + " " + curyear);
            curmonthNew = curmonth + 1;
            if (curmonthNew < 10) {
                curmonthNew = "0" + curmonthNew;
                //curmonthNew = curmonthNew;
            }
            var daysInMonth = new Date(curyear, curmonthNew, 1, -1).getDate();
            datefrom = curyear.toString() + curmonthNew.toString() + "01";
            dateto = curyear.toString() + curmonthNew.toString() + daysInMonth;
        }
        else if ($("#cboperiod").val() == "3") {
        //debugger;
            groupby = 3;
            date.setDate(date.getDate() - 1);
            var newcurdate = date.getDate();
            var newcurmonth = date.getMonth();
            var newcurmonthfix = date.getMonth();
            var newcuryear = date.getFullYear();
            var newcuryearfix = date.getFullYear();
            day = newcurdate;
            if (curmonthNew < 10) {
                curmonthNew = "0" + curmonthNew;
                //curmonthNew =  curmonthNew;
            }
            if (newcurdate < 10) {
                newcurdate = "0" + newcurdate;
                //newcurdate = newcurdate;
            }
            $('#txtdate').val(newcurdate + " " + monthNames[newcurmonth] + " " + newcuryear);
            newcurmonth = newcurmonth + 1;
            if (newcurmonth < 10) {
                newcurmonth = "0" + newcurmonth;
                //curmonthNew =  curmonthNew;
            }
            datefrom = newcuryear.toString() + newcurmonth.toString() + newcurdate;
            dateto = newcuryear.toString() + newcurmonth.toString() + newcurdate;
        }
        else if ($("#cboperiod").val() == "2") {
            groupby = 2;
            var newcurmonth;
            var newcuryear;
            weekdate.setDate(weekdate.getDate() - 13);
            first = weekdate.getDate() - weekdate.getDay() + 1;
            firstday = new Date(weekdate.setDate(first)).toDateString();
            newcurmonth = weekdate.getMonth() + 1;
            newcuryear = weekdate.getFullYear();
            if (newcurmonth < 10) {
                newcurmonth = "0" + newcurmonth;
                // newcurmonth =  newcurmonth;
            }
            if (first < 10) {
                first = "0" + first;
                //first = first;
            }
            var monthfrom = newcurmonth - 1;
            datefrom = newcuryear.toString() + newcurmonth.toString() + first;
            weekdate.setDate(weekdate.getDate() + 6);
            last = weekdate.getDate();

            lastday = new Date(weekdate.setDate(last)).toDateString();
            newcurmonth = weekdate.getMonth() + 1;
            newcuryear = weekdate.getFullYear();
            if (newcurmonth < 10) {
                newcurmonth = "0" + newcurmonth;
               // newcurmonth =  newcurmonth;
            }
            if (last < 10) {
                last = "0" + last;
                //last = last;
            }
            var monthto = newcurmonth - 1;
            dateto = newcuryear.toString() + newcurmonth.toString() + last;
            $('#txtdate').val(shortmonth[monthfrom] + ' ' + first + " - " + shortmonth[monthto] + ' ' + last + "," + newcuryear);
            $("#time").html('<span>time by week</span>');
        }

        // ----- For Loading data
           $('#DisableDiv').fadeTo('slow', .6);
            $('#DisableDiv').append('<div style="background-color:#E6E6E6;position: absolute;top:0;left:0;width: 100%;height:110%;z-index:1001;-moz-opacity: 0.8;opacity:.80;filter: alpha(opacity=80);"><img src="../_assets/img/loading1.gif" style="position:fixed;top:40%;left:46%;width:120px;"/></div>');
            setTimeout(function() 
            { 
            }, 100)
         //------------------   
          var str = new Array();
          var str1 = "";
          GetData(datefrom, dateto, groupby,ProcessId);
          GetGridData(datefrom, dateto,ProcessId);               
    });
    
$(".next").click(function() {
        if ($("#cboperiod").val() == "1") {       
            groupby = 1;
            if (curmonth == 11) {
                curyear = curyear + 1;
                curmonth = 0;
            }
            else {
                curmonth = curmonth + 1;
            }
            if (curmonth > curmonthfix && curyear == curyearfix) {
                curmonth = curmonth - 1;
                return false;
            }
            else {
                $('#txtdate').val(monthNames[curmonth] + " " + curyear);
            }
            curmonthNew = curmonth + 1;
            if (curmonthNew < 10) {
                curmonthNew = "0" + curmonthNew;
                 //curmonthNew = curmonthNew;
            }
            var daysInMonth = new Date(curyear, curmonthNew, 1, -1).getDate();
            datefrom = curyear.toString() + curmonthNew.toString() + "01";
            dateto = curyear.toString() + curmonthNew.toString() + daysInMonth;
        }
        else if ($("#cboperiod").val() == "3") {       
            groupby = 3;
            date.setDate(date.getDate() + 1);
            var newcurdate = date.getDate();
            var newcurmonth = date.getMonth();
            var newcurmonthfix = date.getMonth();
            var newcuryear = date.getFullYear();
            var newcuryearfix = date.getFullYear();
            if (curmonthNew < 10) {
                //curmonthNew = "0" + curmonthNew;
                curmonthNew =  curmonthNew;
            }
            if (newcurdate < 10) {
                newcurdate = "0" + newcurdate;
               //newcurdate =  newcurdate;
            }
            if (newcurdate > curdatefix && newcurmonth == curmonthfix && newcuryear == newcuryearfix) {
                newcurdate = newcurdate - 1;
                date.setDate(date.getDate() - 1);
                return false;
            }
            else {
                $('#txtdate').val(newcurdate + " " + monthNames[newcurmonth] + " " + newcuryear);
                newcurmonth = newcurmonth + 1;
            }
             if (newcurmonth < 10) {
                //curmonthNew = "0" + curmonthNew;
                newcurmonth =  "0" + newcurmonth;
            }
            datefrom = newcuryear.toString() + newcurmonth.toString() + newcurdate;
            dateto = newcuryear.toString() + newcurmonth.toString() + newcurdate;

        }
        else if ($("#cboperiod").val() == "2") {       
            groupby = 2;          
            var newcurmonth;
            var newcuryear;
            weekdate.setDate(weekdate.getDate() + 1);
            first = weekdate.getDate() - weekdate.getDay() + 1;
            firstday = new Date(weekdate.setDate(first)).toDateString();
            newcurmonth = weekdate.getMonth();
            newcuryear = weekdate.getFullYear();           
            if (first < 10) {
                first = "0" + first;
                //first = first;
            }
            var monthfrom = (newcurmonth + 1);
             if (newcurmonth < 10) {
                newcurmonth = "0" + newcurmonth;
            }
            var monthfrom1=monthfrom;
             if (monthfrom1 < 10) {
                monthfrom1 = "0" + monthfrom1;
            }
            datefrom = newcuryear.toString() + monthfrom1.toString() + first;
            weekdate.setDate(weekdate.getDate() + 6);
            last = weekdate.getDate();

            lastday = new Date(weekdate.setDate(last)).toDateString();
            newcurmonth = weekdate.getMonth();
            newcuryear = weekdate.getFullYear();
            if (last < 10) {
                last = "0" + last;
                //last = last;
            }
            var monthto = (newcurmonth + 1);
             if (newcurmonth < 10) {
                newcurmonth = "0" + newcurmonth;
            }
            var monthto1=monthto;
             if (monthto1 < 10) {
                monthto1 = "0" + monthto1;
            }
            dateto = newcuryear.toString() + monthto1.toString() + last;
            monthfrom=monthfrom-1;
            monthto=monthto-1;
            $('#txtdate').val(shortmonth[monthfrom] + ' ' + first + " - " + shortmonth[monthto] + ' ' + last + "," + curyear);
            $("#time").html('<span>time by week</span>');
        }
         // ----- For Loading data
           $('#DisableDiv').fadeTo('slow', .6);
            $('#DisableDiv').append('<div style="background-color:#E6E6E6;position: absolute;top:0;left:0;width: 100%;height:110%;z-index:1001;-moz-opacity: 0.8;opacity:.80;filter: alpha(opacity=80);"><img src="../_assets/img/loading1.gif" style="position:fixed;top:40%;left:46%;width:120px;"/></div>');
            setTimeout(function() 
            { 
            }, 100)
         //------------------   
            var str = new Array();
            GetData(datefrom, dateto, groupby,ProcessId);
            var str1 = "";
            GetGridData(datefrom, dateto,ProcessId);
    });
    
    //============================
    
function CatIDName(Did, cat) {
    if (Did != 4) {
        $('#AppDetails').show();
        $('#BreakDetails').hide();
        GetGridData1(Did, cat);
        $('#BTNTExt').text("Save Category");
        CategoryResponse();
    }
    else {
        if (cat == "Non Productive Break") {
            $('#AppDetails').hide();
            $('#BreakDetails').show();
            var isbreakproductive = 0;
            GetBreak(isbreakproductive, cat)
            $('#BTNTExt').text("Save Break Type");
            BreakCategory();

        }
        if (cat == "Productive Break") {
            $('#AppDetails').hide();
            $('#BreakDetails').show();
            var isbreakproductive = 1;
            GetBreak(isbreakproductive, cat)
            $('#BTNTExt').text("Save Break Type");
            //$('#FillBreak').text('Show');
            BreakCategory();
        }
    }
}


function GetBreak(IsProductiveBreak, catname) {
    // ----- For Loading data
    $('#DisableDiv').fadeTo('slow', .6);
    $('#DisableDiv').append('<div style="background-color:#E6E6E6;position: absolute;top:0;left:0;width: 100%;height:110%;z-index:1001;-moz-opacity: 0.8;opacity:.80;filter: alpha(opacity=80);"><img src="_assets/img/loading1.gif" style="position:fixed;top:40%;left:46%;width:120px;"/></div>');
    setTimeout(function () { }, 100);
    //------------------   
    var hdval = $("#hdnProcessId").val();
    $("#spanstatus").text(catname + " - Details");
    $.ajax({

        url: "ActivityDashboard.aspx/GetBreakType",
        dataType: "json",
        type: "POST",
        data: "{'datefrom':'" + datefrom + "','dateto':'" + dateto + "','processid':'" + hdval + "','IsBreakProductive':'" + IsProductiveBreak + "','Agentid':'" + SelectedAgentId + "'}",
        contentType: "application/json; charset=utf-8",
        success: bindBreaktyperesponse,
        error: function (XHR, errStatus, errorThrown) {
            var err = JSON.parse(XHR.responseText);
            errorMessage = err.Message;
            alert("Error: " + errorMessage);
        },
        failure: function (response) {
            alert(response.responseText);
        },
    });
}
function bindBreaktyperesponse(response) {
    str2 = response.d;
    BindBreakTypeTable(str2);


}
function BindBreakTypeTable(str2) {
    $("#BreakDetails").empty();
    if (str2 != "") {
        $("#BreakDetails").empty();
        var data = jQuery.parseJSON(str2);
        var strname = "";
        if (data != null) {
            var datalength = data.length;
            var gvcol = "";
            gvcol = "<thead><tr >";
            gvcol = gvcol + "<th>Select</th>";
            for (strname in data[0]) {
                if (strname != "AppName" && strname != "BreakType") {
                    gvcol = gvcol + "<th>" + strname + "</th>";
                }
                else {
                    gvcol = gvcol + "<th style='display: none;'>" + strname + "</th>";
                }
            }
            gvcol = gvcol + "</tr></thead>";
            $("#BreakDetails").append(gvcol);
            gvrow = "<tbody>";
            for (var i = 0; i <= datalength; i += 1) {
                var gvrow = "";
                gvrow = gvrow + "<tr >";
                if (data[i] != null) {
                    gvrow = gvrow + "<td data-title=" + '"' + "Select" + '"' + " ><input id='Checkbox1' type='checkbox' /></td>"
                }
                for (strname in data[i]) {

                    if (data[i][strname] == null) {
                        gvrow = gvrow + "<td data-title=" + '"' + strname + '"' + ">0</td>";
                    }

                    else {
                        if (strname == "Duration") {
                            gvrow = gvrow + "<td data-title=" + '"' + strname + '"' + " >" + convertsecond(data[i][strname]) + "</td>";

                        }
                            //else if (strname == "AppName") {
                            //    gvrow = gvrow + "<td data-title=" + '"' + strname + '"' + " style='display: none;'>" + (data[i][strname]) + "</td>";
                            //}
                        else if (strname == "BreakType") {
                            gvrow = gvrow + "<td data-title=" + '"' + strname + '"' + " style='display: none;'>" + (data[i][strname]) + "</td>";
                        }


                        else {

                            gvrow = gvrow + "<td data-title=" + '"' + strname + '"' + ">" + (data[i][strname]) + "</td>";
                        }
                    }
                }
                gvrow = gvrow + "</tr>";
                $("#BreakDetails").append(gvrow);
            }
            gvrow = gvrow + "</tbody></table>";

            $('#DetailDialog').modal('show')
        }
    }
    $('#DisableDiv').html("");
}
//Function For Fill dropdown BreakCategory
function BreakCategory() {
    $('#DropDownList1').empty();
    $('#DropDownList1').append($('<option>').text("Select BreakType").attr('value', -1));
    $('#DropDownList1').append($('<option>').text("Non Productive").attr('value', 0));
    $('#DropDownList1').append($('<option>').text("Productive ").attr('value', 1));


}

//Insert BreakDescription Into Database
function InsertBreakDescription(Id, BID) {
    $.ajax({
        type: "POST",
        url: "ActivityDashboard.aspx/InsertBreakDescription",
        contentType: "application/json; charset=utf-8",
        dataType: "JSON",
        data: "{'CateogryId':'" + Id + "','BReakId':'" + BID + "'}",

        //success: FillCatgeory,
        error: function (XHR, errStatus, errorThrown) {
            var err = JSON.parse(XHR.responseText);
            errorMessage = err.Message;
            alert("Error: " + errorMessage);
        },
        failure: function (response) {
            alert(response.responseText);
        },
    });
}
//call function on link click for fill data into dropdown
function CategoryResponse() {
    var hdnAgent = $('#hdnAgentId').val();
    $.ajax({
        type: "POST",
        url: "ActivityDashboard.aspx/GetCategory",
        contentType: "application/json; charset=utf-8",
        dataType: "JSON",
        //data: "{}",
        success: FillCatgeory,
        error: function (XHR, errStatus, errorThrown) {
            var err = JSON.parse(XHR.responseText);
            errorMessage = err.Message;
            alert("Error: " + errorMessage);
        },
        failure: function (response) {
            alert(response.responseText);
        },
    });
}
//Fill Popup Drop Down On link click
function FillCatgeory(response) {
    strAgent = response.d;
    if (strAgent != "") {
        var Process = jQuery.parseJSON(strAgent);
        $('#DropDownList1').empty();
        if (Process != null) {
            $('#DropDownList1').append($('<option>').text("Select Category").attr('value', -1));
            var datalength = Process.length;
            for (var i = 0; i <= datalength - 1; i++) {
                $('#DropDownList1').append($('<option>').text(Process[i].Description).attr('value', Process[i].ID));
            }
        }
    }
}
//Button click event for get popup grid chek row value
$('#BTNTExt').click(function () {
    var ab = $('#BTNTExt').text();
    if (ab == "Save Category") {
        var element = document.getElementById("DropDownList1");
        var value = $("#DropDownList1").val();
        if ($('input:checkbox').is(':checked') && value > -1) {
            $('input:checkbox').each(function () {
                var e = document.getElementById("DropDownList1");
                var a = e.options[e.selectedIndex].value;
                $this = $(this);
                if ($(this).is(":checked")) {
                    var one = ($this.parent().siblings('td').eq(0).text());
                    var two = $this.parent().siblings('td').eq(1).text();
                    var three = $this.parent().siblings('td').eq(2).text();
                    InsertCategory(a, one, two);
                    $('input:checkbox:checked').hide();
                    ($this.parent().siblings('td')).hide();
                }
            });
        }
        else {
            alert("Please Select the Category");
        }
    }

    else {
        var element = document.getElementById("DropDownList1");
        var value = $("#DropDownList1").val();
        if ($('input:checkbox').is(':checked') && value > -1) {
            $('input:checkbox').each(function () {
                var e = document.getElementById("DropDownList1");
                var a = e.options[e.selectedIndex].value;
                $this = $(this);
                if ($(this).is(":checked")) {
                    var one = ($this.parent().siblings('td').eq(0).text());
                    var two = $this.parent().siblings('td').eq(1).text();
                    var three = $this.parent().siblings('td').eq(2).text();

                    InsertBreakDescription(a, one);
                    $('input:checkbox:checked').hide();
                    ($this.parent().siblings('td').hide());
                    //location.reload(true);
                }
            });
        }
        else {
            alert("Please Select the Category");
        }
    }

});

//Fill checked appname n app tittle on database
function InsertCategory(Id, apptittle, Appname) {
    $.ajax({
        type: "POST",
        url: "ActivityDashboard.aspx/InsertCateogry",
        contentType: "application/json; charset=utf-8",
        dataType: "JSON",
        //data: "{'Cateogry':'" + Id + "','Appname':'" + Appname + "','AppTittle':'" + apptittle + "'}",
       data: "{'Cateogry':'" + Id + "','Appname':'" + Appname + "','AppTittle':'" + apptittle + "','PID':'" + ProcessId + "'}",

        //success: FillCatgeory,
        error: function (XHR, errStatus, errorThrown) {
            var err = JSON.parse(XHR.responseText);
            errorMessage = err.Message;
            alert("Error: " + errorMessage);
        },
        failure: function (response) {
            alert(response.responseText);
        },
    });
}