﻿var datefrom = ""; var dateto = ""; var curmonthNew = "";
var date = new Date();
var curdate = date.getDate();
var curdatefix = date.getDate();
var curmonth = date.getMonth();
var curmonthfix = date.getMonth();
var curyear = date.getFullYear();
var curyearfix = date.getFullYear();
curmonthNew = curmonth + 1;
var monthNames = ["January", "February", "March",
"April", "May", "June",
"July", "August", "September",
"October", "November", "December"
];
var groupby = 0;

$(document).ready(function() {
$(".tab").hide();
    if (curmonthNew < 10) {
        curmonthNew = "0" + curmonthNew;
    }
    load();
    $(".prev").click(function() {
    $("#divvolumelabel").html('<span>Forecast vs Actual Volume</span>');
    $("#divAHTlabel").html('<span>Forecast vs Actual AHT</span>');
    if ($("#cboperiod").val() == "1") {
        $("#AgentStatus").hide();
        $("#divvolumelabel").hide();
        groupby = 1;
        if (curmonth == 0) {
            curyear = curyear - 1;
            curmonth = 11;
        }
        else {
            curmonth = curmonth - 1;
        }
        $('#txtdate').val(monthNames[curmonth] + " " + curyear);
        curmonthNew = curmonth + 1;
        if (curmonthNew < 10) {
            curmonthNew = "0" + curmonthNew;
        }
        var daysInMonth = new Date(curyear, curmonthNew, 1, -1).getDate();
        datefrom = curyear.toString() + curmonthNew.toString() + "01";
        dateto = curyear.toString() + curmonthNew.toString() + daysInMonth;
        $("#monthlycall").show();
        $("#divvolumelabel").show();
    }
    else if ($("#cboperiod").val() == "3") {
        //$("#AgentStatus").hide();
        $("#monthlycall").hide();
        groupby = 3;
        date.setDate(date.getDate() - 1);
        var newcurdate = date.getDate();
        var newcurmonth = date.getMonth();
        var newcurmonthfix = date.getMonth();
        var newcuryear = date.getFullYear();
        var newcuryearfix = date.getFullYear();
        day = newcurdate;

        //$('#txtdate').val(monthNames[curmonth] + " " + curyear);

        if (curmonthNew < 10) {
            curmonthNew = "0" + curmonthNew;
        }
        if (newcurdate < 10) {
            newcurdate = "0" + newcurdate;
        }
        
        $('#txtdate').val(newcurdate + " " + monthNames[newcurmonth] + " " + newcuryear);
        newcurmonth=newcurmonth+1;
        datefrom = newcuryear.toString() + newcurmonth.toString() + newcurdate;
        dateto = newcuryear.toString() + newcurmonth.toString() + newcurdate;
    }

    var str = new Array();
    GetData(datefrom, dateto, groupby);
});
$(".next").click(function() {
$("#divvolumelabel").html('<span>Forecast vs Actual Volume</span>');
$("#divAHTlabel").html('<span>Forecast vs Actual AHT</span>');
    if ($("#cboperiod").val() == "1") {
    $("#AgentStatus").hide();
    
        groupby = 1;
        if (curmonth == 11) {
            curyear = curyear + 1;
            curmonth = 0;

        }
        else {
            curmonth = curmonth + 1;
        }
        if (curmonth > curmonthfix && curyear == curyearfix) {
            curmonth = curmonth - 1;
            return false;
        }
        else {
            $('#txtdate').val(monthNames[curmonth] + " " + curyear);
            //return true;
        }
        curmonthNew = curmonth + 1;
        if (curmonthNew < 10) {
            curmonthNew = "0" + curmonthNew;
        }
        var daysInMonth = new Date(curyear, curmonthNew, 1, -1).getDate();
        datefrom = curyear.toString() + curmonthNew.toString() + "01";
        dateto = curyear.toString() + curmonthNew.toString() + daysInMonth;
        $("#monthlycall").show();
    }
    else if ($("#cboperiod").val() == "3") {
    //$("#AgentStatus").hide();
    $("#monthlycall").hide();
        groupby = 3;
         
//        if(curdate==30 && curmonth < newcurmonth)
//        {
//        date.setDate(date.getDate());
//        }
//        else if(curdate==31 && curmonth < newcurmonth)
//        {
//        date.setDate(date.getDate());
//        }
//        else
//        {
         date.setDate(date.getDate()+1);
//        }
        var newcurdate = date.getDate();
        var newcurmonth = date.getMonth();
        var newcurmonthfix = date.getMonth();
        var newcuryear = date.getFullYear();
        var newcuryearfix = date.getFullYear();
       daysInMonth = new Date(newcuryear, curmonthNew, 1, -1).getDate();
              
        if (curmonthNew < 10) {
            curmonthNew = "0" + curmonthNew;
        }
//        newcurdate=newcurdate+1;
        if (newcurdate < 10) {
            newcurdate = "0" + newcurdate;
        }
//        if(curdate==30 && curmonth < newcurmonth)
//        {
//        newcurdate=newcurdate-1;
//        date.setDate(date.getDate() - 1);
//        return false;
//        }
//        else if(curdate==31 && curmonth < newcurmonth)
//        {
//        newcurdate=newcurdate-1;
//        date.setDate(date.getDate() - 1);
//        return false;
//        }
       if (newcurdate > curdatefix && newcurmonth == curmonthfix && newcuryear == newcuryearfix) {
            newcurdate = newcurdate - 1;
            date.setDate(date.getDate() - 1);
            //$('#txtdate').val(newcurdate + " " + monthNames[newcurmonth] + " " + newcuryear);
            return;
        }

        else {
           // newcurdate = newcurdate + 1;
            $('#txtdate').val(newcurdate + " " + monthNames[newcurmonth] + " " + newcuryear);
            newcurmonth=newcurmonth+1;
        }
        datefrom = newcuryear.toString() + newcurmonth.toString() + newcurdate;
        dateto = newcuryear.toString() + newcurmonth.toString() + newcurdate;
    }

    var str = new Array();
    GetData(datefrom, dateto, groupby);
});
$(".close").click(function(){
$("#PieModal").removeClass("modalnew").addClass("modal fade");
});
});
function load() {
    $("#divvolumelabel").html('<span>Forecast vs Actual Volume</span>');
    $("#divAHTlabel").html('<span>Forecast vs Actual AHT</span>');
    if ($("#cboperiod").val() == "1") {
    $("#AgentStatus").hide();
    $("#divvolumelabel").hide();
        groupby = 1;
        $('#txtdate').val(monthNames[curmonth] + " " + curyear);
        if (curdate < 10) {
            curdate = "0" + curdate;
        }
        var daysInMonth = new Date(curyear, curmonthNew, 1, -1).getDate();
        datefrom = curyear.toString() + curmonthNew.toString() + "01";
        dateto = curyear.toString() + curmonthNew.toString() + curdate;
        //$("#time").html('<span>time by day</span>');
        $("#monthlycall").show();
        $("#divvolumelabel").show();
        $("#divlabel").html('<span>Monthly Volume</span>');        
    }
    else if ($("#cboperiod").val() == "3") {
    $("#monthlycall").hide();
        groupby = 3;
        if (curdate < 10) {
            curdate = "0" + curdate;
        }
        datefrom = curyear.toString() + curmonthNew.toString() + curdate;
        dateto = curyear.toString() + curmonthNew.toString() + curdate;
        $('#txtdate').val(curdate + " " + monthNames[curmonth] + " " + curyear);
        var str1="";
        getAgentStatus();
       // $("#time").html('<span>time by hours</span>');
    }
    var str = new Array();
    GetData(datefrom, dateto, groupby);
}

////////////////////////////////////////////
function getAgentStatus()
{
$.ajax({
        url: "Dashboard3.aspx/getAgentStatus",
        dataType: "json",
        type: "POST",
        //data: "{'datefrom':'" + datefrom + "','dateto':'" + dateto + "','groupby':'" + groupby + "'}",
        contentType: "application/json; charset=utf-8",
        success: getstatusresponse,
        error: function (XHR, errStatus, errorThrown) {
            var err = JSON.parse(XHR.responseText);
            errorMessage = err.Message;
            alert("Error: " + errorMessage);
        },
        failure: function (response) {
            alert(response.responseText);
        },
    });
    $("#AgentStatus").show();
    $("#divlabel").html('<span>Agent Status</span>');
}
////////////////////////////////////////////
var agentstatus="";
function getStatusAgent(status)
{
agentstatus=status;
$.ajax({
        url: "Dashboard3.aspx/getStatusAgent",
        dataType: "json",
        type: "POST",
        data: "{'status':'" + status + "'}",
        contentType: "application/json; charset=utf-8",
        success: getstatusAgentresponse,
        error: function (XHR, errStatus, errorThrown) {
            var err = JSON.parse(XHR.responseText);
            errorMessage = err.Message;
            alert("Error: " + errorMessage);
        },
        failure: function (response) {
            alert(response.responseText);
        },
    });
//    $("#AgentStatus").show();
//    $("#divlabel").html('<span>Agent Status</span>');
}

function getstatusAgentresponse(response)
{
    str1 = response.d;    
    fillagents(str1);
}
//////////////////////////////////////////////////
function GetData(datefrom, dateto, groupby) {
    $.ajax({
        url: "Dashboard3.aspx/GetData",
        dataType: "json",
        type: "POST",
        data: "{'datefrom':'" + datefrom + "','dateto':'" + dateto + "','groupby':'" + groupby + "'}",
        contentType: "application/json; charset=utf-8",
        success: getdataresponse,
        error: function (XHR, errStatus, errorThrown) {
            var err = JSON.parse(XHR.responseText);
            errorMessage = err.Message;
            alert("Error: " + errorMessage);
        },
        failure: function (response) {
            alert(response.responseText);
        },
    });
}

function getstatusresponse(response)
{
    str1 = response.d;    
    plotdonut(str1);
}

function getdataresponse(response)
{
    str = response.d;
    filltextdata(str);
    CallVolume(str);
    AHT(str);
    MonthlyCallVolume(str);
}

function PieTooltip(x, y, color, contents) {
    $('<div id="tooltip">' + contents + '</div>').css({
        position: 'absolute',
        display: 'none',
        top: y + 5,
        left: x + 20,
        border: '2px solid ' + color,
        padding: '3px',
        'font-size': '9px',
        'border-radius': '5px',
        'background-color': '#fff',
        'font-family': 'Verdana, Arial, Helvetica, Tahoma, sans-serif',
        'text-align': 'center',
        //'width': '100px',
       // 'margin-left': '450px',
        opacity: 0.9
    }).appendTo("body").fadeIn(200);
}

function pieHover(event, pos, obj) {
   if (obj) {
        percent = parseFloat(obj.series.percent).toFixed(2);      
        $("#hover").html('<span style="font-weight: bold; color: ' + obj.series.color + '">' + obj.series.label + ' (' + percent + '%)</span>');
    }
    else {
        $("#hover").html('');
    }
}

function pieClick(event, pos, obj) {
   if (obj) {
        percent = parseFloat(obj.series.percent).toFixed(2);      
       // alert('' + obj.series.label + ': ' + percent + '%');
       var str1="";
       getStatusAgent(obj.series.label);
      
        //$("#PieModal").css("display", "block");
    }
    else {
       
    }
    
}

function fillagents(str1)
{
var data = jQuery.parseJSON(str1);
    if (data != null) {
        var datalength = data.length;
        $("#ulcat").empty();
        for (var i = 0; i <= datalength - 1; i += 1) {
            var agents = data[i].AgentName;            
            var design = "";
            design = "<li style='list-style: none; width:100%'><span style='width:100%'>" + agents + "</span></li> ";          
            $('#divagent ul').append(design);
        }
        $("#PieModal").removeClass("modal fade").addClass("modalnew");
         $("#spanstatus").text(agentstatus);
        }
}

function plotdonut(str1) {
    //var datadoc = response.d;
    var data = jQuery.parseJSON(str1);
    if (data != null) {
        $.plot($("#AgentStatus"), data,
        {
            series:
            {
                pie:
                {
                    show: true, innerRadius: .3, label:false,  
                    label:
                {
                   show: true,
                    radius: 0.8,
            formatter: function (label, series) {               
                return '<div style="border:1px solid grey;font-size:8pt;text-align:center;padding:3px;color:white;">' +
                +
                Math.round(series.percent) +
                '%</div>';
},
background: {
                opacity: 0.8,
                color: '#000'
            },
                },
                

                },
                
            },
          
            grid: {
                hoverable: true,
                clickable:true,
                borderWidth: 1,              
            },
           
            legend:
                {
                    show: true,
                    margin: 2,
                },
        });
        $("#AgentStatus").bind("plothover", pieHover);
        $("#AgentStatus").bind("plotclick", pieClick);
    }
}

var previousPoint = null,
    previousLabel = null;
function showTooltip(x, y, color, contents) {
    $('<div id="tooltip">' + contents + '</div>').css({
        position: 'absolute',
        display: 'none',
        top: y - 40,
        left: x - 60,
        border: '2px solid ' + color,
        padding: '3px',
        'font-size': '9px',
        'border-radius': '5px',
        'background-color': '#fff',
        'font-family': 'Verdana, Arial, Helvetica, Tahoma, sans-serif',
        'text-align': 'center',
        opacity: 0.9
    }).appendTo("body").fadeIn(200);
}

function barHover(event, pos, item) {
    if (item) {
        if ((previousLabel != item.series.label) || (previousPoint != item.dataIndex)) {
            previousPoint = item.dataIndex;
            previousLabel = item.series.label;
            percent = parseFloat(item.series.percent).toFixed(2);
           
            $("#tooltip").remove();

            var x = item.datapoint[0];
            var y = item.datapoint[1].toString();           
            var color = item.series.color;
            var str = "";
            str="<strong> Hour " + x + "</strong><br>"

            showTooltip(item.pageX, item.pageY, color,
            str +
             "<strong>" + item.series.label + "</strong>: <strong>" + y + "</strong>");
        }
    } else {
        $("#tooltip").remove();
        previousPoint = null;
    }
}
function monthbarHover(event, pos, item) {
    if (item) {
//        if ((previousLabel != item.series.label) || (previousPoint != item.dataIndex)) {
//            previousPoint = item.dataIndex;
//            previousLabel = item.series.label;
//            percent = parseFloat(item.series.percent).toFixed(2);
           
            $("#tooltip").remove();

            var x = item.datapoint[0];
            var y = item.datapoint[1].toString();           
            var color = item.series.color;
            var str = "";
            str="<strong> Day " + x + "</strong><br>"

            showTooltip(item.pageX, item.pageY, color,
            str +
             "<strong>" + item.series.label + "</strong>: <strong>" + y + "</strong>");
//        }
    } else {
        $("#tooltip").remove();
        previousPoint = null;
    }
}

function CallVolume(str) {
    //var datadoc = response.d;
    var data = jQuery.parseJSON(str[2]);
    if(data==null)
    {
        $("#bar-chart").hide();
    }
    if (data != null) {
    $("#bar-chart").show();
        var datalength = data.length;
        var d1 = []; var d2 = [];       
        for (var i = 0; i <= datalength - 1; i += 1) {
                d1.push([data[i].HourlyInterval, data[i].CallRecieved]);
                d2.push([data[i].HourlyInterval, data[i].ForecastCallReceived]);
        }
   var dataset = [
    {
        label: "Call Recieved",
        data: d1,
        bars: {
                show: true,
                barWidth: .2,
                fill: true,
                lineWidth: 1,
                order: 1,
                fillColor:  "#90EE90"
            },
        color: "#90EE90",
//        lines: { show: false }
    },
    {
        label: "Forecast Call Received",
        data: d2,
        color: "#F08080",       
        lines: { show: true, barWidth: .3 },
        bars: { show: false },
    },
        ];
        $.plot($("#bar-chart"), dataset, {
        xaxis: {
//            min: 1,
            tickLength: 0, // hide gridlines
        },
            series: {               
            },
            grid: {
                hoverable: true,                
               borderWidth: 0,                
            },            

            legend:
                {
                    show:false,
                },
            valueLabels: {
                show: true
            }
        });
        $("#bar-chart").bind("plothover", barHover);
    }

} 

function AHT(str) {
    //var datadoc = response.d;
    var data = jQuery.parseJSON(str[3]);
    if(data==null)
    {
        $("#divAHT").hide();
    }
    if (data != null) {
    $("#divAHT").show();
        var datalength = data.length;
        var d1 = []; var d2 = [];       
        for (var i = 0; i <= datalength - 1; i += 1) {
                d1.push([data[i].HourlyInterval, data[i].AHThrs]);
                d2.push([data[i].HourlyInterval, data[i].forcastAHTHrs]);
        }
   var dataset = [
    {
        label: "AHT",
        data: d1,
        bars: {
                show: true,
                barWidth: .2,
                fill: true,
                lineWidth: 1,
                order: 1,
                fillColor:  "#90EE90"
            },
        //yaxis: { min: 0, max: 0, tickLength: 0, ticks: 0, showticks: false },
        //xaxis: { min: 1, max: 50, ticks: 1,order:1 },

        color: "#90EE90",
        lines: { show: false }
    },
    {
        label: "Forecast AHT",
        data: d2,
        xaxis: { min: 0, max: 50, ticks: 1,order:2 },
        color: "#F08080",       
        lines: { show: true, barWidth: .3 },
        bars: { show: false, barWidth: .3, order: 2,},
    },
        ];

        var stack = 0, bars = true, lines = false, steps = false;
        $.plot($("#divAHT"), dataset, {
        xaxis: {
            //min: 0.5,
//          //  max: 50,
////            mode: "hour",
////            timeformat: "%b",
////            tickSize: [1, "hour"],
////            monthNames: ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"],
            tickLength: 0, // hide gridlines
////            axisLabel: 'hour',
////            axisLabelUseCanvas: true,
////            axisLabelFontSizePixels: 12,
////            axisLabelFontFamily: 'Verdana, Arial, Helvetica, Tahoma, sans-serif',
////            axisLabelPadding: 10
        },
            series: {               
//                stack: stack,
//                lines: { show: false },                
//                bars: { show: true, barWidth: .2},
            },
            grid: {
                hoverable: true,                
                borderWidth: 0,                
//                backgroundColor: null,
//                tickColor: "rgba(0,0,0,0)",
//                markings: [{ xaxis: { from: 0, to: 50 }, yaxis: { from: 0, to: 0 }, color: "#000" }],
            },
            multiplebars: true,
            bars: {
                show: true,
                lineWidth: 0,
                fill: true,
                fillColor: { colors: [{ opacity: 1.0 }, { opacity: 1.0 }] },                
            },
            legend:
                {
                    show:false,
                },
            valueLabels: {
                show: true
            }
        });
        $("#divAHT").bind("plothover", barHover);
    }
}

function MonthlyCallVolume(str) {
    //var datadoc = response.d;
    var data = jQuery.parseJSON(str[1]);
    if(data==null)
    {
        $("#monthlycall").hide();
    }
    if (data != null) {
    if(groupby==1)
    {
        $("#monthlycall").show();
        }
        var datalength = data.length;
        var d1 = []; var d2 = [];       
        for (var i = 0; i <= datalength - 1; i += 1) {
                d1.push([data[i].monthday, data[i].callrecieved]);
                d2.push([data[i].monthday, data[i].forecastcallreceived]);
        }
   var dataset = [
    {
        label: "Call Recieved",
        data: d1,
        yaxis: { min: 0, max: 5000, tickLength: 1, ticks: 1, showticks: true,},
        xaxis: { min: 1 },
        points: { symbol: "circle", fillColor: "#AA4643"},
        color: "#AA4643",
        
        lines: { show: true, linewidth:1 }
    },
    {
        label: "Forecast Call Recieved",
        data: d2,
        yaxis: { min: 0, max: 5000, tickLength: 1, ticks: 1, showticks: true,},
        xaxis: { min: 1},
        points: { symbol: "circle", fillColor: "#058DC7"},
        color: "#058DC7",       
        lines: { show: true,linewidth:1 }
    },
        ];

//        var stack = 0, bars = true, lines = false, steps = false;
        $.plot($("#monthlycall"), dataset, {
            series: {               
                //stack: stack,
                lines: { show: true },                
//                bars: { show: false, barWidth: .2},
//                points: { show: true }
            },
            grid: {
                hoverable: true,                
                borderWidth: 1,                
                backgroundColor: null,
//                tickColor: "rgba(0,0,0,0)",
//                markings: [{ xaxis: { from: 0, to: 50 }, yaxis: { from: 0, to: 0 }, color: "#000" }],
            },
            
//            bars: {
//                show: true,
//                lineWidth: 0,
//                fill: true,
//                fillColor: { colors: [{ opacity: 1.0 }, { opacity: 1.0 }] },                
//            },
            legend:
                {
                    show:false,
                },
            valueLabels: {
                show: true
            }
        });
        $("#monthlycall").bind("plothover", monthbarHover);
    }
}

function filltextdata(str) {   
    var data = jQuery.parseJSON(str[0]);
    if (data != null) {
       var callrec=data[0].CallReceived;
       $("#lblCallRcvd").text(callrec);
       $("#lblA1").text(data[0].CallAbondoned);
       $("#lblA2").text(data[0].CallAbondonedPercent);
       $("#lblASA").text(data[0].ASA);
       $("#lblAHT").text(data[0].AHTHRS);
       $("#lblCallAns").text(data[0].CallsAns30Sec);
       $("#lblTmPrsent").text(data[0].TMPresent);
       $("#lblAbsent").text(data[0].TMAbsent);
       $("#lbllongwait").text(data[0].longestwait);
       if(data[0].AHTHRS > 5.0)
       {
       $("#lblAHT").css({"color": "red"});
       }
       else
       {
       $("#lblAHT").css({"color": "green"});
       }
       if(data[0].CallsAns30Sec < 80)
       {
       $("#lblCallAns").css({"color": "red"});
       }
       else
       {
       $("#lblCallAns").css({"color": "green"});
       }
      if(data[0].CallAbondonedPercent > 5)
      {
      $("#lblA1").css({"color": "red"});
      $("#lblA2").css({"color": "red"});
      }
      else
      {
      $("#lblA1").css({"color": "green"});
      $("#lblA2").css({"color": "green"});
      }
    }
}