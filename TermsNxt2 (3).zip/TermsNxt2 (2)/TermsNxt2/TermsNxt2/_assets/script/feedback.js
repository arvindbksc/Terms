﻿$(function() {


    var feedbackTab = {

        speed: 300,
        containerWidth: $('.feedback-panel').outerWidth(),
        containerHeight: $('.feedback-panel').outerHeight(),
        tabHeight: $('.feedback-tab').outerHeight(),
        tabWidth: $('.feedback-tab').outerWidth(),

        init: function() {
            $('.feedback-panel').css('width', feedbackTab.containerHeight + 'px');

            $('a.feedback-tab').click(function(event) {

                if ($('.feedback-panel').hasClass('open')) {
                    $('.feedback-panel').animate({ left: '-' + (feedbackTab.containerWidth - feedbackTab.tabWidth) }, feedbackTab.speed)
                            .removeClass('open');
                } else {
                    $('.feedback-panel').animate({ left: '0' }, feedbackTab.speed)
                            .addClass('open');
                }
                event.preventDefault();
            });
        }
    };

    feedbackTab.init();

    $(".button").click(function() {
        var email = $("input#email").val();
        var message = $("textarea#message").val();
        var response_message = "Thank you for your comment, see ya!"

        var dataString = 'email=' + email + '&message=' + message;

        $.ajax({
            type: "POST",
            url: "sendmail.php",
            data: dataString,
            success: function() {
                $('#form-wrap').html("<div id='response-message'></div>");
                $('#response-message').html("<p>" + response_message + "</p>")
                    .hide()
                    .fadeIn(500)
                    .animate({ opacity: 1.0 }, 1000)
                    .fadeIn(0, function() {
                        $('.feedback-panel')
                        .animate({ left: '-' + (feedbackTab.containerWidth + feedbackTab.tabWidth) },
                        (feedbackTab.speed))
                        .removeClass('open');
                    })


            }
        });
        return false;
    });



});
        
        
