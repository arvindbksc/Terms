﻿var datefrom = ""; var dateto = ""; var curmonthNew = "";
var date = new Date();
var curdate = date.getDate();
var curdatefix = date.getDate();
var curmonth = date.getMonth();
var curmonthfix = date.getMonth();
var curyear = date.getFullYear();
var curyearfix = date.getFullYear();
var firstday, lastday;
var weekdate;
var first = date.getDate() - date.getDay() + 1;
var last = first + 6;
var ProcessId= $('#hdnProcessId').val();
var AgentId=$('#hdnAgentId').val();;
var RadioBtnVal=$("input[id=rdByProcess]:checked").val();
var SelectedAgentId='';

curmonthNew = curmonth + 1;
var monthNames = ["January", "February", "March","April", "May", "June","July", "August", "September","October", "November", "December"];
var shortmonth = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
var WeekDays = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
var groupby = 0;

$(document).ready(function() {
// ----- For Loading data
   $('#DisableDiv').fadeTo('slow', .6);
    $('#DisableDiv').append('<div style="background-color:#E6E6E6;position: absolute;top:0;left:0;width: 100%;height:110%;z-index:1001;-moz-opacity: 0.8;opacity:.80;filter: alpha(opacity=80);"><img src="../_assets/img/loading1.gif" style="position:fixed;top:40%;left:46%;width:120px;"/></div>');
    setTimeout(function() 
    {}, 100)
 //------------------   
    if (curmonthNew < 10) {
        curmonthNew = "0" + curmonthNew;
    }
    $("#gvData").UseAccessibleHeader = true;
    $(".gvAgents").UseAccessibleHeader = true;
    load();    
    $(".prev").click(function() {
        if ($("#cboperiod").val() == "1") {
            groupby = 1;
            if (curmonth == 0) {
                curyear = curyear - 1;
                curmonth = 11;
            }
            else {
                curmonth = curmonth - 1;
            }
            $('#txtdate').val(monthNames[curmonth] + " " + curyear);
            curmonthNew = curmonth + 1;
            if (curmonthNew < 10) {
                curmonthNew = "0" + curmonthNew;
            }
            var daysInMonth = new Date(curyear, curmonthNew, 1, -1).getDate();
            datefrom = curyear.toString() + curmonthNew.toString() + "01";
            dateto = curyear.toString() + curmonthNew.toString() + daysInMonth;
        }
        else if ($("#cboperiod").val() == "3") {
            groupby = 3;
            date.setDate(date.getDate() - 1);
            var newcurdate = date.getDate();
            var newcurmonth = date.getMonth();
            var newcurmonthfix = date.getMonth();
            var newcuryear = date.getFullYear();
            var newcuryearfix = date.getFullYear();
            day = newcurdate;
            if (curmonthNew < 10) {
                curmonthNew = "0" + curmonthNew;
            }
            if (newcurdate < 10) {
                newcurdate = "0" + newcurdate;
            }
            $('#txtdate').val(newcurdate + " " + monthNames[newcurmonth] + " " + newcuryear);
            newcurmonth = newcurmonth + 1;
            datefrom = newcuryear.toString() + newcurmonth.toString() + newcurdate;
            dateto = newcuryear.toString() + newcurmonth.toString() + newcurdate;
        }
        else if ($("#cboperiod").val() == "2") {
            groupby = 2;
            var newcurmonth;
            var newcuryear;
            weekdate.setDate(weekdate.getDate() - 13);
            first = weekdate.getDate() - weekdate.getDay() + 1;
            firstday = new Date(weekdate.setDate(first)).toDateString();
            newcurmonth = weekdate.getMonth() + 1;
            newcuryear = weekdate.getFullYear();
            if (newcurmonth < 10) {
                newcurmonth = "0" + newcurmonth;
            }
            if (first < 10) {
                first = "0" + first;
            }
            var monthfrom = newcurmonth - 1;
            datefrom = newcuryear.toString() + newcurmonth.toString() + first;
            weekdate.setDate(weekdate.getDate() + 6);
            last = weekdate.getDate();

            lastday = new Date(weekdate.setDate(last)).toDateString();
            newcurmonth = weekdate.getMonth() + 1;
            newcuryear = weekdate.getFullYear();
            if (newcurmonth < 10) {
                newcurmonth = "0" + newcurmonth;
            }
            if (last < 10) {
                last = "0" + last;
            }
            var monthto = newcurmonth - 1;
            dateto = newcuryear.toString() + newcurmonth.toString() + last;
            $('#txtdate').val(shortmonth[monthfrom] + ' ' + first + " - " + shortmonth[monthto] + ' ' + last + "," + curyear);
            $("#time").html('<span>time by week</span>');
        }

        // ----- For Loading data
           $('#DisableDiv').fadeTo('slow', .6);
            $('#DisableDiv').append('<div style="background-color:#E6E6E6;position: absolute;top:0;left:0;width: 100%;height:110%;z-index:1001;-moz-opacity: 0.8;opacity:.80;filter: alpha(opacity=80);"><img src="../_assets/img/loading1.gif" style="position:fixed;top:40%;left:46%;width:120px;"/></div>');
            setTimeout(function() 
            { 
            }, 100)
         //------------------   
          var str = new Array();
          var str1 = "";
          GetData(datefrom, dateto, groupby,ProcessId);
          GetGridData(datefrom, dateto,ProcessId);
               
    });
    $(".next").click(function() {
        if ($("#cboperiod").val() == "1") {
            groupby = 1;
            if (curmonth == 11) {
                curyear = curyear + 1;
                curmonth = 0;
            }
            else {
                curmonth = curmonth + 1;
            }
            if (curmonth > curmonthfix && curyear == curyearfix) {
                curmonth = curmonth - 1;
                return false;
            }
            else {
                $('#txtdate').val(monthNames[curmonth] + " " + curyear);
            }
            curmonthNew = curmonth + 1;
            if (curmonthNew < 10) {
                curmonthNew = "0" + curmonthNew;
            }
            var daysInMonth = new Date(curyear, curmonthNew, 1, -1).getDate();
            datefrom = curyear.toString() + curmonthNew.toString() + "01";
            dateto = curyear.toString() + curmonthNew.toString() + daysInMonth;
        }
        else if ($("#cboperiod").val() == "3") {
            groupby = 3;
            date.setDate(date.getDate() + 1);
            var newcurdate = date.getDate();
            var newcurmonth = date.getMonth();
            var newcurmonthfix = date.getMonth();
            var newcuryear = date.getFullYear();
            var newcuryearfix = date.getFullYear();
            if (curmonthNew < 10) {
                curmonthNew = "0" + curmonthNew;
            }
            if (newcurdate < 10) {
                newcurdate = "0" + newcurdate;
            }
            if (newcurdate > curdatefix && newcurmonth == curmonthfix && newcuryear == newcuryearfix) {
                newcurdate = newcurdate - 1;
                date.setDate(date.getDate() - 1);
                return false;
            }
            else {
                $('#txtdate').val(newcurdate + " " + monthNames[newcurmonth] + " " + newcuryear);
                newcurmonth = newcurmonth + 1;
            }
            datefrom = newcuryear.toString() + newcurmonth.toString() + newcurdate;
            dateto = newcuryear.toString() + newcurmonth.toString() + newcurdate;

        }
        else if ($("#cboperiod").val() == "2") {
            groupby = 2;          
            var newcurmonth;
            var newcuryear;
            weekdate.setDate(weekdate.getDate() + 1);
            first = weekdate.getDate() - weekdate.getDay() + 1;
            firstday = new Date(weekdate.setDate(first)).toDateString();
            newcurmonth = weekdate.getMonth();
            newcuryear = weekdate.getFullYear();           
            if (first < 10) {
                first = "0" + first;
            }
            var monthfrom = (newcurmonth + 1);
             if (newcurmonth < 10) {
                newcurmonth = "0" + newcurmonth;
            }
            var monthfrom1=monthfrom;
             if (monthfrom1 < 10) {
                monthfrom1 = "0" + monthfrom1;
            }
            datefrom = newcuryear.toString() + monthfrom1.toString() + first;
            weekdate.setDate(weekdate.getDate() + 6);
            last = weekdate.getDate();

            lastday = new Date(weekdate.setDate(last)).toDateString();
            newcurmonth = weekdate.getMonth();
            newcuryear = weekdate.getFullYear();
            if (last < 10) {
                last = "0" + last;
            }
            var monthto = (newcurmonth + 1);
             if (newcurmonth < 10) {
                newcurmonth = "0" + newcurmonth;
            }
            var monthto1=monthto;
             if (monthto1 < 10) {
                monthto1 = "0" + monthto1;
            }
            dateto = newcuryear.toString() + monthto1.toString() + last;
            monthfrom=monthfrom-1;
            monthto=monthto-1;
            $('#txtdate').val(shortmonth[monthfrom] + ' ' + first + " - " + shortmonth[monthto] + ' ' + last + "," + curyear);
            $("#time").html('<span>time by week</span>');
        }
         // ----- For Loading data
           $('#DisableDiv').fadeTo('slow', .6);
            $('#DisableDiv').append('<div style="background-color:#E6E6E6;position: absolute;top:0;left:0;width: 100%;height:110%;z-index:1001;-moz-opacity: 0.8;opacity:.80;filter: alpha(opacity=80);"><img src="../_assets/img/loading1.gif" style="position:fixed;top:40%;left:46%;width:120px;"/></div>');
            setTimeout(function() 
            { 
            }, 100)
         //------------------   
            var str = new Array();
            GetData(datefrom, dateto, groupby,ProcessId);
            var str1 = "";
            GetGridData(datefrom, dateto,ProcessId);
    });
});
function load() {
    if ($("#cboperiod").val() == "1") {
        groupby = 1;
        $('#txtdate').val(monthNames[curmonth] + " " + curyear);
        var daysInMonth = new Date(curyear, curmonthNew, 1, -1).getDate();
        datefrom = curyear.toString() + curmonthNew.toString() + "01";
        dateto = curyear.toString() + curmonthNew.toString() + daysInMonth;
        $("#time").html('<span>time by day</span>');
    }
    else if ($("#cboperiod").val() == "3") {
        groupby = 3;
        if (curdate < 10) {
            curdate = "0" + curdate;
        }
        datefrom = curyear.toString() + curmonthNew.toString() + curdate;
        dateto = curyear.toString() + curmonthNew.toString() + curdate;
        $('#txtdate').val(curdate + " " + monthNames[curmonth] + " " + curyear);
        $("#time").html('<span>time by hours</span>');
    }
    else if ($("#cboperiod").val() == "2") {
        groupby = 2;
        weekdate = new Date();
        firstday = new Date(weekdate.setDate(first)).toDateString();
        lastday = new Date(weekdate.setDate(last)).toDateString();
        if (first < 10) {
            first = "0" + first;
        }
        if (last < 10) {
            last = "0" + last;
        }
        datefrom = curyear.toString() + curmonthNew.toString() + first;
        dateto = curyear.toString() + curmonthNew.toString() + last;
        $('#txtdate').val(shortmonth[curmonth] + ' ' + first + " - " + shortmonth[curmonth] + ' ' + last + "," + curyear);
        $("#time").html('<span>time by week</span>');
    }   
    // GetFilter(AgentId);
     // ----- For Loading data
        $('#DisableDiv').fadeTo('slow', .6);
        $('#DisableDiv').append('<div style="background-color:#E6E6E6;position: absolute;top:0;left:0;width: 100%;height:110%;z-index:1001;-moz-opacity: 0.8;opacity:.80;filter: alpha(opacity=80);"><img src="../_assets/img/loading1.gif" style="position:fixed;top:40%;left:46%;width:120px;"/></div>');
          setTimeout(function() 
          { 
          }, 100)
     //------------------          
        var str = new Array();
        GetData(datefrom, dateto, groupby,ProcessId);
        var str1 = "";
        var str="";
        GetGridData(datefrom, dateto,ProcessId);

}
function GetData(datefrom, dateto, groupby) {
    var hv = $('#hdnProcessId').val();        
     $.ajax({
        url: "ActivityDashboard.aspx/GetData",
        dataType: "json",
        type: "POST",
        data: "{'datefrom':'" + datefrom + "','dateto':'" + dateto + "','groupby':'" + groupby + "','process':'" + hv + "','AgentId':'" + SelectedAgentId + "'}",
        contentType: "application/json; charset=utf-8",
        success: getdataresponse,
        error: function (XHR, errStatus, errorThrown) {
            var err = JSON.parse(XHR.responseText);
            errorMessage = err.Message;
            alert("Error: " + errorMessage);
        },
        failure: function (response) {
            alert(response.responseText);
        },
    });
}
function getdataresponse(response)
{
    str = response.d;    
    getTotalLoginHrs(str);
    plotdonut(str);
    getTotalProductiveHrs(str);
    getcateogry(str);
    if (groupby == 2) {
        plotWithOptionsweekly(str);
    }
    else {
        plotWithOptions(str);
    }
    plotcategory1(str);
    plotcategory2(str);
    plotcategory3(str);  
    $('#DisableDiv').html("");  
}
function pieHover(event, pos, obj) {
    if (obj) {
        percent = parseFloat(obj.series.percent).toFixed(2);
        if (obj.series.color == "#00008B") {
            obj.series.label = 'Non Productive Break';
        }
        else if (obj.series.color == "#ADD8E6") {
            obj.series.label = 'Productive Break';
        }
        $("#hover").html('<span style="font-weight: bold; color: ' + obj.series.color + '">' + obj.series.label + ' (' + percent + '%)</span>');
    }
    else {
        $("#hover").html('');
    }
}

function pieClick(event, pos, obj) {
    if (!obj)
        return;
    percent = parseFloat(obj.series.percent).toFixed(2);
    alert('' + obj.series.label + ': ' + percent + '%');
}
function plotdonut(str) {
    var data = jQuery.parseJSON(str[1]);
    if (data == null) {
        $("#div1").hide();
    }
    else {
        $("#div1").show();
    }
    if (data != null) {
        $.plot($("#chart5"), data,
        {
            series:
            {
                pie:
                {
                    show: true, innerRadius: .6, label:false,
                },                
            },          
            grid: 
            {
                hoverable: true,                             
            },
            legend:
            {
               show:false,
            },
        });
        $("#chart5").bind("plothover", pieHover);
       
    }
}
var previousPoint = null,
    previousLabel = null;
function showTooltip(x, y, color, contents) {
    $('<div id="tooltip">' + contents + '</div>').css({
        position: 'absolute',
        display: 'none',
        top: y - 40,
        left: x - 60,
        border: '2px solid ' + color,
        padding: '3px',
        'font-size': '9px',
        'border-radius': '5px',
        'background-color': '#fff',
        'font-family': 'Verdana, Arial, Helvetica, Tahoma, sans-serif',
        'text-align': 'center',
        opacity: 0.9
    }).appendTo("body").fadeIn(200);
}

function barHover(event, pos, item) {
    if (item) {
        if ((previousLabel != item.series.label) || (previousPoint != item.dataIndex)) {
            previousPoint = item.dataIndex;
            previousLabel = item.series.label;
            percent = parseFloat(item.series.percent).toFixed(2);
           
            $("#tooltip").remove();

            var x = item.datapoint[0];
            var y = item.datapoint[1].toString();
            y= y.replace("-", "");
            var color = item.series.color;
            var str = "";
            if (groupby == 1) {
                str="<strong> Day " + x + "</strong><br>"
            }
            else if (groupby == 3) {
                str="<strong> Hour " + x + "</strong><br>"
            }
            showTooltip(item.pageX, item.pageY, color,
            str +
             "<strong>" + item.series.label + "</strong>: <strong>" + y + "</strong>");
        }
    } else {
        $("#tooltip").remove();
        previousPoint = null;
    }
}

function plotWithOptions(str) {
    var data = jQuery.parseJSON(str[2]);
    if (data != null) {
        var datalength = data.length;
        var d1 = []; var d2 = [];     
        for (var i = 0; i <= datalength - 1; i += 1) {          
                if (data[i].isproductive == 1) {
                    d1.push([data[i].Day, data[i].duration]);
                }
                else {
                    d2.push([data[i].Day, -data[i].duration]);
                } 
        }        
        var dataset;        
            dataset = [
                {
                    label: "Productive Hrs",
                    data: d1,
                    //yaxis: { min: 0, max: 0, tickLength: 0, ticks: 0, showticks: false },
                    //xaxis: { min: 0, max: 50, ticks: 1 },
                    color: "#90EE90",
                    //points: { symbol: "circle", fillColor: "#FF0000", show: true },
                    lines: { show: false }
                },
                {
                    label: "Non Productive Hrs",
                    data: d2,
                    //yaxis: { min: 0, max: 0, tickLength: 0, ticks: 0, showticks: false },
                    //xaxis: { min: 0, max: 50, ticks: 1 },
                    color: "#F08080",
                    //points: { symbol: "triangle", fillColor: "#0062FF", show: true },
                    lines: { show: false }
                },
            ];
          

        var stack = 0, bars = true, lines = false, steps = false;
        $.plot($("#bar-chart"), dataset, {
            series: {
                stack: stack,
                lines: { show: false },                
                bars: { show: true, barWidth: 0.2, order: 1, }
            },
            xaxis: {min:1,},
            yaxis: {
                show: false,
                ticks: 0
            },
            grid: {
                hoverable: true,
                borderWidth: 0,
                backgroundColor: null,
                tickColor: "rgba(0,0,0,0)",
                markings: [{ xaxis: { from: 0, to: 31 }, yaxis: { from: 0, to: 0 }, color: "#000" }]
            },            
            bars: {
                show: true,
                lineWidth: 0,
                fill: true,
                fillColor: { colors: [{ opacity: 0.9 }, { opacity: 0.8 }] },                
            },
            legend:
                {
                    show:false,
                },
            valueLabels: {
                show: true
            }
        });
        $("#bar-chart").bind("plothover", barHover);
    }
}
function plotWithOptionsweekly(str) {
    var data = jQuery.parseJSON(str[2]);
    if (data != null) {
        var datalength = data.length;
        var d1 = []; var d2 = [];
        for (var i = 0; i <= datalength - 1; i += 1) {
            if (data[i].isproductive == 1) {
                d1.push([data[i].Day, data[i].duration]);
            }
            else {
                d2.push([data[i].Day, -data[i].duration]);
            }
        }
        var dataset;
        dataset = [
        {
            label: "Productive Hrs",
            data: d1,
            color: "#90EE90",    
            lines: { show: false }
        },
        {
            label: "Non Productive Hrs",
            data: d2,    
            color: "#F08080",    
            lines: { show: false }
        },
     ];
        var stack = 0, bars = true, lines = false, steps = false;
        $.plot($("#bar-chart"), dataset, {
            series: {
                stack: stack,
                lines: { show: false },
                bars: { show: true, barWidth: 0.2, order: 1, }
            },
            xaxis: {
                min: 1.0,
                max: 7.0,
                //mode: null,
                ticks: [[1.0, "Mon"], [2.0, "Tue"], [3.0, "Wed"], [4.0, "Thu"], [5.0, "Fri"], [6.0, "Sat"], [7.0, "Sun"]],
                tickLength: 0, // hide gridlines
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial, Helvetica, Tahoma, sans-serif',
                axisLabelPadding: 5
            },
            yaxis: {
                show: false,
                ticks: 0
            },
            grid: {
                hoverable: true,                
                borderWidth: 0,                
                backgroundColor: null,
                tickColor: "rgba(0,0,0,0)",
                markings: [{ xaxis: { from: 0, to: 31 }, yaxis: { from: 0, to: 0 }, color: "#000" }
                ]
            },
            bars: {
                show: true,
                lineWidth: 0,
                fill: true,
                fillColor: { colors: [{ opacity: 0.9 }, { opacity: 0.8 }] },
            },
            legend:
                {
                    show: false,
                },
            valueLabels: {
                show: true
            }
        });
        $("#bar-chart").bind("plothover", barHover);
    }
}
 
function CategorybarHover(event, pos, item) { 
    if (item) {
        if ((previousLabel != item.series.label) || (previousPoint != item.dataIndex)) {
            previousPoint = item.dataIndex;
            previousLabel = item.series.label;
            percent = parseFloat(item.series.percent).toFixed(2);           
            $("#tooltip").remove();
            var x = item.datapoint[0];
            var y = item.datapoint[1].toString();           
            y= y.replace("-", "");
            var color = item.series.color;
            var str = "";
            showTooltip(item.pageX, item.pageY, color,
            //str + "<strong>" + item.series.label + "</strong>: <strong>" + y + "</strong> %");
            str + "<strong> Hour :" + y + "</strong> %");
        }
    } 
    else 
    {
        $("#tooltip").remove();
        previousPoint = null;
    }
}

function plotcategory1(str) {
    var catdata = jQuery.parseJSON(str[4]);
    if (catdata == null) {
        $("#divspot").hide();
    }
    else {
        $("#divspot").show();
    }
    if (catdata != null) {
        var datalength = catdata.length;
        var d1 = [];       
        var abc = "";
        $("#ul1info").empty();
        for (var i = 0; i <= datalength - 1; i += 1) {
            d1.push([catdata[i].ID,catdata[i].Duration]);
            var catsr = catdata[i].ID;
            var appname = catdata[i].AppName;      
            $("#cat1info ul").append("<li class = 'aap-list'><span class='cat1info'>" + catsr + "</span><span class='appinfo'>" + ChangeToProperCase(appname) + "</span></li>");
        }        
        var dataset = [
            {  
                label:"",
                data: d1,
                color: "#90EE90",
                lines: { show: false }
            },];   
        
        var stack = 0, bars = true, lines = false, steps = false;
        $.plot($("#cat1"), dataset, {
            series: {
              //label:"Time By Day",                   
              stack: stack,
              lines: { show: false },
              bars: { show: bars, barWidth: .5,label:false }
            },
            xaxis: {
                ticks: 0, min: 1, max: 6,
            },
            grid: {
                hoverable: true,
                borderWidth: 0,
                aboveData: false,
                backgroundColor: null,
                tickColor: "rgba(0,0,0,0)",
                markings: [{ xaxis: { from: 0, to: 40 }, yaxis: { from: 0, to: 0 }, color: "#000" }]
            },
            bars:
             {
                show: true,
                lineWidth: 0,
                fill: true,
                fillColor: { colors: [{ opacity: 0.9 }, { opacity: 0.8 }] }
             },
            legend:
             {
                show: false,
             },
            valueLabels: 
            {
               show: true
            }
        });
        $("#cat1").bind("plothover", CategorybarHover);         
    }
}
function plotcategory2(str) {
    var catdata = jQuery.parseJSON(str[5]);
    if (catdata == null) {
        $("#divspot").hide();
    }
    else {
        $("#divspot").show();
    }
    if (catdata != null) {
        var datalength = catdata.length;
        var d1 = [];
        $("#ul2info").empty();
        for (var i = 0; i <= datalength - 1; i += 1) {
            d1.push([catdata[i].ID, catdata[i].Duration]);
            var catsr = catdata[i].ID;
            var appname = catdata[i].AppName;
            $('#cat2info ul').append("<li class = 'aap-list'><span class='cat2info'>" + catsr + "</span><span class='appinfo'>" + ChangeToProperCase(appname) + "</span></li>");
        }
        var dataset = [
        {
            label: "",
            data: d1,
            color: "#90EE90",
            lines: { show: false }
        },
        ];
        var stack = 0, bars = true, lines = false, steps = false;
        $.plot($("#cat2"), dataset, {
            series: 
            {
              //label:"Time By Day",                   
              stack: stack,
              lines: { show: false },
              bars: { show: bars, barWidth: .5 }
            },
            xaxis: 
            {
                ticks: 0, min: 1, max: 6,
            },
            yaxis: {ticks:0, show:false,},
            grid: {
                hoverable:true,
                borderWidth: 0,
                aboveData: false,
                backgroundColor: null,
                tickColor: "rgba(0,0,0,0)",
                markings: [{ xaxis: { from:-10, to:40}, yaxis: { from: 0, to: 0 }, color: "#000" }]
            },
            bars: 
            {
                show: true,
                lineWidth: 0,
                fill: true,
                fillColor: { colors: [{ opacity: 0.9 }, { opacity: 0.8 }] }
            }
        });
        $("#cat2").bind("plothover", CategorybarHover);
    }
}
function plotcategory3(str) {
    //var datadoc = response.d;
    var catdata = jQuery.parseJSON(str[6]);
    if (catdata == null) {
        $("#divspot").hide();
    }
    else {
        $("#divspot").show();
    }
    if (catdata != null) {
        var datalength = catdata.length;
        var d1 = [];
        var abc = ""
        $("#ul3info").empty();
        for (var i = 0; i <= datalength - 1; i += 1) {
            d1.push([catdata[i].ID, catdata[i].Duration]);
            var catsr = catdata[i].ID;
            var appname = catdata[i].AppName;
            $('#cat3info ul').append("<li class = 'aap-list'><span class='cat3info'>" + catsr + "</span><span class='appinfo'>" + ChangeToProperCase(appname) + "</span></li>");
        }

        var dataset = [
                {
                    label: "",
                    data: d1,
                    color: "#808080",
                    lines: { show: false }
                },
            ];
        var stack = 0, bars = true, lines = false, steps = false;
        $.plot($("#cat3"), dataset, {
           series: {
             //label:"Time By Day",                   
              stack: stack,
              lines: { show: false },
              bars: { show: bars, barWidth: .5 }
            },
            xaxis: {
                ticks: 0, min: 1, max: 6,
            },
            yaxis: { ticks: 0, show: false, },
            grid: {
                hoverable:true,
                borderWidth: 0,
                aboveData: false,
                backgroundColor: null,
                tickColor: "rgba(0,0,0,0)",
                markings: [{ yaxis: { from: 0, to: 0 }, color: "#000" }]
            },
            bars: {
                show: true,
                lineWidth: 0,
                fill: true,
                fillColor: { colors: [{ opacity: 0.9 }, { opacity: 0.8 }] }
            }
        });
        $("#cat3").bind("plothover", CategorybarHover);
    }
}
function getTotalLoginHrs(str) {
    var data = jQuery.parseJSON(str[0]);    
    var d1 = data[0].TotalDuration;
    if (d1 != null) {
        var d2 = d1.split(":");
        $("#lbltotallogin").text(d2[0] + "h " + d2[1] + "m");
    }
}
function getTotalProductiveHrs(str) {
    var data = jQuery.parseJSON(str[3]);
    var d1 = data[0].Duration;
    $("#divprodhrs").text(d1);
}

function getcateogry(str) {
    var catdata = jQuery.parseJSON(str[1]);
    if (catdata != null) {    
        var datalength = catdata.length;
        var d1 = [];
        var abc = ""
        $("#ulcat").empty();
        for (var i = 0; i <= datalength - 1; i += 1) {
            var catDuration = catdata[i].data;
            var Cat = catdata[i].label;
            var color = catdata[i].color;
            if (color == "#00008B") {
                Cat = 'Non Productive Break';
            }
            else if (color == "#ADD8E6") {
                Cat = 'Productive Break';
            }
            var design = "";
            design = "<li><p> <span style='border:solid 1px #ccc; border-image: none; padding:5px; color:#000;'>" + catDuration + "%</span> " + Cat + "</p>";
            design = design + "<div class='progress progress-xs'>";
            design = design + "<div class='progress' role='progressbar' aria-valuenow=" + catDuration + " aria-valuemin='0' aria-valuemax='100' style='background-color:" + color + "; width:" + catDuration + "%'></div></div></li>";
            $('#divcat ul').append(design);
        }
    }
}

function convertsecond(totalSeconds) {
    var hours = Math.floor(totalSeconds / 3600);
    if (hours < 10) {
        hours = "0" + hours;
    }
    totalSeconds %= 3600;
    var minutes = Math.floor(totalSeconds / 60);
    if (minutes < 10) {
        minutes = "0" + minutes;
    }
    var seconds = totalSeconds % 60;
    if (seconds < 10) {
        seconds = "0" + seconds;
    }
    var strsec=hours + ":" + minutes + ":" + seconds;
    return strsec;
}

function GetGridData(datefrom, dateto,ProcessId) {
//debugger;
    var hdval=$("#hdnProcessId").val();
    $.ajax({
        url: "ActivityDashboard.aspx/BindGrid",
        dataType: "json",
        type: "POST",
        data: "{'datefrom':'" + datefrom + "','dateto':'" + dateto + "','process':'" + hdval + "','Agent':'" + SelectedAgentId + "'}",
        contentType: "application/json; charset=utf-8",
        success: bindresponse,
        error: function (XHR, errStatus, errorThrown) {
            var err = JSON.parse(XHR.responseText);
            errorMessage = err.Message;
            alert("Error: " + errorMessage);
        },
        failure: function (response) {
            alert(response.responseText);
        },
    });
}

function bindresponse(response) {
    str1 = response.d;
    Bindgrid(str1);
    
    $('#DisableDiv').html("");
}
function Bindgrid(str1) {
    $("#gvData").empty();    
    if (str1 != "") {       
        var data = jQuery.parseJSON(str1);
        var strname = "";
       
        if (data != null) {
            var datalength = data.length;
            var gvcol = "";
            gvcol = "<thead><tr>";
            for (strname in data[0]) {
                gvcol = gvcol + "<th>" + strname + "</th>";
            }
            gvcol = gvcol + "</tr></thead>";
            $("#gvData").append(gvcol);
            gvrow = "<tbody>";
           // $("#gvData").addClass("datatable");
            for (var i = 0; i <= datalength - 1; i += 1) {
                var gvrow = "";
                gvrow = gvrow + "<tr>";
                for (strname in data[i]) {                  
                    
                    if (data[i][strname] == null) {
                        gvrow = gvrow + "<td>0</td>";
                    }
                    else {
                        if (strname != "Agent" && strname != "Utilization %") {
                            gvrow = gvrow + "<td>" + convertsecond(data[i][strname]) + "</td>";
                        }                      
                        else {
                            gvrow = gvrow + "<td>" + data[i][strname] + "</td>";
                        }
                    }
                }
                gvrow = gvrow + "</tr>";
                $("#gvData").append(gvrow);
            }
            gvrow = gvrow + "</tbody>";
        }
    }
    SetDefaultSortOrder();
    $('#gvData').tablesorter();
}
function ChangeToProperCase(str) {
    var val = str.toLowerCase(), newVal = '';
    val = val.split(' ');
    for (var c = 0; c < val.length; c++) {
        if (c > 0 && val[c] == "is" || c > 0 && val[c] == "to" || c > 0 && val[c] == "the") {
            newVal += val[c] + ' ';
        } else newVal += val[c].substring(0, 1).toUpperCase() + val[c].substring(1, val[c].length) + (c + 1 == val.length ? '' : ' ');
    }
    return newVal;
}
function Sort(cell, sortOrder) {
    var sorting = [[cell.cellIndex, sortOrder]];
    $("#gvData").trigger("sorton", [sorting]);
    if (sortOrder == 0) {
        sortOrder = 1;
        cell.className = "sortDesc";
    }
    else {
        sortOrder = 0;
        cell.className = "sortAsc";
    }
    cell.setAttribute("onclick", "Sort(this, " + sortOrder + ")");
    cell.onclick = function() { Sort(this, sortOrder); };
    document.getElementById("Gridcontainer").scrollTop = 0;
}
function SetDefaultSortOrder() {    
    var headers = gvData.getElementsByTagName("th");
    for (var i = 0; i < headers.length; i++) {
        headers[i].className = "sortDesc";
    }
}

//--------------- Grid -----------------------

//function GetAgentsGridData(ProcessId) {
//    $.ajax({
//        url: "ActivityDashboard.aspx/BindAgentGrid",
//        dataType: "json",
//        type: "POST",
//        data: "{'ProcessId':'" + ProcessId + "'}",        
//        contentType: "application/json; charset=utf-8",
//        success: AgentGridresponse,
//        error: function (XHR, errStatus, errorThrown) {
//            var err = JSON.parse(XHR.responseText);
//            errorMessage = err.Message;
//            alert("Error: " + errorMessage);
//        },
//        failure: function (response) {
//            alert(response.responseText);
//        },
//    });
//}
//function AgentGridresponse(response) {
//    strAgent = response.d;    
//    BindAgentGrid(strAgent);
//}
//function BindAgentGrid(strAgent) {
//    $("#gvAgents").empty();    
//    if (strAgent != "") {       
//        var data = jQuery.parseJSON(strAgent);
//        var strname = "";       
//        if (data != null) {
//            var datalength = data.length;
//            var gvcol = "";
//            gvcol = "<thead><tr>";
//            for (strname in data[0]) {
//                gvcol = gvcol + "<th>" + strname + "</th>";
//            }
//            gvcol = gvcol + "</tr></thead>";
//            $("#gvAgents").append(gvcol);
//            gvrow = "<tbody>";           
//            for (var i = 0; i <= datalength - 1; i += 1) {
//                var gvrow = "";
//                gvrow = gvrow + "<tr>";
//                for (strname in data[i]) {                                      
//                    if (data[i][strname] == null) {
//                        gvrow = gvrow + "<td>0</td>";
//                    }
//                    else {
//                        if (strname == "AgentId") {
//                            //gvrow = gvrow + "<td><a href='" + data[i][strname] + "'>" + data[i][strname] + "</a></td>";
//                            gvrow = gvrow + "<td>" + data[i][strname] + "</td>";
//                        } 
//                        else{
//                            gvrow = gvrow + "<td>" + data[i][strname] + "</td>";
//                        }
//                    }
//                }
//                gvrow = gvrow + "</tr>";
//                $("#gvAgents").append(gvrow);
//            }
//            gvrow = gvrow + "</tbody>";
//        }
//    }
//}

   $("#btnPopUp").click(function() {  
      var rd=  $('input:radio[id=rdByProcess]').attr('checked',true ); 
        $('input:radio[name=Fill2]').attr('checked',false );  
         if ($("#rdByAgents").checked==true){
            alert('test');
        }
        
        $('#cboAgentName').empty();      
        var strAgent = "";   
        FillProcess();
        //GetAgentsGridData(ProcessId);          
        $("#cboProcess").val(ProcessId);
    });
    $(document).ready(function() {
        FillProcess(AgentId);
        $("#cboProcess").val(ProcessId);
    });
 
 function FillProcess() {
  var hdnAgent = $('#hdnAgentId').val();   
    $.ajax({
        type: "POST",
        url: "ActivityDashboard.aspx/BindProcess",
        contentType: "application/json; charset=utf-8",
        dataType: "JSON",
        data: "{'AgentId':'" + AgentId + "'}",    
        success:FillLoggedUserProcess,
        error: function (XHR, errStatus, errorThrown) {
            var err = JSON.parse(XHR.responseText);
            errorMessage = err.Message;
            alert("Error: " + errorMessage);
        },
        failure: function (response) {
            alert(response.responseText);
        },
    });
}

function FillLoggedUserProcess(response) {
   strAgent = response.d; 
   var Process = jQuery.parseJSON(strAgent);
   $('#cboProcess').empty();
   if (Process != null) {
    $('#cboProcess').append($('<option>').text("Select process").attr('value', -1));
    var datalength = Process.length;
    for (var i = 0; i <= datalength - 1; i++) {
        $('#cboProcess').append($('<option>').text(Process[i].ProcessName).attr('value', Process[i].Processid));
    }
   }
}

function GetAgentsOfProcess(ProcessId) {
    $.ajax({
        url: "ActivityDashboard.aspx/BindAgentGrid",
        dataType: "json",
        type: "POST",
        data: "{'ProcessId':'" + ProcessId + "'}",        
        contentType: "application/json; charset=utf-8",
        success: BindProcessAgents,
        error: function (XHR, errStatus, errorThrown) {
            var err = JSON.parse(XHR.responseText);
            errorMessage = err.Message;
            alert("Error: " + errorMessage);
        },
        failure: function (response) {
            alert(response.responseText);
        },
    });
}

function BindProcessAgents(response) {
   strAgent = response.d; 
   var Process = jQuery.parseJSON(strAgent);
   $('#cboAgentName').empty();
   if (Process != null) {
    $('#cboAgentName').append($('<option>').text("Select Agent").attr('value', -1));
    var datalength = Process.length;
    for (var i = 0; i <= datalength - 1; i++) {
        $('#cboAgentName').append($('<option>').text(Process[i].AgentName).attr('value', Process[i].AgentId));
    }
   }
}

$("#cboProcess").change(function () {
    var strAgent = "";
    if ($('#cboProcess').val() == -1) {
        alert("Please Select ProcessId");
         $('#cboAgentName').empty();
        return false;
    }
    //GetAgentsGridData($("#cboProcess").val());
    GetAgentsOfProcess($("#cboProcess").val());
});

//---- For Loading 
$("#btnGet").click(function () {
if (RadioBtnVal==1){ 
     if ($('#cboProcess').val() == -1) {
        alert("Please Select ProcessId");
        return false;    
     }
        var ProId=$("#cboProcess").val();
        var ProName=$("#cboProcess option:selected").text();
        SelectedAgentId=''
        $('#hdnProcessId').val(ProId);
        $('#spnProcessName').text(ProName);
        
        SaveFilter(AgentId,RadioBtnVal,ProId,SelectedAgentId);
        
        var str = new Array();
        GetData(datefrom, dateto, groupby,ProId);
        var str1 = "";
        var str="";
        GetGridData(datefrom, dateto,ProId);
        
        $('#DisableDiv').fadeTo('slow', .6);
        $('#DisableDiv').append('<div style="background-color:#E6E6E6;position: absolute;top:0;left:0;width: 100%;height:110%;z-index:1001;-moz-opacity: 0.8;opacity:.80;filter: alpha(opacity=80);"><img src="../_assets/img/loading1.gif" style="position:fixed;top:40%;left:46%; width:120px;"/></div>');
        setTimeout(function() 
        { 
        }, 100)
  }
  if (RadioBtnVal==2){ 
    if ($('#cboProcess').val() == -1) {
        alert("Please Select ProcessId");
        return false;    
     }
     if ($('#cboAgentName').val() == -1) {
        alert("Please Select Agent");
        return false;    
     }
        var ProId=$("#cboProcess").val();
        var ProName=$("#cboProcess option:selected").text();
        var AgentName=$("#cboAgentName option:selected").text();
        SelectedAgentId=$("#cboAgentName").val();
        
        SaveFilter(AgentId,RadioBtnVal,ProId,SelectedAgentId);
        
        $('#hdnProcessId').val(ProId);
        $('#spnProcessName').text(AgentName + " [" + ProName + "'s]");
        
        var str = new Array();
        GetData(datefrom, dateto, groupby,ProId,SelectedAgentId);
        var str1 = "";
        var str="";
        GetGridData(datefrom, dateto,ProId,SelectedAgentId);
        
        $('#DisableDiv').fadeTo('slow', .6);
        $('#DisableDiv').append('<div style="background-color:#E6E6E6;position: absolute;top:0;left:0;width: 100%;height:110%;z-index:1001;-moz-opacity: 0.8;opacity:.80;filter: alpha(opacity=80);"><img src="../_assets/img/loading1.gif" style="position:fixed;top:40%;left:46%; width:120px;"/></div>');
        setTimeout(function() 
        { 
        }, 100)
  }  
});

$("#rdByAgents").click(function(){
    RadioBtnVal=$("input[id=rdByAgents]:checked").val();
    $("#lblAgents").css('display','block');
    $("#cboAgentName").css('display','block');
});

$("#rdByProcess").click(function(){
    RadioBtnVal=$("input[id=rdByProcess]:checked").val();
    $("#lblAgents").css('display','none');
    $("#cboAgentName").css('display','none');
});

function SaveFilter(Userid,Filter,Process,SelectedAgent) {    
    $.ajax({
        url: "ActivityDashboard.aspx/SaveFilter",
        dataType: "json",
        type: "POST",
        data: "{'UserId':'" + Userid + "','SelectedFilter':" + Filter + ",'SelectedProcess':" + Process + ",'SelectedAgent':'" + SelectedAgent + "'}",        
        contentType: "application/json; charset=utf-8",        
        error: function (XHR, errStatus, errorThrown) {
            var err = JSON.parse(XHR.responseText);
            errorMessage = err.Message;
            alert("Error: " + errorMessage);
        },
        failure: function (response) {
            alert(response.responseText);
        },
    });
};

function GetFilter(Userid) { 
//debugger;   
    $.ajax({
        url: "ActivityDashboard.aspx/GetUserFilter",
        dataType: "json",
        type: "POST",
        data: "{'UserId':'" + Userid + "'}",        
        contentType: "application/json; charset=utf-8", 
        success:SetFilterValue,       
        error: function (XHR, errStatus, errorThrown) {
            var err = JSON.parse(XHR.responseText);
            errorMessage = err.Message;
            alert("Error: " + errorMessage);
        },
        failure: function (response) {
            alert(response.responseText);
        },
    });
};
function SetFilterValue(response) {
//debugger;
   strAgent = response.d; 
   var Process = jQuery.parseJSON(strAgent);
   
   $('#hdnProcessId').val(ProcessId);
   $('#spnProcessName').text(ProcessName);
   SelectedAgentId="";
}