﻿var datefrom = ""; var dateto = ""; var curmonthNew = "";
var date = new Date();
var curdate = date.getDate();
var curdatefix = date.getDate();
var curmonth = date.getMonth();
var curmonthfix = date.getMonth();
var curyear = date.getFullYear();
var curyearfix = date.getFullYear();
curmonthNew = curmonth + 1;
var monthNames = ["January", "February", "March",
"April", "May", "June",
"July", "August", "September",
"October", "November", "December"
];
var groupby = 0;

$(document).ready(function() {
    $(".tab").hide();
    if (curmonthNew < 10) {
        curmonthNew = "0" + curmonthNew;
    }
    load();
    $(".prev").click(function() {
        if ($("#cboperiod").val() == "1") {
            groupby = 1;
            if (curmonth == 0) {
                curyear = curyear - 1;
                curmonth = 11;
            }
            else {
                curmonth = curmonth - 1;
            }
            $('#txtdate').val(monthNames[curmonth] + " " + curyear);
            curmonthNew = curmonth + 1;
            if (curmonthNew < 10) {
                curmonthNew = "0" + curmonthNew;
            }
            var daysInMonth = new Date(curyear, curmonthNew, 1, -1).getDate();
            datefrom = curyear.toString() + curmonthNew.toString() + "01";
            dateto = curyear.toString() + curmonthNew.toString() + daysInMonth;

        }
        else if ($("#cboperiod").val() == "3") {
            groupby = 3;
            date.setDate(date.getDate() - 1);
            var newcurdate = date.getDate();
            var newcurmonth = date.getMonth();
            var newcurmonthfix = date.getMonth();
            var newcuryear = date.getFullYear();
            var newcuryearfix = date.getFullYear();
            day = newcurdate;
            if (curmonthNew < 10) {
                curmonthNew = "0" + curmonthNew;
            }
            if (newcurdate < 10) {
                newcurdate = "0" + newcurdate;
            }
           
            $('#txtdate').val(newcurdate + " " + monthNames[newcurmonth] + " " + newcuryear);
            newcurmonth=newcurmonth+1;
             datefrom = newcuryear.toString() + newcurmonth.toString() + newcurdate;
            dateto = newcuryear.toString() + newcurmonth.toString() + newcurdate;
        }

        var str = "";
    GetData(datefrom, dateto, groupby);
    });
    $(".next").click(function() {
        if ($("#cboperiod").val() == "1") {
            $("#AgentStatus").hide();

            groupby = 1;
            if (curmonth == 11) {
                curyear = curyear + 1;
                curmonth = 0;

            }
            else {
                curmonth = curmonth + 1;
            }
            if (curmonth > curmonthfix && curyear == curyearfix) {
                curmonth = curmonth - 1;
                return false;
            }
            else {
                $('#txtdate').val(monthNames[curmonth] + " " + curyear);
                //return true;
            }
            curmonthNew = curmonth + 1;
            if (curmonthNew < 10) {
                curmonthNew = "0" + curmonthNew;
            }
            var daysInMonth = new Date(curyear, curmonthNew, 1, -1).getDate();
            datefrom = curyear.toString() + curmonthNew.toString() + "01";
            if(curmonthNew==11)
            {
            dateto = curyear.toString() + curmonthNew.toString() + curdate;
            }
            else
            {
            dateto = curyear.toString() + curmonthNew.toString() + daysInMonth;
            }
            
        }
        else if ($("#cboperiod").val() == "3") {
            groupby = 3;
//            if(curdate==30 && curmonth < newcurmonth)
//        {
//        date.setDate(date.getDate());
//        }
//        else if(curdate==31 && curmonth < newcurmonth)
//        {
//        date.setDate(date.getDate());
//        }
//        else
//        {
         date.setDate(date.getDate()+1);
//        }
        var newcurdate = date.getDate();
        var newcurmonth = date.getMonth();
        var newcurmonthfix = date.getMonth();
        var newcuryear = date.getFullYear();
        var newcuryearfix = date.getFullYear();
        daysInMonth = new Date(newcuryear, curmonthNew, 1, -1).getDate();
              
        if (curmonthNew < 10) {
            curmonthNew = "0" + curmonthNew;
        }
//        newcurdate=newcurdate+1;
        if (newcurdate < 10) {
            newcurdate = "0" + newcurdate;
        }
//        if(curdate==30 && curmonth < newcurmonth)
//        {
//        newcurdate=newcurdate-1;
//        date.setDate(date.getDate() - 1);
//        return false;
//        }
//        else if(curdate==31 && curmonth < newcurmonth)
//        {
//        newcurdate=newcurdate-1;
//        date.setDate(date.getDate() - 1);
//        return false;
//        }
        if (newcurdate > curdatefix && newcurmonth == curmonthfix && newcuryear == newcuryearfix) {
            newcurdate = newcurdate - 1;
            date.setDate(date.getDate() - 1);
            //$('#txtdate').val(newcurdate + " " + monthNames[newcurmonth] + " " + newcuryear);
            return;
        }

        else {
            //newcurdate = newcurdate + 1;
            $('#txtdate').val(newcurdate + " " + monthNames[newcurmonth] + " " + newcuryear);
            newcurmonth=newcurmonth+1;
        }
        datefrom = newcuryear.toString() + newcurmonth.toString() + newcurdate;
        dateto = newcuryear.toString() + newcurmonth.toString() + newcurdate;
        }

        var str = "";
    GetData(datefrom, dateto, groupby);
    });
});
function load() {
    if ($("#cboperiod").val() == "1") {
        $("#divhourlgv").removeClass("showgrid").addClass("hidegrid");
       $("#divgv").removeClass("hidegrid").addClass("showgrid"); 
        groupby = 1;
        $('#txtdate').val(monthNames[curmonth] + " " + curyear);
        if (curdate < 10) {
            curdate = "0" + curdate;
        }
        var daysInMonth = new Date(curyear, curmonthNew, 1, -1).getDate();
        datefrom = curyear.toString() + curmonthNew.toString() + "01";
        dateto = curyear.toString() + curmonthNew.toString() + curdate;
    }
    else if ($("#cboperiod").val() == "3") {
    $("#divgv").removeClass("showgrid").addClass("hidegrid");
        $("#divhourlgv").removeClass("hidegrid").addClass("showgrid");
       
        groupby = 3;
         if (curdate < 10) {
            curdate = "0" + curdate;
        }
        datefrom = curyear.toString() + curmonthNew.toString() + curdate;
        dateto = curyear.toString() + curmonthNew.toString() + curdate;
        $('#txtdate').val(curdate + " " + monthNames[curmonth] + " " + curyear);
    }
    var str = "";
    GetData(datefrom, dateto, groupby);
}

function GetData(datefrom, dateto, groupby) {
    $.ajax({
        url: "Forcasting.aspx/GetData",
        dataType: "json",
        type: "POST",
        data: "{'datefrom':'" + datefrom + "','dateto':'" + dateto + "','groupby':'" + groupby + "'}",
        contentType: "application/json; charset=utf-8",
        success: getdataresponse,
        error: function (XHR, errStatus, errorThrown) {
            var err = JSON.parse(XHR.responseText);
            errorMessage = err.Message;
            alert("Error: " + errorMessage);
        },
        failure: function (response) {
            alert(response.responseText);
        },
    });
}

function getdataresponse(response)
{
    str = response.d;
    Bindgrid(str);
    AHT(str);    
    Volume(str);
    Staff(str);
}

function AHT(str) {
    //var datadoc = response.d;
    if(str=="")
    {
    $("#divAHTlabel").hide();
    $("#divAHT").hide();
    }
    if(str!="")
    {
    var data = jQuery.parseJSON(str);
    if(data==null)
    {
        $("#divAHT").hide();
        
    }
    if (data != null) {
    $("#divAHT").show();
    $("#divAHT").show();
        var datalength = data.length;
        var d1 = []; var d2 = [];       
        for (var i = 0; i <= datalength - 1; i += 1) {
//        if(groupby==1)
//        {
            d1.push([data[i].label, data[i].ForecastAHT]);  
//        }
//        else
//        {
//            d1.push([data[i].HourlyInterval, data[i].ForecastAHT]);  
//        }
                            
        }
   var dataset = [
    {
        label: "Forecast AHT",
        data: d1,
        bars: {
                show: true,
                barWidth: .2,
                fill: true,
                lineWidth: 1,
                order: 1,
                fillColor:  "#90EE90"
            },
        //yaxis: { min: 0, max: 0, tickLength: 0, ticks: 0, showticks: false },
        //xaxis: { min: 1, max: 50, ticks: 1,order:1 },

        color: "#90EE90",
        lines: { show: false }
    },    
        ];

        var stack = 0, bars = true, lines = false, steps = false;
        $.plot($("#divAHT"), dataset, {
        xaxis: {
        min:1,
            tickLength: 0, // hide gridlines
        },
            series: {               
            },
            grid: {
                hoverable: true,                
                borderWidth: 0,                
            },
            
//            bars: {
//                show: true,
//                lineWidth: 0,
//                fill: true,
//                fillColor: { colors: [{ opacity: 1.0 }, { opacity: 1.0 }] },                
//            },
            legend:
                {
                    show:false,
                },
            valueLabels: {
                show: true
            }
        });
        $("#divAHT").bind("plothover", barHover);
    }
    }
}

function Volume(str) {
    //var datadoc = response.d;
    if(str=="")
    {
    $("#divVolumeLabel").hide();
    $("#divVolume").hide();
    }
    if(str!="")
    {
    var data = jQuery.parseJSON(str);
    if (data != null) {
     $("#divVolumeLabel").show();
    $("#divVolume").show();
        var datalength = data.length;
        var d1 = []; var d2 = [];       
        for (var i = 0; i <= datalength - 1; i += 1) {
//        if(groupby==1)
//        {
            d1.push([data[i].label, data[i].ForecastCallReceived]);  
//        }
//        else
//        {
//            d1.push([data[i].HourlyInterval, data[i].ForecastCallReceived]);  
//        }
                            
        }
   var dataset = [
    {
        label: "Forecast Volume",
        data: d1,
        bars: {
                show: false,
                barWidth: .2,
                fill: true,
                lineWidth: 1,
                order: 1,
                fillColor:  "#90EE90"
            },
        //color: "#90EE90",
        lines: { show: true }
    },    
        ];

        var stack = 0, bars = true, lines = false, steps = false;
        $.plot($("#divVolume"), dataset, {
        xaxis: {
        min:1,
            tickLength: 0, // hide gridlines
        },
            series: {               
            },
            grid: {
                hoverable: true,                
                borderWidth: 0,                
            },

            legend:
                {
                    show:false,
                },
            valueLabels: {
                show: true
            }
        });
        $("#divVolume").bind("plothover", barHover);
    }
    }
}

function Staff(str) {
    //var datadoc = response.d;
    if(str=="")
    {
    $("#divstafflabel").hide();
    $("#divstaff").hide();
    }
    if(str!="")
    {
    var data = jQuery.parseJSON(str);
    if (data != null) {
    $("#divstafflabel").show();
    $("#divstaff").show();
        var datalength = data.length;
        var d1 = []; var d2 = [];       
        for (var i = 0; i <= datalength - 1; i += 1) {
//        if(groupby==1)
//        {
            d1.push([data[i].label, data[i].data]);  
//        }
//        else
//        {
//            d1.push([data[i].HourlyInterval, data[i].ForecastedStaffRequired]);  
//        }
//                            
//        }
}
          var dataset = [
    {
        label: "Forecast Volume",
        data: d1,
        bars: {
                show: false,
                barWidth: .2,
                fill: true,
                lineWidth: 1,
                order: 1,
                fillColor:  "#90EE90"
            },
        color: "red",
        lines: { show: true }
    },    
        ];
        $.plot($("#divstaff"), dataset, {
        xaxis: {
        min:1,
            tickLength: 0, // hide gridlines
        },
       
           series: {               
            },
            grid: {
                hoverable: true,                
                borderWidth: 0,                
            },

            legend:
                {
                    show:false,
                },
            valueLabels: {
                show: true
            }
        });
        $("#divstaff").bind("plothover", barHover);
    }
    }
}

function barHover(event, pos, item) {
    if (item) {
        if ((previousLabel != item.series.label) || (previousPoint != item.dataIndex)) {
            previousPoint = item.dataIndex;
            previousLabel = item.series.label;
            percent = parseFloat(item.series.percent).toFixed(2);
           
            $("#tooltip").remove();

            var x = item.datapoint[0];
            var y = item.datapoint[1].toString();           
            var color = item.series.color;
            var str = "";
            if(groupby==1 && datefrom==dateto)
            {
            str="<strong> Hour " + x + "</strong><br>"
            }
            else if(groupby==1 && datefrom!=dateto)
            {
            str="<strong> Day " + x + "</strong><br>"
            }
            else
            {
            str="<strong> Hour " + x + "</strong><br>"
            }
            

            showTooltip(item.pageX, item.pageY, color,
            str +
             "<strong>" + item.series.label + "</strong>: <strong>" + y + "</strong>");
        }
    } else {
        $("#tooltip").remove();
        previousPoint = null;
    }
}

var previousPoint = null,
    previousLabel = null;
function showTooltip(x, y, color, contents) {
    $('<div id="tooltip">' + contents + '</div>').css({
        position: 'absolute',
        display: 'none',
        top: y - 40,
        left: x - 60,
        border: '2px solid ' + color,
        padding: '3px',
        'font-size': '9px',
        'border-radius': '5px',
        'background-color': '#fff',
        'font-family': 'Verdana, Arial, Helvetica, Tahoma, sans-serif',
        'text-align': 'center',
        opacity: 0.9
    }).appendTo("body").fadeIn(200);
}

function Bindgrid(str) { 
if(str=="")
{
if(groupby==1)
{
$("#divgv").hide();
}
else
{
$("#divhourlgv").hide();
}
}  
if(str!="")
{
if(groupby==1)
{
$("#divgv").show();
}
else
{
$("#divhourlgv").show();
}
    var data = jQuery.parseJSON(str);
    
    if (data != null) {
    var datalength = data.length;      
        $("#gvDatahour").empty();       
       $("#gvData").empty();
       if(datefrom==dateto)
       {
       $("#gvData").append("<tr><th>Hourly Interval</th><th>Forecast AHT</th><th>Forecast Volume</th><th>Forecast Staff</th></tr>"); 
       }
       else
       {
       $("#gvData").append("<tr><th>Day</th><th>Forecast AHT</th><th>Forecast Volume</th><th>Forecast Staff</th></tr>"); 
       }
       $("#gvDatahour").append("<tr><th>Hourly Interval</th><th>Forecast AHT</th><th>Forecast Volume</th><th>Forecast Staff</th></tr>");     
       for (var i = 0; i <= datalength - 1; i += 1) {
       if(groupby==1)
       {          
     
       $("#gvData").append("<tr><td>" + data[i].label + "</td><td>" + data[i].ForecastAHT + "</td><td>" + data[i].ForecastCallReceived + "</td><td>" + data[i].data + "</td></tr>");      
       }
       else
      
       {     
       $("#gvDatahour").append("<tr><td>" + data[i].label + "</td><td>" + data[i].ForecastAHT + "</td><td>" + data[i].ForecastCallReceived + "</td><td>" + data[i].data + "</td></tr>");     
       }

       }      
    }
    }
}