﻿Imports System.Data.Sql
Imports System.Data.SqlClient
Imports System.Data

Partial Class _assets_usrcontrol_TrackerHeader
    Inherits System.Web.UI.UserControl

    Dim conn As SqlConnection
    Dim cmd As SqlCommand
    Dim adp As SqlDataAdapter

    Dim connCRM As String = Common.connCRM
    Dim connLeads As String = Common.connLeads
    Dim connreport As String = Common.connreport

#Region "--- Properties ---"
    Property AgentID() As String
        Get
            Return ViewState("AgentID")
        End Get
        Set(ByVal value As String)
            ViewState("AgentID") = value
        End Set
    End Property
    Property Agentname() As String
        Get
            Return ViewState("Agentname")
        End Get
        Set(ByVal value As String)
            ViewState("Agentname") = value
        End Set
    End Property
#End Region
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            If AgentID Is Nothing Or AgentID = "" Then
                FormsAuthentication.SignOut()
            Else

                'If Not Common.AuthenticatePage(Request.Url, AgentID, Request.ApplicationPath) Then
                '    Response.Redirect("~/Unauthorized.htm")
                'End If
                If Not AuthenticatePage(Request.Url, AgentID, Request.ApplicationPath) Then
                    Response.Redirect("~/Unauthorized.htm")
                End If

            End If
        End If
    End Sub


    Public Function AuthenticatePage(ByVal URL As System.Uri, ByVal Agentid As String, ByVal ApplicationPath As String) As Boolean
        Dim strPath(), pagepath As String

        If ApplicationPath <> "/" Then
            pagepath = URL.AbsolutePath.ToString.Substring(URL.AbsolutePath.ToString.IndexOf(ApplicationPath) + ApplicationPath.Length + 1)
        Else
            pagepath = URL.AbsolutePath.ToString.Substring(1)
        End If

        If pagepath.Contains("?") Then
            pagepath = pagepath.Substring(0, pagepath.ToLower.LastIndexOf("?"))
        End If
        ' slashcount = CountCharacter(pagepath, "/")

        strPath = URL.Segments()

        'Dim db As New DBAccess("report")
        'db.slDataAdd("agentid", Agentid)
        'db.slDataAdd("module", strPath(strPath.Length - 2).Replace("/", ""))
        'db.slDataAdd("page", pagepath)
        'Dim dt As DataTable = db.ReturnTable("usp_ValidatePage", , True)
        'db = Nothing

        '------------------------Rajkumar Start 2 
        ' Dim dtCampID As New DataTable
        ' ddlAgents.Items.Clear()

        ' Dim dt As New DataTable

        'conn = New SqlConnection(connreport)
        'cmd = New SqlCommand()
        'cmd.Parameters.AddWithValue("agentid", Agentid)
        'cmd.Parameters.AddWithValue("module", strPath(strPath.Length - 2).Replace("/", ""))
        'cmd.Parameters.AddWithValue("page", pagepath)
        'cmd.Connection = conn
        'cmd.CommandType = CommandType.StoredProcedure
        'cmd.CommandText = "usp_ValidatePage"

        'adp = New SqlDataAdapter(cmd)
        'adp.Fill(dt)
        'cmd = Nothing
        'adp = Nothing

        'ddlAgents.DataSource = dtCampID
        'ddlAgents.DataTextField = "agent name"
        'ddlAgents.DataValueField = "AgentId"
        'ddlAgents.DataBind()
        'dtCampID = Nothing
        '--------------------------Rajkumar End 2

        'db = New DBAccess("CRM")
        'db.slDataAdd("Agentid", Agentid)
        'db.slDataAdd("URL", strPath(strPath.Length - 1).Replace("/", ""))
        'db.Executeproc("usp_SaveTermsVisit")
        'db = Nothing

        ''''''''''''rajkumar  --- Start
        conn = New SqlConnection(connCRM)
        cmd = New SqlCommand()

        cmd.Parameters.AddWithValue("Agentid", Agentid)
        cmd.Parameters.AddWithValue("URL", strPath(strPath.Length - 1).Replace("/", ""))

        cmd.Connection = conn
        cmd.CommandType = CommandType.StoredProcedure
        cmd.CommandText = "usp_SaveTermsVisit"

        conn.Open()
        cmd.ExecuteScalar()
        conn.Close()
        cmd = Nothing
        ''''''''''''rajkumar  --- End

        'If Agentid.ToLower = "nss43793" Then Return True
        'If dt.Rows.Count > 0 Then

        '    Return True
        'Else
        '    Return False
        'End If
        Return True

    End Function

End Class
