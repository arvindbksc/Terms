﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Drawing.Imaging;
using System.Drawing.Text;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.IO;

public partial class _assets_usrcontrol_Cimage : System.Web.UI.UserControl
{
    protected void Page_Load(object sender, EventArgs e)
    {

        
        //System.IO.DirectoryInfo di = new DirectoryInfo(Server.MapPath("~\\myupload\\Capimages"));

        //foreach (FileInfo file in di.GetFiles())
        //{

        //    Image1.ImageUrl = @"~\myupload\Capimages\Captcha.jpg"; //Server.MapPath("~\\myupload\\Capimages\\") + "Captcha.jpg";
        //}

 

      //  // Create a random code and store it in the Session object.
        this.Session["CaptchaImageText"] = GenerateRandomCode();
        // Create a CAPTCHA image using the text stored in the Session object.
        RandomImage ci = new RandomImage(this.Session["CaptchaImageText"].ToString(), 300, 75);


        // Change the response headers to output a JPEG image.
        this.Response.Clear();
        this.Response.ContentType = "image/jpeg";

        // Write the image to the response stream in JPEG format.
        ci.Image.Save(this.Response.OutputStream, ImageFormat.Jpeg);


        //  ci.Image.Save(Server.MapPath(@"~\Images\Test.jpg"), ImageFormat.Jpeg);



        // Dispose of the CAPTCHA image object.
        ci.Dispose();

    }


    // Function to generate random string with Random class.
    private string GenerateRandomCode()
    {
        Random r = new Random();
        string s = "";
        for (int j = 0; j < 5; j++)
        {
            int i = r.Next(3);
            int ch;
            switch (i)
            {
                case 1:
                    ch = r.Next(0, 9);
                    s = s + ch.ToString();
                    break;
                case 2:
                    ch = r.Next(65, 90);
                    s = s + Convert.ToChar(ch).ToString();
                    break;
                case 3:
                    ch = r.Next(97, 122);
                    s = s + Convert.ToChar(ch).ToString();
                    break;
                default:
                    ch = r.Next(97, 122);
                    s = s + Convert.ToChar(ch).ToString();
                    break;
            }
            r.NextDouble();
            r.Next(100, 1999);
        }
        return s;
    }

    public void RefreshImage()
    {

        //if (System.IO.File.Exists(Server.MapPath("~/Images/")))
        //{
        //    System.IO.File.Delete(Server.MapPath("~/Images/"));
        //}


        string[] files = System.IO.Directory.GetFiles(Server.MapPath("~\\myupload\\Capimages"));
        foreach (string file in files)
        {
            System.IO.File.Delete(file);

        }


        // Create a random code and store it in the Session object.
        this.Session["CaptchaImageText"] = GenerateRandomCode();
        // Create a CAPTCHA image using the text stored in the Session object.
        RandomImage ci = new RandomImage(this.Session["CaptchaImageText"].ToString(), 300, 75);
        // Change the response headers to output a JPEG image.
        this.Response.Clear();
        this.Response.ContentType = "image/jpeg";
        // Write the image to the response stream in JPEG format.
        //ci.Image.Save(this.Response.OutputStream, ImageFormat.Jpeg);


        // ci.Image.Save(@"~\Images\" +  DateTime.Now.ToString("yyyyMMddHHmm") + ".jpg", ImageFormat.Jpeg);

        ci.Image.Save(Server.MapPath(@"~\\myupload\\Capimages\\Captcha.jpg"), ImageFormat.Jpeg);



        // Dispose of the CAPTCHA image object.
        ci.Dispose();

    }
    ///


    protected void Refresh_Click(object sender, EventArgs e)
    {


        RefreshImage();
        //  System.Threading.Thread.Sleep(5000);
    }


    //protected void Button1_Click(object sender, EventArgs e)
    //{
    //    if (Session["CaptchaImageText"] != null)
    //    {
    //        if (this.txtimgcode.Text == this.Session["CaptchaImageText"].ToString())
    //        {
    //            lblmsg.Text = "Excellent.......";
    //        }
    //        else
    //        {
    //            lblmsg.Text = "image code is not valid.";
    //        }
    //        this.txtimgcode.Text = "";
    //    }
    //}
}