﻿
Partial Class _assets_usrcontrol_DateTimePicker3
    Inherits System.Web.UI.UserControl

    Protected Sub imgcal_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles imgcal.Click
        Calendar1.Visible = True
    End Sub

    Protected Sub Calendar1_SelectionChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles Calendar1.SelectionChanged
        Dim datetime1 As DateTime = Convert.ToDateTime(Calendar1.SelectedDate.ToShortDateString())
        ' Dim Timespan1 As TimeSpan = New TimeSpan(DateTime.Now.Hour, DateTime.Now.Minute, DateTime.Now.Second)

        ' Dim Timespan1 As TimeSpan = New TimeSpan(DateTime.Now.ToString("HH:mm:ss"))
        '  datetime1 = datetime1.Add(Timespan1)
        TextBox1.Text = CDate(datetime1).ToString("yyyyMMdd")
        '  Calendar1.SelectedDate = TextBox1.Text

        Calendar1.Visible = False

    End Sub
    Public ReadOnly Property Text() As String
        Get
            Dim str As String = TextBox1.Text
            Return str
        End Get
    End Property
    Public Property value() As String
        Get
            Dim str As String = TextBox1.Text
            Return str
        End Get
        Set(ByVal value As String)
            TextBox1.Text = value
        End Set
    End Property

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
        If Not IsPostBack Then
            If Me.Text = "" Then
                Me.value = CDate(DateTime.Now).ToString("yyyyMMdd")
                'DateTime.Now.ToString("dd-MMM-yyyy HH:mm:ss")
            End If


        End If
    End Sub
End Class
