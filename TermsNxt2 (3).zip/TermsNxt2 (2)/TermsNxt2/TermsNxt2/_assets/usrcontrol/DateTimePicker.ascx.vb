﻿Namespace TermsNxt2
    Partial Class _assets_usrcontrol_DateTimePicker
        Inherits System.Web.UI.UserControl

        Protected Sub imgcal_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles imgcal.Click
            Calendar1.Visible = True
        End Sub

        Protected Sub Calendar1_SelectionChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles Calendar1.SelectionChanged
            Dim datetime1 As DateTime = Convert.ToDateTime(Calendar1.SelectedDate.ToShortDateString())
            Dim Timespan1 As TimeSpan = New TimeSpan(DateTime.Now.Hour, DateTime.Now.Minute, DateTime.Now.Second)
            ' Dim Timespan1 As TimeSpan = New TimeSpan(DateTime.Now.ToString("HH:mm:ss"))
            datetime1 = datetime1.Add(Timespan1)
            TextBox1.Text = datetime1.ToString("dd-MMM-yyyy HH:mm:ss")
            Calendar1.Visible = False
        End Sub
        Public ReadOnly Property Text() As String
            Get
                Dim str As String = TextBox1.Text
                Return str
            End Get
        End Property
        Public Property value() As String
            Get
                Dim str As String = TextBox1.Text
                Return str
            End Get
            Set(ByVal value As String)
                TextBox1.Text = value
            End Set
        End Property
    End Class
End Namespace