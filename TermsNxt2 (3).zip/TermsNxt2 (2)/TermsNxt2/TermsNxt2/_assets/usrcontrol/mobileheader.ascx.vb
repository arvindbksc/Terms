﻿
Partial Class _assets_usrcontrol_mobileheader
    Inherits System.Web.UI.UserControl

    Protected Sub lnkLogout_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles lnkLogout.Click
        FormsAuthentication.SignOut()
        Response.Redirect("~/mobile/default.aspx")
    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Session("Agentid") = "0" Then
            FormsAuthentication.SignOut()

        End If
    End Sub
End Class
