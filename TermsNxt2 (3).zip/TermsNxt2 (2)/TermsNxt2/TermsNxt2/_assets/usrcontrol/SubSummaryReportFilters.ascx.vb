﻿Imports System.Data
Imports com.nss.DBAccess
Imports System.Data.SqlClient
Partial Class _assets_usrcontrol_SubSummaryReportFilters
    Inherits System.Web.UI.UserControl
#Region "Properties"
    Property AgentID() As String
        Get
            Return ViewState("AgentID")
        End Get
        Set(ByVal value As String)
            ViewState("AgentID") = value
        End Set
    End Property
#End Region
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        campid = Session("SelectedCampaignid")
        If Not IsPostBack Then
            SetDateFilters()
            getdata()
        End If
    End Sub
    Public ReadOnly Property calltype() As String
        Get
            Return ddlCallType.SelectedValue
        End Get
    End Property
    Public ReadOnly Property Errortype() As String
        Get
            Return ddlErrorType.SelectedValue
        End Get
    End Property
    Public ReadOnly Property Qe() As String
        Get
            Return ddlQE.SelectedValue
        End Get
    End Property
    Public ReadOnly Property cmfid() As String
        Get
            Return ddlcmf.SelectedValue
        End Get
    End Property
    Public ReadOnly Property DateFrom() As String
        Get
            Return DdlYears.SelectedValue.ToString & DdlMonths.SelectedValue.ToString.PadLeft(2, "0") & DdlDay.SelectedValue.ToString.PadLeft(2, "0")
        End Get
    End Property
    Public ReadOnly Property DateTO() As String
        Get
            Return Ddlyear1.SelectedValue.ToString & Ddlmonth1.SelectedValue.ToString.PadLeft(2, "0") & Ddlday1.SelectedValue.ToString.PadLeft(2, "0")
        End Get
    End Property
    Private Sub SetUserFilters()
        Dim db As New DBAccess("qualitynew")
        Dim dr As DataRow = db.ReturnRow("Select * from Tbl_UserFilters where userid='" & Session("AgentID") & "'")
        db = Nothing
        Try
            If dr Is Nothing Then
                For Each item As ListItem In DdlYears.Items
                    If item.Text = Now.Year.ToString Then
                        DdlYears.ClearSelection()
                        item.Selected = True
                    End If
                Next
                For Each item As ListItem In Ddlyear1.Items
                    If item.Text = Now.Year.ToString Then
                        Ddlyear1.ClearSelection()
                        item.Selected = True
                    End If
                Next
                For Each item As ListItem In DdlDay.Items
                    If item.Value = Now.Day.ToString.PadLeft(2, "0") Then
                        DdlDay.ClearSelection()
                        item.Selected = True
                    End If
                Next
                For Each item As ListItem In Ddlday1.Items
                    If item.Value = Now.Day.ToString.PadLeft(2, "0") Then
                        Ddlday1.ClearSelection()
                        item.Selected = True
                    End If
                Next
                For Each item As ListItem In Ddlmonth1.Items
                    If item.Value = Now.Month.ToString.PadLeft(2, "0") Then
                        Ddlmonth1.ClearSelection()
                        item.Selected = True
                    End If
                Next
                For Each item As ListItem In DdlMonths.Items
                    If item.Value = Now.Month.ToString.PadLeft(2, "0") Then
                        DdlMonths.ClearSelection()
                        item.Selected = True
                    End If
                Next
            Else
                If Not IsDBNull(dr("QEID")) Then
                    'MsgBox(ddlQE.Items.FindByValue(dr("QEID")).Value)
                    ddlQE.ClearSelection()
                    ddlQE.Items.FindByValue(dr("QEID")).Selected = True
                End If
                If Not IsDBNull(dr("CallType")) Then
                    'MsgBox(ddlCallType.Items.FindByValue(dr("CallType")).Value)
                    ddlCallType.ClearSelection()
                    ddlCallType.Items.FindByValue(dr("CallType")).Selected = True
                End If
                If Not IsDBNull(dr("ErrorType")) Then
                    'MsgBox(ddlErrorType.Items.FindByValue(dr("ErrorType")).Value)
                    ddlErrorType.ClearSelection()
                    ddlErrorType.Items.FindByValue(dr("ErrorType")).Selected = True
                End If
                If Not IsDBNull(dr("cmfid")) Then
                    'MsgBox(ddlErrorType.Items.FindByValue(dr("ErrorType")).Value)
                    ddlcmf.ClearSelection()
                    ddlcmf.Items.FindByValue(dr("cmfid")).Selected = True
                End If
            End If

        Catch ex As Exception
            Dim db1 As New DBAccess("qualitynew")
            db1.exeSQL("delete from Tbl_UserFilters where userid='" & Session("AgentID") & "'")
            db1 = Nothing
            SetUserFilters()
        End Try
    End Sub
    Private campid As String
    Private Sub SetDateFilters()
        Dim db As New DBAccess("qualitynew")
        Dim dr As DataRow = db.ReturnRow("Select * from Tbl_UserFilters where userid='" & Session("AgentID") & "'")
        db = Nothing
        Try
            If dr Is Nothing Then
                For Each item As ListItem In DdlYears.Items
                    If item.Text = Now.Year.ToString Then
                        DdlYears.ClearSelection()
                        item.Selected = True
                    End If
                Next
                For Each item As ListItem In Ddlyear1.Items
                    If item.Text = Now.Year.ToString Then
                        Ddlyear1.ClearSelection()
                        item.Selected = True
                    End If
                Next
                For Each item As ListItem In DdlDay.Items
                    If item.Value = Now.Day.ToString.PadLeft(2, "0") Then
                        DdlDay.ClearSelection()
                        item.Selected = True
                    End If
                Next
                For Each item As ListItem In Ddlday1.Items
                    If item.Value = Now.Day.ToString.PadLeft(2, "0") Then
                        Ddlday1.ClearSelection()
                        item.Selected = True
                    End If
                Next
                For Each item As ListItem In Ddlmonth1.Items
                    If item.Value = Now.Month.ToString.PadLeft(2, "0") Then
                        Ddlmonth1.ClearSelection()
                        item.Selected = True
                    End If
                Next
                For Each item As ListItem In DdlMonths.Items
                    If item.Value = Now.Month.ToString.PadLeft(2, "0") Then
                        DdlMonths.ClearSelection()
                        item.Selected = True
                    End If
                Next
            Else
                If Not IsDBNull(dr("DateFrom")) Then
                    'MsgBox(ddlErrorType.Items.FindByValue(dr("ErrorType")).Value)
                    DdlYears.ClearSelection()
                    DdlMonths.ClearSelection()
                    DdlDay.ClearSelection()
                    Dim datefrom As String = dr("DateFrom")
                    Dim day, year, month As String
                    day = datefrom.Substring(6, 2)
                    month = datefrom.Substring(4, 2)
                    year = datefrom.Substring(0, 4)
                    DdlYears.Items.FindByValue(year).Selected = True
                    DdlMonths.Items.FindByValue(month).Selected = True
                    DdlDay.Items.FindByValue(day).Selected = True
                End If
                If Not IsDBNull(dr("DateTo")) Then
                    'MsgBox(ddlErrorType.Items.FindByValue(dr("ErrorType")).Value)
                    Ddlyear1.ClearSelection()
                    Ddlmonth1.ClearSelection()
                    Ddlday1.ClearSelection()
                    Dim datefrom As String = dr("DateTo")
                    Dim day, year, month As String
                    day = datefrom.Substring(6, 2)
                    month = datefrom.Substring(4, 2)
                    year = datefrom.Substring(0, 4)
                    Ddlyear1.Items.FindByValue(year).Selected = True
                    Ddlmonth1.Items.FindByValue(month).Selected = True
                    Ddlday1.Items.FindByValue(day).Selected = True
                End If
            End If
        Catch ex As Exception
            Dim db1 As New DBAccess("qualitynew")
            db1.exeSQL("delete from Tbl_UserFilters where userid='" & Session("AgentID") & "'")
            db1 = Nothing
            SetDateFilters()
        End Try
    End Sub

    Private Sub saveUserFilters()
        'Dim fromDate, todate As String
        ' fromDate = DdlYears.SelectedValue.ToString & DdlMonths.SelectedValue.ToString.PadLeft(2, "0") & DdlDay.SelectedValue.ToString.PadLeft(2, "0")
        'todate = Ddlyear1.SelectedValue.ToString & Ddlmonth1.SelectedValue.ToString.PadLeft(2, "0") & Ddlday1.SelectedValue.ToString.PadLeft(2, "0")
        Dim dbFilter As New DBAccess("qualitynew")
        If dbFilter.ReturnValue("select count(*) from Tbl_UserFilters where UserId='" & Session("AgentID") & "'", False) = 0 Then
            dbFilter.slDataAdd("UserId", Session("AgentID"))
            dbFilter.slDataAdd("Campaignid", 0)
            dbFilter.slDataAdd("Date", Ddlyear1.SelectedValue.ToString & Ddlmonth1.SelectedValue.ToString.PadLeft(2, "0") & Ddlday1.SelectedValue.ToString.PadLeft(2, "0"))
            dbFilter.slDataAdd("outcome", 0)
            dbFilter.slDataAdd("customerid", 0)
            dbFilter.InsertinTable("Tbl_UserFilters")
        End If
        dbFilter.slDataAdd("QEID", ddlQE.SelectedValue)
        dbFilter.slDataAdd("CallType", ddlCallType.SelectedValue)
        dbFilter.slDataAdd("ErrorType", ddlErrorType.SelectedValue)
        dbFilter.slDataAdd("cmfid", ddlcmf.SelectedValue)
        dbFilter.slDataAdd("datefrom", DateFrom)
        dbFilter.slDataAdd("dateto", DateTO)
        dbFilter.UpdateinTable("Tbl_UserFilters", "UserId='" & Session("AgentID") & "'")
        dbFilter = Nothing
    End Sub

    Private Sub getdata()

        getQE()
        getcalltype()
        getErrorType()
        getCMFList()
        SetUserFilters()

        'SetUserFilters()


    End Sub
    Public Event firedata()
    Protected Sub btnGetTransactions_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnGetTransactions.Click
        saveUserFilters()
        getdata()
        RaiseEvent firedata()
    End Sub
    Private Sub getcalltype()
        If Not campid Is Nothing Then
            ' Dim db As New DBAccess("qualitynew")
            Dim db As New DBAccess
            'fromDate = DdlYears.SelectedValue.ToString & DdlMonths.SelectedValue.ToString.PadLeft(2, "0") & DdlDay.SelectedValue.ToString.PadLeft(2, "0")
            'todate = Ddlyear1.SelectedValue.ToString & Ddlmonth1.SelectedValue.ToString.PadLeft(2, "0") & Ddlday1.SelectedValue.ToString.PadLeft(2, "0")
            db.slDataAdd("DateFrom", DateFrom)
            db.slDataAdd("DateTo", DateTO)
            db.slDataAdd("camp", campid)
            db.slDataAdd("Filter", "CallType")
            Dim dt As DataTable = db.ReturnTable("usp_QualitySummaryGetFilter_New", , True)
            db = Nothing
            ddlCallType.DataTextField = "calltype"
            ddlCallType.DataValueField = "calltype"
            ddlCallType.DataSource = dt
            ddlCallType.DataBind()
            Dim item As New ListItem
            item.Text = "All"
            item.Value = "%"
            ddlCallType.Items.Insert(0, item)
            dt = Nothing
        End If
        
    End Sub
    Private Sub getErrorType()
        If Not campid Is Nothing Then
            '  Dim db As New DBAccess("qualitynew")
            Dim db As New DBAccess
            'fromDate = DdlYears.SelectedValue.ToString & DdlMonths.SelectedValue.ToString.PadLeft(2, "0") & DdlDay.SelectedValue.ToString.PadLeft(2, "0")
            'todate = Ddlyear1.SelectedValue.ToString & Ddlmonth1.SelectedValue.ToString.PadLeft(2, "0") & Ddlday1.SelectedValue.ToString.PadLeft(2, "0")
            db.slDataAdd("DateFrom", DateFrom)
            db.slDataAdd("DateTo", DateTO)
            db.slDataAdd("camp", campid)
            db.slDataAdd("Filter", "ErrorType")
            Dim dt As DataTable = db.ReturnTable("usp_QualitySummaryGetFilter_New", , True)
            db = Nothing
            ddlErrorType.DataTextField = "ErrorType"
            ddlErrorType.DataValueField = "ErrorType"
            ddlErrorType.DataSource = dt
            ddlErrorType.DataBind()
            Dim item As New ListItem
            item.Text = "All"
            item.Value = "%"
            ddlErrorType.Items.Insert(0, item)
            dt = Nothing
        End If
    End Sub
    Private Sub getQE()
        If Not campid Is Nothing Then
            ' Dim db As New DBAccess("qualitynew")
            Dim db As New DBAccess
            db.slDataAdd("DateFrom", DateFrom)
            db.slDataAdd("DateTo", DateTO)
            db.slDataAdd("camp", campid)
            db.slDataAdd("Filter", "QE")
            Dim dt As DataTable = db.ReturnTable("usp_QualitySummaryGetFilter_New", , True)
            db = Nothing
            ddlQE.DataTextField = "QEName"
            ddlQE.DataValueField = "QEID"
            ddlQE.DataSource = dt
            ddlQE.DataBind()
            Dim item1 As New ListItem
            item1.Text = "All"
            item1.Value = "%"
            ddlQE.Items.Insert(0, item1)
            dt = Nothing
        End If
    End Sub
    Private Sub getCMFList()
        If Not campid Is Nothing Then
            '   Dim db As New DBAccess("qualitynew")
            Dim db As New DBAccess
            'fromDate = DdlYears.SelectedValue.ToString & DdlMonths.SelectedValue.ToString.PadLeft(2, "0") & DdlDay.SelectedValue.ToString.PadLeft(2, "0")
            'todate = Ddlyear1.SelectedValue.ToString & Ddlmonth1.SelectedValue.ToString.PadLeft(2, "0") & Ddlday1.SelectedValue.ToString.PadLeft(2, "0")
            db.slDataAdd("DateFrom", DateFrom)
            db.slDataAdd("DateTo", DateTO)
            db.slDataAdd("camp", campid)
            db.slDataAdd("Filter", "CMFList")
            Dim dt As DataTable = db.ReturnTable("usp_QualitySummaryGetFilter_New", , True)
            db = Nothing
            ddlcmf.DataTextField = "CmfName"
            ddlcmf.DataValueField = "cmfid"
            ddlcmf.DataSource = dt
            ddlcmf.DataBind()
            Dim item1 As New ListItem
            item1.Text = "All"
            item1.Value = 0
            ddlcmf.Items.Insert(0, item1)
            dt = Nothing
        End If
    End Sub

    Protected Sub ddlQE_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ddlQE.SelectedIndexChanged
        saveUserFilters()
        RaiseEvent firedata()
    End Sub

    Protected Sub ddlcmf_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ddlcmf.SelectedIndexChanged
        saveUserFilters()
        RaiseEvent firedata()
    End Sub

    Protected Sub ddlCallType_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ddlCallType.SelectedIndexChanged
        saveUserFilters()
        RaiseEvent firedata()
    End Sub

    Protected Sub ddlErrorType_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ddlErrorType.SelectedIndexChanged
        saveUserFilters()
        RaiseEvent firedata()
    End Sub
End Class
