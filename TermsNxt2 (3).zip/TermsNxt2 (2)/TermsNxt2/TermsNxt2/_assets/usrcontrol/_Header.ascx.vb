﻿
Partial Public Class _Header
    Inherits System.Web.UI.UserControl


#Region "Properties"
    Property AgentID() As String
        Get
            Return ViewState("AgentID")
        End Get
        Set(ByVal value As String)
            ViewState("AgentID") = value
        End Set
    End Property
#End Region

    Protected Sub LnkLogout_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles lnkLogout.Click
        '@ark
        Session.Abandon()
        FormsAuthentication.SignOut()
        ScriptManager.RegisterClientScriptBlock(Me, System.Type.GetType("System.String"), "back", "javascript:window.history.forward(1);", False)
        lnkLogout.Text = ""

        'Response.Redirect("~/Default.aspx")
        'Response.Redirect("weblogin.aspx?web=true")


        Dim serverpath As String
        '''''''''''''If Request.Url.Host = "localhost" Then
        '''''''''''''    serverpath = HttpContext.Current.Request.ApplicationPath
        '''''''''''''Else
        '''''''''''''    ' serverpath = "http://terms-monitor.niit-tech.com"
        '''''''''''''    serverpath = System.Configuration.ConfigurationManager.AppSettings("LiveServerPath")

        '''''''''''''End If
        'Response.Redirect(serverpath & "/weblogin.aspx?web=true")
        'Response.Redirect(HttpUtility.UrlDecode(serverpath & "/^weblogin"))
        Response.Redirect(serverpath & "/_weblogin.aspx")

        ' Dim paramvalue As String = HttpUtility.UrlEncode(RC4.EncryptURL("true"))
        ' Response.Redirect(String.Format(serverpath & "/weblogin.aspx?web={0}", paramvalue))


    End Sub
    Protected Sub lnkHome_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles lnkHome.Click
        If Not Session("agentid") Is Nothing Then
            Response.Redirect("~/Data/^Sitemap")
        End If


    End Sub


    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        If Not IsPostBack Then
            '        AddHandler _button.Click, AddressOf _button_Clicked

            If Session("agentid") Is Nothing Then
                FormsAuthentication.SignOut()
                lnkLogout.Text = ""
            Else
                AgentID = Session("AgentID")
                lnkLogin.InnerText = ""
                'If Not Common.AuthenticatePage(Request.Url, AgentID, Request.ApplicationPath) Then
                '    Response.Redirect("~/Unauthorized.htm")
                'End If
            End If
        End If
    End Sub

End Class
