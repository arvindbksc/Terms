﻿Public Class _breadcrumbs
    Inherits System.Web.UI.UserControl

    'Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

    'End Sub
    Public Property CurrentPage() As String
        Get
            Return ViewState("currentpage")
        End Get
        Set(ByVal value As String)
            ViewState("currentpage") = value
            If Previouscrumbs Is Nothing Then
                loadcrumbs()
            End If

            lblbreadcrumbs.InnerHtml = Previouscrumbs & " - " & value
        End Set
    End Property
    Public Property Previouscrumbs() As String
        Get
            Return ViewState("Previouscrumbs")
        End Get
        Set(ByVal value As String)
            ViewState("Previouscrumbs") = value
        End Set
    End Property


    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        'If Not IsPostBack Then
        '    loadcrumbs()
        'End If
    End Sub

    Private Sub loadcrumbs()
        Dim dirstr As String
        dirstr = ""
        If Request.ApplicationPath <> "/" And Request.ApplicationPath <> "" Then


            dirstr = Request.Url.AbsolutePath.Replace(Request.ApplicationPath, "")
        Else
            dirstr = Request.Url.AbsolutePath
        End If

        'Response.Write(dirstr)
        Dim strb As New StringBuilder
        Dim previouspath As String = Request.Url.AbsoluteUri.Replace(dirstr, "")
        Dim currentpath As String
        strb.Append("<a href='" & previouspath & "'>Home</a>")
        Dim dirs() As String = dirstr.Split("/")
        For ictr As Integer = 1 To dirs.Length - 2
            currentpath = previouspath & "/" & dirs(ictr)
            strb.Append(" - ")
            strb.Append("<a href='" & currentpath & "'>" & dirs(ictr) & "</a>")
            previouspath = currentpath
        Next
        Previouscrumbs = strb.ToString
    End Sub

End Class