﻿
Partial Class _assets_usrcontrol_MobileucDatePicker
    Inherits System.Web.UI.UserControl
    Public Event Changed As System.EventHandler
    Property Height() As Unit
        Get
            Return TextBox1.Height
        End Get
        Set(ByVal value As Unit)
            TextBox1.Height = value
        End Set
    End Property
    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
        If Not IsPostBack Then
            If Me.Text = "" Then
                Me.value = DateTime.Now
            End If

            'btnClick.Attributes.Clear()
            'If KeepLeft Then
            '    btnClick.Attributes.Add("onClick", "fPopCalendar(" & TextBox1.ClientID & "," & TextBox1.ClientID & ",'dd/mm/yyyy'," & IIf(KeepLeft, 1, 0) & ");return false;")
            'Else
            '    btnClick.Attributes.Add("onClick", "fPopCalendar(" & TextBox1.ClientID & "," & TextBox1.ClientID & ",'dd/mm/yyyy'," & IIf(KeepLeft, 1, 0) & ");return false;")
            'End If
        End If
    End Sub
    Public ReadOnly Property Text() As String
        Get
            Dim str As String = TextBox1.Text
            'If IsDate(TextBox1.Text) Then
            '    If Format = "dd" Then
            '        str = str.Substring(6, 4) & "/" & str.Substring(3, 2) & "/" & str.Substring(0, 2)
            '    Else
            '        str = str.Substring(6, 4) & "/" & str.Substring(0, 2) & "/" & str.Substring(3, 2)
            '    End If

            'End If

            Return str
        End Get
        'Set(ByVal Value As String)
        '    TextBox1.Text = Value.ToString()
        'End Set
    End Property
    Public ReadOnly Property yyyymmdd() As String
        Get
            Dim str As String = TextBox1.Text
            Return DateTime.Parse(str).ToString("yyyyMMdd")
            'If str.Trim.Length = 0 Then
            '    Return str
            'End If
            'str = str.Substring(6, 4) & str.Substring(3, 2) & str.Substring(0, 2)
            'Return str
        End Get
    End Property

    Public Property value() As Date
        Get
            Dim str As String = TextBox1.Text
            Return DateTime.Parse(str)
            'If Format = "dd" Then
            '    str = str.Substring(6, 4) & "/" & str.Substring(3, 2) & "/" & str.Substring(0, 2)
            'Else
            '    str = str.Substring(6, 4) & "/" & str.Substring(0, 2) & "/" & str.Substring(3, 2)
            'End If
            'Return str
        End Get
        Set(ByVal value As Date)
            TextBox1.Text = value.ToString("dd-MMM-yyyy") 'value.Day.ToString.PadLeft(2, "0") & "/" & value.Month.ToString.PadLeft(2, "0") & "/" & value.Year.ToString

        End Set
    End Property
    Public ReadOnly Property mmddyyyy() As String
        Get
            Dim str As String = TextBox1.Text
            Return DateTime.Parse(str).ToString("MM/dd/yyyy")
            'If str.Trim.Length = 0 Then
            '    Return str
            'End If
            'str = str.Substring(3, 2) & "/" & str.Substring(0, 2) & "/" & str.Substring(6, 4)
            'Return str
        End Get
    End Property
    Private m_KeepLeft As Boolean
    Public Property KeepLeft() As Boolean
        Get
            Return m_KeepLeft
        End Get
        Set(ByVal value As Boolean)
            m_KeepLeft = value
        End Set
    End Property
    Property Format() As String
        Get
            If System.Globalization.CultureInfo.CurrentCulture.DateTimeFormat.ShortDatePattern.StartsWith("d") Then
                Return "dd"
            ElseIf System.Globalization.CultureInfo.CurrentCulture.DateTimeFormat.ShortDatePattern.StartsWith("m") Then
                Return "mm"
            Else
                Return "yy"

            End If
        End Get
        Set(ByVal value As String)

        End Set
    End Property


    Protected Sub TextBox1_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles TextBox1.TextChanged
        RaiseEvent Changed(sender, e)
    End Sub

    Protected Sub TextBox1_PreRender(ByVal sender As Object, ByVal e As System.EventArgs) Handles TextBox1.PreRender
        TextBox1.Attributes("readonly") = "readonly"
    End Sub
End Class
