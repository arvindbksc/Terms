﻿Imports System.Data
Imports com.nss.DBAccess
Partial Class Graphs_ThumbGraph
    Inherits System.Web.UI.Page
#Region "Properties"
    Dim dt As DataTable
    Property CampaignID() As Integer
        Get
            Return ViewState("CampaignID")
        End Get
        Set(ByVal value As Integer)
            ViewState("CampaignID") = value
        End Set
    End Property

    Property KPA() As Integer
        Get
            Return ViewState("KPA")
        End Get
        Set(ByVal value As Integer)
            ViewState("KPA") = value
        End Set
    End Property
    Property Period() As Integer
        Get
            Return ViewState("Period")
        End Get
        Set(ByVal value As Integer)
            ViewState("Period") = value
        End Set
    End Property

    Property GroupBy() As Integer
        Get
            Return ViewState("GroupBy")
        End Get
        Set(ByVal value As Integer)
            ViewState("GroupBy") = value
        End Set
    End Property
    Property GraphSize() As Integer
        Get
            Return ViewState("GraphSize")
        End Get
        Set(ByVal value As Integer)
            ViewState("GraphSize") = value
        End Set
    End Property
    Property AgentID() As String
        Get
            Return ViewState("AgentID")
        End Get
        Set(ByVal value As String)
            ViewState("AgentID") = value
        End Set
    End Property
    Property Graphtype() As Integer
        Get
            Return ViewState("Graphtype")
        End Get
        Set(ByVal value As Integer)
            ViewState("Graphtype") = value
        End Set
    End Property
#End Region
    Dim dtvolume, dtTat, dtAgent, dtTransType, dtAHT, dtQuality, dtING As DataTable
    Dim ds As DataSet
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then

            'CampaignID = Session("CampaignID")
            AgentID = Session("AgentID")
            'Put user code to initialize the page here
            'Period = Request.QueryString("Period")
            'GroupBy = Request.QueryString("GroupBy")
            querystring()
            If Request.QueryString("type") = "Attendance" Then
                returnAttendanceData()
            ElseIf Request.QueryString("type") = "quality" Then
                returnQualityData()
            ElseIf Request.QueryString("type") = "roster" Then
                returnRosterData()
            ElseIf Request.QueryString("type") = "HPS" Then
                returnHPSData()
            ElseIf Request.QueryString("type") = "ING" Then
                returnHPSData()
                'returnINGData()
            End If
        End If
    End Sub
    Private Sub querystring()
        GraphSize = Request.QueryString("GraphSize")
        Chart1.Width = GraphSize
        Chart1.Height = GraphSize
        CampaignID = Request.QueryString("CampaignID")
        KPA = Request.QueryString("KPA")
        Graphtype = Request.QueryString("graphtype")
        Period = Request.QueryString("period")
        GroupBy = Convert.ToInt32(Request.QueryString("groupby"))
    End Sub
    Private Sub returnINGData()
        Dim db As New DBAccess
        db.slDataAdd("Period", Period)
        db.slDataAdd("Campaignid", CampaignID)
        Dim dr As DataRow = db.ReturnRow("usp_GetStart_EndDateForAPeriod", True)
        db = Nothing
        db = New DBAccess("CRM")
        'db.slDataAdd("startday", dr(0))
        'db.slDataAdd("enday", dr(1))
        'db.slDataAdd("CampaignId", CampaignID)
        'db.slDataAdd("groupby", GroupBy)

        'dtvolume = db.ReturnTable("usp_INGDashboard", , True)

        ds = db.ReturnDataset("usp_INGDashboard", True)

        db = Nothing
       

        RenderINGGraph()
    End Sub
    Private Sub returnHPSData()
        Dim db As New DBAccess
        db.slDataAdd("Period", Period)
        db.slDataAdd("Campaignid", CampaignID)
        Dim dr As DataRow = db.ReturnRow("usp_GetStart_EndDateForAPeriod", True)
        db = Nothing
        db = New DBAccess("CRM")
        db.slDataAdd("startday", dr(0))
        db.slDataAdd("enday", dr(1))
        db.slDataAdd("CampaignId", CampaignID)
        db.slDataAdd("groupby", GroupBy)
        'dsAll = db.ReturnDataset("usp_WillsDashboard", True)
        dtvolume = db.ReturnTable("usp_hpsdashboard", , True)
        'dtvolume.Columns.Add("Target2", System.Type.GetType("System.Double"), "430")
        db = Nothing
        db = New DBAccess("CRM")
        db.slDataAdd("StartDate", dr(0))
        db.slDataAdd("EndDate", dr(1))
        db.slDataAdd("CampaignId", CampaignID)
        db.slDataAdd("groupby", GroupBy)
        'dsAll = db.ReturnDataset("usp_WillsDashboard", True)
        dtTat = db.ReturnTable("usp_WillsDashboard", , True)
        db = Nothing
        'Dim db1 As New DBAccess("CRM")
        'db1.slDataAdd("StartDate", dr(0))
        'db1.slDataAdd("EndDate", dr(1))
        'db1.slDataAdd("campaignID", 173)
        'db1.slDataAdd("GroupBy", 3)
        'dtQuality = db1.ReturnTable("usp_CustomDashboard_Quality", , True)
        'dtQuality.Columns.Add("Target", System.Type.GetType("System.Double"), "98")
        'db1 = Nothing
        db = New DBAccess("CRM")
        db.slDataAdd("StartDate", dr(0))
        db.slDataAdd("EndDate", dr(1))
        db.slDataAdd("campaignid", CampaignID)
        db.slDataAdd("groupBy", GroupBy)
        dtQuality = db.ReturnTable("[usp_CustomDashboard_Quality]", , True)
        db = Nothing
        db = New DBAccess("CRM")
        db.slDataAdd("startday", dr(0))
        db.slDataAdd("endDay", dr(1))
        db.slDataAdd("campaignid", CampaignID)
        db.slDataAdd("groupBy", GroupBy)
        '----------------- AHT & Transaction
        dtAHT = db.ReturnTable("usp_dashboard_aht", , True)
        dtAHT.Columns.Remove("AHT")
        dtAHT.Columns.Add("AHT", System.Type.GetType("System.Decimal"), "iif([Transactions]=0,0, ([Transaction Duration]/[Transactions]))")
        dtAHT.Columns.Add("Target1", System.Type.GetType("System.Double"), ".05")
        db = Nothing

        RenderHPSGraph()
    End Sub
    Private Sub returnQualityData()
        dt = Nothing
        Dim db As New DBAccess
        db.slDataAdd("Period", Period)
        db.slDataAdd("Campaignid", CampaignID)
        Dim dr As DataRow = db.ReturnRow("usp_GetStart_EndDateForAPeriod", True)
        db = Nothing
        db = New DBAccess("qualitynew")
        db.slDataAdd("DateFrom", dr(0))
        db.slDataAdd("DateTo", dr(1))
        db.slDataAdd("inQAId", Request.QueryString("QE"))
        db.slDataAdd("campaignid", CampaignID)
        db.slDataAdd("userid", AgentID)
        db.slDataAdd("groupBy", Request.QueryString("groupby"))
        dt = db.ReturnTable("usp_getQCScoreOnTransdate_graph", , True)
        db = Nothing
        If GroupBy = 0 Or GroupBy = 1 Or GroupBy = 2 Or GroupBy = 3 Then 'that is day
            dt.Columns.Add("Day", System.Type.GetType("System.DateTime"), "groupname")
        End If
       
        renderQualityGraph()
    End Sub
    Private Sub returnRosterData()
        dt = Nothing
        Dim db As New DBAccess
        db.slDataAdd("Datefrom", Request.QueryString("periodfrom"))
        db.slDataAdd("Dateto", Request.QueryString("periodto"))
        db.slDataAdd("GroupBy", GroupBy)
        dt = db.ReturnTable("usp_getRosterDashBoard", , True)
        db = Nothing
        If GroupBy = 4 Then 'that is day
            dt.Columns.Add("Day", System.Type.GetType("System.DateTime"), "Column1")
        End If
        renderRosterGraph()
    End Sub
    Private Sub returnAttendanceData()
        ' Dim campaignid As Integer = 191
        dt = Nothing
        Dim db As New DBAccess
        db.slDataAdd("Period", Period)
        db.slDataAdd("Campaignid", CampaignID)
        Dim dr As DataRow = db.ReturnRow("usp_GetStart_EndDateForAPeriod", True)
        db = Nothing
        db = New DBAccess
        db.slDataAdd("startday", dr(0))
        db.slDataAdd("endDay", dr(1))
        db.slDataAdd("UserId", AgentID)
        db.slDataAdd("campaignid", CampaignID)
        db.slDataAdd("groupBy", Request.QueryString("groupby"))

        dt = db.ReturnTable("[usp_getAttendanceCount]", , True)
        

        db = Nothing
        RenderGraph()
        AttendanceGraph()
    End Sub
    
    Private Sub AttendanceGraph()
        Chart1.Series(0).XValueMember = dt.Columns(0).ColumnName
        Chart1.ChartAreas(0).AxisX.LabelStyle.Format = "0"
        Select Case KPA
            Case 1
                Chart1.Titles.Add("Present")
                Chart1.Series(0).YValueMembers = "Present"
            Case 2
                Chart1.Titles.Add("Leave")
                Chart1.Series(0).YValueMembers = "Leave"
            Case 3
                Chart1.Titles.Add("Absent")
                Chart1.Series(0).YValueMembers = "Absent"
        End Select

        Chart1.DataSource = dt.DefaultView
        Chart1.DataBind()
    End Sub
    Private Sub RenderGraph()

        'returnData()
        Chart1.Series.Clear()
        Chart1.Series.Add("series1")
        Chart1.ChartAreas(0).AxisX.IntervalAutoMode = DataVisualization.Charting.IntervalAutoMode.FixedCount
        Chart1.TextAntiAliasingQuality = DataVisualization.Charting.TextAntiAliasingQuality.High
        Select Case KPA
            Case 1
                Chart1.Series(0).ChartType = DataVisualization.Charting.SeriesChartType.Column
                Chart1.Series(0)("DrawingStyle") = "Cylinder"

            Case 2
                Chart1.Series(0).ChartType = DataVisualization.Charting.SeriesChartType.Spline
                Chart1.Series(0).BorderWidth = 3

                Chart1.Series(0).MarkerStyle = DataVisualization.Charting.MarkerStyle.Diamond
                Chart1.Series(0).MarkerSize = 6
                Chart1.Series(0).MarkerColor = Drawing.Color.White

            Case 3
                Chart1.Series(0).BorderWidth = 3
                Chart1.Series(0).ChartType = DataVisualization.Charting.SeriesChartType.Spline
                Chart1.Series(0).MarkerStyle = DataVisualization.Charting.MarkerStyle.Diamond
                Chart1.Series(0).MarkerSize = 5
                Chart1.Series(0).Color = Drawing.Color.Red
                Chart1.Series(0).MarkerColor = Drawing.Color.White
            Case 4
                'myPane.Title.Text = "Login Hrs."
                Chart1.Titles.Add("OverAll Score%")
                Chart1.Series(0).YValueMembers = "OverAll Score%"
                Chart1.Series(0).ChartType = DataVisualization.Charting.SeriesChartType.Pie
                Chart1.Series(0)("PieLabelStyle") = "inside"
                Chart1.ChartAreas(0).Area3DStyle.Enable3D = True
                Chart1.ChartAreas(0).Area3DStyle.Inclination = 0

        End Select
        'Chart1.ChartAreas(0).AxisX.LabelAutoFitStyle = DataVisualization.Charting.LabelAutoFitStyles.LabelsAngleStep30        
        'Select Case Graphtype
        '    Case 1
        '        Chart1.Series(0).ChartType = DataVisualization.Charting.SeriesChartType.Spline
        '        Chart1.Series(0).MarkerStyle = DataVisualization.Charting.MarkerStyle.Diamond
        '        Chart1.Series(0).MarkerSize = 6
        '        Chart1.Series(0).MarkerColor = Drawing.Color.White
        '        Chart1.Series(0).BorderWidth = 3
        '        'Chart1.Series(0).IsValueShownAsLabel = False

        '    Case 3
        '        Chart1.Series(0).ChartType = DataVisualization.Charting.SeriesChartType.Pie
        '        Chart1.Series(0)("PieLabelStyle") = "outside"
        '        Chart1.ChartAreas(0).Area3DStyle.Enable3D = True
        '        Chart1.ChartAreas(0).Area3DStyle.Inclination = 0

        '    Case Else
        '        Chart1.Series(0).ChartType = DataVisualization.Charting.SeriesChartType.Column
        '        Chart1.Series(0)("DrawingStyle") = "Cylinder"

        'End Select
        
    End Sub
    Private Sub renderQualityGraph()
        Chart1.Series.Clear()
        Chart1.Series.Add("series1")
        'Chart1.ChartAreas(0).AxisX.IntervalAutoMode = DataVisualization.Charting.IntervalAutoMode.FixedCount
        Chart1.TextAntiAliasingQuality = DataVisualization.Charting.TextAntiAliasingQuality.High
        Chart1.ChartAreas(0).AxisX.LabelAutoFitStyle = DataVisualization.Charting.LabelAutoFitStyles.LabelsAngleStep30
        'Dim mypane As System.Web.UI.DataVisualization.Charting.Series
        'mypane = Chart1.Series(0)
        If GroupBy = 0 Or GroupBy = 1 Or GroupBy = 2 Or GroupBy = 3 Then
            Chart1.Series(0).XValueMember = "Day"
            Chart1.ChartAreas(0).AxisX.LabelStyle.Format = "ddd"
        Else
            Chart1.Series(0).XValueMember = dt.Columns(0).ColumnName
            Chart1.ChartAreas(0).AxisX.LabelStyle.Format = "0"
        End If
        'Chart1.Series(0).XValueMember = dt.Columns(0).ColumnName
        'Chart1.ChartAreas(0).AxisX.LabelStyle.Format = "0"

        Select Case KPA
            Case 1
                'Chart1.Titles.Add("Calls Evaluated")
                Chart1.Titles.Add("Evaluated")
                Chart1.Series(0).YValueMembers = "Monitored"
                Chart1.Series(0).ChartType = DataVisualization.Charting.SeriesChartType.Column
                Chart1.Series(0)("DrawingStyle") = "Cylinder"
                Chart1.Series(0).IsValueShownAsLabel = True
                Chart1.DataSource = dt.DefaultView
                Chart1.DataBind()
            Case 2
                Chart1.Titles.Add("Far %")
                Chart1.Series(0).YValueMembers = "FAR%"
                Chart1.Series(0).ChartType = DataVisualization.Charting.SeriesChartType.Spline
                Chart1.Series(0).BorderWidth = 3
                Chart1.Series(0).Color = Drawing.Color.Red
                Chart1.Series(0).MarkerStyle = DataVisualization.Charting.MarkerStyle.Diamond
                Chart1.Series(0).MarkerSize = 6
                Chart1.Series(0).MarkerColor = Drawing.Color.White
                Chart1.Series(0).IsValueShownAsLabel = True
                Chart1.DataSource = dt.DefaultView
                Chart1.DataBind()
            Case 3
                Chart1.Titles.Add("NFar %")
                Chart1.Series(0).YValueMembers = "NFAR%"
                Chart1.Series(0).BorderWidth = 3
                Chart1.Series(0).ChartType = DataVisualization.Charting.SeriesChartType.Spline
                Chart1.Series(0).MarkerStyle = DataVisualization.Charting.MarkerStyle.Diamond
                Chart1.Series(0).MarkerSize = 5
                Chart1.Series(0).MarkerColor = Drawing.Color.White
                Chart1.Series(0).IsValueShownAsLabel = True
                Chart1.DataSource = dt.DefaultView
                Chart1.DataBind()
            Case 4
                'myPane.Title.Text = "Login Hrs."
                Chart1.Titles.Add("OverAll Score%")
                Chart1.Series(0).YValueMembers = "OverAll Score%"
                'Chart1.Series(0).ChartType = DataVisualization.Charting.SeriesChartType.Pie
                'Chart1.Series(0)("PieLabelStyle") = "inside"
                'Chart1.ChartAreas(0).Area3DStyle.Enable3D = True
                'Chart1.ChartAreas(0).Area3DStyle.Inclination = 0
                Chart1.Series(0).BorderWidth = 3
                Chart1.Series(0).ChartType = DataVisualization.Charting.SeriesChartType.Spline
                Chart1.Series(0).MarkerStyle = DataVisualization.Charting.MarkerStyle.Diamond
                Chart1.Series(0).MarkerSize = 5
                Chart1.Series(0).MarkerColor = Drawing.Color.White
                Chart1.Series(0).IsValueShownAsLabel = True
                Chart1.DataSource = dt.DefaultView
                Chart1.DataBind()
            
        End Select

        
    End Sub
    Private Sub renderRosterGraph()
        Chart1.Series.Clear()
        Chart1.Series.Add("series1")
        'Chart1.ChartAreas(0).AxisX.IntervalAutoMode = DataVisualization.Charting.IntervalAutoMode.FixedCount
        Chart1.TextAntiAliasingQuality = DataVisualization.Charting.TextAntiAliasingQuality.High
        Chart1.ChartAreas(0).AxisX.LabelAutoFitStyle = DataVisualization.Charting.LabelAutoFitStyles.LabelsAngleStep30
        'Dim mypane As System.Web.UI.DataVisualization.Charting.Series
        'mypane = Chart1.Series(0)
        If GroupBy = 4 Then
            Chart1.Series(0).XValueMember = "Day"
            Chart1.ChartAreas(0).AxisX.LabelStyle.Format = "ddd"
        Else
            Chart1.Series(0).XValueMember = "Column1"
            Chart1.ChartAreas(0).AxisX.LabelStyle.Format = "0"
        End If
        'Chart1.Series(0).XValueMember = dt.Columns(0).ColumnName
        'Chart1.ChartAreas(0).AxisX.LabelStyle.Format = "0"

        Select Case KPA
            Case 1
                Chart1.Titles.Add("Process Wise Roster")
                Chart1.Series(0).YValueMembers = "agents"
                Chart1.Series(0).ChartType = DataVisualization.Charting.SeriesChartType.Column ' = DataVisualization.Charting.SeriesChartType.Pie
                'Chart1.Series(0)("PieLabelStyle") = "inside"
                'Chart1.Series(0)("PieDrawingStyle") = "Concave"
                'Chart1.ChartAreas(0).Area3DStyle.Enable3D = True
                'Chart1.ChartAreas(0).Area3DStyle.Inclination = 0
                'Chart1.Series(0).ChartType = DataVisualization.Charting.SeriesChartType.Column
                Chart1.Series(0)("DrawingStyle") = "Cylinder"
                Chart1.Series(0).IsValueShownAsLabel = True
            Case 2

                Chart1.Titles.Add("Shift Wise Roster")
                Chart1.Series(0).YValueMembers = "agents"
                Chart1.Series(0).ChartType = DataVisualization.Charting.SeriesChartType.Column
                Chart1.Series(0)("DrawingStyle") = "Cylinder"
                Chart1.Series(0).IsValueShownAsLabel = True
            Case 3
                Chart1.Titles.Add("Process Special Cab")
                Chart1.Series(0).YValueMembers = "agents"
                Chart1.Series(0).ChartType = DataVisualization.Charting.SeriesChartType.Column
                Chart1.Series(0)("DrawingStyle") = "Cylinder"
                Chart1.Series(0).IsValueShownAsLabel = True
            Case 4
                Chart1.Titles.Add("Day Wise Special Cab")
                Chart1.Series(0).YValueMembers = "agents"
                Chart1.Series(0).ChartType = DataVisualization.Charting.SeriesChartType.Column
                Chart1.Series(0)("DrawingStyle") = "Cylinder"
                Chart1.Series(0).IsValueShownAsLabel = True
        End Select

        Chart1.DataSource = dt.DefaultView
        Chart1.DataBind()
    End Sub
    Private Sub RenderHPSGraph()
        Chart1.Series.Clear()
        Chart1.Series.Add("Series1")
        'Chart1.ChartAreas(0).AxisX.IntervalAutoMode = DataVisualization.Charting.IntervalAutoMode.FixedCount
        Chart1.TextAntiAliasingQuality = DataVisualization.Charting.TextAntiAliasingQuality.High
        Chart1.ChartAreas(0).AxisX.LabelAutoFitStyle = DataVisualization.Charting.LabelAutoFitStyles.LabelsAngleStep30
        'Dim mypane As System.Web.UI.DataVisualization.Charting.Series
        'mypane = Chart1.Series(0)
        'If GroupBy = 0 Or GroupBy = 1 Or GroupBy = 2 Or GroupBy = 3 Then
        '    Chart1.Series(0).XValueMember = "Day"
        '    Chart1.ChartAreas(0).AxisX.LabelStyle.Format = "ddd"
        'Else
        '    Chart1.Series(0).XValueMember = dt.Columns(0).ColumnName
        '    Chart1.ChartAreas(0).AxisX.LabelStyle.Format = "0"
        'End If
        Select Case KPA
            Case 5
                'Chart1.Series.Add("Target1")
                Chart1.Series.Add("Volume")
                Chart1.Titles.Add("Volume")
                Chart1.Series(0).XValueMember = dtvolume.Columns(0).ColumnName
                Chart1.Series(0).YValueMembers = "Transaction"
                Chart1.Series(0).ChartType = DataVisualization.Charting.SeriesChartType.Spline
                Chart1.Series(0).BorderWidth = 3
                Chart1.Series(0).Color = Drawing.Color.Red
                Chart1.Series(0).MarkerStyle = DataVisualization.Charting.MarkerStyle.Diamond
                Chart1.Series(0).MarkerSize = 6
                Chart1.Series(0).MarkerColor = Drawing.Color.White
                Chart1.Series(0).IsValueShownAsLabel = True
                ' Chart1.ChartAreas(0).AxisY.IsStartedFromZero = True
                'Chart1.ChartAreas(0).AxisY.Minimum = 400
                'Chart1.Series(1).XValueMember = dtvolume.Columns(0).ColumnName
                ''Chart1.Series(1).YValueMembers = "Target2"
                'Chart1.Series(1).YValueMembers = "Target"
                'Chart1.Series(1).ChartType = DataVisualization.Charting.SeriesChartType.Line
                'Chart1.Series(1).BorderDashStyle = DataVisualization.Charting.ChartDashStyle.Dash
                'Chart1.Series(1).BorderWidth = 2
                'Chart1.Series(1).MarkerStyle = DataVisualization.Charting.MarkerStyle.Diamond
                'Chart1.Series(1).MarkerSize = 6
                'Chart1.Series(1).MarkerColor = Drawing.Color.Yellow
                'Chart1.Series(1).Color = Drawing.Color.Green
                'Chart1.Series(1).IsValueShownAsLabel = True

                Chart1.DataSource = dtvolume
                Chart1.DataBind()
            Case 6
                'myPane.Title.Text = "Completes"
                Chart1.Series.Clear()
                Chart1.Series.Add("Target1")
                Chart1.Series.Add("AHT")
                Chart1.Series(0).XValueMember = dtAHT.Columns(0).ColumnName
                Chart1.ChartAreas(0).AxisX.LabelStyle.Format = "0"
                Chart1.Titles.Add("AHT")
                'Chart1.Titles.Add("Completes")
                Chart1.Series(0).YValueMembers = "AHT1"
                Chart1.Series(0).ChartType = DataVisualization.Charting.SeriesChartType.Column
                'Chart1.Series(0).Color = Drawing.Color.Blue
                Chart1.Series(0)("DrawingStyle") = "Cylinder"
                Chart1.Series(0).IsValueShownAsLabel = True
                Chart1.Series(1).XValueMember = dtAHT.Columns(0).ColumnName
                Chart1.Series(1).YValueMembers = "Target1"
                Chart1.Series(1).ChartType = DataVisualization.Charting.SeriesChartType.Line
                Chart1.Series(1).BorderDashStyle = DataVisualization.Charting.ChartDashStyle.Dash
                Chart1.Series(1).BorderWidth = 2
                Chart1.Series(1).MarkerStyle = DataVisualization.Charting.MarkerStyle.Diamond
                Chart1.Series(1).MarkerSize = 6
                Chart1.Series(1).MarkerColor = Drawing.Color.Yellow
                Chart1.Series(1).Color = Drawing.Color.Green
                Chart1.Series(1).IsValueShownAsLabel = True
                Chart1.DataSource = dtAHT.DefaultView
                Chart1.DataBind()

            Case 7
                Chart1.Series.Clear()
                Chart1.Series.Add("Target")
                Chart1.Series.Add("TAT")
                Chart1.Series(0).XValueMember = dtTat.Columns(0).ColumnName
                Chart1.ChartAreas(0).AxisX.LabelStyle.Format = "0"
                Chart1.Titles.Add("Turn Around Time")

                Chart1.Series(0).YValueMembers = "Turn Around Time"
                Chart1.Series(0).BorderWidth = 3
                Chart1.Series(0).ChartType = DataVisualization.Charting.SeriesChartType.Spline
                Chart1.Series(0).MarkerStyle = DataVisualization.Charting.MarkerStyle.Diamond
                Chart1.Series(0).MarkerSize = 5
                Chart1.Series(0).Color = Drawing.Color.Red
                Chart1.Series(0).MarkerColor = Drawing.Color.White
                Chart1.Series(0).IsValueShownAsLabel = True
                Chart1.Series(1).XValueMember = dtTat.Columns(0).ColumnName
                Chart1.Series(1).YValueMembers = "Target1"
                Chart1.Series(1).ChartType = DataVisualization.Charting.SeriesChartType.Spline
                Chart1.Series(1).BorderDashStyle = DataVisualization.Charting.ChartDashStyle.Dash
                Chart1.Series(1).BorderWidth = 2
                Chart1.Series(1).MarkerStyle = DataVisualization.Charting.MarkerStyle.Diamond
                Chart1.Series(1).MarkerSize = 6
                Chart1.Series(1).MarkerColor = Drawing.Color.Yellow
                Chart1.Series(1).Color = Drawing.Color.Green
                Chart1.Series(1).IsValueShownAsLabel = True
                Chart1.ChartAreas(0).AxisY.IsStartedFromZero = False
                Chart1.DataSource = dtTat.DefaultView
                Chart1.DataBind()
            Case 8
                'myPane.Title.Text = "Login Hrs."
                Chart1.Series.Clear()
                Chart1.Series.Add("Target")
                Chart1.Series.Add("FAR")
                Chart1.Series(0).XValueMember = dtQuality.Columns(0).ColumnName
                'Chart1.ChartAreas(0).AxisX.LabelStyle.Format = "0"
                Chart1.Titles.Add("Internal Quality")
                Chart1.Series(0).YValueMembers = "FAR"
                Chart1.Series(0).BorderWidth = 3
                Chart1.Series(0).ChartType = DataVisualization.Charting.SeriesChartType.Line
                Chart1.Series(0).MarkerStyle = DataVisualization.Charting.MarkerStyle.Diamond
                Chart1.Series(0).MarkerSize = 5
                Chart1.Series(0).Color = Drawing.Color.Red
                Chart1.Series(0).MarkerColor = Drawing.Color.White
                Chart1.Series(0).IsValueShownAsLabel = True
                Chart1.Series(1).XValueMember = dtQuality.Columns(0).ColumnName
                Chart1.Series(1).YValueMembers = "Target1"
                Chart1.Series(1).ChartType = DataVisualization.Charting.SeriesChartType.Line
                Chart1.Series(1).BorderDashStyle = DataVisualization.Charting.ChartDashStyle.Dash
                Chart1.Series(1).BorderWidth = 2
                Chart1.Series(1).MarkerStyle = DataVisualization.Charting.MarkerStyle.Diamond
                Chart1.Series(1).MarkerSize = 6
                Chart1.Series(1).MarkerColor = Drawing.Color.Yellow
                Chart1.Series(1).Color = Drawing.Color.Green
                Chart1.Series(1).IsValueShownAsLabel = True
                Chart1.ChartAreas(0).AxisY.IsStartedFromZero = False

                'Chart1.ChartAreas(0).AxisY.Minimum = 60
                'Chart1.ChartAreas(0).AxisY.Interval = 5
                Chart1.DataSource = dtQuality.DefaultView
                Chart1.DataBind()
        End Select
    End Sub
    Private Sub RenderINGGraph()
        Chart1.Series.Clear()
        Chart1.Series.Add("Series1")
        'Chart1.ChartAreas(0).AxisX.IntervalAutoMode = DataVisualization.Charting.IntervalAutoMode.FixedCount
        Chart1.TextAntiAliasingQuality = DataVisualization.Charting.TextAntiAliasingQuality.High
        Chart1.ChartAreas(0).AxisX.LabelAutoFitStyle = DataVisualization.Charting.LabelAutoFitStyles.LabelsAngleStep30
        'Dim mypane As System.Web.UI.DataVisualization.Charting.Series
        'mypane = Chart1.Series(0)
        'If GroupBy = 0 Or GroupBy = 1 Or GroupBy = 2 Or GroupBy = 3 Then
        '    Chart1.Series(0).XValueMember = "Day"
        '    Chart1.ChartAreas(0).AxisX.LabelStyle.Format = "ddd"
        'Else
        '    Chart1.Series(0).XValueMember = dt.Columns(0).ColumnName
        '    Chart1.ChartAreas(0).AxisX.LabelStyle.Format = "0"
        'End If
        Select Case KPA
            Case 5
                'Chart1.Series.Add("Target1")
                Chart1.Series.Add("Company")
                Chart1.Titles.Add("Company")
                Chart1.Series(0).XValueMember = ds.Tables(0).Columns(0).ColumnName 'dtvolume.Columns(0).ColumnName
                Chart1.Series(0).YValueMembers = "Amount"
                Chart1.Series(0).ChartType = DataVisualization.Charting.SeriesChartType.Spline
                Chart1.Series(0).BorderWidth = 3
                Chart1.Series(0).Color = Drawing.Color.Red
                Chart1.Series(0).MarkerStyle = DataVisualization.Charting.MarkerStyle.Diamond
                Chart1.Series(0).MarkerSize = 6
                Chart1.Series(0).MarkerColor = Drawing.Color.White
                Chart1.Series(0).IsValueShownAsLabel = True
                Chart1.ChartAreas(0).AxisY.IsStartedFromZero = False

                'Chart1.Series(1).XValueMember = ds.Tables(1).Columns(0).ColumnName
                ''Chart1.Series(1).YValueMembers = "Target2"
                'Chart1.Series(1).YValueMembers = "Amount"
                'Chart1.Series(1).ChartType = DataVisualization.Charting.SeriesChartType.Line
                'Chart1.Series(1).BorderDashStyle = DataVisualization.Charting.ChartDashStyle.Dash
                'Chart1.Series(1).BorderWidth = 2
                'Chart1.Series(1).MarkerStyle = DataVisualization.Charting.MarkerStyle.Diamond
                'Chart1.Series(1).MarkerSize = 6
                'Chart1.Series(1).MarkerColor = Drawing.Color.Yellow
                'Chart1.Series(1).Color = Drawing.Color.Green
                'Chart1.Series(1).IsValueShownAsLabel = True

                Chart1.DataSource = ds.Tables(0)
                Chart1.DataBind()
            Case 6
                'myPane.Title.Text = "Completes"
                Chart1.Series.Clear()
                ' Chart1.Series.Add("Target1")
                Chart1.Series.Add("State")
                Chart1.Series(0).XValueMember = ds.Tables(1).Columns(0).ColumnName
                Chart1.ChartAreas(0).AxisX.LabelStyle.Format = "0"
                Chart1.Titles.Add("State")
                'Chart1.Titles.Add("Completes")
                Chart1.Series(0).YValueMembers = "Amount"
                Chart1.Series(0).ChartType = DataVisualization.Charting.SeriesChartType.Column
                'Chart1.Series(0).Color = Drawing.Color.Blue
                Chart1.Series(0)("DrawingStyle") = "Cylinder"
                Chart1.Series(0).IsValueShownAsLabel = True
                'Chart1.Series(1).XValueMember = dtAHT.Columns(0).ColumnName
                'Chart1.Series(1).YValueMembers = "Target1"
                'Chart1.Series(1).ChartType = DataVisualization.Charting.SeriesChartType.Line
                'Chart1.Series(1).BorderDashStyle = DataVisualization.Charting.ChartDashStyle.Dash
                'Chart1.Series(1).BorderWidth = 2
                'Chart1.Series(1).MarkerStyle = DataVisualization.Charting.MarkerStyle.Diamond
                'Chart1.Series(1).MarkerSize = 6
                'Chart1.Series(1).MarkerColor = Drawing.Color.Yellow
                'Chart1.Series(1).Color = Drawing.Color.Green
                'Chart1.Series(1).IsValueShownAsLabel = True
                Chart1.DataSource = ds.Tables(1)
                Chart1.DataBind()

            Case 7
                Chart1.Series.Clear()
                'Chart1.Series.Add("Target")
                Chart1.Series.Add("Reason")
                Chart1.Series(0).XValueMember = ds.Tables(2).Columns(0).ColumnName
                Chart1.ChartAreas(0).AxisX.LabelStyle.Format = "0"
                Chart1.Titles.Add("Reason")

                Chart1.Series(0).YValueMembers = "Amount"
                Chart1.Series(0).BorderWidth = 3
                Chart1.Series(0).ChartType = DataVisualization.Charting.SeriesChartType.Spline
                Chart1.Series(0).MarkerStyle = DataVisualization.Charting.MarkerStyle.Diamond
                Chart1.Series(0).MarkerSize = 5
                Chart1.Series(0).Color = Drawing.Color.Red
                Chart1.Series(0).MarkerColor = Drawing.Color.White
                Chart1.Series(0).IsValueShownAsLabel = True
                'Chart1.Series(1).XValueMember = dtTat.Columns(0).ColumnName
                'Chart1.Series(1).YValueMembers = "Target1"
                'Chart1.Series(1).ChartType = DataVisualization.Charting.SeriesChartType.Spline
                'Chart1.Series(1).BorderDashStyle = DataVisualization.Charting.ChartDashStyle.Dash
                'Chart1.Series(1).BorderWidth = 2
                'Chart1.Series(1).MarkerStyle = DataVisualization.Charting.MarkerStyle.Diamond
                'Chart1.Series(1).MarkerSize = 6
                'Chart1.Series(1).MarkerColor = Drawing.Color.Yellow
                'Chart1.Series(1).Color = Drawing.Color.Green
                'Chart1.Series(1).IsValueShownAsLabel = True
                Chart1.ChartAreas(0).AxisY.IsStartedFromZero = False
                Chart1.DataSource = ds.Tables(2)
                Chart1.DataBind()
            Case 8
                'myPane.Title.Text = "Login Hrs."
                Chart1.Series.Clear()
                'Chart1.Series.Add("Target")
                Chart1.Series.Add("Age")
                Chart1.Series(0).XValueMember = ds.Tables(3).Columns(0).ColumnName
                'Chart1.ChartAreas(0).AxisX.LabelStyle.Format = "0"
                Chart1.Titles.Add("Age")
                Chart1.Series(0).YValueMembers = "Amount"
                Chart1.Series(0).BorderWidth = 3
                Chart1.Series(0).ChartType = DataVisualization.Charting.SeriesChartType.Line
                Chart1.Series(0).MarkerStyle = DataVisualization.Charting.MarkerStyle.Diamond
                Chart1.Series(0).MarkerSize = 5
                Chart1.Series(0).Color = Drawing.Color.Red
                Chart1.Series(0).MarkerColor = Drawing.Color.White
                Chart1.Series(0).IsValueShownAsLabel = True
                'Chart1.Series(1).XValueMember = dtQuality.Columns(0).ColumnName
                'Chart1.Series(1).YValueMembers = "Target1"
                'Chart1.Series(1).ChartType = DataVisualization.Charting.SeriesChartType.Line
                'Chart1.Series(1).BorderDashStyle = DataVisualization.Charting.ChartDashStyle.Dash
                'Chart1.Series(1).BorderWidth = 2
                'Chart1.Series(1).MarkerStyle = DataVisualization.Charting.MarkerStyle.Diamond
                'Chart1.Series(1).MarkerSize = 6
                'Chart1.Series(1).MarkerColor = Drawing.Color.Yellow
                'Chart1.Series(1).Color = Drawing.Color.Green
                'Chart1.Series(1).IsValueShownAsLabel = True
                Chart1.ChartAreas(0).AxisY.IsStartedFromZero = False

                'Chart1.ChartAreas(0).AxisY.Minimum = 60
                'Chart1.ChartAreas(0).AxisY.Interval = 5
                Chart1.DataSource = ds.Tables(3)
                Chart1.DataBind()
        End Select
    End Sub
End Class
