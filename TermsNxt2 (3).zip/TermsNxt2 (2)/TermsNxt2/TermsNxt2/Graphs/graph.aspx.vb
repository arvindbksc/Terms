
Imports ZedGraph
Imports ZedGraph.Web
Imports System.Drawing

Imports System.Data
Imports com.nss.DBAccess
Public Class graph
    Inherits System.Web.UI.Page

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region
    Dim dt As DataTable
    Property CampaignID() As Integer
        Get
            Return ViewState("CampaignID")
        End Get
        Set(ByVal value As Integer)
            ViewState("CampaignID") = value
        End Set
    End Property

    Property KPA() As Integer
        Get
            Return ViewState("KPA")
        End Get
        Set(ByVal value As Integer)
            ViewState("KPA") = value
        End Set
    End Property
    Property Period() As Integer
        Get
            Return ViewState("Period")
        End Get
        Set(ByVal value As Integer)
            ViewState("Period") = value
        End Set
    End Property

    Property GroupBy() As Integer
        Get
            Return ViewState("GroupBy")
        End Get
        Set(ByVal value As Integer)
            ViewState("GroupBy") = value
        End Set
    End Property
    Property GraphSize() As Integer
        Get
            Return ViewState("GraphSize")
        End Get
        Set(ByVal value As Integer)
            ViewState("GraphSize") = value
        End Set
    End Property
    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
        GraphSize = Request.QueryString("GraphSize")
        ZedGraphWeb1.Width = GraphSize
        ZedGraphWeb1.Height = GraphSize
    End Sub
    Private Sub returnData()
        ' Dim campaignid As Integer = 191
        Dim db As New DBAccess
        db.slDataAdd("Period", Period)
        db.slDataAdd("Campaignid", campaignid)

        Dim dr As DataRow = db.ReturnRow("usp_GetStart_EndDateForAPeriod", True)
        db = Nothing
        db = New DBAccess


        db.slDataAdd("startday", dr(0))
        db.slDataAdd("endDay", dr(1))
        db.slDataAdd("campaignid", CampaignID)
        db.slDataAdd("groupBy", GroupBy)
        'If cboFilterBy.SelectedItem.Text <> "None" And txtFilterValue.Text.Trim <> "" Then
        '    lblFilter.Text = "Filtered for " & cboFilterBy.SelectedItem.Text & " = " & txtFilterValue.Text
        '    If cboFilterBy.SelectedValue.Contains("String") Then
        '        'db.slDataAdd("Filterby", "'" & cboFilterBy.SelectedItem.Text & "'")
        '    End If
        '    db.slDataAdd("Filterby", cboFilterBy.SelectedItem.Text)
        '    db.slDataAdd("Filterbyvalue", txtFilterValue.Text)
        'End If
        dt = db.ReturnTable("usp_CampaignPerformanceTerms2", , True)
        dt.Columns.Remove("CPH")
        dt.Columns.Add("CPH", System.Type.GetType("System.Decimal"), "iif([Login Duration]=0,0, ([Completes]/[Login Duration])*3600)")
        dt.Columns.Remove("AHT")
        dt.Columns.Add("AHT", System.Type.GetType("System.Double"), "iif([Transactions]=0,0, [Transaction Duration]/[Transactions])")
        'dt.Columns.Remove("LoginHrs")
        dt.Columns.Add("LoginHrs", System.Type.GetType("System.Double"), "[Login Duration]/3600")

    End Sub

    Private Sub OnRenderGraph(ByVal zgw As ZedGraphWeb, ByVal g As System.Drawing.Graphics, _
      ByVal masterPane As ZedGraph.MasterPane) Handles ZedGraphWeb1.RenderGraph

        CampaignID = Request.QueryString("CampaignID")
        KPA = Request.QueryString("KPA")
        Period = Request.QueryString("Period")
        GroupBy = Request.QueryString("GroupBy")



        returnData()

        ' Get a reference to the GraphPane instance in the ZedGraphControl
        masterPane.PaneList.Clear()

        Dim myPane As GraphPane = New GraphPane(New Rectangle(0, 0, GraphSize, GraphSize), "", "", "") 'masterPane(0)
        myPane.Title.FontSpec.Size = 32
        myPane.Title.FontSpec.IsBold = True

        myPane.YAxis.Title.FontSpec.Size = 30
        myPane.XAxis.Title.FontSpec.Size = 30
        myPane.YAxis.Scale.FontSpec.Size = 28


        myPane.Legend.IsVisible = False
        myPane.YAxis.Scale.Min = 0

        Dim GraphType As GraphTypes = GraphTypes.Line

        Dim dsl As New ZedGraph.DataSourcePointList
        dsl.DataSource = dt
        Dim str As New List(Of String)
        Dim i As Integer = 0
        For Each dr In dt.Rows
            str.Add(dt.Rows(i)(0))
            i = i + 1
        Next
        ' Set the titles and axis labels
        Select Case GroupBy
            Case 0
                myPane.XAxis.Title.Text = "Campaigns"
                myPane.XAxis.Scale.TextLabels = str.ToArray
                myPane.XAxis.Type = AxisType.Text
            Case 1
                myPane.XAxis.Title.Text = "Agents"
                myPane.XAxis.Scale.TextLabels = str.ToArray
                myPane.XAxis.Type = AxisType.Text
            Case 2
                myPane.XAxis.Title.Text = "Teams"
                myPane.XAxis.Scale.TextLabels = str.ToArray
                myPane.XAxis.Type = AxisType.Text
            Case 3
                myPane.XAxis.Title.Text = "Days"
                myPane.XAxis.Scale.TextLabels = str.ToArray
                myPane.XAxis.Type = AxisType.Text
            Case Else
                myPane.XAxis.Title.Text = "Hours"
                myPane.XAxis.Scale.FontSpec.Size = 28
        End Select
        
        Select Case KPA
            Case 1
                myPane.Title.Text = "CPH"
                dsl.XDataMember = dt.Columns(0).ColumnName
                dsl.YDataMember = "CPH"
                GraphType = GraphTypes.Line
            Case 2
                myPane.Title.Text = "Completes"
                dsl.XDataMember = dt.Columns(0).ColumnName
                dsl.YDataMember = "Completes"
                GraphType = GraphTypes.Bar

            Case 3
                myPane.Title.Text = "AHT"
                dsl.XDataMember = dt.Columns(0).ColumnName
                dsl.YDataMember = "AHT"
                GraphType = GraphTypes.Line
            Case 4
                myPane.Title.Text = "Login Hrs."
                dsl.XDataMember = dt.Columns(0).ColumnName
                dsl.YDataMember = "Loginhrs"
                GraphType = GraphTypes.Line

        End Select
       

        Select Case GraphType
            Case GraphTypes.Line
                Dim myCurve As LineItem
                myCurve = myPane.AddCurve("Alpha", dsl, Color.Red, SymbolType.Diamond)
                myCurve.Line.Width = 2
                ' Fill the symbols with white
                myCurve.Symbol.Fill = New Fill(Color.White)
                myCurve.Symbol.Size = 16
                myCurve.IsY2Axis = False
            Case GraphTypes.Bar
                Dim myCurve As BarItem
                myCurve = myPane.AddBar("com", dsl, Color.CadetBlue)
                myCurve.IsY2Axis = False
        End Select
        myPane.XAxis.MajorGrid.IsVisible = False
        'myPane.XAxis.CrossAuto = True
        'myPane.YAxis.Scale.Align = AlignP.Inside
        ' Manually set the axis range

        myPane.YAxis.Scale.MajorUnit = 0.5
        myPane.YAxis.Scale.MinorUnit = 0.1
        myPane.XAxis.Scale.MinorStep = 1
        myPane.XAxis.Scale.MajorStep = 1
        myPane.XAxis.Scale.BaseTic = 1

        ' Fill the axis background with a gradient
        myPane.Y2Axis.IsVisible = False
        myPane.Chart.Fill = New Fill(Color.White, Color.SteelBlue, 45.0F)
        masterPane.PaneList.Add(myPane)
        masterPane.AxisChange(g)
        BarItem.CreateBarLabels(myPane, False, "f0", "verdana", 24, Color.Black, False, False, False)
    End Sub

End Class
Public Enum GraphTypes
    Line
    Bar
    Pie
End Enum
