﻿Imports System.Web.UI.DataVisualization.Charting
Imports System.Data
Imports com.nss.DBAccess
Partial Class Graphs_HPSGraph
    Inherits System.Web.UI.Page
    Dim dt As DataTable
#Region "--- Properties ---"
    Property CampaignID() As Integer
        'Get
        '    Return cboCampaigns.SelectedValue
        'End Get
        'Set(ByVal value As Integer)
        '    cboCampaigns.SelectedItem.Selected = False
        '    cboCampaigns.Items.FindByValue(value).Selected = True
        'End Set
        Get
            Return ViewState("CampaignID")
        End Get
        Set(ByVal value As Integer)
            ViewState("CampaignID") = value
        End Set
    End Property
    Property KPA() As Integer
        Get
            Return ViewState("KPA")
        End Get
        Set(ByVal value As Integer)
            ViewState("KPA") = value
        End Set
    End Property
    Property Period() As Integer
        Get
            Return CboPeriod.SelectedValue
        End Get
        Set(ByVal value As Integer)
            CboPeriod.Items.FindByValue(value).Selected = True
        End Set
    End Property
    Property GroupBy() As Integer
        Get
            Return CboGroup.SelectedValue
        End Get
        Set(ByVal value As Integer)
            '  CboGroup.Items.FindByValue(value).Selected = True
        End Set
    End Property
    Property AgentID() As String
        Get
            Return ViewState("AgentID")
        End Get
        Set(ByVal value As String)
            ViewState("AgentID") = value
        End Set
    End Property
    Property Campaigntype() As Integer
        Get
            Return ViewState("Campaigntype")
        End Get
        Set(ByVal value As Integer)
            ViewState("Campaigntype") = value
            'Session("ProcessID") = value
        End Set
    End Property
#End Region
#Region "--- Initialize Controls ---"
    Private Sub LoadData()
        fillperiod()
        FillCommonFilters()
        ' FillProcessCampaigns()
    End Sub
    Private Sub fillperiod()
        Dim db As New DBAccess
        Dim dt As DataTable = db.ReturnTable("select * from tbl_Reports_DatePeriods")
        db = Nothing
        Dim dr As DataRow = dt.NewRow
        dr(0) = 10
        dr(1) = "Between"
        dt.Rows.Add(dr)
        CboPeriod.DataTextField = "Caption"
        CboPeriod.DataValueField = "Period"
        CboPeriod.DataSource = dt
        CboPeriod.DataBind()

    End Sub
    Private Sub FillCommonFilters()
        Dim db As New DBAccess
        'Dim dr1 As DataRow = dt.NewRow
        'dr1(1) = 5
        'dr1(0) = "Questions"
        'dt.Rows.Add(dr1)
        db = New DBAccess
        dt = db.ReturnTable("Select * from tbl_Reports_GroupBy")
        db = Nothing
        Dim dtrow() As DataRow = dt.Select("Caption IN('Campaign','Agent','Day','Team','Hour')")
        dt.Rows.Remove(dtrow(0))
        dt.Rows.Remove(dtrow(1))
        dt.Rows.Remove(dtrow(2))
        dt.Rows.Remove(dtrow(3))
        dt.Rows.Remove(dtrow(4))
        'Dim dtrow1 As DataRow = dt.NewRow
        'dtrow1(0) = "Employer"
        'dtrow1(1) = 5
        'dt.Rows.Add(dtrow1)
        'Dim dr2 As DataRow = dt.NewRow
        'dr2(1) = 6
        'dr2(0) = "Transaction Type"
        'dt.Rows.Add(dr2)
        'Dim dr4 As DataRow = dt.NewRow
        'dr4(1) = 7
        'dr4(0) = "Health Plan"
        'dt.Rows.Add(dr4)

        Dim dtrow1 As DataRow = dt.NewRow
        dtrow1(0) = "Resolved"
        dtrow1(1) = 8
        dt.Rows.Add(dtrow1)
        Dim dr2 As DataRow = dt.NewRow
        dr2(1) = 9
        dr2(0) = "In Progress"
        dt.Rows.Add(dr2)
        'Dim dr3 As DataRow = dt.NewRow
        'dr3(1) = 10
        'dr3(0) = "Supplier"
        'dt.Rows.Add(dr3)
        'Dim dr4 As DataRow = dt.NewRow
        'dr4(1) = 11
        'dr4(0) = "Age"
        'dt.Rows.Add(dr4)
        CboGroup.DataTextField = "Caption"
        CboGroup.DataValueField = "ID"
        CboGroup.DataSource = dt
        CboGroup.DataBind()


    End Sub
    Private Sub FillProcessCampaigns()
        'Common.FillProcessCampaigns(CboProcess, cboCampaigns, AgentID, CampaignID)
        Dim dt As DataTable
        Dim db As New DBAccess("CRM")
        dt = db.ReturnTable("select * from tbl_Config_Campaigns where processid=103 and active=1 order by name", False)
        db = Nothing
        cboCampaigns.DataTextField = "Name"
        cboCampaigns.DataValueField = "CampaignID"
        cboCampaigns.DataSource = dt
        cboCampaigns.DataBind()
    End Sub
#End Region
#Region "--- Load ---"
    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
        If Not IsPostBack Then
            If Session("AgentID") <> "" Then
                CampaignID = Session("CampaignID")
                AgentID = Session("AgentID")
                LoadData()
                KPA = Request.QueryString("KPA")
                Period = Request.QueryString("Period")
                GroupBy = Request.QueryString("GroupBy")
                If Request.QueryString("Type") = "ING" Then
                    CboPeriod.SelectedValue = 3
                Else
                    CboPeriod.SelectedValue = 4
                End If
                DrawChart()
                UcDateTo.Visible = False
                ucDateFrom.Visible = False
                lblAnd.Visible = False
            End If
        End If
    End Sub
#End Region
#Region "--- Events ---"
    Protected Sub cboGraphType_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboGraphType.SelectedIndexChanged
        DrawChart()
    End Sub
    Protected Sub btnRefresh_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnRefresh.Click
        DrawChart()
    End Sub
    Protected Sub cboDisposition_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboDisposition.SelectedIndexChanged

        DrawChart()
    End Sub
    Protected Sub ucDateFrom_Changed(ByVal sender As Object, ByVal e As System.EventArgs) Handles ucDateFrom.Changed
        DrawChart()
    End Sub
    Protected Sub UcDateTo_Changed(ByVal sender As Object, ByVal e As System.EventArgs) Handles UcDateTo.Changed
        DrawChart()
    End Sub
    Protected Sub Chart1_Click(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.ImageMapEventArgs) Handles Chart1.Click
        DrawChart()
        Select Case cboGraphType.SelectedValue
            Case 1
            Case 3
                Dim i As Integer = e.PostBackValue
                If i >= 0 And i < Chart1.Series(0).Points.Count Then
                    Chart1.Series(0).Points(i).CustomProperties += "Exploded=true"
                End If


            Case Else
        End Select
    End Sub
    Protected Sub cboCampaigns_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboCampaigns.SelectedIndexChanged
        DrawChart()
    End Sub
    Protected Sub cboworktype_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboworktype.SelectedIndexChanged
        'If cboworktype.SelectedValue = 3 Then
        '    CboGroup.Visible = False
        '    cboKPA.Visible = False
        '    lblgroup.visible = False
        '    lblkpa.Visible = False
        'Else
        '    CboGroup.Visible = True
        '    cboKPA.Visible = True
        '    lblgroup.visible = True
        '    lblkpa.Visible = True
        'End If

        DrawChart()
    End Sub
    Protected Sub CboGroup_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles CboGroup.SelectedIndexChanged
        If CboGroup.SelectedValue = 5 Then
            'lblkpa.Visible = False
            lblDisposition.Visible = False
            cboDisposition.Visible = False
            'lblDisposition.Text = "Questions"
            '' fillQuestions()
            cboKPA.Visible = True
        ElseIf CboGroup.SelectedValue = 6 Then
            cboKPA.Visible = False
            'lblkpa.Visible = False
            lblDisposition.Visible = False
            cboDisposition.Visible = True
            fillTransactionType()
            'ElseIf CboGroup.SelectedValue = 9 Then
            '    lblkpa.Visible = False
            '    lblDisposition.Visible = True
            '    cboDisposition.Visible = True
            '    lblDisposition.Text = "Dispositions"
            '    fillTransactionType()
            '    cboKPA.Visible = False
        ElseIf CboGroup.SelectedValue = 7 Then
            cboKPA.SelectedValue = 12
            'lblkpa.Visible = False
            lblDisposition.Visible = False
            cboDisposition.Visible = False
            'lblDisposition.Text = "Questions"
            '' fillQuestions()
            cboKPA.Visible = True
        ElseIf CboGroup.SelectedValue = 7 Then
            'lblkpa.Visible = False
            lblDisposition.Visible = False
            cboDisposition.Visible = False
        Else
            'cboKPA.SelectedValue <> 12
            cboKPA.Visible = True
            'lblkpa.Visible = True
            'If cboKPA.SelectedValue = 9 Then
            '    filldisposition()
            '    lblDisposition.Visible = True
            '    cboDisposition.Visible = True
            '    lblDisposition.Text = "Dispositions"
            'Else
            lblDisposition.Visible = False
            cboDisposition.Visible = False
            'End If

        End If
        DrawChart()
    End Sub
    Protected Sub CboPeriod_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles CboPeriod.SelectedIndexChanged
        If CboGroup.SelectedValue = 9 Then
            'lblkpa.Visible = False
            lblDisposition.Visible = True
            cboDisposition.Visible = True
            lblDisposition.Text = "Dispositions"
            ' filldisposition()
            cboKPA.Visible = False
        ElseIf CboGroup.SelectedValue = 5 Then
            'lblDisposition.Visible = True
            'cboDisposition.Visible = True
            'lblDisposition.Text = "Questions"
            ''fillQuestions()
            'cboKPA.Visible = False
        ElseIf CboGroup.SelectedValue = 6 Then
            cboKPA.Visible = False
            'lblkpa.Visible = False
            lblDisposition.Visible = False
            cboDisposition.Visible = True
            'fillTransactionType()
        End If
        If CboPeriod.SelectedValue = 10 Then
            ucDateFrom.Visible = True
            UcDateTo.Visible = True
            lblAnd.Visible = True
            DrawChart()
        Else
            ucDateFrom.Visible = False
            UcDateTo.Visible = False
            lblAnd.Visible = False
            DrawChart()
        End If

    End Sub
    Protected Sub cboKPA_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboKPA.SelectedIndexChanged
        'FillCommonFilters()
        If cboKPA.SelectedValue = 9 Then
            'filldisposition()
            'lblDisposition.Visible = True
            cboDisposition.Visible = True
            lblDisposition.Text = "Dispositions"
        ElseIf cboKPA.SelectedValue = 5 Then
            lblDisposition.Visible = True
            cboDisposition.Visible = True
            lblDisposition.Text = "Questions"
            ' fillQuestions()
            'ElseIf cboKPA.SelectedValue = 10 Then
            '    CboGroup.Items.Insert(
        ElseIf cboKPA.SelectedValue = 12 Then
            CboGroup.SelectedValue = 7
        ElseIf cboKPA.SelectedValue = 13 Then
            CboGroup.SelectedValue = 7
        Else
            lblDisposition.Visible = False
            cboDisposition.Visible = False
        End If

        DrawChart()
    End Sub

#End Region
#Region "--- Functions ---"
    Private Sub fillTransactionType()
        Dim db As New DBAccess("CRM")
        Dim dt As New DataTable
        'db.slDataAdd("CampaignID", cboCampaigns.SelectedValue)
        dt = db.ReturnTable("usp_getHPSTransactionType", , True)
        db = Nothing
        If dt.Rows.Count > 0 Then
            Dim dr As DataRow = dt.NewRow
            dr(0) = "All"
            'dr(1) = "All"
            dt.Rows.Add(dr)
            cboDisposition.DataValueField = "Transaction Type"
            cboDisposition.DataTextField = "Transaction Type"
            cboDisposition.DataSource = dt
            cboDisposition.DataBind()
            'cboDisposition.SelectedItem.Text = "All"
        End If
        dt = Nothing
    End Sub
    Private Sub DrawChart()
        returnData()
        RenderGraph()
    End Sub
    Private Sub returnData()
        ' Dim campaignid As Integer = 191
        Dim db As New DBAccess
        Dim startday As Integer, endday As Integer
        If CboPeriod.SelectedValue = 10 Then
            startday = ucDateFrom.yyyymmdd
            endday = UcDateTo.yyyymmdd
        Else
            db = New DBAccess
            db.slDataAdd("Period", CboPeriod.SelectedValue)
            db.slDataAdd("Campaignid", cboCampaigns.SelectedValue)
            Dim dr As DataRow = db.ReturnRow("usp_GetStart_EndDateForAPeriod", True)
            db = Nothing
            startday = dr(0)
            endday = dr(1)
        End If
        db = Nothing
        ' db = New DBAccess
        'Dim drKPa As DataRow = db.ReturnRow("select * from tbl_Config_KPA_Master where KPAID=" & KPA)

        'db = Nothing
        'Dim sqlselect As String, sqlwhere As String, sqlgroup As String
        'sqlselect = "Select  A.AgentID,n.[Group Id], n.[Agent Name], n.[Group Name],convert(varchar,[Day]) as [Day],convert(varchar,[Hour]) as [Hour]" & _
        '        ",A.LoginDuration , A.TransactionDuration , A.BreakDuration , A.Transactions , A.Sales , a.campaignid " & _
        '        " FROM tbl_Summary_Performance A  inner join @names n on n.agentid=A.agentid " & _
        '        " where A.[Day]>= @startday and A.[Day]<= @endday and  A.campaignid  =@campaignID"
        'db = New DBAccess
        'db.slDataAdd("Campaignid", CampaignID)
        'db.slDataAdd("userid", AgentID)
        'Dim dtcampaigntype As DataTable = db.ReturnTable("usp_getcampaigntype", , True)
        'db = Nothing
        'If dtcampaigntype.Rows.Count > 1 Then
        '    Campaigntype = 1
        'ElseIf dtcampaigntype.Rows.Count = 0 Then
        '    Campaigntype = 1
        'Else
        '    Campaigntype = dtcampaigntype.Rows(0).Item(0)
        'End If
        'db = Nothing

        'db = New DBAccess
        'db.slDataAdd("startday", startday)
        'db.slDataAdd("endDay", endday)
        'db.slDataAdd("campaignid", 173)
        'db.slDataAdd("groupBy", GroupBy)
        If CboGroup.SelectedValue = 5 Then
            KPA = cboKPA.SelectedValue
        ElseIf CboGroup.SelectedValue = 6 Then
            KPA = 6
            'ElseIf CboGroup.SelectedValue = 9 Then
            '    KPA = 9
        Else
            KPA = cboKPA.SelectedValue
        End If

        'If cboworktype.SelectedValue = 3 Then
        '    KPA = 17
        'End If

        If KPA < 5 Then

            'dt = db.ReturnTable("usp_CampaignPerformanceTerms2", , True)
            'dt.Columns.Remove("CPH")
            'If Campaigntype = 11 Then
            '    dt.Columns.Add("CPH", System.Type.GetType("System.Decimal"), "iif([Login Duration]=0,0, ([Sales]/[Login Duration])*3600)")
            'Else
            '    dt.Columns.Add("CPH", System.Type.GetType("System.Decimal"), "iif([Login Duration]=0,0, ([Completes]/[Login Duration])*3600)")
            'End If
            db = New DBAccess("CRM")
            db.slDataAdd("startday", startday)
            db.slDataAdd("endDay", endday)
            db.slDataAdd("campaignid", 289)
            db.slDataAdd("groupBy", GroupBy)
            '----------------- AHT & Transaction
            dt = db.ReturnTable("usp_dashboard_aht", , True)
            dt.Columns.Remove("AHT")
            dt.Columns.Add("AHT", System.Type.GetType("System.Double"), "iif([Transactions]=0,0, [Transaction Duration]/[Transactions])")
            'dtAHT.Columns.Add("LoginHrs", System.Type.GetType("System.Double"), "[Login Duration]/3600")
            db = Nothing
            'dt.Columns.Remove("AHT")
            'dt.Columns.Add("AHT", System.Type.GetType("System.Double"), "iif([Transactions]=0,0, [Transaction Duration]/[Transactions])")
            'dt.Columns.Remove("LoginHrs")
            'dt.Columns.Add("LoginHrs", System.Type.GetType("System.Double"), "[Login Duration]/3600")
            'ElseIf KPA = 9 Then
            '    db.slDataAdd("Disposition", cboDisposition.SelectedValue)
            '    db.slDataAdd("graphtype", cboGraphType.SelectedValue)
            '    dt = db.ReturnTable("[usp_getSubOutcome]", , True)
            '    dt.Columns.Remove("column1")
            'ElseIf KPA = 5 Then
            '    Dim dbanswer As New DBAccess
            '    dbanswer.slDataAdd("startday", startday)
            '    dbanswer.slDataAdd("endDay", endday)
            '    dbanswer.slDataAdd("Question", cboDisposition.SelectedValue)
            '    dbanswer.slDataAdd("graphtype", cboGraphType.SelectedValue)
            '    dt = dbanswer.ReturnTable("[usp_getAnswersCount]", , True)
        ElseIf KPA = 6 Then
            'getoutcome(startday, endday)
            db = New DBAccess("CRM")
            db.slDataAdd("startday", startday)
            db.slDataAdd("endDay", endday)
            db.slDataAdd("TransactionType", cboDisposition.SelectedValue)
            dt = db.ReturnTable("usp_getHPSTransactionTypeVolume", , True)
            If cboGraphType.SelectedValue = 3 Then
                dt.DefaultView.Sort = "volume ASC"
            End If
        ElseIf KPA = 10 Or KPA = 11 Or KPA = 14 Then
            'getoutcome(startday, endday)
            db = New DBAccess("CRM")
            db.slDataAdd("StartDate", startday)
            db.slDataAdd("EndDate", endday)
            db.slDataAdd("groupBy", CboGroup.SelectedValue)
            dt = db.ReturnTable("usp_WillsBIData", , True)
            'If cboGraphType.SelectedValue = 3 Then
            '    dt.DefaultView.Sort = "volume ASC"
            'End If

            'Else
            '    dt = db.ReturnTable("usp_Survey_Analysis", , True)
            '    dt.Columns.Remove("RPH")
            '    dt.Columns.Add("RPH", System.Type.GetType("System.Decimal"), "iif([Login Duration]=0,0, ([Revenue]/[Login Duration])*3600)")
            '    dt.Columns.Remove("Fill Rate")
            '    dt.Columns.Add("Fill Rate", System.Type.GetType("System.Decimal"), "iif([Total Responses]=0,0, ([Positive Count]/[Total Responses]))")
            '    dt.Columns.Remove("CPH")
            '    dt.Columns.Add("CPH", System.Type.GetType("System.Decimal"), "iif([Login Duration]=0,0, ([Completes]/[Login Duration])*3600)")
        ElseIf KPA = 12 Then
            'getoutcome(startday, endday)
            db = New DBAccess("CRM")
            'db.slDataAdd("StartDate", startday)
            'db.slDataAdd("EndDate", endday)
            'db.slDataAdd("groupBy", CboGroup.SelectedValue)
            dt = db.ReturnTable("usp_HPS_enrollment_errors", , True)
        ElseIf KPA = 13 Then
            'getoutcome(startday, endday)
            db = New DBAccess("CRM")
            'db.slDataAdd("StartDate", startday)
            'db.slDataAdd("EndDate", endday)
            'db.slDataAdd("groupBy", CboGroup.SelectedValue)
            dt = db.ReturnTable("usp_HPS_provider_errors", , True)
        ElseIf KPA = 15 Or KPA = 16 Or KPA = 17 Then
            'getoutcome(startday, endday)
            db = New DBAccess("CRM")
            db.slDataAdd("StartDate", startday)
            db.slDataAdd("EndDate", endday)
            db.slDataAdd("groupBy", CboGroup.SelectedValue)
            db.slDataAdd("KPA", KPA)
            db.slDataAdd("worktype", cboworktype.SelectedValue)
            dt = db.ReturnTable("usp_INGDashboard", , True)
            db = Nothing
            'ElseIf KPA = 17 Then
            '    db = New DBAccess("CRM")
            '    db.slDataAdd("StartDate", startday)
            '    db.slDataAdd("EndDate", endday)
            '    db.slDataAdd("KPA", KPA)
            '    db.slDataAdd("worktype", cboworktype.SelectedValue)
            '    dt = db.ReturnTable("usp_INGDashboard", , True)
            '    db = Nothing
        ElseIf KPA = 18 Or KPA = 19 Then
            db = New DBAccess("CRM")
            db.slDataAdd("StartDate", startday)
            db.slDataAdd("EndDate", endday)
            db.slDataAdd("groupBy", CboGroup.SelectedValue)
            db.slDataAdd("KPA", KPA)
            'db.slDataAdd("worktype", cboworktype.SelectedValue)
            dt = db.ReturnTable("usp_LctgDashboard", , True)
            db = Nothing
        End If


    End Sub
    Private Sub RenderGraph()
        Chart1.Series.Clear()
        Chart1.Series.Add("series1")
        If CboGroup.SelectedValue = 5 Then
            ' KPA = 5
        ElseIf CboGroup.SelectedValue = 6 Then
            KPA = 6
            'ElseIf CboGroup.SelectedValue = 9 Then
            '    KPA = 9
        Else
            KPA = cboKPA.SelectedValue
        End If
        'If cboworktype.SelectedValue = 3 Then
        '    KPA = 17
        'End If
        'If KPA > 7 Then
        'Chart1.Series.Add("series2")
        'End If

        'Set the titles and axis labels
        Dim mypane As System.Web.UI.DataVisualization.Charting.Series
        mypane = Chart1.Series(0)

        Select Case GroupBy
            Case 0
                Chart1.ChartAreas(0).AxisX.Title = "Campaigns"
                mypane.XValueType = DataVisualization.Charting.ChartValueType.Int32
            Case 1
                Chart1.ChartAreas(0).AxisX.Title = "Agents"
                mypane.XValueType = DataVisualization.Charting.ChartValueType.String
            Case 2
                Chart1.ChartAreas(0).AxisX.Title = "Teams"
                mypane.XValueType = DataVisualization.Charting.ChartValueType.String
            Case 3
                Chart1.ChartAreas(0).AxisX.Title = "Days"
                mypane.XValueType = DataVisualization.Charting.ChartValueType.Date
            Case 4
                Chart1.ChartAreas(0).AxisX.Title = "Hours"
                mypane.XValueType = DataVisualization.Charting.ChartValueType.Int32
            Case 5
                Chart1.ChartAreas(0).AxisX.Title = "Employer"
                mypane.XValueType = DataVisualization.Charting.ChartValueType.String
            Case 6
                Chart1.ChartAreas(0).AxisX.Title = "Transaction Type"
                mypane.XValueType = DataVisualization.Charting.ChartValueType.String
            Case 7
                Chart1.ChartAreas(0).AxisX.Title = "Health Plan"
                mypane.XValueType = DataVisualization.Charting.ChartValueType.String
            Case 8
                Chart1.ChartAreas(0).AxisX.Title = "Resolved" '"Type of complain" '"Company"
                mypane.XValueType = DataVisualization.Charting.ChartValueType.String
            Case 9
                Chart1.ChartAreas(0).AxisX.Title = "In Progress" '"Destination" '"State"
                mypane.XValueType = DataVisualization.Charting.ChartValueType.String
            Case 10
                Chart1.ChartAreas(0).AxisX.Title = "Suplier" '"Reason"
                mypane.XValueType = DataVisualization.Charting.ChartValueType.String

                'Case 11
                '    Chart1.ChartAreas(0).AxisX.Title = "Reason"
                '    mypane.XValueType = DataVisualization.Charting.ChartValueType.String
                'Case 12
                '    Chart1.ChartAreas(0).AxisX.Title = "Reason"
                '    mypane.XValueType = DataVisualization.Charting.ChartValueType.String
        End Select
        Dim recol As String
        GridView1.Columns.Clear()
        Dim bouncol As BoundField
        bouncol = New BoundField
        If dt.Columns.Count > 0 Then
            bouncol.HeaderText = dt.Columns(0).ColumnName
            bouncol.DataField = dt.Columns(0).ColumnName
            bouncol.ItemStyle.HorizontalAlign = HorizontalAlign.Left
        End If
        GridView1.Columns.Add(bouncol)

        Select Case cboGraphType.SelectedValue
            Case 1
                Chart1.Series(0).ChartType = DataVisualization.Charting.SeriesChartType.Spline
                Chart1.Series(0).MarkerStyle = DataVisualization.Charting.MarkerStyle.Diamond
                Chart1.Series(0).MarkerSize = 12
                Chart1.Series(0).MarkerColor = Drawing.Color.Gray
                Chart1.Series(0).BorderWidth = 3
                Chart1.Series(0).IsValueShownAsLabel = True
            Case 3
                Chart1.Series(0).ChartType = DataVisualization.Charting.SeriesChartType.Pie
                Chart1.Series(0)("PieLabelStyle") = "outside"
                Chart1.Series(0).IsValueShownAsLabel = True
                Chart1.Series(0).PostBackValue = "#INDEX"

                'Chart1.ChartAreas(0).AxisY.PositionToValue(100)
                'Chart1.Series(0)("DrawingStyle") = "SoftEdge"
                'Chart1.ChartAreas(0).Area3DStyle.Inclination = 0
            Case Else
                Chart1.Series(0).ChartType = DataVisualization.Charting.SeriesChartType.Column
                Chart1.Series(0)("DrawingStyle") = "Cylinder"
                Chart1.Series(0).IsValueShownAsLabel = True
                'Chart1.ChartAreas(0).Area3DStyle.Enable3D = True
        End Select
        'If KPA > 7 Then
        'Select Case cboGraphType.SelectedValue
        '    Case 1
        '        Chart1.Series(1).ChartType = DataVisualization.Charting.SeriesChartType.Spline
        '        Chart1.Series(1).Color = Drawing.Color.IndianRed
        '        Chart1.Series(1).MarkerStyle = DataVisualization.Charting.MarkerStyle.Diamond
        '        Chart1.Series(1).MarkerSize = 6
        '        Chart1.Series(1).MarkerColor = Drawing.Color.Black
        '        Chart1.Series(1).BorderWidth = 3
        '        Chart1.Series(1).IsValueShownAsLabel = False
        '    Case 3
        '        Chart1.Series(1).ChartType = DataVisualization.Charting.SeriesChartType.Pie
        '    Case Else
        '        Chart1.Series(1).ChartType = DataVisualization.Charting.SeriesChartType.Column
        '        Chart1.Series(1)("DrawingStyle") = "Cylinder"
        '        Chart1.Series(1).Color = Drawing.Color.IndianRed
        'End Select
        'End If

        Chart1.ChartAreas(0).AxisX.LabelAutoFitStyle = DataVisualization.Charting.LabelAutoFitStyles.LabelsAngleStep30
        Select Case KPA
            Case 1

                Chart1.Titles.Add("CPH")
                Chart1.Series(0).XValueMember = dt.Columns(0).ColumnName
                Chart1.Series(0).YValueMembers = "CPH"

                bouncol = New BoundField
                bouncol.HeaderText = "CPH"
                bouncol.DataField = "CPH"
                bouncol.DataFormatString = "{0:n}"
                GridView1.Columns.Add(bouncol)
            Case 2
                'myPane.Title.Text = "Completes"
                Chart1.Titles.Add("Completes")
                Chart1.Series(0).XValueMember = dt.Columns(0).ColumnName
                Chart1.Series(0).YValueMembers = "Completes"

                bouncol = New BoundField
                bouncol.HeaderText = "Completes"
                bouncol.DataField = "Completes"
                GridView1.Columns.Add(bouncol)
            Case 3
                Chart1.Titles.Add("AHT")
                Chart1.Series(0).XValueMember = dt.Columns(0).ColumnName
                Chart1.Series(0).YValueMembers = "AHT"

                bouncol = New BoundField
                bouncol.HeaderText = "AHT"
                bouncol.DataField = "AHT"
                bouncol.DataFormatString = "{0:n}"
                GridView1.Columns.Add(bouncol)
            Case 4
                'myPane.Title.Text = "Login Hrs."

                Chart1.Titles.Add("Login Hrs.")
                Chart1.Series(0).XValueMember = dt.Columns(0).ColumnName
                Chart1.Series(0).YValueMembers = "Loginhrs"
                'Chart1.Series(0).IsValueShownAsLabel = True
                bouncol = New BoundField
                bouncol.HeaderText = "Loginhrs"
                bouncol.DataField = "Loginhrs"
                bouncol.DataFormatString = "{0:n}"
                GridView1.Columns.Add(bouncol)
            Case 5
                Chart1.Titles.Add("Answers")
                Chart1.Series(0).XValueMember = dt.Columns(0).ColumnName
                Chart1.Series(0).YValueMembers = "Answer Count"

                bouncol = New BoundField
                bouncol.HeaderText = "Answer Count"
                bouncol.DataField = "Answer Count"
                GridView1.Columns.Add(bouncol)
            Case 6
                Chart1.Titles.Add("Transaction Type")
                Chart1.Series(0).XValueMember = dt.Columns(0).ColumnName
                Chart1.Series(0).YValueMembers = "Volume"

                bouncol = New BoundField
                bouncol.HeaderText = "Volume"
                bouncol.DataField = "Volume"
                'bouncol.DataFormatString = "{0:n}"
                GridView1.Columns.Add(bouncol)
            Case 7
                Chart1.Titles.Add("Fill Rate")
                Chart1.Series(0).XValueMember = dt.Columns(0).ColumnName
                Chart1.Series(0).YValueMembers = "Fill Rate"

                bouncol = New BoundField
                bouncol.HeaderText = "Fill Rate"
                bouncol.DataField = "Fill Rate"
                bouncol.DataFormatString = "{0:n}"
                GridView1.Columns.Add(bouncol)
            Case 8
                Chart1.Titles.Add("RPH vs CPH")
                Chart1.Series(0).XValueMember = dt.Columns(0).ColumnName
                Chart1.Series(0).YValueMembers = "RPH"
                'Chart1.Series.Add("CPH")
                Chart1.Series(1).XValueMember = dt.Columns(0).ColumnName
                Chart1.Series(1).YValueMembers = "CPH"



                bouncol = New BoundField
                bouncol.HeaderText = "RPH"
                bouncol.DataField = "RPH"
                bouncol.DataFormatString = "{0:n}"
                GridView1.Columns.Add(bouncol)
                bouncol = New BoundField
                bouncol.HeaderText = "CPH"
                bouncol.DataField = "CPH"
                bouncol.DataFormatString = "{0:n}"
                GridView1.Columns.Add(bouncol)
            Case 9
                Chart1.Titles.Add("Sub Disposition")
                Chart1.Series(0).XValueMember = dt.Columns(0).ColumnName
                Chart1.Series(0).YValueMembers = "countsecoutcome"
                'Chart1.Series(0).Points(0)("Exploded") = "true"
                'Chart1.Series(0).IsVisibleInLegen = True
                'Chart1.Series(1).XValueMember = dt.Columns(0).ColumnName
                'Chart1.Series(1).YValueMembers = "countsecoutcome"
                bouncol = New BoundField
                bouncol.HeaderText = "Count"
                bouncol.DataField = "countsecoutcome"
                bouncol.DataFormatString = "{0:n}"
                GridView1.Columns.Add(bouncol)
            Case 10
                Chart1.Titles.Add("Volume")
                Chart1.Series(0).XValueMember = dt.Columns(0).ColumnName
                Chart1.Series(0).YValueMembers = "Volume Received"

                bouncol = New BoundField
                bouncol.HeaderText = "Volume Received"
                bouncol.DataField = "Volume Received"
                ' bouncol.DataFormatString = "{0:n}"
                GridView1.Columns.Add(bouncol)
            Case 11
                Chart1.Titles.Add("Rejects")
                Chart1.Series(0).XValueMember = dt.Columns(0).ColumnName
                Chart1.Series(0).YValueMembers = "Rejects"

                bouncol = New BoundField
                bouncol.HeaderText = "Rejects"
                bouncol.DataField = "Rejects"
                ' bouncol.DataFormatString = "{0:n}"
                GridView1.Columns.Add(bouncol)
            Case 12
                Chart1.Titles.Add("Analysis of Enrollment Errors")
                Chart1.Series(0).XValueMember = dt.Columns(0).ColumnName
                Chart1.Series(0).YValueMembers = "Error"

                bouncol = New BoundField
                bouncol.HeaderText = "Error (%)"
                bouncol.DataField = "Error"
                ' bouncol.DataFormatString = "{0:n}"
                GridView1.Columns.Add(bouncol)
            Case 13
                Chart1.Titles.Add("Analysis of Provider Errors")
                Chart1.Series(0).XValueMember = dt.Columns(0).ColumnName
                Chart1.Series(0).YValueMembers = "Error"

                bouncol = New BoundField
                bouncol.HeaderText = "Error (%)"
                bouncol.DataField = "Error"
                ' bouncol.DataFormatString = "{0:n}"
                GridView1.Columns.Add(bouncol)
            Case 14
                Chart1.Titles.Add("Employer wise open enrollment ")
                Chart1.Series(0).XValueMember = dt.Columns(0).ColumnName
                Chart1.Series(0).YValueMembers = "Open Enrollment"

                bouncol = New BoundField
                bouncol.HeaderText = "Open Enrollment (%)"
                bouncol.DataField = "Open Enrollment"
                ' bouncol.DataFormatString = "{0:n}"
                GridView1.Columns.Add(bouncol)
            Case 15
                Chart1.Titles.Add("Price Transffered")
                Chart1.Series(0).XValueMember = dt.Columns(0).ColumnName
                Chart1.Series(0).YValueMembers = "Price Transffered"

                bouncol = New BoundField
                bouncol.HeaderText = "Price Transffered"
                bouncol.DataField = "Price Transffered"
                ' bouncol.DataFormatString = "{0:n}"
                GridView1.Columns.Add(bouncol)
            Case 16
                Chart1.Titles.Add("Policy Count")
                Chart1.Series(0).XValueMember = dt.Columns(0).ColumnName
                Chart1.Series(0).YValueMembers = "Policy"

                bouncol = New BoundField
                bouncol.HeaderText = "Policy Count"
                bouncol.DataField = "Policy"
                ' bouncol.DataFormatString = "{0:n}"
                GridView1.Columns.Add(bouncol)
                'Case 17
                '    Chart1.Titles.Add("Policy Count")
                '    Chart1.Series(0).XValueMember = dt.Columns(0).ColumnName
                '    Chart1.Series(0).YValueMembers = "Policy"

                '    bouncol = New BoundField
                '    bouncol.HeaderText = "Policy Count"
                '    bouncol.DataField = "Policy"
                '    ' bouncol.DataFormatString = "{0:n}"
                '    GridView1.Columns.Add(bouncol)
            Case 18
                'Chart1.Titles.Add("Count")
                Chart1.Series(0).XValueMember = dt.Columns(0).ColumnName
                Chart1.Series(0).YValueMembers = dt.Columns(1).ColumnName

                bouncol = New BoundField
                bouncol.HeaderText = "Count"
                bouncol.DataField = "Count"
                ' bouncol.DataFormatString = "{0:n}"
                GridView1.Columns.Add(bouncol)
            Case 19
                'Chart1.Titles.Add("[Percent %]")
                Chart1.Series(0).XValueMember = dt.Columns(0).ColumnName
                Chart1.Series(0).YValueMembers = dt.Columns(1).ColumnName

                bouncol = New BoundField
                bouncol.HeaderText = "[Percent %]"
                bouncol.DataField = "Percent %"
                ' bouncol.DataFormatString = "{0:n}"
                GridView1.Columns.Add(bouncol)
        End Select

        Chart1.DataSource = dt.DefaultView
        Chart1.DataBind()
        'GridView1.DataSource = dt.DefaultView
        'GridView1.DataBind()
        Select Case cboGraphType.SelectedValue
            Case 1
                Chart1.Series(0).LabelFormat = "{0:n}"
            Case 3
                'If Chart1.Series(0).Points.Count > 0 Then
                'Chart1.Series(0).Points(Chart1.Series(0).Points.Count - 1)("Exploded") = "true"
                'End If

                Chart1.Series(0).LabelFormat = "{0}%"
                'Chart1.Series(0).Label = "#PERCENT"
                Chart1.Series(0).LegendText = "#VALX"
                Chart1.ChartAreas(0).InnerPlotPosition.X = 10
                Chart1.ChartAreas(0).InnerPlotPosition.Y = 10
                'Chart1.Series(0).ShadowOffset = 2
                'Chart1.ChartAreas(0).Position.X = 80
                Chart1.ChartAreas(0).InnerPlotPosition.Width = 70
                Chart1.ChartAreas(0).InnerPlotPosition.Height = 70
                Chart1.Series(0)("PieDrawingStyle") = "Concave"
                Chart1.Legends.Add("Legent1")
                Chart1.Legends("Legent1").Enabled = True
                'Chart1.Legends("Legent1").CellColumns.Item(0).HeaderText = "abc"
                Chart1.Legends("Legent1").Alignment = System.Drawing.StringAlignment.Center
                'Chart1.Series(0).IsVisibleInLegend = True

            Case Else
                Chart1.Series(0).LabelFormat = "{0}%"
                'Chart1.Series(0)("DrawingStyle") = "Wedge"
                Chart1.Series(0).Color = Drawing.Color.CornflowerBlue
                Chart1.Series(0).BackSecondaryColor = Drawing.Color.Navy
                Chart1.Series(0).BackGradientStyle = GradientStyle.VerticalCenter
                Chart1.Series(0).BackHatchStyle = ChartHatchStyle.LargeConfetti
                Chart1.Series(0).ShadowOffset = 2
        End Select
        'Chart1.Series(0).Label = "#PERCENT"
    End Sub
#End Region
End Class
