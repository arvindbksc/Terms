﻿Imports System.Data
Imports com.nss.DBAccess
Partial Class Graphs_MSGraph
    Inherits System.Web.UI.Page
#Region "Properties"
    Dim dt As DataTable
    Property CampaignID() As Integer
        Get
            Return ViewState("CampaignID")
        End Get
        Set(ByVal value As Integer)
            ViewState("CampaignID") = value
        End Set
    End Property

    Property KPA() As Integer
        Get
            Return ViewState("KPA")
        End Get
        Set(ByVal value As Integer)
            ViewState("KPA") = value
        End Set
    End Property
    Property Period() As Integer
        Get
            Return ViewState("Period")
        End Get
        Set(ByVal value As Integer)
            ViewState("Period") = value
        End Set
    End Property

    Property GroupBy() As Integer
        Get
            Return ViewState("GroupBy")
        End Get
        Set(ByVal value As Integer)
            ViewState("GroupBy") = value
        End Set
    End Property
    Property GraphSize() As Integer
        Get
            Return ViewState("GraphSize")
        End Get
        Set(ByVal value As Integer)
            ViewState("GraphSize") = value
        End Set
    End Property
#End Region
    Dim dtEmployer, dtTat, dtAgent, dtTransType, dtAHT, dtQuality As DataTable
    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        If Not IsPostBack Then


            'Put user code to initialize the page here
            GraphSize = Request.QueryString("GraphSize")
            Chart1.Width = GraphSize
            Chart1.Height = GraphSize
            CampaignID = Request.QueryString("CampaignID")
            KPA = Request.QueryString("KPA")
            Period = Request.QueryString("Period")
            GroupBy = Request.QueryString("GroupBy")



            returnData()
        End If
    End Sub
    Private Sub returnData()
        ' Dim campaignid As Integer = 191
        Dim db As New DBAccess
        db.slDataAdd("Period", Period)
        db.slDataAdd("Campaignid", CampaignID)
        Dim dr As DataRow = db.ReturnRow("usp_GetStart_EndDateForAPeriod", True)
        db = Nothing
        db = New DBAccess
        db.slDataAdd("startday", dr(0))
        db.slDataAdd("endDay", dr(1))
        db.slDataAdd("campaignid", CampaignID)
        db.slDataAdd("groupBy", GroupBy)

        '@test
        dt = db.ReturnTable("[usp_GetKPIChart]", , True)
        If GroupBy = 3 Then 'that is day
            dt.Columns.Add("Day", System.Type.GetType("System.DateTime"), "groupname")
        End If
        db = New DBAccess("CRM")
        db.slDataAdd("StartDate", dr(0))
        db.slDataAdd("EndDate", dr(1))
        db.slDataAdd("CampaignId", CampaignID)
        'dsAll = db.ReturnDataset("usp_WillsDashboard", True)
        dtTat = db.ReturnTable("usp_WillsDashboard", , True)
        db = Nothing
        Dim db1 As New DBAccess("CRM")
        db1.slDataAdd("StartDate", dr(0))
        db1.slDataAdd("EndDate", dr(1))
        db1.slDataAdd("campaignID", 173)
        db1.slDataAdd("GroupBy", 3)
        dtQuality = db1.ReturnTable("usp_CustomDashboard_Quality", , True)
        'dtQuality.Columns.Add("Target", System.Type.GetType("System.Double"), "98")
        db1 = Nothing
        db = New DBAccess("CRM")
        db.slDataAdd("startday", dr(0))
        db.slDataAdd("endDay", dr(1))
        db.slDataAdd("campaignid", CampaignID)
        db.slDataAdd("groupBy", GroupBy)
        '----------------- AHT & Transaction
        dtAHT = db.ReturnTable("usp_dashboard_aht", , True)
        dtAHT.Columns.Remove("AHT")
        dtAHT.Columns.Add("AHT", System.Type.GetType("System.Double"), "iif([Transactions]=0,0, [Transaction Duration]/[Transactions])")
        'dtAHT.Columns.Add("LoginHrs", System.Type.GetType("System.Double"), "[Login Duration]/3600")

        
        db = Nothing
        RenderGraph()
       
    End Sub

    Private Sub RenderGraph()

        'returnData()
        Chart1.Series.Clear()
        Chart1.Series.Add("series1")
        Chart1.ChartAreas(0).AxisX.IntervalAutoMode = DataVisualization.Charting.IntervalAutoMode.FixedCount
        Chart1.TextAntiAliasingQuality = DataVisualization.Charting.TextAntiAliasingQuality.High
        'Chart1.ChartAreas(0).AxisX.LabelAutoFitStyle = DataVisualization.Charting.LabelAutoFitStyles.LabelsAngleStep30
        If GroupBy = 3 Then
            Chart1.Series(0).XValueMember = "Day"
            Chart1.ChartAreas(0).AxisX.LabelStyle.Format = "ddd"
        Else
            Chart1.Series(0).XValueMember = dt.Columns(0).ColumnName
            Chart1.ChartAreas(0).AxisX.LabelStyle.Format = "0"
        End If
        Select Case KPA
            Case 1

                Chart1.Titles.Add("CPH")
                Chart1.Series(0).YValueMembers = "CPH"
                Chart1.Series(0).ChartType = DataVisualization.Charting.SeriesChartType.Spline
                Chart1.Series(0).BorderWidth = 3
                Chart1.Series(0).Color = Drawing.Color.Red
                Chart1.Series(0).MarkerStyle = DataVisualization.Charting.MarkerStyle.Diamond
                Chart1.Series(0).MarkerSize = 6
                Chart1.Series(0).MarkerColor = Drawing.Color.White
                Chart1.DataSource = dt.DefaultView
                Chart1.DataBind()
            Case 2
                'myPane.Title.Text = "Completes"
                Chart1.Titles.Add("Transactions")
                'Chart1.Titles.Add("Completes")
                Chart1.Series(0).YValueMembers = "Transactions"
                Chart1.Series(0).ChartType = DataVisualization.Charting.SeriesChartType.Column
                Chart1.Series(0)("DrawingStyle") = "Cylinder"
                Chart1.DataSource = dt.DefaultView
                Chart1.DataBind()

            Case 3
                Chart1.Titles.Add("AHT")

                Chart1.Series(0).YValueMembers = "AHT"
                Chart1.Series(0).BorderWidth = 3
                Chart1.Series(0).ChartType = DataVisualization.Charting.SeriesChartType.Spline
                Chart1.Series(0).MarkerStyle = DataVisualization.Charting.MarkerStyle.Diamond
                Chart1.Series(0).MarkerSize = 5
                Chart1.Series(0).MarkerColor = Drawing.Color.White
                Chart1.DataSource = dt.DefaultView
                Chart1.DataBind()
            Case 4
                'myPane.Title.Text = "Login Hrs."
                Chart1.Titles.Add("Login Hrs.")
                Chart1.Series(0).YValueMembers = "Login duration"
                Chart1.Series(0).BorderWidth = 3
                Chart1.Series(0).ChartType = DataVisualization.Charting.SeriesChartType.Line
                Chart1.Series(0).MarkerStyle = DataVisualization.Charting.MarkerStyle.Diamond
                Chart1.Series(0).MarkerSize = 5
                Chart1.Series(0).MarkerColor = Drawing.Color.White
                Chart1.DataSource = dt.DefaultView
                Chart1.DataBind()
                '@test
            Case 5

                Chart1.Titles.Add("Monitored Transactions")
                'Chart1.Titles.Add("Completes")
                Chart1.Series(0).YValueMembers = "MonitoredTransactions"
                Chart1.Series(0).ChartType = DataVisualization.Charting.SeriesChartType.Column
                Chart1.Series(0)("DrawingStyle") = "Cylinder"
                Chart1.DataSource = dt.DefaultView
                Chart1.DataBind()

            Case 6

                Chart1.Titles.Add("Error Transactions")
                'Chart1.Titles.Add("Completes")
                Chart1.Series(0).YValueMembers = "ErrorTransactions"
                Chart1.Series(0).ChartType = DataVisualization.Charting.SeriesChartType.Column
                Chart1.Series(0)("DrawingStyle") = "Cylinder"
                Chart1.DataSource = dt.DefaultView
                Chart1.DataBind()


                'Case 5

                '    Chart1.Titles.Add("Volume")
                '    Chart1.Series(0).YValueMembers = "Volume"
                '    Chart1.Series(0).ChartType = DataVisualization.Charting.SeriesChartType.Spline
                '    Chart1.Series(0).BorderWidth = 3
                '    Chart1.Series(0).Color = Drawing.Color.Red
                '    Chart1.Series(0).MarkerStyle = DataVisualization.Charting.MarkerStyle.Diamond
                '    Chart1.Series(0).MarkerSize = 6
                '    Chart1.Series(0).MarkerColor = Drawing.Color.White
                'Case 6
                '    'myPane.Title.Text = "Completes"
                '    Chart1.Titles.Add("AHT")
                '    'Chart1.Titles.Add("Completes")
                '    Chart1.Series(0).YValueMembers = "AHT"
                '    Chart1.Series(0).ChartType = DataVisualization.Charting.SeriesChartType.Column
                '    Chart1.Series(0)("DrawingStyle") = "Cylinder"
                '    Chart1.DataSource = dtAHT.DefaultView
                '    Chart1.DataBind()

                'Case 7
                '    Chart1.Titles.Add("TAT")

                '    Chart1.Series(0).YValueMembers = "TAT"
                '    Chart1.Series(0).BorderWidth = 3
                '    Chart1.Series(0).ChartType = DataVisualization.Charting.SeriesChartType.Spline
                '    Chart1.Series(0).MarkerStyle = DataVisualization.Charting.MarkerStyle.Diamond
                '    Chart1.Series(0).MarkerSize = 5
                '    Chart1.Series(0).MarkerColor = Drawing.Color.White
                '    Chart1.DataSource = dtTat.DefaultView
                '    Chart1.DataBind()
                'Case 8
                '    'myPane.Title.Text = "Login Hrs."
                '    Chart1.Titles.Add("FAR")
                '    Chart1.Series(0).YValueMembers = "FAR"
                '    Chart1.Series(0).BorderWidth = 3
                '    Chart1.Series(0).ChartType = DataVisualization.Charting.SeriesChartType.Line
                '    Chart1.Series(0).MarkerStyle = DataVisualization.Charting.MarkerStyle.Diamond
                '    Chart1.Series(0).MarkerSize = 5
                '    Chart1.Series(0).MarkerColor = Drawing.Color.White
                '    Chart1.DataSource = dtQuality.DefaultView
                '    Chart1.DataBind()





        End Select

        
    End Sub

End Class

