
Imports System.Web.UI.DataVisualization.Charting
Imports System.Data
Imports com.nss.DBAccess
Public Class graph
    Inherits System.Web.UI.Page

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region
    Dim dt As DataTable
#Region "Properties"


    Property CampaignID() As Integer
        'Get
        '    Return cboCampaigns.SelectedValue
        'End Get
        'Set(ByVal value As Integer)
        '    cboCampaigns.SelectedItem.Selected = False
        '    cboCampaigns.Items.FindByValue(value).Selected = True
        'End Set
        Get
            Return ViewState("CampaignID")
        End Get
        Set(ByVal value As Integer)
            ViewState("CampaignID") = value
        End Set
    End Property

    Property KPA() As Integer
        Get
            Return ViewState("KPA")
        End Get
        Set(ByVal value As Integer)
            ViewState("KPA") = value
        End Set
    End Property


    Property Period() As Integer
        Get
            Return CboPeriod.SelectedValue
        End Get
        Set(ByVal value As Integer)
            CboPeriod.Items.FindByValue(value).Selected = True
        End Set
    End Property

    Property GroupBy() As Integer
        Get
            Return CboGroup.SelectedValue
        End Get
        Set(ByVal value As Integer)
            CboGroup.Items.FindByValue(value).Selected = True
        End Set
    End Property
    Property AgentID() As String
        Get
            Return ViewState("AgentID")
        End Get
        Set(ByVal value As String)
            ViewState("AgentID") = value
        End Set
    End Property
    Property Campaigntype() As Integer
        Get
            Return ViewState("Campaigntype")
        End Get
        Set(ByVal value As Integer)
            ViewState("Campaigntype") = value
            'Session("ProcessID") = value
        End Set
    End Property
#End Region

#Region "Initialize Controls"


    Private Sub LoadData()
        FillCommonFilters()
        FillProcessCampaigns()

    End Sub

    Private Sub FillCommonFilters()
        Dim db As New DBAccess
        Dim dt As DataTable = db.ReturnTable("select * from tbl_Reports_DatePeriods")
        db = Nothing
        Dim dr As DataRow = dt.NewRow
        dr(0) = 10
        dr(1) = "Between"
        dt.Rows.Add(dr)
        CboPeriod.DataTextField = "Caption"
        CboPeriod.DataValueField = "Period"
        CboPeriod.DataSource = dt
        CboPeriod.DataBind()
        db = New DBAccess
        dt = db.ReturnTable("Select * from tbl_Reports_GroupBy")
        db = Nothing
        Dim dr1 As DataRow = dt.NewRow
        dr1(1) = 5
        dr1(0) = "Questions"
        dt.Rows.Add(dr1)
        Dim dr2 As DataRow = dt.NewRow
        dr2(1) = 6
        dr2(0) = "Dispositions"
        dt.Rows.Add(dr2)
        Dim dr3 As DataRow = dt.NewRow
        dr3(1) = 9
        dr3(0) = "Sub Disposition"
        dt.Rows.Add(dr3)

        '@test
        'Dim dr4 As DataRow = dt.NewRow
        'dr4(1) = 10
        'dr4(0) = "Monitored"
        'dt.Rows.Add(dr4)

        CboGroup.DataTextField = "Caption"
        CboGroup.DataValueField = "ID"
        CboGroup.DataSource = dt
        CboGroup.DataBind()


    End Sub
    Private Sub FillProcessCampaigns()
        Common.FillProcessCampaigns(CboProcess, cboCampaigns, AgentID, CampaignID)
        Dim lstcampaign As New ListItem
        lstcampaign.Value = 0
        lstcampaign.Text = "All"
        If cboCampaigns.Items.Contains(lstcampaign) Then
            cboCampaigns.Items.Remove(lstcampaign)
        End If


    End Sub
#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
        If Not IsPostBack Then
            If Session("AgentID") <> "" Then
                CampaignID = Session("CampaignID")
                AgentID = Session("AgentID")
                LoadData()
                KPA = Request.QueryString("KPA")
                Period = Request.QueryString("Period")
                GroupBy = Request.QueryString("GroupBy")
                DrawChart()
                UcDateTo.Visible = False
                ucDateFrom.Visible = False
                lblAnd.Visible = False
            End If
        End If
    End Sub

    Private Sub filldisposition()
        Dim db As New DBAccess("CRM")
        Dim dt As New DataTable
        db.slDataAdd("CampaignID", cboCampaigns.SelectedValue)
        dt = db.ReturnTable("usp_GetDispositions", , True)
        db = Nothing
        If dt.Rows.Count > 0 Then
            Dim dr As DataRow = dt.NewRow
            dr(0) = 0
            dr(1) = "All"
            dt.Rows.Add(dr)
            cboDisposition.DataValueField = "Code"
            cboDisposition.DataTextField = "Caption"
            cboDisposition.DataSource = dt
            cboDisposition.DataBind()
        End If
        dt = Nothing
    End Sub
    Private Sub fillQuestions()
        Dim db As New DBAccess
        Dim dt As New DataTable
        db.slDataAdd("CampaignID", cboCampaigns.SelectedValue)
        dt = db.ReturnTable("usp_getQuestionDropDown", , True)
        db = Nothing
        If dt.Rows.Count > 0 Then
            'Dim dr As DataRow = dt.NewRow
            'dr(0) = 0
            'dr(1) = "All"
            'dt.Rows.Add(dr)
            cboDisposition.DataValueField = "QuestId"
            cboDisposition.DataTextField = "Caption"
            cboDisposition.DataSource = dt
            cboDisposition.DataBind()
        End If
        dt = Nothing
    End Sub
    
    Private Sub DrawChart()
        returnData()
        RenderGraph()
    End Sub
    Private Sub returnData()
        ' Dim campaignid As Integer = 191
        Dim db As New DBAccess
        Dim startday As Integer, endday As Integer
        If CboPeriod.SelectedValue = 10 Then
            startday = ucDateFrom.yyyymmdd
            endday = UcDateTo.yyyymmdd
        Else
            db = New DBAccess
            db.slDataAdd("Period", CboPeriod.SelectedValue)
            db.slDataAdd("Campaignid", CampaignID)
            Dim dr As DataRow = db.ReturnRow("usp_GetStart_EndDateForAPeriod", True)
            db = Nothing
            startday = dr(0)
            endday = dr(1)
        End If
        db = Nothing
        ' db = New DBAccess
        'Dim drKPa As DataRow = db.ReturnRow("select * from tbl_Config_KPA_Master where KPAID=" & KPA)

        'db = Nothing
        'Dim sqlselect As String, sqlwhere As String, sqlgroup As String
        'sqlselect = "Select  A.AgentID,n.[Group Id], n.[Agent Name], n.[Group Name],convert(varchar,[Day]) as [Day],convert(varchar,[Hour]) as [Hour]" & _
        '        ",A.LoginDuration , A.TransactionDuration , A.BreakDuration , A.Transactions , A.Sales , a.campaignid " & _
        '        " FROM tbl_Summary_Performance A  inner join @names n on n.agentid=A.agentid " & _
        '        " where A.[Day]>= @startday and A.[Day]<= @endday and  A.campaignid  =@campaignID"
        db = New DBAccess
        db.slDataAdd("Campaignid", CampaignID)
        db.slDataAdd("userid", AgentID)
        Dim dtcampaigntype As DataTable = db.ReturnTable("usp_getcampaigntype", , True)
        db = Nothing
        If dtcampaigntype.Rows.Count > 1 Then
            Campaigntype = 1
        ElseIf dtcampaigntype.Rows.Count = 0 Then
            Campaigntype = 1
        Else
            Campaigntype = dtcampaigntype.Rows(0).Item(0)
        End If
        db = Nothing

        db = New DBAccess
        db.slDataAdd("startday", startday)
        db.slDataAdd("endDay", endday)
        db.slDataAdd("campaignid", CampaignID)
        db.slDataAdd("groupBy", GroupBy)
        If CboGroup.SelectedValue = 5 Then
            KPA = 5
        ElseIf CboGroup.SelectedValue = 6 Then
            KPA = 6
        ElseIf CboGroup.SelectedValue = 9 Then
            KPA = 9
        
        Else
            KPA = cboKPA.SelectedValue
        End If

        If KPA < 5 Then
            If Campaigntype = 11 Then
                dt = db.ReturnTable("usp_CampaignPerformanceTerms2_VoiceCampaign", "", True)
            Else
                dt = db.ReturnTable("usp_CampaignPerformanceTerms2", , True)
            End If
            dt.Columns.Remove("CPH")
            If Campaigntype = 11 Then
                dt.Columns.Add("CPH", System.Type.GetType("System.Decimal"), "iif([Login Duration]=0,0, ([Completes]/[Login Duration])*3600)")
            Else
                dt.Columns.Add("CPH", System.Type.GetType("System.Decimal"), "iif([Login Duration]=0,0, ([Completes]/[Login Duration])*3600)")
            End If
            If Campaigntype = 11 Then
                dt.Columns.Add("AHT1", System.Type.GetType("System.Double"), "iif([Completes]=0,0, [AHT]/[Completes])")
            Else
                dt.Columns.Remove("AHT")
                dt.Columns.Add("AHT", System.Type.GetType("System.Double"), "iif([Transactions]=0,0, [Transaction Duration]/[Transactions])")
            End If

            

            'dt.Columns.Remove("LoginHrs")
            dt.Columns.Add("LoginHrs", System.Type.GetType("System.Double"), "[Login Duration]/3600")
            '@test
            'ElseIf KPA = 10 Then
            '    dt.Columns.Add("Monitored Transaction", System.Type.GetType("System.Double"), "Monitored/3600")
        ElseIf KPA = 9 Then
            db.slDataAdd("Disposition", cboDisposition.SelectedValue)
            db.slDataAdd("graphtype", cboGraphType.SelectedValue)
            dt = db.ReturnTable("[usp_getSubOutcome]", , True)
            dt.Columns.Remove("column1")
        ElseIf KPA = 5 Then
            Dim dbanswer As New DBAccess
            dbanswer.slDataAdd("startday", startday)
            dbanswer.slDataAdd("endDay", endday)
            dbanswer.slDataAdd("Question", cboDisposition.SelectedValue)
            dbanswer.slDataAdd("graphtype", cboGraphType.SelectedValue)
            dt = dbanswer.ReturnTable("[usp_getAnswersCount]", , True)
        ElseIf KPA = 6 Then
            'getoutcome(startday, endday)
            dt = transpose(startday, endday)
            If cboGraphType.SelectedValue = 3 Then
                dt.DefaultView.Sort = "Count ASC"
            End If

            'Else
            '    dt = db.ReturnTable("usp_Survey_Analysis", , True)
            '    dt.Columns.Remove("RPH")
            '    dt.Columns.Add("RPH", System.Type.GetType("System.Decimal"), "iif([Login Duration]=0,0, ([Revenue]/[Login Duration])*3600)")
            '    dt.Columns.Remove("Fill Rate")
            '    dt.Columns.Add("Fill Rate", System.Type.GetType("System.Decimal"), "iif([Total Responses]=0,0, ([Positive Count]/[Total Responses]))")
            '    dt.Columns.Remove("CPH")
            '    dt.Columns.Add("CPH", System.Type.GetType("System.Decimal"), "iif([Login Duration]=0,0, ([Completes]/[Login Duration])*3600)")

        End If

       
    End Sub
    Private Sub getoutcome(ByVal startday As Integer, ByVal endday As Integer)
        Dim dboutcome As New DBAccess
        Dim dtoutcome As DataTable
        dboutcome.slDataAdd("startday", startday)
        dboutcome.slDataAdd("endDay", endday)
        dboutcome.slDataAdd("campaignid", CampaignID)
        dtoutcome = dboutcome.ReturnTable("usp_getoutcome", , True)
        dboutcome = Nothing
        Dim cols As DataColumnCollection = dtoutcome.Columns
        dboutcome = New DBAccess
        dboutcome.slDataAdd("CampaignID", CampaignID)
        Dim dtoutcome2 As DataTable = dboutcome.ReturnTable("usp_ReportOutcomeDescription", , True)
        dboutcome = Nothing
        For Each dr In dtoutcome2.Rows
            cols("Outcome" & dr("toOutcome")).Caption = dr("Description")
        Next
        'Dim bouncol As BoundField
        Dim objcol As DataColumn
        For Each objcol In cols
            If objcol.ColumnName.Contains("Outcome") Then
                If objcol.Caption <> objcol.ColumnName Then
                    dtoutcome.Columns.Item(objcol.ColumnName).ColumnName = objcol.Caption
                End If
            End If
        Next
    End Sub
    Private Function transpose(ByVal startday As Integer, ByVal endday As Integer) As DataTable
        Dim dboutcome As New DBAccess
        Dim dtoutcome As DataTable
        dboutcome.slDataAdd("startday", startday)
        dboutcome.slDataAdd("endDay", endday)
        dboutcome.slDataAdd("campaignid", CampaignID)
        dtoutcome = dboutcome.ReturnTable("usp_getoutcome", , True)
        dboutcome = Nothing
        Dim cols As DataColumnCollection = dtoutcome.Columns
        dboutcome = New DBAccess
        dboutcome.slDataAdd("CampaignID", CampaignID)
        Dim dtoutcome2 As DataTable = dboutcome.ReturnTable("usp_ReportOutcomeDescription", , True)
        dboutcome = Nothing
        For Each dr In dtoutcome2.Rows
            cols("Outcome" & dr("toOutcome")).Caption = dr("Description")
        Next
        'Dim bouncol As BoundField
        Dim objcol As DataColumn
        For Each objcol In cols
            If objcol.ColumnName.Contains("Outcome") Then
                If objcol.Caption <> objcol.ColumnName Then
                    dtoutcome.Columns.Item(objcol.ColumnName).ColumnName = objcol.Caption
                End If
            End If
        Next

        Dim newdt As New DataTable
        newdt.Columns.Add("Dispositions")
        newdt.Columns.Add("Count", GetType(Integer))
        'For Each dr As DataRow In dtoutcome.Rows
        '    newdt.Columns.Add(dr(0))
        'Next
        For i As Integer = 1 To dtoutcome.Columns.Count - 1
            Dim dr As DataRow = newdt.NewRow
            If Not dtoutcome.Columns(i).ColumnName.Contains("Outcome") Then
                dr.Item(0) = dtoutcome.Columns(i).ColumnName
                For j As Integer = 0 To dtoutcome.Rows.Count - 1
                    dr.Item(j + 1) = dtoutcome.Rows(j).Item(i).ToString
                Next
                newdt.Rows.Add(dr)
            End If
           
        Next
        'For Each row In newdt.Rows
        '    If row(0).ToString.Contains("Outcome") Then
        '        newdt.Rows.Remove(row)
        '    End If
        'Next
        Return newdt
    End Function


    Private Sub RenderGraph()
        Chart1.Series.Clear()
        Chart1.Series.Add("series1")
        If CboGroup.SelectedValue = 5 Then
            KPA = 5
        ElseIf CboGroup.SelectedValue = 6 Then
            KPA = 6
        ElseIf CboGroup.SelectedValue = 9 Then
            KPA = 9
            '@test
            'ElseIf CboGroup.SelectedValue = 10 Then
            '    KPA = 10


        Else
            KPA = cboKPA.SelectedValue
        End If

        'If KPA > 7 Then
        'Chart1.Series.Add("series2")
        'End If

        'Set the titles and axis labels
        Dim mypane As System.Web.UI.DataVisualization.Charting.Series
        mypane = Chart1.Series(0)

        Select Case GroupBy
            Case 0
                Chart1.ChartAreas(0).AxisX.Title = "Campaigns"
                mypane.XValueType = DataVisualization.Charting.ChartValueType.Int32
            Case 1
                Chart1.ChartAreas(0).AxisX.Title = "Agents"
                mypane.XValueType = DataVisualization.Charting.ChartValueType.String
            Case 2
                Chart1.ChartAreas(0).AxisX.Title = "Teams"
                mypane.XValueType = DataVisualization.Charting.ChartValueType.String
            Case 3
                Chart1.ChartAreas(0).AxisX.Title = "Days"
                mypane.XValueType = DataVisualization.Charting.ChartValueType.Date
            Case 4
                Chart1.ChartAreas(0).AxisX.Title = "Hours"
                mypane.XValueType = DataVisualization.Charting.ChartValueType.Int32
            Case 5
                Chart1.ChartAreas(0).AxisX.Title = "Question"
                mypane.XValueType = DataVisualization.Charting.ChartValueType.String
                '@test
                'Case 10
                '    Chart1.ChartAreas(0).AxisX.Title = "Monitored"
                '    mypane.XValueType = DataVisualization.Charting.ChartValueType.String
        End Select
        Dim recol As String
        GridView1.Columns.Clear()

        Dim bouncol As BoundField
        bouncol = New BoundField
        bouncol.HeaderText = dt.Columns(0).ColumnName
        bouncol.DataField = dt.Columns(0).ColumnName
        bouncol.ItemStyle.HorizontalAlign = HorizontalAlign.Left
        GridView1.Columns.Add(bouncol)

        Select Case cboGraphType.SelectedValue
            Case 1
                Chart1.Series(0).ChartType = DataVisualization.Charting.SeriesChartType.Spline
                Chart1.Series(0).MarkerStyle = DataVisualization.Charting.MarkerStyle.Diamond
                Chart1.Series(0).MarkerSize = 12
                Chart1.Series(0).MarkerColor = Drawing.Color.Gray
                Chart1.Series(0).BorderWidth = 3
                Chart1.Series(0).IsValueShownAsLabel = True
            Case 3
                Chart1.Series(0).ChartType = DataVisualization.Charting.SeriesChartType.Pie
                Chart1.Series(0)("PieLabelStyle") = "outside"
                Chart1.Series(0).IsValueShownAsLabel = True
                Chart1.Series(0).PostBackValue = "#INDEX"
                'Chart1.Series(0)("DrawingStyle") = "SoftEdge"
                'Chart1.ChartAreas(0).Area3DStyle.Inclination = 0
            Case Else
                Chart1.Series(0).ChartType = DataVisualization.Charting.SeriesChartType.Column
                Chart1.Series(0)("DrawingStyle") = "Cylinder"
                Chart1.Series(0).IsValueShownAsLabel = True
                'Chart1.ChartAreas(0).Area3DStyle.Enable3D = True
        End Select
        'If KPA > 7 Then
        'Select Case cboGraphType.SelectedValue
        '    Case 1
        '        Chart1.Series(1).ChartType = DataVisualization.Charting.SeriesChartType.Spline
        '        Chart1.Series(1).Color = Drawing.Color.IndianRed
        '        Chart1.Series(1).MarkerStyle = DataVisualization.Charting.MarkerStyle.Diamond
        '        Chart1.Series(1).MarkerSize = 6
        '        Chart1.Series(1).MarkerColor = Drawing.Color.Black
        '        Chart1.Series(1).BorderWidth = 3
        '        Chart1.Series(1).IsValueShownAsLabel = False
        '    Case 3
        '        Chart1.Series(1).ChartType = DataVisualization.Charting.SeriesChartType.Pie
        '    Case Else
        '        Chart1.Series(1).ChartType = DataVisualization.Charting.SeriesChartType.Column
        '        Chart1.Series(1)("DrawingStyle") = "Cylinder"
        '        Chart1.Series(1).Color = Drawing.Color.IndianRed
        'End Select
        'End If
        Chart1.ChartAreas(0).AxisX.LabelAutoFitStyle = DataVisualization.Charting.LabelAutoFitStyles.LabelsAngleStep30
        Select Case KPA
            Case 1

                Chart1.Titles.Add("CPH")
                Chart1.Series(0).XValueMember = dt.Columns(0).ColumnName
                Chart1.Series(0).YValueMembers = "CPH"

                bouncol = New BoundField
                bouncol.HeaderText = "CPH"
                bouncol.DataField = "CPH"
                bouncol.DataFormatString = "{0:n}"
                GridView1.Columns.Add(bouncol)
            Case 2
                'myPane.Title.Text = "Completes"
                Chart1.Titles.Add("Completes")
                Chart1.Series(0).XValueMember = dt.Columns(0).ColumnName
                Chart1.Series(0).YValueMembers = "Completes"

                bouncol = New BoundField
                bouncol.HeaderText = "Completes"
                bouncol.DataField = "Completes"
                GridView1.Columns.Add(bouncol)
            Case 3
                Chart1.Titles.Add("AHT")
                Chart1.Series(0).XValueMember = dt.Columns(0).ColumnName
                If Campaigntype = 11 Then
                    Chart1.Series(0).YValueMembers = "AHT1"
                Else
                    Chart1.Series(0).YValueMembers = "AHT"
                End If


                bouncol = New BoundField
                bouncol.HeaderText = "AHT"
                If Campaigntype = 11 Then
                    bouncol.DataField = "AHT1"
                Else
                    bouncol.DataField = "AHT"
                End If

                bouncol.DataFormatString = "{0:n}"
                GridView1.Columns.Add(bouncol)
            Case 4
                'myPane.Title.Text = "Login Hrs."

                Chart1.Titles.Add("Login Hrs.")
                Chart1.Series(0).XValueMember = dt.Columns(0).ColumnName
                Chart1.Series(0).YValueMembers = "Loginhrs"
                'Chart1.Series(0).IsValueShownAsLabel = True
                bouncol = New BoundField
                bouncol.HeaderText = "Loginhrs"
                bouncol.DataField = "Loginhrs"
                bouncol.DataFormatString = "{0:n}"
                GridView1.Columns.Add(bouncol)
            Case 5
                Chart1.Titles.Add("Answers")
                Chart1.Series(0).XValueMember = dt.Columns(0).ColumnName
                Chart1.Series(0).YValueMembers = "Answer Count"

                bouncol = New BoundField
                bouncol.HeaderText = "Answer Count"
                bouncol.DataField = "Answer Count"
                GridView1.Columns.Add(bouncol)
            Case 6
                Chart1.Titles.Add("Dispositions")
                Chart1.Series(0).XValueMember = dt.Columns(0).ColumnName
                Chart1.Series(0).YValueMembers = "count"

                bouncol = New BoundField
                bouncol.HeaderText = "count"
                bouncol.DataField = "count"
                'bouncol.DataFormatString = "{0:n}"
                GridView1.Columns.Add(bouncol)
            Case 7
                Chart1.Titles.Add("Fill Rate")
                Chart1.Series(0).XValueMember = dt.Columns(0).ColumnName
                Chart1.Series(0).YValueMembers = "Fill Rate"

                bouncol = New BoundField
                bouncol.HeaderText = "Fill Rate"
                bouncol.DataField = "Fill Rate"
                bouncol.DataFormatString = "{0:n}"
                GridView1.Columns.Add(bouncol)
            Case 8
                Chart1.Titles.Add("RPH vs CPH")
                Chart1.Series(0).XValueMember = dt.Columns(0).ColumnName
                Chart1.Series(0).YValueMembers = "RPH"
                'Chart1.Series.Add("CPH")
                Chart1.Series(1).XValueMember = dt.Columns(0).ColumnName
                Chart1.Series(1).YValueMembers = "CPH"



                bouncol = New BoundField
                bouncol.HeaderText = "RPH"
                bouncol.DataField = "RPH"
                bouncol.DataFormatString = "{0:n}"
                GridView1.Columns.Add(bouncol)
                bouncol = New BoundField
                bouncol.HeaderText = "CPH"
                bouncol.DataField = "CPH"
                bouncol.DataFormatString = "{0:n}"
                GridView1.Columns.Add(bouncol)
            Case 9
                Chart1.Titles.Add("Sub Disposition")
                Chart1.Series(0).XValueMember = dt.Columns(0).ColumnName
                Chart1.Series(0).YValueMembers = "countsecoutcome"
                'Chart1.Series(0).Points(0)("Exploded") = "true"
                'Chart1.Series(0).IsVisibleInLegen = True
                'Chart1.Series(1).XValueMember = dt.Columns(0).ColumnName
                'Chart1.Series(1).YValueMembers = "countsecoutcome"
                bouncol = New BoundField
                bouncol.HeaderText = "Count"
                bouncol.DataField = "countsecoutcome"
                bouncol.DataFormatString = "{0:n}"
                GridView1.Columns.Add(bouncol)

                '@test
                'Case 10

                '    Chart1.Titles.Add("Monitored Transaction")
                '    Chart1.Series(0).XValueMember = dt.Columns(0).ColumnName
                '    Chart1.Series(0).YValueMembers = "Monitored"

                '    bouncol = New BoundField
                '    bouncol.HeaderText = "Monitored Transaction"
                '    bouncol.DataField = "Monitored Transaction"
                '    bouncol.DataFormatString = "{0:n}"
                '    GridView1.Columns.Add(bouncol)

        End Select

        Chart1.DataSource = dt.DefaultView
        Chart1.DataBind()
        GridView1.DataSource = dt.DefaultView
        GridView1.DataBind()
        Select Case cboGraphType.SelectedValue
            Case 1
                Chart1.Series(0).LabelFormat = "{0:n}"
            Case 3
                'If Chart1.Series(0).Points.Count > 0 Then
                '    Chart1.Series(0).Points(Chart1.Series(0).Points.Count - 1)("Exploded") = "true"
                'End If
                Chart1.Series(0).Label = "#PERCENT"
                Chart1.Series(0).ShadowOffset = 2
                Chart1.Series(0)("PieDrawingStyle") = "Concave"
            Case Else
                Chart1.Series(0).LabelFormat = "{0:n}"
                'Chart1.Series(0)("DrawingStyle") = "Wedge"
                Chart1.Series(0).Color = Drawing.Color.CornflowerBlue
                Chart1.Series(0).BackSecondaryColor = Drawing.Color.Navy
                Chart1.Series(0).BackGradientStyle = GradientStyle.VerticalCenter
                Chart1.Series(0).BackHatchStyle = ChartHatchStyle.LargeConfetti
                Chart1.Series(0).ShadowOffset = 2
        End Select
    End Sub


    Protected Sub CboGroup_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles CboGroup.SelectedIndexChanged
        If CboGroup.SelectedValue = 5 Then
            lblkpa.Visible = False
            lblDisposition.Visible = True
            cboDisposition.Visible = True
            lblDisposition.Text = "Questions"
            fillQuestions()
            cboKPA.Visible = False
        ElseIf CboGroup.SelectedValue = 6 Then
            cboKPA.Visible = False
            lblkpa.Visible = False
            lblDisposition.Visible = False
            cboDisposition.Visible = False
        ElseIf CboGroup.SelectedValue = 9 Then
            lblkpa.Visible = False
            lblDisposition.Visible = True
            cboDisposition.Visible = True
            lblDisposition.Text = "Dispositions"
            filldisposition()
            cboKPA.Visible = False
        Else
            cboKPA.Visible = True
            lblkpa.Visible = True
            'If cboKPA.SelectedValue = 9 Then
            '    filldisposition()
            '    lblDisposition.Visible = True
            '    cboDisposition.Visible = True
            '    lblDisposition.Text = "Dispositions"
            'Else
            lblDisposition.Visible = False
            cboDisposition.Visible = False
            'End If

        End If
        DrawChart()
    End Sub

    Protected Sub CboPeriod_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles CboPeriod.SelectedIndexChanged
        If CboGroup.SelectedValue = 9 Then
            lblkpa.Visible = False
            lblDisposition.Visible = True
            cboDisposition.Visible = True
            lblDisposition.Text = "Dispositions"
            filldisposition()
            cboKPA.Visible = False
        ElseIf CboGroup.SelectedValue = 5 Then
            lblDisposition.Visible = True
            cboDisposition.Visible = True
            lblDisposition.Text = "Questions"
            fillQuestions()
            cboKPA.Visible = False
        ElseIf CboGroup.SelectedValue = 6 Then
            cboKPA.Visible = False
            lblkpa.Visible = False
            lblDisposition.Visible = False
            cboDisposition.Visible = False
        End If
        If CboPeriod.SelectedValue = 10 Then
            ucDateFrom.Visible = True
            UcDateTo.Visible = True
            lblAnd.Visible = True
            DrawChart()
        Else
            ucDateFrom.Visible = False
            UcDateTo.Visible = False
            lblAnd.Visible = False
            DrawChart()
        End If

    End Sub

    Protected Sub cboCampaigns_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboCampaigns.SelectedIndexChanged
        CampaignID = cboCampaigns.SelectedValue
        If CboGroup.SelectedValue = 9 Then
            lblkpa.Visible = False
            lblDisposition.Visible = True
            cboDisposition.Visible = True
            lblDisposition.Text = "Dispositions"
            filldisposition()
            cboKPA.Visible = False
        ElseIf CboGroup.SelectedValue = 5 Then
            lblDisposition.Visible = True
            cboDisposition.Visible = True
            lblDisposition.Text = "Questions"
            fillQuestions()
            cboKPA.Visible = False
        ElseIf CboGroup.SelectedValue = 6 Then
            cboKPA.Visible = False
            lblkpa.Visible = False
            lblDisposition.Visible = False
            cboDisposition.Visible = False
        End If
        'filldisposition()
        'fillQuestions()
        DrawChart()
    End Sub

    Protected Sub cboKPA_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboKPA.SelectedIndexChanged
        If cboKPA.SelectedValue = 9 Then
            filldisposition()
            lblDisposition.Visible = True
            cboDisposition.Visible = True
            lblDisposition.Text = "Dispositions"
        ElseIf cboKPA.SelectedValue = 5 Then
            lblDisposition.Visible = True
            cboDisposition.Visible = True
            lblDisposition.Text = "Questions"
            fillQuestions()
        Else

            lblDisposition.Visible = False
            cboDisposition.Visible = False
        End If

        DrawChart()
    End Sub

    Protected Sub cboGraphType_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboGraphType.SelectedIndexChanged
        DrawChart()
    End Sub

    Protected Sub btnRefresh_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnRefresh.Click
        DrawChart()
    End Sub

    Protected Sub cboDisposition_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboDisposition.SelectedIndexChanged

        DrawChart()
    End Sub

    Protected Sub ucDateFrom_Changed(ByVal sender As Object, ByVal e As System.EventArgs) Handles ucDateFrom.Changed
        DrawChart()
    End Sub

    Protected Sub UcDateTo_Changed(ByVal sender As Object, ByVal e As System.EventArgs) Handles UcDateTo.Changed
        DrawChart()
    End Sub


    Protected Sub Chart1_Click(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.ImageMapEventArgs) Handles Chart1.Click
        DrawChart()
        Select Case cboGraphType.SelectedValue
            Case 1
            Case 3
                Dim i As Integer = e.PostBackValue
                If i >= 0 And i < Chart1.Series(0).Points.Count Then
                    Chart1.Series(0).Points(i).CustomProperties += "Exploded=true"
                End If


            Case Else
        End Select
    End Sub
End Class
