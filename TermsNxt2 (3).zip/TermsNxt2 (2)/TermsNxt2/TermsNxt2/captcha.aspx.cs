﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using com.nss.DBAccess;
using System.IO;
using System.DirectoryServices.AccountManagement;
using System.DirectoryServices;
using System.Web.Security;
using System.Configuration;
using System.Text.RegularExpressions;

public partial class captcha : System.Web.UI.Page
{


    private string DomainName="";
    private string m_UserId="";

    string domainName = System.Net.NetworkInformation.IPGlobalProperties.GetIPGlobalProperties().DomainName;

    public string AgentID
    {
        get { return ViewState["Agentid"].ToString(); }
        set
        {
            
            ViewState["Agentid"] = value;
        }
    }


    
    protected void Page_Load(object sender, EventArgs e)
    {

        //tbxcode.Text = hdncode.Value;
    }

    #region "Change Password"


    public bool Authenticate()
    {


        if (this.Session["UserID"] != null)
        {


            Session["Lanid"] = Request.ServerVariables["LOGON_USER"].ToString().Substring(Request.ServerVariables["LOGON_USER"].ToString().IndexOf("\\", 0) + 1);

            com.nss.DBAccess.DBAccess.process = "Report";
            com.nss.DBAccess.DBAccess db = new com.nss.DBAccess.DBAccess();




            if (Session["Lanid"] == "" )
            {
                Session["Lanid"] = "&&";
            
            }

            db.slDataAdd("UserId", Session["Lanid"]);
            System.Data.DataRow dr = db.ReturnRow("usp_CheckTermsUser", true);
            
            if (dr == null)
            {

                lblerror.Text = "The username or password you entered is incorrect.";
                PanelError.Visible = true;
                return false;
            }
             if (dr != null)
             {
            Session["AgentID"] = dr["AgentID"];
                Session["Campaignid"] = dr["Campaignid"];
                Session["username"] = dr["AgentName"];
                Session["UserID"] = dr["AgentID"];
                Response.Write(Session["username"]);
                Response.Write(Session["Lanid"]);
                return true;
             }

            
        }

        else
        {
            return false;
        }

        return false;

    }

    



    private bool RedirectToWinAuth(string strInternal = "Internal")
    {
        bool flag = false;

            if (strInternal == "external" )
        {
                //'@original
                //'To Return authenticate true and redirect to another page sitemap.aspx 
                //'Response.Redirect(Request.RawUrl.Replace("weblogin", "winauth/winlogin"))

                if (Authenticate() ==true)
                {
                   // 'FormsAuthentication.RedirectFromLoginPage(Session("AgentID"), False)
                    flag = true; 
                    return flag;


                }
        }


          
        string str ="";
        str = ConfigurationManager.AppSettings["Internal"];

        if (Regex.IsMatch(Request.UserHostAddress.ToString(),str))
        {

              Response.Redirect(Request.RawUrl.Replace("weblogin", "winauth/winlogin"));
        }
        else

        {
            flag = false;
            return flag;
        }
      


            return flag;


    }

    
    
    
    private bool    CheckPassword()
    {

        bool returnvalue = false;
        DBAccess db = new DBAccess("CRM");
        string strQuery="";
        if (AgentID != "")
    {
        strQuery = "Select ISNULL(PassExpired,0) FROM dbo.tbl_AgentMaster where LanID='" + AgentID + "'";


    }

        returnvalue = (bool)db.ReturnValue(strQuery, false);
        if (returnvalue == true)
        {

            string str = "";
            str = "$('#DialogBackground').height($(document).height()-10);$('#DialogBackground').width($(window).width());$('#DialogBackground').css('visibility','visible');$('#PanelResetPWD').css('visibility','visible');" + " $('#PanelResetPWD').css('left',($(window).width() - $('#PanelResetPWD').width())/2); ";
            ScriptManager.RegisterStartupScript(Page, Page.GetType(), "Movedialog", str, true);
            returnvalue = true;

        }
        else
        {
            returnvalue = false;
        }



        return returnvalue;


}

#endregion

   
    protected void btnLogin_Click(object sender, EventArgs e)
    {
        PanelError.Visible = false;
        AgentID = txtUserID.Text.Trim();

        if (CheckPassword() == true)
        {




        }
        else
        {
            com.nss.DBAccess.DBAccess.process = "Report";
             com.nss.DBAccess.DBAccess db = new com.nss.DBAccess.DBAccess();
             db.slDataAdd("userid", txtUserID.Text.Trim());
             db.slDataAdd("password", RC4.Encrypt(txtUserID.Text.Trim(), txtPassword.Text.Trim()));
             System.Data.DataRow dr = db.ReturnRow("usp_IsUserValid", true);
             if (dr == null)
             {

                         lblerror.Text = "The username or password you entered is incorrect.";
                         PanelError.Visible = true;
                         return;
             }

             if (this.Session["Text"] != null)
             {
                 if (this.txtimgcode.Text == this.Session["Text"].ToString())
                 {

              Session["Lanid"] = HttpUtility.HtmlEncode(txtUserID.Text.Trim());
             Session["CampaignID"] = dr["campaignid"];
             Session["AgentID"] = dr["AgentID"];
             Session["UserID"] = dr["AgentID"];
             Session["username"] = dr["AgentName"];
             Session["IsVerifier"] = dr["btVerifier"];
             FormsAuthentication.RedirectFromLoginPage(Session["AgentID"].ToString(),false);
                 }

             }

            // '@Captcha Image
            //'If (Me.Session("Text") IsNot Nothing) Then
            //'    ' If (txtimgcode.Text = Session("Text").ToString()) Then

            //'    Session("Lanid") = HttpUtility.HtmlEncode(txtUserID.Text.Trim)
            //'    Session("CampaignID") = dr("campaignid")
            //'    Session("AgentID") = dr("AgentID")
            //'    Session("UserID") = dr("AgentID")
            //'    Session("username") = dr("AgentName")
            //'    Session("IsVerifier") = dr("btVerifier")
            //'    FormsAuthentication.RedirectFromLoginPage(Session("AgentID"), False)
            //'Else

            //'    lblerror.Text = "image code is not valid."
            //'    PanelError.Visible = True
            //'    Return
            //'    'End If
            //'End If

            //'@Without Captcha Image
            //Session("Lanid") = HttpUtility.HtmlEncode(txtUserID.Text.Trim)
            //Session("CampaignID") = dr("campaignid")
            //Session("AgentID") = dr("AgentID")
            //Session("UserID") = dr("AgentID")
            //Session("username") = dr("AgentName")
            //Session("IsVerifier") = dr("btVerifier")
            //FormsAuthentication.RedirectFromLoginPage(Session("AgentID"), False)


            

        }

    }


    protected void LinkButton1_Click(object sender, EventArgs e)
    {

        m_UserId = Request.ServerVariables["LOGON_USER"].ToString().Substring(Request.ServerVariables["LOGON_USER"].ToString().IndexOf("\\",0)+1 );
            //(Request.ServerVariables["LOGON_USER"], IndexOf(Request.ServerVariables["LOGON_USER"], "\") + 1, Len(Request.ServerVariables["LOGON_USER"]));
        OpenDialog();
        tbxWinauthUserID.Text = m_UserId;

    }

    
    private void OpenDialog()
    {
         String str="";
        str = "$('#DialogBackground').height($(document).height()-2);$('#DialogBackground').width($(window).width());$('#DialogBackground').css('visibility','visible');$('#PnlWinAuth').css('visibility','visible'); $('#PnlWinAuth').css('left',($(window).width() - $('#PnlWinAuth').width())/2); ";
        ScriptManager.RegisterStartupScript(Page, Page.GetType(), "Movedialog", str, true);
    }



    private bool AuthorizeThisUser(string strUserID, string strPwd)
    {
        bool returnvalue = false;


        try
        {

            System.DirectoryServices.DirectoryEntry dirEntry = null;
            System.DirectoryServices.DirectorySearcher dirSearcher = null;
            dirEntry = new System.DirectoryServices.DirectoryEntry("LDAP://" + domainName);
            dirEntry.AuthenticationType = AuthenticationTypes.Secure;
            dirEntry.Username = strUserID;
            dirEntry.Password = strPwd;
            dirSearcher = new System.DirectoryServices.DirectorySearcher(dirEntry);

                    if (strUserID != "" )
                        dirSearcher.Filter = "(samAccountName=" + strUserID + ")";

                    

                     SearchResultCollection DirectorySearchCollection = dirSearcher.FindAll();
                    if (DirectorySearchCollection.Count == 0)  //'return false if user isn't found

                        returnvalue = false;

                    else

                        returnvalue = true;

                    

        
        }

        catch (Exception ex)
        {

           // throw ex;
                    lblerror.Text = ex.Message +"The username or password you entered is incorrect for Window AD Authentication";
                    PanelError.Visible = true;
                    returnvalue = false;
                    return returnvalue; 
 

        }
        return returnvalue;

    }

    protected void btnWinAuth_Click(object sender, EventArgs e)
    {

        

        

          com.nss.DBAccess.DBAccess.process = "Report";
             com.nss.DBAccess.DBAccess db = new com.nss.DBAccess.DBAccess();
             db.slDataAdd("userid", txtUserID.Text.Trim());
            
             System.Data.DataRow dr = db.ReturnRow("usp_IsUserValid2", true);
             if (dr == null)
             {

                 lblerror.Text = "The username  is not Existing On Terms.Please Call or Mail for Creation.";
                         PanelError.Visible = true;
                         return;
             }

             if (dr != null)
             {
                  if ((tbxWinauthUserID.Text.Trim() != "") && (tbxwinauthPwd.Text.Trim() != "")) 
                 {

                     if (AuthorizeThisUser(tbxWinauthUserID.Text.Trim(), tbxwinauthPwd.Text.Trim()))
                     {

                         PanelError.Visible = false;
                         lblerror.Text = "";


                         Session["Lanid"] = HttpUtility.HtmlEncode(txtUserID.Text.Trim());
                         Session["CampaignID"] = dr["campaignid"];
                         Session["AgentID"] = dr["AgentID"];
                         Session["UserID"] = dr["AgentID"];
                         Session["username"] = dr["AgentName"];
                         Session["IsVerifier"] = dr["btVerifier"];
                         FormsAuthentication.RedirectFromLoginPage(Session["AgentID"].ToString(), false);
                     }
                     else
                     {

                             
                    lblerror.Text = "The username or password you entered is incorrect for Window AD Authentication";
                    PanelError.Visible = true;
                    
                     }

                  }
             }

    }

    
#region"Utility"
    private void AlertMessage(string msg)
    {
        lblHumanMessage.Text = msg;
        HumanMessage.CssClass = "HMFail";
      //  HumanMessage.Style.Value["visibility"] = "visible";
    
    }


    private void SuccessMessage(string msg)
    {
        lblHumanMessage.Text = msg;
        HumanMessage.CssClass = "HMSuccess";
        //HumanMessage.Style.Keys("visibility") = "visible";
    }
#endregion

    
}