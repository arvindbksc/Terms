﻿Imports com.nss.DBAccess
Imports System.Data
Imports System.Web.UI.DataVisualization.Charting
Imports System.Drawing

Partial Class PerfSum_GordonDashboard
    Inherits System.Web.UI.Page
#Region "--- Properties ---"
    Property CampaignID() As Integer
        Get
            Return ViewState("CampaignID")
        End Get
        Set(ByVal value As Integer)
            ViewState("CampaignID") = value
            Session("CampaignID") = value
        End Set
    End Property
    Property AgentID() As String
        Get
            Return ViewState("AgentID")
        End Get
        Set(ByVal value As String)
            ViewState("AgentID") = value
        End Set
    End Property
    Property ChartPeriod() As Integer
        Get
            Return ViewState("ChartPeriod")
        End Get
        Set(ByVal value As Integer)
            ViewState("ChartPeriod") = value
        End Set
    End Property
    Property ChartGroupBy() As Integer
        Get
            Return ViewState("ChartGroupBy")
        End Get
        Set(ByVal value As Integer)
            ViewState("ChartGroupBy") = value
        End Set
    End Property
    Property Campaigntype() As Integer
        Get
            Return ViewState("Campaigntype")
        End Get
        Set(ByVal value As Integer)
            ViewState("Campaigntype") = value
        End Set
    End Property
    
#End Region
    Dim dtQuality, dtProductivity, dtAbsent, dtFeedback, dtFinalScore_Initial, dtFinalScore_Final As DataTable
    Dim dtAgent_FinalScore As DataTable = Nothing
    Dim dtnew As DataTable

    Dim dtConsolidate As DataTable

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            If Session("agentid") Is Nothing Then
                FormsAuthentication.SignOut()
            End If
            'Session("AgentID") = "NSS51102"
            If Session("AgentID") <> "" Then
                BindGroupByMembers()
                CampaignID = Session("CampaignID")
                AgentID = Session("AgentID")
                LoadData()
                DrawChart()
                UcDateTo.Visible = False
                ucDateFrom.Visible = False
                lblAnd.Visible = False
                PanelReports.Controls.Add(Common.GetMenu(Request.Url, AgentID, Request.ApplicationPath))
            End If
        End If
    End Sub

#Region "--- Functions ---"
    Private Sub LoadData()
        FillCommonFilters()
    End Sub
    Private Sub FillCommonFilters()
        Dim db As New DBAccess
        Dim dt As DataTable = db.ReturnTable("select * from tbl_Reports_DatePeriods")
        db = Nothing
        Dim dr As DataRow = dt.NewRow
        dr(0) = 10
        dr(1) = "Between"
        dt.Rows.Add(dr)
        CboPeriod.DataTextField = "Caption"
        CboPeriod.DataValueField = "Period"
        CboPeriod.DataSource = dt
        CboPeriod.DataBind()

        db = New DBAccess
        dt = db.ReturnTable("Select * from tbl_Reports_GroupBy")
        db = Nothing
    End Sub

    Private Function IntegerToDateString(ByVal d As Integer) As String
        Return d.ToString.Substring(0, 4) & "-" & d.ToString.Substring(4, 2) & "-" & d.ToString.Substring(6, 2)
    End Function

    Private Sub FillData()
        ' CreateDataTableColumn()
        Dim db As New DBAccess
        Dim startday As Integer, endday As Integer
        Dim sdate, edate As DateTime
        If CboPeriod.SelectedValue = 10 Then
            startday = ucDateFrom.yyyymmdd
            endday = UcDateTo.yyyymmdd
            sdate = ucDateFrom.value
            edate = UcDateTo.value
            ChartPeriod = DateDiff(DateInterval.Day, sdate, edate)
        Else
            db = New DBAccess
            db.slDataAdd("Period", CboPeriod.SelectedValue)
            db.slDataAdd("Campaignid", CampaignID)
            Dim dr As DataRow = db.ReturnRow("usp_GetStart_EndDateForAPeriod", True)
            db = Nothing
            startday = dr(0)
            endday = dr(1)
            sdate = IntegerToDateString(startday)
            edate = IntegerToDateString(endday)
            ChartPeriod = DateDiff(DateInterval.Day, sdate, edate)
        End If
        db = Nothing
        '----------------- Quality
        db = New DBAccess
        db.slDataAdd("DateFrom", startday)
        db.slDataAdd("DateTo", endday)
        db.slDataAdd("campaignid", 281)
        db.slDataAdd("graphType", "quality")
        db.slDataAdd("monthORquarter", cboGroupBYPeriod.SelectedValue)
        db.slDataAdd("groupByCriteria", cboGroupBYCriteria.SelectedValue)
        db.slDataAdd("groupBymembers", cboGroupMembers.SelectedValue)
        dtQuality = db.ReturnTable("usp_Graph_Morris_Data", "Quality", True)
        db = Nothing
        '--------------------------------------------------
        '------------------------------productivity
        db = New DBAccess
        db.slDataAdd("DateFrom", startday)
        db.slDataAdd("DateTo", endday)
        db.slDataAdd("campaignid", 281)
        'db.slDataAdd("groupby", 3)
        'db.slDataAdd("groupby", 1) 'for Agent
        db.slDataAdd("graphType", "productivity")
        db.slDataAdd("monthORquarter", cboGroupBYPeriod.SelectedValue)
        db.slDataAdd("groupByCriteria", cboGroupBYCriteria.SelectedValue)
        db.slDataAdd("groupBymembers", cboGroupMembers.SelectedValue)

        dtProductivity = db.ReturnTable("usp_Graph_Morris_Data", "Productivity", True)
        db = Nothing

        '----------------- Absenteeism
        db = New DBAccess
        db.slDataAdd("DateFrom", startday)
        db.slDataAdd("DateTo", endday)
        db.slDataAdd("campaignid", 281)
        db.slDataAdd("graphType", "attendance")
        db.slDataAdd("monthORquarter", cboGroupBYPeriod.SelectedValue)
        db.slDataAdd("groupByCriteria", cboGroupBYCriteria.SelectedValue)
        db.slDataAdd("groupBymembers", cboGroupMembers.SelectedValue)
        'db.slDataAdd("groupByCriteria", 1)
        'db.slDataAdd("groupBymembers", "NSS55812")
        dtAbsent = db.ReturnTable("usp_Graph_Morris_Data", "Absent", True)
        db = Nothing

        '-----------------------Feedback
        db = New DBAccess
        db.slDataAdd("DateFrom", startday)
        db.slDataAdd("DateTo", endday)
        db.slDataAdd("campaignid", 281)
        db.slDataAdd("graphType", "feedbackinitiative")
        db.slDataAdd("monthORquarter", cboGroupBYPeriod.SelectedValue)
        db.slDataAdd("groupByCriteria", CboGroupByCriteria.SelectedValue)
        db.slDataAdd("groupBymembers", cboGroupMembers.SelectedValue)
        dtFeedback = db.ReturnTable("usp_Graph_Morris_Data", "Feedback", True)
        db = Nothing
        '----------------------Final Score
        db = New DBAccess
        db.slDataAdd("startday", startday)
        db.slDataAdd("endday", endday)
        db.slDataAdd("campaignid", 281)
        'db.slDataAdd("graphType", "feedbackinitiative")
        db.slDataAdd("monthORquarter", cboGroupBYPeriod.SelectedValue)
        ' db.slDataAdd("groupByCriteria", CboGroupByCriteria.SelectedValue)
        db.slDataAdd("groupBymembers", cboGroupMembers.SelectedValue)
        dtFinalScore_Initial = db.ReturnTable("usp_Morris_ScoreCard_Data_MQ", "FinalScore_Initial", True)
        db = Nothing
        FillFinalScore()

        '---------------------------to fill Gridview below graph
        FillConsolidatedTable()
        '------------------------------------------
        gvData.DataSource = dtnew
        gvData.Databind()


    End Sub

    Private Sub FillFinalScore()
        ' Dim Attendance As Integer

        If dtFinalScore_Initial.Rows.Count > 0 Then
            For Each row As DataRow In dtFinalScore_Initial.Rows
                row("TotalErrors") = IIf(IsDBNull(row("Errors(Int)")), 0, row("Errors(Int)")) + IIf(IsDBNull(row("Errors(Ext)")), 0, row("Errors(Ext)"))
                '------------
                If IIf(IsDBNull(row("CallMonitored")), 0, row("CallMonitored")) = 0 Then
                    row("Quality %") = 0
                Else
                    row("Quality %") = (row("CallMonitored") - row("TotalErrors")) / row("CallMonitored") * 100.0
                End If
                '-----------------
                'If row("AttendanceStatus") = "P" Then
                '    Attendance = 1
                'ElseIf row("AttendanceStatus") = "HD" Or row("AttendanceStatus") = "HDLWP" Then
                '    Attendance = 0.5
                'Else
                '    Attendance = 0
                'End If

                row("TotalScore") = IIf(IsDBNull(row("AttendanceStatus_Score")), 0, row("AttendanceStatus_Score")) * 0.1 + IIf(IsDBNull(row("TotalAds")), 0, row("TotalAds")) * 0.5 + IIf(IsDBNull(row("Quality %")), 0, row("Quality %")) * 0.3 + IIf(IsDBNull(row("InitiativePoints")), 0, row("InitiativePoints")) * 0.1
            Next
        End If

        dtFinalScore_Initial.Columns.Remove("NonFatalQCount")
        dtFinalScore_Initial.Columns.Remove("NonFatalErrorCount")
        dtFinalScore_Initial.Columns.Remove("CallMonitored")

        If dtFinalScore_Initial.Select("AgentID='" & cboGroupMembers.SelectedValue & "'").Length > 0 Then
            dtAgent_FinalScore = dtFinalScore_Initial.Select("AgentID='" & cboGroupMembers.SelectedValue & "'").CopyToDataTable
        End If

       
        Dim dtAll As DataTable
        Dim dtSelect As DataTable
        Dim index As Integer = 0

        If Not dtAgent_FinalScore Is Nothing Then
            If dtAgent_FinalScore.Rows.Count > 0 Then
                For Each row As DataRow In dtAgent_FinalScore.Rows
                    'dtAll = dt.Select("Date='" & row("Date") & "'" & " AND AgentID<>'" & row("AgentID") & "'").CopyToDataTable()
                    dtAll = dtFinalScore_Initial.Select("groupname='" & row("groupname") & "'").CopyToDataTable()
                    'countAgents = dtAll.Rows.Count

                    If dtAll.Select("TotalScore >" & row("TotalScore")).Length > 0 Then
                        dtSelect = dtAll.Select("TotalScore >" & row("TotalScore")).CopyToDataTable()
                        row("CurrentRank") = dtSelect.Rows.Count + 1
                    ElseIf dtAll.Select("TotalScore =" & row("TotalScore")).Length > 0 Then
                        row("CurrentRank") = 1
                    End If
                Next
            End If
        End If

    End Sub

    Private Sub FillConsolidatedTable()

        If dtProductivity.Rows.Count > 0 Then  'atleast dtProductivity will have data, if it have data
            dtnew = New DataTable

            dtConsolidate = dtProductivity.Copy 'dtConsolidate will have dtProductivity data already

            'Dim colagentid As DataColumn = New DataColumn("agentid", GetType(System.String))
            'Dim colgroupname As DataColumn = New DataColumn("groupname", GetType(System.String))
            'Dim colachieved As DataColumn = New DataColumn("achieved", GetType(System.String))
            'Dim coltargetset As DataColumn = New DataColumn("targetset", GetType(System.String))

            Dim colfar As DataColumn = New DataColumn("far", GetType(System.String))
            Dim coltargetQuality As DataColumn = New DataColumn("targetQuality", GetType(System.String))

            Dim colfeedback As DataColumn = New DataColumn("feedback", GetType(System.String))

            Dim colabsenteeism As DataColumn = New DataColumn("absenteeism", GetType(System.String))
            Dim colleaves As DataColumn = New DataColumn("leaves", GetType(System.String))

            Dim colfinalscore As DataColumn = New DataColumn("finalscore", GetType(System.String))
            Dim colranking As DataColumn = New DataColumn("ranking", GetType(System.String))
            '-----------------------
            'dtConsolidate.Columns.Add(colagentid)
            'dtConsolidate.Columns.Add(colgroupname)
            'dtConsolidate.Columns.Add(colachieved)
            'dtConsolidate.Columns.Add(coltargetset)

            dtConsolidate.Columns.Add(colfar)
            dtConsolidate.Columns.Add(coltargetQuality)

            dtConsolidate.Columns.Add(colfeedback)

            dtConsolidate.Columns.Add(colabsenteeism)
            dtConsolidate.Columns.Add(colleaves)

            dtConsolidate.Columns.Add(colfinalscore)
            dtConsolidate.Columns.Add(colranking)

            Dim index As Integer = 0
            For Each row As DataRow In dtProductivity.Rows 'dt1 has distinct Month name

                Dim rowQua() As DataRow = dtQuality.Select("groupname='" & row("groupname") & "'")
                If rowQua.Length > 0 Then
                    dtConsolidate.Rows(index).Item("far") = rowQua(0).Item("FAR%") 'to set for the first row in data row array of quality
                    dtConsolidate.Rows(index).Item("targetQuality") = rowQua(0).Item("Target%")
                End If

                Dim rowAbs() As DataRow = dtAbsent.Select("groupname='" & row("groupname") & "'")
                If rowAbs.Length > 0 Then
                    dtConsolidate.Rows(index).Item("absenteeism") = rowAbs(0).Item("achieved") 'to set for the first row in data row array of quality
                    dtConsolidate.Rows(index).Item("leaves") = rowAbs(0).Item("achieved2")
                End If

                Dim rowFeedback() As DataRow = dtFeedback.Select("groupname='" & row("groupname") & "'")
                If rowFeedback.Length > 0 Then
                    dtConsolidate.Rows(index).Item("feedback") = rowFeedback(0).Item("achieved") 'to set for the first row in data row array of quality
                End If


                If Not dtAgent_FinalScore Is Nothing Then
                    If dtAgent_FinalScore.Rows.Count > 0 Then
                        Dim row_Score_rank() As DataRow = dtAgent_FinalScore.Select("groupname='" & row("groupname") & "'")
                        If row_Score_rank.Length > 0 Then
                            dtConsolidate.Rows(index).Item("finalscore") = row_Score_rank(0).Item("totalscore") 'to set for the first row in data row array of quality
                            dtConsolidate.Rows(index).Item("ranking") = row_Score_rank(0).Item("currentrank")
                        End If
                    End If
                End If
                index += 1
            Next
        End If

        If Not dtConsolidate Is Nothing Then
            If dtConsolidate.Rows.Count > 0 Then
                ' dtConsolidate.Columns.Remove("agentid")
                dtConsolidate.Columns.Remove("SourceColumn")
                dtConsolidate.Columns.Remove("groupname2")
                dtConsolidate.Columns.Remove("col2")
                dtConsolidate.Columns.Remove("sortingby")

                dtConsolidate.Columns("groupname").ColumnName = "PARAMETERS"
                dtConsolidate.Columns("far").ColumnName = "Quality Accept%"
                dtConsolidate.Columns("targetquality").ColumnName = "Target%"
                dtConsolidate.Columns("achieved").ColumnName = "Productivity"
                dtConsolidate.Columns("absenteeism").ColumnName = "absenteeism%"

                'To change the column sequence of "Total Ads" and "TargetSet",so after transpose "Quality%" comes first.
                dtConsolidate.Columns("TargetSet").SetOrdinal(4)
                dtConsolidate.Columns("Productivity").SetOrdinal(3)


                For Each col As DataColumn In dtConsolidate.Columns
                    col.ColumnName = col.ColumnName.ToUpper
                Next

                'To create new columns

                For i As Integer = 0 To dtConsolidate.Rows.Count - 1
                    'check if the column already exists or Not
                    If Not dtnew.Columns.Contains(dtConsolidate.Rows(i)(0)) Then
                        dtnew.Columns.Add(dtConsolidate.Rows(i)(0), GetType(System.String))
                    End If
                Next


                'To create new Row
                For i As Integer = 0 To dtConsolidate.Columns.Count - 1
                    Dim dr As DataRow = dtnew.NewRow
                    dtnew.Rows.Add(dr)
                Next

                'To transpose
                For i As Integer = 0 To dtConsolidate.Rows.Count - 1
                    For j As Integer = 0 To dtConsolidate.Columns.Count - 1
                        dtnew.Rows(j).Item(i) = dtConsolidate.Rows(i).Item(j).ToString
                    Next
                Next

                If dtnew.Rows.Count > 0 Then
                    dtnew.Rows.RemoveAt(0)
                End If

                Dim colParam As DataColumn = New DataColumn("PARAMETERS", GetType(System.String))
                dtnew.Columns.Add(colParam)
                For m As Integer = 0 To dtnew.Rows.Count - 1
                    dtnew.Rows(m).Item("PARAMETERS") = dtConsolidate.Columns(m + 1).ColumnName
                Next
                dtnew.Columns("PARAMETERS").SetOrdinal(0)

                Dim colTotal As DataColumn = New DataColumn("TOTAL", GetType(System.String))
                dtnew.Columns.Add(colTotal)

                Dim colFinalStatus As DataColumn = New DataColumn("FINAL STATUS", GetType(System.String))
                dtnew.Columns.Add(colFinalStatus)

                Dim Index As Integer
                Dim isAvg As Boolean
                Dim total As Double
                Dim isRANKINGColumn As Boolean

                If dtnew.Rows.Count > 0 Then
                    For Each row As DataRow In dtnew.Rows
                        Index = 0
                        isAvg = False
                        total = 0
                        isRANKINGColumn = False
                        For j As Integer = 0 To dtnew.Columns.Count - 1
                            If dtnew.Columns(j).ColumnName <> "PARAMETERS" And dtnew.Columns(j).ColumnName <> "TOTAL" And dtnew.Columns(j).ColumnName <> "FINAL STATUS" Then
                                If row("PARAMETERS") = "QUALITY ACCEPT%" Then
                                    total += IIf(row(j) = "", 0, row(j))
                                    isAvg = True
                                    'Avg
                                ElseIf row("PARAMETERS") = "TARGET%" Then
                                    total += IIf(row(j) = "", 0, row(j))
                                    isAvg = True
                                    'Avg
                                ElseIf row("PARAMETERS") = "PRODUCTIVITY" Then
                                    total += IIf(row(j) = "", 0, row(j))
                                    isAvg = True
                                    'Avg
                                ElseIf row("PARAMETERS") = "TARGETSET" Then
                                    total += IIf(row(j) = "", 0, row(j))
                                    isAvg = True
                                    'Avg
                                ElseIf row("PARAMETERS") = "FEEDBACK%" Then
                                    total += IIf(row(j) = "", 0, row(j))
                                ElseIf row("PARAMETERS") = "FINALSCORE" Then
                                    total += IIf(row(j) = "", 0, row(j))
                                ElseIf row("PARAMETERS") = "RANKING" Then
                                    total += IIf(row(j) = "", 0, row(j))
                                    isAvg = True
                                    isRANKINGColumn = True
                                    'Avg
                                ElseIf row("PARAMETERS") = "ABSENTEEISM%" Then
                                    total += IIf(row(j) = "", 0, row(j))
                                    isAvg = True
                                    'Avg
                                ElseIf row("PARAMETERS") = "LEAVES" Then
                                    total += IIf(row(j) = "", 0, row(j))
                                End If
                                Index += 1
                            End If
                        Next


                        If isAvg = True Then
                            row("TOTAL") = Math.Round(total / Index, 2)
                        Else
                            row("TOTAL") = Math.Round(total, 2)
                        End If

                        If isRANKINGColumn Then
                            row("TOTAL") = Math.Round(total / Index, 0)
                        End If

                    Next
                End If

            End If
        End If

    End Sub

#End Region
#Region "--- Draw Graph ---"
    Private Sub DrawChart()
        If cboGroupMembers.SelectedItem.Text <> "--Select--" Then
            FillData()
            If Not dtQuality.Rows.Count < 0 Then
                RenderGraph()
            End If
        End If
    End Sub

    ' Private Sub RenderGraph(ByVal charts As Chart, ByVal yValueMem As String,ByVal Title As String )
    Private Sub RenderGraph()
        Dim xValueMem As String = ""
        Dim Title As String = ""
        ' If charts.ID = "Chart1" Then
        With Chart1
            .ChartAreas(0).AxisX.IntervalAutoMode = DataVisualization.Charting.IntervalAutoMode.FixedCount
            .TextAntiAliasingQuality = DataVisualization.Charting.TextAntiAliasingQuality.High
            Title = "Quality Acceptance"
            .Titles.Add(Title)
            .Series.Clear()
            .Series.Add("Target")
            .Series.Add("Data Count")

            With .Series(0)
                .XValueMember = "groupname"
                .YValueMembers = "Target%"
                .LabelFormat = "{0:n}"

                .ChartType = DataVisualization.Charting.SeriesChartType.Line
                .BorderWidth = 2
                .Color = Drawing.Color.Red
                .IsValueShownAsLabel = True

                .MarkerStyle = DataVisualization.Charting.MarkerStyle.Diamond
                .MarkerSize = 6
                .MarkerColor = Drawing.Color.Yellow

            End With
            With .Series(1)
                .XValueMember = "groupname"
                .YValueMembers = "FAR%"

                .ChartType = DataVisualization.Charting.SeriesChartType.Line
                .BorderWidth = 2
                .Color = Drawing.Color.Blue
                .MarkerStyle = DataVisualization.Charting.MarkerStyle.Diamond
                .MarkerSize = 6
                .MarkerColor = Drawing.Color.Yellow
                .IsValueShownAsLabel = True
            End With
            .ChartAreas(0).AxisX.MajorGrid.Enabled = False
            .ChartAreas(0).AxisY.MajorGrid.Enabled = False
            .ChartAreas(0).AxisX.Interval = 1
            .ChartAreas(0).AxisX2.Interval = 1
            .ChartAreas(0).AxisX.IntervalAutoMode = DataVisualization.Charting.IntervalAutoMode.FixedCount
            .ChartAreas(0).AxisX2.IntervalAutoMode = DataVisualization.Charting.IntervalAutoMode.FixedCount
            .ChartAreas(0).AxisY2.MajorGrid.Enabled = True
            .ChartAreas(0).AxisY.Minimum = 80
            .ChartAreas(0).AxisY.Title = "Quality Score"
            ' .DataSource = dtBuildingOffice.DefaultView
            .DataSource = dtQuality.DefaultView
            .DataBind()
        End With
        ' End If
        '-------------------------------------
        '  If charts.ID = "Chart2" Then
        With Chart2
            .ChartAreas(0).AxisX.IntervalAutoMode = DataVisualization.Charting.IntervalAutoMode.FixedCount
            .TextAntiAliasingQuality = DataVisualization.Charting.TextAntiAliasingQuality.High
            Title = "Productivity"
            .Titles.Add(Title)
            .Series.Clear()
            .Series.Add("Target")
            .Series.Add("Data Count")
            With .Series(0)
                .XValueMember = "Groupname"
                .YValueMembers = "Achieved"
                '.LabelFormat = "{0:n}"

                .ChartType = DataVisualization.Charting.SeriesChartType.Column
                .BorderWidth = 4
                .Color = Drawing.Color.Blue
                .BackGradientStyle = DataVisualization.Charting.GradientStyle.VerticalCenter
                .BackSecondaryColor = Drawing.Color.SkyBlue
                .IsValueShownAsLabel = True
            End With
            With .Series(1)
                .XValueMember = "Groupname"
                .YValueMembers = "TargetSet"

                .ChartType = DataVisualization.Charting.SeriesChartType.Line
                .BorderWidth = 2
                .Color = Drawing.Color.Red
                .MarkerStyle = DataVisualization.Charting.MarkerStyle.Diamond
                .MarkerSize = 6
                .MarkerColor = Drawing.Color.Yellow
                .IsValueShownAsLabel = True
            End With
            .ChartAreas(0).AxisX.MajorGrid.Enabled = False
            .ChartAreas(0).AxisY.MajorGrid.Enabled = False
            .ChartAreas(0).AxisX.Interval = 1
            .ChartAreas(0).AxisX2.Interval = 1
            .ChartAreas(0).AxisX.IntervalAutoMode = DataVisualization.Charting.IntervalAutoMode.FixedCount
            .ChartAreas(0).AxisX2.IntervalAutoMode = DataVisualization.Charting.IntervalAutoMode.FixedCount
            .ChartAreas(0).AxisY2.MajorGrid.Enabled = False
            .ChartAreas(0).AxisY.Title = "No. of Ads"
            ' mypane = .Series(0)
            '.ChartAreas(0).AxisY.Minimum = 80
            .DataSource = dtProductivity.DefaultView
            .DataBind()
        End With
        'End If
        '---------------------------------------------------------------
        With ChartFeedback
            .ChartAreas(0).AxisX.IntervalAutoMode = DataVisualization.Charting.IntervalAutoMode.FixedCount
            .TextAntiAliasingQuality = DataVisualization.Charting.TextAntiAliasingQuality.High
            Title = "Feedback"
            .Titles.Add(Title)
            .Series.Clear()
            .Series.Add("Target")
            .Series.Add("Data Count")

            With .Series(0)
                .XValueMember = "groupname"
                .YValueMembers = "Achieved"
                '.LabelFormat = "{0:n}"

                .ChartType = DataVisualization.Charting.SeriesChartType.Line
                .BorderWidth = 2
                .Color = Drawing.Color.Red
                .IsValueShownAsLabel = True

                .MarkerStyle = DataVisualization.Charting.MarkerStyle.Diamond
                .MarkerSize = 6
                .MarkerColor = Drawing.Color.Yellow

            End With
            .ChartAreas(0).AxisX.MajorGrid.Enabled = False
            .ChartAreas(0).AxisY.MajorGrid.Enabled = False
            .ChartAreas(0).AxisX.Interval = 1
            .ChartAreas(0).AxisX2.Interval = 1
            .ChartAreas(0).AxisX.IntervalAutoMode = DataVisualization.Charting.IntervalAutoMode.FixedCount
            .ChartAreas(0).AxisX2.IntervalAutoMode = DataVisualization.Charting.IntervalAutoMode.FixedCount
            .ChartAreas(0).AxisY2.MajorGrid.Enabled = True
            .ChartAreas(0).AxisY.Minimum = 0
            .ChartAreas(0).AxisY.Title = "No. of Feedback"
            .DataSource = dtFeedback.DefaultView
            .DataBind()
        End With
        '-------------------------------------
        '-----------------------------------

        With Chart6
            .ChartAreas(0).AxisX.IntervalAutoMode = DataVisualization.Charting.IntervalAutoMode.FixedCount
            .TextAntiAliasingQuality = DataVisualization.Charting.TextAntiAliasingQuality.High
            ' mypane = .Series(0)
            Title = "Absenteeism Rate/Leaves"
            .Titles.Add(Title)
            .Series.Clear()
            .Series.Add("Achieved")
            .Series.Add("Achieved2")
            xValueMem = "Groupname"
            With .Series(0)
                .XValueMember = xValueMem
                .YValueMembers = "Achieved"
                .ChartType = DataVisualization.Charting.SeriesChartType.Spline
                .BorderWidth = 3
                .Color = Drawing.Color.Blue
                .IsValueShownAsLabel = True
                ' .LabelFormat = "{0:n}"

                .MarkerStyle = DataVisualization.Charting.MarkerStyle.Diamond
                .MarkerSize = 6
                .MarkerColor = Drawing.Color.Yellow
                .YAxisType = AxisType.Secondary

            End With
            With .Series(1)
                .XValueMember = "Groupname"
                .YValueMembers = "Achieved2"

                .ChartType = DataVisualization.Charting.SeriesChartType.Spline
                .BorderWidth = 3
                .Color = Drawing.Color.Red
                .MarkerStyle = DataVisualization.Charting.MarkerStyle.Diamond
                .MarkerSize = 6
                .MarkerColor = Drawing.Color.Yellow
                .IsValueShownAsLabel = True
                .YAxisType = AxisType.Primary
            End With

            .ChartAreas(0).AxisX.MajorGrid.Enabled = False
            .ChartAreas(0).AxisY.MajorGrid.Enabled = False
            .ChartAreas(0).AxisY.Title = "No. of Leaves"
            .ChartAreas(0).AxisY2.Title = "Absenteeism Rate"

            .DataSource = dtAbsent.DefaultView
            .DataBind()
        End With
        '---------------------------

        With ChartTotalScore
            .ChartAreas(0).AxisX.IntervalAutoMode = DataVisualization.Charting.IntervalAutoMode.FixedCount
            .TextAntiAliasingQuality = DataVisualization.Charting.TextAntiAliasingQuality.High
            Title = "Total Score"
            .Titles.Add(Title)
            .Series.Clear()
            .Series.Add("Target")
            .Series.Add("Data Count")
            With .Series(0)
                .XValueMember = "Groupname"
                .YValueMembers = "TotalScore"
                ' .LabelFormat = "{0:n}"

                .ChartType = DataVisualization.Charting.SeriesChartType.Column
                .BorderWidth = 4
                .Color = Drawing.Color.Blue
                .BackGradientStyle = DataVisualization.Charting.GradientStyle.VerticalCenter
                .BackSecondaryColor = Drawing.Color.SkyBlue
                .IsValueShownAsLabel = True
            End With
            'With .Series(1)
            '    .XValueMember = "Groupname"
            '    .YValueMembers = "Target"

            '    .ChartType = DataVisualization.Charting.SeriesChartType.Line
            '    .BorderWidth = 2
            '    .Color = Drawing.Color.Red
            '    .MarkerStyle = DataVisualization.Charting.MarkerStyle.Diamond
            '    .MarkerSize = 6
            '    .MarkerColor = Drawing.Color.Yellow
            '    .IsValueShownAsLabel = True
            'End With
            .ChartAreas(0).AxisX.MajorGrid.Enabled = False
            .ChartAreas(0).AxisY.MajorGrid.Enabled = False
            .ChartAreas(0).AxisY.Title = "No. of Score"
            .ChartAreas(0).AxisX.Interval = 1
            .ChartAreas(0).AxisX2.Interval = 1
            .ChartAreas(0).AxisX.IntervalAutoMode = DataVisualization.Charting.IntervalAutoMode.FixedCount
            .ChartAreas(0).AxisX2.IntervalAutoMode = DataVisualization.Charting.IntervalAutoMode.FixedCount
            .ChartAreas(0).AxisY2.MajorGrid.Enabled = False
            ' mypane = .Series(0)
            '.ChartAreas(0).AxisY.Minimum = 80
            If Not dtAgent_FinalScore Is Nothing Then
                .DataSource = dtAgent_FinalScore.DefaultView
                .DataBind()
            Else
                .DataSource = Nothing
                .DataBind()
            End If

        End With
        'End If
        '-----------------------------------

        With ChartRanking
            .ChartAreas(0).AxisX.IntervalAutoMode = DataVisualization.Charting.IntervalAutoMode.FixedCount
            .TextAntiAliasingQuality = DataVisualization.Charting.TextAntiAliasingQuality.High
            Title = "Ranking"
            .Titles.Add(Title)
            .Series.Clear()
            .Series.Add("Target")
            .Series.Add("Data Count")
            With .Series(0)
                .XValueMember = "Groupname"
                .YValueMembers = "CurrentRank"
                ' .LabelFormat = "{0:n}"

                .ChartType = DataVisualization.Charting.SeriesChartType.Column
                .BorderWidth = 4
                .Color = Drawing.Color.Blue
                .BackGradientStyle = DataVisualization.Charting.GradientStyle.VerticalCenter
                .BackSecondaryColor = Drawing.Color.SkyBlue
                .IsValueShownAsLabel = True
            End With
            'With .Series(1)
            '    .XValueMember = "Groupname"
            '    .YValueMembers = "Target"

            '    .ChartType = DataVisualization.Charting.SeriesChartType.Line
            '    .BorderWidth = 2
            '    .Color = Drawing.Color.Red
            '    .MarkerStyle = DataVisualization.Charting.MarkerStyle.Diamond
            '    .MarkerSize = 6
            '    .MarkerColor = Drawing.Color.Yellow
            '    .IsValueShownAsLabel = True
            'End With
            .ChartAreas(0).AxisX.MajorGrid.Enabled = False
            .ChartAreas(0).AxisY.MajorGrid.Enabled = False
            .ChartAreas(0).AxisY.Title = "Rank"

            .ChartAreas(0).AxisX.Interval = 1
            .ChartAreas(0).AxisX2.Interval = 1
            .ChartAreas(0).AxisX.IntervalAutoMode = DataVisualization.Charting.IntervalAutoMode.FixedCount
            .ChartAreas(0).AxisX2.IntervalAutoMode = DataVisualization.Charting.IntervalAutoMode.FixedCount
            .ChartAreas(0).AxisY2.MajorGrid.Enabled = False
            ' mypane = .Series(0)
            '.ChartAreas(0).AxisY.Minimum = 80
            If Not dtAgent_FinalScore Is Nothing Then
                .DataSource = dtAgent_FinalScore.DefaultView
                .DataBind()
            Else
                .DataSource = Nothing
                .DataBind()
            End If

        End With
        'End If
        '-----------------------------------
    End Sub

    Private Sub BindGroupByMembers()
        Dim db As DBAccess
        Dim dtSearch As DataTable
        '------------------------------productivity
        db = New DBAccess
        'db.slDataAdd("DateFrom", "")
        'db.slDataAdd("DateTo", "")
        db.slDataAdd("campaignid", 281)
        ' db.slDataAdd("groupby", 3)
        db.slDataAdd("graphType", "search")
        If Not IsPostBack Then
            db.slDataAdd("groupByCriteria", 3) 'for Campaign
        Else
            db.slDataAdd("groupByCriteria", CboGroupByCriteria.SelectedValue)
        End If

        ' dtAllData = db.ReturnTable("usp_Gordon_BuildingTypeData", , True)
        dtSearch = db.ReturnTable("usp_Graph_Morris_Data", , True)
        db = Nothing

        If dtSearch.Rows.Count > 0 Then
            Dim row As DataRow = dtSearch.NewRow
            row.Item(0) = -1
            row.Item(1) = "--Select--"
            dtSearch.Rows.InsertAt(row, 0)
            cboGroupMembers.Items.Clear()

            cboGroupMembers.DataValueField = "Id"
            cboGroupMembers.DataTextField = "Name"
            cboGroupMembers.DataSource = dtSearch
            cboGroupMembers.DataBind()
        Else
            cboGroupMembers.DataSource = Nothing
            cboGroupMembers.DataBind()
        End If
    End Sub
#End Region

#Region "--- Events ---"
    Protected Sub ImageButton1_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton1.Click
        DrawChart()
    End Sub
    Protected Sub CboPeriod_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles CboPeriod.SelectedIndexChanged
        If CboPeriod.SelectedValue = 10 Then
            ucDateFrom.Visible = True
            UcDateTo.Visible = True
            lblAnd.Visible = True
            ChartPeriod = ucDateFrom.yyyymmdd - UcDateTo.yyyymmdd
            DrawChart()
        Else
            ucDateFrom.Visible = False
            UcDateTo.Visible = False
            lblAnd.Visible = False
            DrawChart()
        End If
    End Sub

    Protected Sub ucDateFrom_Changed(ByVal sender As Object, ByVal e As System.EventArgs) Handles ucDateFrom.Changed
        ' DrawChart()
    End Sub

    Protected Sub UcDateTo_Changed(ByVal sender As Object, ByVal e As System.EventArgs) Handles UcDateTo.Changed
        ' DrawChart()
    End Sub

    Protected Sub CCboGroupByCriteria_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles CboGroupByCriteria.SelectedIndexChanged
        BindGroupByMembers()
        '  DrawChart()
    End Sub

    Protected Sub cboGroupMembers_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboGroupMembers.SelectedIndexChanged
        DrawChart()
    End Sub

    Protected Sub cboGroupBYPeriod_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboGroupBYPeriod.SelectedIndexChanged
        If cboGroupMembers.SelectedItem.Text <> "--Select--" Then
            DrawChart()
        End If

    End Sub

    Protected Sub gvData_RowDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles gvData.RowDataBound
        If e.Row.RowType = DataControlRowType.DataRow Then
            If e.Row.Cells(0).Text = "QUALITY ACCEPT%" Or e.Row.Cells(0).Text = "PRODUCTIVITY" Then
                Dim chk As New System.Web.UI.WebControls.Image
                chk.ID = "chkb"
                Dim dr As DataRowView = DirectCast(e.Row.DataItem, DataRowView)

                If e.Row.Cells(e.Row.Cells.Count - 2).Text > dtnew.Rows(e.Row.RowIndex + 1).Item("TOTAL") Then
                    chk.ImageUrl = "..\_assets\img\up.gif"
                ElseIf e.Row.Cells(e.Row.Cells.Count - 2).Text < dtnew.Rows(e.Row.RowIndex + 1).Item("TOTAL") Then
                    chk.ImageUrl = "..\_assets\img\down2.gif"
                Else
                    chk.ImageUrl = "..\_assets\img\bg.gif"
                End If

                e.Row.Cells(e.Row.Cells.Count - 1).Controls.Add(chk)

            End If
        End If

    End Sub
#End Region

End Class
