﻿Imports com.nss.DBAccess
Imports System.Data
Imports System.Web.UI.DataVisualization.Charting
Imports System.Drawing
Partial Class PerfSum_Utilization
    Inherits System.Web.UI.Page

#Region "--- Properties ---"
    Property CampaignID() As Integer
        Get
            Return ViewState("CampaignID")
        End Get
        Set(ByVal value As Integer)
            ViewState("CampaignID") = value
            Session("CampaignID") = value
        End Set
    End Property
    Property AgentID() As String
        Get
            Return ViewState("AgentID")
        End Get
        Set(ByVal value As String)
            ViewState("AgentID") = value
        End Set
    End Property
    Property ChartPeriod() As Integer
        Get
            Return ViewState("ChartPeriod")
        End Get
        Set(ByVal value As Integer)
            ViewState("ChartPeriod") = value
        End Set
    End Property
    Property GroupBy() As Integer
        Get
            Return ViewState("GroupBy")
        End Get
        Set(ByVal value As Integer)
            ViewState("GroupBy") = value
        End Set
    End Property
    Property Campaigntype() As Integer
        Get
            Return ViewState("Campaigntype")
        End Get
        Set(ByVal value As Integer)
            ViewState("Campaigntype") = value
        End Set
    End Property

#End Region
    Dim dt As DataTable
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            If Session("agentid") Is Nothing Then
                FormsAuthentication.SignOut()
            End If
            If Session("AgentID") <> "" Then
                CampaignID = Session("CampaignID")
                AgentID = Session("AgentID")
                LoadData()
                DrawChart()
                UcDateTo.Visible = False
                ucDateFrom.Visible = False
                lblAnd.Visible = False
            End If
        End If
    End Sub
#Region "--- Functions ---"
    Private Sub LoadData()
        FillCommonFilters()
        FillProcessCampaigns()
        CboPeriod.SelectedValue = 3
    End Sub
    Private Sub FillProcessCampaigns()
        Common.FillProcessCampaigns(CboProcess, cboCampaigns, AgentID, CampaignID)
        cboCampaigns.SelectedValue = 290
        'Dim db As New DBAccess("CRM")
        'dt = db.ReturnTable("select * from tbl_Config_Campaigns where processid=103", False)
        'db = Nothing
        'cboCampaigns.DataTextField = "Name"
        'cboCampaigns.DataValueField = "CampaignID"
        'cboCampaigns.DataSource = dt
        'cboCampaigns.DataBind()
    End Sub
    Private Sub FillCommonFilters()
        Dim db As New DBAccess
        Dim dt As DataTable = db.ReturnTable("select * from tbl_Reports_DatePeriods")
        db = Nothing
        Dim dr As DataRow = dt.NewRow
        dr(0) = 10
        dr(1) = "Between"
        dt.Rows.Add(dr)
        CboPeriod.DataTextField = "Caption"
        CboPeriod.DataValueField = "Period"
        CboPeriod.DataSource = dt
        CboPeriod.DataBind()
        db = New DBAccess
        dt = db.ReturnTable("Select * from tbl_Reports_GroupBy")
        db = Nothing
    End Sub
    Private Function IntegerToDateString(ByVal d As Integer) As String
        Return d.ToString.Substring(0, 4) & "-" & d.ToString.Substring(4, 2) & "-" & d.ToString.Substring(6, 2)
    End Function
    Private Sub FillData()
        Dim db As New DBAccess
        Dim startday As Integer, endday As Integer
        Dim sdate, edate As DateTime
        If CboPeriod.SelectedValue = 10 Then
            startday = ucDateFrom.yyyymmdd
            endday = UcDateTo.yyyymmdd
            sdate = ucDateFrom.value
            edate = UcDateTo.value
            ChartPeriod = DateDiff(DateInterval.Day, sdate, edate)
        Else
            db = New DBAccess
            db.slDataAdd("Period", CboPeriod.SelectedValue)
            db.slDataAdd("Campaignid", CampaignID)
            Dim dr As DataRow = db.ReturnRow("usp_GetStart_EndDateForAPeriod", True)
            db = Nothing
            startday = dr(0)
            endday = dr(1)
            sdate = IntegerToDateString(startday)
            edate = IntegerToDateString(endday)
            ChartPeriod = DateDiff(DateInterval.Day, sdate, edate)
        End If
        db = Nothing
        db = New DBAccess("CRM")
        db.slDataAdd("startday", startday)
        db.slDataAdd("endday", endday)
        db.slDataAdd("campaignID", cboCampaigns.SelectedValue)
        db.slDataAdd("Groupby", 3)
        dt = db.ReturnTable("usp_dashboard_AHt", , True)
        'dt.Columns.Add("Utilization", System.Type.GetType("System.Double"), "iif([Transactions]=0,0, [Transaction Duration]/[Target])*100")
        db = Nothing
        GridView1.DataSource = dt
        GridView1.DataBind()

    End Sub
#End Region
#Region "--- Draw Graph ---"
    Private Sub DrawChart()
        FillData()
        If dt.Rows.Count > 0 Then
            RenderGraph(Chart1, "UTILIZATION")
        End If
    End Sub
    Private Sub RenderGraph(ByVal charts As Chart, ByVal Title As String)
        Dim xValueMem As String = ""
        charts.Series.Clear()
        charts.Series.Add("series1")

        charts.ChartAreas(0).AxisX.IntervalAutoMode = DataVisualization.Charting.IntervalAutoMode.FixedCount
        charts.TextAntiAliasingQuality = DataVisualization.Charting.TextAntiAliasingQuality.High
        Dim mypane As System.Web.UI.DataVisualization.Charting.Series
        mypane = charts.Series(0)
        charts.Series(0).IsValueShownAsLabel = True
        charts.Series(0).MarkerColor = Drawing.Color.White
        charts.ChartAreas(0).AxisX.MajorGrid.Enabled = False
        charts.ChartAreas(0).AxisY.MajorGrid.Enabled = False
        charts.Series(0).ChartType = DataVisualization.Charting.SeriesChartType.Column
        charts.Series(0).MarkerColor = Drawing.Color.White
        charts.Series(0)("DrawingStyle") = "Cylinder"
        charts.Series(0).IsValueShownAsLabel = True
        '--- Add New Series
        charts.Series.Add("Target")
        charts.Series.Add("Transaction")
        charts.Series(1).BorderWidth = 3
        charts.Series(1).Color = Color.Green
        charts.Series(1).XValueMember = dt.Columns(0).ColumnName
        charts.Series(1).YValueMembers = "Target"
        charts.Series(1).ChartType = DataVisualization.Charting.SeriesChartType.Line
        charts.Series(1).BorderDashStyle = ChartDashStyle.Dash
        charts.Series(1).MarkerStyle = DataVisualization.Charting.MarkerStyle.Diamond
        charts.Series(1).MarkerSize = 6
        charts.Series(1).MarkerColor = Drawing.Color.Yellow
        charts.Series(1).IsValueShownAsLabel = True
        
        charts.DataSource = dt.DefaultView
        xValueMem = dt.Columns(0).ColumnName
        charts.DataBind()
        charts.Titles.Add(Title)
        charts.Series(0).XValueMember = xValueMem
        charts.Series(0).YValueMembers = dt.Columns("Utilization").ColumnName
        charts.Series(0).LabelFormat = "{0:n}"
        'charts.Series(0).Label = "#PERCENT"
    End Sub
#End Region
#Region "--- Event ---"
    Protected Sub CboPeriod_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles CboPeriod.SelectedIndexChanged
        If CboPeriod.SelectedValue = 10 Then
            ucDateFrom.Visible = True
            UcDateTo.Visible = True
            lblAnd.Visible = True
            ChartPeriod = ucDateFrom.yyyymmdd - UcDateTo.yyyymmdd
            DrawChart()
        Else
            ucDateFrom.Visible = False
            UcDateTo.Visible = False
            lblAnd.Visible = False
            DrawChart()
        End If
    End Sub
    Protected Sub ucDateFrom_Changed(ByVal sender As Object, ByVal e As System.EventArgs) Handles ucDateFrom.Changed
        DrawChart()
    End Sub
    Protected Sub UcDateTo_Changed(ByVal sender As Object, ByVal e As System.EventArgs) Handles UcDateTo.Changed
        DrawChart()
    End Sub
    Protected Sub ImageButton1_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton1.Click
        DrawChart()
    End Sub
    Protected Sub cboCampaigns_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboCampaigns.SelectedIndexChanged
        DrawChart()
    End Sub
#End Region

  
End Class
