﻿Imports com.nss.DBAccess
Imports System.Data
Imports System.Text

Partial Class CampaignDataSummary
    Inherits System.Web.UI.Page
    Dim footerval(23) As Double
    Dim breakCounter As Integer = 0
#Region "Properties"

    Property ProcessID() As Integer
        Get
            Return ViewState("ProcessID")
        End Get
        Set(ByVal value As Integer)
            ViewState("ProcessID") = value
            Session("ProcessID") = value
        End Set
    End Property
    Property Campaigntype() As Integer
        Get
            Return ViewState("Campaigntype")
        End Get
        Set(ByVal value As Integer)
            ViewState("Campaigntype") = value
            'Session("ProcessID") = value
        End Set
    End Property
    Property Period() As Integer
        Get
            Return ViewState("Period")
        End Get
        Set(ByVal value As Integer)
            ViewState("Period") = value
            'Session("ProcessID") = value
        End Set
    End Property
    Property ReportType() As Integer
        Get
            Return ViewState("ReportType")
        End Get
        Set(ByVal value As Integer)
            ViewState("ReportType") = value
        End Set
    End Property
    Property CampaignID() As Integer
        Get
            Return ViewState("CampaignID")
        End Get
        Set(ByVal value As Integer)
            ViewState("CampaignID") = value
        End Set
    End Property

    Property AgentID() As String
        Get
            Return ViewState("AgentID")
        End Get
        Set(ByVal value As String)
            ViewState("AgentID") = value
        End Set
    End Property
#End Region

    Private Sub LoadData()

        FillProcessCampaigns()
        FillCommonFilters()
        If CboProcess.SelectedItem.Text = "HPS" Then
            CboPeriod.SelectedValue = 3
        End If
    End Sub

    Private Sub FillCommonFilters()
        Dim db As New DBAccess
        Dim dt As DataTable = db.ReturnTable("select * from tbl_Reports_DatePeriods")
        db = Nothing
        Dim dr As DataRow = dt.NewRow
        dr(0) = 10
        dr(1) = "Between"
        dt.Rows.Add(dr)
        CboPeriod.DataTextField = "Caption"
        CboPeriod.DataValueField = "Period"
        CboPeriod.DataSource = dt
        CboPeriod.DataBind()

        db = Nothing

        Period = Request.QueryString("period")
        CboPeriod.SelectedValue = Period

        FillGroupBy()
    End Sub

    Private Sub FillGroupBy()
        Dim db As New DBAccess
        db = New DBAccess("CRM")

        CboGroup.Items.Clear()
        Dim dt As DataTable = db.ReturnTable("Select Caption,ID from tbl_Config_Reports_GroupBy where campaignID =" & CampaignID & "")
        db = Nothing
        CboGroup.DataTextField = "Caption"
        CboGroup.DataValueField = "ID"
        CboGroup.DataSource = dt
        CboGroup.DataBind()
        CboGroup.SelectedIndex = 0
    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        HumanMessage.Style.Item("visibility") = "hidden"
        If Not IsPostBack Then
            ReportType = Request.QueryString("ReportType")
            If Session("AgentID") <> "" Then
                If Not Request.QueryString("Campaign") Is Nothing Then
                    Session("CampaignID") = Request.QueryString("Campaign")
                End If
                CampaignID = Session("CampaignID")
                AgentID = Session("AgentID")
                PanelReports.Controls.Add(Common.GetMenu(Request.Url, AgentID, Request.ApplicationPath))
                LoadData()
                fillgrid()
                UcDateTo.Visible = False
                ucDateFrom.Visible = False
                lblAnd.Visible = False
            End If
        End If
    End Sub

    Private Sub fillgrid()

        For Each obj In footerval
            obj = 0
        Next
        'Dim columns As String
        Dim db As New DBAccess
        Dim startday As Integer, endday As Integer
        If CboPeriod.SelectedValue = 10 Then
            startday = ucDateFrom.yyyymmdd
            endday = UcDateTo.yyyymmdd
        Else
            db = New DBAccess
            db.slDataAdd("Period", CboPeriod.SelectedValue)
            db.slDataAdd("Campaignid", cboCampaigns.SelectedValue)
            Dim dr As DataRow = db.ReturnRow("usp_GetStart_EndDateForAPeriod", True)
            db = Nothing
            startday = dr(0)
            endday = dr(1)
        End If
        db = New DBAccess
        db.slDataAdd("processid", CboProcess.SelectedValue)
        db.slDataAdd("Campaignid", cboCampaigns.SelectedValue)
        db.slDataAdd("userid", AgentID)
        Dim dtcampaigntype As DataTable = db.ReturnTable("usp_getcampaigntype", , True)
        'campaigntype = db.ReturnValue("usp_getcampaigntype", True)
        db = Nothing
        If dtcampaigntype.Rows.Count > 1 Then
            Campaigntype = 1
        Else
            Campaigntype = dtcampaigntype.Rows(0).Item(0)
        End If
        


        db = New DBAccess
        Dim dt As New DataTable

        
            db.slDataAdd("startday", startday)
            db.slDataAdd("endDay", endday)
            db.slDataAdd("campaignid", cboCampaigns.SelectedValue)
            db.slDataAdd("groupBy", CboGroup.SelectedValue)
            'db.slDataAdd("groupBy", CboGroup.SelectedValue)

            'If cboFilterBy.SelectedItem.Text <> "None" And txtFilterValue.Text.Trim <> "" Then
            '    lblFilter.Text = "Filtered for " & cboFilterBy.SelectedItem.Text & " = " & txtFilterValue.Text
            '    If cboFilterBy.SelectedValue.Contains("String") Then
            '        'db.slDataAdd("Filterby", "'" & cboFilterBy.SelectedItem.Text & "'")
            '    End If
            '    db.slDataAdd("Filterby", cboFilterBy.SelectedItem.Text)
            '    db.slDataAdd("Filterbyvalue", txtFilterValue.Text)
            'End If
            'Dim strsql As String
            'strsql = "select * from tbl_Summary_CollectedData where Day >= '" & dr(0) & "' AND  Day <= '" & dr(1) & "' AND campaignid='" & CampaignID & "'"
        'dt = db.ReturnTable("usp_CampaignPerformance2", , True)



        If cboCampaigns.SelectedValue = "341" Then 'LH
            dt = db.ReturnTable("usp_CampaignPerformance2", , True)
        ElseIf cboCampaigns.SelectedValue = "342" Then 'Tribune

            dt = db.ReturnTable("usp_CampaignPerformance4_Tribune", , True)

        ElseIf cboCampaigns.SelectedValue = "367" Then 'Nant Media

            dt = db.ReturnTable("usp_CampaignPerformance5_NantMedia", , True)
        Else
            dt = db.ReturnTable("usp_CampaignPerformance2", , True)
        End If

            'Dim dtime As Date
            'dtime = dr(0).ToString
            lblReportName.Text = CboGroup.SelectedItem.Text & " wise Performance Summary "
            LblError.Text = "Between " & IntegerToDateString(startday) & "  and " & IntegerToDateString(endday) & " for " & cboCampaigns.SelectedItem.Text & " campaign"

            db = Nothing
            GridView1.AutoGenerateColumns = False
            CreateGridColumns(dt.Columns)
            GridView1.DataSource = dt
            GridView1.DataBind()
            dt = Nothing


            ScriptManager.RegisterStartupScript(Me, Me.GetType(), "SortGrid", "$(function(){{$('#" & GridView1.ClientID & "').tablesorter({cancelSelection:true}); }});", True)
            System.Threading.Thread.Sleep(100)
    End Sub
    Private Function IntegerToDateString(ByVal d As Integer) As String
        Return d.ToString.Substring(0, 4) & "-" & d.ToString.Substring(4, 2) & "-" & d.ToString.Substring(6, 2)
    End Function
    Private Sub CreateGridColumns(ByVal cols As DataColumnCollection)
         GridView1.Columns.Clear()
        Dim tempcolumn As TemplateField
        Dim bouncol As BoundField
        Dim objcol As DataColumn
        For Each objcol In cols
            If objcol.ColumnName = "Agents" Then
                tempcolumn = New TemplateField
                Dim tmpagcol As New TemplateAgentName
                tempcolumn.HeaderText = "Agents"
                tmpagcol.DataImageField = "AgentStatus"
                tmpagcol.DataTextField = objcol.ColumnName
                tempcolumn.ItemStyle.HorizontalAlign = HorizontalAlign.Left
                tempcolumn.ItemTemplate = tmpagcol
                GridView1.Columns.Add(tempcolumn)
            ElseIf objcol.ColumnName.ToLower = "column1" Then
                bouncol = New BoundField
                bouncol.HeaderText = CboGroup.SelectedItem.Text
                bouncol.DataField = objcol.ColumnName


                GridView1.Columns.Add(bouncol)
            ElseIf objcol.ColumnName.Contains("Question") Then
                If objcol.Caption <> objcol.ColumnName Then
                    bouncol = New BoundField
                    bouncol.HeaderText = objcol.Caption
                    bouncol.DataField = objcol.ColumnName


                    GridView1.Columns.Add(bouncol)
                End If
            Else
                If objcol.ColumnName <> "Agentstatus" Then
                    bouncol = New BoundField
                    bouncol.HeaderText = objcol.ColumnName
                    bouncol.DataField = objcol.ColumnName


                    GridView1.Columns.Add(bouncol)
                End If

            End If

        Next
    End Sub
    'Private Sub CreateGridColumns(ByVal cols As DataColumnCollection)
    '    GridView1.Columns.Clear()
    '    Dim tempcolumn As TemplateField
    '    Dim bouncol As BoundField
    '    Dim objcol As DataColumn
    '    For Each objcol In cols
    '        If objcol.ColumnName = "Agents" Then
    '            tempcolumn = New TemplateField
    '            Dim tmpagcol As New TemplateAgentName
    '            tempcolumn.HeaderText = "Agents"
    '            tmpagcol.DataImageField = "AgentStatus"
    '            tmpagcol.DataTextField = objcol.ColumnName
    '            tempcolumn.ItemStyle.HorizontalAlign = HorizontalAlign.Left
    '            tempcolumn.ItemTemplate = tmpagcol
    '            GridView1.Columns.Add(tempcolumn)
    '        Else
    '            If objcol.ColumnName <> "Agentstatus" Then
    '                bouncol = New BoundField
    '                bouncol.HeaderText = objcol.ColumnName
    '                bouncol.DataField = objcol.ColumnName

    '                GridView1.Columns.Add(bouncol)
    '            End If

    '        End If

    '    Next
    '    'Dim MonthCols As BoundField

    '    'Dim ctr As Integer

    '    'For ictr As Integer = 0 To ctr
    '    '    tempcolumn = New TemplateColumn
    '    '    Dim tmp As New TemplateField

    '    '    'tempcolumn.ItemTemplate = 
    '    '    MonthCols = New BoundField
    '    '    MonthCols.HeaderText = "Month" & ictr + 1
    '    '    MonthCols.DataField = ""
    '    '    GridView1.Columns.Add(MonthCols)
    '    '    'Next

    'End Sub
    Private Sub FillProcessCampaigns()
        Common.FillProcesses(CboProcess, AgentID)
        'Common.FillProcessCampaigns(CboProcess, cboCampaigns, AgentID, CampaignID)
        Dim lstprocess As New ListItem
        lstprocess.Value = 0
        lstprocess.Text = "All"
        If CboProcess.Items.Contains(lstprocess) Then
            CboProcess.Items.Remove(lstprocess)
        End If
        Dim db As New DBAccess
        db.slDataAdd("Agentid", AgentID)
        CboProcess.SelectedValue = db.ReturnRow("usp_getAgentProcess", True)(4)
        db = Nothing
        Common.FillCampaigns(cboCampaigns, AgentID, CboProcess.SelectedValue)
    End Sub

    Protected Sub cboCampaigns_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboCampaigns.SelectedIndexChanged
        CampaignID = cboCampaigns.SelectedValue
        FillGroupBy()
        fillgrid()
        'Dim helper As GridViewHelper = New GridViewHelper(GridView1)
        'helper.RegisterGroup("Agents", True, True)
        'helper.ApplyGroupSort()
    End Sub

    Protected Sub GridView1_RowDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles GridView1.RowDataBound

        '    ' e.Row.Cells(0).Style.Add("white-space", "nowrap")
        ' If (Math.Round(drv("Accuracy%") / 1.0, 2) < 99.0) Then

        '        '      foreach (TableCell cell in e.Row.Cells)
        '        'If (EndtimeEST < ActualEndTimeEST) Then

        '        '                e.Row.Cells[17].ForeColor = Color.Red;
        '        '                e.Row.Cells[20].Text = "Missed TAT";
        '        '                e.Row.Cells[20].ForeColor = Color.Red;

        If e.Row.RowType = DataControlRowType.DataRow Then

            Dim drv As DataRowView
            drv = (DirectCast(e.Row.DataItem, DataRowView))

      

            If e.Row.Cells(7).Text > "00" Then
                If Math.Round((e.Row.Cells(7).Text / 1.0), 2) < 99.0 Then

                    e.Row.Cells(7).ForeColor = Drawing.Color.Red

                Else
                    e.Row.Cells(7).ForeColor = Drawing.Color.Black
                  
                End If
            Else
                If e.Row.Cells(3).Text > "00" Then
                    e.Row.Cells(7).Text = "100%"
                End If
                End If
        End If


    End Sub
    ' Protected Sub GridView1_RowDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles GridView1.RowDataBound


    '    If Campaigntype = 11 Then
    '        If e.Row.RowType = DataControlRowType.Header Then
    '            'For i As Integer = 0 To footerval.Length - 1
    '            '    footerval(i) = 0
    '            'Next
    '            If CboGroup.SelectedValue <> 4 Then
    '                e.Row.Cells(18).Text = "NFAR Score<br />[%]"
    '                e.Row.Cells(19).Text = "FAR Score<br />[%]"
    '                e.Row.Cells(21).Text = "OverAll Score<br />[%]"
    '            End If
    '        End If
    '        If e.Row.RowType = DataControlRowType.DataRow Then
    '            'Dim itemlen As Integer = e.Row.Cells(0).Text.ToString.Length
    '            'If itemlen > widestdata Then
    '            '    widestdata = itemlen
    '            'End If
    '            'Me.GridView1.Columns(0).ItemStyle.Width = widestdata * 10
    '            Me.GridView1.Columns(0).ItemStyle.Wrap = False
    '            e.Row.Cells(0).Attributes.Add("style", "white-space:nowrap")

    '            If e.Row.Cells(0).Controls.Count > 0 Then
    '                If CType(e.Row.Cells(0).Controls(0).Controls(0).Controls(0).Controls(0), Image).ImageUrl.Contains("onbreak") Then
    '                    breakCounter = breakCounter + 1
    '                End If
    '            End If

    '            e.Row.Cells(0).Style.Add("text-align", "left")
    '            footerval(1) = footerval(1) + e.Row.Cells(1).Text
    '            footerval(2) = footerval(2) + e.Row.Cells(2).Text 'login hrs
    '            footerval(3) = footerval(3) + e.Row.Cells(3).Text 'Break duration
    '            footerval(4) = footerval(4) + e.Row.Cells(4).Text ' Talk duration
    '            footerval(5) = footerval(5) + e.Row.Cells(5).Text ' Wrap duration
    '            footerval(6) = footerval(6) + e.Row.Cells(6).Text ' Completes
    '            footerval(7) = footerval(7) + e.Row.Cells(7).Text ' Part Completes
    '            footerval(8) = footerval(8) + e.Row.Cells(8).Text ' Contacts
    '            footerval(9) = footerval(9) + e.Row.Cells(9).Text ' Connects
    '            footerval(10) = footerval(10) + e.Row.Cells(10).Text 'CPH
    '            footerval(11) = footerval(11) + e.Row.Cells(11).Text 'PCPH
    '            footerval(12) = footerval(12) + e.Row.Cells(12).Text 'AHT
    '            footerval(13) = footerval(13) + e.Row.Cells(13).Text 'Contact per hour
    '            footerval(14) = footerval(14) + e.Row.Cells(14).Text 'Contact Rate
    '            footerval(15) = footerval(15) + e.Row.Cells(15).Text 'Conversion Rate
    '            footerval(16) = footerval(16) + e.Row.Cells(16).Text
    '            If CboGroup.SelectedValue <> 4 Then
    '                footerval(17) = footerval(17) + e.Row.Cells(17).Text 'Call Monitored
    '                footerval(18) = footerval(18) + e.Row.Cells(18).Text 'NFAR
    '                footerval(19) = footerval(19) + e.Row.Cells(19).Text 'NFAR
    '                footerval(20) = footerval(20) + e.Row.Cells(20).Text
    '                footerval(21) = footerval(21) + e.Row.Cells(21).Text
    '                footerval(22) = footerval(22) + e.Row.Cells(22).Text
    '            End If
    '            'e.Row.Cells(2).Text = Math.Round((e.Row.Cells(2).Text / 3600 * 1.0), 2)
    '            e.Row.Cells(2).Text = Common.TimeString(e.Row.Cells(2).Text)
    '            e.Row.Cells(3).Text = Common.TimeString(e.Row.Cells(3).Text)
    '            'e.Row.Cells(4).Text = Math.Round((e.Row.Cells(4).Text / 1.0), 2)
    '            e.Row.Cells(4).Text = Common.TimeString(e.Row.Cells(4).Text)
    '            e.Row.Cells(5).Text = Common.TimeString(e.Row.Cells(5).Text)
    '            e.Row.Cells(6).Text = Common.TimeString(e.Row.Cells(6).Text)
    '            e.Row.Cells(11).Text = Math.Round((e.Row.Cells(11).Text / 1.0), 2)
    '            e.Row.Cells(12).Text = Math.Round((e.Row.Cells(12).Text / 1.0), 2)
    '            If e.Row.Cells(7).Text = "0" Then
    '                e.Row.Cells(13).Text = "00:00:00"
    '            Else
    '                e.Row.Cells(13).Text = Common.TimeString(e.Row.Cells(13).Text / e.Row.Cells(7).Text)
    '            End If

    '            e.Row.Cells(14).Text = Math.Round((e.Row.Cells(14).Text / 1.0), 2)
    '            e.Row.Cells(15).Text = Math.Round((e.Row.Cells(15).Text / 1.0) * 100, 2)
    '            e.Row.Cells(16).Text = Math.Round((e.Row.Cells(16).Text / 1.0) * 100, 2)
    '            If CboGroup.SelectedValue <> 4 Then
    '                If e.Row.Cells(17).Text = "0" Then
    '                    e.Row.Cells(18).Text = ""
    '                    e.Row.Cells(19).Text = ""
    '                Else
    '                    If e.Row.Cells(18).Text = "0" Then
    '                        e.Row.Cells(18).Text = 100
    '                    Else
    '                        e.Row.Cells(18).Text = Math.Round(100 - ((e.Row.Cells(19).Text / e.Row.Cells(18).Text) * 100), 2)
    '                    End If
    '                    e.Row.Cells(19).Text = Math.Round(100 - ((e.Row.Cells(20).Text / e.Row.Cells(17).Text) * 100), 2)
    '                End If
    '                If e.Row.Cells(21).Text <= "0" Then
    '                    e.Row.Cells(21).Text = "0"
    '                Else
    '                    e.Row.Cells(21).Text = Math.Round((e.Row.Cells(22).Text / e.Row.Cells(21).Text) * 100, 2)
    '                End If
    '            End If
    '        ElseIf e.Row.RowType = DataControlRowType.Footer Then
    '            If CboGroup.SelectedValue = 1 Then
    '                e.Row.Cells(0).Text = "[OnBreak= " & breakCounter.ToString & "] Total: "
    '            Else
    '                e.Row.Cells(0).Text = "Total: "
    '            End If


    '            If CboGroup.SelectedValue = 3 Or CboGroup.SelectedValue = 4 Then
    '                e.Row.Cells(1).Text = Math.Ceiling(footerval(1) / GridView1.Rows.Count)
    '            Else
    '                e.Row.Cells(1).Text = footerval(1)
    '            End If

    '            'e.Row.Cells(2).Text = Math.Round((footerval(2) / 3600 * 1.0), 2)
    '            e.Row.Cells(2).Text = Common.TimeString(footerval(2))
    '            e.Row.Cells(3).Text = Common.TimeString(footerval(3))
    '            'e.Row.Cells(4).Text = Math.Round((footerval(4) / 1 * 1.0), 2)
    '            e.Row.Cells(4).Text = Common.TimeString(footerval(4))
    '            e.Row.Cells(5).Text = Common.TimeString(footerval(5))
    '            e.Row.Cells(6).Text = Common.TimeString(footerval(6))
    '            e.Row.Cells(7).Text = footerval(7)
    '            e.Row.Cells(8).Text = footerval(8)
    '            e.Row.Cells(9).Text = footerval(9)
    '            e.Row.Cells(10).Text = footerval(10)
    '            'e.Row.Cells(10).Text = Math.Round((footerval(6) / (footerval(2) / 3600 * 1.0)), 2)
    '            e.Row.Cells(11).Text = Math.Round((footerval(7) / (footerval(2) / 3600 * 1.0)), 2)
    '            e.Row.Cells(12).Text = Math.Round((footerval(8) / (footerval(2) / 3600 * 1.0)), 2)
    '            If footerval(7) = 0 Then
    '                e.Row.Cells(13).Text = "00:00:00"
    '            Else
    '                e.Row.Cells(13).Text = Common.TimeString((footerval(13) / footerval(7)))
    '            End If

    '            e.Row.Cells(14).Text = Math.Round((footerval(9) / (footerval(2) / 3600 * 1.0)), 2)
    '            e.Row.Cells(15).Text = Math.Round((footerval(9) / footerval(10)) * 100, 2)
    '            e.Row.Cells(16).Text = Math.Round((footerval(7) / footerval(9)) * 100, 2)
    '            If CboGroup.SelectedValue <> 4 Then
    '                e.Row.Cells(17).Text = footerval(17)
    '                If footerval(17) = 0 Then
    '                    e.Row.Cells(18).Text = ""
    '                    e.Row.Cells(19).Text = ""
    '                Else
    '                    If footerval(18) = 0 Then
    '                        e.Row.Cells(18).Text = 100
    '                    Else
    '                        e.Row.Cells(18).Text = Math.Round(100 - ((footerval(19) / footerval(18)) * 100), 2)
    '                    End If
    '                    e.Row.Cells(19).Text = Math.Round(100 - ((footerval(20) / footerval(17)) * 100), 2)
    '                    If footerval(21) <= "0" Then
    '                        e.Row.Cells(21).Text = ""
    '                    Else
    '                        e.Row.Cells(21).Text = Math.Round((footerval(22) / footerval(21)) * 100, 2)
    '                    End If
    '                End If

    '                e.Row.Cells(20).Text = footerval(20)
    '            End If
    '        End If
    '    Else
    '        If e.Row.RowType = DataControlRowType.Header Then
    '            'For i As Integer = 0 To footerval.Length - 1
    '            '    footerval(i) = 0
    '            'Next

    '            e.Row.Cells(0).Text = "Supervisor"
    '            e.Row.Cells(1).Text = "No Error"
    '            e.Row.Cells(2).Text = "Fatal Error"
    '            e.Row.Cells(3).Text = "Monitored<br />"
    '            e.Row.Cells(4).Text = "Non-Monitored<br />"
    '            e.Row.Cells(5).Text = "Total Processed<br />"
    '            e.Row.Cells(6).Text = "Monitored Sample<br />[%]"
    '            e.Row.Cells(7).Text = "Accuracy<br />[%]"
    '        End If
    '        If e.Row.RowType = DataControlRowType.DataRow Then
    '            e.Row.Cells(0).Style.Add("white-space", "nowrap")
    '            ' e.Row.Cells(0).Style.Add("nowrap", "nowrap")
    '            e.Row.Cells(0).Style.Add("text-align", "left")

    '            If e.Row.Cells(0).Controls.Count > 0 Then
    '                If CType(e.Row.Cells(0).Controls(0).Controls(0).Controls(0).Controls(0), Image).ImageUrl.Contains("onbreak") Then
    '                    breakCounter = breakCounter + 1
    '                End If
    '            End If

    '            footerval(1) = footerval(1) + e.Row.Cells(1).Text
    '            footerval(2) = footerval(2) + e.Row.Cells(2).Text 'login hrs
    '            footerval(3) = footerval(3) + e.Row.Cells(3).Text 'transation duration
    '            footerval(4) = footerval(4) + e.Row.Cells(4).Text ' break duration
    '            footerval(5) = footerval(5) + e.Row.Cells(5).Text 'Transaction
    '            footerval(6) = footerval(6) + e.Row.Cells(6).Text ' Completes
    '            footerval(7) = footerval(7) + e.Row.Cells(7).Text
    '            footerval(10) = footerval(10) + e.Row.Cells(10).Text
    '            footerval(11) = footerval(11) + e.Row.Cells(11).Text
    '            footerval(0) += 1
    '            footerval(12) = footerval(12) + e.Row.Cells(12).Text 'Call Monitored
    '            footerval(13) = footerval(13) + e.Row.Cells(13).Text 'NFAR
    '            footerval(14) = footerval(14) + e.Row.Cells(14).Text 'NFAR
    '            footerval(15) = footerval(15) + e.Row.Cells(15).Text
    '            footerval(16) = footerval(16) + e.Row.Cells(16).Text
    '            footerval(17) = footerval(17) + e.Row.Cells(17).Text
    '            If CboGroup.SelectedValue = 1 Then
    '                footerval(18) = footerval(18) + e.Row.Cells(18).Text
    '                footerval(19) = footerval(19) + e.Row.Cells(19).Text
    '            End If

    '            If e.Row.Cells(2).Text = 0 Then
    '                e.Row.Cells(7).Text = "N.A"
    '            Else
    '                e.Row.Cells(7).Text = Math.Round((e.Row.Cells(5).Text / e.Row.Cells(2).Text) * 3600, 2)
    '            End If

    '            If e.Row.Cells(5).Text = "0" Then
    '                e.Row.Cells(8).Text = "N.A"
    '                e.Row.Cells(9).Text = "N.A"
    '            Else
    '                e.Row.Cells(8).Text = Common.TimeString(e.Row.Cells(3).Text / e.Row.Cells(5).Text) 'AHT
    '                If (e.Row.Cells(3).Text - e.Row.Cells(10).Text) <> 0 And (e.Row.Cells(5).Text - e.Row.Cells(11).Text) <> 0 Then
    '                    e.Row.Cells(9).Text = Common.TimeString((e.Row.Cells(3).Text - e.Row.Cells(10).Text) / (e.Row.Cells(5).Text - e.Row.Cells(11).Text)) 'AHT
    '                Else
    '                    e.Row.Cells(9).Text = "N.A"
    '                End If

    '            End If


    '            e.Row.Cells(2).Text = Common.TimeString(e.Row.Cells(2).Text)
    '            e.Row.Cells(3).Text = Common.TimeString(e.Row.Cells(3).Text)
    '            e.Row.Cells(4).Text = Common.TimeString(e.Row.Cells(4).Text)
    '            e.Row.Cells(10).Text = Common.TimeString(e.Row.Cells(10).Text)
    '            If e.Row.Cells(12).Text = "0" Then
    '                e.Row.Cells(13).Text = ""
    '                e.Row.Cells(14).Text = ""
    '            Else
    '                If e.Row.Cells(13).Text = "0" Then
    '                    e.Row.Cells(13).Text = 100
    '                Else
    '                    e.Row.Cells(13).Text = Math.Round(100 - ((e.Row.Cells(14).Text / e.Row.Cells(13).Text) * 100), 2)
    '                End If
    '                e.Row.Cells(14).Text = Math.Round(100 - ((e.Row.Cells(15).Text / e.Row.Cells(12).Text) * 100), 2)
    '            End If
    '            If e.Row.Cells(16).Text <= "0" Then
    '                e.Row.Cells(16).Text = "0"
    '            Else
    '                e.Row.Cells(16).Text = Math.Round((e.Row.Cells(17).Text / e.Row.Cells(16).Text) * 100, 2)
    '            End If
    '            If CboGroup.SelectedValue = 1 Then
    '                e.Row.Cells(18).Text = Common.TimeString(e.Row.Cells(18).Text)
    '                e.Row.Cells(19).Text = Common.TimeString(e.Row.Cells(19).Text)
    '            End If
    '            ' 

    '        ElseIf e.Row.RowType = DataControlRowType.Footer Then
    '            If CboGroup.SelectedValue = 1 Then
    '                e.Row.Cells(0).Text = "[OnBreak= " & breakCounter.ToString & "] Total: "
    '            Else
    '                e.Row.Cells(0).Text = "Total: "
    '            End If

    '            If CboGroup.SelectedValue = 3 Then
    '                e.Row.Cells(1).Text = Math.Ceiling(footerval(1) / footerval(0))
    '            Else
    '                e.Row.Cells(1).Text = footerval(1)
    '            End If
    '            'e.Row.Cells(1).Text = footerval(1)

    '            e.Row.Cells(2).Text = Common.TimeString(footerval(2))
    '            e.Row.Cells(3).Text = Common.TimeString(footerval(3))
    '            e.Row.Cells(4).Text = Common.TimeString(footerval(4))
    '            e.Row.Cells(10).Text = Common.TimeString(footerval(10))
    '            e.Row.Cells(5).Text = footerval(5) 'transations
    '            e.Row.Cells(6).Text = footerval(6) 'completes
    '            If footerval(2) = 0 Then
    '                e.Row.Cells(7).Text = "N.A" 'CPH
    '            Else
    '                e.Row.Cells(7).Text = Math.Round((footerval(5) / footerval(2)) * 3600, 2) 'CPH
    '            End If
    '            If footerval(5) = 0 Then
    '                e.Row.Cells(8).Text = "N.A" 'AHT
    '                e.Row.Cells(9).Text = "N.A" 'AHT
    '            Else
    '                e.Row.Cells(8).Text = Common.TimeString(footerval(3) / footerval(5)) 'AHT
    '                If (footerval(3) - footerval(10)) <> 0 And (footerval(5) - footerval(11)) <> 0 Then
    '                    e.Row.Cells(9).Text = Common.TimeString((footerval(3) - footerval(10)) / (footerval(5) - footerval(11))) 'AHT
    '                End If
    '            End If
    '            e.Row.Cells(11).Text = footerval(11)
    '            e.Row.Cells(12).Text = footerval(12)
    '            If footerval(12) = 0 Then
    '                e.Row.Cells(13).Text = ""
    '                e.Row.Cells(14).Text = ""
    '            Else
    '                If footerval(13) = 0 Then
    '                    e.Row.Cells(13).Text = 100
    '                Else
    '                    e.Row.Cells(13).Text = Math.Round(100 - ((footerval(14) / footerval(13)) * 100), 2)
    '                End If
    '                e.Row.Cells(14).Text = Math.Round(100 - ((footerval(15) / footerval(12)) * 100), 2)
    '                If footerval(16) <= "0" Then
    '                    e.Row.Cells(16).Text = "0"
    '                Else
    '                    e.Row.Cells(16).Text = Math.Round((footerval(17) / footerval(16)) * 100, 2)
    '                End If
    '                e.Row.Cells(15).Text = footerval(15)
    '                If CboGroup.SelectedValue = 1 Then
    '                    e.Row.Cells(18).Text = Common.TimeString(footerval(18))
    '                    e.Row.Cells(19).Text = Common.TimeString(footerval(19))
    '                End If
    '            End If
    '        End If
    '    End If

    'End Sub
    Protected Sub GridView1_PreRender(ByVal sender As Object, ByVal e As System.EventArgs) Handles GridView1.PreRender
        If Not GridView1 Is Nothing Then
            If GridView1.HeaderRow Is Nothing Then
            Else

                GridView1.HeaderRow.TableSection = TableRowSection.TableHeader
                GridView1.FooterRow.TableSection = TableRowSection.TableFooter
            End If
        End If
    End Sub
    Protected Sub ImageButton1_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton1.Click
        fillgrid()
        GridViewExportUtil.Export(lblReportName.Text & "-" & LblError.Text & ".xls", Me.GridView1)
    End Sub

    Private Sub ExportToexcel()
        Dim tw As New IO.StringWriter()
        Dim hw As New System.Web.UI.HtmlTextWriter(tw)
        'Dim frm As HtmlForm = New HtmlForm()
        Response.ContentType = "application/vnd.ms-excel"
        Response.AddHeader("content-disposition", "attachment;filename=" & lblReportName.Text & "-" & LblError.Text & ".xls")
        Response.Charset = ""
        EnableViewState = False
        'Controls.Add(frm)
        GridView1.RenderControl(hw)
        Response.Write(tw.ToString())
        Response.End()
    End Sub
    Protected Sub CboGroup_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles CboGroup.SelectedIndexChanged
        If CboProcess.SelectedItem.Text = "HPS" Then
            CboPeriod.SelectedValue = 3
        End If
        fillgrid()
    End Sub

    Protected Sub btnFilter_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnFilter.Click
        If CboProcess.SelectedItem.Text = "HPS" Then
            CboPeriod.SelectedValue = 3
        End If
        fillgrid()
    End Sub

    Protected Sub btnRefresh_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnRefresh.Click
        If CboProcess.SelectedItem.Text = "HPS" Then
            CboPeriod.SelectedValue = 3
        End If
        fillgrid()
    End Sub
    'Protected Sub ucDateFrom_Changed(ByVal sender As Object, ByVal e As System.EventArgs) Handles ucDateFrom.Changed
    '    fillgrid()
    'End Sub
    'Protected Sub UcDateTo_Changed(ByVal sender As Object, ByVal e As System.EventArgs) Handles UcDateTo.Changed
    '    fillgrid()
    'End Sub

    Protected Sub CboProcess_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles CboProcess.SelectedIndexChanged
        ProcessID = CboProcess.SelectedValue
        Common.FillCampaigns(cboCampaigns, AgentID, CboProcess.SelectedValue)
        CampaignID = cboCampaigns.SelectedValue
        If CboProcess.SelectedItem.Text = "HPS" Then
            CboPeriod.SelectedValue = 3
        End If
        fillgrid()
    End Sub
    Protected Sub CboPeriod_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles CboPeriod.SelectedIndexChanged
        If CboPeriod.SelectedValue = 10 Then
            ucDateFrom.Visible = True
            UcDateTo.Visible = True
            lblAnd.Visible = True
            fillgrid()
        Else
            ucDateFrom.Visible = False
            UcDateTo.Visible = False
            lblAnd.Visible = False
            fillgrid()
        End If
    End Sub

    Protected Sub imgfav_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles imgfav.Click
        Common.AddToFav(AgentID, "Campaign Summary")
        SuccessMessage("Report has been added to your favourite list")
        fillgrid()
    End Sub
#Region "Utility"

    Private Sub AlertMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMFail"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub

    Private Sub SuccessMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMSuccess"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub

    'Protected Sub ImageButton1_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton1.Click
    '    'fillgrid()
    '    GridViewExportUtil.Export(lblReportName.CurrentPage & "-" & LblError.Text & ".xls", Me.GdAttendance)
    'End Sub


    Public Overrides Sub VerifyRenderingInServerForm(ByVal Control As Control)

    End Sub

#End Region
End Class
