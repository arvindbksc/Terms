﻿Imports com.nss.DBAccess
Imports System.Data
Imports System.Web
Imports System.Drawing
Imports System.Web.UI
Imports System.Web.Services
Imports System.Web.Services.WebService
Partial Class Forcasting
    Inherits System.Web.UI.Page

    <WebMethod()> _
        Public Shared Function GetData(ByVal datefrom As String, ByVal dateto As String, ByVal groupby As Int32) As String
        Dim dt As New DataTable
        Dim db As New DBAccess("CRM")
        Dim gv As New GridView
        db.slDataAdd("datefrom", datefrom)
        db.slDataAdd("dateto", dateto)
        db.slDataAdd("GroupBy", groupby)
        dt = db.ReturnTable("usp_GetDemoForecast", , True)
        Dim sjData As String = ""
        If dt.Rows.Count > 0 Then
            sjData = GetJson(dt)
           
        End If
        Return sjData
    End Function
    Public Sub Bind(ByVal instance As GridView, ByVal dataSource As Object)
        instance.DataSource = dataSource
        instance.DataBind()
    End Sub
    Public Shared Function GetJson(ByVal dt As DataTable) As String
        Dim serializer As New System.Web.Script.Serialization.JavaScriptSerializer()
        serializer.MaxJsonLength = Integer.MaxValue
        Dim rows As New List(Of Dictionary(Of String, Object))()
        Dim row As Dictionary(Of String, Object) = Nothing
        Dim row2 As Dictionary(Of Integer, Object) = Nothing
        For Each dr As DataRow In dt.Rows
            row = New Dictionary(Of String, Object)()
            row2 = New Dictionary(Of Integer, Object)()
            For Each dc As DataColumn In dt.Columns
                row.Add(dc.ColumnName.Trim(), dr(dc))
            Next
            rows.Add(row)
        Next
        Return serializer.Serialize(rows)
    End Function

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            BindColumnToGridview()
            BindhourlyGridview()
        End If
    End Sub
    Private Sub BindColumnToGridview()
        Dim dt As New DataTable()
        dt.Columns.Add("Day")
        dt.Columns.Add("Forecast AHT")
        dt.Columns.Add("Forecast Volume")
        dt.Columns.Add("Forecast Staff")
        dt.Rows.Add()
        gvData.DataSource = dt
        gvData.DataBind()
        'gvData.Rows(0).Visible = False
    End Sub
    Private Sub BindhourlyGridview()
        Dim dt As New DataTable()
        dt.Columns.Add("Hourly Interval")
        dt.Columns.Add("Forecast AHT")
        dt.Columns.Add("Forecast Volume")
        dt.Columns.Add("Forecast Staff")
        dt.Rows.Add()
        gvDatahour.DataSource = dt
        gvDatahour.DataBind()
        'gvDatahour.Rows(0).Visible = False
    End Sub
End Class
