﻿Imports com.nss.DBAccess
Imports System.Data
Imports System.Text

Partial Class CampaignSummary
    Inherits System.Web.UI.Page
    Dim footerval(30) As Double
    Dim breakCounter As Integer = 0
#Region "Properties"

    Property ProcessID() As Integer
        Get
            Return ViewState("ProcessID")
        End Get
        Set(ByVal value As Integer)
            ViewState("ProcessID") = value
            Session("ProcessID") = value
        End Set
    End Property
    Property Campaigntype() As Integer
        Get
            Return ViewState("Campaigntype")
        End Get
        Set(ByVal value As Integer)
            ViewState("Campaigntype") = value
            'Session("ProcessID") = value
        End Set
    End Property
    Property ReportType() As Integer
        Get
            Return ViewState("ReportType")
        End Get
        Set(ByVal value As Integer)
            ViewState("ReportType") = value
        End Set
    End Property
    Property CampaignID() As Integer
        Get
            Return ViewState("CampaignID")
        End Get
        Set(ByVal value As Integer)
            ViewState("CampaignID") = value
        End Set
    End Property

    Property AgentID() As String
        Get
            Return ViewState("AgentID")
        End Get
        Set(ByVal value As String)
            ViewState("AgentID") = value
        End Set
    End Property
#End Region

    Private Sub LoadData()
        FillCommonFilters()
        FillProcessCampaigns()
        fillFilters()
        cboCampaigns.SelectedValue = 0
    End Sub

    Private Sub FillCommonFilters()
        Dim db As New DBAccess
        Dim dt As DataTable = db.ReturnTable("select * from tbl_Reports_DatePeriods")
        db = Nothing
        Dim dr As DataRow = dt.NewRow
        dr(0) = 10
        dr(1) = "Between"
        dt.Rows.Add(dr)
        CboPeriod.DataTextField = "Caption"
        CboPeriod.DataValueField = "Period"
        CboPeriod.DataSource = dt
        CboPeriod.DataBind()
        db = New DBAccess
        dt = db.ReturnTable("Select * from tbl_Reports_GroupBy")
        db = Nothing
        Dim dtrow() As DataRow = dt.Select("Caption IN('Hour')")
        dt.Rows.Remove(dtrow(0))

        CboGroup.DataTextField = "Caption"
        CboGroup.DataValueField = "ID"
        CboGroup.DataSource = dt
        CboGroup.DataBind()

        cboGroupBy2.DataTextField = "Caption"
        cboGroupBy2.DataValueField = "ID"
        cboGroupBy2.DataSource = dt
        Dim dr1 As DataRow = dt.NewRow
        dr1(0) = "Rule"
        dr1(1) = 4
        dt.Rows.Add(dr1)
        cboGroupBy2.DataBind()


    End Sub
    Private Sub fillFilters()
        Dim db As New DBAccess("CRM")
        Dim dt As DataTable = db.ReturnTable("select distinct(RuleName),[Rule] from [tbl_Zions_Performance] where RuleName is not null order by [Rule]")
        db = Nothing
        cboFilterBy.DataTextField = "RuleName"
        cboFilterBy.DataValueField = "Rule"
        cboFilterBy.DataSource = dt
        cboFilterBy.DataBind()
        cboFilterBy.Items.Insert(0, "")
        cboFilterBy.SelectedValue = 0
    End Sub
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        HumanMessage.Style.Item("visibility") = "hidden"
        If Not IsPostBack Then
            ReportType = Request.QueryString("ReportType")
            If Session("AgentID") <> "" Then
                If Not Request.QueryString("Campaign") Is Nothing Then
                    Session("CampaignID") = Request.QueryString("Campaign")
                End If
                CampaignID = Session("CampaignID")
                AgentID = Session("AgentID")
                PanelReports.Controls.Add(Common.GetMenu(Request.Url, AgentID, Request.ApplicationPath))
                LoadData()
                CboGroup.SelectedValue = Request.QueryString("groupby")
                CboPeriod.SelectedValue = Request.QueryString("period")
                setstartdate()
                fillgrid("%")
                UcDateTo.Visible = False
                ucDateFrom.Visible = False
                lblAnd.Visible = False

            End If
        End If
    End Sub

    Private Sub fillgrid(ByVal FilterBy As String)

        For Each obj In footerval
            obj = 0
        Next
        'Dim columns As String
        Dim db As New DBAccess
        Dim startday As Integer, endday As Integer
        If CboPeriod.SelectedValue = 10 Then
            startday = ucDateFrom.yyyymmdd
            endday = UcDateTo.yyyymmdd
        Else
            db = New DBAccess
            db.slDataAdd("Period", CboPeriod.SelectedValue)
            db.slDataAdd("Campaignid", cboCampaigns.SelectedValue)
            Dim dr As DataRow = db.ReturnRow("usp_GetStart_EndDateForAPeriod", True)
            db = Nothing
            startday = dr(0)
            endday = dr(1)
        End If
        db = New DBAccess
        db.slDataAdd("processid", CboProcess.SelectedValue)
        db.slDataAdd("Campaignid", cboCampaigns.SelectedValue)
        db.slDataAdd("userid", AgentID)
        Dim dtcampaigntype As DataTable = db.ReturnTable("usp_getcampaigntype", , True)
        'campaigntype = db.ReturnValue("usp_getcampaigntype", True)
        db = Nothing
        If dtcampaigntype.Rows.Count > 1 Then
            Campaigntype = 1
        Else
            Campaigntype = dtcampaigntype.Rows(0).Item(0)
        End If
        db = New DBAccess("CRM")
        Dim dt As New DataTable
        db.slDataAdd("userid", AgentID)
        db.slDataAdd("startday", startday)
        db.slDataAdd("endDay", endday)
        db.slDataAdd("campaignid", cboCampaigns.SelectedValue)
        db.slDataAdd("groupBy", CboGroup.SelectedValue)
        If cboFilterBy.SelectedItem.Text.Trim = "" Then
            FilterBy = "%"
        Else
            FilterBy = cboFilterBy.SelectedItem.Text
        End If
        db.slDataAdd("FilterBy", FilterBy)
        db.slDataAdd("groupBy2", cboGroupBy2.SelectedValue)
        db.slDataAdd("Processid", CboProcess.SelectedValue)
        If Campaigntype = 11 Then
            dt = db.ReturnTable("usp_CampaignPerformanceTerms2_VoiceCampaign", "", True)
        Else
            dt = db.ReturnTable("usp_CampaignPerformanceTerms2_Zions", , True)
        End If
        'Dim dtime As Date
        'dtime = dr(0).ToString
        lblReportName.Text = CboGroup.SelectedItem.Text & " wise Performance Summary "
        LblError.Text = "Between " & IntegerToDateString(startday) & "  and " & IntegerToDateString(endday) & " for " & cboCampaigns.SelectedItem.Text & " campaign"
        db = Nothing
        GridView1.AutoGenerateColumns = False
        CreateGridColumns(dt.Columns)
        GridView1.DataSource = dt
        GridView1.DataBind()
        dt = Nothing
        ScriptManager.RegisterStartupScript(Me, Me.GetType(), "SortGrid", "$(function(){{$('#" & GridView1.ClientID & "').tablesorter({cancelSelection:true}); }});", True)
        'System.Threading.Thread.Sleep(100)
    End Sub
    Private Function IntegerToDateString(ByVal d As Integer) As String
        Return d.ToString.Substring(0, 4) & "-" & d.ToString.Substring(4, 2) & "-" & d.ToString.Substring(6, 2)
    End Function
    Private Sub CreateGridColumns(ByVal cols As DataColumnCollection)
        GridView1.Columns.Clear()
        Dim tempcolumn As TemplateField
        Dim bouncol As BoundField
        Dim objcol As DataColumn
        For Each objcol In cols
            If objcol.ColumnName = "Agents" Then
                tempcolumn = New TemplateField
                Dim tmpagcol As New TemplateAgentName
                tempcolumn.HeaderText = "Agents"
                tmpagcol.DataImageField = "AgentStatus"
                tmpagcol.DataTextField = objcol.ColumnName
                tempcolumn.ItemStyle.HorizontalAlign = HorizontalAlign.Left
                tempcolumn.ItemTemplate = tmpagcol
                GridView1.Columns.Add(tempcolumn)
            Else
                If objcol.ColumnName <> "Agentstatus" Then
                    bouncol = New BoundField
                    bouncol.HeaderText = objcol.ColumnName
                    bouncol.DataField = objcol.ColumnName

                    GridView1.Columns.Add(bouncol)
                End If

            End If

        Next
        'Dim MonthCols As BoundField

        'Dim ctr As Integer

        'For ictr As Integer = 0 To ctr
        '    tempcolumn = New TemplateColumn
        '    Dim tmp As New TemplateField

        '    'tempcolumn.ItemTemplate = 
        '    MonthCols = New BoundField
        '    MonthCols.HeaderText = "Month" & ictr + 1
        '    MonthCols.DataField = ""
        '    GridView1.Columns.Add(MonthCols)
        '    'Next

    End Sub
    Private Sub FillProcessCampaigns()
        Common.FillProcesses(CboProcess, AgentID)
        'Common.FillProcessCampaigns(CboProcess, cboCampaigns, AgentID, CampaignID)
        Dim lstprocess As New ListItem
        lstprocess.Value = 0
        lstprocess.Text = "All"
        If CboProcess.Items.Contains(lstprocess) Then
            CboProcess.Items.Remove(lstprocess)
        End If
        'Dim db As New DBAccess
        'db.slDataAdd("Agentid", AgentID)
        'CboProcess.SelectedValue = db.ReturnRow("usp_getAgentProcess", True)(4)
        CboProcess.SelectedValue = 103
        'db = Nothing
        Common.FillCampaigns(cboCampaigns, AgentID, CboProcess.SelectedValue)
    End Sub

    Protected Sub cboCampaigns_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboCampaigns.SelectedIndexChanged
        CampaignID = cboCampaigns.SelectedValue
        setstartdate()
        fillgrid("%")
        'setstartdate()
        'Dim helper As GridViewHelper = New GridViewHelper(GridView1)
        'helper.RegisterGroup("Agents", True, True)
        'helper.ApplyGroupSort()
    End Sub
    Protected Sub setstartdate()
        'If CampaignID = 290 Then
        '    ' Label1.Text = "Start Date : "
        '    ' lblcmpstartdate.Text = " 01-Feb-2013"
        '    'lblAccuracyTarget.Text = "97.91"
        '    'lblTatTraget.Text = "96.91"
        'ElseIf CampaignID = 291 Then
        '    Label1.Text = "Start Date :"
        '    lblcmpstartdate.Text = " 05-Feb-2013"
        '    'lblAccuracyTarget.Text = "97.97"
        '    'lblTatTraget.Text = "96.91"
        'ElseIf CampaignID = 292 Then
        '    Label1.Text = "Start Date : "
        '    lblcmpstartdate.Text = " 30-Jan-2013"
        '    'lblAccuracyTarget.Text = "99.79"
        '    'lblTatTraget.Text = "99.03"
        'ElseIf CampaignID = 293 Then
        '    Label1.Text = "Start Date : "
        '    lblcmpstartdate.Text = " 01-Feb-2013"
        '    'lblAccuracyTarget.Text = "97.20"
        '    'lblTatTraget.Text = "98.0"
        'ElseIf CampaignID = 289 Then
        '    Label1.Text = "Start Date : "
        '    lblcmpstartdate.Text = " 03-Nov-2012"
        'Else
        '    Label1.Text = ""
        '    lblcmpstartdate.Text = ""
        '    'lblAccuracyTarget.Text = "97.50"
        '    'lblTatTraget.Text = "97.97"
        'End If
    End Sub
    'Protected widestdata As Integer = 0
    Protected Sub GridView1_RowDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles GridView1.RowDataBound
        If e.Row.RowType = DataControlRowType.DataRow Then
            If CboGroup.SelectedItem.Text = cboGroupBy2.SelectedItem.Text Then
                e.Row.Cells(1).Visible = False
            End If
            footerval(2) = footerval(2) + e.Row.Cells(2).Text
            footerval(3) = footerval(3) + e.Row.Cells(3).Text
            footerval(4) = footerval(4) + e.Row.Cells(4).Text
            footerval(5) = footerval(5) + e.Row.Cells(5).Text
            footerval(6) = footerval(6) + e.Row.Cells(6).Text
            footerval(7) = footerval(7) + e.Row.Cells(7).Text
            footerval(8) = footerval(8) + e.Row.Cells(8).Text
            footerval(9) = footerval(9) + e.Row.Cells(9).Text
            footerval(10) = footerval(10) + e.Row.Cells(10).Text
            footerval(11) = footerval(11) + e.Row.Cells(11).Text

            e.Row.Cells(8).Text = Common.TimeString(e.Row.Cells(2).Text / e.Row.Cells(4).Text)
            e.Row.Cells(2).Text = Common.TimeString(e.Row.Cells(2).Text)
            e.Row.Cells(9).Text = Math.Round(100 - ((e.Row.Cells(10).Text / e.Row.Cells(9).Text) * 100), 2)
            e.Row.Cells(3).Text = Common.TimeString(e.Row.Cells(3).Text)
            e.Row.Cells(10).Text = e.Row.Cells(10).Text
            e.Row.Cells(11).Text = Math.Round((e.Row.Cells(11).Text * 1.0 / e.Row.Cells(5).Text) * 100, 2)
        End If
        If e.Row.RowType = DataControlRowType.Footer Then
            If CboGroup.SelectedItem.Text = cboGroupBy2.SelectedItem.Text Then
                e.Row.Cells(1).Visible = False
            End If
            e.Row.Cells(0).Text = "Total :"
            e.Row.Cells(2).Text = Common.TimeString(footerval(2))
            e.Row.Cells(3).Text = Common.TimeString(footerval(3))
            e.Row.Cells(4).Text = footerval(4)
            e.Row.Cells(5).Text = footerval(5)
            e.Row.Cells(6).Text = footerval(6)
            e.Row.Cells(7).Text = footerval(7)
            e.Row.Cells(8).Text = Common.TimeString(footerval(2) / footerval(4))
            e.Row.Cells(9).Text = Math.Round(100 - ((footerval(10) / footerval(9)) * 100), 2)
            e.Row.Cells(10).Text = footerval(10)
            e.Row.Cells(11).Text = Math.Round((footerval(11) * 1.0 / footerval(5)) * 100, 2)
        End If
        If e.Row.RowType = DataControlRowType.Header Then
            e.Row.Cells(0).Text = CboGroup.SelectedItem.Text
            e.Row.Cells(1).Text = cboGroupBy2.SelectedItem.Text
            If CboGroup.SelectedItem.Text = cboGroupBy2.SelectedItem.Text Then
                e.Row.Cells(1).Visible = False
            End If
        End If
    End Sub
    Protected Sub GridView1_PreRender(ByVal sender As Object, ByVal e As System.EventArgs) Handles GridView1.PreRender
        If Not GridView1 Is Nothing Then
            If GridView1.HeaderRow Is Nothing Then
            Else

                GridView1.HeaderRow.TableSection = TableRowSection.TableHeader
                GridView1.FooterRow.TableSection = TableRowSection.TableFooter
            End If
        End If
    End Sub
    Protected Sub ImageButton1_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton1.Click
        setstartdate()
        fillgrid("%")
        GridViewExportUtil.Export(lblReportName.Text & "-" & LblError.Text & ".xls", Me.GridView1)
    End Sub

    Private Sub ExportToexcel()
        Dim tw As New IO.StringWriter()
        Dim hw As New System.Web.UI.HtmlTextWriter(tw)
        'Dim frm As HtmlForm = New HtmlForm()
        Response.ContentType = "application/vnd.ms-excel"
        Response.AddHeader("content-disposition", "attachment;filename=" & lblReportName.Text & "-" & LblError.Text & ".xls")
        Response.Charset = ""
        EnableViewState = False
        'Controls.Add(frm)
        GridView1.RenderControl(hw)
        Response.Write(tw.ToString())
        Response.End()
    End Sub
    Protected Sub CboGroup_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles CboGroup.SelectedIndexChanged
        setstartdate()
        fillgrid("%")
    End Sub

    'Protected Sub btnFilter_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnFilter.Click
    '    fillgrid()
    'End Sub

    Protected Sub btnRefresh_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnRefresh.Click
        setstartdate()
        fillgrid("%")
    End Sub
    'Protected Sub ucDateFrom_Changed(ByVal sender As Object, ByVal e As System.EventArgs) Handles ucDateFrom.Changed
    '    fillgrid()
    'End Sub
    'Protected Sub UcDateTo_Changed(ByVal sender As Object, ByVal e As System.EventArgs) Handles UcDateTo.Changed
    '    fillgrid()
    'End Sub

    Protected Sub CboProcess_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles CboProcess.SelectedIndexChanged
        ProcessID = CboProcess.SelectedValue
        Common.FillCampaigns(cboCampaigns, AgentID, CboProcess.SelectedValue)
        CampaignID = cboCampaigns.SelectedValue
        setstartdate()
        fillgrid("%")
    End Sub
    Protected Sub CboPeriod_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles CboPeriod.SelectedIndexChanged
        If CboPeriod.SelectedValue = 10 Then
            ucDateFrom.Visible = True
            UcDateTo.Visible = True
            lblAnd.Visible = True
            setstartdate()
            fillgrid("%")
        Else
            ucDateFrom.Visible = False
            UcDateTo.Visible = False
            lblAnd.Visible = False
            setstartdate()
            fillgrid("%")
        End If
    End Sub

    Protected Sub imgfav_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles imgfav.Click
        Common.AddToFav(AgentID, "Campaign Summary")
        SuccessMessage("Report has been added to your favourite list")
        setstartdate()
        fillgrid("%")
    End Sub
#Region "Utility"

    Private Sub AlertMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMFail"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub

    Private Sub SuccessMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMSuccess"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub

    'Protected Sub ImageButton1_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton1.Click
    '    'fillgrid()
    '    GridViewExportUtil.Export(lblReportName.CurrentPage & "-" & LblError.Text & ".xls", Me.GdAttendance)
    'End Sub


    Public Overrides Sub VerifyRenderingInServerForm(ByVal Control As Control)

    End Sub

#End Region
   
    Protected Sub cboFilterBy_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboFilterBy.SelectedIndexChanged
        fillgrid(cboFilterBy.SelectedItem.Text)
    End Sub

    Protected Sub cboGroupBy2_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboGroupBy2.SelectedIndexChanged
        fillgrid("%")
    End Sub
End Class
