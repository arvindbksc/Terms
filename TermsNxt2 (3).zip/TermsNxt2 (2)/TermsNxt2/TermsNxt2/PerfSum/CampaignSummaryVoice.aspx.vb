﻿Imports com.nss.DBAccess
Imports System.Data
Imports System.Text
Partial Class PerfSum_CampaignSummaryVoice
    Inherits System.Web.UI.Page
    Dim footerval(23) As Double
    Dim rows As Integer
    Dim col As Integer
    Dim footerval1(23) As Double
    Dim dtAll As DataTable
#Region "Properties"

    Property ReportType() As Integer
        Get
            Return ViewState("ReportType")
        End Get
        Set(ByVal value As Integer)
            ViewState("ReportType") = value
        End Set
    End Property
    Property CampaignID() As Integer
        Get
            Return ViewState("CampaignID")
        End Get
        Set(ByVal value As Integer)
            ViewState("CampaignID") = value
        End Set
    End Property

    Property AgentID() As String
        Get
            Return ViewState("AgentID")
        End Get
        Set(ByVal value As String)
            ViewState("AgentID") = value
        End Set
    End Property
    Property Campaigntype() As Integer
        Get
            Return ViewState("Campaigntype")
        End Get
        Set(ByVal value As Integer)
            ViewState("Campaigntype") = value
            'Session("ProcessID") = value
        End Set
    End Property
    Property dttotal() As DataTable
        Get
            Return ViewState("dttotal")
        End Get
        Set(ByVal value As DataTable)
            ViewState("dttotal") = value
        End Set
    End Property
#End Region
#Region "Load"
    Private Sub LoadData()
        FillCommonFilters()
        FillProcessCampaigns()
    End Sub
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            ReportType = Request.QueryString("ReportType")
            If Session("AgentID") <> "" Then
                If Not Request.QueryString("Campaign") Is Nothing Then
                    Session("CampaignID") = Request.QueryString("Campaign")
                End If
                'CampaignID = Session("CampaignID")
                AgentID = Session("AgentID")
                PanelReports.Controls.Add(Common.GetMenu(Request.Url, AgentID, Request.ApplicationPath))
                LoadData()
                'fillgrid()
                fillData()
                UcDateTo.Visible = False
                ucDateFrom.Visible = False
                lblAnd.Visible = False
            End If
        End If
    End Sub
    Private Sub fillData()
        Dim db As New DBAccess
        Dim startday As Integer, endday As Integer
        If CboPeriod.SelectedValue = 10 Then
            startday = ucDateFrom.yyyymmdd
            endday = UcDateTo.yyyymmdd
        Else
            db = New DBAccess
            db.slDataAdd("Period", CboPeriod.SelectedValue)
            db.slDataAdd("Campaignid", CampaignID)
            Dim dr As DataRow = db.ReturnRow("usp_GetStart_EndDateForAPeriod", True)
            db = Nothing
            startday = dr(0)
            endday = dr(1)
        End If

        'db = New DBAccess
        'Dim dt As DataTable
        'db.slDataAdd("StartDate", startday)
        'db.slDataAdd("EndDate", endday)
        'db.slDataAdd("userid", AgentID)
        'db.slDataAdd("processid", CboProcess.SelectedValue)
        'db.slDataAdd("campaignid", cboCampaigns.SelectedValue)
        'db.slDataAdd("GroupBy", CboGroup1.SelectedValue)
        'dt = db.ReturnTable("usp_AttendanceHistoryCampaign", , True)
        'db = Nothing
        'Dim row As DataRow = dt.NewRow
        'row(0) = -1
        'row(1) = "GrandTotal"
        'dt.Rows.Add(row)
        ''lblReportName.Text = " Attendance History "
        'reptgroupby.DataSource = dt
        'reptgroupby.DataBind()
        'dt = Nothing

        db = New DBAccess
        Dim dtAttribute As DataTable
        db.slDataAdd("StartDate", startday)
        db.slDataAdd("EndDate", endday)
        db.slDataAdd("userid", AgentID)
        db.slDataAdd("processid", CboProcess.SelectedValue)
        db.slDataAdd("campaignid", cboCampaigns.SelectedValue)
        db.slDataAdd("GroupBy", CboGroup1.SelectedValue)
        dtAttribute = db.ReturnTable("usp_AttendanceHistoryCampaign", , True)
        db = Nothing


        db = New DBAccess
        ' Dim dt As DataTable
        db.slDataAdd("startday", startday)
        db.slDataAdd("endday", endday)
        db.slDataAdd("userid", AgentID)
        db.slDataAdd("processid", CboProcess.SelectedValue)
        db.slDataAdd("campaignid", cboCampaigns.SelectedValue)
        db.slDataAdd("GroupBy", CboGroup.SelectedValue)    'for   --Second filters ---         Campaign,Team,Agent,Day,Hour
        db.slDataAdd("GroupBy2", CboGroup1.SelectedValue)  ' for   --first filter --        Campaign,Team,Hour 
        dtAll = db.ReturnTable("usp_CampaignPerformanceTerms2_VoiceCampaign_New", , True)
        db = Nothing

        '----------------------------------------------------------------
        Dim dtRepeater As DataTable

        If CboGroup1.SelectedValue = 4 Then  ' from first filter it is "Hour" among   --      Campaign,Team,Hour 
            Dim distCol() As String = {"GroupBy2"}
            dtRepeater = dtAll.DefaultView.ToTable(True, distCol)

            dtRepeater.Columns(0).ColumnName = "id"
            dtRepeater.Columns.Add("name", Type.GetType("System.Int32"))
            dtRepeater.Columns.Add("name2", Type.GetType("System.String"))

            For i As Integer = 0 To dtRepeater.Rows.Count - 1
                dtRepeater.Rows(i)("name") = dtRepeater.Rows(i)("id")
                dtRepeater.Rows(i)("name2") = dtRepeater.Rows(i)("id")
            Next

            If dtRepeater.Rows.Count > 0 Then
                dtRepeater = dtRepeater.Select("1=1", "name ASC").CopyToDataTable
                dtRepeater.Columns.Remove("name")
                dtRepeater.Columns("name2").ColumnName = "name"
            End If

        Else  ' from first filter it is "Campaign,Team" among   --      Campaign,Team,Hour 
            dtRepeater = dtAttribute

            'Dim row As DataRow = dtRepeater.NewRow
            'row(0) = -1
            'row(1) = "GrandTotal"
            'dtRepeater.Rows.Add(row)
        End If
        '----------------------------------------------------------------

        'Dim col_second As String = dtAll.Columns(1).ColumnName  ' to get columnname of second column  i.e. campaign or agent or team or day or hour
        'Dim distCol() As String = {"GroupBy2", col_second}
        'Dim dtRepeater As DataTable = dtAll.DefaultView.ToTable(True, distCol)

        'dtRepeater.Columns(0).ColumnName = "id"
        'dtRepeater.Columns(1).ColumnName = "name"

        'dtRepeater.Columns.Add("name", Type.GetType("System.String"))

        'For i As Integer = 0 To dtRepeater.Rows.Count - 1
        '    dtRepeater.Rows(i)("name") = dtRepeater.Rows(i)("id")
        'Next
        '----------------------------------------------------------------

        Dim row As DataRow = dtRepeater.NewRow
        row(0) = -1
        row(1) = "GrandTotal"
        dtRepeater.Rows.Add(row)

        reptgroupby.DataSource = dtRepeater 'this is change
        reptgroupby.DataBind()
        dtAll = Nothing

    End Sub
#End Region

#Region "Function"
    Private Sub FillCommonFilters()
        Dim db As New DBAccess
        Dim dt As DataTable = db.ReturnTable("select * from tbl_Reports_DatePeriods")
        db = Nothing
        Dim dr As DataRow = dt.NewRow
        dr(0) = 10
        dr(1) = "Between"
        dt.Rows.Add(dr)
        CboPeriod.DataTextField = "Caption"
        CboPeriod.DataValueField = "Period"
        CboPeriod.DataSource = dt
        CboPeriod.DataBind()
        dt = Nothing
        db = New DBAccess
        dt = db.ReturnTable("Select * from tbl_Reports_GroupBy")
        db = Nothing
        CboGroup.DataTextField = "Caption"
        CboGroup.DataValueField = "ID"
        CboGroup.DataSource = dt
        CboGroup.DataBind()
    End Sub
    Private Function IntegerToDateString(ByVal d As Integer) As String
        Return d.ToString.Substring(0, 4) & "-" & d.ToString.Substring(4, 2) & "-" & d.ToString.Substring(6, 2)
    End Function
    Private Sub FillProcessCampaigns()
        'Common.FillProcessCampaigns(CboProcess, cboCampaigns, AgentID, CampaignID)
        Common.FillProcesses(CboProcess, AgentID)
        'Common.FillProcessCampaigns(CboProcess, cboCampaigns, AgentID, CampaignID)
        Dim lstprocess As New ListItem
        lstprocess.Value = 0
        lstprocess.Text = "All"
        If CboProcess.Items.Contains(lstprocess) Then
            CboProcess.Items.Remove(lstprocess)
        End If
        Dim db As New DBAccess
        db.slDataAdd("Agentid", AgentID)
        CboProcess.SelectedValue = db.ReturnRow("usp_getAgentProcess", True)(4)
        db = Nothing
        Common.FillCampaigns(cboCampaigns, AgentID, CboProcess.SelectedValue)
    End Sub
#End Region
#Region "gridops"
    Dim dgdata As GridView
    Dim hasdata As Boolean = False
    Protected Sub reptgroupby_ItemDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.RepeaterItemEventArgs) Handles reptgroupby.ItemDataBound

        Dim dt As DataTable = Nothing

        Dim lblcampaign As Label = e.Item.FindControl("lblcampaign")
        Dim lblcampid As Label = e.Item.FindControl("lblcampid")
        'Dim columns As String

        Dim db As New DBAccess
        Dim startday As Integer, endday As Integer
        If CboPeriod.SelectedValue = 10 Then
            startday = ucDateFrom.yyyymmdd
            endday = UcDateTo.yyyymmdd
        Else
            db = New DBAccess
            db.slDataAdd("Period", CboPeriod.SelectedValue)
            db.slDataAdd("Campaignid", cboCampaigns.SelectedValue)
            Dim dr As DataRow = db.ReturnRow("usp_GetStart_EndDateForAPeriod", True)
            db = Nothing
            startday = dr(0)
            endday = dr(1)
        End If

        db = New DBAccess
        db.slDataAdd("processid", CboProcess.SelectedValue)
        db.slDataAdd("Campaignid", cboCampaigns.SelectedValue)
        db.slDataAdd("userid", AgentID)
        Dim dtcampaigntype As DataTable = db.ReturnTable("usp_getcampaigntype", , True)
        db = Nothing
        If dtcampaigntype.Rows.Count > 1 Then
            Campaigntype = 1
        Else
            Campaigntype = dtcampaigntype.Rows(0).Item(0)
        End If
        db = Nothing


        Dim rowsVain() As DataRow = dtAll.Select("GroupBy2='" & lblcampid.Text & "'")
        If rowsVain.Length > 0 Then
            dt = dtAll.Select("GroupBy2='" & lblcampid.Text & "'").CopyToDataTable()
            If dt.Rows.Count > 0 Then  'for ascending according to second column
                dt = dt.Select("1=1", dt.Columns(1).ColumnName & " ASC").CopyToDataTable
            End If
        End If

        If Not dt Is Nothing Then
            Dim dt2 As DataTable = dt.Copy
            dt2.Columns.Remove("GroupBy2")  '--remove the  "GroupBy2" column from actual dt
            dt = dt2

        ElseIf dt Is Nothing Then     '--if dt is NULL
            dt = dtAll.Clone
            dt.Columns.Remove("GroupBy2")
        End If

        'db = New DBAccess
        'db.slDataAdd("userid", AgentID)
        'db.slDataAdd("startday", startday)
        'db.slDataAdd("endDay", endday)

        'If CampaignID = 0 And CboGroup1.SelectedValue = 0 Then
        '    db.slDataAdd("campaignid", lblcampid.Text)
        'Else
        '    db.slDataAdd("campaignid", cboCampaigns.SelectedValue)
        'End If

        'If CboGroup1.SelectedValue = 1 Then
        '    db.slDataAdd("supervisorid", lblcampid.Text)
        'Else
        '    db.slDataAdd("supervisorid", "%")
        'End If

        'db.slDataAdd("GroupBy2", lblcampid.Text)  ' --rajkumar 21-May-2014 Added
        ''rajkumar  --- also check for another groupBY  -- for CampaignID and SupervisorID as they are HardCode

        'db.slDataAdd("processid", CboProcess.SelectedValue)
        'db.slDataAdd("groupBy", CboGroup.SelectedValue)

        'If Campaigntype = 11 Then
        '    ' dt = db.ReturnTable("usp_CampaignPerformanceTerms2_VoiceCampaign", , True)
        '    dt = db.ReturnTable("usp_CampaignPerformanceTerms2_VoiceCampaign_New", , True)
        'Else
        '    dt = db.ReturnTable("usp_CampaignPerformanceTerms2", , True)
        'End If
        'db = Nothing

        rows = dt.Rows.Count

        If rows > 0 Then
            hasdata = True
        End If

        dttotal = dt.Clone
        lblReportName.Text = CboGroup.SelectedItem.Text & " wise Performance Summary "
        LblError.Text = "Between " & IntegerToDateString(startday) & "  and " & IntegerToDateString(endday) & " for " & cboCampaigns.SelectedItem.Text & " campaign"

        dgdata = e.Item.FindControl("GridView1")

        If hasdata = True Then
            If lblcampaign.Text <> "GrandTotal" Then
                'Dim dgdata1 As GridView = e.Item.FindControl("GridView2")
                rowcount = 0
                AddHandler dgdata.RowDataBound, AddressOf gridRowDataBound
                dgdata.AutoGenerateColumns = False
                CreateGridColumns(dt.Columns)
                If dt.Rows.Count > 0 Then
                    dgdata.DataSource = dt
                    dgdata.DataBind()
                    If Campaigntype = 11 Then

                        If CboGroup.SelectedValue <> 4 Then
                            dgdata.Columns(20).Visible = False
                            dgdata.Columns(22).Visible = False
                        End If
                        If CboGroup.SelectedValue = 1 Then
                            dgdata.Columns(1).Visible = False
                            'dgdata.Columns(22).Visible = False
                        End If
                    Else
                        'dgdata.Columns(6).Visible = False
                        If CboGroup.SelectedValue <> 4 Then
                            dgdata.Columns(12).Visible = False
                            dgdata.Columns(14).Visible = False
                        End If
                    End If

                Else
                    lblcampaign.Visible = False
                    dgdata.Visible = False
                End If
            Else
                col = dttotal.Columns.Count
                lblcampaign.Visible = False
                Dim row As DataRow = dttotal.NewRow
                If CboGroup.SelectedValue = 1 Then
                    row.Item(1) = 254
                    For i As Integer = 2 To footerval1.Length - (footerval1.Length - col + 1)
                        row.Item(i) = footerval1(i)
                    Next
                Else
                    For i As Integer = 1 To footerval1.Length - (footerval1.Length - col + 1)
                        row.Item(i) = footerval1(i)
                    Next
                End If
                dttotal.Rows.Add(row)
                AddHandler dgdata.RowDataBound, AddressOf gridRowDataBoundGrandTotal
                dgdata.AutoGenerateColumns = False
                CreateGridColumnsGrandTotal(dttotal.Columns)
                dgdata.DataSource = dttotal
                dgdata.DataBind()
                dgdata.HeaderRow.Cells(0).Text = ""
                ' dgdata.HeaderRow.Visible = False
                If Campaigntype = 11 Then

                    If CboGroup.SelectedValue <> 4 Then
                        dgdata.Columns(20).Visible = False
                        dgdata.Columns(22).Visible = False
                    End If
                    If CboGroup.SelectedValue = 1 Then
                        dgdata.Columns(1).Visible = False
                        'dgdata.Columns(22).Visible = False
                    End If
                Else
                    'dgdata.Columns(6).Visible = False
                    If CboGroup.SelectedValue <> 4 Then
                        dgdata.Columns(12).Visible = False
                        dgdata.Columns(14).Visible = False
                    End If
                End If
                dgdata.RowStyle.Font.Bold = True
            End If
        Else
            lblcampaign.Visible = False
            dgdata.Visible = False
        End If
    End Sub
    Private Sub gridRowDataBoundGrandTotal(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs)
        If Campaigntype = 11 Then
            If e.Row.RowType = DataControlRowType.Header Then
                If CboGroup.SelectedValue <> 4 Then
                    e.Row.Cells(18).Text = "NFAR Score<br />[%]"
                    e.Row.Cells(19).Text = "FAR Score<br />[%]"
                    e.Row.Cells(21).Text = "OverAll Score<br />[%]"
                    'e.Row.Cells(19).Visible = False
                End If
                'For i As Integer = 0 To e.Row.Cells.Count - 1
                '    e.Row.Cells(i).Text = ""
                'Next
                e.Row.Visible = False
            End If
            If e.Row.RowType = DataControlRowType.Footer Then
                e.Row.Visible = False
            End If
            If e.Row.RowType = DataControlRowType.DataRow Then
                If CboGroup.SelectedValue = 1 Then
                    e.Row.Cells(0).Text = "Summary: Agent Count " + totoalagents.ToString()
                Else
                    e.Row.Cells(0).Text = "Summary: "
                End If

                'If CboGroup.SelectedValue = 1 Then
                '    e.Row.Cells(0).Width = 220
                'Else
                '    e.Row.Cells(0).Width = 100
                'End If
                e.Row.Cells(0).Style.Add("text-align", "left")
                'If CboGroup.SelectedValue = 3 Then
                '    e.Row.Cells(1).Text = Math.Ceiling(footerval1(1) / dgdata.Rows.Count)
                'Else
                '    e.Row.Cells(1).Text = footerval1(1)
                'End If
                e.Row.Cells(1).Text = footerval1(1)
                'e.Row.Cells(2).Text = Math.Round(footerval1(2) / 3600.0, 2)
                e.Row.Cells(2).Text = Common.TimeString(footerval1(2))
                e.Row.Cells(3).Text = Common.TimeString(footerval1(3))
                'e.Row.Cells(4).Text = Math.Round(footerval1(4) / 1.0, 2)
                e.Row.Cells(4).Text = Common.TimeString(footerval1(4))
                e.Row.Cells(5).Text = Common.TimeString(footerval1(5))
                e.Row.Cells(6).Text = Common.TimeString(footerval1(6))
                e.Row.Cells(7).Text = footerval1(7)
                e.Row.Cells(8).Text = footerval1(8)
                e.Row.Cells(9).Text = footerval1(9)
                e.Row.Cells(10).Text = footerval1(10)
                e.Row.Cells(11).Text = Math.Round((footerval1(7) / (footerval1(2) / 3600 * 1.0)), 2)
                e.Row.Cells(12).Text = Math.Round((footerval1(8) / (footerval1(2) / 3600 * 1.0)), 2)
                If footerval(7) = 0.0 Then
                    e.Row.Cells(13).Text = "00:00:00"
                Else
                    e.Row.Cells(13).Text = Common.TimeString(footerval1(13) / footerval1(7))
                End If
                e.Row.Cells(14).Text = Math.Round((footerval1(9) / (footerval1(2) / 3600 * 1.0)), 2)
                e.Row.Cells(15).Text = Math.Round((footerval1(9) / footerval1(10)) * 100, 2)
                e.Row.Cells(16).Text = Math.Round((footerval1(7) / footerval1(9)) * 100, 2)
                If CboGroup.SelectedValue <> 4 Then
                    e.Row.Cells(17).Text = footerval1(17)
                    If footerval1(17) = 0 Then
                        e.Row.Cells(18).Text = ""
                        e.Row.Cells(19).Text = ""
                    Else
                        If footerval1(18) = 0 Then
                            e.Row.Cells(18).Text = 100
                        Else
                            e.Row.Cells(18).Text = Math.Round(100 - ((footerval1(19) / footerval1(18)) * 100), 2)
                        End If
                        e.Row.Cells(19).Text = Math.Round(100 - ((footerval1(20) / footerval1(17)) * 100), 2)
                    End If
                    e.Row.Cells(20).Text = footerval1(20)
                    If footerval1(21) <= "0" Then
                        e.Row.Cells(21).Text = "0"
                    Else
                        'If footerval1(20) > "0" Then
                        '    e.Row.Cells(21).Text = Math.Round(0 / (footerval1(21) * 100), 2)
                        'Else
                        e.Row.Cells(21).Text = Math.Round((footerval1(22) / footerval1(21)) * 100, 2)
                        'End If
                        ' e.Row.Cells(21).Text = e.Row.Cells(21).Text
                        ' e.Row.Cells(22).Text = e.Row.Cells(22).Text
                    End If
                End If
            End If
        Else
            If e.Row.RowType = DataControlRowType.Header Then
                For i As Integer = 0 To e.Row.Cells.Count - 1
                    e.Row.Cells(i).Text = ""
                Next
                e.Row.Visible = False
                'e.Row.Cells(7).Text = "TPH/CPH"
                'If CboGroup.SelectedValue <> 4 Then
                '    e.Row.Cells(10).Text = "NFAR Score<br />[%]"
                '    e.Row.Cells(11).Text = "FAR Score<br />[%]"
                '    e.Row.Cells(13).Text = "OverAll Score<br />[%]"
                'End If
            End If
            If e.Row.RowType = DataControlRowType.Footer Then
                e.Row.Visible = False
            End If
            If e.Row.RowType = DataControlRowType.DataRow Then
                'If CboGroup.SelectedValue = 1 Then
                '    e.Row.Cells(0).Text = "Summary: Agent Count " + totoalagents.ToString()
                'Else
                e.Row.Cells(0).Text = "Summary: "
                'End If

                e.Row.Cells(1).Text = footerval1(1)
                e.Row.Cells(2).Text = Common.TimeString(footerval1(2))
                e.Row.Cells(3).Text = Common.TimeString(footerval1(3))
                e.Row.Cells(4).Text = Common.TimeString(footerval1(4))
                e.Row.Cells(5).Text = footerval1(5)
                e.Row.Cells(6).Text = footerval1(6)
                'e.Row.Cells(7).Text = footerval1(7)
                If footerval1(2) = 0 Then
                    e.Row.Cells(7).Text = "N.A" 'CPH
                Else
                    e.Row.Cells(7).Text = Math.Round((footerval1(5) / footerval1(2)) * 3600, 2) 'CPH
                End If
                If footerval1(5) = "0" Then
                    e.Row.Cells(8).Text = "N.A"
                Else
                    e.Row.Cells(8).Text = Common.TimeString(footerval1(3) / footerval1(5)) 'AHT
                End If
                If CboGroup.SelectedValue <> 4 Then
                    e.Row.Cells(9).Text = footerval1(9)
                    If footerval1(9) = 0 Then
                        e.Row.Cells(10).Text = ""
                        e.Row.Cells(11).Text = ""
                    Else
                        If footerval1(10) = 0 Then
                            e.Row.Cells(10).Text = 100
                        Else
                            e.Row.Cells(10).Text = Math.Round(100 - ((footerval1(11) / footerval1(10)) * 100), 2)
                        End If
                        e.Row.Cells(11).Text = Math.Round(100 - ((footerval1(12) / footerval1(9)) * 100), 2)
                    End If
                    e.Row.Cells(12).Text = footerval1(12)
                    If footerval1(13) <= "0" Then
                        e.Row.Cells(13).Text = ""
                    Else
                        e.Row.Cells(13).Text = Math.Round((footerval1(14) / footerval1(13)) * 100, 2)
                    End If
                End If
        End If
        End If
    End Sub
    Dim rowcount As Integer = 0
    Dim totoalagents As Integer = 0
    Private Sub gridRowDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs)
        If Campaigntype = 11 Then
            If e.Row.RowType = DataControlRowType.Header Then
                e.Row.TableSection = TableRowSection.TableHeader
                ScriptManager.RegisterStartupScript(Me, Me.GetType(), sender.ClientID.ToString, "$(function(){{$('#" & sender.ClientID & "').tablesorter({cancelSelection:true}); }});", True)

                For i As Integer = 0 To footerval.Length - 1
                    footerval(i) = 0
                Next
                If CboGroup.SelectedValue <> 4 Then
                    e.Row.Cells(18).Text = "NFAR Score<br />[%]"
                    e.Row.Cells(19).Text = "FAR Score<br />[%]"
                    e.Row.Cells(21).Text = "OverAll Score<br />[%]"
                    'e.Row.Cells(19).Visible = False
                End If
            End If
            If e.Row.RowType = DataControlRowType.DataRow Then
                rowcount += 1
                totoalagents += 1
                'If CboGroup.SelectedValue = 1 Then
                '    e.Row.Cells(0).Width = 220
                'Else
                '    e.Row.Cells(0).Width = 100
                'End If
                'dgdata.Columns(0).ItemStyle.Wrap = False
                e.Row.Cells(0).Style.Add("white-space", "nowrap")
                e.Row.Cells(0).Style.Add("text-align", "left")
                footerval(1) = footerval(1) + e.Row.Cells(1).Text
                footerval(2) = footerval(2) + e.Row.Cells(2).Text 'login hrs
                footerval(3) = footerval(3) + e.Row.Cells(3).Text 'Break duration
                footerval(4) = footerval(4) + e.Row.Cells(4).Text ' Talk duration
                footerval(5) = footerval(5) + e.Row.Cells(5).Text ' Wrap duration
                footerval(6) = footerval(6) + e.Row.Cells(6).Text ' Idle Duration
                footerval(7) = footerval(7) + e.Row.Cells(7).Text  ' Completes
                footerval(8) = footerval(8) + e.Row.Cells(8).Text  ' Part Completes
                footerval(9) = footerval(9) + e.Row.Cells(9).Text  ' Contacts
                footerval(10) = footerval(10) + e.Row.Cells(10).Text  ' Connects
                footerval(11) = footerval(11) + e.Row.Cells(11).Text  'CPH
                footerval(12) = footerval(12) + e.Row.Cells(12).Text  'PCPH
                footerval(13) = footerval(13) + e.Row.Cells(13).Text  'AHT
                footerval(14) = footerval(14) + e.Row.Cells(14).Text  'Contact per hour
                footerval(15) = footerval(15) + e.Row.Cells(15).Text  'Contact Rate
                footerval(16) = footerval(16) + e.Row.Cells(16).Text  'Conversion Rate  
                If CboGroup.SelectedValue <> 4 Then
                    footerval(17) = footerval(17) + e.Row.Cells(17).Text 'Call Monitored
                    footerval(18) = footerval(18) + e.Row.Cells(18).Text 'NFAR
                    footerval(19) = footerval(19) + e.Row.Cells(19).Text 'NFAR
                    footerval(20) = footerval(20) + e.Row.Cells(20).Text
                    footerval(21) = footerval(21) + e.Row.Cells(21).Text
                    footerval(22) = footerval(22) + e.Row.Cells(22).Text
                End If

                'footerval1(1) = footerval1(1) + e.Row.Cells(1).Text
                footerval1(2) = footerval1(2) + e.Row.Cells(2).Text
                footerval1(3) = footerval1(3) + e.Row.Cells(3).Text
                footerval1(4) = footerval1(4) + e.Row.Cells(4).Text
                footerval1(5) = footerval1(5) + e.Row.Cells(5).Text
                footerval1(6) = footerval1(6) + e.Row.Cells(6).Text
                footerval1(7) = footerval1(7) + e.Row.Cells(7).Text
                footerval1(8) = footerval1(8) + e.Row.Cells(8).Text
                footerval1(9) = footerval1(9) + e.Row.Cells(9).Text
                footerval1(10) = footerval1(10) + e.Row.Cells(10).Text
                footerval1(11) = footerval1(11) + e.Row.Cells(11).Text
                footerval1(12) = footerval1(12) + e.Row.Cells(12).Text
                footerval1(13) = footerval1(13) + e.Row.Cells(13).Text
                footerval1(14) = footerval1(14) + e.Row.Cells(14).Text
                footerval1(15) = footerval1(15) + e.Row.Cells(15).Text
                footerval1(16) = footerval1(16) + e.Row.Cells(16).Text
                If CboGroup.SelectedValue <> 4 Then
                    footerval1(17) = footerval1(17) + e.Row.Cells(17).Text 'Call Monitored
                    footerval1(18) = footerval1(18) + e.Row.Cells(18).Text 'NFAR
                    footerval1(19) = footerval1(19) + e.Row.Cells(19).Text 'NFAR
                    footerval1(20) = footerval1(20) + e.Row.Cells(20).Text
                    footerval1(21) = footerval1(21) + e.Row.Cells(21).Text
                    footerval1(22) = footerval1(22) + e.Row.Cells(22).Text
                End If
                'footerval1(2) = Math.Round(footerval1(2) / 3600.0, 2)
                'e.Row.Cells(2).Text = Math.Round((e.Row.Cells(2).Text / 3600.0), 2)
                e.Row.Cells(2).Text = Common.TimeString(e.Row.Cells(2).Text)
                e.Row.Cells(3).Text = Common.TimeString(e.Row.Cells(3).Text)
                'e.Row.Cells(4).Text = Math.Round((e.Row.Cells(4).Text / 1.0), 2)
                e.Row.Cells(4).Text = Common.TimeString(e.Row.Cells(4).Text)
                e.Row.Cells(5).Text = Common.TimeString(e.Row.Cells(5).Text)
                e.Row.Cells(6).Text = Common.TimeString(e.Row.Cells(6).Text)
                e.Row.Cells(11).Text = Math.Round((e.Row.Cells(11).Text / 1.0), 2)
                e.Row.Cells(12).Text = Math.Round((e.Row.Cells(12).Text / 1.0), 2)
                If e.Row.Cells(7).Text = "0" Then
                    e.Row.Cells(13).Text = "00:00:00"
                Else
                    e.Row.Cells(13).Text = Common.TimeString(e.Row.Cells(13).Text / e.Row.Cells(7).Text)
                End If

                e.Row.Cells(14).Text = Math.Round((e.Row.Cells(14).Text / 1.0), 2)
                e.Row.Cells(15).Text = Math.Round((e.Row.Cells(15).Text / 1.0) * 100, 2)
                e.Row.Cells(16).Text = Math.Round((e.Row.Cells(16).Text / 1.0) * 100, 2)
                If CboGroup.SelectedValue <> 4 Then
                    If e.Row.Cells(17).Text = "0" Then
                        e.Row.Cells(18).Text = ""
                        e.Row.Cells(19).Text = ""
                    Else
                        If e.Row.Cells(18).Text = "0" Then
                            e.Row.Cells(18).Text = 100
                        Else
                            e.Row.Cells(18).Text = Math.Round(100 - ((e.Row.Cells(19).Text / e.Row.Cells(18).Text) * 100), 2)
                        End If
                        e.Row.Cells(19).Text = Math.Round(100 - ((e.Row.Cells(20).Text / e.Row.Cells(17).Text) * 100), 2)
                    End If
                    If e.Row.Cells(21).Text <= "0" Then
                        e.Row.Cells(21).Text = "0"
                    Else
                        'If e.Row.Cells(20).Text > "0" Then
                        '    e.Row.Cells(21).Text = Math.Round((0 / e.Row.Cells(21).Text) * 100, 2)
                        'Else
                        e.Row.Cells(21).Text = Math.Round((e.Row.Cells(22).Text / e.Row.Cells(21).Text) * 100, 2)
                        'End If
                        'e.Row.Cells(21).Text = e.Row.Cells(21).Text
                        ' e.Row.Cells(22).Text = e.Row.Cells(22).Text
                    End If

                    ' e.Row.Cells(19).Visible = False
                End If

                '    e.Row.Cells(7).Text = Common.TimeString(e.Row.Cells(7).Text)

            ElseIf e.Row.RowType = DataControlRowType.Footer Then
                e.Row.TableSection = TableRowSection.TableFooter
                If CboGroup.SelectedValue = 1 Then
                    e.Row.Cells(0).Text = "Total: No. of Agents " + rowcount.ToString()
                Else
                    e.Row.Cells(0).Text = "Total: "
                End If

                If CboGroup.SelectedValue = 3 Or CboGroup.SelectedValue = 4 Then
                    e.Row.Cells(1).Text = Math.Ceiling(footerval(1) / dgdata.Rows.Count)

                Else
                    e.Row.Cells(1).Text = footerval(1)
                End If
                e.Row.Cells(0).Style.Add("text-align", "left")
                footerval1(1) = footerval1(1) + e.Row.Cells(1).Text
                'e.Row.Cells(1).Text = footerval(1)
                'e.Row.Cells(2).Text = Math.Round(footerval(2) / 3600.0, 2)
                e.Row.Cells(2).Text = Common.TimeString(footerval(2))
                e.Row.Cells(3).Text = Common.TimeString(footerval(3))
                'e.Row.Cells(4).Text = Math.Round(footerval(4) / 1.0, 2)
                e.Row.Cells(4).Text = Common.TimeString(footerval(4))
                e.Row.Cells(5).Text = Common.TimeString(footerval(5))
                e.Row.Cells(6).Text = Common.TimeString(footerval(6))
                e.Row.Cells(7).Text = footerval(7)
                e.Row.Cells(8).Text = footerval(8)
                e.Row.Cells(9).Text = footerval(9)
                e.Row.Cells(10).Text = footerval(10)
                e.Row.Cells(11).Text = Math.Round((footerval(7) / (footerval(2) / 3600 * 1.0)), 2)
                e.Row.Cells(12).Text = Math.Round((footerval(8) / (footerval(2) / 3600 * 1.0)), 2)
                If footerval(7) = 0.0 Then
                    e.Row.Cells(13).Text = "00:00:00"
                Else
                    e.Row.Cells(13).Text = Common.TimeString(footerval(13) / footerval(7))
                End If
                e.Row.Cells(14).Text = Math.Round((footerval(9) / (footerval(2) / 3600 * 1.0)), 2)
                e.Row.Cells(15).Text = Math.Round((footerval(9) / footerval(10)) * 100, 2)
                e.Row.Cells(16).Text = Math.Round((footerval(7) / footerval(9)) * 100, 2)
                If CboGroup.SelectedValue <> 4 Then
                    e.Row.Cells(17).Text = footerval(17)
                    If footerval(17) = 0 Then
                        e.Row.Cells(18).Text = ""
                        e.Row.Cells(19).Text = ""
                    Else
                        If footerval(18) = 0 Then
                            e.Row.Cells(18).Text = 100
                        Else
                            e.Row.Cells(18).Text = Math.Round(100 - ((footerval(19) / footerval(18)) * 100), 2)
                        End If
                        e.Row.Cells(19).Text = Math.Round(100 - ((footerval(20) / footerval(17)) * 100), 2)
                        If footerval(21) <= "0" Then
                            e.Row.Cells(21).Text = ""
                        Else
                            e.Row.Cells(21).Text = Math.Round((footerval(22) / footerval(21)) * 100, 2)
                        End If
                    End If
                    e.Row.Cells(20).Text = footerval(20)
                End If
            End If
        Else
            If e.Row.RowType = DataControlRowType.Header Then
                For i As Integer = 0 To footerval.Length - 1
                    footerval(i) = 0
                Next
                e.Row.TableSection = TableRowSection.TableHeader
                ScriptManager.RegisterStartupScript(Me, Me.GetType(), sender.ClientID.ToString, "$(function(){{$('#" & sender.ClientID & "').tablesorter({cancelSelection:true}); }});", True)

                e.Row.Cells(7).Text = "TPH/CPH"
                If CboGroup.SelectedValue <> 4 Then
                    e.Row.Cells(10).Text = "NFAR Score<br />[%]"
                    e.Row.Cells(11).Text = "FAR Score<br />[%]"
                    e.Row.Cells(13).Text = "OverAll Score<br />[%]"
                End If
            End If
            If e.Row.RowType = DataControlRowType.DataRow Then
                footerval(1) = footerval(1) + e.Row.Cells(1).Text
                footerval(2) = footerval(2) + e.Row.Cells(2).Text 'login hrs
                footerval(3) = footerval(3) + e.Row.Cells(3).Text 'transation duration
                footerval(4) = footerval(4) + e.Row.Cells(4).Text ' break duration
                footerval(5) = footerval(5) + e.Row.Cells(5).Text 'Transaction
                footerval(6) = footerval(6) + e.Row.Cells(6).Text ' Completes
                footerval(7) = footerval(7) + e.Row.Cells(7).Text

                'footerval(0) += 1
                If CboGroup.SelectedValue <> 4 Then
                    footerval(9) = footerval(9) + e.Row.Cells(9).Text 'Call Monitored
                    footerval(10) = footerval(10) + e.Row.Cells(10).Text 'NFAR
                    footerval(11) = footerval(11) + e.Row.Cells(11).Text 'NFAR
                    footerval(12) = footerval(12) + e.Row.Cells(12).Text
                    footerval(13) = footerval(13) + e.Row.Cells(13).Text
                    footerval(14) = footerval(14) + e.Row.Cells(14).Text
                End If
                If CboGroup.SelectedValue = 1 Then
                    footerval(15) = footerval(15) + e.Row.Cells(15).Text
                    footerval(16) = footerval(16) + e.Row.Cells(16).Text
                End If
                'footerval1(1) = footerval1(1) + e.Row.Cells(1).Text
                footerval1(2) = footerval1(2) + e.Row.Cells(2).Text 'login hrs
                footerval1(3) = footerval1(3) + e.Row.Cells(3).Text 'transation duration
                footerval1(4) = footerval1(4) + e.Row.Cells(4).Text ' break duration
                footerval1(5) = footerval1(5) + e.Row.Cells(5).Text 'Transaction
                footerval1(6) = footerval1(6) + e.Row.Cells(6).Text ' Completes
                footerval1(7) = footerval1(7) + e.Row.Cells(7).Text
                footerval(0) += 1
                If CboGroup.SelectedValue <> 4 Then
                    footerval1(9) = footerval1(9) + e.Row.Cells(9).Text 'Call Monitored
                    footerval1(10) = footerval1(10) + e.Row.Cells(10).Text 'NFAR
                    footerval1(11) = footerval1(11) + e.Row.Cells(11).Text 'NFAR
                    footerval1(12) = footerval1(12) + e.Row.Cells(12).Text
                    footerval1(13) = footerval1(13) + e.Row.Cells(13).Text
                    footerval1(14) = footerval1(14) + e.Row.Cells(14).Text
                End If
                If CboGroup.SelectedValue = 1 Then
                    footerval1(15) = footerval1(15) + e.Row.Cells(15).Text
                    footerval1(16) = footerval1(16) + e.Row.Cells(16).Text
                End If

                If e.Row.Cells(2).Text = "0" Then
                    e.Row.Cells(7).Text = "N.A"
                Else
                    e.Row.Cells(7).Text = Math.Round((e.Row.Cells(5).Text / e.Row.Cells(2).Text) * 3600, 2)
                End If

                If e.Row.Cells(5).Text = "0" Then
                    e.Row.Cells(8).Text = "N.A"
                Else
                    e.Row.Cells(8).Text = Common.TimeString(e.Row.Cells(3).Text / e.Row.Cells(5).Text) 'AHT
                End If


                e.Row.Cells(2).Text = Common.TimeString(e.Row.Cells(2).Text)
                e.Row.Cells(3).Text = Common.TimeString(e.Row.Cells(3).Text)
                e.Row.Cells(4).Text = Common.TimeString(e.Row.Cells(4).Text)
                If CboGroup.SelectedValue <> 4 Then
                    If e.Row.Cells(9).Text = "0" Then
                        e.Row.Cells(10).Text = ""
                        e.Row.Cells(11).Text = ""
                    Else
                        If e.Row.Cells(10).Text = "0" Then
                            e.Row.Cells(10).Text = 100
                        Else
                            e.Row.Cells(10).Text = Math.Round(100 - ((e.Row.Cells(11).Text / e.Row.Cells(10).Text) * 100), 2)
                        End If
                        e.Row.Cells(11).Text = Math.Round(100 - ((e.Row.Cells(12).Text / e.Row.Cells(9).Text) * 100), 2)
                    End If
                    If e.Row.Cells(13).Text <= "0" Then
                        e.Row.Cells(13).Text = ""
                    Else
                        e.Row.Cells(13).Text = Math.Round((e.Row.Cells(14).Text / e.Row.Cells(13).Text) * 100, 2)
                    End If
                End If
                If CboGroup.SelectedValue = 1 Then
                    e.Row.Cells(15).Text = Common.TimeString(e.Row.Cells(15).Text)
                    e.Row.Cells(16).Text = Common.TimeString(e.Row.Cells(16).Text)
                End If
            ElseIf e.Row.RowType = DataControlRowType.Footer Then
                e.Row.TableSection = TableRowSection.TableFooter
                e.Row.Cells(0).Text = "Total: " '& footerval(0)
                If CboGroup.SelectedValue = 3 Or CboGroup.SelectedValue = 4 Then
                    e.Row.Cells(1).Text = Math.Ceiling(footerval(1) / dgdata.Rows.Count)

                Else
                    e.Row.Cells(1).Text = footerval(1)
                End If
                'e.Row.Cells(1).Text = footerval(1)
                footerval1(1) = footerval1(1) + e.Row.Cells(1).Text
                e.Row.Cells(2).Text = Common.TimeString(footerval(2))
                e.Row.Cells(3).Text = Common.TimeString(footerval(3))
                e.Row.Cells(4).Text = Common.TimeString(footerval(4))

                e.Row.Cells(5).Text = footerval(5) 'transations
                e.Row.Cells(6).Text = footerval(6) 'completes
                If footerval(2) = 0 Then
                    e.Row.Cells(7).Text = "N.A" 'CPH
                Else
                    e.Row.Cells(7).Text = Math.Round((footerval(5) / footerval(2)) * 3600, 2) 'CPH
                End If
                If footerval(5) = 0 Then
                    e.Row.Cells(8).Text = "N.A" 'AHT
                Else
                    e.Row.Cells(8).Text = Common.TimeString(footerval(3) / footerval(5)) 'AHT
                End If
                If CboGroup.SelectedValue <> 4 Then
                    e.Row.Cells(9).Text = footerval(9)
                    If footerval(9) = 0 Then
                        e.Row.Cells(10).Text = ""
                        e.Row.Cells(11).Text = ""
                    Else
                        If footerval(10) = 0 Then
                            e.Row.Cells(10).Text = 100
                        Else
                            e.Row.Cells(10).Text = Math.Round(100 - ((footerval(11) / footerval(10)) * 100), 2)
                        End If
                        e.Row.Cells(11).Text = Math.Round(100 - ((footerval(12) / footerval(9)) * 100), 2)
                        If footerval(13) <= "0" Then
                            e.Row.Cells(13).Text = "0"
                        Else
                            e.Row.Cells(13).Text = Math.Round((footerval(14) / footerval(13)) * 100, 2)
                        End If
                    End If
                    e.Row.Cells(12).Text = footerval(12)
                    If CboGroup.SelectedValue = 1 Then
                        e.Row.Cells(15).Text = Common.TimeString(footerval(15))
                        e.Row.Cells(16).Text = Common.TimeString(footerval(16))
                    End If
                End If
            End If
        End If
    End Sub
    Private Sub CreateGridColumns(ByVal cols As DataColumnCollection)
        dgdata.Columns.Clear()
        'Dim tempcolumn As TemplateField
        Dim bouncol As BoundField
        Dim objcol As DataColumn
        For Each objcol In cols
            'If objcol.ColumnName = "Agents" Then
            '    tempcolumn = New TemplateField
            '    Dim tmpagcol As New TemplateAgentName
            '    tempcolumn.HeaderText = "Agents"
            '    tmpagcol.DataImageField = "AgentStatus"
            '    tmpagcol.DataTextField = objcol.ColumnName
            '    tempcolumn.ItemStyle.HorizontalAlign = HorizontalAlign.Left
            '    tempcolumn.ItemTemplate = tmpagcol
            '    tempcolumn.ItemStyle.Wrap = False
            '    dgdata.Columns.Add(tempcolumn)
            'Else
            If objcol.ColumnName <> "Agentstatus" Then
                bouncol = New BoundField
                bouncol.HeaderText = objcol.ColumnName
                bouncol.DataField = objcol.ColumnName
                dgdata.Columns.Add(bouncol)
            End If
            'End If
        Next
    End Sub
    Private Sub CreateGridColumnsGrandTotal(ByVal cols As DataColumnCollection)
        dgdata.Columns.Clear()
        'Dim tempcolumn As TemplateField
        Dim bouncol As BoundField
        Dim objcol As DataColumn
        For Each objcol In cols
            '    If objcol.ColumnName = "Agents" Then
            '        tempcolumn = New TemplateField
            '        Dim tmpagcol As New TemplateAgentName
            '        tempcolumn.HeaderText = "Agents"
            '        tmpagcol.DataImageField = "AgentStatus"
            '        tmpagcol.DataTextField = 1
            '        tempcolumn.ItemStyle.HorizontalAlign = HorizontalAlign.Left
            '        tempcolumn.ItemTemplate = tmpagcol
            '        dgdata.Columns.Add(tempcolumn)
            '    Else
            If objcol.ColumnName <> "Agentstatus" Then
                bouncol = New BoundField
                bouncol.HeaderText = objcol.ColumnName
                bouncol.DataField = objcol.ColumnName
                dgdata.Columns.Add(bouncol)
            End If
            'End If
        Next
    End Sub
#End Region
#Region "Events"
    Protected Sub cboCampaigns_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboCampaigns.SelectedIndexChanged
        CampaignID = cboCampaigns.SelectedValue
        fillData()
    End Sub
    Protected Sub CboGroup_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles CboGroup.SelectedIndexChanged
        fillData()
    End Sub
    'Protected Sub btnFilter_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnFilter.Click
    '    fillData()
    'End Sub
    Protected Sub btnRefresh_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnRefresh.Click
        fillData()
    End Sub
    Protected Sub CboProcess_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles CboProcess.SelectedIndexChanged

        Common.FillCampaigns(cboCampaigns, AgentID, CboProcess.SelectedValue)
        CampaignID = cboCampaigns.SelectedValue
        fillData()
    End Sub
    Protected Sub CboPeriod_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles CboPeriod.SelectedIndexChanged
        If CboPeriod.SelectedValue = 10 Then
            ucDateFrom.Visible = True
            UcDateTo.Visible = True
            lblAnd.Visible = True
            fillData()
        Else
            ucDateFrom.Visible = False
            UcDateTo.Visible = False
            lblAnd.Visible = False
            fillData()
        End If
    End Sub
    Protected Sub CboGroup1_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles CboGroup1.SelectedIndexChanged
        fillData()
    End Sub
#End Region
#Region "Not Use"
    'Private Sub fillgrid()

    '    For Each obj In footerval
    '        obj = 0
    '    Next
    '    'Dim columns As String
    '    Dim db As New DBAccess
    '    Dim startday As Integer, endday As Integer
    '    If CboPeriod.SelectedValue = 10 Then
    '        startday = ucDateFrom.yyyymmdd
    '        endday = UcDateTo.yyyymmdd
    '    Else
    '        db = New DBAccess
    '        db.slDataAdd("Period", CboPeriod.SelectedValue)
    '        db.slDataAdd("Campaignid", CampaignID)
    '        Dim dr As DataRow = db.ReturnRow("usp_GetStart_EndDateForAPeriod", True)
    '        db = Nothing
    '        startday = dr(0)
    '        endday = dr(1)
    '    End If

    '    db = New DBAccess
    '    Dim dt As DataTable
    '    db.slDataAdd("userid", AgentID)
    '    db.slDataAdd("startday", startday)
    '    db.slDataAdd("endDay", endday)
    '    db.slDataAdd("campaignid", CampaignID)
    '    db.slDataAdd("groupBy", CboGroup.SelectedValue)
    '    If cboFilterBy.SelectedItem.Text <> "None" And txtFilterValue.Text.Trim <> "" Then
    '        lblFilter.Text = "Filtered for " & cboFilterBy.SelectedItem.Text & " = " & txtFilterValue.Text
    '        If cboFilterBy.SelectedValue.Contains("String") Then
    '            'db.slDataAdd("Filterby", "'" & cboFilterBy.SelectedItem.Text & "'")
    '        End If
    '        db.slDataAdd("Filterby", cboFilterBy.SelectedItem.Text)
    '        db.slDataAdd("Filterbyvalue", txtFilterValue.Text)
    '    End If
    '    dt = db.ReturnTable("usp_CampaignPerformanceTerms2_VoiceCampaign", , True)
    '    rows = dt.Rows.Count
    '    'Dim dtime As Date
    '    'dtime = dr(0).ToString
    '    lblReportName.Text = CboGroup.SelectedItem.Text & " wise Performance Summary "
    '    LblError.Text = "Between " & IntegerToDateString(startday) & "  and " & IntegerToDateString(endday) & " for " & cboCampaigns.SelectedItem.Text & " campaign"

    '    db = Nothing
    '    'GridView1.AutoGenerateColumns = False
    '    'CreateGridColumns(dt.Columns)
    '    'GridView1.DataSource = dt
    '    'GridView1.DataBind()
    '    'If CboGroup.SelectedValue <> 4 Then
    '    '    GridView1.Columns(19).Visible = False
    '    'End If
    '    'System.Threading.Thread.Sleep(100)
    'End Sub

    'Private Sub CreateGridColumns(ByVal cols As DataColumnCollection)
    '    GridView1.Columns.Clear()
    '    Dim tempcolumn As TemplateField
    '    Dim bouncol As BoundField
    '    Dim objcol As DataColumn
    '    For Each objcol In cols
    '        If objcol.ColumnName = "Agents" Then
    '            tempcolumn = New TemplateField
    '            Dim tmpagcol As New TemplateAgentName
    '            tempcolumn.HeaderText = "Agents"
    '            tmpagcol.DataImageField = "AgentStatus"
    '            tmpagcol.DataTextField = objcol.ColumnName
    '            tempcolumn.ItemStyle.HorizontalAlign = HorizontalAlign.Left
    '            tempcolumn.ItemTemplate = tmpagcol
    '            GridView1.Columns.Add(tempcolumn)
    '        Else
    '            If objcol.ColumnName <> "Agentstatus" Then
    '                bouncol = New BoundField
    '                bouncol.HeaderText = objcol.ColumnName
    '                bouncol.DataField = objcol.ColumnName


    '                GridView1.Columns.Add(bouncol)
    '            End If

    '        End If

    '    Next

    'End Sub




    'Protected Sub GridView1_RowDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles GridView1.RowDataBound
    '    If e.Row.RowType = DataControlRowType.Header Then
    '        If CboGroup.SelectedValue <> 4 Then
    '            e.Row.Cells(17).Text = "NFAR Score<br />[%]"
    '            e.Row.Cells(18).Text = "FAR Score<br />[%]"
    '        End If
    '    End If
    '    If e.Row.RowType = DataControlRowType.DataRow Then
    '        footerval(1) = footerval(1) + e.Row.Cells(1).Text
    '        footerval(2) = footerval(2) + e.Row.Cells(2).Text 'login hrs
    '        footerval(3) = footerval(3) + e.Row.Cells(3).Text 'Break duration
    '        footerval(4) = footerval(4) + e.Row.Cells(4).Text ' Talk duration
    '        footerval(5) = footerval(5) + e.Row.Cells(5).Text ' Wrap duration
    '        footerval(6) = footerval(6) + e.Row.Cells(6).Text ' Completes
    '        footerval(7) = footerval(7) + e.Row.Cells(7).Text ' Part Completes
    '        footerval(8) = footerval(8) + e.Row.Cells(8).Text ' Contacts
    '        footerval(9) = footerval(9) + e.Row.Cells(9).Text ' Connects
    '        footerval(10) = footerval(10) + e.Row.Cells(10).Text 'CPH
    '        footerval(11) = footerval(11) + e.Row.Cells(11).Text 'PCPH
    '        footerval(12) = footerval(12) + e.Row.Cells(12).Text 'AHT
    '        footerval(13) = footerval(13) + e.Row.Cells(13).Text 'Contact per hour
    '        footerval(14) = footerval(14) + e.Row.Cells(14).Text 'Contact Rate
    '        footerval(15) = footerval(15) + e.Row.Cells(15).Text 'Conversion Rate
    '        If CboGroup.SelectedValue <> 4 Then
    '            footerval(16) = footerval(16) + e.Row.Cells(16).Text 'Call Monitored
    '            footerval(17) = footerval(17) + e.Row.Cells(17).Text 'NFAR
    '            footerval(18) = footerval(18) + e.Row.Cells(18).Text 'NFAR
    '            footerval(19) = footerval(19) + e.Row.Cells(19).Text
    '        End If

    '        '    footerval(0) += 1
    '        '    If e.Row.Cells(2).Text = 0 Then
    '        '        e.Row.Cells(10).Text = "N.A"
    '        '    Else
    '        '        e.Row.Cells(10).Text = Math.Round((e.Row.Cells(9).Text / e.Row.Cells(2).Text) * 3600, 2)
    '        '    End If

    '        '    If e.Row.Cells(5).Text = "0" Then
    '        '        e.Row.Cells(11).Text = "N.A"
    '        '    Else
    '        '        e.Row.Cells(11).Text = Common.TimeString(e.Row.Cells(3).Text / e.Row.Cells(8).Text) 'AHT
    '        '    End If


    '        e.Row.Cells(2).Text = Math.Round((e.Row.Cells(2).Text / 1.0), 2)
    '        e.Row.Cells(3).Text = Common.TimeString(e.Row.Cells(3).Text)
    '        e.Row.Cells(4).Text = Math.Round((e.Row.Cells(4).Text / 1.0), 2)
    '        e.Row.Cells(5).Text = Common.TimeString(e.Row.Cells(5).Text)
    '        e.Row.Cells(10).Text = Math.Round((e.Row.Cells(10).Text / 1.0), 2)
    '        e.Row.Cells(11).Text = Math.Round((e.Row.Cells(11).Text / 1.0), 2)
    '        If e.Row.Cells(6).Text = "0" Then
    '            e.Row.Cells(12).Text = "00:00:00"
    '        Else
    '            e.Row.Cells(12).Text = Common.TimeString(e.Row.Cells(12).Text / e.Row.Cells(6).Text)
    '        End If

    '        e.Row.Cells(13).Text = Math.Round((e.Row.Cells(13).Text / 1.0), 2)
    '        e.Row.Cells(14).Text = Math.Round((e.Row.Cells(14).Text / 1.0) * 100, 2)
    '        e.Row.Cells(15).Text = Math.Round((e.Row.Cells(15).Text / 1.0) * 100, 2)
    '        If CboGroup.SelectedValue <> 4 Then
    '            If e.Row.Cells(16).Text = "0" Then
    '                e.Row.Cells(17).Text = ""
    '                e.Row.Cells(18).Text = ""
    '            Else
    '                If e.Row.Cells(17).Text = "0" Then
    '                    e.Row.Cells(17).Text = 100
    '                Else
    '                    e.Row.Cells(17).Text = Math.Round(100 - ((e.Row.Cells(18).Text / e.Row.Cells(17).Text) * 100), 2)
    '                End If
    '                e.Row.Cells(18).Text = Math.Round(100 - ((e.Row.Cells(19).Text / e.Row.Cells(16).Text) * 100), 2)
    '            End If
    '        End If
    '        '    e.Row.Cells(7).Text = Common.TimeString(e.Row.Cells(7).Text)

    '    ElseIf e.Row.RowType = DataControlRowType.Footer Then
    '        e.Row.Cells(0).Text = "Total: "
    '        e.Row.Cells(1).Text = footerval(1)
    '        e.Row.Cells(2).Text = Math.Round(footerval(2) / 1.0, 2)
    '        e.Row.Cells(3).Text = Common.TimeString(footerval(3))
    '        e.Row.Cells(4).Text = Math.Round(footerval(4) / 1.0, 2)
    '        e.Row.Cells(5).Text = Common.TimeString(footerval(5))
    '        e.Row.Cells(6).Text = footerval(6)
    '        e.Row.Cells(7).Text = footerval(7)
    '        e.Row.Cells(8).Text = footerval(8)
    '        e.Row.Cells(9).Text = footerval(9)
    '        e.Row.Cells(10).Text = Math.Round(footerval(6) / footerval(2), 2)
    '        e.Row.Cells(11).Text = Math.Round(footerval(7) / footerval(2), 2)
    '        e.Row.Cells(12).Text = Common.TimeString(footerval(12) / footerval(6))
    '        e.Row.Cells(13).Text = Math.Round(footerval(8) / footerval(2), 2)
    '        e.Row.Cells(14).Text = Math.Round((footerval(8) / footerval(9)) * 100, 2)
    '        e.Row.Cells(15).Text = Math.Round((footerval(6) / footerval(8)) * 100, 2)
    '        If CboGroup.SelectedValue <> 4 Then
    '            e.Row.Cells(16).Text = footerval(16)
    '            If footerval(16) = 0 Then
    '                e.Row.Cells(17).Text = ""
    '                e.Row.Cells(18).Text = ""
    '            Else
    '                If footerval(17) = 0 Then
    '                    e.Row.Cells(17).Text = 100
    '                Else
    '                    e.Row.Cells(17).Text = Math.Round(100 - ((footerval(18) / footerval(17)) * 100), 2)
    '                End If
    '                e.Row.Cells(18).Text = Math.Round(100 - ((footerval(19) / footerval(16)) * 100), 2)
    '            End If

    '            e.Row.Cells(19).Text = footerval(19)
    '        End If
    '        '    If footerval(2) = 0 Then
    '        '        e.Row.Cells(10).Text = "N.A" 'CPH
    '        '    Else
    '        '        e.Row.Cells(10).Text = Math.Round((footerval(9) / footerval(2)) * 3600, 2) 'CPH
    '        '    End If
    '        '    If footerval(5) = 0 Then
    '        '        e.Row.Cells(11).Text = "N.A" 'AHT
    '        '    Else
    '        '        e.Row.Cells(11).Text = Common.TimeString(footerval(3) / footerval(8)) 'AHT
    '        '    End If

    '    End If
    'End Sub

    'Protected Sub ImageButton1_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton1.Click
    '    fillgrid()
    '    GridViewExportUtil.Export(lblReportName.Text & "-" & LblError.Text & ".xls", Me.GridView1)
    'End Sub
    'Private Sub ExportToexcel()
    '    Dim tw As New IO.StringWriter()
    '    Dim hw As New System.Web.UI.HtmlTextWriter(tw)
    '    'Dim frm As HtmlForm = New HtmlForm()
    '    Response.ContentType = "application/vnd.ms-excel"
    '    Response.AddHeader("content-disposition", "attachment;filename=" & lblReportName.Text & "-" & LblError.Text & ".xls")
    '    Response.Charset = ""
    '    EnableViewState = False
    '    'Controls.Add(frm)
    '    GridView1.RenderControl(hw)
    '    Response.Write(tw.ToString())
    '    Response.End()
    'End Sub

    'Protected Sub ucDateFrom_Changed(ByVal sender As Object, ByVal e As System.EventArgs) Handles ucDateFrom.Changed
    '    fillData()
    'End Sub
    'Protected Sub UcDateTo_Changed(ByVal sender As Object, ByVal e As System.EventArgs) Handles UcDateTo.Changed
    '    fillData()
    'End Sub
#End Region

    
   
    Protected Sub imgfav_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles imgfav.Click
        Common.AddToFav(AgentID, "Campaign Summary New")
        SuccessMessage("Report has been added to your favourite list")
        fillData()
    End Sub
#Region "Utility"

    Private Sub AlertMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMFail"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub

    Private Sub SuccessMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMSuccess"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub

    'Protected Sub ImageButton1_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton1.Click
    '    'fillgrid()
    '    GridViewExportUtil.Export(lblReportName.CurrentPage & "-" & LblError.Text & ".xls", Me.GdAttendance)
    'End Sub


    Public Overrides Sub VerifyRenderingInServerForm(ByVal Control As Control)

    End Sub

#End Region
End Class
