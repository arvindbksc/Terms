﻿Imports com.nss.DBAccess
Imports System.Data
Imports System.Web.UI.DataVisualization.Charting
Imports System.Drawing

Partial Class PerfSum_HPSDashboard
    Inherits System.Web.UI.Page
#Region "--- Properties ---"
    Property CampaignID() As Integer
        Get
            Return ViewState("CampaignID")
        End Get
        Set(ByVal value As Integer)
            ViewState("CampaignID") = value
            Session("CampaignID") = value
        End Set
    End Property
    Property AgentID() As String
        Get
            Return ViewState("AgentID")
        End Get
        Set(ByVal value As String)
            ViewState("AgentID") = value
        End Set
    End Property
    Property ChartPeriod() As Integer
        Get
            Return ViewState("ChartPeriod")
        End Get
        Set(ByVal value As Integer)
            ViewState("ChartPeriod") = value
        End Set
    End Property
    Property ChartGroupBy() As Integer
        Get
            Return ViewState("ChartGroupBy")
        End Get
        Set(ByVal value As Integer)
            ViewState("ChartGroupBy") = value
        End Set
    End Property
    Property Campaigntype() As Integer
        Get
            Return ViewState("Campaigntype")
        End Get
        Set(ByVal value As Integer)
            ViewState("Campaigntype") = value
        End Set
    End Property
    Property GroupBy() As Integer
        Get
            Return CboGroup.SelectedValue
        End Get
        Set(ByVal value As Integer)
            CboGroup.Items.FindByValue(value).Selected = True
        End Set
    End Property
#End Region
    Dim dtAHT, dtQuality, dtTAT, dtAbsent As DataTable
    Dim ds As DataSet
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            If Session("agentid") Is Nothing Then
                FormsAuthentication.SignOut()
            End If
            If Session("AgentID") <> "" Then
                CampaignID = Session("CampaignID")
                AgentID = Session("AgentID")
                LoadData()
                DrawChart()
                UcDateTo.Visible = False
                ucDateFrom.Visible = False
                lblAnd.Visible = False
            End If
        End If
    End Sub
#Region "--- Functions ---"
    Private Sub LoadData()
        FillCommonFilters()
        FillProcessCampaigns()
    End Sub
    Private Sub FillCommonFilters()
        Dim db As New DBAccess
        Dim dt As DataTable = db.ReturnTable("select * from tbl_Reports_DatePeriods")
        db = Nothing
        Dim dr As DataRow = dt.NewRow
        dr(0) = 10
        dr(1) = "Between"
        dt.Rows.Add(dr)
        CboPeriod.DataTextField = "Caption"
        CboPeriod.DataValueField = "Period"
        CboPeriod.DataSource = dt
        CboPeriod.DataBind()

        db = New DBAccess
        dt = db.ReturnTable("Select * from tbl_Reports_GroupBy")
        db = Nothing

        Dim dtrow() As DataRow = dt.Select("Caption IN('Campaign','Agent','Hour')")
        dt.Rows.Remove(dtrow(0))
        dt.Rows.Remove(dtrow(1))
        dt.Rows.Remove(dtrow(2))

        'Dim dr1 As DataRow = dt.NewRow
        'dr1(1) = 5
        'dr1(0) = "Questions"
        'dt.Rows.Add(dr1)
        'Dim dr2 As DataRow = dt.NewRow
        'dr2(1) = 6
        'dr2(0) = "Dispositions"
        'dt.Rows.Add(dr2)
        'Dim dr3 As DataRow = dt.NewRow
        'dr3(1) = 9
        'dr3(0) = "Sub Disposition"
        'dt.Rows.Add(dr3)
        CboGroup.DataTextField = "Caption"
        CboGroup.DataValueField = "ID"
        CboGroup.DataSource = dt
        CboGroup.DataBind()


    End Sub
    Private Sub FillProcessCampaigns()
        Common.FillProcessCampaigns(CboProcess, cboCampaigns, AgentID, CampaignID)
    End Sub
    Private Function IntegerToDateString(ByVal d As Integer) As String
        Return d.ToString.Substring(0, 4) & "-" & d.ToString.Substring(4, 2) & "-" & d.ToString.Substring(6, 2)
    End Function
    Private Sub FillData()
        Dim db As New DBAccess
        Dim startday As Integer, endday As Integer
        Dim sdate, edate As DateTime
        If CboPeriod.SelectedValue = 10 Then
            startday = ucDateFrom.yyyymmdd
            endday = UcDateTo.yyyymmdd
            sdate = ucDateFrom.value
            edate = UcDateTo.value
            ChartPeriod = DateDiff(DateInterval.Day, sdate, edate)
        Else
            db = New DBAccess
            db.slDataAdd("Period", CboPeriod.SelectedValue)
            db.slDataAdd("Campaignid", CampaignID)
            Dim dr As DataRow = db.ReturnRow("usp_GetStart_EndDateForAPeriod", True)
            db = Nothing
            startday = dr(0)
            endday = dr(1)
            sdate = IntegerToDateString(startday)
            edate = IntegerToDateString(endday)
            ChartPeriod = DateDiff(DateInterval.Day, sdate, edate)
        End If
        db = Nothing
        lblReportName.Text = cboCampaigns.SelectedItem.Text & " Dashboard Between " & IntegerToDateString(startday) & "  and " & IntegerToDateString(endday)
        ' GridView1.AutoGenerateColumns = True
        db = New DBAccess
        db.slDataAdd("startday", startday)
        db.slDataAdd("endDay", endday)
        db.slDataAdd("campaignid", CampaignID)
        db.slDataAdd("groupBy", CboGroup.SelectedValue)
        '----------------- AHT & Transaction
        dtAHT = db.ReturnTable("usp_CampaignPerformanceTerms2", , True)
        dtAHT.Columns.Remove("AHT")
        dtAHT.Columns.Add("AHT", System.Type.GetType("System.Double"), "iif([Transactions]=0,0, [Transaction Duration]/[Transactions])")
        ' dtAHT.Columns.Add("LoginHrs", System.Type.GetType("System.Double"), "[Login Duration]/3600")
        db = Nothing
        '----------------- FAR & NFAR
        Dim db1 As New DBAccess("CRM")
        db1.slDataAdd("StartDate", startday)
        db1.slDataAdd("EndDate", endday)
        db1.slDataAdd("campaignID", CampaignID)
        db1.slDataAdd("GroupBy", CboGroup.SelectedValue)
        dtQuality = db1.ReturnTable("usp_CustomDashboard_Quality", , True)
        db1 = Nothing
        '----------------- TAT
        db = New DBAccess
        db.slDataAdd("StartDate", startday)
        db.slDataAdd("EndDate", endday)
        db.slDataAdd("Campid", CampaignID)
        db.slDataAdd("GroupBy", CboGroup.SelectedValue)
        dtTAT = db.ReturnTable("usp_CustomDashboard_TAT", , True)
        db = Nothing
        '----------------- Absenteeism
        db = New DBAccess
        db.slDataAdd("StartDate", startday)
        db.slDataAdd("EndDate", endday)
        db.slDataAdd("processid", CboProcess.SelectedValue)
        db.slDataAdd("campaignid", CampaignID)
        db.slDataAdd("userid", AgentID)
        db.slDataAdd("groupBy", CboGroup.SelectedValue)
        dtAbsent = db.ReturnTable("usp_AttendanceSummary", , True)
        db = Nothing

        '----------------- Claim Amount Paid and Gender Wise Claim Amount Paid
        ' Added By Gaurav on 31st Dec'12 for Graph7 and Graph8
        db = New DBAccess
        ds = db.ReturnDataset("usp_getHPSdata", True)
        db = Nothing
    End Sub

#End Region
#Region "--- Draw Graph ---"
    Private Sub DrawChart()
        FillData()
        RenderGraph(Chart1, "AHT", "AHT")
        RenderGraph(Chart2, "Transactions", "TRANSACTION")
        RenderGraph(Chart3, "FAR", "FAR")
        RenderGraph(Chart4, "NFAR", "NFAR")
        RenderGraph(Chart5, "TAT %", "TAT MET")
        RenderGraph(Chart6, "Absenteeism Rate", "ABSENTEEISM RATE")
        RenderGraph(Chart7, "COUNTS", "CLAIM AMOUNT PAID")
        RenderGraph(Chart8, "Male", "GENDER WISE CLAIM AMOUNT PAID")
    End Sub
    Private Sub RenderGraph(ByVal charts As Chart, ByVal yValueMem As String, ByVal Title As String)
        Dim xValueMem As String = ""
        charts.Series.Clear()
        charts.Series.Add("series1")
        charts.ChartAreas(0).AxisX.IntervalAutoMode = DataVisualization.Charting.IntervalAutoMode.FixedCount
        charts.TextAntiAliasingQuality = DataVisualization.Charting.TextAntiAliasingQuality.High
        Dim mypane As System.Web.UI.DataVisualization.Charting.Series
        mypane = charts.Series(0)
        Select Case GroupBy
            Case 2
                charts.ChartAreas(0).AxisX.Title = "Teams"
                mypane.XValueType = DataVisualization.Charting.ChartValueType.String
            Case 3
                charts.ChartAreas(0).AxisX.Title = "Days"
                mypane.XValueType = DataVisualization.Charting.ChartValueType.Date
        End Select

        If charts.ClientID = "Chart6" Then
            charts.Series(0).ChartType = DataVisualization.Charting.SeriesChartType.Spline
            charts.Series(0).BorderWidth = 3
            charts.Series(0).Color = Drawing.Color.Red
            charts.Series(0).MarkerStyle = DataVisualization.Charting.MarkerStyle.Diamond
            charts.Series(0).MarkerSize = 6
            charts.Series(0).MarkerColor = Drawing.Color.White
            charts.Series(0).IsValueShownAsLabel = True

        Else
            charts.Series(0).ChartType = DataVisualization.Charting.SeriesChartType.Column
            charts.Series(0).MarkerColor = Drawing.Color.White
            charts.Series(0)("DrawingStyle") = "Cylinder"
            charts.Series(0).IsValueShownAsLabel = True
        End If
        'charts.ChartAreas(0).AxisX.LabelAutoFitStyle = DataVisualization.Charting.LabelAutoFitStyles.LabelsAngleStep30
        charts.ChartAreas(0).AxisX.MajorGrid.Enabled = False
        charts.ChartAreas(0).AxisY.MajorGrid.Enabled = False

        If CboGroup.SelectedValue = 3 Then
            If ChartPeriod <= 30 Then
                charts.ChartAreas(0).AxisX.LabelStyle.Interval = 1
            End If
            If ChartPeriod <= 30 And ChartPeriod >= 14 Then
                charts.ChartAreas(0).AxisX.LabelStyle.Interval = 7
            End If
            If ChartPeriod >= 90 Then
                charts.ChartAreas(0).AxisX.LabelStyle.Interval = 30
            ElseIf ChartPeriod > 14 Then
                charts.ChartAreas(0).AxisX.LabelStyle.Interval = 7
            End If
        End If
        

        If charts.ClientID = "Chart1" Or charts.ClientID = "Chart2" Then
            charts.DataSource = dtAHT.DefaultView
            xValueMem = dtAHT.Columns(0).ColumnName
        ElseIf charts.ClientID = "Chart3" Or charts.ClientID = "Chart4" Then
            charts.DataSource = dtQuality.DefaultView
            xValueMem = dtQuality.Columns(0).ColumnName
        ElseIf charts.ClientID = "Chart5" Then
            charts.DataSource = dtTAT.DefaultView
            xValueMem = dtTAT.Columns(0).ColumnName
        ElseIf charts.ClientID = "Chart6" Then
            charts.DataSource = dtAbsent.DefaultView
            If charts.ClientID = "Chart6" And GroupBy = 2 Then
                xValueMem = dtAbsent.Columns(1).ColumnName
            Else
                xValueMem = dtAbsent.Columns(0).ColumnName
            End If
        ElseIf charts.ClientID = "Chart7" Then
            charts.DataSource = ds.Tables(0)
            xValueMem = ds.Tables(0).Columns(0).ColumnName
            Chart7.Series(0).XValueMember = xValueMem
            Chart7.Series(0).YValueMembers = yValueMem
            Chart7.Legends.Add("Legent1")
            Chart7.Legends("Legent1").Enabled = True
            Chart7.Legends("Legent1").Alignment = System.Drawing.StringAlignment.Near
            Chart7.Series(0).IsVisibleInLegend = True
        End If
        With Chart8
            .Series.Clear()
            .Series.Add("Male")
            .Series.Add("Female")
            With .Series(0)
                .XValueMember = "ProviderName"
                .YValueMembers = "Female"
                .ChartType = DataVisualization.Charting.SeriesChartType.Column
                .BorderWidth = 4
                .Color = Drawing.Color.Blue
                .BackGradientStyle = DataVisualization.Charting.GradientStyle.VerticalCenter
                .BackSecondaryColor = Drawing.Color.SkyBlue
                .IsValueShownAsLabel = True
            End With
            With .Series(1)
                .XValueMember = "ProviderName"
                .YValueMembers = "Female"
                .ChartType = DataVisualization.Charting.SeriesChartType.Column
                .BorderWidth = 4
                .Color = Drawing.Color.OrangeRed
                .BackGradientStyle = DataVisualization.Charting.GradientStyle.VerticalCenter
                .BackSecondaryColor = Drawing.Color.DarkOrange
                .IsValueShownAsLabel = True
            End With
            .DataSource = ds.Tables(1)
            .DataBind()
        End With
        charts.DataBind()
        Chart7.Series(0).ChartType = DataVisualization.Charting.SeriesChartType.Pie
        Chart7.Series(0)("PieLabelStyle") = "outside"
        Chart7.Series(0).ShadowOffset = 1
        Chart7.Series(0)("PieDrawingStyle") = "Concave"

        If charts.ClientID = "Chart6" Then
            charts.Titles.Add(Title)
            charts.Series(0).XValueMember = xValueMem
            charts.Series(0).YValueMembers = yValueMem
            charts.Series(0).LabelFormat = "{0:n}"
        Else

            charts.Titles.Add(Title)
            charts.Series(0).XValueMember = xValueMem
            charts.Series(0).YValueMembers = yValueMem
            charts.Series(0).LabelFormat = "{0:n}"
            'Dim random As New Random()
            'For Each Item As DataPoint In charts.Series(0).Points
            '    Dim c As Color = Color.FromArgb(random.[Next](0, 255), random.[Next](0, 255), random.[Next](0, 255))
            '    Item.Color = c
            'Next
        End If

    End Sub
#End Region
#Region "--- Events ---"
    Protected Sub cboCampaigns_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboCampaigns.SelectedIndexChanged
        CampaignID = cboCampaigns.SelectedValue
        DrawChart()
        'FillGraph()
    End Sub
    Protected Sub ImageButton1_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton1.Click
        DrawChart()
    End Sub
    Protected Sub CboPeriod_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles CboPeriod.SelectedIndexChanged
        If CboPeriod.SelectedValue = 10 Then
            ucDateFrom.Visible = True
            UcDateTo.Visible = True
            lblAnd.Visible = True
            ChartPeriod = ucDateFrom.yyyymmdd - UcDateTo.yyyymmdd
            DrawChart()
        Else
            ucDateFrom.Visible = False
            UcDateTo.Visible = False
            lblAnd.Visible = False
            DrawChart()
        End If
    End Sub
    Protected Sub CboGroup_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles CboGroup.SelectedIndexChanged
        DrawChart()
    End Sub
    Protected Sub ucDateFrom_Changed(ByVal sender As Object, ByVal e As System.EventArgs) Handles ucDateFrom.Changed
        DrawChart()
    End Sub
    Protected Sub UcDateTo_Changed(ByVal sender As Object, ByVal e As System.EventArgs) Handles UcDateTo.Changed
        DrawChart()
    End Sub
#End Region
End Class
