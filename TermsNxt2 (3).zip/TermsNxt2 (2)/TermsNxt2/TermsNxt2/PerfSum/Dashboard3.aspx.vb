﻿Imports com.nss.DBAccess
Imports System.Web.UI.DataVisualization.Charting
Imports System.Data
Imports System.Web
Imports System.Drawing
Imports System.Web.UI
Imports System.Web.Services
Imports System.Web.Services.WebService
Partial Class PerfSum_Desboard3
    Inherits System.Web.UI.Page
#Region "Properties"
    Property CampaignID() As Integer
        Get
            Return ViewState("CampaignID")
        End Get
        Set(ByVal value As Integer)
            ViewState("CampaignID") = value
            Session("CampaignID") = value
        End Set
    End Property
    Property AgentID() As String
        Get
            Return ViewState("AgentID")
        End Get
        Set(ByVal value As String)
            ViewState("AgentID") = value
        End Set
    End Property
    Property ChartGroupBy() As Integer
        Get
            Return ViewState("ChartGroupBy")
        End Get
        Set(ByVal value As Integer)
            ViewState("ChartGroupBy") = value
        End Set
    End Property
    Property CurMonth() As Integer
        Get
            Return ViewState("CurMonth")
        End Get
        Set(ByVal value As Integer)
            ViewState("CurMonth") = value
        End Set
    End Property
#End Region
#Region "--- Support Functions ---"
    Private Sub FillMenu()
        Dim dt As New DataTable
        'Dim col1 As DataColumn
        dt.Columns.Add("displayName", Type.GetType("System.String"))
        dt.Columns.Add("HomePage", Type.GetType("System.String"))
        dt.Columns.Add("sequence", Type.GetType("System.String"))

        Dim row2 As DataRow
        row2 = dt.NewRow
        row2(0) = "Performance"
        row2(1) = "perfsum/CampaignSummary_Demo.aspx?groupby=0&period=3"
        row2(2) = "1"
        dt.Rows.Add(row2)

        row2 = dt.NewRow
        row2(0) = "Staffing"
        row2(1) = "Staffing/Roster/Roster_Demo.aspx"
        row2(2) = "2"
        dt.Rows.Add(row2)

        row2 = dt.NewRow
        row2(0) = "Forcasting"
        row2(1) = "perfsum/Forcasting.aspx"
        row2(2) = "3"
        dt.Rows.Add(row2)


        'row2 = dt.NewRow
        'row2(0) = "Analysis"
        'row2(1) = "Graphs/HPSGraph.aspx"
        'row2(2) = "5"
        'dt.Rows.Add(row2)

        'Dim db As DBAccess
        'Dim db As New DBAccess
        'db.slDataAdd("userid", AgentID)
        'Dim dt As DataTable = db.ReturnTable("usp_getUserModule", , True)
        'db = Nothing


        Dim tbl As New HtmlTable
        tbl.Attributes.Add("class", "menu")
        tbl.CellPadding = 4
        tbl.CellSpacing = 4
        Dim tr As HtmlTableRow
        Dim td As HtmlTableCell
        For Each row As DataRow In dt.Rows
            tr = New HtmlTableRow
            td = New HtmlTableCell
            td.InnerHtml = "<a href='../" & row.Item(1) & "'><div class='item'><span class='left'>" & row.Item(0)
            td.InnerHtml += "</span><span class='right'><img src='../_assets/img/graygo.PNG' /></span></div></a>"
            tr.Cells.Add(td)
            tbl.Rows.Add(tr)
        Next

        'db = New DBAccess
        'db.slDataAdd("userid", AgentID)
        'Dim dtfav As DataTable = db.ReturnTable("usp_getUserfavourite", , True)
        'db = Nothing

        Dim dtfav As New DataTable
        'Dim col1 As DataColumn
        dtfav.Columns.Add("Name", Type.GetType("System.String"))
        dtfav.Columns.Add("shortURL", Type.GetType("System.String"))

        Dim row3 As DataRow

        row3 = dtfav.NewRow
        row3(0) = "Forcasting"
        row3(1) = "perfsum/Forcasting.aspx"
        'row3(2) = "3"
        dtfav.Rows.Add(row3)

        If dtfav.Rows.Count > 0 Then
            tr = New HtmlTableRow
            td = New HtmlTableCell
            td.Attributes.Add("class", "heading")

            td.InnerHtml = "<div class='heading'><span class='left'>My Favourites</span></div>"
            tr.Cells.Add(td)
            tbl.Rows.Add(tr)
            For Each row As DataRow In dtfav.Rows
                tr = New HtmlTableRow
                td = New HtmlTableCell
                td.InnerHtml = "<a href='../" & row.Item(1) & "'><div class='item'><span class='left'>" & row.Item(0)
                td.InnerHtml += "</span><span class='right'><img src='../_assets/img/graygo.PNG' /></span></div></a>"
                tr.Cells.Add(td)
                tbl.Rows.Add(tr)
            Next
        End If
        'divmenu.Controls.Add(tbl)
       

    End Sub
    
    Private Function IntegerToDateString(ByVal d As Integer) As String
        Return d.ToString.Substring(0, 4) & "-" & d.ToString.Substring(4, 2) & "-" & d.ToString.Substring(6, 2)
    End Function
    Dim dtIncommingCall, dtInterval, dt, dtAHt As DataTable
    Dim dsData As DataSet
    Private Sub FillData()
        Dim db As New DBAccess("CRM")
        db.slDataAdd("Datefrom", dateFrom.Value)
        db.slDataAdd("Dateto", dateTo.Value)
        db.slDataAdd("Groupby", cboperiod.SelectedValue)
        dsData = db.ReturnDataset("usp_GetDemoDashBoard", True)
        db = Nothing
        dt = dsData.Tables(0)
        dtIncommingCall = dsData.Tables(1)
        dtInterval = dsData.Tables(2)
        dtAHt = dsData.Tables(3)
        If dt.Rows.Count > 0 Then
            'lblCallRcvd.Text = dt.Rows(0).Item("CallReceived")
            'lblA1.Text = dt.Rows(0).Item("Call Abondoned")
            'lblA2.Text = dt.Rows(0).Item("Call Abondoned Percent")
            'lblASA.Text = dt.Rows(0).Item("ASA")
            'lblAHT.Text = dt.Rows(0).Item("AHT")
            'lblCallAns.Text = dt.Rows(0).Item("% Calls Ans 30 Sec")
            'lblTmPrsent.Text = dt.Rows(0).Item("TM's Present")
            'lblAbsent.Text = dt.Rows(0).Item("TM's Absent")
            'If lblA2.Text < 5 Then
            '    lblA2.ForeColor = Color.Green
            '    lblA1.ForeColor = Color.Green
            'Else
            '    lblA2.ForeColor = Color.Red
            '    lblA1.ForeColor = Color.Red
            'End If
            'If lblCallAns.Text < 80 Then
            '    lblCallAns.ForeColor = Color.Red
            'Else
            '    lblCallAns.ForeColor = Color.Green
            'End If
            'If lblAHT.Text < 300 Then
            '    lblAHT.Text = Common.TimeString(lblAHT.Text)
            '    lblAHT.ForeColor = Color.Green
            'Else
            '    lblAHT.Text = Common.TimeString(lblAHT.Text)
            '    lblAHT.ForeColor = Color.Red
            'End If
        End If
        
    End Sub
    <WebMethod()> _
    Public Shared Function GetData(ByVal datefrom As String, ByVal dateto As String, ByVal groupby As Int32) As String()
        Dim ds As New DataSet
        Dim db As New DBAccess("CRM")
        db.slDataAdd("datefrom", datefrom)
        db.slDataAdd("dateto", dateto)
        db.slDataAdd("GroupBy", groupby)
        ds = db.ReturnDataset("usp_GetDemoDashBoard", True)
        Dim sjData(ds.Tables.Count) As String
        Dim i As Integer = 0
        For Each dt As DataTable In ds.Tables
            If ds.Tables(i).Rows.Count > 0 Then
                sjData(i) = GetJson(ds.Tables(i))
            End If

            i += 1
        Next
        Return sjData
    End Function

    <WebMethod()> _
    Public Shared Function getAgentStatus() As String
        Dim dt As New DataTable
        Dim db As New DBAccess("CRM")
        dt = db.ReturnTable("usp_DemoAgentStatus", , True)
        Dim sjData As String = ""
        Dim i As Integer = 0
        If dt.Rows.Count > 0 Then
            sjData = GetJson(dt)
        End If
        Return sjData
    End Function
    <WebMethod()> _
    Public Shared Function getStatusAgent(ByVal status As String) As String
        Dim dt As New DataTable
        Dim db As New DBAccess("CRM")
        db.slDataAdd("status", status)
        dt = db.ReturnTable("usp_DemoGetStatusAgent", , True)
        Dim sjData As String = ""
        Dim i As Integer = 0
        If dt.Rows.Count > 0 Then
            sjData = GetJson(dt)
        End If
        Return sjData
    End Function
    Public Shared Function GetJson(ByVal dt As DataTable) As String
        Dim serializer As New System.Web.Script.Serialization.JavaScriptSerializer()
        serializer.MaxJsonLength = Integer.MaxValue

        Dim rows As New List(Of Dictionary(Of String, Object))()
        Dim row As Dictionary(Of String, Object) = Nothing
        Dim row2 As Dictionary(Of Integer, Object) = Nothing
        For Each dr As DataRow In dt.Rows
            row = New Dictionary(Of String, Object)()
            row2 = New Dictionary(Of Integer, Object)()
            For Each dc As DataColumn In dt.Columns
                row.Add(dc.ColumnName.Trim(), dr(dc))
            Next
            rows.Add(row)
        Next
        Return serializer.Serialize(rows)
    End Function
   
#End Region
    
    '#Region "--- Draw Graph ---"
    '    Private Sub DrawChart()
    '        FillData()
    '        'RenderGraph(Chart4, "Day", "Monthly Volume ")
    '        'RenderGraph(Chart8, "Hour", "Daily Hourly Wise Volume")
    '        'RenderGraph(Chart5, "Hour", "Daily Hourly Wise AHT")
    '    End Sub
    '    Private Sub RenderGraph(ByVal charts As Chart, ByVal yValueMem As String, ByVal Title As String)
    '        Dim xValueMem As String = ""
    '        charts.Series.Clear()
    '        charts.Series.Add("series1")
    '        charts.ChartAreas(0).AxisX.IntervalAutoMode = DataVisualization.Charting.IntervalAutoMode.FixedCount
    '        charts.TextAntiAliasingQuality = DataVisualization.Charting.TextAntiAliasingQuality.High
    '        Dim mypane As System.Web.UI.DataVisualization.Charting.Series
    '        mypane = charts.Series(0)
    '        If charts.ClientID = "Chart4" Then
    '            charts.Series(0).ChartType = DataVisualization.Charting.SeriesChartType.Line
    '            'charts.Series(0).MarkerStyle = DataVisualization.Charting.MarkerStyle.Diamond
    '            'charts.Series(0).MarkerSize = 3
    '            charts.Series(0).MarkerColor = Drawing.Color.White
    '            charts.Series(0)("DrawingStyle") = "Cylinder"
    '            charts.Series(0).IsValueShownAsLabel = True
    '            charts.ChartAreas(0).AxisY.Interval = 20
    '            charts.ChartAreas(0).AxisY.IsStartedFromZero = False
    '            '--- Add New Series
    '            'charts.Series.Add("day")
    '            'charts.Series.Add("CallReceived")
    '            'charts.Series(1).BorderWidth = 2
    '            'charts.Series(1).Color = Color.Green
    '            'charts.Series(1).XValueMember = dtIncommingCall.Columns(0).ColumnName
    '            'charts.Series(1).YValueMembers = dtIncommingCall.Columns(1).ColumnName
    '            'charts.Series(1).ChartType = DataVisualization.Charting.SeriesChartType.Line
    '            'charts.Series(1).BorderDashStyle = ChartDashStyle.Dash
    '            'charts.Series(1).MarkerStyle = DataVisualization.Charting.MarkerStyle.Diamond
    '            'charts.Series(1).MarkerSize = 6
    '            'charts.Series(1).MarkerColor = Drawing.Color.Yellow
    '            'charts.Series(1).IsValueShownAsLabel = True
    '        ElseIf charts.ClientID = "Chart5" Then
    '            charts.Series(0).ChartType = DataVisualization.Charting.SeriesChartType.Line
    '            'charts.Series(1).ChartType = DataVisualization.Charting.SeriesChartType.Line
    '            'charts.Series(0).BorderWidth = 3
    '            charts.Series(0)("DrawingStyle") = "Cylinder"
    '            charts.Series(0).Color = Drawing.Color.GreenYellow
    '            charts.Series(0).IsValueShownAsLabel = False
    '            charts.Series.Add("forcast AHT")
    '            charts.Series(1).BorderWidth = 2
    '            charts.Series(1).Color = Color.Red
    '            charts.Series(1).ChartType = DataVisualization.Charting.SeriesChartType.Line
    '            ' charts.Series(1).BorderDashStyle = ChartDashStyle.Dash
    '            charts.Series(1)("DrawingStyle") = "Cylinder"
    '            charts.Series(1).MarkerStyle = DataVisualization.Charting.MarkerStyle.Diamond
    '            charts.Series(1).MarkerSize = 6
    '            charts.Series(1).MarkerColor = Drawing.Color.Yellow
    '            charts.Series(1).IsValueShownAsLabel = False
    '        ElseIf charts.ClientID = "Chart8" Then
    '            charts.Series(0).ChartType = DataVisualization.Charting.SeriesChartType.Column
    '            'charts.Series(1).ChartType = DataVisualization.Charting.SeriesChartType.Line
    '            'charts.Series(0).BorderWidth = 3
    '            charts.Series(0)("DrawingStyle") = "Cylinder"
    '            charts.Series(0).Color = Drawing.Color.Green
    '            'charts.Series(1).MarkerStyle = DataVisualization.Charting.MarkerStyle.Diamond
    '            'charts.Series(1).MarkerSize = 3
    '            'charts.Series(1).MarkerColor = Drawing.Color.White
    '            'charts.Series(1).IsValueShownAsLabel = True
    '            'charts.ChartAreas(0).AxisY.IsStartedFromZero = False
    '            '--- Add New Series
    '            'charts.Series.Add("CallReceived")
    '            charts.Series.Add("forcast")
    '            charts.Series(1).BorderWidth = 2
    '            charts.Series(1).Color = Color.White
    '            'charts.Series(1).XValueMember = dtInterval.Columns(1).ColumnName
    '            'charts.Series(1).YValueMembers = dtInterval.Columns(0).ColumnName
    '            charts.Series(1).ChartType = DataVisualization.Charting.SeriesChartType.Line
    '            ' charts.Series(1).BorderDashStyle = ChartDashStyle.Dash
    '            charts.Series(1).MarkerStyle = DataVisualization.Charting.MarkerStyle.Diamond
    '            charts.Series(1).MarkerSize = 6
    '            charts.Series(1).MarkerColor = Drawing.Color.Yellow
    '            charts.Series(1).IsValueShownAsLabel = False
    '        End If
    '        charts.Series(0).IsValueShownAsLabel = True
    '        charts.Series(0).IsVisibleInLegend = True
    '        charts.Series(0).MarkerColor = Drawing.Color.White
    '        charts.ChartAreas(0).AxisX.MajorGrid.Enabled = False
    '        charts.ChartAreas(0).AxisY.MajorGrid.Enabled = False

    '        If charts.ClientID = "Chart4" Then
    '            charts.DataSource = dtIncommingCall.DefaultView
    '            xValueMem = dtIncommingCall.Columns(0).ColumnName
    '            yValueMem = dtIncommingCall.Columns(1).ColumnName
    '        ElseIf charts.ClientID = "Chart5" Then
    '            charts.DataSource = dtAHt.DefaultView
    '            xValueMem = dtAHt.Columns(0).ColumnName
    '            yValueMem = dtAHt.Columns(1).ColumnName
    '            charts.Series(1).XValueMember = dtAHt.Columns(0).ColumnName
    '            charts.Series(1).YValueMembers = dtAHt.Columns(2).ColumnName
    '        ElseIf charts.ClientID = "Chart8" Then
    '            charts.DataSource = dtInterval.DefaultView
    '            xValueMem = dtInterval.Columns(0).ColumnName
    '            yValueMem = dtInterval.Columns(1).ColumnName
    '            charts.Series(1).XValueMember = dtInterval.Columns(0).ColumnName
    '            charts.Series(1).YValueMembers = dtInterval.Columns(2).ColumnName
    '        End If
    '        charts.DataBind()
    '        charts.Titles.Add(Title)
    '        charts.Series(0).XValueMember = xValueMem
    '        charts.Series(0).YValueMembers = yValueMem

    '        'charts.Series(0).LabelFormat = "{0:n}"

    '    End Sub
    '#End Region

End Class
