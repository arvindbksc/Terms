﻿Imports com.nss.DBAccess
Imports System.Data
Imports System.Text
Partial Class PerfSum_CampaignSummary_Demo
    Inherits System.Web.UI.Page
    Dim footerval(27) As Double
    Dim breakCounter As Integer = 0
#Region "Properties"
    Property ProcessID() As Integer
        Get
            Return ViewState("ProcessID")
        End Get
        Set(ByVal value As Integer)
            ViewState("ProcessID") = value
            Session("ProcessID") = value
        End Set
    End Property
    Property Campaigntype() As Integer
        Get
            Return ViewState("Campaigntype")
        End Get
        Set(ByVal value As Integer)
            ViewState("Campaigntype") = value
        End Set
    End Property
    Property Period() As Integer
        Get
            Return ViewState("Period")
        End Get
        Set(ByVal value As Integer)
            ViewState("Period") = value
        End Set
    End Property
    Property ReportType() As Integer
        Get
            Return ViewState("ReportType")
        End Get
        Set(ByVal value As Integer)
            ViewState("ReportType") = value
        End Set
    End Property
    Property CampaignID() As Integer
        Get
            Return ViewState("CampaignID")
        End Get
        Set(ByVal value As Integer)
            ViewState("CampaignID") = value
        End Set
    End Property
    Property AgentID() As String
        Get
            Return ViewState("AgentID")
        End Get
        Set(ByVal value As String)
            ViewState("AgentID") = value
        End Set
    End Property
#End Region

    Private Sub LoadData()
        FillCommonFilters()
        'FillProcessCampaigns()
        'If CboProcess.SelectedItem.Text = "HPS" Then
        '    CboPeriod.SelectedValue = 3
        'End If
    End Sub
    Private Sub FillCommonFilters()
        Dim db As New DBAccess
        Dim dt As DataTable = db.ReturnTable("select * from tbl_Reports_DatePeriods")
        db = Nothing
        Dim dr As DataRow = dt.NewRow
        dr(0) = 10
        dr(1) = "Between"
        dt.Rows.Add(dr)
        CboPeriod.DataTextField = "Caption"
        CboPeriod.DataValueField = "Period"
        CboPeriod.DataSource = dt
        CboPeriod.DataBind()

        db = New DBAccess
        'dt = db.ReturnTable("Select * from tbl_Reports_GroupBy")
        dt = db.ReturnTable("Select * from tbl_Reports_GroupBy  WHERE Caption NOT IN ('Team') ")
        db = Nothing
        CboGroup.DataTextField = "Caption"
        CboGroup.DataValueField = "ID"
        If dt.Rows.Count > 0 Then
            For Each row As DataRow In dt.Rows
                If row("Caption") = "Hour" Then
                    row("Caption") = "Half Hour"
                End If
            Next
        End If

        CboGroup.DataSource = dt
        CboGroup.DataBind()
        'Period = Request.QueryString("period")
        'CboPeriod.SelectedValue = Period

    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        HumanMessage.Style.Item("visibility") = "hidden"
        If Session("agentid") Is Nothing Then
            FormsAuthentication.SignOut()
        End If
        If Not IsPostBack Then
            ReportType = Request.QueryString("ReportType")
            If Session("AgentID") <> "" Then
                If Not Request.QueryString("Campaign") Is Nothing Then
                    Session("CampaignID") = Request.QueryString("Campaign")
                End If
                CampaignID = Session("CampaignID")
                AgentID = Session("AgentID")
                PanelReports.Controls.Add(Common.GetMenu(Request.Url, AgentID, Request.ApplicationPath))
                LoadData()
                CboGroup.SelectedValue = 4 '' to set initially the selected value of hour  (now half hour)
                fillgrid()
                UcDateTo.Visible = False
                ucDateFrom.Visible = False
                lblAnd.Visible = False
            End If
        End If
    End Sub
    Private Sub fillgrid()
        For Each obj In footerval
            obj = 0
        Next
        'Dim columns As String
        Dim db As New DBAccess
        Dim startday As Integer, endday As Integer
        If CboPeriod.SelectedValue = 10 Then
            startday = ucDateFrom.yyyymmdd
            endday = UcDateTo.yyyymmdd
        Else
            db = New DBAccess
            db.slDataAdd("Period", CboPeriod.SelectedValue)
            db.slDataAdd("Campaignid", cboCampaigns.SelectedValue)
            Dim dr As DataRow = db.ReturnRow("usp_GetStart_EndDateForAPeriod", True)
            db = Nothing
            startday = dr(0)
            endday = dr(1)
        End If
        db = New DBAccess
        db.slDataAdd("processid", CboProcess.SelectedValue)
        db.slDataAdd("Campaignid", cboCampaigns.SelectedValue)
        db.slDataAdd("userid", AgentID)
        Dim dtcampaigntype As DataTable = db.ReturnTable("usp_getcampaigntype", , True)
        db = Nothing
        If dtcampaigntype.Rows.Count > 1 Then
            Campaigntype = 1
        Else
            Campaigntype = dtcampaigntype.Rows(0).Item(0)
        End If

        'CboGroup.SelectedValue = 1

        db = New DBAccess("CRM")
        Dim dt As New DataTable
        'db.slDataAdd("userid", AgentID)
        db.slDataAdd("DateFrom", startday)
        db.slDataAdd("DateTo", endday)
        'db.slDataAdd("campaignid", cboCampaigns.SelectedValue)
        db.slDataAdd("groupBy", CboGroup.SelectedValue)
       
        ' db.slDataAdd("Processid", CboProcess.SelectedValue)

        'If Campaigntype = 11 Then
        '    dt = db.ReturnTable("usp_CampaignPerformanceTerms2_VoiceCampaign_Demo", "", True)
        '    'dt.Rows(0).Item(0) = "TEST"
        'Else
        '    dt = db.ReturnTable("usp_CampaignPerformanceTerms2", , True)
        'End If
        dt = db.ReturnTable("usp_getDemoData", "", True)

        lblReportName.Text = CboGroup.SelectedItem.Text & " wise Performance Summary "
        LblError.Text = "Between " & IntegerToDateString(startday) & "  and " & IntegerToDateString(endday) & " for " & cboCampaigns.SelectedItem.Text & " campaign"

        db = Nothing
        GridView1.AutoGenerateColumns = False
        CreateGridColumns(dt.Columns)
        GridView1.DataSource = dt
        GridView1.DataBind()

        ' '' ''If Campaigntype = 11 Then
        ' '' ''    If CboGroup.SelectedValue <> 4 Then
        ' '' ''        GridView1.Columns(20).Visible = False
        ' '' ''        GridView1.Columns(22).Visible = False
        ' '' ''    End If
        ' '' ''Else
        ' '' ''    If CboGroup.SelectedValue <> 1 Then
        ' '' ''        GridView1.Columns(15).Visible = False
        ' '' ''        GridView1.Columns(17).Visible = False
        ' '' ''        GridView1.Columns(18).Visible = False
        ' '' ''    Else
        ' '' ''        GridView1.Columns(15).Visible = False
        ' '' ''        GridView1.Columns(17).Visible = False
        ' '' ''        GridView1.Columns(20).Visible = False
        ' '' ''    End If
        ' '' ''End If

        If CboGroup.SelectedValue = 1 Then
            GridView1.Columns(0).Visible = False
            GridView1.Columns(1).Visible = False
            GridView1.Columns(2).Visible = False
            GridView1.Columns(3).Visible = False
            GridView1.Columns(4).Visible = False
            GridView1.Columns(5).Visible = False
        Else
            GridView1.Columns(0).Visible = False
            GridView1.Columns(1).Visible = False
            GridView1.Columns(2).Visible = False
            GridView1.Columns(3).Visible = False
            GridView1.Columns(4).Visible = False
            GridView1.Columns(5).Visible = False
        End If


        dt = Nothing
        ScriptManager.RegisterStartupScript(Me, Me.GetType(), "SortGrid", "$(function(){{$('#" & GridView1.ClientID & "').tablesorter({cancelSelection:true}); }});", True)
        'System.Threading.Thread.Sleep(100)
    End Sub
    Private Function IntegerToDateString(ByVal d As Integer) As String
        Return d.ToString.Substring(0, 4) & "-" & d.ToString.Substring(4, 2) & "-" & d.ToString.Substring(6, 2)
    End Function
    Private Sub CreateGridColumns(ByVal cols As DataColumnCollection)
        GridView1.Columns.Clear()
        Dim tempcolumn As TemplateField
        Dim bouncol As BoundField
        Dim objcol As DataColumn
        For Each objcol In cols
            If objcol.ColumnName = "Agents" Then
                tempcolumn = New TemplateField
                Dim tmpagcol As New TemplateAgentName
                tempcolumn.HeaderText = "Agents"
                tmpagcol.DataImageField = "AgentStatus"
                tmpagcol.DataTextField = objcol.ColumnName
                tempcolumn.ItemStyle.HorizontalAlign = HorizontalAlign.Left
                tempcolumn.ItemTemplate = tmpagcol
                GridView1.Columns.Add(tempcolumn)
            Else
                If objcol.ColumnName <> "Agentstatus" Then
                    bouncol = New BoundField
                    bouncol.HeaderText = objcol.ColumnName
                    bouncol.DataField = objcol.ColumnName
                    GridView1.Columns.Add(bouncol)
                End If
            End If
        Next
    End Sub
    Private Sub FillProcessCampaigns()
        Common.FillProcesses(CboProcess, AgentID)
        Dim lstprocess As New ListItem
        lstprocess.Value = 0
        lstprocess.Text = "All"
        If CboProcess.Items.Contains(lstprocess) Then
            CboProcess.Items.Remove(lstprocess)
        End If
        Dim db As New DBAccess
        db.slDataAdd("Agentid", AgentID)
        CboProcess.SelectedValue = db.ReturnRow("usp_getAgentProcess", True)(4)
        db = Nothing
        Common.FillCampaigns(cboCampaigns, AgentID, CboProcess.SelectedValue)
    End Sub

    Protected Sub cboCampaigns_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboCampaigns.SelectedIndexChanged
        CampaignID = cboCampaigns.SelectedValue
        fillgrid()
    End Sub

    Protected Sub GridView1_RowDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles GridView1.RowDataBound
        If e.Row.RowType = DataControlRowType.Header Then
            If CboGroup.SelectedValue = 1 Then
                e.Row.Cells(15).Visible = False
                e.Row.Cells(17).Visible = False
                e.Row.Cells(6).Width = 200
            End If
          
            'If CboGroup.SelectedValue <> 4 Then
            '    e.Row.Cells(18).Text = "NFAR Score<br />[%]"
            '    e.Row.Cells(19).Text = "FAR Score<br />[%]"
            '    e.Row.Cells(21).Text = "OverAll Score<br />[%]"
            'End If
        End If

        If e.Row.RowType = DataControlRowType.DataRow Then
            Me.GridView1.Columns(0).ItemStyle.Wrap = False
            e.Row.Cells(0).Attributes.Add("style", "white-space:nowrap")
            If e.Row.Cells(0).Controls.Count > 0 Then
                If CType(e.Row.Cells(0).Controls(0).Controls(0).Controls(0).Controls(0), Image).ImageUrl.Contains("onbreak") Then
                    breakCounter = breakCounter + 1
                End If
            End If
           
            e.Row.Cells(0).Style.Add("text-align", "left")
            If CboGroup.SelectedValue = 0 Or CboGroup.SelectedValue = 3 Or CboGroup.SelectedValue = 4 Then

                footerval(0) = footerval(0) + e.Row.Cells(0).Text  '' Call Received_In
                footerval(1) = footerval(1) + e.Row.Cells(1).Text  'Call Abondon_In
                footerval(2) = footerval(2) + e.Row.Cells(2).Text 'CallHandled_In
                footerval(3) = footerval(3) + e.Row.Cells(3).Text 'Talk Duration_In
                footerval(4) = footerval(4) + e.Row.Cells(4).Text ' Monitored_In
                footerval(5) = footerval(5) + e.Row.Cells(5).Text ' ErrorCount_In

                'footerval(6) = footerval(6) + e.Row.Cells(6).Text ' Day,hour,campaign
                footerval(7) = footerval(7) + e.Row.Cells(7).Text ' TMCount
                footerval(8) = footerval(8) + e.Row.Cells(8).Text ' Login Duration
                footerval(9) = footerval(9) + e.Row.Cells(9).Text ' Break Duration

                footerval(10) = footerval(10) + e.Row.Cells(10).Text 'Call Received
                footerval(11) = footerval(11) + e.Row.Cells(11).Text 'Call Abondon
                footerval(12) = footerval(12) + e.Row.Cells(12).Text 'Call Handled %

                footerval(13) = footerval(13) + e.Row.Cells(13).Text 'Call Abondon %
                footerval(14) = footerval(14) + e.Row.Cells(14).Text 'ATT  i.e. Call Duration
                footerval(15) = footerval(15) + e.Row.Cells(15).Text 'AHT
                footerval(16) = footerval(16) + e.Row.Cells(16).Text 'ACHT   

                footerval(17) = footerval(17) + e.Row.Cells(17).Text 'ACW  i.e. wrap time
                footerval(18) = IIf(footerval(18) > e.Row.Cells(18).Text, footerval(18), e.Row.Cells(18).Text) 'LongestWait
                footerval(19) = footerval(19) + e.Row.Cells(19).Text 'Idle Duration
                footerval(20) = footerval(20) + e.Row.Cells(20).Text 'Call Handle within SLA

                footerval(21) = footerval(21) + e.Row.Cells(21).Text 'Monitored
                footerval(22) = footerval(22) + e.Row.Cells(22).Text 'Error %
                footerval(23) = footerval(23) + e.Row.Cells(23).Text 'ASA
                footerval(24) = footerval(24) + e.Row.Cells(24).Text 'Forecast Call Received

                footerval(25) = footerval(25) + e.Row.Cells(25).Text 'Forecast AHT
                footerval(26) = footerval(26) + e.Row.Cells(26).Text 'Forecasted Staff Required


                ''''''''Computing
                ''''call Handle %  s
                If e.Row.Cells(0).Text = 0 Then 'Numerator
                    e.Row.Cells(12).Text = 0
                Else
                    e.Row.Cells(12).Text = Math.Round((e.Row.Cells(2).Text / e.Row.Cells(0).Text) * 100, 2)
                End If

                ''''call Abandon %
                If e.Row.Cells(0).Text = 0 Then 'Numerator
                    e.Row.Cells(13).Text = 0
                Else
                    e.Row.Cells(13).Text = Math.Round((e.Row.Cells(1).Text / e.Row.Cells(0).Text) * 100, 2)
                End If

                ''''AHT
                If e.Row.Cells(2).Text = 0 Then
                    e.Row.Cells(15).Text = 0
                Else
                    e.Row.Cells(15).Text = (e.Row.Cells(3).Text / e.Row.Cells(2).Text)
                End If

                ''Error %
                If e.Row.Cells(4).Text = 0 Then
                    e.Row.Cells(22).Text = 0
                Else
                    e.Row.Cells(22).Text = Math.Round(100 - ((e.Row.Cells(5).Text / e.Row.Cells(4).Text) * 100), 2)
                End If

                'formatting
                e.Row.Cells(8).Text = Common.TimeString(e.Row.Cells(8).Text)
                e.Row.Cells(9).Text = Common.TimeString(e.Row.Cells(9).Text)
                e.Row.Cells(14).Text = Common.TimeString(e.Row.Cells(14).Text)
                e.Row.Cells(15).Text = Common.TimeString(e.Row.Cells(15).Text)
                e.Row.Cells(16).Text = Common.TimeString(e.Row.Cells(16).Text)

                e.Row.Cells(17).Text = Common.TimeString(e.Row.Cells(17).Text)
                e.Row.Cells(18).Text = Common.TimeString(e.Row.Cells(18).Text)
                e.Row.Cells(19).Text = Common.TimeString(e.Row.Cells(19).Text)
                e.Row.Cells(23).Text = Common.TimeString(e.Row.Cells(23).Text)
                e.Row.Cells(25).Text = Common.TimeString(e.Row.Cells(25).Text)

            ElseIf CboGroup.SelectedValue = 1 Then
                e.Row.Cells(15).Visible = False
                e.Row.Cells(17).Visible = False
                e.Row.Cells(6).Width = 200
                footerval(0) = footerval(0) + e.Row.Cells(0).Text  '' Call Received_In
                footerval(1) = footerval(1) + e.Row.Cells(1).Text  'Call Abondon_In
                footerval(2) = footerval(2) + e.Row.Cells(2).Text 'CallHandled_In
                footerval(3) = footerval(3) + e.Row.Cells(3).Text 'Talk Duration_In
                footerval(4) = footerval(4) + e.Row.Cells(4).Text ' Monitored_In
                footerval(5) = footerval(5) + e.Row.Cells(5).Text ' ErrorCount_In

                'footerval(6) = footerval(6) + e.Row.Cells(6).Text ' Day,hour,campaign

                footerval(7) = footerval(7) + e.Row.Cells(7).Text   'AgentStatus ' TMCount
                footerval(8) = footerval(8) + e.Row.Cells(8).Text   ' Login Duration

                footerval(9) = footerval(9) + e.Row.Cells(9).Text   ' Break Duration
                footerval(10) = footerval(10) + e.Row.Cells(10).Text 'Call Received
                footerval(11) = footerval(11) + e.Row.Cells(11).Text  'ATT
                footerval(12) = footerval(12) + e.Row.Cells(12).Text 'AHT

                footerval(13) = footerval(13) + e.Row.Cells(13).Text  'ACHT
                footerval(14) = footerval(14) + e.Row.Cells(14).Text  'ACW

                'footerval(15) = IIf(footerval(15) > e.Row.Cells(15).Text, footerval(15), e.Row.Cells(15).Text)  'LongestWait
                footerval(16) = footerval(16) + e.Row.Cells(16).Text   'Idle Duration

                ' footerval(17) = footerval(17) + e.Row.Cells(17).Text  'Call Handle within SLA
                footerval(18) = footerval(18) + e.Row.Cells(18).Text  'Monitored
                footerval(19) = footerval(19) + e.Row.Cells(19).Text  'Error %

                'footerval(20) = footerval(20) + e.Row.Cells(20).Text    ''''out of index


                ''''AHT
                If e.Row.Cells(2).Text = 0 Then
                    e.Row.Cells(12).Text = 0
                Else
                    e.Row.Cells(12).Text = (e.Row.Cells(3).Text / e.Row.Cells(2).Text)   ''AHT = Time Format( Talk Duration / Call Handled)
                    ' e.Row.Cells(6).Text = 332  ''AHT = Time Format( Talk Duration / Call Handled)
                End If

                ''Error %
                If e.Row.Cells(4).Text = 0 Then
                    e.Row.Cells(19).Text = 0
                Else
                    e.Row.Cells(19).Text = Math.Round(100 - ((e.Row.Cells(5).Text / e.Row.Cells(4).Text) * 100), 2)  'Error % = 100 - Error Count/Monitored*100
                End If

                'formatting
                e.Row.Cells(8).Text = Common.TimeString(e.Row.Cells(8).Text)
                e.Row.Cells(9).Text = Common.TimeString(e.Row.Cells(9).Text)

                e.Row.Cells(11).Text = Common.TimeString(e.Row.Cells(11).Text)
                e.Row.Cells(12).Text = Common.TimeString(e.Row.Cells(12).Text)
                e.Row.Cells(13).Text = Common.TimeString(e.Row.Cells(13).Text)
                e.Row.Cells(14).Text = Common.TimeString(e.Row.Cells(14).Text)

                e.Row.Cells(15).Text = Common.TimeString(e.Row.Cells(15).Text)
                e.Row.Cells(16).Text = Common.TimeString(e.Row.Cells(16).Text)

            End If

        ElseIf e.Row.RowType = DataControlRowType.Footer Then

            If CboGroup.SelectedValue = 0 Or CboGroup.SelectedValue = 3 Or CboGroup.SelectedValue = 4 Then
                e.Row.Cells(0).Text = "Total: "
                'footerval(0) = footerval(0) + e.Row.Cells(0).Text  '' Call Received_In
                'footerval(1) = footerval(1) + e.Row.Cells(1).Text  'Call Abondon_In
                'footerval(2) = footerval(2) + e.Row.Cells(2).Text 'CallHandled_In
                'footerval(3) = footerval(3) + e.Row.Cells(3).Text 'Talk Duration_In
                'footerval(4) = footerval(4) + e.Row.Cells(4).Text ' Monitored_In
                'footerval(5) = footerval(5) + e.Row.Cells(5).Text ' ErrorCount_In

                'footerval(6) = footerval(6) + e.Row.Cells(6).Text ' Day,hour,campaign

                ' e.Row.Cells(7).Text = footerval(7)  ' TMCount
                e.Row.Cells(8).Text = Common.TimeString(footerval(8))  ' Login Duration
                e.Row.Cells(9).Text = Common.TimeString(footerval(9))  ' Break Duration

                e.Row.Cells(10).Text = footerval(10)  'Call Received
                e.Row.Cells(11).Text = footerval(11)  'Call Abondon
                e.Row.Cells(12).Text = IIf(footerval(0) = 0, 0, Math.Round((footerval(2) / footerval(0)) * 100, 2))  ' Call Handled %

                e.Row.Cells(13).Text = IIf(footerval(0) = 0, 0, Math.Round((footerval(1) / footerval(0)) * 100, 2))    ' Call Abandon %
                e.Row.Cells(14).Text = Common.TimeString(footerval(14))  'ATT  i.e. Call Duration
                e.Row.Cells(15).Text = Common.TimeString(IIf(footerval(2) = 0, 0, footerval(3) / footerval(2)))  ' AHT
                e.Row.Cells(16).Text = Common.TimeString(footerval(16))  'ACHT   

                e.Row.Cells(17).Text = Common.TimeString(footerval(17))  'ACW  i.e. wrap time
                e.Row.Cells(18).Text = Common.TimeString(footerval(18)) 'LongestWait
                e.Row.Cells(19).Text = Common.TimeString(footerval(19))  'Idle Duration
                e.Row.Cells(20).Text = footerval(20)  'Call Handle within SLA

                e.Row.Cells(21).Text = footerval(21)  'Monitored
                e.Row.Cells(22).Text = IIf(footerval(4) = 0, 0, Math.Round(100 - ((footerval(5) / footerval(4)) * 100), 2))              'Error %
                e.Row.Cells(23).Text = Common.TimeString(footerval(23))  'ASA
                e.Row.Cells(24).Text = footerval(24)  'Forecast Call Received

                e.Row.Cells(25).Text = Common.TimeString(footerval(25))  'Forecast AHT
                e.Row.Cells(26).Text = footerval(26)  'Forecasted Staff Required


            ElseIf CboGroup.SelectedValue = 1 Then
                e.Row.Cells(15).Visible = False
                e.Row.Cells(17).Visible = False
                e.Row.Cells(0).Text = "[OnBreak= " & breakCounter.ToString & "] Total: "
                'footerval(0) = footerval(0) + e.Row.Cells(0).Text  '' Call Received_In
                'footerval(1) = footerval(1) + e.Row.Cells(1).Text  'Call Abondon_In
                'footerval(2) = footerval(2) + e.Row.Cells(2).Text 'CallHandled_In
                'footerval(3) = footerval(3) + e.Row.Cells(3).Text 'Talk Duration_In
                'footerval(4) = footerval(4) + e.Row.Cells(4).Text ' Monitored_In
                'footerval(5) = footerval(5) + e.Row.Cells(5).Text ' ErrorCount_In

                'footerval(6) = footerval(6) + e.Row.Cells(6).Text ' Day,hour,campaign

                ' e.Row.Cells(7).Text = footerval(7)   'AgentStatus ' TMCount
                e.Row.Cells(8).Text = Common.TimeString(footerval(8))    ' Login Duration

                e.Row.Cells(9).Text = Common.TimeString(footerval(9))    ' Break Duration
                e.Row.Cells(10).Text = Common.TimeString(footerval(10))  'Call Received
                e.Row.Cells(11).Text = Common.TimeString(footerval(11))   'ATT
                e.Row.Cells(12).Text = Common.TimeString(IIf(footerval(2) = 0, 0, footerval(3) / footerval(2)))  ' AHT

                e.Row.Cells(13).Text = Common.TimeString(footerval(13))   'ACHT
                e.Row.Cells(14).Text = Common.TimeString(footerval(14))   'ACW

                'e.Row.Cells(15).Text = Common.TimeString(footerval(15)) 'LongestWait
                e.Row.Cells(16).Text = Common.TimeString(footerval(16))   'Idle Duration

                'e.Row.Cells(17).Text = footerval(17)   'Call Handle within SLA
                e.Row.Cells(18).Text = footerval(18)  'Monitored
                e.Row.Cells(19).Text = IIf(footerval(4) = 0, 0, Math.Round(100 - ((footerval(5) / footerval(4)) * 100), 2))   'Error %


                'e.Row.Cells(3).Text = Common.TimeString(footerval(3))           'login duration
                'e.Row.Cells(4).Text = Common.TimeString(footerval(4))           'Break duration

                'e.Row.Cells(5).Text = footerval(5)                                  ' Call Received
                'e.Row.Cells(6).Text = Common.TimeString(footerval(6))                       ' Talk Duration
                'e.Row.Cells(7).Text = IIf(footerval(5) = 0, 0, Common.TimeString((footerval(6) / footerval(5))))  ' AHT
                'e.Row.Cells(8).Text = footerval(8)                                         'ACW

                'e.Row.Cells(9).Text = footerval(9)                                      'ACHT to be shown
                'e.Row.Cells(10).Text = Common.TimeString(footerval(10))                 'Idle Duration
                'e.Row.Cells(11).Text = footerval(11)    'Call Handle within SLA
                'e.Row.Cells(12).Text = footerval(12)    'Monitored

                'e.Row.Cells(13).Text = IIf(footerval(12) = 0, 0, Math.Round(100 - ((footerval(15) / footerval(12)) * 100), 2)) 'Error %
                'e.Row.Cells(14).Text = footerval(14)                'Call Hanldes   ---Not to be shown
                'e.Row.Cells(15).Text = footerval(15)               'Error Count 

                '''''''e.Row.Cells(16).Text = Common.TimeString(footerval(16))    'LongestWait

            End If

        End If

    End Sub

    Protected Sub GridView1_PreRender(ByVal sender As Object, ByVal e As System.EventArgs) Handles GridView1.PreRender
        If Not GridView1 Is Nothing Then
            If GridView1.HeaderRow Is Nothing Then
            Else
                GridView1.HeaderRow.TableSection = TableRowSection.TableHeader
                GridView1.FooterRow.TableSection = TableRowSection.TableFooter
            End If
        End If
    End Sub
    Protected Sub ImageButton1_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton1.Click
        fillgrid()
        GridViewExportUtil.Export(lblReportName.Text & "-" & LblError.Text & ".xls", Me.GridView1)
    End Sub
    Private Sub ExportToexcel()
        Dim tw As New IO.StringWriter()
        Dim hw As New System.Web.UI.HtmlTextWriter(tw)
        Response.ContentType = "application/vnd.ms-excel"
        Response.AddHeader("content-disposition", "attachment;filename=" & lblReportName.Text & "-" & LblError.Text & ".xls")
        Response.Charset = ""
        EnableViewState = False
        GridView1.RenderControl(hw)
        Response.Write(tw.ToString())
        Response.End()
    End Sub
    Protected Sub CboGroup_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles CboGroup.SelectedIndexChanged
        If CboProcess.SelectedItem.Text = "HPS" Then
            CboPeriod.SelectedValue = 3
        End If
        fillgrid()
    End Sub
    Protected Sub btnFilter_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnFilter.Click
        If CboProcess.SelectedItem.Text = "HPS" Then
            CboPeriod.SelectedValue = 3
        End If
        fillgrid()
    End Sub
    Protected Sub btnRefresh_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnRefresh.Click
        If CboProcess.SelectedItem.Text = "HPS" Then
            CboPeriod.SelectedValue = 3
        End If
        fillgrid()
    End Sub
    Protected Sub CboProcess_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles CboProcess.SelectedIndexChanged
        ProcessID = CboProcess.SelectedValue
        Common.FillCampaigns(cboCampaigns, AgentID, CboProcess.SelectedValue)
        CampaignID = cboCampaigns.SelectedValue
        If CboProcess.SelectedItem.Text = "HPS" Then
            CboPeriod.SelectedValue = 3
        End If
        fillgrid()
    End Sub
    Protected Sub CboPeriod_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles CboPeriod.SelectedIndexChanged
        If CboPeriod.SelectedValue = 10 Then
            ucDateFrom.Visible = True
            UcDateTo.Visible = True
            lblAnd.Visible = True
            fillgrid()
        Else
            ucDateFrom.Visible = False
            UcDateTo.Visible = False
            lblAnd.Visible = False
            fillgrid()
        End If
    End Sub
    Protected Sub imgfav_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles imgfav.Click
        Common.AddToFav(AgentID, "Campaign Summary")
        SuccessMessage("Report has been added to your favourite list")
        fillgrid()
    End Sub
#Region "Utility"
    Private Sub AlertMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMFail"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub
    Private Sub SuccessMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMSuccess"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub
    Public Overrides Sub VerifyRenderingInServerForm(ByVal Control As Control)

    End Sub
#End Region
End Class
