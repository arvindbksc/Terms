﻿Imports com.nss.DBAccess
Imports System.Data
Imports System.Text

Partial Class OutcomeSummary
    Inherits System.Web.UI.Page
    Dim rowval(10), footerval() As Integer
#Region "Properties"
    Property ReportType() As Integer
        Get
            Return ViewState("ReportType")
        End Get
        Set(ByVal value As Integer)
            ViewState("ReportType") = value
        End Set
    End Property
    Property CampaignID() As Integer
        Get
            Return ViewState("CampaignID")
        End Get
        Set(ByVal value As Integer)
            ViewState("CampaignID") = value
        End Set
    End Property

    Property AgentID() As String
        Get
            Return ViewState("AgentID")
        End Get
        Set(ByVal value As String)
            ViewState("AgentID") = value
        End Set
    End Property
    Property Campaigntype() As Integer
        Get
            Return ViewState("Campaigntype")
        End Get
        Set(ByVal value As Integer)
            ViewState("Campaigntype") = value
            'Session("ProcessID") = value
        End Set
    End Property
#End Region
#Region "Load"
    Private Sub LoadData()
        FillCommonFilters()
        FillProcessCampaigns()
    End Sub
    Private Sub FillCommonFilters()
        Dim db As New DBAccess
        Dim dt As DataTable = db.ReturnTable("select * from tbl_Reports_DatePeriods")
        db = Nothing
        Dim dr As DataRow = dt.NewRow
        dr(0) = 10
        dr(1) = "Between"
        dt.Rows.Add(dr)
        CboPeriod.DataTextField = "Caption"
        CboPeriod.DataValueField = "Period"
        CboPeriod.DataSource = dt
        CboPeriod.DataBind()
       
        db = New DBAccess
        dt = db.ReturnTable("Select * from tbl_Reports_GroupBy")
        db = Nothing
        CboGroup.DataTextField = "Caption"
        CboGroup.DataValueField = "ID"
        CboGroup.DataSource = dt
        CboGroup.DataBind()
    End Sub
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        HumanMessage.Style.Item("visibility") = "hidden"
        If Not IsPostBack Then
            ReportType = Request.QueryString("ReportType")
            If Session("AgentID") <> "" Then
                CampaignID = Session("CampaignID")
                AgentID = Session("AgentID")
                PanelReports.Controls.Add(Common.GetMenu(Request.Url, AgentID, Request.ApplicationPath))
                ucDateFrom.Visible = False
                UcDateTo.Visible = False
                lblAnd.Visible = False
                LoadData()
                
                fillgrid()
            End If
        End If
    End Sub
    Private Sub fillgrid()
        If cboCampaigns.SelectedItem.Text = "HPS" Then
            CboPeriod.SelectedValue = 3
        End If
        'For Each obj In footerval
        '    obj = 0
        'Next
        'Dim columns As String
        Dim db As New DBAccess
        db.slDataAdd("Period", CboPeriod.SelectedValue)
        db.slDataAdd("Campaignid", CampaignID)

        'Dim dr As DataRow = db.ReturnRow("usp_GetStart_EndDateForAPeriod", True)
        'db = Nothing
        Dim startday As Integer, endday As Integer
        If CboPeriod.SelectedValue = 10 Then
            startday = ucDateFrom.yyyymmdd
            endday = UcDateTo.yyyymmdd
        Else
            db = New DBAccess("CRM")
            db.slDataAdd("Period", CboPeriod.SelectedValue)
            'db.slDataAdd("Campaignid", CampaignID)
            Dim dr As DataRow = db.ReturnRow("usp_GetStart_EndDateForAPeriod", True)
            db = Nothing
            startday = dr(0)
            endday = dr(1)
        End If

        db = New DBAccess
        db.slDataAdd("processid", 0)
        db.slDataAdd("Campaignid", cboCampaigns.SelectedValue)
        db.slDataAdd("userid", AgentID)
        Campaigntype = db.ReturnValue("usp_getcampaigntype", True)
        'campaigntype = db.ReturnValue("usp_getcampaigntype", True)
        db = Nothing
        db = New DBAccess
        Dim dt As DataTable

        db.slDataAdd("startday", startday)
        db.slDataAdd("endDay", endday)
        db.slDataAdd("campaignid", cboCampaigns.SelectedValue)
        db.slDataAdd("groupBy", CboGroup.SelectedValue)
        If cboFilterBy.SelectedItem.Text <> "None" And txtFilterValue.Text.Trim <> "" Then
            lblFilter.Text = "Filtered for " & cboFilterBy.SelectedItem.Text & " = " & txtFilterValue.Text
            If cboFilterBy.SelectedValue.Contains("String") Then
                'db.slDataAdd("Filterby", "'" & cboFilterBy.SelectedItem.Text & "'")
            End If
            db.slDataAdd("Filterby", cboFilterBy.SelectedItem.Text)
            db.slDataAdd("Filterbyvalue", txtFilterValue.Text)
        End If
        dt = db.ReturnTable("usp_OutcomePerformance", , True)
        'Dim dtime As Date
        'dtime = dr(0).ToString
        'lblReportName.Text = CboGroup.SelectedItem.Text & " wise Outcome Summary "
        LblError.Text = "Between " & IntegerToDateString(startday) & "  and " & IntegerToDateString(endday) & " for " & cboCampaigns.SelectedItem.Text & " campaign"

        db = Nothing
        GridView1.AutoGenerateColumns = False
        CreateGridColumns(dt.Columns)
        GridView1.DataSource = dt
        GridView1.DataBind()

        If Campaigntype = 11 And CboGroup.SelectedValue <> 1 Then
            GridView1.Columns(1).Visible = False
        End If
        'System.Threading.Thread.Sleep(100)
    End Sub
#End Region
#Region "GrisOperation"
    Private Sub CreateGridColumns(ByVal cols As DataColumnCollection)
        Dim db As New DBAccess
        db.slDataAdd("CampaignID", CampaignID)
        Dim dtoutcome As DataTable = db.ReturnTable("usp_ReportOutcomeDescription", , True)
        For Each dr In dtoutcome.Rows
            cols("Outcome" & dr("toOutcome")).Caption = dr("Description")
        Next

        GridView1.Columns.Clear()
        Dim tempcolumn As TemplateField
        Dim bouncol As BoundField
        Dim objcol As DataColumn
        For Each objcol In cols
            If objcol.ColumnName = "Agents" Then
                tempcolumn = New TemplateField
                Dim tmpagcol As New TemplateAgentName
                tempcolumn.HeaderText = "Agents"
                tmpagcol.DataImageField = "AgentStatus"
                tmpagcol.DataTextField = objcol.ColumnName
                tempcolumn.ItemStyle.HorizontalAlign = HorizontalAlign.Left
                tempcolumn.ItemTemplate = tmpagcol
                GridView1.Columns.Add(tempcolumn)
            ElseIf objcol.ColumnName.ToLower = "column1" Then
                bouncol = New BoundField
                bouncol.HeaderText = CboGroup.SelectedItem.Text
                bouncol.DataField = objcol.ColumnName


                GridView1.Columns.Add(bouncol)
            ElseIf objcol.ColumnName.Contains("Outcome") Then
                If objcol.Caption <> objcol.ColumnName Then
                    bouncol = New BoundField
                    bouncol.HeaderText = objcol.Caption
                    bouncol.DataField = objcol.ColumnName


                    GridView1.Columns.Add(bouncol)
                End If
            Else
                If objcol.ColumnName <> "Agentstatus" Then
                    bouncol = New BoundField
                    bouncol.HeaderText = objcol.ColumnName
                    bouncol.DataField = objcol.ColumnName


                    GridView1.Columns.Add(bouncol)
                End If

            End If

        Next
        'Dim MonthCols As BoundField

        'Dim ctr As Integer

        'For ictr As Integer = 0 To ctr
        '    tempcolumn = New TemplateColumn
        '    Dim tmp As New TemplateField

        '    'tempcolumn.ItemTemplate = 
        '    MonthCols = New BoundField
        '    MonthCols.HeaderText = "Month" & ictr + 1
        '    MonthCols.DataField = ""
        '    GridView1.Columns.Add(MonthCols)
        '    'Next

    End Sub
    Protected Sub GridView1_PreRender(ByVal sender As Object, ByVal e As System.EventArgs) Handles GridView1.PreRender
        GridView1.UseAccessibleHeader = True
        'GridView1.HeaderRow.TableSection = TableRowSection.TableHeader
    End Sub
    Protected Sub GridView1_RowDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles GridView1.RowDataBound
        If e.Row.RowType = DataControlRowType.Header Then
            ReDim footerval(e.Row.Cells.Count - 1)
        End If

        'For data Value
        If e.Row.RowType = DataControlRowType.DataRow Then
            e.Row.Cells(0).Style.Add("white-space", "nowrap")
            e.Row.Cells(0).Style.Add("text-align", "left")

            If Campaigntype = 11 Then 'And CboGroup.SelectedValue = 1 Then
                If CboGroup.SelectedValue = 1 Then
                    For i As Integer = 2 To footerval.Length - 1
                        If Not e.Row.Cells(i).Text.Contains("nbsp") Then
                            footerval(i) = footerval(i) + e.Row.Cells(i).Text
                        End If
                    Next
                Else
                    For i As Integer = 1 To footerval.Length - 1
                        If Not e.Row.Cells(i).Text.Contains("nbsp") Then
                            footerval(i) = footerval(i) + e.Row.Cells(i).Text
                        End If
                    Next
                End If

                'Rajkumar change 1
                '[Contact rate]=Contacts/Connects
                e.Row.Cells(footerval.Length - 5).Text = Math.Round(e.Row.Cells(footerval.Length - 6).Text * 100.0 / e.Row.Cells(footerval.Length - 4).Text, 2)
                '[Contact Per Hour]=[No.of Contacts]/Login Hrs
                e.Row.Cells(footerval.Length - 6).Text = Math.Round(e.Row.Cells(footerval.Length - 6).Text / (e.Row.Cells(footerval.Length - 1).Text / 3600.0), 2)
                'Login Hrs Duration in correct format
                e.Row.Cells(footerval.Length - 1).Text = Common.TimeString(e.Row.Cells(footerval.Length - 1).Text)


            Else
                For i As Integer = 1 To footerval.Length - 1
                    If Not e.Row.Cells(i).Text.Contains("nbsp") Then
                        footerval(i) = footerval(i) + e.Row.Cells(i).Text
                    End If
                Next
                'Rajkumar change 2
                'Login Hrs Duration in correct format
                e.Row.Cells(footerval.Length - 1).Text = Common.TimeString(e.Row.Cells(footerval.Length - 1).Text)
            End If

        End If


        '-------For Footer Value
        If e.Row.RowType = DataControlRowType.Footer Then
            If Campaigntype = 11 Then 'And CboGroup.SelectedValue = 1 Then
                If CboGroup.SelectedValue = 1 Then
                    For i As Integer = 2 To footerval.Length - 1
                        e.Row.Cells(i).Text = footerval(i)
                    Next
                Else
                    For i As Integer = 1 To footerval.Length - 1
                        e.Row.Cells(i).Text = footerval(i)
                    Next
                End If

                'Rajkumar change 3
                '[Contact rate]=Contacts/Connects
                e.Row.Cells(footerval.Length - 5).Text = Math.Round(e.Row.Cells(footerval.Length - 6).Text * 100.0 / e.Row.Cells(footerval.Length - 4).Text, 2)
                '[Contact Per Hour]=[No.of Contacts]/Login Hrs
                e.Row.Cells(footerval.Length - 6).Text = Math.Round(e.Row.Cells(footerval.Length - 6).Text / (e.Row.Cells(footerval.Length - 1).Text / 3600.0), 2)
                'Login Hrs Duration in correct format
                e.Row.Cells(footerval.Length - 1).Text = Common.TimeString(e.Row.Cells(footerval.Length - 1).Text)

            Else
                For i As Integer = 1 To footerval.Length - 1
                    e.Row.Cells(i).Text = footerval(i)
                Next
                'Rajkumar change 4
                'Login Hrs Duration in correct format
                e.Row.Cells(footerval.Length - 1).Text = Common.TimeString(e.Row.Cells(footerval.Length - 1).Text)
            End If
        End If

    End Sub
#End Region
#Region "Event"
    Protected Sub cboCampaigns_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboCampaigns.SelectedIndexChanged
        CampaignID = cboCampaigns.SelectedValue
        fillgrid()
        'Dim helper As GridViewHelper = New GridViewHelper(GridView1)
        'helper.RegisterGroup("Agents", True, True)
        'helper.ApplyGroupSort()
    End Sub
    Protected Sub CboPeriod_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles CboPeriod.SelectedIndexChanged
        If CboPeriod.SelectedValue = 10 Then
            ucDateFrom.Visible = True
            UcDateTo.Visible = True
            lblAnd.Visible = True
            fillgrid()
        Else
            ucDateFrom.Visible = False
            UcDateTo.Visible = False
            lblAnd.Visible = False
            fillgrid()
        End If
    End Sub
    Protected Sub ImageButton1_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton1.Click
        fillgrid()
        GridViewExportUtil.Export(lblReportName.Text & "-" & LblError.Text & ".xls", Me.GridView1)
    End Sub
    Protected Sub CboGroup_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles CboGroup.SelectedIndexChanged
        fillgrid()
    End Sub

    Protected Sub btnFilter_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnFilter.Click
        fillgrid()
    End Sub

    Protected Sub btnRefresh_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnRefresh.Click
        fillgrid()
    End Sub
#End Region
#Region "Support Function"
    Private Function IntegerToDateString(ByVal d As Integer) As String
        Return d.ToString.Substring(0, 4) & "-" & d.ToString.Substring(4, 2) & "-" & d.ToString.Substring(6, 2)
    End Function

    Private Sub FillProcessCampaigns()
        Common.FillProcessCampaigns(CboProcess, cboCampaigns, AgentID, CampaignID)
        Dim lstcampaign As New ListItem
        lstcampaign.Value = 0
        lstcampaign.Text = "All"
        If cboCampaigns.Items.Contains(lstcampaign) Then
            cboCampaigns.Items.Remove(lstcampaign)
        End If
    End Sub
   
#End Region
#Region "Not Used"
    'Public Function TimeString(ByVal Seconds As Long) As String

    '    'if verbose = false, returns
    '    'something like
    '    '02:22.08
    '    'if true, returns
    '    '2 hours, 22 minutes, and 8 seconds

    '    Dim lHrs As Long
    '    Dim lMinutes As Long
    '    Dim lSeconds As Long

    '    lSeconds = Seconds

    '    lHrs = Int(lSeconds / 3600)
    '    lMinutes = (Int(lSeconds / 60)) - (lHrs * 60)
    '    lSeconds = Int(lSeconds Mod 60)

    '    If lSeconds = 60 Then
    '        lMinutes = lMinutes + 1
    '        lSeconds = 0
    '    End If

    '    If lMinutes = 60 Then
    '        lMinutes = 0
    '        lHrs = lHrs + 1
    '    End If

    '    TimeString = lHrs.ToString("####00") & ":" & _
    '    lMinutes.ToString("00") & ":" & _
    '     lSeconds.ToString("00")

    'End Function



    'Protected Sub GridView1_RowCreated(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles GridView1.RowCreated

    '    If e.Row.RowType = DataControlRowType.DataRow Then

    '        e.Row.Cells(1).Controls.AddAt(0, New Image)
    '    End If

    'End Sub





    'Private Sub ExportToexcel()
    '    Dim tw As New IO.StringWriter()
    '    Dim hw As New System.Web.UI.HtmlTextWriter(tw)
    '    'Dim frm As HtmlForm = New HtmlForm()
    '    Response.ContentType = "application/vnd.ms-excel"
    '    Response.AddHeader("content-disposition", "attachment;filename=" & lblReportName.Text & "-" & LblError.Text & ".xls")
    '    Response.Charset = ""
    '    EnableViewState = False
    '    'Controls.Add(frm)
    '    GridView1.RenderControl(hw)
    '    Response.Write(tw.ToString())
    '    Response.End()
    'End Sub
#End Region

    Protected Sub imgfav_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles imgfav.Click
        Common.AddToFav(AgentID, "Outcome Summary")
        SuccessMessage("Report has been added to your favourite list")
        fillgrid()
    End Sub
#Region "Utility"

    Private Sub AlertMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMFail"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub

    Private Sub SuccessMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMSuccess"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub

    'Protected Sub ImageButton1_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton1.Click
    '    'fillgrid()
    '    GridViewExportUtil.Export(lblReportName.CurrentPage & "-" & LblError.Text & ".xls", Me.GdAttendance)
    'End Sub


    Public Overrides Sub VerifyRenderingInServerForm(ByVal Control As Control)

    End Sub

#End Region
End Class
