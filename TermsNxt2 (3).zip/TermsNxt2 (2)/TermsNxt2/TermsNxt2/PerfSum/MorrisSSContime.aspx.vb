﻿Imports com.nss.DBAccess
Imports System.Data
Imports System.Text

Partial Class MorrisSSContime
    Inherits System.Web.UI.Page

#Region "Properties"

    Property ProcessID() As Integer
        Get
            Return ViewState("ProcessID")
        End Get
        Set(ByVal value As Integer)
            ViewState("ProcessID") = value
            Session("ProcessID") = value
        End Set
    End Property
    Property Campaigntype() As Integer
        Get
            Return ViewState("Campaigntype")
        End Get
        Set(ByVal value As Integer)
            ViewState("Campaigntype") = value
            'Session("ProcessID") = value
        End Set
    End Property
    Property Period() As Integer
        Get
            Return ViewState("Period")
        End Get
        Set(ByVal value As Integer)
            ViewState("Period") = value
            'Session("ProcessID") = value
        End Set
    End Property
    Property ReportType() As Integer
        Get
            Return ViewState("ReportType")
        End Get
        Set(ByVal value As Integer)
            ViewState("ReportType") = value
        End Set
    End Property
    Property CampaignID() As Integer
        Get
            Return ViewState("CampaignID")
        End Get
        Set(ByVal value As Integer)
            ViewState("CampaignID") = value
        End Set
    End Property

    Property AgentID() As String
        Get
            Return ViewState("AgentID")
        End Get
        Set(ByVal value As String)
            ViewState("AgentID") = value
        End Set
    End Property
#End Region

    Private Sub LoadData()
        FillCommonFilters()
        FillProcessCampaigns()
    End Sub

    Private Sub FillCommonFilters()
        Dim db As New DBAccess
        Dim dt As DataTable = db.ReturnTable("select * from tbl_Reports_DatePeriods")
        db = Nothing
        Dim dr As DataRow = dt.NewRow
        dr(0) = 10
        dr(1) = "Between"
        dt.Rows.Add(dr)
        CboPeriod.DataTextField = "Caption"
        CboPeriod.DataValueField = "Period"
        CboPeriod.DataSource = dt
        CboPeriod.DataBind()

        db = New DBAccess
        dt = db.ReturnTable("Select * from tbl_Reports_GroupBy")
        db = Nothing

        Dim drGroupBy As DataRow

        'to remove hour filter
        If dt.Rows.Count > 0 Then
            dt.Rows.RemoveAt(4)
            drGroupBy = dt.NewRow
            drGroupBy("Caption") = "WorkType"
            drGroupBy("ID") = 5
            dt.Rows.Add(drGroupBy)
        End If

        CboGroup.DataTextField = "Caption"
        CboGroup.DataValueField = "ID"
        CboGroup.DataSource = dt
        CboGroup.DataBind()
        Period = Request.QueryString("period")
        CboPeriod.SelectedValue = Period

    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        HumanMessage.Style.Item("visibility") = "hidden"
        If Not IsPostBack Then
            ReportType = Request.QueryString("ReportType")
            If Session("AgentID") <> "" Then
                If Not Request.QueryString("Campaign") Is Nothing Then
                    Session("CampaignID") = Request.QueryString("Campaign")
                End If
                CampaignID = Session("CampaignID")
                AgentID = Session("AgentID")
                PanelReports.Controls.Add(Common.GetMenu(Request.Url, AgentID, Request.ApplicationPath))
                LoadData()
                fillgrid()
                UcDateTo.Visible = False
                ucDateFrom.Visible = False
                lblAnd.Visible = False
            End If
        End If
    End Sub

    Private Sub fillgrid()
        Dim db As DBAccess
        Try
            Dim startday As Integer, endday As Integer
            If CboPeriod.SelectedValue = 10 Then
                startday = ucDateFrom.yyyymmdd
                endday = UcDateTo.yyyymmdd
            Else
                db = New DBAccess
                db.slDataAdd("Period", CboPeriod.SelectedValue)
                db.slDataAdd("Campaignid", cboCampaigns.SelectedValue)
                Dim dr As DataRow = db.ReturnRow("usp_GetStart_EndDateForAPeriod", True)
                db = Nothing
                startday = dr(0)
                endday = dr(1)
            End If
            db = New DBAccess()
            db.slDataAdd("processid", CboProcess.SelectedValue)
            db.slDataAdd("Campaignid", cboCampaigns.SelectedValue)
            db.slDataAdd("userid", AgentID)
            Dim dtcampaigntype As DataTable = db.ReturnTable("usp_getcampaigntype", , True)
            'campaigntype = db.ReturnValue("usp_getcampaigntype", True)
            db = Nothing
            If dtcampaigntype.Rows.Count > 1 Then
                Campaigntype = 1
            Else
                Campaigntype = dtcampaigntype.Rows(0).Item(0)
            End If

            db = New DBAccess("Leads")
            Dim dt As New DataTable
            db.slDataAdd("userid", AgentID)
            db.slDataAdd("startday", startday)
            db.slDataAdd("endDay", endday)
            db.slDataAdd("campaignid", cboCampaigns.SelectedValue)
            db.slDataAdd("groupBy", CboGroup.SelectedValue)
            db.slDataAdd("Processid", CboProcess.SelectedValue)

            dt = db.ReturnTable("usp_MorrisSSC_OnTime" & cboCampaigns.SelectedValue, "", True)  'for usp_MorrisSSC_OnTime306

            lblReportName.Text = CboGroup.SelectedItem.Text & " wise OnTime Summary "
            LblError.Text = "Between " & IntegerToDateString(startday) & "  and " & IntegerToDateString(endday) & " for " & cboCampaigns.SelectedItem.Text & " campaign"

            db = Nothing
            ' GridView1.AutoGenerateColumns = False
            ' CreateGridColumns(dt.Columns)
            GridView1.DataSource = dt
            GridView1.DataBind()

            dt = Nothing

            ScriptManager.RegisterStartupScript(Me, Me.GetType(), "SortGrid", "$(function(){{$('#" & GridView1.ClientID & "').tablesorter({cancelSelection:true}); }});", True)
            'System.Threading.Thread.Sleep(100)

        Catch sqlEx As SqlClient.SqlException
            If sqlEx.Number = 2812 Then  'for stored procedure not found
                GridView1.DataSource = Nothing
                GridView1.DataBind()
            End If

        Catch ex As Exception
            AlertMessage(ex.Message)
        End Try
    End Sub
    Private Function IntegerToDateString(ByVal d As Integer) As String
        Return d.ToString.Substring(0, 4) & "-" & d.ToString.Substring(4, 2) & "-" & d.ToString.Substring(6, 2)
    End Function
    
    Private Sub FillProcessCampaigns()
        Common.FillProcesses(CboProcess, AgentID)
        Dim lstprocess As New ListItem
        lstprocess.Value = 0
        lstprocess.Text = "All"
        If CboProcess.Items.Contains(lstprocess) Then
            CboProcess.Items.Remove(lstprocess)
        End If
        Dim db As New DBAccess
        db.slDataAdd("Agentid", AgentID)
        CboProcess.SelectedValue = db.ReturnRow("usp_getAgentProcess", True)(4)
        db = Nothing
        Common.FillCampaigns(cboCampaigns, AgentID, CboProcess.SelectedValue)

        'To remove "All"
        If cboCampaigns.Items.Count > 0 Then
            cboCampaigns.Items.RemoveAt(cboCampaigns.Items.Count - 1)
        End If

    End Sub

    Protected Sub cboCampaigns_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboCampaigns.SelectedIndexChanged
        CampaignID = cboCampaigns.SelectedValue
        fillgrid()
    End Sub

    Protected Sub ImageButton1_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton1.Click
        fillgrid()
        GridViewExportUtil.Export(lblReportName.Text & "-" & LblError.Text & ".xls", Me.GridView1)
    End Sub

    Private Sub ExportToexcel()
        Dim tw As New IO.StringWriter()
        Dim hw As New System.Web.UI.HtmlTextWriter(tw)
        Response.ContentType = "application/vnd.ms-excel"
        Response.AddHeader("content-disposition", "attachment;filename=" & lblReportName.Text & "-" & LblError.Text & ".xls")
        Response.Charset = ""
        EnableViewState = False
        GridView1.RenderControl(hw)
        Response.Write(tw.ToString())
        Response.End()
    End Sub
    Protected Sub CboGroup_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles CboGroup.SelectedIndexChanged
        fillgrid()
    End Sub

    Protected Sub btnFilter_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnFilter.Click
        fillgrid()
    End Sub

    Protected Sub btnRefresh_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnRefresh.Click
        fillgrid()
    End Sub

    Protected Sub CboProcess_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles CboProcess.SelectedIndexChanged
        ProcessID = CboProcess.SelectedValue
        Common.FillCampaigns(cboCampaigns, AgentID, CboProcess.SelectedValue)

        'To remove "All"
        If cboCampaigns.Items.Count > 0 Then
            cboCampaigns.Items.RemoveAt(cboCampaigns.Items.Count - 1)
        End If

        CampaignID = cboCampaigns.SelectedValue
        fillgrid()
    End Sub
    Protected Sub CboPeriod_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles CboPeriod.SelectedIndexChanged
        If CboPeriod.SelectedValue = 10 Then
            ucDateFrom.Visible = True
            UcDateTo.Visible = True
            lblAnd.Visible = True
            fillgrid()
        Else
            ucDateFrom.Visible = False
            UcDateTo.Visible = False
            lblAnd.Visible = False
            fillgrid()
        End If
    End Sub

    Protected Sub imgfav_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles imgfav.Click
        Common.AddToFav(AgentID, "MorrisSSContime Summary")
        SuccessMessage("Report has been added to your favourite list")
        fillgrid()
    End Sub
#Region "Utility"

    Private Sub AlertMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMFail"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub

    Private Sub SuccessMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMSuccess"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub
#End Region
End Class
