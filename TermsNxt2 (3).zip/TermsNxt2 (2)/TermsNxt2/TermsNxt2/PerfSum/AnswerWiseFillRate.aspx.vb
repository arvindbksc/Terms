﻿Imports com.nss.DBAccess
Imports System.Data
Imports System.Text
Partial Class PerfSum_AnswerWiseFillRate
    Inherits System.Web.UI.Page
#Region "Properties"
    Property ReportType() As Integer
        Get
            Return ViewState("ReportType")
        End Get
        Set(ByVal value As Integer)
            ViewState("ReportType") = value
        End Set
    End Property
    Property CampaignID() As Integer
        Get
            Return ViewState("CampaignID")
        End Get
        Set(ByVal value As Integer)
            ViewState("CampaignID") = value
        End Set
    End Property

    Property AgentID() As String
        Get
            Return ViewState("AgentID")
        End Get
        Set(ByVal value As String)
            ViewState("AgentID") = value
        End Set
    End Property
#End Region
#Region "Load"
    Private Sub LoadData()
        FillCommonFilters()
        FillProcessCampaigns()
    End Sub
    Private Sub FillCommonFilters()
        Dim db As New DBAccess
        Dim dt As DataTable = db.ReturnTable("select * from tbl_Reports_DatePeriods")
        db = Nothing
        CboPeriod.DataTextField = "Caption"
        CboPeriod.DataValueField = "Period"
        CboPeriod.DataSource = dt
        CboPeriod.DataBind()
        'db = New DBAccess
        'dt = db.ReturnTable("Select * from tbl_Reports_GroupBy")
        'db = Nothing
        'CboGroup.DataTextField = "Caption"
        'CboGroup.DataValueField = "ID"
        'CboGroup.DataSource = dt
        'CboGroup.DataBind()
    End Sub
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            ReportType = Request.QueryString("ReportType")
            If Session("AgentID") <> "" Then
                CampaignID = Session("CampaignID")
                AgentID = Session("AgentID")
                LoadData()
                fillgrid()

            End If

        End If
    End Sub
    Private Sub fillgrid()

        'For Each obj In footerval
        '    obj = 0
        'Next
        'Dim columns As String
        Dim db As New DBAccess
        db.slDataAdd("Period", CboPeriod.SelectedValue)
        db.slDataAdd("Campaignid", CampaignID)

        Dim dr As DataRow = db.ReturnRow("usp_GetStart_EndDateForAPeriod", True)
        db = Nothing
        db = New DBAccess
        Dim dt As New DataTable


        db.slDataAdd("DateFrom", dr(0))
        db.slDataAdd("DateTo", dr(1))
        db.slDataAdd("campaign", CampaignID)
        db.slDataAdd("ReportType", cboFilterBy.SelectedValue)
        dt = db.ReturnTable("usp_GetAnswerWiseFillRate", , True)

        lblFilter.Text = "Filtered for " & cboFilterBy.SelectedItem.Text
       
        lblReportName.Text = "Answer wise Fillrate "
        LblError.Text = "Between " & IntegerToDateString(dr(0)) & "  and " & IntegerToDateString(dr(1)) & " for " & cboCampaigns.SelectedItem.Text & " campaign"

        db = Nothing
        GridView1.AutoGenerateColumns = False
        CreateGridColumns(dt.Columns)
        GridView1.DataSource = dt
        GridView1.DataBind()
        'System.Threading.Thread.Sleep(100)
    End Sub
#End Region
#Region "GridOperation"
    Private Sub CreateGridColumns(ByVal cols As DataColumnCollection)
        'Dim db As New DBAccess
        'db.slDataAdd("CampaignID", CampaignID)
        'Dim dtoutcome As DataTable = db.ReturnTable("usp_ReportOutcomeDescription", , True)
        'For Each dr In dtoutcome.Rows
        '    cols("Outcome" & dr("toOutcome")).Caption = dr("Description")
        'Next

        GridView1.Columns.Clear()
        Dim tempcolumn As TemplateField
        Dim bouncol As BoundField
        Dim objcol As DataColumn

        bouncol = New BoundField
        bouncol.HeaderText = "S.No."
        'bouncol.DataField = objcol.ColumnName


        GridView1.Columns.Add(bouncol)
        For Each objcol In cols
            If objcol.ColumnName = "Agents" Then
                tempcolumn = New TemplateField
                Dim tmpagcol As New TemplateAgentName
                tempcolumn.HeaderText = "Agents"
                tmpagcol.DataImageField = "AgentStatus"
                tmpagcol.DataTextField = objcol.ColumnName
                tempcolumn.ItemStyle.HorizontalAlign = HorizontalAlign.Left
                tempcolumn.ItemTemplate = tmpagcol
                GridView1.Columns.Add(tempcolumn)
                'ElseIf objcol.ColumnName.ToLower = "column1" Then
                '    bouncol = New BoundField
                '    bouncol.HeaderText = CboGroup.SelectedItem.Text
                '    bouncol.DataField = objcol.ColumnName


                '    GridView1.Columns.Add(bouncol)
            ElseIf objcol.ColumnName.Contains("Outcome") Then
                If objcol.Caption <> objcol.ColumnName Then
                    bouncol = New BoundField
                    bouncol.HeaderText = objcol.Caption
                    bouncol.DataField = objcol.ColumnName


                    GridView1.Columns.Add(bouncol)
                End If
            Else
                If objcol.ColumnName <> "Agentstatus" Then
                    bouncol = New BoundField
                    bouncol.HeaderText = objcol.ColumnName
                    bouncol.DataField = objcol.ColumnName


                    GridView1.Columns.Add(bouncol)
                End If

            End If

        Next


    End Sub
    Protected Sub GridView1_PreRender(ByVal sender As Object, ByVal e As System.EventArgs) Handles GridView1.PreRender
        GridView1.UseAccessibleHeader = True
    End Sub
    Dim i As Integer = 1
    Protected Sub GridView1_RowDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles GridView1.RowDataBound
        If e.Row.RowType = DataControlRowType.DataRow Then
            e.Row.Cells(5).Text = Math.Round(e.Row.Cells(4).Text / 1.0, 2)
            ' For Each row As GridViewRow In GridView1.Rows
            e.Row.Cells(0).Text = i
            i += 1
            ' Next
        End If
    End Sub
#End Region
#Region "Event"
    Protected Sub cboCampaigns_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboCampaigns.SelectedIndexChanged
        CampaignID = cboCampaigns.SelectedValue
        fillgrid()
        'Dim helper As GridViewHelper = New GridViewHelper(GridView1)
        'helper.RegisterGroup("Agents", True, True)
        'helper.ApplyGroupSort()
    End Sub
    Protected Sub CboPeriod_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles CboPeriod.SelectedIndexChanged
        fillgrid()
    End Sub
    Protected Sub ImageButton1_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton1.Click
        fillgrid()
        GridViewExportUtil.Export(lblReportName.Text & "-" & LblError.Text & ".xls", Me.GridView1)
    End Sub
    'Protected Sub CboGroup_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles CboGroup.SelectedIndexChanged
    '    fillgrid()
    'End Sub

    'Protected Sub btnFilter_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnFilter.Click
    '    fillgrid()
    'End Sub

    Protected Sub btnRefresh_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnRefresh.Click
        fillgrid()
    End Sub
    Protected Sub cboFilterBy_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboFilterBy.SelectedIndexChanged
        fillgrid()
    End Sub
#End Region
#Region "Support Function"
    Private Function IntegerToDateString(ByVal d As Integer) As String
        Return d.ToString.Substring(0, 4) & "-" & d.ToString.Substring(4, 2) & "-" & d.ToString.Substring(6, 2)
    End Function

    Private Sub FillProcessCampaigns()
        Common.FillProcessCampaigns(CboProcess, cboCampaigns, AgentID, CampaignID)
        Dim lstcampaign As New ListItem
        lstcampaign.Value = 0
        lstcampaign.Text = "All"
        cboCampaigns.Items.Remove(lstcampaign)
    End Sub
    Public Overrides Sub VerifyRenderingInServerForm(ByVal Control As Control)

    End Sub
#End Region

End Class
