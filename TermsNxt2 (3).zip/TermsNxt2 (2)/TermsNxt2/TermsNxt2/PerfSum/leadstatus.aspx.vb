﻿Imports com.nss.DBAccess
Imports System.Data
Imports System.Text
Partial Class PerfSum_leadstatus
    Inherits System.Web.UI.Page
    Dim footerval(12) As Integer
    Property ReportType() As Integer
        Get
            Return ViewState("ReportType")
        End Get
        Set(ByVal value As Integer)
            ViewState("ReportType") = value
        End Set
    End Property
    Public ReadOnly Property CampaignID() As Integer
        Get
            Return IIf(cboCampaigns.SelectedValue = "", 0, cboCampaigns.SelectedValue)
        End Get

    End Property
    Private Sub LoadData()
        FillCommonFilters()
        FillProcessCampaigns()
    End Sub
    
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then

            ReportType = Request.QueryString("ReportType")
            LoadData()
            fillgrid()
            'ElseIf Me.Master.MasterChanged Then
            '    fillgrid()
            '    Me.Master.MasterChanged = False
        End If
    End Sub
    Private Sub FillCommonFilters()
        Dim db As New DBAccess
        Dim dt As DataTable = db.ReturnTable("select * from tbl_Reports_DatePeriods")
        db = Nothing
        CboPeriod.DataTextField = "Caption"
        CboPeriod.DataValueField = "Period"
        CboPeriod.DataSource = dt
        CboPeriod.DataBind()
    End Sub
    Private Sub fillgrid()

        For Each obj In footerval
            obj = 0
        Next
        Dim columns As String
        Dim db As New DBAccess
        Dim leadrec, totalavaLeads, TotalDialleads, AvaLeads, DialLeads, TotalCompLeads, TotalDMC As Integer
        db.slDataAdd("Period", CboPeriod.SelectedValue)
        db.slDataAdd("Campaignid", CampaignID)

        Dim dr As DataRow = db.ReturnRow("usp_GetStart_EndDateForAPeriod", True)
        db = Nothing
        db = New DBAccess
        ' Dim dt As DataTable

        db.slDataAdd("startday", dr(0))
        db.slDataAdd("endDay", dr(1))
        db.slDataAdd("campaignid", CampaignID)
        'db.slDataAdd("groupBy", CboGroup.SelectedValue)
        Dim strsql, strsql1, strsql2, strsql3 As String
        db = New DBAccess("Leads")
        strsql = "select count(*) from tbl_LeadMaster" + CampaignID.ToString + " where convert(varchar,Creationtime,112) between '" & dr(0) & "' and '" & dr(1) & "'"
        leadrec = db.ReturnValue(strsql, False)
        strsql1 = "select count(*) from tbl_LeadMaster" + CampaignID.ToString + " where dialstate=0 and ISexpired =0"
        totalavaLeads = db.ReturnValue(strsql1, False)
        strsql2 = "select count(*) from tbl_LeadMaster" + CampaignID.ToString + " where dialstate=0 and ISexpired =0 and convert(varchar,creationtime,112) between '" & dr(0) & "' and '" & dr(1) & "'"
        AvaLeads = db.ReturnValue(strsql2, False)
        'strsql3 = "select count(*)  from tbl_LeadMaster162 where dialstate<>0 and convert(varchar,dateadd(n,-330,creationtime),112) between '" & dr(0) & "' and '" & dr(1) & "'"
        strsql3 = "select count(*) from [GGN-NSS-SQL1].[CRM].[dbo].tbl_Customer_Last_Status B inner join tbl_leadmaster" + CampaignID.ToString + " C on B.customerid=C.customerid where B.campaignid=" + CampaignID.ToString + " and convert(varchar,C.creationtime,112) between '" & dr(0) & "' and '" & dr(1) & "'"
        DialLeads = db.ReturnValue(strsql3, False)
        db = Nothing
        db = New DBAccess("CRM")
        strsql = "select count(*) from tbl_Customer_Last_Status B inner join tbl_Data_Transactions C on B.LastTransID=C.ID where B.campaignid=" + CampaignID.ToString + " and convert(varchar,C.StartDateTime,112) between '" & dr(0) & "' and '" & dr(1) & "'"
        TotalDialleads = db.ReturnValue(strsql, False)
        strsql1 = "select COUNT(*) FROM tbl_Customer_Last_Status A INNER JOIN tbl_Data_Transactions C on A.LastTransID=C.ID inner join"
        strsql1 = strsql1 + " tbl_Config_ResultGroups B ON A.lastresult = b.ResultCode"
        strsql1 = strsql1 + " WHERE A.campaignid=" + CampaignID.ToString + " and convert(varchar,C.StartDateTime,112) between '" & dr(0) & "' and '" & dr(1) & "' AND (b.groupname in ('Complete'))"
        TotalCompLeads = db.ReturnValue(strsql1, False)
        strsql2 = "SELECT COUNT(*) FROM tbl_Customer_Last_Status A INNER JOIN tbl_Config_ResultGroups B ON A.lastresult = b.ResultCode INNER JOIN"
        strsql2 = strsql2 + " tbl_Data_Transactions C on A.LastTransID=C.ID "
        strsql2 = strsql2 + " WHERE A.campaignid=" + CampaignID.ToString + " and convert(varchar,C.StartDateTime,112) between '" & dr(0) & "' and '" & dr(1) & "' AND (b.groupname = 'DMC')"
        TotalDMC = db.ReturnValue(strsql2, False)
        db = Nothing

        Dim dt As New DataTable
        dt.Columns.Add("Lead Recieved")
        dt.Columns.Add("Total Available Leads")
        dt.Columns.Add("Total Dialed Leads")
        dt.Columns.Add("Available Leads")
        dt.Columns.Add("Dialed Leads")
        dt.Columns.Add("Total Complete Leads")
        dt.Columns.Add("Total DMC")
        Dim row As DataRow = dt.Rows.Add
        row.Item("Lead Recieved") = leadrec
        row.Item("Total Available Leads") = totalavaLeads
        row.Item("Total Dialed Leads") = TotalDialleads
        row.Item("Available Leads") = AvaLeads
        row.Item("Dialed Leads") = DialLeads
        row.Item("Total Complete Leads") = TotalCompLeads
        row.Item("Total DMC") = TotalDMC
        GridView1.DataSource = dt
        GridView1.DataBind()
        'dt = db.ReturnTable("usp_QuestData", , True)
        'Dim dtime As Date
        'dtime = dr(0).ToString
        lblReportName.Text = "Lead Status Report"
        LblError.Text = "Between " & IntegerToDateString(dr(0)) & "  and " & IntegerToDateString(dr(1)) & " for " & cboCampaigns.SelectedItem.Text & " campaign"

        db = Nothing
        
        'System.Threading.Thread.Sleep(100)
    End Sub
    Private Function IntegerToDateString(ByVal d As Integer) As String
        Return d.ToString.Substring(0, 4) & "-" & d.ToString.Substring(4, 2) & "-" & d.ToString.Substring(6, 2)
    End Function
    Private Sub FillProcessCampaigns()
        Dim db As New DBAccess
        Dim dt As DataTable
        dt = db.ReturnTable("Select * from tbl_Config_Processes where processid=10")
        'Dim dr As DataRow
        'dr = dt.NewRow
        'dr("ProcessName") = "All"
        'dr("ProcessID") = 0
        'dt.Rows.Add(dr)
        db = Nothing
        CboProcess.DataTextField = "ProcessName"
        CboProcess.DataValueField = "ProcessID"
        CboProcess.DataSource = dt
        CboProcess.DataBind()
        Dim dbt As New DBAccess()
        'dbt.slDataAdd("empID", UserID)
        Dim dtc As DataTable = dbt.ReturnTable("Select * from tbl_config_Campaigns where processid=10")
        dbt = Nothing
        'dr = dtc.NewRow
        'dr("Name") = "All"
        'dr("CampaignId") = 0
        'dtc.Rows.Add(dr)
        cboCampaigns.DataTextField = "Name"
        cboCampaigns.DataValueField = "CampaignId"
        cboCampaigns.DataSource = dtc
        cboCampaigns.DataBind()


    End Sub
    Protected Sub cboCampaigns_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboCampaigns.SelectedIndexChanged
        fillgrid()
        'Dim helper As GridViewHelper = New GridViewHelper(GridView1)
        'helper.RegisterGroup("Agents", True, True)
        'helper.ApplyGroupSort()
    End Sub
    Protected Sub CboPeriod_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles CboPeriod.SelectedIndexChanged
        fillgrid()
    End Sub
    Public Function TimeString(ByVal Seconds As Long) As String

        'if verbose = false, returns
        'something like
        '02:22.08
        'if true, returns
        '2 hours, 22 minutes, and 8 seconds

        Dim lHrs As Long
        Dim lMinutes As Long
        Dim lSeconds As Long

        lSeconds = Seconds

        lHrs = Int(lSeconds / 3600)
        lMinutes = (Int(lSeconds / 60)) - (lHrs * 60)
        lSeconds = Int(lSeconds Mod 60)

        If lSeconds = 60 Then
            lMinutes = lMinutes + 1
            lSeconds = 0
        End If

        If lMinutes = 60 Then
            lMinutes = 0
            lHrs = lHrs + 1
        End If

        TimeString = lHrs.ToString("####00") & ":" & _
        lMinutes.ToString("00") & ":" & _
         lSeconds.ToString("00")

    End Function
    Protected Sub ImageButton1_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton1.Click
        fillgrid()
        GridViewExportUtil.Export(lblReportName.Text & "-" & LblError.Text & ".xls", Me.GridView1)
    End Sub
End Class
