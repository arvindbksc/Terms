﻿Imports com.nss.DBAccess
Imports System.Data

Partial Class PerfSum_AgentLoginStatus
    Inherits System.Web.UI.Page
    Dim db As New DBAccess

#Region "Property"
    Public Property currentdate() As Date
        Get
            Return ViewState("currentdate")
        End Get
        Set(ByVal value As Date)
            ViewState("currentdate") = value
        End Set
    End Property
    Property AgentID() As String
        Get
            Return ViewState("AgentID")
        End Get
        Set(ByVal value As String)
            ViewState("AgentID") = value
        End Set
    End Property
#End Region
#Region "Load"
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        HumanMessage.Style.Item("visibility") = "hidden"
        If Not IsPostBack Then
            Dim dbdate As New DBAccess
            AgentID = Session("AgentID")
            PanelReports.Controls.Add(Common.GetMenu(Request.Url, AgentID, Request.ApplicationPath))
            currentdate = dbdate.ReturnValue("select getdate()", False)
            dbdate = Nothing
            txtDate.value = currentdate
            GetAgentList()
        End If
    End Sub
    Private Sub GetAgentList()
        db = New DBAccess
        Dim dtAgents As New DataTable
        db.slDataAdd("datefrom", txtDate.value.ToString("yyyyMMdd"))
        dtAgents = db.ReturnTable("usp_getOrionAgents", , True)
        db = Nothing
        If dtAgents.Rows.Count > 0 Then
            gvLoginStatus.DataSource = dtAgents
            gvLoginStatus.DataBind()
            Dim chk As CheckBox
            Dim lblEmp As Label
            Dim dropDown As DropDownList
            For Each row As GridViewRow In gvLoginStatus.Rows
                lblEmp = CType(row.FindControl("lblEmpId"), Label)
                chk = CType(row.FindControl("chkAgents"), CheckBox)
                dropDown = CType(row.FindControl("ddlLoginStatus"), DropDownList)
                'dropDown.SelectedValue = dtAgents.Rows(0)(1).ToString()
                dropDown.SelectedValue = dtAgents.Select("Agentid='" & lblEmp.Text & "'")(0)(6).ToString()
                'Dim foundRows() As DataRow = dtAgents.Select("select LoginStatus EMpCode= '" & lblEmp.Text & "'")
                If chk.Checked = True Then
                    chk.Enabled = False
                    dropDown.Enabled = False
                End If
            Next
        End If
    End Sub
#End Region
#Region "Event"
    Protected Sub btnSave_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnSave.Click
        Dim count As Integer = 0
        Dim chk As CheckBox
        Dim dropDown As DropDownList
        For Each row As GridViewRow In gvLoginStatus.Rows
            db = New DBAccess
            chk = CType(row.FindControl("chkAgents"), CheckBox)
            dropDown = CType(row.FindControl("ddlLoginStatus"), DropDownList)
            If chk.Checked = True And dropDown.Enabled = True Then
                db.slDataAdd("Agentid", CType(row.FindControl("lblEmpId"), Label).Text)
                db.slDataAdd("LoginStatus", CType(row.FindControl("ddlLoginStatus"), DropDownList).Text)
                db.slDataAdd("CallDate", txtDate.value.ToString("yyyyMMdd"))
                db.Executeproc("usp_setAgentLoginStatus")
                count += 1
            End If
            db = Nothing
        Next
        If count > 0 Then
            SuccessMessage("Agent Status has been saved")
            GetAgentList()
        Else
            AlertMessage("Please select agent")
        End If

    End Sub
    Protected Sub txtDate_Changed(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtDate.Changed
        GetAgentList()
    End Sub

    Protected Sub btnRefresh_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnRefresh.Click
        GetAgentList()
    End Sub
#End Region
#Region "Utility"

    Private Sub AlertMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMFail"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub
    Private Sub SuccessMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMSuccess"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub

#End Region

    Protected Sub imgfav_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles imgfav.Click
        Common.AddToFav(AgentID, "Orion Agents Login Status")
        SuccessMessage("Report has been added to your favourite list")
        GetAgentList()
    End Sub
End Class
