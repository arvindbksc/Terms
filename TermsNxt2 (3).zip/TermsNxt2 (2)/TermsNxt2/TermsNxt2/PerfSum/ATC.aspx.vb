﻿Imports com.nss.DBAccess
Imports System.Data
Imports System.Text
Partial Class PerfSum_ATC
    Inherits System.Web.UI.Page
    Dim rowval(10), footerval() As Integer
#Region "Properties"
    Property ReportType() As Integer
        Get
            Return ViewState("ReportType")
        End Get
        Set(ByVal value As Integer)
            ViewState("ReportType") = value
        End Set
    End Property
    Property CampaignID() As Integer
        Get
            Return ViewState("CampaignID")
        End Get
        Set(ByVal value As Integer)
            ViewState("CampaignID") = value
        End Set
    End Property

    Property AgentID() As String
        Get
            Return ViewState("AgentID")
        End Get
        Set(ByVal value As String)
            ViewState("AgentID") = value
        End Set
    End Property
#End Region
#Region "Load"
    Private Sub LoadData()
        FillCommonFilters()
        FillProcessCampaigns()
    End Sub
    Private Sub FillCommonFilters()
        Dim db As New DBAccess
        Dim dt As DataTable = db.ReturnTable("select * from tbl_Reports_DatePeriods")
        db = Nothing
        Dim dr As DataRow = dt.NewRow
        dr(0) = 10
        dr(1) = "Between"
        dt.Rows.Add(dr)
        CboPeriod.DataTextField = "Caption"
        CboPeriod.DataValueField = "Period"
        CboPeriod.DataSource = dt
        CboPeriod.DataBind()
        db = New DBAccess
        dt = db.ReturnTable("Select * from tbl_Reports_GroupBy where id <> 4")
        db = Nothing
        CboGroup.DataTextField = "Caption"
        CboGroup.DataValueField = "ID"
        CboGroup.DataSource = dt
        CboGroup.DataBind()
    End Sub
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        HumanMessage.Style.Item("visibility") = "hidden"
        If Not IsPostBack Then
            ReportType = Request.QueryString("ReportType")
            If Session("AgentID") <> "" Then
                CampaignID = Session("CampaignID")
                AgentID = Session("AgentID")
                PanelReports.Controls.Add(Common.GetMenu(Request.Url, AgentID, Request.ApplicationPath))
                ucDateFrom.Visible = False
                UcDateTo.Visible = False
                lblAnd.Visible = False
                LoadData()
                fillgrid()
            End If
        End If
    End Sub
    Private Sub fillgrid()

        Dim db As New DBAccess
        db.slDataAdd("Period", CboPeriod.SelectedValue)
        db.slDataAdd("Campaignid", CampaignID)
        Dim startday As Integer, endday As Integer
        If CboPeriod.SelectedValue = 10 Then
            startday = ucDateFrom.yyyymmdd
            endday = UcDateTo.yyyymmdd
        Else
            db = New DBAccess("CRM")
            db.slDataAdd("Period", CboPeriod.SelectedValue)
            Dim dr As DataRow = db.ReturnRow("usp_GetStart_EndDateForAPeriod", True)
            db = Nothing
            startday = dr(0)
            endday = dr(1)
        End If

        db = New DBAccess
        Dim dt As DataTable

        db.slDataAdd("DateFrom", startday)
        db.slDataAdd("dateTo", endday)
        db.slDataAdd("campaignid", CampaignID)
        db.slDataAdd("GroupBy", CboGroup.SelectedValue)
        dt = db.ReturnTable("usp_ATC", , True)
        
        LblError.Text = "Between " & IntegerToDateString(startday) & "  and " & IntegerToDateString(endday) & " for " & cboCampaigns.SelectedItem.Text & " campaign"

        db = Nothing
        If dt.Rows.Count > 0 Then
            GridView1.AutoGenerateColumns = True
            CreateGridColumns(dt.Columns)
            GridView1.DataSource = dt
            GridView1.DataBind()
            'GridView1.Columns(1).Visible = False
        End If
        

    End Sub
#End Region
#Region "GrisOperation"
    Private Sub CreateGridColumns(ByVal cols As DataColumnCollection)
        'Dim db As New DBAccess
        'db.slDataAdd("CampaignID", CampaignID)
        'Dim dtoutcome As DataTable = db.ReturnTable("usp_ReportOutcomeDescription", , True)
        'For Each dr In dtoutcome.Rows
        '    cols("Outcome" & dr("toOutcome")).Caption = dr("Description")
        'Next

        'GridView1.Columns.Clear()
        Dim tempcolumn As TemplateField
        Dim bouncol As BoundField
        Dim objcol As DataColumn
        For Each objcol In cols
            '    If objcol.ColumnName = "Agents" Then
            '        tempcolumn = New TemplateField
            '        Dim tmpagcol As New TemplateAgentName
            '        tempcolumn.HeaderText = "Agents"
            '        tmpagcol.DataImageField = "AgentStatus"
            '        tmpagcol.DataTextField = objcol.ColumnName
            '        tempcolumn.ItemStyle.HorizontalAlign = HorizontalAlign.Left
            '        tempcolumn.ItemTemplate = tmpagcol
            '        GridView1.Columns.Add(tempcolumn)
            If objcol.ColumnName.ToLower = "column1" Then
                objcol.ColumnName = CboGroup.SelectedItem.Text
                'bouncol = New BoundField
                'bouncol.HeaderText = CboGroup.SelectedItem.Text
                'bouncol.DataField = objcol.ColumnName


                'GridView1.Columns.Add(bouncol)

                '    ElseIf objcol.ColumnName.Contains("Outcome") Then
                'If objcol.Caption <> objcol.ColumnName Then
                '    bouncol = New BoundField
                '    bouncol.HeaderText = objcol.Caption
                '    bouncol.DataField = objcol.ColumnName


                '    GridView1.Columns.Add(bouncol)
            End If
            '    Else
            'If objcol.ColumnName <> "Agentstatus" Then
            '    bouncol = New BoundField
            '    bouncol.HeaderText = objcol.ColumnName
            '    bouncol.DataField = objcol.ColumnName


            '    GridView1.Columns.Add(bouncol)
            'End If

            '    End If

        Next


    End Sub
    'Protected Sub GridView1_PreRender(ByVal sender As Object, ByVal e As System.EventArgs) Handles GridView1.PreRender
    '    GridView1.UseAccessibleHeader = True

    'End Sub
    Protected Sub GridView1_RowDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles GridView1.RowDataBound
        If e.Row.RowType = DataControlRowType.Header Then
            ReDim footerval(e.Row.Cells.Count - 1)
        End If
        If e.Row.RowType = DataControlRowType.DataRow Then
            For i As Integer = 1 To footerval.Length - 1
                If Not e.Row.Cells(i).Text.Contains("nbsp") Then
                    footerval(i) = footerval(i) + e.Row.Cells(i).Text
                End If
            Next
        End If
        If e.Row.RowType = DataControlRowType.Footer Then
            e.Row.Cells(0).Text = "Total"
            For i As Integer = 1 To footerval.Length - 1
                e.Row.Cells(i).Text = footerval(i)
            Next
        End If

    End Sub
#End Region
#Region "Event"
    Protected Sub cboCampaigns_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboCampaigns.SelectedIndexChanged
        CampaignID = cboCampaigns.SelectedValue
        fillgrid()
       
    End Sub
    Protected Sub CboPeriod_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles CboPeriod.SelectedIndexChanged
        If CboPeriod.SelectedValue = 10 Then
            ucDateFrom.Visible = True
            UcDateTo.Visible = True
            lblAnd.Visible = True
            fillgrid()
        Else
            ucDateFrom.Visible = False
            UcDateTo.Visible = False
            lblAnd.Visible = False
            fillgrid()
        End If
    End Sub
    Protected Sub ImageButton1_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton1.Click
        fillgrid()
        GridViewExportUtil.Export(lblReportName.Text & "-" & LblError.Text & ".xls", Me.GridView1)
    End Sub
    Protected Sub CboGroup_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles CboGroup.SelectedIndexChanged
        fillgrid()
    End Sub

    Protected Sub btnFilter_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnFilter.Click
        fillgrid()
    End Sub

    Protected Sub btnRefresh_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnRefresh.Click
        fillgrid()
    End Sub
#End Region
#Region "Support Function"
    Private Function IntegerToDateString(ByVal d As Integer) As String
        Return d.ToString.Substring(0, 4) & "-" & d.ToString.Substring(4, 2) & "-" & d.ToString.Substring(6, 2)
    End Function

    Private Sub FillProcessCampaigns()
        Common.FillProcessCampaigns(CboProcess, cboCampaigns, AgentID, CampaignID)
    End Sub

#End Region
    Protected Sub imgfav_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles imgfav.Click
        Common.AddToFav(AgentID, "ATC")
        SuccessMessage("Report has been added to your favourite list")
        fillgrid()
    End Sub
#Region "Utility"

    Private Sub AlertMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMFail"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub

    Private Sub SuccessMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMSuccess"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub

    Public Overrides Sub VerifyRenderingInServerForm(ByVal Control As Control)

    End Sub

#End Region
End Class
