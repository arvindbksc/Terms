﻿Imports com.nss.DBAccess
Imports System.Data
Imports System.Web.UI.DataVisualization.Charting
Imports System.Drawing

Partial Class PerfSum_GordonDashboard
    Inherits System.Web.UI.Page

#Region "--- Properties ---"
    'Property CampaignID() As Integer
    '    Get
    '        Return ViewState("CampaignID")
    '    End Get
    '    Set(ByVal value As Integer)
    '        ViewState("CampaignID") = value
    '        Session("CampaignID") = value
    '    End Set
    'End Property
    Property AgentID() As String
        Get
            Return ViewState("AgentID")
        End Get
        Set(ByVal value As String)
            ViewState("AgentID") = value
        End Set
    End Property
#End Region

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            If Session("agentid") Is Nothing Then
                FormsAuthentication.SignOut()
            End If
            'Session("AgentID") = "NSS51102"
            If Session("AgentID") <> "" Then
                BindGroupByMembers()
                ' CampaignID = Session("CampaignID")
                AgentID = Session("AgentID")
                LoadData()
                UcDateTo.Visible = False
                ucDateFrom.Visible = False
                lblAnd.Visible = False
                PanelReports.Controls.Add(Common.GetMenu(Request.Url, AgentID, Request.ApplicationPath))
            End If
        End If

    End Sub

#Region "--- Functions ---"
    Private Sub LoadData()
        FillCommonFilters()
    End Sub
    Private Sub FillCommonFilters()
        Dim db As New DBAccess
        Dim dt As DataTable = db.ReturnTable("select * from tbl_Reports_DatePeriods")
        db = Nothing
        Dim dr As DataRow = dt.NewRow
        dr(0) = 10
        dr(1) = "Between"
        dt.Rows.Add(dr)
        CboPeriod.DataTextField = "Caption"
        CboPeriod.DataValueField = "Period"
        CboPeriod.DataSource = dt
        CboPeriod.DataBind()

        db = New DBAccess
        dt = db.ReturnTable("Select * from tbl_Reports_GroupBy")
        db = Nothing
    End Sub

    Private Function IntegerToDateString(ByVal d As Integer) As String
        Return d.ToString.Substring(0, 4) & "-" & d.ToString.Substring(4, 2) & "-" & d.ToString.Substring(6, 2)
    End Function

    Private Sub FillData()
        If cboGroupMembers.SelectedItem.Text = "--Select--" Then
            Exit Sub
        End If
        '------------------
        Dim ds As DataSet

        Dim db As New DBAccess
        Dim startday As Integer, endday As Integer
        Dim sdate, edate As DateTime
        If CboPeriod.SelectedValue = 10 Then
            startday = ucDateFrom.yyyymmdd
            endday = UcDateTo.yyyymmdd
            sdate = ucDateFrom.value
            edate = UcDateTo.value
            ' ChartPeriod = DateDiff(DateInterval.Day, sdate, edate)
        Else
            db = New DBAccess
            db.slDataAdd("Period", CboPeriod.SelectedValue)
            db.slDataAdd("Campaignid", 281)
            Dim dr As DataRow = db.ReturnRow("usp_GetStart_EndDateForAPeriod", True)
            db = Nothing
            startday = dr(0)
            endday = dr(1)
            sdate = IntegerToDateString(startday)
            edate = IntegerToDateString(endday)
            ' ChartPeriod = DateDiff(DateInterval.Day, sdate, edate)
        End If
        db = Nothing
        '----------------- 
        db = New DBAccess

        db.slDataAdd("startday", startday)
        db.slDataAdd("endday", endday)
        db.slDataAdd("campaignid", 281)
        'db.slDataAdd("GroupBy", CboGroupByCriteria.SelectedValue)
        db.slDataAdd("groupBymembers", cboGroupMembers.SelectedValue)
        ds = db.ReturnDataset("usp_Morris_ScoreCard_Data", True)
        db = Nothing

        'for all data
        If ds.Tables(1).Rows.Count > 0 Then
            FillFilteredData(ds.Tables(1))
        End If

        'for the attendance
        If ds.Tables(0).Rows.Count > 0 Then
            FillAttendanceData(ds.Tables(0))
        End If


    End Sub

#End Region
#Region "--- Functions---"

    Private Sub BindGroupByMembers()
        Dim db As DBAccess
        Dim dtSearch As DataTable
        '------------------------------productivity
        db = New DBAccess
        db.slDataAdd("campaignid", 281)
        dtSearch = db.ReturnTable("usp_GetAgentsOfTheProcess", , True)
        db = Nothing

        If dtSearch.Rows.Count > 0 Then
            Dim row As DataRow = dtSearch.NewRow
            row.Item(1) = -1
            row.Item(0) = "--Select--"
            dtSearch.Rows.InsertAt(row, 0)
            cboGroupMembers.Items.Clear()

            cboGroupMembers.DataValueField = "AgentId"
            cboGroupMembers.DataTextField = "Agent Name"
            cboGroupMembers.DataSource = dtSearch
            cboGroupMembers.DataBind()
        Else
            cboGroupMembers.DataSource = Nothing
            cboGroupMembers.DataBind()
        End If
    End Sub

    Private Sub FillFilteredData(ByVal dt As DataTable)

        Dim Attendance As Integer

        If dt.Rows.Count > 0 Then
            For Each row As DataRow In dt.Rows
                row("TotalErrors") = row("Errors(Int)") + row("Errors(Ext)")
                '------------
                If row("CallMonitored") = 0 Then
                    row("Quality %") = 0
                Else
                    row("Quality %") = (row("CallMonitored") - row("TotalErrors")) / row("CallMonitored") * 100.0
                End If
                '-----------------
                If row("AttendanceStatus") = "P" Then
                    Attendance = 1
                ElseIf row("AttendanceStatus") = "HD" Or row("AttendanceStatus") = "HDLWP" Then
                    Attendance = 0.5
                Else
                    Attendance = 0
                End If
                row("TotalScore") = Attendance * 0.1 + row("TotalAds") * 0.5 + row("Quality %") * 0.3 + row("InitiativePoints") * 0.1
            Next
        End If

        dt.Columns.Remove("NonFatalQCount")
        dt.Columns.Remove("NonFatalErrorCount")
        dt.Columns.Remove("CallMonitored")

        Dim dtAgent As DataTable = dt.Select("AgentID='" & cboGroupMembers.SelectedValue & "'").CopyToDataTable
        'Dim dtAgent As DataTable = dt.Copy


        Dim dtAll As DataTable
        ' Dim countAgents As Integer
        Dim dtSelect As DataTable
        Dim index As Integer = 0

        For Each row As DataRow In dtAgent.Rows
            'dtAll = dt.Select("Date='" & row("Date") & "'" & " AND AgentID<>'" & row("AgentID") & "'").CopyToDataTable()
            dtAll = dt.Select("Date='" & row("Date") & "'").CopyToDataTable()
            'countAgents = dtAll.Rows.Count

            If dtAll.Select("TotalScore >" & row("TotalScore")).Length > 0 Then
                dtSelect = dtAll.Select("TotalScore >" & row("TotalScore")).CopyToDataTable()
                row("CurrentRank") = dtSelect.Rows.Count + 1
            ElseIf dtAll.Select("TotalScore =" & row("TotalScore")).Length > 0 Then
                row("CurrentRank") = 1
            End If


            If index > 0 Then
                'To set Previous Rank
                row("PreviousRank") = dtAgent.Rows.Item(index - 1)("CurrentRank")
                'To set for WO
                If row("AttendanceStatus") = "WO" Then
                    row("CurrentRank") = dtAgent.Rows.Item(index - 1)("CurrentRank")
                End If
            End If

            index += 1
        Next

        'To remove the first row which is before date
        If dtAgent.Rows.Count = 1 Then
        ElseIf dtAgent.Rows.Count > 0 Then
            dtAgent.Rows.RemoveAt(0)
        End If

        GridView1.DataSource = dtAgent
        GridView1.DataBind()

    End Sub

    Private Sub FillAttendanceData(ByVal dtAttendance As DataTable)
        Dim sum As Decimal = 0
        Dim sumPresent As Decimal = 0
        Dim Absenteeismrate As String = 0
        Dim ShrinkageRate As String = 0
        Dim newRow As DataRow = dtAttendance.NewRow
        Dim newRow2 As DataRow = dtAttendance.NewRow

        If dtAttendance.Rows.Count > 0 Then
            For Each row As DataRow In dtAttendance.Rows
                Select Case row("AttendanceStatus")
                    Case "P"
                        sumPresent += 1
                    Case "LWP"
                        sum += 1
                    Case "A"
                        sum += 1
                    Case "L"
                        sum += 1
                    Case "HD"
                        sum += 0.5
                    Case "HDLWP"
                        sum += 0.5
                    Case "WO"
                        sum += 0
                    Case Else
                        sum += 0
                End Select
            Next

            Absenteeismrate = Math.Round(sum / (sum + sumPresent), 2)
            ShrinkageRate = Math.Round(sum / (sum + sumPresent), 2)
            newRow(0) = "Absenteeism Rate"
            newRow(1) = Absenteeismrate + " %"

            newRow2(0) = "Shrinkage Rate"
            newRow2(1) = ShrinkageRate + " %"

            dtAttendance.Rows.Add(newRow)
            dtAttendance.Rows.Add(newRow2)
        End If

        GridView2.DataSource = dtAttendance
        GridView2.DataBind()
    End Sub

#End Region

#Region "--- Events ---"
    Protected Sub CboPeriod_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles CboPeriod.SelectedIndexChanged
        If CboPeriod.SelectedValue = 10 Then
            ucDateFrom.Visible = True
            UcDateTo.Visible = True
            lblAnd.Visible = True
            FillData()
        Else
            ucDateFrom.Visible = False
            UcDateTo.Visible = False
            lblAnd.Visible = False
            FillData()
        End If
    End Sub

    Protected Sub ucDateFrom_Changed(ByVal sender As Object, ByVal e As System.EventArgs) Handles ucDateFrom.Changed
        FillData()
    End Sub

    Protected Sub UcDateTo_Changed(ByVal sender As Object, ByVal e As System.EventArgs) Handles UcDateTo.Changed
        FillData()
    End Sub

    Protected Sub cboGroupMembers_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboGroupMembers.SelectedIndexChanged
        FillData()
    End Sub

    Protected Sub btnRefresh_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnRefresh.Click
        FillData()
        ' SuccessMessage("test")
    End Sub

    Protected Sub GridView1_RowDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles GridView1.RowDataBound
        If e.Row.RowType = DataControlRowType.DataRow Then
            If IsNumeric(e.Row.Cells(11).Text) And IsNumeric(e.Row.Cells(12).Text) Then
                If CInt(e.Row.Cells(11).Text) < CInt(e.Row.Cells(12).Text) Then
                    CType(e.Row.FindControl("gdImage"), ImageButton).ImageUrl = "..\_assets\img\up.gif"
                ElseIf CInt(e.Row.Cells(11).Text) > CInt(e.Row.Cells(12).Text) Then
                    CType(e.Row.FindControl("gdImage"), ImageButton).ImageUrl = "..\_assets\img\down2.gif"
                ElseIf CInt(e.Row.Cells(11).Text) = CInt(e.Row.Cells(12).Text) Then
                    CType(e.Row.FindControl("gdImage"), ImageButton).ImageUrl = "..\_assets\img\bg.gif"
                End If
            Else
                CType(e.Row.FindControl("gdImage"), ImageButton).ImageUrl = "..\_assets\img\bg.gif"
            End If
        End If
    End Sub

#End Region

End Class
