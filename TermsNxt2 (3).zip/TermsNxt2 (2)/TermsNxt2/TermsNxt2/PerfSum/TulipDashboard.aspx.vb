﻿Imports com.nss.DBAccess
Imports System.Data
Partial Class TulipDashboard
    Inherits System.Web.UI.Page
#Region "Properties"

    Property ReportType() As Integer
        Get
            Return ViewState("ReportType")
        End Get
        Set(ByVal value As Integer)
            ViewState("ReportType") = value
        End Set
    End Property
    Property CampaignID() As Integer
        Get
            Return ViewState("CampaignID")
        End Get
        Set(ByVal value As Integer)
            ViewState("CampaignID") = value
        End Set
    End Property

    Property AgentID() As String
        Get
            Return ViewState("AgentID")
        End Get
        Set(ByVal value As String)
            ViewState("AgentID") = value
        End Set
    End Property
#End Region
#Region "Load"
    Private Sub LoadData()
        FillCommonFilters()
        FillProcessCampaigns()
    End Sub
#End Region
#Region "Support function"
    Private Sub FillCommonFilters()
        Dim db As New DBAccess
        Dim dt As DataTable = db.ReturnTable("select * from tbl_Reports_DatePeriods")
        db = Nothing
        Dim dr As DataRow = dt.NewRow
        dr(0) = 10
        dr(1) = "Between"
        dt.Rows.Add(dr)
        CboPeriod.DataTextField = "Caption"
        CboPeriod.DataValueField = "Period"
        CboPeriod.DataSource = dt
        CboPeriod.DataBind()
    End Sub
    Private Sub FillProcessCampaigns()
        Common.FillCampaigns(cboCampaigns, AgentID)
        Dim lstcampaign As New ListItem
        lstcampaign.Value = 0
        lstcampaign.Text = "All"
        If cboCampaigns.Items.Contains(lstcampaign) Then
            cboCampaigns.Items.Remove(lstcampaign)
        End If
    End Sub
    Private Function IntegerToDateString(ByVal d As Integer) As String
        Return d.ToString.Substring(0, 4) & "-" & d.ToString.Substring(4, 2) & "-" & d.ToString.Substring(6, 2)
    End Function
    Private Sub ExportToexcel()
        Dim tw As New IO.StringWriter()
        Dim hw As New System.Web.UI.HtmlTextWriter(tw)
        Response.ContentType = "application/vnd.ms-excel"
        Response.AddHeader("content-disposition", "attachment;filename=" & lblReportName.Text & "-" & LblError.Text & ".xls")
        Response.Charset = ""
        EnableViewState = False
        GridView1.RenderControl(hw)
        Response.Write(tw.ToString())
        Response.End()
    End Sub
#End Region
#Region "Utility"

    Private Sub AlertMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMFail"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub

    Private Sub SuccessMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMSuccess"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub
#End Region
#Region "Grid Function"
    Private Sub fillgrid()

        '-------------------------------------------------------------------------------------
        '-------------------------------------------------------------------------------------
        Dim db As New DBAccess("report")
        Dim startday As Integer, endday As Integer
        If CboPeriod.SelectedValue = 10 Then
            startday = ucDateFrom.yyyymmdd
            endday = UcDateTo.yyyymmdd
        Else
            db = New DBAccess
            db.slDataAdd("Period", CboPeriod.SelectedValue)
            db.slDataAdd("Campaignid", CampaignID)
            Dim dr As DataRow = db.ReturnRow("usp_GetStart_EndDateForAPeriod", True)
            db = Nothing
            startday = dr(0)
            endday = dr(1)
        End If
        lblReportName.Text = "Dashboard"
        LblError.Text = "Between " & IntegerToDateString(startday) & "  and " & IntegerToDateString(endday) & " for " & cboCampaigns.SelectedItem.Text & " campaign"


        Try
            ' ''---------------Option2 ----------------------------Start

            db = New DBAccess("report")
            db.slDataAdd("datefrom", startday)
            db.slDataAdd("dateto", endday)
            db.slDataAdd("campaignid", cboCampaigns.SelectedValue)
            ' db.slDataAdd("type", "daterange") '''' ------change
            Dim dtDateRange As DataTable = db.ReturnTable("usp_getTulipReportData_Terms", , True)
            db = Nothing


            Dim dtFinal As DataTable = New DataTable

            Dim col1 As DataColumn = New DataColumn("Time Range", System.Type.GetType("System.String"))
            dtFinal.Columns.Add(col1)
            Dim col2 As DataColumn = New DataColumn("Legend", System.Type.GetType("System.String"))
            dtFinal.Columns.Add(col2)
            Dim col3 As DataColumn = New DataColumn("Reports Count", System.Type.GetType("System.String"))
            dtFinal.Columns.Add(col3)
            Dim col4 As DataColumn = New DataColumn("% Contribution", System.Type.GetType("System.String"))
            dtFinal.Columns.Add(col4)

            Dim total As Integer = 0

            Dim row As DataRow
            If dtDateRange.Rows.Count > 0 Then
                For i As Integer = 0 To dtDateRange.Columns.Count - 1
                    row = dtFinal.NewRow
                    For j As Integer = 0 To dtDateRange.Rows.Count - 1
                        row("Time Range") = dtDateRange.Columns(i).ColumnName
                        row("Reports Count") = dtDateRange.Rows(j)(i)
                        total += dtDateRange.Rows(j)(i)
                    Next
                    dtFinal.Rows.Add(row)
                Next

                For m As Integer = 0 To dtFinal.Rows.Count - 1
                    dtFinal.Rows(m)("% Contribution") = IIf(total = 0, 0, Math.Round(dtFinal.Rows(m)("Reports Count") * 100.0 / total, 2))
                Next
            End If

            GridView1.DataSource = dtFinal
            GridView1.DataBind()
            ''---------------Option2 ----------------------------End
        Catch ex As Exception
            GridView1.DataSource = Nothing
            GridView1.DataBind()
        End Try
    End Sub
#End Region

#Region "Event"
    Protected Sub CboPeriod_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles CboPeriod.SelectedIndexChanged
        If CboPeriod.SelectedValue = 10 Then
            ucDateFrom.Visible = True
            UcDateTo.Visible = True
            lblAnd.Visible = True
            fillgrid()
        Else
            ucDateFrom.Visible = False
            UcDateTo.Visible = False
            lblAnd.Visible = False
            fillgrid()
        End If
    End Sub

    Protected Sub ImageButton1_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton1.Click
        fillgrid()
        GridViewExportUtil.Export(lblReportName.Text & "-" & LblError.Text & ".xls", Me.GridView1)
    End Sub

    Protected Sub imgfav_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles imgfav.Click
        Common.AddToFav(AgentID, "Tulip Dashboard")
        SuccessMessage("Report has been added to your favourite list")
        fillgrid()
    End Sub
    Protected Sub cboCampaigns_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboCampaigns.SelectedIndexChanged
        fillgrid()
    End Sub
    Protected Sub btnRefresh_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnRefresh.Click
        fillgrid()
    End Sub
#End Region
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        HumanMessage.Style.Item("visibility") = "hidden"
        If Not IsPostBack Then
            If Session("AgentID") <> "" Then
                CampaignID = Session("CampaignID")
                AgentID = Session("AgentID")
                PanelReports.Controls.Add(Common.GetMenu(Request.Url, AgentID, Request.ApplicationPath))
                LoadData()
                fillgrid()
                UcDateTo.Visible = False
                ucDateFrom.Visible = False
                lblAnd.Visible = False
            End If
        End If
    End Sub



    Protected Sub GridView1_RowDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles GridView1.RowDataBound
        If e.Row.Cells(0).Text = "Before Time" Then
            'e.Row.BackColor = Drawing.Color.FromName("#33CC33")
            CType(e.Row.FindControl("lblLegend"), Label).BackColor = Drawing.Color.FromName("#33CC33")
        ElseIf e.Row.Cells(0).Text = "0" Then
            CType(e.Row.FindControl("lblLegend"), Label).BackColor = Drawing.Color.FromName("#00B050")
            'e.Row.BackColor = Drawing.Color.FromName("#00B050")
        ElseIf e.Row.Cells(0).Text = "BETWEEN 0 AND 04:59" Then
            CType(e.Row.FindControl("lblLegend"), Label).BackColor = Drawing.Color.FromName("#FFFF00")
            'e.Row.BackColor = Drawing.Color.FromName("#FFFF00")


        ElseIf e.Row.Cells(0).Text = "BETWEEN 5 AND 14:59" Then
            CType(e.Row.FindControl("lblLegend"), Label).BackColor = Drawing.Color.FromName("#FFC000")
            'e.Row.BackColor = Drawing.Color.FromName("#FFC000")
        ElseIf e.Row.Cells(0).Text = "BETWEEN 15 AND 29:59" Then
            CType(e.Row.FindControl("lblLegend"), Label).BackColor = Drawing.Color.FromName("#FF0000")
            ' e.Row.BackColor = Drawing.Color.FromName("#FF0000")
        ElseIf Replace(e.Row.Cells(0).Text, "&gt;", ">") = "> 29:59" Then
            CType(e.Row.FindControl("lblLegend"), Label).BackColor = Drawing.Color.FromName("#C00000")
            'e.Row.BackColor = Drawing.Color.FromName("#C00000")

        End If

    End Sub
End Class
