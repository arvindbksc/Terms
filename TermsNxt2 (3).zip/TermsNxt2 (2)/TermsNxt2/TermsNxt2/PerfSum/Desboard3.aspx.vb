﻿Imports com.nss.DBAccess
Imports System.Data
Partial Class PerfSum_Desboard3
    Inherits System.Web.UI.Page
#Region "Properties"

    Property CampaignID() As Integer
        Get
            Return ViewState("CampaignID")
        End Get
        Set(ByVal value As Integer)
            ViewState("CampaignID") = value
            Session("CampaignID") = value
        End Set
    End Property
    Property AgentID() As String
        Get
            Return ViewState("AgentID")
        End Get
        Set(ByVal value As String)
            ViewState("AgentID") = value
        End Set
    End Property
    Property ChartPeriod() As Integer
        Get
            Return ViewState("ChartPeriod")
        End Get
        Set(ByVal value As Integer)
            ViewState("ChartPeriod") = value
        End Set
    End Property
    Property ChartGroupBy() As Integer
        Get
            Return ViewState("ChartGroupBy")
        End Get
        Set(ByVal value As Integer)
            ViewState("ChartGroupBy") = value
        End Set
    End Property
    Property Campaigntype() As Integer
        Get
            Return ViewState("Campaigntype")
        End Get
        Set(ByVal value As Integer)
            ViewState("Campaigntype") = value
            'Session("ProcessID") = value
        End Set
    End Property

#End Region

    Private Sub CreateChartPreview()
        Dim chart As Panel, img As Image
        Dim ictr As Integer
        ChartContainerInner.Style.Item("width") = 3200
    End Sub
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            If Session("agentid") Is Nothing Then
                FormsAuthentication.SignOut()
            End If
            If Session("AgentID") <> "" Then
                ChartPeriod = 3
                ChartGroupBy = 3
                CampaignID = Session("CampaignID")
                AgentID = Session("AgentID")
                FillProcessCampaigns()
                FillMenu()
                'FillSummary()
                FillGraph()
                FillGrid()
            End If

        End If
    End Sub
    Private Sub FillGrid()
        Dim db As New DBAccess
        db.slDataAdd("Period", 4)
        db.slDataAdd("Campaignid", CampaignID)
        Dim dr As DataRow = db.ReturnRow("usp_GetStart_EndDateForAPeriod", True)
        db = Nothing
        'lbldate.Text = dr(3)
        db = New DBAccess("CRM")
        db.slDataAdd("startday", dr(0))
        db.slDataAdd("endday", dr(1))
        Dim dt As DataTable = db.ReturnTable("usp_getHPSCountingdata", , True)
        db = Nothing
        grvSummary.DataSource = dt
        grvSummary.DataBind()
    End Sub
    Private Sub FillMenu()
        Dim dt As New DataTable
        'Dim col1 As DataColumn
        dt.Columns.Add("displayName", Type.GetType("System.String"))
        dt.Columns.Add("HomePage", Type.GetType("System.String"))
        dt.Columns.Add("sequence", Type.GetType("System.String"))

        Dim row2 As DataRow

        row2 = dt.NewRow
        row2(0) = "Performance"
        row2(1) = "perfsum/campaignsummaryhps.aspx?groupby=0&period=3"
        row2(2) = "1"
        dt.Rows.Add(row2)

        row2 = dt.NewRow
        row2(0) = "Staffing"
        row2(1) = "Staffing/AttendanceSummary.aspx?process=59&period=3&groupby=0"
        row2(2) = "2"
        dt.Rows.Add(row2)

        row2 = dt.NewRow
        row2(0) = "Accuracy"
        row2(1) = "Quality/MainSummary.htm"
        'row2(1) = "Quality/SummaryReportPerCamp.aspx?QEID=%&cmfid=0&calltype=%&errortype=%&campid=173&DateFrom=20121201&DateTo=20121231&campName=HPS"
        row2(2) = "3"
        dt.Rows.Add(row2)

        'row2 = dt.NewRow
        'row2(0) = "Performance"
        'row2(1) = "perfsum/campaignsummaryhps.aspx?groupby=1&period=3"
        'row2(2) = "4"
        'dt.Rows.Add(row2)

        row2 = dt.NewRow
        row2(0) = "Analysis"
        'row2(1) = "PerfSum/HPSDashboard.aspx"
        row2(1) = "Graphs/HPSGraph.aspx"
        row2(2) = "5"
        dt.Rows.Add(row2)

        Dim db As DBAccess
        'Dim db As New DBAccess
        'db.slDataAdd("userid", AgentID)
        'Dim dt As DataTable = db.ReturnTable("usp_getUserModule", , True)
        'db = Nothing


        Dim tbl As New HtmlTable
        tbl.Attributes.Add("class", "menu")
        tbl.CellPadding = 4
        tbl.CellSpacing = 4
        Dim tr As HtmlTableRow
        Dim td As HtmlTableCell
        For Each row As DataRow In dt.Rows
            tr = New HtmlTableRow
            td = New HtmlTableCell
            td.InnerHtml = "<a href='../" & row.Item(1) & "'><div class='item'><span class='left'>" & row.Item(0)
            td.InnerHtml += "</span><span class='right'><img src='../_assets/img/graygo.PNG' /></span></div></a>"
            tr.Cells.Add(td)
            tbl.Rows.Add(tr)
        Next



        'db = New DBAccess
        'db.slDataAdd("userid", AgentID)
        'Dim dtfav As DataTable = db.ReturnTable("usp_getUserfavourite", , True)
        'db = Nothing

        Dim dtfav As New DataTable
        'Dim col1 As DataColumn
        dtfav.Columns.Add("Name", Type.GetType("System.String"))
        dtfav.Columns.Add("shortURL", Type.GetType("System.String"))

        Dim row3 As DataRow

        row3 = dtfav.NewRow
        row3(0) = "Volume"
        row3(1) = "perfsum/volume.aspx"
        dtfav.Rows.Add(row3)


        row3 = dtfav.NewRow
        row3(0) = "Utilization"
        row3(1) = "perfsum/utilization.aspx"
        dtfav.Rows.Add(row3)

        row3 = dtfav.NewRow
        row3(0) = "SLA"
        row3(1) = "perfsum/willsdashboard.aspx"
        dtfav.Rows.Add(row3)

        row3 = dtfav.NewRow
        row3(0) = "Data Report"
        row3(1) = "data/TransactionData.aspx?campaign=173&groupby=0&period=3"
        dtfav.Rows.Add(row3)

        row3 = dtfav.NewRow
        row3(0) = "Balance Score Card"
        row3(1) = "perfsum/Scorecard.htm"
        dtfav.Rows.Add(row3)

        row3 = dtfav.NewRow
        row3(0) = "Claims Ageing"
        row3(1) = "perfsum/ClaimsAgeing.htm"
        dtfav.Rows.Add(row3)

        If dtfav.Rows.Count > 0 Then
            tr = New HtmlTableRow
            td = New HtmlTableCell
            td.Attributes.Add("class", "heading")

            td.InnerHtml = "<div class='heading'><span class='left'>My Favourites</span></div>"
            tr.Cells.Add(td)
            tbl.Rows.Add(tr)
            For Each row As DataRow In dtfav.Rows
                tr = New HtmlTableRow
                td = New HtmlTableCell
                td.InnerHtml = "<a href='../" & row.Item(1) & "'><div class='item'><span class='left'>" & row.Item(0)
                td.InnerHtml += "</span><span class='right'><img src='../_assets/img/graygo.PNG' /></span></div></a>"
                tr.Cells.Add(td)
                tbl.Rows.Add(tr)
            Next
        End If
        tr = New HtmlTableRow
        td = New HtmlTableCell
        td.Attributes.Add("class", "more")
        td.InnerHtml = "<a href='../Data/^Sitemap'><div class='more'><span class='right'>"
        td.InnerHtml += "More>></div></a>"
        tr.Cells.Add(td)
        tbl.Rows.Add(tr)
        divmenu.Controls.Add(tbl)
    End Sub
    Private Sub FillGraph()
        ChartContainerInner.Controls.Clear()
        Dim objLink As HyperLink
        Dim objImg As Image
        For ictr = 4 To 7
            objLink = New HyperLink
            objLink.NavigateUrl = "../Graphs/HPSGraph.aspx?type=ING&KPA=" & ictr + 1 & "&GraphSize=200&CampaignID=" & cboCampaigns.SelectedValue
            objLink.ID = "lnkKPA" & ictr + 1
            objImg = New Image
            objImg.ImageUrl = "../Graphs/thumbgraph.aspx?type=ING&KPA=" & ictr + 1 & "&GraphSize=200&CampaignID=" & cboCampaigns.SelectedValue
            objImg.ID = "imgKPA" & ictr + 1
            objImg.CssClass = "chart"
            objLink.Controls.Add(objImg)
            ChartContainerInner.Controls.Add(objLink)
        Next
    End Sub
    Protected Sub cboCampaigns_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboCampaigns.SelectedIndexChanged
        CampaignID = cboCampaigns.SelectedValue
        FillGrid()
        FillGraph()
    End Sub
    Private Sub FillProcessCampaigns()
        'Common.FillProcessCampaigns(CboProcess, cboCampaigns, AgentID, CampaignID)
        Dim dt As DataTable
        Dim db As New DBAccess("CRM")
        dt = db.ReturnTable("select * from tbl_Config_Campaigns where processid=103 and active=1 order by name", False)
        db = Nothing
        cboCampaigns.DataTextField = "Name"
        cboCampaigns.DataValueField = "CampaignID"
        cboCampaigns.DataSource = dt
        cboCampaigns.DataBind()
    End Sub
    Private Sub FillSummary()
        Dim db As New DBAccess
        db.slDataAdd("CampaignID", CampaignID)
        Dim dt As DataTable = db.ReturnTable("usp_DailyDashboardSummary", , True)
        db = Nothing
        db = New DBAccess

        db.slDataAdd("Period", 0)
        db.slDataAdd("Campaignid", CampaignID)

        Dim dr As DataRow = db.ReturnRow("usp_GetStart_EndDateForAPeriod", True)
        db = Nothing
        db = New DBAccess
        db.slDataAdd("Campaignid", CampaignID)
        db.slDataAdd("userid", AgentID)
        Dim dtcampaigntype As DataTable = db.ReturnTable("usp_getcampaigntype", , True)
        db = Nothing
        If dtcampaigntype.Rows.Count > 1 Then
            Campaigntype = 1
        Else
            Campaigntype = dtcampaigntype.Rows(0).Item(0)
        End If
        db = Nothing
        db = New DBAccess
        db.slDataAdd("startday", dr(0))
        db.slDataAdd("endDay", dr(1))
        db.slDataAdd("campaignid", CampaignID)
        db.slDataAdd("groupBy", 3)
        dt = db.ReturnTable("usp_CampaignPerformanceTerms2", , True)
    End Sub

    'Protected Sub cboChartPeriod_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboChartPeriod.SelectedIndexChanged
    '    ChartPeriod = cboChartPeriod.SelectedValue
    '    FillGrid()
    '    FillGraph()
    'End Sub

    Protected Sub btnRefresh_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnRefresh.Click
        'ChartPeriod = cboChartPeriod.SelectedValue

        'If ChartPeriod = 0 Then
        '    ChartGroupBy = 4

        'Else
        '    ChartGroupBy = 3
        'End If
        FillGrid()
        FillGraph()
    End Sub
    Dim previousCat As String = ""
    Dim firstRow As Integer = -1

    Protected Sub grvSummary_RowDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles grvSummary.RowDataBound
        If e.Row.RowType = DataControlRowType.Header Then
            e.Row.Cells(0).Text = ""
        End If
        If (e.Row.RowType = DataControlRowType.DataRow) Then
            e.Row.Cells(0).Font.Bold = True
            Dim i As Integer
            ' If cboChartPeriod.SelectedValue = 5 Then
            For i = 3 To e.Row.Cells.Count - 1
                If Not e.Row.Cells(i).Text Is Nothing Then
                    If Not e.Row.Cells(i).Text.Contains("&nbsp;") Then
                        If Convert.ToDouble(e.Row.Cells(i).Text) < Convert.ToDouble(e.Row.Cells(2).Text) Then
                            e.Row.Cells(i).ForeColor = Drawing.Color.Red
                        Else
                            e.Row.Cells(i).ForeColor = Drawing.Color.Green
                        End If
                    End If
                End If


            Next
            Dim drv As DataRowView = CType(e.Row.DataItem, DataRowView)
            If (previousCat = drv("Campaign").ToString) Then
                If (grvSummary.Rows(firstRow).Cells(0).RowSpan = 0) Then
                    grvSummary.Rows(firstRow).Cells(0).RowSpan = 2
                Else
                    grvSummary.Rows(firstRow).Cells(0).RowSpan = (grvSummary.Rows(firstRow).Cells(0).RowSpan + 1)
                End If
                'Remove the cell   
                e.Row.Cells.RemoveAt(0)
            Else
                'Set the vertical alignment to top  
                e.Row.VerticalAlign = VerticalAlign.Top
                'Maintain the category in memory   
                previousCat = drv("Campaign").ToString
                firstRow = e.Row.RowIndex
            End If

            'Else
            '    For i = 3 To 6
            '        If Not e.Row.Cells(i).Text Is Nothing Then
            '            If Not e.Row.Cells(i).Text.Contains("&nbsp;") Then
            '                If Convert.ToDouble(e.Row.Cells(i).Text) < Convert.ToDouble(e.Row.Cells(2).Text) Then
            '                    e.Row.Cells(i).ForeColor = Drawing.Color.Red
            '                Else
            '                    e.Row.Cells(i).ForeColor = Drawing.Color.Green
            '                End If
            '            End If
            '        End If


            '    Next
            'End If

        End If

    End Sub
End Class
