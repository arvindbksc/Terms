﻿Imports com.nss.DBAccess
Imports System.Data
Imports System.Web.UI.DataVisualization.Charting
Imports System.Drawing

Partial Class PerfSum_GordonDashboard
    Inherits System.Web.UI.Page
#Region "--- Properties ---"
    Property CampaignID() As Integer
        Get
            Return ViewState("CampaignID")
        End Get
        Set(ByVal value As Integer)
            ViewState("CampaignID") = value
            Session("CampaignID") = value
        End Set
    End Property
    Property AgentID() As String
        Get
            Return ViewState("AgentID")
        End Get
        Set(ByVal value As String)
            ViewState("AgentID") = value
        End Set
    End Property
    Property ChartPeriod() As Integer
        Get
            Return ViewState("ChartPeriod")
        End Get
        Set(ByVal value As Integer)
            ViewState("ChartPeriod") = value
        End Set
    End Property
    Property ChartGroupBy() As Integer
        Get
            Return ViewState("ChartGroupBy")
        End Get
        Set(ByVal value As Integer)
            ViewState("ChartGroupBy") = value
        End Set
    End Property
    Property Campaigntype() As Integer
        Get
            Return ViewState("Campaigntype")
        End Get
        Set(ByVal value As Integer)
            ViewState("Campaigntype") = value
        End Set
    End Property
    
#End Region
    Dim dtAllData, dtBuildingOffice, dtBuildingSublease, dtIndustrialBuilding, dtIndustrialSublease, dtOutcome, dtAbsent As DataTable

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            If Session("agentid") Is Nothing Then
                FormsAuthentication.SignOut()
            End If
            'Session("AgentID") = "NSS51102"
            If Session("AgentID") <> "" Then
                CampaignID = Session("CampaignID")
                AgentID = Session("AgentID")
                LoadData()
                DrawChart()
                UcDateTo.Visible = False
                ucDateFrom.Visible = False
                lblAnd.Visible = False
            End If
        End If
    End Sub
#Region "--- Functions ---"
    Private Sub CreateDataTableColumn()
        dtBuildingOffice = New DataTable
        dtBuildingSublease = New DataTable
        dtIndustrialBuilding = New DataTable
        dtIndustrialSublease = New DataTable

        Dim column As DataColumn
        column = New DataColumn
        With column
            .DataType = System.Type.GetType("System.String")
            .DefaultValue = "98"
        End With
        dtBuildingOffice.Columns.Add(column)
        dtBuildingOffice.Columns.Add("Market")
        dtBuildingOffice.Columns.Add("Data Count")

        Dim column1 As DataColumn
        column1 = New DataColumn
        With column1
            .DataType = System.Type.GetType("System.String")
            .DefaultValue = "98"
        End With
        dtBuildingSublease.Columns.Add(column1)
        dtBuildingSublease.Columns.Add("Market")
        dtBuildingSublease.Columns.Add("Data Count")

        Dim column2 As DataColumn
        column2 = New DataColumn
        With column2
            .DataType = System.Type.GetType("System.String")
            .DefaultValue = "98"
        End With
        dtIndustrialBuilding.Columns.Add(column2)
        dtIndustrialBuilding.Columns.Add("Market")
        dtIndustrialBuilding.Columns.Add("Data Count")

        Dim column3 As DataColumn
        column3 = New DataColumn
        With column3
            .DataType = System.Type.GetType("System.String")
            .DefaultValue = "98"
        End With
        dtIndustrialSublease.Columns.Add(column3)
        dtIndustrialSublease.Columns.Add("Market")
        dtIndustrialSublease.Columns.Add("Data Count")
    End Sub

    Private Sub LoadData()
        FillCommonFilters()
    End Sub
    Private Sub FillCommonFilters()
        Dim db As New DBAccess
        Dim dt As DataTable = db.ReturnTable("select * from tbl_Reports_DatePeriods")
        db = Nothing
        Dim dr As DataRow = dt.NewRow
        dr(0) = 10
        dr(1) = "Between"
        dt.Rows.Add(dr)
        CboPeriod.DataTextField = "Caption"
        CboPeriod.DataValueField = "Period"
        CboPeriod.DataSource = dt
        CboPeriod.DataBind()

        db = New DBAccess
        dt = db.ReturnTable("Select * from tbl_Reports_GroupBy")
        db = Nothing
    End Sub
    Private Function IntegerToDateString(ByVal d As Integer) As String
        Return d.ToString.Substring(0, 4) & "-" & d.ToString.Substring(4, 2) & "-" & d.ToString.Substring(6, 2)
    End Function
    Private Sub FillData()
        CreateDataTableColumn()
        Dim db As New DBAccess
        Dim startday As Integer, endday As Integer
        Dim sdate, edate As DateTime
        If CboPeriod.SelectedValue = 10 Then
            startday = ucDateFrom.yyyymmdd
            endday = UcDateTo.yyyymmdd
            sdate = ucDateFrom.value
            edate = UcDateTo.value
            ChartPeriod = DateDiff(DateInterval.Day, sdate, edate)
        Else
            db = New DBAccess
            db.slDataAdd("Period", CboPeriod.SelectedValue)
            db.slDataAdd("Campaignid", CampaignID)
            Dim dr As DataRow = db.ReturnRow("usp_GetStart_EndDateForAPeriod", True)
            db = Nothing
            startday = dr(0)
            endday = dr(1)
            sdate = IntegerToDateString(startday)
            edate = IntegerToDateString(endday)
            ChartPeriod = DateDiff(DateInterval.Day, sdate, edate)
        End If
        db = Nothing
        '----------------- Office Building, Office Sublease, Industrial Building, Industrial Sublease
        db = New DBAccess
        db.slDataAdd("startday", startday)
        db.slDataAdd("endDay", endday)
        dtAllData = db.ReturnTable("usp_Gordon_BuildingTypeData", , True)
        db = Nothing
        '---- Office Building
        Dim dtRow() As DataRow = dtAllData.Select("[Building Type]= 'Office'")
        For Each dr As DataRow In dtRow
            dtBuildingOffice.ImportRow(dr)
        Next
        '---- Office Sublease
        Dim dtRow3() As DataRow = dtAllData.Select("[Building Type]= 'Office Sublease'")
        For Each dr1 As DataRow In dtRow3
            dtBuildingSublease.ImportRow(dr1)
        Next
        '---- Industrial Building
        Dim dtRow1() As DataRow = dtAllData.Select("[Building Type]= 'Industrial'")
        For Each dr2 As DataRow In dtRow1
            dtIndustrialBuilding.ImportRow(dr2)
        Next
        '---- Industrial Sublease
        Dim dtRow2() As DataRow = dtAllData.Select("[Building Type]= 'Industrial Sublease'")
        For Each dr3 As DataRow In dtRow2
            dtIndustrialSublease.ImportRow(dr3)
        Next
        '----------------- Source Of Update
        db = New DBAccess
        db.slDataAdd("StartDate", startday)
        db.slDataAdd("EndDate", endday)
        dtOutcome = db.ReturnTable("usp_GordonGraphforOutcome", , True)
        db = Nothing
        '----------------- Absenteeism
        db = New DBAccess
        db.slDataAdd("StartDate", startday)
        db.slDataAdd("EndDate", endday)
        db.slDataAdd("processid", 2)
        db.slDataAdd("campaignid", 32)
        db.slDataAdd("userid", AgentID)
        db.slDataAdd("groupBy", 3)
        dtAbsent = db.ReturnTable("usp_AttendanceSummary", , True)
        db = Nothing
    End Sub

    Private Sub showlegend(ByVal tablename As DataTable)
       
    End Sub

#End Region
#Region "--- Draw Graph ---"
    Private Sub DrawChart()
        FillData()
        If Not dtAllData.Rows.Count < 0 Then
            RenderGraph(Chart1, "Data Count", "OFFICE BUILDING")
            RenderGraph(Chart2, "Data Count", "INDUSTRIAL BUILDING")
            RenderGraph(Chart3, "Data Count", "OFFICE SUBLEASE")
            RenderGraph(Chart4, "Data Count", "INDUSTRIAL SUBLEASE")
            RenderGraph(Chart5, "Data Count", "SOURCE OF UPDATE")
            RenderGraph(Chart6, "Absenteeism Rate", "ABSENTEEISM RATE")
        End If
    End Sub
    Private Sub RenderGraph(ByVal charts As Chart, ByVal yValueMem As String, ByVal Title As String)
        Dim xValueMem As String = ""
        charts.Series.Clear()
        charts.Series.Add("series1")
        charts.ChartAreas(0).AxisX.IntervalAutoMode = DataVisualization.Charting.IntervalAutoMode.FixedCount
        charts.TextAntiAliasingQuality = DataVisualization.Charting.TextAntiAliasingQuality.High
        Dim mypane As System.Web.UI.DataVisualization.Charting.Series
        mypane = charts.Series(0)
        If charts.ClientID = "Chart6" Then
            charts.Series(0).ChartType = DataVisualization.Charting.SeriesChartType.Spline
            charts.Series(0).BorderWidth = 3
            charts.Series(0).Color = Drawing.Color.Red
            charts.Series(0).MarkerStyle = DataVisualization.Charting.MarkerStyle.Diamond
            charts.Series(0).MarkerSize = 6
            charts.Series(0).MarkerColor = Drawing.Color.White
            charts.Series(0).IsValueShownAsLabel = True

        ElseIf charts.ClientID = "Chart5" Then
            charts.Series(0).ChartType = DataVisualization.Charting.SeriesChartType.Pie
        Else
            charts.Series(0).ChartType = DataVisualization.Charting.SeriesChartType.Line
        End If
        charts.Series(0).IsValueShownAsLabel = True
        charts.Series(0).MarkerColor = Drawing.Color.White
        charts.ChartAreas(0).AxisX.MajorGrid.Enabled = False
        charts.ChartAreas(0).AxisY.MajorGrid.Enabled = False
        With Chart1
            .Series.Clear()
            .Series.Add("Target")
            .Series.Add("Data Count")
            With .Series(0)
                .XValueMember = "Market"
                .YValueMembers = "Data Count"

                '.YAxisType = DataVisualization.Charting.AxisType.Primary

                .ChartType = DataVisualization.Charting.SeriesChartType.Column
                .BorderWidth = 4
                .Color = Drawing.Color.Blue
                .BackGradientStyle = DataVisualization.Charting.GradientStyle.VerticalCenter
                .BackSecondaryColor = Drawing.Color.SkyBlue
                .IsValueShownAsLabel = True
            End With
            With .Series(1)
                .XValueMember = "Market"
                .YValueMembers = "Column1"
                '.YAxisType = DataVisualization.Charting.AxisType.Secondary

                .ChartType = DataVisualization.Charting.SeriesChartType.Line
                .BorderWidth = 2
                .Color = Drawing.Color.Red
                .MarkerStyle = DataVisualization.Charting.MarkerStyle.Diamond
                .MarkerSize = 6
                .MarkerColor = Drawing.Color.Yellow
            End With
            .ChartAreas(0).AxisX.MajorGrid.Enabled = False
            .ChartAreas(0).AxisY.MajorGrid.Enabled = False
            .ChartAreas(0).AxisX.Interval = 1
            .ChartAreas(0).AxisX2.Interval = 1
            .ChartAreas(0).AxisX.IntervalAutoMode = DataVisualization.Charting.IntervalAutoMode.FixedCount
            .ChartAreas(0).AxisX2.IntervalAutoMode = DataVisualization.Charting.IntervalAutoMode.FixedCount
            .ChartAreas(0).AxisY2.MajorGrid.Enabled = False
            .DataSource = dtBuildingOffice.DefaultView
            .DataBind()
        End With

        With Chart2
            .Series.Clear()
            .Series.Add("Target")
            .Series.Add("Data Count")
            With .Series(0)
                .XValueMember = "Market"
                .YValueMembers = "Data Count"

                '.YAxisType = DataVisualization.Charting.AxisType.Primary

                .ChartType = DataVisualization.Charting.SeriesChartType.Column
                .BorderWidth = 4
                .Color = Drawing.Color.Blue
                .BackGradientStyle = DataVisualization.Charting.GradientStyle.VerticalCenter
                .BackSecondaryColor = Drawing.Color.SkyBlue
                .IsValueShownAsLabel = True
            End With
            With .Series(1)
                .XValueMember = "Column1"
                .YValueMembers = "Column1"
                '.YAxisType = DataVisualization.Charting.AxisType.Primary

                .ChartType = DataVisualization.Charting.SeriesChartType.Line
                .BorderWidth = 2
                .Color = Drawing.Color.Red
                .MarkerStyle = DataVisualization.Charting.MarkerStyle.Diamond
                .MarkerSize = 6
                .MarkerColor = Drawing.Color.Yellow
            End With
            .ChartAreas(0).AxisX.MajorGrid.Enabled = False
            .ChartAreas(0).AxisY.MajorGrid.Enabled = False
            .ChartAreas(0).AxisX.Interval = 1
            .ChartAreas(0).AxisX2.Interval = 1
            .ChartAreas(0).AxisX.IntervalAutoMode = DataVisualization.Charting.IntervalAutoMode.FixedCount
            .ChartAreas(0).AxisX2.IntervalAutoMode = DataVisualization.Charting.IntervalAutoMode.FixedCount
            .ChartAreas(0).AxisY2.MajorGrid.Enabled = False
            .DataSource = dtIndustrialBuilding.DefaultView
            .DataBind()
        End With

        With Chart3
            .Series.Clear()
            .Series.Add("Target")
            .Series.Add("Data Count")
            With .Series(0)
                .XValueMember = "Market"
                .YValueMembers = "Data Count"

                '.YAxisType = DataVisualization.Charting.AxisType.Primary

                .ChartType = DataVisualization.Charting.SeriesChartType.Column
                .BorderWidth = 4
                .Color = Drawing.Color.Blue
                .BackGradientStyle = DataVisualization.Charting.GradientStyle.VerticalCenter
                .BackSecondaryColor = Drawing.Color.SkyBlue
                .IsValueShownAsLabel = True
            End With
            With .Series(1)
                .XValueMember = "Column1"
                .YValueMembers = "Column1"
                '.YAxisType = DataVisualization.Charting.AxisType.Primary

                .ChartType = DataVisualization.Charting.SeriesChartType.Line
                .BorderWidth = 2
                .Color = Drawing.Color.Red
                .MarkerStyle = DataVisualization.Charting.MarkerStyle.Diamond
                .MarkerSize = 6
                .MarkerColor = Drawing.Color.Yellow
            End With
            .ChartAreas(0).AxisX.MajorGrid.Enabled = False
            .ChartAreas(0).AxisY.MajorGrid.Enabled = False
            .ChartAreas(0).AxisX.Interval = 1
            .ChartAreas(0).AxisX2.Interval = 1
            .ChartAreas(0).AxisX.IntervalAutoMode = DataVisualization.Charting.IntervalAutoMode.FixedCount
            .ChartAreas(0).AxisX2.IntervalAutoMode = DataVisualization.Charting.IntervalAutoMode.FixedCount
            .ChartAreas(0).AxisY2.MajorGrid.Enabled = False
            .DataSource = dtBuildingSublease.DefaultView
            .DataBind()
        End With

        With Chart4
            .Series.Clear()
            .Series.Add("Target")
            .Series.Add("Data Count")
            With .Series(0)
                .XValueMember = "Market"
                .YValueMembers = "Data Count"

                '.YAxisType = DataVisualization.Charting.AxisType.Primary

                .ChartType = DataVisualization.Charting.SeriesChartType.Column
                .BorderWidth = 4
                .Color = Drawing.Color.Blue
                .BackGradientStyle = DataVisualization.Charting.GradientStyle.VerticalCenter
                .BackSecondaryColor = Drawing.Color.SkyBlue
                .IsValueShownAsLabel = True
            End With
            With .Series(1)
                .XValueMember = "Column1"
                .YValueMembers = "Column1"
                '.YAxisType = DataVisualization.Charting.AxisType.Primary

                .ChartType = DataVisualization.Charting.SeriesChartType.Line
                .BorderWidth = 2
                .Color = Drawing.Color.Red
                .MarkerStyle = DataVisualization.Charting.MarkerStyle.Diamond
                .MarkerSize = 6
                .MarkerColor = Drawing.Color.Yellow
            End With
            .ChartAreas(0).AxisX.MajorGrid.Enabled = False
            .ChartAreas(0).AxisY.MajorGrid.Enabled = False
            .ChartAreas(0).AxisX.Interval = 1
            .ChartAreas(0).AxisX2.Interval = 1
            .ChartAreas(0).AxisX.IntervalAutoMode = DataVisualization.Charting.IntervalAutoMode.FixedCount
            .ChartAreas(0).AxisX2.IntervalAutoMode = DataVisualization.Charting.IntervalAutoMode.FixedCount
            .ChartAreas(0).AxisY2.MajorGrid.Enabled = False
            .DataSource = dtIndustrialSublease.DefaultView
            .DataBind()
        End With

        If charts.ClientID = "Chart5" Then
            charts.DataSource = dtOutcome
            xValueMem = dtOutcome.Columns(0).ColumnName
            Chart5.Series(0).XValueMember = xValueMem
            Chart5.Series(0).YValueMembers = yValueMem
            Chart5.Legends.Add("Legent1")
            Chart5.Legends("Legent1").Enabled = True
            Chart5.Legends("Legent1").Alignment = System.Drawing.StringAlignment.Near
            'Chart5.Legends("Legent1").Font.Size=System.Drawing.Size.
            Chart5.Series(0).IsVisibleInLegend = True
            'Chart5.Series(0).Label = "#PERCENT"
            'Chart5.Series(0).LegendText = "#VALX"

        ElseIf charts.ClientID = "Chart6" Then
            charts.DataSource = dtAbsent.DefaultView
            If charts.ClientID = "Chart6" Then
                xValueMem = dtAbsent.Columns(0).ColumnName
            End If
        End If
        charts.DataBind()
        If charts.ClientID = "Chart6" Then
            charts.Titles.Add(Title)
            charts.Series(0).XValueMember = xValueMem
            charts.Series(0).YValueMembers = yValueMem
            charts.Series(0).LabelFormat = "{0:n}"
        Else
            charts.Titles.Add(Title)
            charts.Series(0).XValueMember = xValueMem
            charts.Series(0).YValueMembers = yValueMem
            charts.Series(0).LabelFormat = "{0:n}"
        End If

        Chart5.Series(0).ChartType = DataVisualization.Charting.SeriesChartType.Pie
        Chart5.Series(0)("PieLabelStyle") = "outside"
        Chart5.Series(0).ShadowOffset = 1
        Chart5.Series(0)("PieDrawingStyle") = "Concave"

        'Chart1.Series(0)("PieDrawingStyle") = "Concave"
        'Chart1.Series(0).Color = Drawing.Color.CornflowerBlue
        'Chart1.Series(0).BackSecondaryColor = Drawing.Color.Navy
        'Chart1.Series(0).BackGradientStyle = GradientStyle.VerticalCenter
        'Chart1.Series(0).BackHatchStyle = ChartHatchStyle.OutlinedDiamond
        'Chart1.Series(0).ShadowOffset = 2
        'Chart1.Series(0).Label = "#PERCENT"

        'Chart2.Series(0)("PieDrawingStyle") = "Concave"
        'Chart2.Series(0).Color = Drawing.Color.CornflowerBlue
        'Chart2.Series(0).BackSecondaryColor = Drawing.Color.CadetBlue
        'Chart2.Series(0).BackGradientStyle = GradientStyle.VerticalCenter
        'Chart2.Series(0).BackHatchStyle = ChartHatchStyle.OutlinedDiamond
        'Chart2.Series(0).ShadowOffset = 2
        'Chart2.Series(0).Label = "#PERCENT"

        'Chart3.Series(0)("PieDrawingStyle") = "Concave"
        'Chart3.Series(0).Color = Drawing.Color.CornflowerBlue
        'Chart3.Series(0).BackSecondaryColor = Drawing.Color.Navy
        'Chart3.Series(0).BackGradientStyle = GradientStyle.VerticalCenter
        'Chart3.Series(0).BackHatchStyle = ChartHatchStyle.OutlinedDiamond
        'Chart3.Series(0).ShadowOffset = 2
        'Chart3.Series(0).Label = "#PERCENT"

        'Chart4.Series(0)("PieDrawingStyle") = "Concave"
        'Chart4.Series(0).Color = Drawing.Color.CornflowerBlue
        'Chart4.Series(0).BackSecondaryColor = Drawing.Color.Navy
        'Chart4.Series(0).BackGradientStyle = GradientStyle.VerticalCenter
        'Chart4.Series(0).BackHatchStyle = ChartHatchStyle.OutlinedDiamond
        'Chart4.Series(0).ShadowOffset = 2
        'Chart4.Series(0).Label = "#PERCENT"

        'Chart6.Series(0).LabelFormat = "{0:n}"
        'Chart6.Series(0).ChartType = DataVisualization.Charting.SeriesChartType.Spline
        'Chart6.Series(0).MarkerStyle = DataVisualization.Charting.MarkerStyle.Diamond
        'Chart6.Series(0).MarkerSize = 12
        'Chart6.Series(0).MarkerColor = Drawing.Color.Gray
        'Chart6.Series(0).BorderWidth = 3
        'Chart6.Series(0).IsValueShownAsLabel = True
        Chart6.Series(0).Label = "#PERCENT"

    End Sub
#End Region
#Region "--- Events ---"
    Protected Sub ImageButton1_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton1.Click
        DrawChart()
    End Sub
    Protected Sub CboPeriod_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles CboPeriod.SelectedIndexChanged
        If CboPeriod.SelectedValue = 10 Then
            ucDateFrom.Visible = True
            UcDateTo.Visible = True
            lblAnd.Visible = True
            ChartPeriod = ucDateFrom.yyyymmdd - UcDateTo.yyyymmdd
            DrawChart()
        Else
            ucDateFrom.Visible = False
            UcDateTo.Visible = False
            lblAnd.Visible = False
            DrawChart()
        End If
    End Sub
    Protected Sub ucDateFrom_Changed(ByVal sender As Object, ByVal e As System.EventArgs) Handles ucDateFrom.Changed
        DrawChart()
    End Sub
    Protected Sub UcDateTo_Changed(ByVal sender As Object, ByVal e As System.EventArgs) Handles UcDateTo.Changed
        DrawChart()
    End Sub
#End Region
End Class
