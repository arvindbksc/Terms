﻿Imports com.nss.DBAccess
Imports System.Data
Imports System.Web.UI.DataVisualization.Charting
Imports System.Drawing
Imports System.Drawing.Imaging

Partial Class PerfSum_WillsDashboard
    Inherits System.Web.UI.Page
#Region "--- Properties ---"
    Property CampaignID() As Integer
        Get
            Return ViewState("CampaignID")
        End Get
        Set(ByVal value As Integer)
            ViewState("CampaignID") = value
            Session("CampaignID") = value
        End Set
    End Property
    Property AgentID() As String
        Get
            Return ViewState("AgentID")
        End Get
        Set(ByVal value As String)
            ViewState("AgentID") = value
        End Set
    End Property
    Property ChartPeriod() As Integer
        Get
            Return ViewState("ChartPeriod")
        End Get
        Set(ByVal value As Integer)
            ViewState("ChartPeriod") = value
        End Set
    End Property
    Property GroupBy() As Integer
        Get
            Return ViewState("GroupBy")
        End Get
        Set(ByVal value As Integer)
            ViewState("GroupBy") = value
        End Set
    End Property
    Property Campaigntype() As Integer
        Get
            Return ViewState("Campaigntype")
        End Get
        Set(ByVal value As Integer)
            ViewState("Campaigntype") = value
        End Set
    End Property

#End Region
    Dim dsAll As DataSet
    Dim dtEmployer, dtTat, dtAgent, dtTransType, dtAHT, dtQuality, dt As DataTable
    Dim ds As DataSet

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            If Session("agentid") Is Nothing Then
                FormsAuthentication.SignOut()
            End If
            If Session("AgentID") <> "" Then
                CampaignID = Session("CampaignID")
                AgentID = Session("AgentID")
                PanelReports.Controls.Add(Common.GetMenu(Request.Url, AgentID, Request.ApplicationPath))
                LoadData()
                DrawChart()
                UcDateTo.Visible = False
                ucDateFrom.Visible = False
                lblAnd.Visible = False
            End If
        End If
    End Sub
#Region "--- Functions ---"
    Private Sub LoadData()
        FillCommonFilters()
        FillProcessCampaigns()
        cboCampaigns.SelectedValue = 290
        'FillMenu()
    End Sub
    'Private Sub FillMenu()
    '    Dim db As New DBAccess
    '    db.slDataAdd("userid", AgentID)
    '    Dim dt As DataTable = db.ReturnTable("usp_getUserModule", , True)
    '    db = Nothing
    '    Dim tbl As New HtmlTable
    '    tbl.Attributes.Add("class", "menu")
    '    tbl.CellPadding = 4
    '    tbl.CellSpacing = 4
    '    Dim tr As HtmlTableRow
    '    Dim td As HtmlTableCell
    '    For Each row As DataRow In dt.Rows
    '        tr = New HtmlTableRow
    '        td = New HtmlTableCell
    '        td.InnerHtml = "<a href='../" & row.Item(1) & "'><div class='item'><span class='left'>" & row.Item(0)
    '        td.InnerHtml += "</span><span class='right'><img src='../_assets/img/graygo.PNG' /></span></div></a>"
    '        tr.Cells.Add(td)
    '        tbl.Rows.Add(tr)
    '    Next

    '    db = New DBAccess
    '    db.slDataAdd("userid", AgentID)
    '    Dim dtfav As DataTable = db.ReturnTable("usp_getUserfavourite", , True)
    '    db = Nothing
    '    If dtfav.Rows.Count > 0 Then
    '        tr = New HtmlTableRow
    '        td = New HtmlTableCell
    '        td.Attributes.Add("class", "heading")

    '        td.InnerHtml = "<div class='heading'><span class='left'>My Favourites</span></div>"
    '        tr.Cells.Add(td)
    '        tbl.Rows.Add(tr)
    '        For Each row As DataRow In dtfav.Rows
    '            tr = New HtmlTableRow
    '            td = New HtmlTableCell
    '            td.InnerHtml = "<a href='../" & row.Item(1) & "'><div class='item'><span class='left'>" & row.Item(0)
    '            td.InnerHtml += "</span><span class='right'><img src='../_assets/img/graygo.PNG' /></span></div></a>"
    '            tr.Cells.Add(td)
    '            tbl.Rows.Add(tr)
    '        Next
    '    End If
    '    tr = New HtmlTableRow
    '    td = New HtmlTableCell
    '    td.Attributes.Add("class", "more")
    '    td.InnerHtml = "<a href='../Data/sitemap.aspx'><div class='more'><span class='right'>"
    '    td.InnerHtml += "More>></div></a>"
    '    tr.Cells.Add(td)
    '    tbl.Rows.Add(tr)
    '    divmenu.Controls.Add(tbl)
    ' End Sub
    Private Sub FillCommonFilters()
        Dim db As New DBAccess
        Dim dt As DataTable = db.ReturnTable("select * from tbl_Reports_DatePeriods")
        db = Nothing
        Dim dr As DataRow = dt.NewRow
        dr(0) = 10
        dr(1) = "Between"
        dt.Rows.Add(dr)
        CboPeriod.DataTextField = "Caption"
        CboPeriod.DataValueField = "Period"
        CboPeriod.DataSource = dt
        CboPeriod.DataBind()
        CboPeriod.SelectedValue = 3
        db = New DBAccess
        dt = db.ReturnTable("Select * from tbl_Reports_GroupBy")
        db = Nothing
    End Sub
    Private Sub FillProcessCampaigns()
        'Common.FillProcessCampaigns(CboProcess, cboCampaigns, AgentID, CampaignID)
        Dim dt As DataTable
        Dim db As New DBAccess("CRM")
        dt = db.ReturnTable("select * from tbl_Config_Campaigns where processid=103 and active=1 order by name", False)
        db = Nothing
        cboCampaigns.DataTextField = "Name"
        cboCampaigns.DataValueField = "CampaignID"
        cboCampaigns.DataSource = dt
        cboCampaigns.DataBind()
        cboCampaigns.SelectedValue = 292
        'Dim db As New DBAccess("CRM")
        'dt = db.ReturnTable("select * from tbl_Config_Campaigns where processid=103", False)
        'db = Nothing
        'cboCampaigns.DataTextField = "Name"
        'cboCampaigns.DataValueField = "CampaignID"
        'cboCampaigns.DataSource = dt
        'cboCampaigns.DataBind()
    End Sub
    Private Function IntegerToDateString(ByVal d As Integer) As String
        Return d.ToString.Substring(0, 4) & "-" & d.ToString.Substring(4, 2) & "-" & d.ToString.Substring(6, 2)
    End Function
   
    Private Sub FillData()
        Dim db As New DBAccess
        Dim startday As Integer, endday As Integer
        Dim sdate, edate As DateTime
        If CboPeriod.SelectedValue = 10 Then
            startday = ucDateFrom.yyyymmdd
            endday = UcDateTo.yyyymmdd
            sdate = ucDateFrom.value
            edate = UcDateTo.value
            ChartPeriod = DateDiff(DateInterval.Day, sdate, edate)
        Else
            db = New DBAccess
            db.slDataAdd("Period", CboPeriod.SelectedValue)
            db.slDataAdd("Campaignid", CampaignID)
            Dim dr As DataRow = db.ReturnRow("usp_GetStart_EndDateForAPeriod", True)
            db = Nothing
            startday = dr(0)
            endday = dr(1)
            sdate = IntegerToDateString(startday)
            edate = IntegerToDateString(endday)
            ChartPeriod = DateDiff(DateInterval.Day, sdate, edate)
        End If
        db = Nothing
        db = New DBAccess("CRM")
        db.slDataAdd("StartDate", startday)
        db.slDataAdd("EndDate", endday)
        db.slDataAdd("CampaignId", cboCampaigns.SelectedValue)
        'dsAll = db.ReturnDataset("usp_WillsDashboard", True)
        dtTat = db.ReturnTable("usp_WillsDashboard", , True)
        db = Nothing

        'dtAgent = dsAll.Tables("Table")
        'dtTransType = dsAll.Tables("Table1")
        'dtEmployer = dsAll.Tables("Table2")
        'dtTat = dsAll.Tables("Table3")

        'dtTat.Columns.Add("Target", System.Type.GetType("System.Double"), "98")

        grdTAT.DataSource = dtTat
        grdTAT.DataBind()

        db = New DBAccess
        db.slDataAdd("startday", startday)
        db.slDataAdd("endDay", endday)
        db.slDataAdd("campaignid", cboCampaigns.SelectedValue)
        db.slDataAdd("groupBy", 3)

        '----------------- AHT & Transaction

        'dtAHT = db.ReturnTable("usp_dashboard_aht", , True)
        'dtAHT.Columns.Remove("AHT")
        'dtAHT.Columns.Add("AHT", System.Type.GetType("System.Double"), "iif([Transactions]=0,0, [Transaction Duration]/[Transactions])")
        'db = Nothing

        '----------------- FAR & NFAR
        Dim db1 As New DBAccess("CRM")
        db1.slDataAdd("StartDate", startday)
        db1.slDataAdd("EndDate", endday)
        db1.slDataAdd("campaignID", cboCampaigns.SelectedValue)
        db1.slDataAdd("GroupBy", 3)
        dtQuality = db1.ReturnTable("usp_CustomDashboard_Quality", , True)
        'dtQuality.Columns.Add("Target", System.Type.GetType("System.Double"), "98")
        db1 = Nothing

        grdFAR.DataSource = dtQuality
        grdFAR.DataBind()
      
    End Sub

#End Region
#Region "--- Draw Graph ---"
    Private Sub DrawChart()
        FillData()
        ' If dt.Rows.Count > 0 Then
        'RenderGraph(Chart1, "Data Count", "AGENT")
        'RenderGraph(Chart2, "Data Count", "TRANSACTION TYPE")
        'RenderGraph(Chart3, "Data Count", "EMPLOYER")
        RenderGraph(Chart4, "Turn Around Time", "Turn Around Time MET")
        'RenderGraph(Chart7, "AHT", "AHT")
        RenderGraph(Chart8, "FAR", "Internal Quality")
        'End If
    End Sub
    Private Sub RenderGraph(ByVal charts As Chart, ByVal yValueMem As String, ByVal Title As String)
        Dim xValueMem As String = ""
        charts.Series.Clear()
        charts.Series.Add("series1")
        charts.ChartAreas(0).AxisX.IntervalAutoMode = DataVisualization.Charting.IntervalAutoMode.FixedCount
        charts.TextAntiAliasingQuality = DataVisualization.Charting.TextAntiAliasingQuality.High
        Dim mypane As System.Web.UI.DataVisualization.Charting.Series
        mypane = charts.Series(0)
        'If  charts.ClientID = "Chart3" Then
        '    charts.Series(0).ChartType = DataVisualization.Charting.SeriesChartType.Pie
        'ElseIf charts.ClientID = "Chart4" Then
        If charts.ClientID = "Chart4" Then
            charts.Series(0).ChartType = DataVisualization.Charting.SeriesChartType.Column
            charts.Series(0).MarkerColor = Drawing.Color.White
            charts.Series(0)("DrawingStyle") = "Cylinder"
            charts.Series(0).IsValueShownAsLabel = True
            charts.ChartAreas(0).AxisY.Interval = 5
            charts.ChartAreas(0).AxisY.IsStartedFromZero = False
            '--- Add New Series
            charts.Series.Add("Target1")
            charts.Series.Add("Turn Around Time")
            charts.Series(1).BorderWidth = 2
            charts.Series(1).Color = Color.Green
            charts.Series(1).XValueMember = dtTat.Columns(1).ColumnName
            charts.Series(1).YValueMembers = "Target1"
            charts.Series(1).ChartType = DataVisualization.Charting.SeriesChartType.Line
            charts.Series(1).BorderDashStyle = ChartDashStyle.Dash
            charts.Series(1).MarkerStyle = DataVisualization.Charting.MarkerStyle.Diamond
            charts.Series(1).MarkerSize = 6
            charts.Series(1).MarkerColor = Drawing.Color.Yellow
            charts.Series(1).IsValueShownAsLabel = True

        ElseIf charts.ClientID = "Chart8" Then
            charts.Series(0).ChartType = DataVisualization.Charting.SeriesChartType.Line
            charts.Series(0).ChartType = DataVisualization.Charting.SeriesChartType.Spline
            charts.Series(0).BorderWidth = 3
            charts.Series(0).Color = Drawing.Color.Red
            charts.Series(0).MarkerStyle = DataVisualization.Charting.MarkerStyle.Diamond
            charts.Series(0).MarkerSize = 6
            charts.Series(0).MarkerColor = Drawing.Color.White
            charts.Series(0).IsValueShownAsLabel = True
            charts.ChartAreas(0).AxisY.IsStartedFromZero = False
            'charts.ChartAreas(0).AxisY.Interval = 3
            '--- Add New Series
            charts.Series.Add("Target1")
            charts.Series.Add("FAR")
            charts.Series(1).BorderWidth = 2
            charts.Series(1).Color = Color.Green
            charts.Series(1).XValueMember = dtQuality.Columns(0).ColumnName
            charts.Series(1).YValueMembers = "Target1"
            charts.Series(1).ChartType = DataVisualization.Charting.SeriesChartType.Line
            charts.Series(1).BorderDashStyle = ChartDashStyle.Dash
            charts.Series(1).MarkerStyle = DataVisualization.Charting.MarkerStyle.Diamond
            charts.Series(1).MarkerSize = 6
            charts.Series(1).MarkerColor = Drawing.Color.Yellow
            charts.Series(1).IsValueShownAsLabel = True
            'Else
            '    'charts.Series(0).ChartType = DataVisualization.Charting.SeriesChartType.Column
            '    charts.Series(0).MarkerColor = Drawing.Color.White
            '    charts.Series(0)("DrawingStyle") = "Cylinder"
            '    charts.Series(0).IsValueShownAsLabel = True
        End If
        charts.Series(0).IsValueShownAsLabel = True
        charts.Series(0).MarkerColor = Drawing.Color.White
        charts.ChartAreas(0).AxisX.MajorGrid.Enabled = False
        charts.ChartAreas(0).AxisY.MajorGrid.Enabled = False

        'If charts.ClientID = "Chart1" Then
        '    charts.DataSource = dtAgent.DefaultView
        '    xValueMem = dtAgent.Columns(1).ColumnName
        'ElseIf charts.ClientID = "Chart2" Then
        '    charts.DataSource = dtTransType.DefaultView
        '    xValueMem = dtTransType.Columns(1).ColumnName
        'ElseIf charts.ClientID = "Chart3" Then
        '    charts.DataSource = dtEmployer
        '    xValueMem = dtEmployer.Columns(0).ColumnName
        '    charts.Series(0).XValueMember = xValueMem
        '    charts.Series(0).YValueMembers = yValueMem
        '    charts.Legends.Add("Legent1")
        '    charts.Legends("Legent1").Enabled = True
        '    charts.Legends("Legent1").Alignment = System.Drawing.StringAlignment.Near
        '    charts.Series(0).IsVisibleInLegend = True
        If charts.ClientID = "Chart4" Then
            charts.DataSource = dtTat.DefaultView
            xValueMem = dtTat.Columns(1).ColumnName
            'ElseIf charts.ClientID = "Chart7" Then
            '    charts.DataSource = dtAHT.DefaultView
            '    xValueMem = dtAHT.Columns(0).ColumnName
        ElseIf charts.ClientID = "Chart8" Then
            charts.DataSource = dtQuality.DefaultView
            xValueMem = dtQuality.Columns(0).ColumnName
        End If
        charts.DataBind()
        'If charts.ClientID = "Chart3" Then
        '    charts.Titles.Add(Title)
        '    charts.Series(0).ChartType = DataVisualization.Charting.SeriesChartType.Pie
        '    charts.Series(0)("PieLabelStyle") = "outside"
        '    charts.Series(0).ShadowOffset = 1
        '    charts.Series(0)("PieDrawingStyle") = "Concave"
        'Else
        charts.Titles.Add(Title)
        charts.Series(0).XValueMember = xValueMem
        charts.Series(0).YValueMembers = yValueMem
        charts.Series(0).LabelFormat = "{0:n}"
        'End If

        'If charts.ClientID <> "Chart3" Then
        '    charts.Series(0).Label = "#PERCENT"
        'End If

    End Sub
#End Region
#Region "--- Events ---"
    Protected Sub CboPeriod_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles CboPeriod.SelectedIndexChanged
        If CboPeriod.SelectedValue = 10 Then
            ucDateFrom.Visible = True
            UcDateTo.Visible = True
            lblAnd.Visible = True
            ChartPeriod = ucDateFrom.yyyymmdd - UcDateTo.yyyymmdd
            DrawChart()
        Else
            ucDateFrom.Visible = False
            UcDateTo.Visible = False
            lblAnd.Visible = False
            DrawChart()
        End If
    End Sub
    Protected Sub ucDateFrom_Changed(ByVal sender As Object, ByVal e As System.EventArgs) Handles ucDateFrom.Changed
        DrawChart()
    End Sub
    Protected Sub UcDateTo_Changed(ByVal sender As Object, ByVal e As System.EventArgs) Handles UcDateTo.Changed
        DrawChart()
    End Sub
    Protected Sub ImageButton1_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton1.Click
        DrawChart()
    End Sub
    Protected Sub cboCampaigns_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboCampaigns.SelectedIndexChanged
        DrawChart()
    End Sub
#End Region

    'Protected Sub Chart1_Click(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.ImageMapEventArgs) Handles Chart1.Click
    '    Response.Redirect("~/Graphs/Enlargedgraph.aspx")
    'End Sub

   
    Protected Sub grdFAR_RowDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles grdFAR.RowDataBound
        If e.Row.RowType = DataControlRowType.DataRow Then
            If Not e.Row.Cells(2).Text.Contains("&nbsp;") Then
                If Convert.ToDouble(e.Row.Cells(2).Text) < Convert.ToDouble(e.Row.Cells(1).Text) Then
                    e.Row.Cells(2).ForeColor = Drawing.Color.White
                    e.Row.Cells(2).BackColor = Drawing.Color.Red
                Else
                    e.Row.Cells(2).ForeColor = Drawing.Color.White
                    e.Row.Cells(2).BackColor = Drawing.Color.Green
                End If
            End If
        End If
    End Sub

    Protected Sub grdTAT_RowDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles grdTAT.RowDataBound
        If e.Row.RowType = DataControlRowType.DataRow Then
            If Not e.Row.Cells(2).Text.Contains("&nbsp;") Then
                If Convert.ToDouble(e.Row.Cells(2).Text) < Convert.ToDouble(e.Row.Cells(1).Text) Then
                    e.Row.Cells(2).ForeColor = Drawing.Color.White
                    e.Row.Cells(2).BackColor = Drawing.Color.Red
                Else
                    e.Row.Cells(2).ForeColor = Drawing.Color.White
                    e.Row.Cells(2).BackColor = Drawing.Color.Green
                End If
            End If
        End If
    End Sub
End Class
