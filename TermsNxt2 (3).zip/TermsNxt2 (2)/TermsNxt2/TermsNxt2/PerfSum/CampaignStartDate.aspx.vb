﻿Imports com.nss.DBAccess
Imports System.Data
Partial Class PerfSum_CampaignStartDate
    Inherits System.Web.UI.Page
    Dim db As New DBAccess
#Region "Properties"
    Property ReportType() As Integer
        Get
            Return ViewState("ReportType")
        End Get
        Set(ByVal value As Integer)
            ViewState("ReportType") = value
        End Set
    End Property
    Property CampaignID() As Integer
        Get
            Return 0 'ViewState("CampaignID")
        End Get
        Set(ByVal value As Integer)
            'ViewState("CampaignID") = value
        End Set
    End Property

    Property AgentID() As String
        Get
            Return ViewState("AgentID")
        End Get
        Set(ByVal value As String)
            ViewState("AgentID") = value
        End Set
    End Property
#End Region
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        HumanMessage.Style.Item("visibility") = "hidden"
        If Not IsPostBack Then
            'lblReportName.Text = ""
            AgentID = Session("AgentID")
            PanelReports.Controls.Add(Common.GetMenu(Request.Url, AgentID, Request.ApplicationPath))
            GetAgentList()
        End If
    End Sub

    Private Sub GetAgentList()
        db = New DBAccess
        Dim currentdate As DateTime = db.ReturnValue("select getdate()", False)
        Dim dtAgents As New DataTable
        db.slDataAdd("datefrom", currentdate.ToString("yyyyMMdd"))
        dtAgents = db.ReturnTable("usp_getOrionAgents", , True)
        db = Nothing
        If dtAgents.Rows.Count > 0 Then
            gvCampaignDate.DataSource = dtAgents
            gvCampaignDate.DataBind()
            Dim chk As CheckBox
            Dim txtDay, txtMonth, txtYear As TextBox
            For Each row As GridViewRow In gvCampaignDate.Rows
                chk = CType(row.FindControl("chkAgents"), CheckBox)
                txtDay = CType(row.FindControl("txtDate"), TextBox)
                txtMonth = CType(row.FindControl("txtMonth"), TextBox)
                txtYear = CType(row.FindControl("txtYear"), TextBox)
                If chk.Checked = True Then
                    chk.Enabled = False
                    txtDay.ReadOnly = True
                    txtMonth.ReadOnly = True
                    txtYear.ReadOnly = True
                End If
            Next
        End If
    End Sub

    Private Sub SetCampaignStartDate()
        Try

            Dim chk As CheckBox
            Dim txtDay, txtMonth, txtYear As TextBox
            For Each row As GridViewRow In gvCampaignDate.Rows
                db = New DBAccess("CRM")
                chk = CType(row.FindControl("chkAgents"), CheckBox)
                txtDay = CType(row.FindControl("txtDate"), TextBox)
                txtMonth = CType(row.FindControl("txtMonth"), TextBox)
                txtYear = CType(row.FindControl("txtYear"), TextBox)
                If chk.Enabled = True And chk.Checked = True Then
                    'And txtDay.ReadOnly = False And txtMonth.ReadOnly = False And txtYear.ReadOnly = False Then
                    Dim AgentId As String = ""
                    Dim startDate As String = ""
                    AgentId = CType(row.FindControl("lblEmpId"), Label).Text
                    If txtDay.Text = "0" Or txtMonth.Text = "0" Or txtYear.Text = "0" Then
                        AlertMessage("Date is not valid for " & AgentId)
                        Return
                    ElseIf Convert.ToInt64(txtDay.Text) > 31 Then
                        AlertMessage("Date is not valid for " & AgentId)
                        Return
                    ElseIf Convert.ToInt64(txtMonth.Text) > 12 Then
                        AlertMessage("Date is not valid for " & AgentId)
                        Return
                    End If
                    startDate = txtYear.Text & txtMonth.Text.PadLeft(2, "0") & txtDay.Text.PadLeft(2, "0")
                    db.slDataAdd("Agentid", AgentId)
                    db.slDataAdd("campaignStartDate", startDate)
                    db.Executeproc("usp_setcampaignstartdate")
                End If
                db = Nothing
            Next
            SuccessMessage("Campaign Start Date has been saved Successfully")
            GetAgentList()
        Catch ex As Exception
            AlertMessage(ex.Message)
        End Try
    End Sub
    Protected Sub btnSave_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnSave.Click
        SetCampaignStartDate()
    End Sub

#Region "Utility"

    Private Sub AlertMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMFail"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub
    Private Sub SuccessMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMSuccess"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub

#End Region

    Protected Sub imgfav_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles imgfav.Click
        Common.AddToFav(AgentID, "Campaign Start Date")
        SuccessMessage("Campaign start date application has been added to your favourite list")
        GetAgentList()
    End Sub
End Class
