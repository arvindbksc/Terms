﻿Imports com.nss.DBAccess
Imports System.Data
Imports System.Text
Partial Class mobile_OutcomeSummary
    Inherits System.Web.UI.Page
#Region "Properties"

    Property CampaignID() As Integer
        Get
            Return ViewState("CampaignID")
        End Get
        Set(ByVal value As Integer)
            ViewState("CampaignID") = value
            Session("CampaignID") = value
        End Set
    End Property
    Property AgentID() As String
        Get
            Return ViewState("AgentID")
        End Get
        Set(ByVal value As String)
            ViewState("AgentID") = value
        End Set
    End Property
    Property ChartPeriod() As Integer
        Get
            Return ViewState("ChartPeriod")
        End Get
        Set(ByVal value As Integer)
            ViewState("ChartPeriod") = value
        End Set
    End Property

    Property ChartGroupBy() As Integer
        Get
            Return ViewState("ChartGroupBy")
        End Get
        Set(ByVal value As Integer)
            ViewState("ChartGroupBy") = value
        End Set
    End Property
    Property Campaigntype() As Integer
        Get
            Return ViewState("Campaigntype")
        End Get
        Set(ByVal value As Integer)
            ViewState("Campaigntype") = value
            'Session("ProcessID") = value
        End Set
    End Property
#End Region
    Private Sub LoadData()
        FillCommonFilters()
        FillProcessCampaigns()
    End Sub
    Private Sub FillCommonFilters()
        Dim db As New DBAccess
        Dim dt As DataTable = db.ReturnTable("select * from tbl_Reports_DatePeriods")
        db = Nothing
        CboPeriod.DataTextField = "Caption"
        CboPeriod.DataValueField = "Period"
        CboPeriod.DataSource = dt
        CboPeriod.DataBind()

    End Sub
    Private Sub FillProcessCampaigns()
        Common.FillProcessCampaigns(CboProcess, cboCampaigns, AgentID, CampaignID)
        Dim lstcampaign As New ListItem
        lstcampaign.Value = 0
        lstcampaign.Text = "All"
        If cboCampaigns.Items.Contains(lstcampaign) Then
            cboCampaigns.Items.Remove(lstcampaign)
        End If
    End Sub
    Private Sub fillgrid()
        Dim db As New DBAccess
        Dim startday As Integer, endday As Integer
        db = New DBAccess
        db.slDataAdd("Period", CboPeriod.SelectedValue)
        db.slDataAdd("Campaignid", cboCampaigns.SelectedValue)
        Dim dr As DataRow = db.ReturnRow("usp_GetStart_EndDateForAPeriod", True)
        db = Nothing
        startday = dr(0)
        endday = dr(1)
        db = New DBAccess
        Dim dt As New DataTable
        db.slDataAdd("startday", startday)
        db.slDataAdd("endDay", endday)
        db.slDataAdd("campaignid", cboCampaigns.SelectedValue)
        db.slDataAdd("groupBy", 0)
        dt = db.ReturnTable("usp_OutcomePerformance", , True)
        'dlview.AutoGenerateRows = False
        Dim db1 As New DBAccess
        db1.slDataAdd("CampaignID", cboCampaigns.SelectedValue)
        Dim dtoutcome As DataTable = db1.ReturnTable("usp_ReportOutcomeDescription", , True)
        db1 = Nothing
        For Each dr1 As DataRow In dtoutcome.Rows
            If dt.Columns.Contains("Outcome" & dr1("toOutcome")) Then
                dt.Columns("Outcome" & dr1("toOutcome").ToString).ColumnName = dr1("Description")
            End If
        Next
        dt.Columns("column1").ColumnName = "Campaign"
        Dim dtnew As DataTable = dt.Clone
        For Each col As DataColumn In dtnew.Columns
            If col.ColumnName.Contains("Outcome") Then
                dt.Columns.Remove(col.ColumnName)
            End If
        Next
        dt.AcceptChanges()
        dlview.DataSource = dt
        dlview.DataBind()
        dt = Nothing
    End Sub
    Private Sub FillMenu()
        divmenu.Controls.Clear()
        Dim tbl As New HtmlTable
        'tbl.Attributes.Add("class", "menu")
        tbl.CellPadding = 0
        tbl.CellSpacing = 0
        Dim tr As New HtmlTableRow
        Dim td As New HtmlTableCell
        td.InnerHtml = "<a href='CampaignSummary.aspx'><div class='item'><span class='left'>" & _
                    "Campaign Summary</span><span class='right'></span></div></a>"
        tr.Cells.Add(td)
        tbl.Rows.Add(tr)
        '-------'
        tr = New HtmlTableRow
        td = New HtmlTableCell
        td.InnerHtml = "<a href='OutcomeSummary.aspx'> Outcome Summary</a>"
        tr.Cells.Add(td)
        tbl.Rows.Add(tr)
        '-------'
        tr = New HtmlTableRow
        td = New HtmlTableCell
        td.InnerHtml = "<a href='Enlargedgraph.aspx'>Data & Analytics</a>"
        tr.Cells.Add(td)
        tbl.Rows.Add(tr)
        '-------'
        tr = New HtmlTableRow
        td = New HtmlTableCell
        td.InnerHtml = "<a href='MarkAttendance.aspx'>Attendance</a>"
        tr.Cells.Add(td)
        tbl.Rows.Add(tr)
        divmenu.Controls.Add(tbl)
    End Sub
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            If Session("AgentID") <> "" Then
                CampaignID = Session("CampaignID")
                AgentID = Session("AgentID")
                LoadData()
                fillgrid()
                FillMenu()
            End If
        End If
    End Sub

    Protected Sub cboCampaigns_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboCampaigns.SelectedIndexChanged
        fillgrid()
        FillMenu()
    End Sub

    Protected Sub CboPeriod_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles CboPeriod.SelectedIndexChanged
        fillgrid()
        FillMenu()
    End Sub
End Class
