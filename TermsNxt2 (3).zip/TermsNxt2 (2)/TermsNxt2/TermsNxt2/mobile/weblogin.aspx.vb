﻿
Partial Class weblogin
    Inherits System.Web.UI.Page

    Protected Sub btnLogin_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnLogin.Click
        'If txtPassword.Text <> "tri" Then
        '    Return
        'End If
        'Dim db As New com.nss.DBAccess.DBAccess
        'Dim dr As System.Data.DataRow = db.ReturnRow("select Agentid,AgentName,campaignid from tbl_agentmaster where lanid='" & txtUserID.Text & "'")
        'db = Nothing
        'If dr Is Nothing Then
        '    Return
        'End If
        'Session("Lanid") = txtUserID.Text
        'Session("CampaignID") = dr("campaignid")
        'Session("AgentID") = dr("AgentID")
        'Session("UserID") = dr("AgentID")
        'Session("username") = dr("AgentName")
        'FormsAuthentication.RedirectFromLoginPage(Session("AgentID"), False)
        Dim db As New com.nss.DBAccess.DBAccess
        db.slDataAdd("userid", txtUserID.Text.Trim)
        db.slDataAdd("password", RC4.Encrypt(txtUserID.Text.Trim, txtPassword.Text.Trim))
        Dim dr As System.Data.DataRow = db.ReturnRow("usp_IsUserValid", True)
        'Dim dr As System.Data.DataRow = db.ReturnRow("select Agentid,AgentName,campaignid from tbl_agentmaster where lanid='" & txtUserID.Text & "'")
        db = Nothing
        If dr Is Nothing Then
            lblerror.Text = "The username or password you entered is incorrect."
            PanelError.Visible = True
            Return
        End If
        Session("Lanid") = txtUserID.Text
        Session("CampaignID") = dr("campaignid")
        Session("AgentID") = dr("AgentID")
        Session("UserID") = dr("AgentID")
        Session("username") = dr("AgentName")
        Response.Redirect("default.aspx")

    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        'If Not IsPostBack Then

        '    If RedirectToWinAuth() Then
        '        Return
        '    End If
        'End If
    End Sub
    Private Function RedirectToWinAuth() As Boolean
        RedirectToWinAuth = True
        Dim str As String
        Dim s As New System.Configuration.AppSettingsReader
        str = s.GetValue("Internal", System.Type.GetType("System.String"))
        If Regex.IsMatch(Request.UserHostAddress.ToString, str) Then

            Response.Redirect(Request.RawUrl.Replace("weblogin", "../winauth/winlogin"))
            Return True
        Else
            RedirectToWinAuth = False
            Return False
        End If
    End Function
End Class
