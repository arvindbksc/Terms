﻿Imports com.nss.DBAccess
Imports System.Data
Imports System.Text
Partial Class mobile_CampaignSummary
    Inherits System.Web.UI.Page
#Region "Properties"

    Property CampaignID() As Integer
        Get
            Return ViewState("CampaignID")
        End Get
        Set(ByVal value As Integer)
            ViewState("CampaignID") = value
            Session("CampaignID") = value
        End Set
    End Property
    Property AgentID() As String
        Get
            Return ViewState("AgentID")
        End Get
        Set(ByVal value As String)
            ViewState("AgentID") = value
        End Set
    End Property
    Property ChartPeriod() As Integer
        Get
            Return ViewState("ChartPeriod")
        End Get
        Set(ByVal value As Integer)
            ViewState("ChartPeriod") = value
        End Set
    End Property

    Property ChartGroupBy() As Integer
        Get
            Return ViewState("ChartGroupBy")
        End Get
        Set(ByVal value As Integer)
            ViewState("ChartGroupBy") = value
        End Set
    End Property
    Property Campaigntype() As Integer
        Get
            Return ViewState("Campaigntype")
        End Get
        Set(ByVal value As Integer)
            ViewState("Campaigntype") = value
            'Session("ProcessID") = value
        End Set
    End Property
#End Region
    Private Sub LoadData()
        FillCommonFilters()
        FillProcessCampaigns()
    End Sub
    Private Sub FillCommonFilters()
        Dim db As New DBAccess
        Dim dt As DataTable = db.ReturnTable("select * from tbl_Reports_DatePeriods")
        db = Nothing
        CboPeriod.DataTextField = "Caption"
        CboPeriod.DataValueField = "Period"
        CboPeriod.DataSource = dt
        CboPeriod.DataBind()

    End Sub
    Private Sub fillgrid()

        Dim db As New DBAccess
        Dim startday As Integer, endday As Integer
        'If CboPeriod.SelectedValue = 10 Then
        '    startday = ucDateFrom.yyyymmdd
        '    endday = UcDateTo.yyyymmdd
        'Else
        db = New DBAccess
        db.slDataAdd("Period", CboPeriod.SelectedValue)
        db.slDataAdd("Campaignid", cboCampaigns.SelectedValue)
        Dim dr As DataRow = db.ReturnRow("usp_GetStart_EndDateForAPeriod", True)
        db = Nothing
        startday = dr(0)
        endday = dr(1)
        'End If
        'db = New DBAccess
        'db.slDataAdd("processid", cboprocess.SelectedValue)
        'db.slDataAdd("Campaignid", cboCampaigns.SelectedValue)
        'db.slDataAdd("userid", AgentID)
        'Dim dtcampaigntype As DataTable = db.ReturnTable("usp_getcampaigntype", , True)
        ''campaigntype = db.ReturnValue("usp_getcampaigntype", True)
        'db = Nothing
        'If dtcampaigntype.Rows.Count > 1 Then
        '    Campaigntype = 1
        'Else
        '    Campaigntype = dtcampaigntype.Rows(0).Item(0)
        'End If
        db = New DBAccess
        Dim dt As New DataTable
        db.slDataAdd("userid", AgentID)
        db.slDataAdd("startday", startday)
        db.slDataAdd("endDay", endday)
        db.slDataAdd("campaignid", cboCampaigns.SelectedValue)
        ' db.slDataAdd("Processid", cboprocess.SelectedValue)
        'If Campaigntype = 11 Then
        '    dt = db.ReturnTable("usp_CampaignPerformanceTerms2_VoiceCampaign", "", True)
        'Else
        dt = db.ReturnTable("usp_Mobile_CampaignPerformanceTerms2", , True)
        'End If
        dlview.DataSource = dt
        dlview.DataBind()
        dt = Nothing

    End Sub
    Private Sub FillMenu()
        divmenu.Controls.Clear()
        Dim tbl As New HtmlTable
        'tbl.Attributes.Add("class", "menu")
        tbl.CellPadding = 0
        tbl.CellSpacing = 0
        Dim tr As New HtmlTableRow
        Dim td As New HtmlTableCell
        td.InnerHtml = "<a href='CampaignSummary.aspx'>Campaign Summary</a>"
        tr.Cells.Add(td)
        tbl.Rows.Add(tr)
        '-------'
        tr = New HtmlTableRow
        td = New HtmlTableCell
        td.InnerHtml = "<a href='OutcomeSummary.aspx'> Outcome Summary</a>"
        tr.Cells.Add(td)
        tbl.Rows.Add(tr)
        '-------'
        tr = New HtmlTableRow
        td = New HtmlTableCell
        td.InnerHtml = "<a href='Enlargedgraph.aspx'>Data & Analytics</a>"
        tr.Cells.Add(td)
        tbl.Rows.Add(tr)
        '-------'
        tr = New HtmlTableRow
        td = New HtmlTableCell
        td.InnerHtml = "<a href='MarkAttendance.aspx'>Attendance</a>"
        tr.Cells.Add(td)
        tbl.Rows.Add(tr)
        divmenu.Controls.Add(tbl)
    End Sub
    Private Sub FillProcessCampaigns()
        Common.FillProcessCampaigns(CboProcess, cboCampaigns, AgentID, CampaignID)
        Dim lstcampaign As New ListItem
        lstcampaign.Value = 0
        lstcampaign.Text = "All"
        If cboCampaigns.Items.Contains(lstcampaign) Then
            cboCampaigns.Items.Remove(lstcampaign)
        End If
    End Sub
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            If Session("AgentID") <> "" Then
                CampaignID = Session("CampaignID")
                AgentID = Session("AgentID")
                LoadData()
                fillgrid()
                FillMenu()
            End If
        End If
    End Sub

    Protected Sub cboCampaigns_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboCampaigns.SelectedIndexChanged
        fillgrid()
        FillMenu()
    End Sub
  
    Protected Sub CboPeriod_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles CboPeriod.SelectedIndexChanged
        fillgrid()
        FillMenu()
    End Sub
End Class
