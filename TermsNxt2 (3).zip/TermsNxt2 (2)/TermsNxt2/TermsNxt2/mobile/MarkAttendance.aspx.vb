﻿Imports com.nss.DBAccess
Imports System.Data
Imports System.Text
Partial Class mobile_MarkAttendance
    Inherits System.Web.UI.Page


#Region "-----Properties-----"

    Property CurrentDate() As Date
        Get
            Return ViewState("CurrentDate")
        End Get
        Set(ByVal value As Date)
            ViewState("CurrentDate") = value
        End Set
    End Property

    Property MinDate() As Date
        Get
            Return ViewState("MinDate")
        End Get
        Set(ByVal value As Date)
            ViewState("MinDate") = value
        End Set
    End Property

    Property SupervisorID() As String
        Get
            Return ViewState("SupervisorID")
        End Get
        Set(ByVal value As String)
            ViewState("SupervisorID") = value
        End Set
    End Property
    Property UserID() As String
        Get
            Return ViewState("UserID")
        End Get
        Set(ByVal value As String)
            ViewState("UserID") = value
        End Set
    End Property
    Property AgentID() As String
        Get
            Return ViewState("AgentID")
        End Get
        Set(ByVal value As String)
            ViewState("AgentID") = value
        End Set
    End Property
    Property UserName() As String
        Get
            Return ViewState("username")
        End Get
        Set(ByVal value As String)
            ViewState("username") = value
        End Set
    End Property

    Property SupervisorID_Above_One_Level() As String
        Get
            Return ViewState("SupervisorID_Above_One_Level")
        End Get
        Set(ByVal value As String)
            ViewState("SupervisorID_Above_One_Level") = value
        End Set
    End Property

    Property SupervisorID_All() As String
        Get
            Return ViewState("SupervisorID_All")
        End Get
        Set(ByVal value As String)
            ViewState("SupervisorID_All") = value
        End Set
    End Property

#End Region

#Region "-----Load Activities-----"

    Private Sub LoadData()
        Try

            Dim db As New DBAccess("CRM")
            'TODO: change this query to stored procedure
            Dim dr As DataRow = db.ReturnRow("SELECT dateadd(dd,1,max([FreezeDate])) as mindate  ,getdate() as currentdate  FROM [tbl_LastFreezedDate]")
            CurrentDate = dr("currentDate")
            txtDate.value = CurrentDate
            MinDate = dr("minDate")
            db = Nothing
            ' lblDate.Text = "* You can mark the attendance between [" & MinDate.ToString("dd-MMM-yyyy") & "] and [" & CurrentDate.ToString("dd-MMM-yyyy") & "]"
        Catch ex As Exception
            LblError.Text = ex.Message
        End Try

    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Try
            If Not IsPostBack Then
                LblError.Visible = False

                'Session("Agentid") = "NSS47671"
                'Session("UserID") = "NSS47671"
                'Session("username") = "Jatin Taneja"

                AgentID = Session("Agentid")

                LoadData()
                SupervisorID = Session("UserID")
                UserID = Session("UserID")
                UserName = Session("username")
                fillgrid(SupervisorID, txtDate.yyyymmdd)
                link2.Text = Session("username") & "(" & Session("UserID") & ")"
                ' Image3.Visible = False
                FillMenu()
            End If

        Catch ex As Exception
            LblError.Text = ex.Message
        End Try
    End Sub
#End Region

#Region "----Grid Ops----"

    Private Sub fillgrid(ByVal supervisorid As String, ByVal retrieveDate As String)
        Try
            'ImgMarkedorNot.ImageUrl = "~/_assets/img/yes.gif"
            GdAttendance.Columns(1).Visible = True
            GdAttendance.Columns(2).Visible = True
            GdAttendance.Columns(GdAttendance.Columns.Count - 1).Visible = True
            GdAttendance.Columns(GdAttendance.Columns.Count - 2).Visible = True

            Dim db As New DBAccess("CRM")

            db.slDataAdd("supervisorid", supervisorid)
            db.slDataAdd("markedDate", retrieveDate)
            'Dim dt As DataTable = db.ReturnTable("usp_retrieveAttendanceData", , True)
            Dim dt As DataTable = db.ReturnTable("usp_getHierarchy", , True)

            GdAttendance.DataSource = dt.DefaultView
            GdAttendance.DataBind()

            db = Nothing
            If dt.Rows.Count < 1 Then
                btsave.Enabled = False
                'btreset.Visible = False
            Else
                btsave.Enabled = True
                For Each row As DataRow In dt.Rows
                    If row.Item("Marked") = 0 Then
                        ImgMarkedorNot.ImageUrl = "~/_assets/img/why.gif"
                        LblMarkedorNot.Text = "Not Marked"
                        Exit For
                    Else
                        ImgMarkedorNot.ImageUrl = "~/_assets/img/yes.gif"
                        LblMarkedorNot.Text = "Marked"
                    End If
                Next
            End If

            GdAttendance.Columns(1).Visible = False
            GdAttendance.Columns(2).Visible = False
            GdAttendance.Columns(GdAttendance.Columns.Count - 1).Visible = False
            GdAttendance.Columns(GdAttendance.Columns.Count - 2).Visible = False

        Catch ex As Exception
            LblError.Text = ex.Message
        End Try
    End Sub

    Protected Sub GdAttendance_RowDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles GdAttendance.RowDataBound
        Try
            If e.Row.RowType = DataControlRowType.DataRow Then
                If e.Row.Cells(e.Row.Cells.Count - 1).Text.ToLower = "false" Or CType(e.Row.FindControl("lblAgentID"), Label).Text = SupervisorID Then
                    CType(e.Row.FindControl("lnkbtagentname"), LinkButton).Visible = False
                    CType(e.Row.FindControl("lblAgentName"), Label).Text = CType(e.Row.FindControl("lblAgentName"), Label).Text + "[" + CType(e.Row.FindControl("lblAgentID"), Label).Text + "]"
                Else
                    CType(e.Row.FindControl("lblAgentName"), Label).Visible = False
                    CType(e.Row.FindControl("lnkbtagentname"), LinkButton).Text = CType(e.Row.FindControl("lnkbtagentname"), LinkButton).Text + "[" + CType(e.Row.FindControl("lblAgentID"), Label).Text + "]"

                End If

                Select Case e.Row.Cells(e.Row.Cells.Count - 2).Text
                    Case 1
                        'CType(e.Row.FindControl("rdpresent"), RadioButton).Checked = True
                        CType(e.Row.FindControl("GVddlmarkedAs"), DropDownList).SelectedValue = "Present"
                    Case 2
                        CType(e.Row.FindControl("GVddlmarkedAs"), DropDownList).SelectedValue = "LWP"
                    Case 3
                        CType(e.Row.FindControl("GVddlmarkedAs"), DropDownList).SelectedValue = "Absent"
                    Case 4
                        CType(e.Row.FindControl("GVddlmarkedAs"), DropDownList).SelectedValue = "Leave"
                    Case 5
                        CType(e.Row.FindControl("GVddlmarkedAs"), DropDownList).SelectedValue = "Half Day"
                    Case 6
                        CType(e.Row.FindControl("GVddlmarkedAs"), DropDownList).SelectedValue = "Half Day LWP"
                    Case 7
                        CType(e.Row.FindControl("GVddlmarkedAs"), DropDownList).SelectedValue = "Weekly Off"
                    Case ""
                        CType(e.Row.FindControl("GVddlmarkedAs"), DropDownList).SelectedValue = "Present"
                    Case Else
                        CType(e.Row.FindControl("GVddlmarkedAs"), DropDownList).SelectedValue = "Present"
                End Select
            End If
        Catch ex As Exception
            LblError.Text = ex.Message
        End Try
    End Sub

#End Region

#Region "-----Date movement-----"

    Private Function validdate(ByVal selecteddate As DateTime) As Boolean
        Try
            If selecteddate > CurrentDate Or selecteddate < MinDate Then
                Return False
            End If
            Return True
        Catch ex As Exception
            LblError.Text = ex.Message
        End Try
    End Function

    Protected Sub btdatedecrease_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btdatedecrease.Click
        Try
            If validdate(DateAdd(DateInterval.Day, -1, txtDate.value)) Then
                txtDate.value = DateAdd(DateInterval.Day, -1, txtDate.value)
                fillgrid(SupervisorID, txtDate.yyyymmdd)
            Else
                LblError.Text = "Date not in valid range."
            End If
            FillMenu()
        Catch ex As Exception
            LblError.Text = ex.Message
        End Try
    End Sub

    Protected Sub btdateincrease_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btdateincrease.Click
        Try
            If validdate(DateAdd(DateInterval.Day, 1, txtDate.value)) Then
                txtDate.value = DateAdd(DateInterval.Day, 1, txtDate.value)
                fillgrid(SupervisorID, txtDate.yyyymmdd)
            Else

                LblError.Text = "Date not in valid range."
            End If
            FillMenu()
        Catch ex As Exception
            LblError.Text = ex.Message
        End Try
    End Sub

    Protected Sub txtDate_Changed(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtDate.Changed
        Try
            If validdate(txtDate.value) Then
                fillgrid(SupervisorID, txtDate.yyyymmdd)
            Else
                LblError.Text = "Date not in valid range"
                txtDate.value = CurrentDate
                fillgrid(SupervisorID, txtDate.yyyymmdd)
            End If
            FillMenu()
        Catch ex As Exception
            LblError.Text = ex.Message
        End Try
    End Sub

#End Region
    Private Sub FillMenu()
        divmenu.Controls.Clear()
        Dim tbl As New HtmlTable
        'tbl.Attributes.Add("class", "menu")
        tbl.CellPadding = 0
        tbl.CellSpacing = 0
        Dim tr As New HtmlTableRow
        Dim td As New HtmlTableCell
        td.InnerHtml = "<a href='CampaignSummary.aspx'>Campaign Summary</a>"
        tr.Cells.Add(td)
        tbl.Rows.Add(tr)
        '-------'
        tr = New HtmlTableRow
        td = New HtmlTableCell
        td.InnerHtml = "<a href='OutcomeSummary.aspx'> Outcome Summary</a>"
        tr.Cells.Add(td)
        tbl.Rows.Add(tr)
        '-------'
        tr = New HtmlTableRow
        td = New HtmlTableCell
        td.InnerHtml = "<a href='Enlargedgraph.aspx'>Data & Analytics</a>"
        tr.Cells.Add(td)
        tbl.Rows.Add(tr)
        '-------'
        tr = New HtmlTableRow
        td = New HtmlTableCell
        td.InnerHtml = "<a href='MarkAttendance.aspx'>Attendance</a>"
        tr.Cells.Add(td)
        tbl.Rows.Add(tr)
        divmenu.Controls.Add(tbl)
    End Sub
#Region "-----Supervisor change-----"

    Protected Sub GdAttendance_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles GdAttendance.SelectedIndexChanged
        Try
            SupervisorID_All = SupervisorID_Above_One_Level
            SupervisorID_Above_One_Level = ""

            If link2.Text <> "<" Then   'if only one hierarchy
                link2.CssClass = "notselectedlink"
                SupervisorID_Above_One_Level = link2.Text
                link2.Text = "<"

                link3.Visible = True
                link3.CssClass = "selectedlink"
                link3.Text = GdAttendance.SelectedDataKey.Item("AgentName").ToString & "(" & GdAttendance.SelectedDataKey.Item("AgentID").ToString & ")"
                SupervisorID = GdAttendance.SelectedDataKey.Item("AgentID").ToString
                fillgrid(SupervisorID, txtDate.yyyymmdd)

            Else ''if greater than  one hierarchy ------ i.e. if link3 have some text and have one more level 'i.e link2.Text ="<"
                link2.CssClass = "notselectedlink"
                SupervisorID_Above_One_Level = link3.Text
                link2.Text = "<"

                link3.Visible = True
                link3.CssClass = "selectedlink"
                link3.Text = GdAttendance.SelectedDataKey.Item("AgentName").ToString & "(" & GdAttendance.SelectedDataKey.Item("AgentID").ToString & ")"
                SupervisorID = GdAttendance.SelectedDataKey.Item("AgentID").ToString
                fillgrid(SupervisorID, txtDate.yyyymmdd)
            End If

            'img.Visible = True
            '------------------------------------------------------

            SupervisorID_All = SupervisorID_All + "," + SupervisorID_Above_One_Level

            If SupervisorID_All.Length > 0 Then 'to remove the preceding comma
                If SupervisorID_All.Substring(0, 1) = "," Then
                    SupervisorID_All = SupervisorID_All.Substring(1, SupervisorID_All.Length - 1)
                End If
            End If
        Catch ex As Exception
            LblError.Text = ex.Message
        End Try
    End Sub

#End Region

    Protected Sub btsave_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btsave.Click
        Try
            btsave.Enabled = False
            Dim db As New DBAccess("CRM")
            ' Dim resign = "", aod = "", Transfer = "", Move = "", Terminated = "", revoke As String = ""
            Dim inStatusID As Short
            Dim markedDate As String
            '  Dim rb1, rb2, rb3, rb4, rb5, rb6, rb7 As RadioButton
            Dim lbAgentid As Label
            Dim ddl As DropDownList

            markedDate = txtDate.yyyymmdd

            For Each dgRow As GridViewRow In GdAttendance.Rows
                db.slDataAdd("markeddate", markedDate)
                lbAgentid = dgRow.FindControl("lblAgentID")
                db.slDataAdd("agentid", lbAgentid.Text)

                ddl = dgRow.FindControl("GVddlmarkedAs")

                If ddl.SelectedItem.Text = "Present" Then
                    inStatusID = 1
                ElseIf ddl.SelectedItem.Text = "LWP" Then
                    inStatusID = 2
                ElseIf ddl.SelectedItem.Text = "Absent" Then
                    inStatusID = 3
                ElseIf ddl.SelectedItem.Text = "Leave" Then
                    inStatusID = 4
                ElseIf ddl.SelectedItem.Text = "Half Day" Then
                    inStatusID = 5
                ElseIf ddl.SelectedItem.Text = "Half Day LWP" Then
                    inStatusID = 6
                ElseIf ddl.SelectedItem.Text = "Weekly Off" Then
                    inStatusID = 7
                Else
                    'error message
                End If

                db.slDataAdd("markedas", inStatusID)
                db.slDataAdd("markedby", UserID)
                db.slDataAdd("BySystem", 0)
                db.Executeproc("usp_saveAttendanceData")
            Next

            fillgrid(SupervisorID, txtDate.yyyymmdd)
            FillMenu()
            btsave.Enabled = True
        Catch ex As Exception
            LblError.Text = ex.Message
        End Try
    End Sub

    Protected Sub link2_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles link2.Click
        Try
            Dim length As Integer
            Dim arrSplit() As String
            Dim strReplace As String = ""

            If link2.Text = "<" Then
                'to get the name of person in (bottom + 1 ) agent name   e.g. Siva,Alok,jatin,Satyendr----result is jatin
                If SupervisorID_All.Length > 0 Then
                    arrSplit = SupervisorID_All.Split(",")
                    SupervisorID_Above_One_Level = arrSplit(arrSplit.Length - 1).ToString  'for (arrSplit.Length -2 ) value
                    SupervisorID_All = SupervisorID_All.Replace(SupervisorID_Above_One_Level, "")

                    If SupervisorID_All.Length > 0 Then
                        If SupervisorID_All.Substring(SupervisorID_All.Length - 1, 1) = "," Then 'if last character is comma
                            SupervisorID_All = SupervisorID_All.Substring(0, SupervisorID_All.Length - 1)
                        End If
                    End If
                End If

                length = SupervisorID_Above_One_Level.LastIndexOf(")") - SupervisorID_Above_One_Level.LastIndexOf("(")
                SupervisorID = SupervisorID_Above_One_Level.Substring(SupervisorID_Above_One_Level.LastIndexOf("(") + 1, length - 1)

                fillgrid(SupervisorID, txtDate.yyyymmdd)
                link2.CssClass = "selectedlink"

                If SupervisorID_All = "" Then
                    link2.Text = SupervisorID_Above_One_Level
                    link3.Visible = False
                Else
                    arrSplit = SupervisorID_All.Split(",")
                    If arrSplit.Length > 0 Then 'if it contains more than one supervisors
                        link2.Text = "<"
                        link3.Visible = True
                        link3.Text = SupervisorID_Above_One_Level
                        'ElseIf arrSplit.Length = 1 Then 'if it contains only one supervisor
                        '    link2.Text = SupervisorID_Above_One_Level
                        '    link3.Visible = False
                    End If
                End If

            End If
            FillMenu()
        Catch ex As Exception
            LblError.Text = ex.Message
        End Try
    End Sub

End Class
