﻿Imports System.Data
Imports com.nss.DBAccess
Partial Class mobile_Graph
    Inherits System.Web.UI.Page
#Region "Properties"


    Property CampaignID() As Integer
        Get
            Return ViewState("CampaignID")
        End Get
        Set(ByVal value As Integer)
            ViewState("CampaignID") = value
        End Set
    End Property

    Property KPA() As Integer
        Get
            Return ViewState("KPA")
        End Get
        Set(ByVal value As Integer)
            ViewState("KPA") = value
        End Set
    End Property


    Property Period() As Integer
        Get
            Return ViewState("Period")
        End Get
        Set(ByVal value As Integer)
            ViewState("Period") = True
        End Set
    End Property

    Property GroupBy() As Integer
        Get
            Return ViewState("GroupBy")
        End Get
        Set(ByVal value As Integer)
            ViewState("GroupBy") = True
        End Set
    End Property
    Property AgentID() As String
        Get
            Return ViewState("AgentID")
        End Get
        Set(ByVal value As String)
            ViewState("AgentID") = value
        End Set
    End Property
    Property Campaigntype() As Integer
        Get
            Return ViewState("Campaigntype")
        End Get
        Set(ByVal value As Integer)
            ViewState("Campaigntype") = value
            'Session("ProcessID") = value
        End Set
    End Property
    Property Graphtype() As Integer
        Get
            Return ViewState("Graphtype")
        End Get
        Set(ByVal value As Integer)
            ViewState("Graphtype") = value
        End Set
    End Property
#End Region
    Dim dt As DataTable
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Session("AgentID") <> "" Then
            CampaignID = Request.QueryString("CampaignID")
            AgentID = Session("AgentID")
            KPA = Request.QueryString("KPA")
            Period = Request.QueryString("Period")
            GroupBy = Request.QueryString("GroupBy")
            Graphtype = Request.QueryString("Graphtype")
            returnData()
            RenderGraph()
        End If
    End Sub
    Private Sub returnData()
        ' Dim campaignid As Integer = 191
        Dim db As New DBAccess
        Dim startday As Integer, endday As Integer

        db.slDataAdd("Period", Request.QueryString("Period"))
        db.slDataAdd("Campaignid", Request.QueryString("CampaignID"))
        Dim dr As DataRow = db.ReturnRow("usp_GetStart_EndDateForAPeriod", True)
        db = Nothing
        startday = dr(0)
        endday = dr(1)

        db = Nothing
        db = New DBAccess
        Dim drKPa As DataRow = db.ReturnRow("select * from tbl_Config_KPA_Master where KPAID=" & KPA)

        db = Nothing

        db = New DBAccess
        db.slDataAdd("Campaignid", Request.QueryString("CampaignID"))
        db.slDataAdd("userid", AgentID)
        Dim dtcampaigntype As DataTable = db.ReturnTable("usp_getcampaigntype", , True)
        db = Nothing
        If dtcampaigntype.Rows.Count > 1 Then
            Campaigntype = 1
        Else
            Campaigntype = dtcampaigntype.Rows(0).Item(0)
        End If
        db = Nothing

        db = New DBAccess
        db.slDataAdd("startday", startday)
        db.slDataAdd("endDay", endday)
        db.slDataAdd("campaignid", Request.QueryString("CampaignID"))
        db.slDataAdd("groupBy", Request.QueryString("GroupBy"))
        ' KPA = cboKPA.SelectedValue
        If KPA < 5 Then

            dt = db.ReturnTable("usp_CampaignPerformanceTerms2", , True)
            dt.Columns.Remove("CPH")
            If Campaigntype = 11 Then
                dt.Columns.Add("CPH", System.Type.GetType("System.Decimal"), "iif([Login Duration]=0,0, ([Sales]/[Login Duration])*3600)")
            Else
                dt.Columns.Add("CPH", System.Type.GetType("System.Decimal"), "iif([Login Duration]=0,0, ([Completes]/[Login Duration])*3600)")
            End If

            dt.Columns.Remove("AHT")
            dt.Columns.Add("AHT", System.Type.GetType("System.Double"), "iif([Transactions]=0,0, [Transaction Duration]/[Transactions])")

            dt.Columns.Add("LoginHrs", System.Type.GetType("System.Double"), "[Login Duration]/3600")
            
        End If


    End Sub
    Private Sub RenderGraph()
        Chart1.Series.Clear()
        Chart1.Series.Add("series1")
        'KPA = cboKPA.SelectedValue
        'If KPA > 7 Then
        'Chart1.Series.Add("series2")
        'End If

        'Set the titles and axis labels
        Dim mypane As System.Web.UI.DataVisualization.Charting.Series
        mypane = Chart1.Series(0)

        Select Case Request.QueryString("GroupBy")
            Case 0
                Chart1.ChartAreas(0).AxisX.Title = "Campaigns"
                mypane.XValueType = DataVisualization.Charting.ChartValueType.Int32
            Case 1
                Chart1.ChartAreas(0).AxisX.Title = "Agents"
                mypane.XValueType = DataVisualization.Charting.ChartValueType.String
            Case 2
                Chart1.ChartAreas(0).AxisX.Title = "Teams"
                mypane.XValueType = DataVisualization.Charting.ChartValueType.String
            Case 3
                Chart1.ChartAreas(0).AxisX.Title = "Days"
                mypane.XValueType = DataVisualization.Charting.ChartValueType.Date
            Case Else
                Chart1.ChartAreas(0).AxisX.Title = "Hours"
                mypane.XValueType = DataVisualization.Charting.ChartValueType.Int32
        End Select

        Select Case Graphtype
            Case 1
                Chart1.Series(0).ChartType = DataVisualization.Charting.SeriesChartType.Spline
                Chart1.Series(0).MarkerStyle = DataVisualization.Charting.MarkerStyle.Diamond
                Chart1.Series(0).MarkerSize = 6
                Chart1.Series(0).MarkerColor = Drawing.Color.White
                Chart1.Series(0).BorderWidth = 3
                Chart1.Series(0).IsValueShownAsLabel = False
            Case 3
                Chart1.Series(0).ChartType = DataVisualization.Charting.SeriesChartType.Pie

                Chart1.Series(0)("PieLabelStyle") = "outside"
                Chart1.ChartAreas(0).Area3DStyle.Enable3D = True
                Chart1.ChartAreas(0).Area3DStyle.Inclination = 0
            Case Else
                Chart1.Series(0).ChartType = DataVisualization.Charting.SeriesChartType.Column
                Chart1.Series(0)("DrawingStyle") = "Cylinder"
        End Select

        Chart1.ChartAreas(0).AxisX.LabelAutoFitStyle = DataVisualization.Charting.LabelAutoFitStyles.LabelsAngleStep30
        Select Case KPA
            Case 1

                Chart1.Titles.Add("CPH")
                Chart1.Series(0).XValueMember = dt.Columns(0).ColumnName
                Chart1.Series(0).YValueMembers = "CPH"
            Case 2
                'myPane.Title.Text = "Completes"
                Chart1.Titles.Add("Completes")
                Chart1.Series(0).XValueMember = dt.Columns(0).ColumnName
                Chart1.Series(0).YValueMembers = "Completes"
            Case 3
                Chart1.Titles.Add("AHT")
                Chart1.Series(0).XValueMember = dt.Columns(0).ColumnName
                Chart1.Series(0).YValueMembers = "AHT"
            Case 4
                Chart1.Titles.Add("Login Hrs.")
                Chart1.Series(0).XValueMember = dt.Columns(0).ColumnName
                Chart1.Series(0).YValueMembers = "Loginhrs"
        End Select
        Chart1.DataSource = dt.DefaultView
        Chart1.DataBind()


    End Sub
End Class
