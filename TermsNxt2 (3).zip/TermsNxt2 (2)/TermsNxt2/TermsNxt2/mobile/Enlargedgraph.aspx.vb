﻿Imports com.nss.DBAccess
Imports System.Data
Partial Class mobile_Enlargedgraph
    Inherits System.Web.UI.Page
#Region "Properties"


    Property CampaignID() As Integer
        'Get
        '    Return cboCampaigns.SelectedValue
        'End Get
        'Set(ByVal value As Integer)
        '    cboCampaigns.SelectedItem.Selected = False
        '    cboCampaigns.Items.FindByValue(value).Selected = True
        'End Set
        Get
            Return ViewState("CampaignID")
        End Get
        Set(ByVal value As Integer)
            ViewState("CampaignID") = value
        End Set
    End Property

    Property KPA() As Integer
        Get
            Return ViewState("KPA")
        End Get
        Set(ByVal value As Integer)
            ViewState("KPA") = value
        End Set
    End Property


    Property Period() As Integer
        Get
            Return CboPeriod.SelectedValue
        End Get
        Set(ByVal value As Integer)
            CboPeriod.Items.FindByValue(value).Selected = True
        End Set
    End Property

    Property GroupBy() As Integer
        Get
            Return CboGroup.SelectedValue
        End Get
        Set(ByVal value As Integer)
            CboGroup.Items.FindByValue(value).Selected = True
        End Set
    End Property
    Property AgentID() As String
        Get
            Return ViewState("AgentID")
        End Get
        Set(ByVal value As String)
            ViewState("AgentID") = value
        End Set
    End Property
    Property Campaigntype() As Integer
        Get
            Return ViewState("Campaigntype")
        End Get
        Set(ByVal value As Integer)
            ViewState("Campaigntype") = value
            'Session("ProcessID") = value
        End Set
    End Property
#End Region
    Dim dt As DataTable
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            If Session("AgentID") <> "" Then
                CampaignID = Request.QueryString("campaignid")
                AgentID = Session("AgentID")
                FillProcessCampaigns()
                FillCommonFilters()
                KPA = Request.QueryString("KPA")
                Period = Request.QueryString("Period")
                GroupBy = Request.QueryString("GroupBy")
                cboCampaigns.SelectedValue = CampaignID
                cboKPA.SelectedValue = KPA
                CboPeriod.SelectedValue = Period
                CboGroup.SelectedValue = GroupBy
                DrawChart()
                FillMenu()

            End If

        End If
    End Sub
    Private Sub FillProcessCampaigns()
        Common.FillProcessCampaigns(CboProcess, cboCampaigns, AgentID, CampaignID)
        Dim lstcampaign As New ListItem
        lstcampaign.Value = 0
        lstcampaign.Text = "All"
        If cboCampaigns.Items.Contains(lstcampaign) Then
            cboCampaigns.Items.Remove(lstcampaign)
        End If

    End Sub
    Private Sub FillCommonFilters()
        Dim db As New DBAccess
        Dim dt As DataTable = db.ReturnTable("select * from tbl_Reports_DatePeriods")
        db = Nothing
        CboPeriod.DataTextField = "Caption"
        CboPeriod.DataValueField = "Period"
        CboPeriod.DataSource = dt
        CboPeriod.DataBind()

        db = New DBAccess
        dt = db.ReturnTable("Select * from tbl_Reports_GroupBy")
        db = Nothing
        CboGroup.DataTextField = "Caption"
        CboGroup.DataValueField = "ID"
        CboGroup.DataSource = dt
        CboGroup.DataBind()


    End Sub
    Private Sub DrawChart()
        imgchart.Src = "../mobile/graph.aspx?KPA=" & cboKPA.SelectedValue & "&GraphType=" & cboGraphType.SelectedValue & "&period=" & CboPeriod.SelectedValue & "&GroupBy=" & CboGroup.SelectedValue & "&CampaignID=" & cboCampaigns.SelectedValue
        'returnData()
        'RenderGraph()
    End Sub
    Private Sub FillMenu()
        divmenu.Controls.Clear()
        Dim tbl As New HtmlTable
        'tbl.Attributes.Add("class", "menu")
        tbl.CellPadding = 0
        tbl.CellSpacing = 0
        Dim tr As New HtmlTableRow
        Dim td As New HtmlTableCell
        td.InnerHtml = "<a href='CampaignSummary.aspx'>Campaign Summary</a>"
        tr.Cells.Add(td)
        tbl.Rows.Add(tr)
        '-------'
        tr = New HtmlTableRow
        td = New HtmlTableCell
        td.InnerHtml = "<a href='OutcomeSummary.aspx'> Outcome Summary</a>"
        tr.Cells.Add(td)
        tbl.Rows.Add(tr)
        '-------'
        tr = New HtmlTableRow
        td = New HtmlTableCell
        td.InnerHtml = "<a href='Enlargedgraph.aspx'>Data & Analytics</a>"
        tr.Cells.Add(td)
        tbl.Rows.Add(tr)
        '-------'
        tr = New HtmlTableRow
        td = New HtmlTableCell
        td.InnerHtml = "<a href='MarkAttendance.aspx'>Attendance</a>"
        tr.Cells.Add(td)
        tbl.Rows.Add(tr)
        divmenu.Controls.Add(tbl)
    End Sub
    'Private Sub returnData()
    '    ' Dim campaignid As Integer = 191
    '    Dim db As New DBAccess
    '    Dim startday As Integer, endday As Integer

    '    db.slDataAdd("Period", CboPeriod.SelectedValue)
    '    db.slDataAdd("Campaignid", CampaignID)
    '    Dim dr As DataRow = db.ReturnRow("usp_GetStart_EndDateForAPeriod", True)
    '    db = Nothing
    '    startday = dr(0)
    '    endday = dr(1)

    '    db = Nothing
    '    db = New DBAccess
    '    Dim drKPa As DataRow = db.ReturnRow("select * from tbl_Config_KPA_Master where KPAID=" & KPA)

    '    db = Nothing

    '    db = New DBAccess
    '    db.slDataAdd("Campaignid", CampaignID)
    '    db.slDataAdd("userid", AgentID)
    '    Dim dtcampaigntype As DataTable = db.ReturnTable("usp_getcampaigntype", , True)
    '    db = Nothing
    '    If dtcampaigntype.Rows.Count > 1 Then
    '        Campaigntype = 1
    '    Else
    '        Campaigntype = dtcampaigntype.Rows(0).Item(0)
    '    End If
    '    db = Nothing

    '    db = New DBAccess
    '    db.slDataAdd("startday", startday)
    '    db.slDataAdd("endDay", endday)
    '    db.slDataAdd("campaignid", cboCampaigns.SelectedValue)
    '    db.slDataAdd("groupBy", GroupBy)
    '    KPA = cboKPA.SelectedValue
    '    If KPA < 5 Then

    '        dt = db.ReturnTable("usp_CampaignPerformanceTerms2", , True)
    '        dt.Columns.Remove("CPH")
    '        If Campaigntype = 11 Then
    '            dt.Columns.Add("CPH", System.Type.GetType("System.Decimal"), "iif([Login Duration]=0,0, ([Sales]/[Login Duration])*3600)")
    '        Else
    '            dt.Columns.Add("CPH", System.Type.GetType("System.Decimal"), "iif([Login Duration]=0,0, ([Completes]/[Login Duration])*3600)")
    '        End If

    '        dt.Columns.Remove("AHT")
    '        dt.Columns.Add("AHT", System.Type.GetType("System.Double"), "iif([Transactions]=0,0, [Transaction Duration]/[Transactions])")
    '        'dt.Columns.Remove("LoginHrs")
    '        dt.Columns.Add("LoginHrs", System.Type.GetType("System.Double"), "[Login Duration]/3600")
    '        'ElseIf KPA = 9 Then
    '        '    db.slDataAdd("Disposition", cboDisposition.SelectedValue)
    '        '    dt = db.ReturnTable("[usp_getSubOutcome]", , True)
    '        '    dt.Columns.Remove("column1")
    '        'Else
    '        '    dt = db.ReturnTable("usp_Survey_Analysis", , True)
    '        '    dt.Columns.Remove("RPH")
    '        '    dt.Columns.Add("RPH", System.Type.GetType("System.Decimal"), "iif([Login Duration]=0,0, ([Revenue]/[Login Duration])*3600)")
    '        '    dt.Columns.Remove("Fill Rate")
    '        '    dt.Columns.Add("Fill Rate", System.Type.GetType("System.Decimal"), "iif([Total Responses]=0,0, ([Positive Count]/[Total Responses]))")
    '        '    dt.Columns.Remove("CPH")
    '        '    dt.Columns.Add("CPH", System.Type.GetType("System.Decimal"), "iif([Login Duration]=0,0, ([Completes]/[Login Duration])*3600)")

    '    End If


    'End Sub
    'Private Sub RenderGraph()
    '    Chart1.Series.Clear()
    '    Chart1.Series.Add("series1")
    '    KPA = cboKPA.SelectedValue
    '    'If KPA > 7 Then
    '    'Chart1.Series.Add("series2")
    '    'End If

    '    'Set the titles and axis labels
    '    Dim mypane As System.Web.UI.DataVisualization.Charting.Series
    '    mypane = Chart1.Series(0)

    '    Select Case GroupBy
    '        Case 0
    '            Chart1.ChartAreas(0).AxisX.Title = "Campaigns"
    '            mypane.XValueType = DataVisualization.Charting.ChartValueType.Int32
    '        Case 1
    '            Chart1.ChartAreas(0).AxisX.Title = "Agents"
    '            mypane.XValueType = DataVisualization.Charting.ChartValueType.String
    '        Case 2
    '            Chart1.ChartAreas(0).AxisX.Title = "Teams"
    '            mypane.XValueType = DataVisualization.Charting.ChartValueType.String
    '        Case 3
    '            Chart1.ChartAreas(0).AxisX.Title = "Days"
    '            mypane.XValueType = DataVisualization.Charting.ChartValueType.Date
    '        Case Else
    '            Chart1.ChartAreas(0).AxisX.Title = "Hours"
    '            mypane.XValueType = DataVisualization.Charting.ChartValueType.Int32
    '    End Select

    '    Select Case cboGraphType.SelectedValue
    '        Case 1
    '            Chart1.Series(0).ChartType = DataVisualization.Charting.SeriesChartType.Spline
    '            Chart1.Series(0).MarkerStyle = DataVisualization.Charting.MarkerStyle.Diamond
    '            Chart1.Series(0).MarkerSize = 6
    '            Chart1.Series(0).MarkerColor = Drawing.Color.White
    '            Chart1.Series(0).BorderWidth = 3
    '            Chart1.Series(0).IsValueShownAsLabel = False
    '        Case 3
    '            Chart1.Series(0).ChartType = DataVisualization.Charting.SeriesChartType.Pie

    '            Chart1.Series(0)("PieLabelStyle") = "outside"
    '            Chart1.ChartAreas(0).Area3DStyle.Enable3D = True
    '            Chart1.ChartAreas(0).Area3DStyle.Inclination = 0
    '        Case Else
    '            Chart1.Series(0).ChartType = DataVisualization.Charting.SeriesChartType.Column
    '            Chart1.Series(0)("DrawingStyle") = "Cylinder"

    '            'Chart1.Series(0).IsValueShownAsLabel = True

    '    End Select

    '    Chart1.ChartAreas(0).AxisX.LabelAutoFitStyle = DataVisualization.Charting.LabelAutoFitStyles.LabelsAngleStep30
    '    Select Case KPA
    '        Case 1

    '            Chart1.Titles.Add("CPH")
    '            Chart1.Series(0).XValueMember = dt.Columns(0).ColumnName
    '            Chart1.Series(0).YValueMembers = "CPH"
    '        Case 2
    '            'myPane.Title.Text = "Completes"
    '            Chart1.Titles.Add("Completes")
    '            Chart1.Series(0).XValueMember = dt.Columns(0).ColumnName
    '            Chart1.Series(0).YValueMembers = "Completes"
    '        Case 3
    '            Chart1.Titles.Add("AHT")
    '            Chart1.Series(0).XValueMember = dt.Columns(0).ColumnName
    '            Chart1.Series(0).YValueMembers = "AHT"
    '        Case 4
    '            'myPane.Title.Text = "Login Hrs."

    '            Chart1.Titles.Add("Login Hrs.")
    '            Chart1.Series(0).XValueMember = dt.Columns(0).ColumnName
    '            Chart1.Series(0).YValueMembers = "Loginhrs"
    '            'Chart1.Series(0).IsValueShownAsLabel = True               
    '            'Case 5
    '            '    Chart1.Titles.Add("Revenue")
    '            '    Chart1.Series(0).XValueMember = dt.Columns(0).ColumnName
    '            '    Chart1.Series(0).YValueMembers = "Revenue"
    '            'Case 6
    '            '    Chart1.Titles.Add("RPH")
    '            '    Chart1.Series(0).XValueMember = dt.Columns(0).ColumnName
    '            '    Chart1.Series(0).YValueMembers = "RPH"
    '            'Case 7
    '            '    Chart1.Titles.Add("Fill Rate")
    '            '    Chart1.Series(0).XValueMember = dt.Columns(0).ColumnName
    '            '    Chart1.Series(0).YValueMembers = "Fill Rate"
    '            'Case 8
    '            '    Chart1.Titles.Add("RPH vs CPH")
    '            '    Chart1.Series(0).XValueMember = dt.Columns(0).ColumnName
    '            '    Chart1.Series(0).YValueMembers = "RPH"
    '            '    'Chart1.Series.Add("CPH")
    '            '    Chart1.Series(1).XValueMember = dt.Columns(0).ColumnName
    '            '    Chart1.Series(1).YValueMembers = "CPH"
    '            'Case 9
    '            '    Chart1.Titles.Add("Sub Disposition")
    '            '    Chart1.Series(0).XValueMember = dt.Columns(0).ColumnName
    '            '    Chart1.Series(0).YValueMembers = "countsecoutcome"

    '    End Select

    '    Chart1.DataSource = dt.DefaultView
    '    Chart1.DataBind()


    'End Sub

    Protected Sub cboCampaigns_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboCampaigns.SelectedIndexChanged
        DrawChart()
        FillMenu()
    End Sub

    Protected Sub cboGraphType_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboGraphType.SelectedIndexChanged
        DrawChart()
        FillMenu()
    End Sub

    Protected Sub CboGroup_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles CboGroup.SelectedIndexChanged
        DrawChart()
        FillMenu()
    End Sub

    Protected Sub CboPeriod_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles CboPeriod.SelectedIndexChanged
        DrawChart()
        FillMenu()
    End Sub
End Class
