﻿Imports com.nss.DBAccess
Imports System.Data
Partial Class mobile_Default
    Inherits System.Web.UI.Page

#Region "Properties"

    Property CampaignID() As Integer
        Get
            Return ViewState("CampaignID")
        End Get
        Set(ByVal value As Integer)
            ViewState("CampaignID") = value
            Session("CampaignID") = value
        End Set
    End Property
    Property AgentID() As String
        Get
            Return ViewState("AgentID")
        End Get
        Set(ByVal value As String)
            ViewState("AgentID") = value
        End Set
    End Property
    Property ChartPeriod() As Integer
        Get
            Return ViewState("ChartPeriod")
        End Get
        Set(ByVal value As Integer)
            ViewState("ChartPeriod") = value
        End Set
    End Property

    Property ChartGroupBy() As Integer
        Get
            Return ViewState("ChartGroupBy")
        End Get
        Set(ByVal value As Integer)
            ViewState("ChartGroupBy") = value
        End Set
    End Property

#End Region
    Private Sub CreateChartPreview()
        Dim chart As Panel, img As Image
        Dim ictr As Integer
        'ChartContainerInner.Style.Item("width") = 3200
        'For ictr = 0 To 7
        '    chart = New Panel
        '    img = New Image
        '    img.ImageUrl = "file:///E:\My Projects\WebSites\Terms2\_assets\img\nsslogopic1.gif"
        '    img.Height = 200
        '    img.Width = 200

        '    chart.CssClass = "Chart"

        '    chart.Controls.Add(img)
        '    ChartContainerInner.Controls.Add(chart)
        'Next


    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            If Session("AgentID") <> "" Then
                ChartPeriod = 0
                ChartGroupBy = 3
                CampaignID = Session("CampaignID")
                AgentID = Session("AgentID")
                FillProcessCampaigns()
                FillMenu()
                FillSummary()
                FillGraph()

            End If

        End If


    End Sub
    Private Sub FillMenu()
        divmenu.Controls.Clear()
        Dim tbl As New HtmlTable
        'tbl.Attributes.Add("class", "menu")
        tbl.CellPadding = 0
        tbl.CellSpacing = 0
        Dim tr As New HtmlTableRow
        Dim td As New HtmlTableCell
        td.InnerHtml = "<a href='CampaignSummary.aspx'>Campaign Summary</a>"
        tr.Cells.Add(td)
        tbl.Rows.Add(tr)
        '-------'
        tr = New HtmlTableRow
        td = New HtmlTableCell
        td.InnerHtml = "<a href='OutcomeSummary.aspx'> Outcome Summary</a>"
        tr.Cells.Add(td)
        tbl.Rows.Add(tr)
        '-------'
        tr = New HtmlTableRow
        td = New HtmlTableCell
        td.InnerHtml = "<a href='Enlargedgraph.aspx'>Data & Analytics</a>"
        tr.Cells.Add(td)
        tbl.Rows.Add(tr)
        '-------'
        tr = New HtmlTableRow
        td = New HtmlTableCell
        td.InnerHtml = "<a href='MarkAttendance.aspx'>Attendance</a>"
        tr.Cells.Add(td)
        tbl.Rows.Add(tr)
        divmenu.Controls.Add(tbl)
    End Sub
    Private Sub FillGraph()
        'ChartContainerInner.Controls.Clear()
        'Dim objLink As HyperLink
        'Dim objImg As Image
        'For ictr = 0 To 3
        '    objLink = New HyperLink
        '    objLink.NavigateUrl = "../Graphs/EnlargedGraph.aspx?KPA=" & ictr + 1 & "&period=" & ChartPeriod & "&GraphSize=200&GroupBy=" & ChartGroupBy & "&CampaignID=" & CampaignID
        '    objLink.ID = "lnkKPA" & ictr + 1
        '    objImg = New Image
        '    objImg.ImageUrl = "../Graphs/msgraph.aspx?KPA=" & ictr + 1 & "&period=" & ChartPeriod & "&GraphSize=200&GroupBy=" & ChartGroupBy & "&CampaignID=" & CampaignID
        '    objImg.ID = "imgKPA" & ictr + 1
        '    objImg.CssClass = "chart"
        '    objLink.Controls.Add(objImg)
        '    ChartContainerInner.Controls.Add(objLink)
        'Next
        HLKPA1.NavigateUrl = "EnlargedGraph.aspx?KPA=1&period=" & ChartPeriod & "&GraphSize=200&GroupBy=" & ChartGroupBy & "&CampaignID=" & CampaignID
        HLKPA2.NavigateUrl = "EnlargedGraph.aspx?KPA=2&period=" & ChartPeriod & "&GraphSize=200&GroupBy=" & ChartGroupBy & "&CampaignID=" & CampaignID
        HLKPA3.NavigateUrl = "EnlargedGraph.aspx?KPA=3&period=" & ChartPeriod & "&GraphSize=200&GroupBy=" & ChartGroupBy & "&CampaignID=" & CampaignID
        HLKPA4.NavigateUrl = "EnlargedGraph.aspx?KPA=4&period=" & ChartPeriod & "&GraphSize=200&GroupBy=" & ChartGroupBy & "&CampaignID=" & CampaignID
        imgAHT.Src = "../Graphs/msgraph.aspx?KPA=4&period=" & ChartPeriod & "&GraphSize=200&GroupBy=" & ChartGroupBy & "&CampaignID=" & CampaignID
        imgCPH.Src = "../Graphs/msgraph.aspx?KPA=1&period=" & ChartPeriod & "&GraphSize=200&GroupBy=" & ChartGroupBy & "&CampaignID=" & CampaignID
        imgCompletes.Src = "../Graphs/msgraph.aspx?KPA=2&period=" & ChartPeriod & "&GraphSize=200&GroupBy=" & ChartGroupBy & "&CampaignID=" & CampaignID
        imgLoginHrs.Src = "../Graphs/msgraph.aspx?KPA=3&period=" & ChartPeriod & "&GraphSize=200&GroupBy=" & ChartGroupBy & "&CampaignID=" & CampaignID
    End Sub
    Protected Sub cboCampaigns_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboCampaigns.SelectedIndexChanged
        CampaignID = cboCampaigns.SelectedValue

        FillSummary()
        FillGraph()
        FillMenu()
    End Sub
    Private Sub FillProcessCampaigns()
        Common.FillProcessCampaigns(CboProcess, cboCampaigns, AgentID, CampaignID)
        'cboCampaigns.Items.FindByValue(CampaignID).Selected = True


    End Sub
    Private Sub FillSummary()
        Dim db As New DBAccess
        db.slDataAdd("CampaignID", CampaignID)
        Dim dt As DataTable = db.ReturnTable("usp_DailyDashboardSummary", , True)
        If dt.Rows.Count > 0 Then
            lblNoofAgents.Text = dt.Rows(0)("loggedin")
            lblNoofAgentsonbreak.Text = dt.Rows(0)("onbreak")
        Else
            lblNoofAgents.Text = "0"
            lblNoofAgentsonbreak.Text = "0"
        End If
        db = Nothing
        db = New DBAccess

        db.slDataAdd("Period", 0)
        db.slDataAdd("Campaignid", CampaignID)

        Dim dr As DataRow = db.ReturnRow("usp_GetStart_EndDateForAPeriod", True)
        db = Nothing
        db = New DBAccess
        db.slDataAdd("startday", dr(0))
        db.slDataAdd("endDay", dr(1))
        db.slDataAdd("campaignid", CampaignID)
        db.slDataAdd("groupBy", 3)
        dt = db.ReturnTable("usp_CampaignPerformanceTerms2", , True)
        If dt.Rows.Count > 0 Then
            lblLoginHrs.Text = Common.TimeString(dt.Rows(0)("Login Duration"))
            LblCompletes.Text = dt.Rows(0)("Completes")
            If dt.Rows(0)("Login Duration") = 0 Or dt.Rows(0)("Completes") = 0 Then
                lblCPH.Text = "N.A."
            Else
                lblCPH.Text = Math.Round((dt.Rows(0)("Completes") / dt.Rows(0)("Login Duration")) * 3600, 2)
            End If


        Else
            'lblNoofAgents.Text = "0"
            'lblNoofAgentsonbreak.Text = "0"
            lblLoginHrs.Text = "0"
            LblCompletes.Text = "0"
            lblCPH.Text = "N.A."
        End If
    End Sub


    Protected Sub cboChartPeriod_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboChartPeriod.SelectedIndexChanged
        ChartPeriod = cboChartPeriod.SelectedValue
        If ChartPeriod = 0 Then
            ChartGroupBy = 4

        Else
            ChartGroupBy = 3
        End If
        FillGraph()
        FillMenu()
    End Sub


    Protected Sub btnRefresh_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnRefresh.Click
        FillSummary()
        FillGraph()
        FillMenu()
    End Sub
End Class
