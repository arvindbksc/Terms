﻿Imports com.nss.DBAccess
Imports System.Data
Imports System.Data.SqlClient
Partial Class TableF_createmetrics
    Inherits System.Web.UI.Page
#Region "Properties"
    Property CampaignID() As Integer
        Get
            Return ViewState("CampaignID")
        End Get
        Set(ByVal value As Integer)
            ViewState("CampaignID") = value
        End Set
    End Property

    Property CustomerID() As Integer
        Get
            Return ViewState("CustomerID")
        End Get
        Set(ByVal value As Integer)
            ViewState("CustomerID") = value
        End Set
    End Property

    Property LoginUserID() As String
        Get
            Return ViewState("LoginUserID")
        End Get
        Set(ByVal value As String)
            ViewState("LoginUserID") = value
        End Set
    End Property

    Property LoginUserName() As String
        Get
            Return ViewState("LoginUserName")
        End Get
        Set(ByVal value As String)
            ViewState("LoginUserName") = value
        End Set
    End Property
    Property LoginUserLanId() As String
        Get
            Return ViewState("LoginUserLanId")
        End Get
        Set(ByVal value As String)
            ViewState("LoginUserLanId") = value
        End Set
    End Property
    Property AgentID() As String
        Get
            Return ViewState("AgentID")
        End Get
        Set(ByVal value As String)
            ViewState("AgentID") = value
        End Set
    End Property
    Property UserID() As String
        Get
            Return ViewState("UserID")
        End Get
        Set(ByVal value As String)
            ViewState("UserID") = value
        End Set
    End Property
#End Region
#Region "Load"
    Private Sub LoadData()
        FillProcessCampaigns()
        FillCampaigns()
        PopulateKCRPs()
    End Sub

    Private Sub FillProcessCampaigns()
        Dim db As New DBAccess
        Dim dt As DataTable = db.ReturnTable("select * from tbl_Config_Processes where Active=1 order by ProcessName", , False)
        ddlProcess.DataTextField = "ProcessName"
        ddlProcess.DataValueField = "ProcessID"
        ddlProcess.DataSource = dt
        ddlProcess.DataBind()
        dt = Nothing
        db = Nothing
    End Sub
    Private Sub PopulateKCRPs()
        Dim db As New DBAccess("CRM")
        db.slDataAdd("processtype", ddlCampaignType.SelectedValue)
        Dim dt As DataTable = db.ReturnTable("usp_TableF_Get_KCRPs", , True)
        db = Nothing
        lstKCRPSource.DataValueField = "KCRPID"
        lstKCRPSource.DataTextField = "KCRPName"
        lstKCRPSource.DataSource = dt
        lstKCRPSource.DataBind()
        dt = Nothing
    End Sub
    Private Sub PopulateProcessKCRPs()
        Dim db As New DBAccess("crm")
        db.slDataAdd("ProcessID", ddlProcess.SelectedValue)
        db.slDataAdd("CampaignId", ddlCampaign.SelectedValue)
        lstKCRPDestination.DataSource = db.ReturnTable("usp_GetProcessKCRP", , True)
        lstKCRPDestination.DataValueField = "KCRPID"
        lstKCRPDestination.DataTextField = "KCRPName"
        lstKCRPDestination.DataBind()
        db = Nothing
    End Sub
    Private Sub FillCampaigns()
        Common.FillCampaigns(ddlCampaign, AgentID, ddlProcess.SelectedValue, CampaignID)
        Dim db As New DBAccess("CRM")
        Dim dt As DataTable
        db.slDataAdd("ProcessId", ddlProcess.SelectedValue)
        dt = db.ReturnTable("usp_GetTableFCampaigns", , True)
        db = Nothing
        If dt.Rows.Count > 0 Then
            ddlCampaign.Items.Remove(ddlCampaign.Items.FindByValue(0))
        End If
    End Sub
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        HumanMessage.Style.Item("visibility") = "hidden"
        If Not IsPostBack Then
            If Session("AgentID") <> "" Then
                CampaignID = Session("CampaignID")
                AgentID = Session("AgentID")
                PanelReports.Controls.Add(Common.GetMenu(Request.Url, AgentID, Request.ApplicationPath))
                LoadData()
            End If
        End If
    End Sub
#End Region
#Region "Event"
    Protected Sub ddlCampaignType_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ddlCampaignType.SelectedIndexChanged
        PopulateKCRPs()
    End Sub
    Protected Sub btnAdd_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnAdd.Click
        If lstKCRPSource.SelectedIndex = -1 Then
            'LblError.Visible = True
            AlertMessage("No KCRPs seem to have been Selected!! Kinldy select the KCRPs you wish to move!")
        Else
            If LblError.Visible = True Then
                LblError.Visible = False
            End If
            Dim item As ListItem
            Dim Count As Integer = lstKCRPSource.Items.Count
            Dim index(Count) As Int16
            Dim i As Int16 = 0
            Dim j As Int16 = 0
            For Each item In lstKCRPSource.Items
                If item.Selected Then
                    index(i) = lstKCRPSource.SelectedIndex
                    lstKCRPDestination.Items.Add(item)
                    i += 1
                End If
            Next
            lstKCRPSource.SelectedIndex = -1
            For j = 0 To i - 1
                lstKCRPSource.Items.RemoveAt(index(j))
            Next
            lstKCRPDestination.SelectedIndex = -1
        End If
    End Sub
    Protected Sub ddlProcess_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ddlProcess.SelectedIndexChanged
        FillCampaigns()
        PopulateProcessKCRPs()
        PopulateKCRPs()
    End Sub
    Protected Sub btnRemove_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnRemove.Click
        If lstKCRPDestination.SelectedIndex = -1 Then
            ' LblError.Visible = True
            AlertMessage("No KCRPs seem to have been Selected!! Kinldy select the KCRPs you wish to remove!")
        Else
            Dim item As ListItem
            Dim Count As Integer = lstKCRPDestination.Items.Count
            Dim index(Count) As Int16
            Dim i As Int16 = 0
            Dim j As Int16 = 0
            For Each item In lstKCRPDestination.Items
                If item.Selected Then
                    index(i) = lstKCRPDestination.SelectedIndex
                    lstKCRPSource.Items.Add(item)
                    i += 1
                End If
            Next

            For j = 0 To i - 1
                lstKCRPDestination.Items.RemoveAt(index(j))
            Next
            lstKCRPDestination.SelectedIndex = -1
            lstKCRPSource.SelectedIndex = -1
        End If
    End Sub
    Protected Sub btnsave_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnsave.Click
        If ValidateControls() Then
            CreateTableF()
        End If
    End Sub
    Protected Sub imgfav_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles imgfav.Click
        Common.AddToFav(AgentID, "Create Metrics")
        SuccessMessage("Create Metrics has been added to your favourite list")
        PopulateKCRPs()
    End Sub
#End Region
#Region "Utility"

    Private Sub AlertMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMFail"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub

    Private Sub SuccessMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMSuccess"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub

    'Protected Sub ImageButton1_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton1.Click
    '    'fillgrid()
    '    GridViewExportUtil.Export(lblReportName.CurrentPage & "-" & LblError.Text & ".xls", Me.GdAttendance)
    'End Sub


    Public Overrides Sub VerifyRenderingInServerForm(ByVal Control As Control)

    End Sub

#End Region

#Region "Support Function"
    Private Function ValidateControls() As Boolean
        If lstKCRPDestination.Items.Count = 0 Then
            AlertMessage("There seem to be no KCRPs selected. Kindly move some KCRPs into the Destination ListBox")
            Return False
        Else
            Return True
        End If
    End Function
    Private Sub CreateTableF()
        Dim item As ListItem
        Dim db As New DBAccess("CRM")
        Dim ctr As Int32
        ctr = 0
        db.BeginTrans()
        Try
            db.slDataAdd("Active", 0)
            db.UpdateinTable("tbl_Config_Tablef_Definition", "processid =" & ddlProcess.SelectedValue & " and CampaignId=" & ddlCampaign.SelectedValue)

            For Each item In lstKCRPDestination.Items
                db.slDataAdd("KCRPID", item.Value)
                db.slDataAdd("ProcessID", ddlProcess.SelectedValue)
                db.slDataAdd("Sequence", ctr)
                db.slDataAdd("CamapignId", ddlCampaign.SelectedValue)
                db.Executeproc("usp_SaveMetricsForAProcess")
                ctr += 1
            Next
            db.CommitTrans()
            SuccessMessage("KCRPs have been updated for " & ddlProcess.SelectedItem.Text)
        Catch ex As Exception
            db.RollBackTrans()
            AlertMessage(ex.Message)
        Finally
            db = Nothing
        End Try
    End Sub
#End Region

    Protected Sub ddlCampaign_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ddlCampaign.SelectedIndexChanged
        PopulateProcessKCRPs()
        PopulateKCRPs()
    End Sub
End Class
