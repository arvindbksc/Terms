﻿Imports com.nss.DBAccess
Imports System.Data
Imports System.Text
Partial Class TableF_ViewReport
    Inherits System.Web.UI.Page
#Region "Properties"

    Property ProcessID() As Integer
        Get
            Return ViewState("ProcessID")
        End Get
        Set(ByVal value As Integer)
            ViewState("ProcessID") = value
            Session("ProcessID") = value
        End Set
    End Property
    Property CampaignID() As Integer
        Get
            Return ViewState("CampaignID")
        End Get
        Set(ByVal value As Integer)
            ViewState("CampaignID") = value
        End Set
    End Property

    Property AgentID() As String
        Get
            Return ViewState("AgentID")
        End Get
        Set(ByVal value As String)
            ViewState("AgentID") = value
        End Set
    End Property
    Property IsAdmin() As Boolean
        Get
            Return ViewState("IsAdmin")
        End Get
        Set(ByVal value As Boolean)
            ViewState("IsAdmin") = value
        End Set
    End Property
#End Region
#Region "Load"
    Private Sub LoadData()
        ValidUser()
        FillProcessCampaigns()
        FillCampaign()
        FillMonthYear()
    End Sub
    Private Sub FillMonthYear()
        For ictr = 1 To 12
            cboMonthFrom.Items.Add(New ListItem(MonthName(ictr), ictr))
            cboMonthTo.Items.Add(New ListItem(MonthName(ictr), ictr))
        Next
        cboMonthFrom.SelectedIndex = cboMonthFrom.Items.IndexOf(cboMonthFrom.Items.FindByValue(DateTime.Now.AddMonths(-1).Month))
        cboMonthTo.SelectedIndex = cboMonthTo.Items.IndexOf(cboMonthTo.Items.FindByValue(DateTime.Now.AddMonths(-1).Month))
        For ictr = DateTime.Now.Year To 2017 Step -1
            cboYearFrom.Items.Add(New ListItem(ictr, ictr))
            cboYearTo.Items.Add(New ListItem(ictr, ictr))
        Next
        cboYearFrom.SelectedIndex = cboYearFrom.Items.IndexOf(cboYearFrom.Items.FindByValue(DateTime.Now.AddMonths(-1).Year))
        cboYearTo.SelectedIndex = cboYearTo.Items.IndexOf(cboYearTo.Items.FindByValue(DateTime.Now.AddMonths(-1).Year))
    End Sub
    Private Sub FillProcessCampaigns()
        Dim db As New DBAccess("CRM")
        Dim dt As New DataTable
        Try
            db.slDataAdd("agentid", AgentID)
            db.slDataAdd("isadmin", IsAdmin)
            
            dt = db.ReturnTable("usp_getTablefprocess", , True)
            db = Nothing
            CboProcess.DataValueField = "ProcessID"
            CboProcess.DataTextField = "ProcessName"
            CboProcess.DataSource = dt
            CboProcess.DataBind()
            btnRefresh.Enabled = CboProcess.Items.Count > 0
        Catch ex As Exception
            AlertMessage(ex.Message.ToString())
        Finally
            db = Nothing
        End Try
    End Sub
    Private Sub FillCampaign()
        Common.FillCampaigns(cboCampaigns, AgentID, CboProcess.SelectedValue, CampaignID)
    End Sub
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        HumanMessage.Style.Item("visibility") = "hidden"
        If Not IsPostBack Then
            If Session("AgentID") <> "" Then
                ProcessID = Session("ProcessID")
                CampaignID = Session("CampaignID")
                AgentID = Session("AgentID")
                LoadData()
                PanelReports.Controls.Add(Common.GetMenu(Request.Url, AgentID, Request.ApplicationPath))
                fillgrid()
            End If
        End If
    End Sub
    Public starttime As DateTime, endtime As DateTime
    Dim Greencount As New ArrayList
    Dim totalrows As Integer = 0
    Private Sub fillgrid()
        'Get all metrics
        Dim db As New DBAccess
        Dim dt As DataTable
        db.slDataAdd("ProcessID", CboProcess.SelectedValue)
        db.slDataAdd("FromDate", cboYearFrom.SelectedValue & cboMonthFrom.SelectedValue.PadLeft(2, "0") & "01")
        db.slDataAdd("ToDate", cboYearTo.SelectedValue & cboMonthTo.SelectedValue.PadLeft(2, "0") & "01")
        db.slDataAdd("CampaignId", cboCampaigns.SelectedValue)
        dt = db.ReturnTable("usp_TableFReport_Metrics", , True)
        db = Nothing

        'Add months
        Dim ctr As Integer
        'Date.Parse(cboYearFrom.SelectedValue & cboMonthFrom.SelectedValue & "01")

        starttime = Date.Parse(cboYearFrom.SelectedValue & cboMonthFrom.SelectedItem.Text & "01")
        endtime = Date.Parse(cboYearTo.SelectedValue & cboMonthTo.SelectedItem.Text & "01")
        ctr = DateDiff(DateInterval.Month, starttime, endtime)
        Dim c As Integer = 0
        While starttime <= endtime
            dt.Columns.Add(starttime.ToString("MMM") & "-" & starttime.Year & "(A/T)")
            starttime = starttime.AddMonths(1)

            Greencount.Add(0)
            c += 1
        End While

        Dim keys(1) As DataColumn
        keys(0) = dt.Columns("MetricID")
        dt.PrimaryKey = keys

        'Get Data
        db = New DBAccess
        Dim dtData As DataTable
        db.slDataAdd("ProcessID", CboProcess.SelectedValue)
        db.slDataAdd("FromDate", cboYearFrom.SelectedValue & cboMonthFrom.SelectedValue.PadLeft(2, "0") & "01")
        db.slDataAdd("ToDate", cboYearTo.SelectedValue & cboMonthTo.SelectedValue.PadLeft(2, "0") & "01")
        db.slDataAdd("CampaignId", cboCampaigns.SelectedValue)
        dtData = db.ReturnTable("usp_TableF_ReportData", , True)
        db = Nothing


        'Fill the table
        Dim dr As DataRow, drtoupdate As DataRow

        Dim monthvalue As String

        Dim i As Integer = 0
        Dim monthcount As String = ""
        For Each dr In dtData.Rows
            drtoupdate = dt.Rows.Find(dr("metricID"))
            If drtoupdate Is Nothing Then
            Else
                starttime = Date.Parse(dr("year") & "-" & dr("Month").ToString.PadLeft(2, "0") & "-" & "01")

                If Not IsDBNull(dr("Target")) And Not IsDBNull(dr("Achievement")) Then

                    If dr("Achievement") < dr("Target") Then
                        monthvalue = "span" & IIf(drtoupdate("Higherisbetter"), "Red", "Green") & dr("Achievement").ToString & "/" & dr("Target").ToString
                    Else
                        monthvalue = "span" & IIf(drtoupdate("Higherisbetter"), "Green", "Red") & dr("Achievement").ToString & "/" & dr("Target").ToString
                    End If
                    If dr("Achievement") = dr("Target") Then
                        monthvalue = "spanGreen" & dr("Achievement").ToString & "/" & dr("Target").ToString
                    End If
                Else
                    monthvalue = "spanWhite" & IIf(IsDBNull(dr("Achievement")), "N/A", dr("Achievement").ToString) & "/" & IIf(IsDBNull(dr("Target")), "N/A", dr("Target").ToString)

                End If
                drtoupdate.Item(starttime.ToString("MMM") & "-" & starttime.Year & "(A/T)") = monthvalue
            End If
        Next
        dt.PrimaryKey = Nothing
        dt.Columns.Remove("MetricID")
        dt.Columns.Remove("Higherisbetter")
        dt.Columns.Remove("Sequence")
        dt.AcceptChanges()

        'Bind the grid
        GridView1.Visible = True
        GridView1.DataSource = dt
        GridView1.DataBind()

        totalrows = dt.Rows.Count * (3 / 4)
        If GridView1.Rows.Count > 0 Then
            Dim j As Integer = GridView1.HeaderRow.Cells.Count
            Dim k As Integer = 4

            For k = 4 To j - 1
                If Greencount(k - 4) >= totalrows Then
                    GridView1.HeaderRow.Cells(k).Text += "<br /><img src='../_assets/img/Green.gif' />"
                Else
                    GridView1.HeaderRow.Cells(k).Text += "<br /><img src='../_assets/img/red.gif' />"
                End If
            Next k
        End If
    End Sub
    Private Function ValidUser() As Boolean
        Dim db As New DBAccess("CRM")
        Dim dr As DataRow = db.ReturnRow("Select top 1 * from tbl_Config_TablefProcessUserMap where agentid='" & AgentID & "'")
        db = Nothing
        If dr Is Nothing Then
            Return False
        Else
            IsAdmin = dr("IsAdmin")
            Return True
        End If
    End Function
#End Region
#Region "grid ops"
    Protected Sub GridView1_RowDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles GridView1.RowDataBound
        Dim cell As Object
        If e.Row.RowType = DataControlRowType.DataRow Then
            Dim counter As Integer = 0
            For Each cell In e.Row.Cells
                If cell.Text.ToString.StartsWith("spanRed") Then
                    cell.Text = cell.Text.Replace("spanRed", "")
                    cell.CssClass = "tablef_red"
                ElseIf cell.Text.ToString.StartsWith("spanGreen") Then
                    cell.Text = cell.Text.Replace("spanGreen", "")
                    cell.CssClass = "tablef_green"
                    Greencount(counter - 4) += 1
                ElseIf cell.Text.ToString.StartsWith("spanWhite") Then
                    cell.Text = cell.Text.Replace("spanWhite", "")
                    cell.CssClass = "tablef_white"
                Else
                    cell.Attributes.Add("Style", "border: black 1px solid;")
                End If
                counter += 1
            Next
        Else
            For Each cell In e.Row.Cells
                cell.Attributes.Add("Style", "border-right: black 1px solid;    border-top: black 1px solid;    border-left: black 1px solid;    border-bottom: black 1px solid;")
            Next
        End If
    End Sub
#End Region
#Region "Event"
    Protected Sub btnRefresh_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnRefresh.Click
        fillgrid()
    End Sub
    Protected Sub CboProcess_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles CboProcess.SelectedIndexChanged
        FillCampaign()
        fillgrid()
    End Sub
    Protected Sub cboMonthFrom_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboMonthFrom.SelectedIndexChanged
        fillgrid()
    End Sub
    Protected Sub cboYearFrom_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboYearFrom.SelectedIndexChanged
        fillgrid()
    End Sub
    Protected Sub cboMonthTo_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboMonthTo.SelectedIndexChanged
        fillgrid()
    End Sub
    Protected Sub cboYearTo_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboYearTo.SelectedIndexChanged
        fillgrid()
    End Sub
    Protected Sub ImageButton1_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton1.Click
        fillgrid()
        GridViewExportUtil.Export(CboProcess.SelectedItem.Text & "-" & cboMonthFrom.SelectedItem.Text & ".xls", Me.GridView1)
    End Sub
    Protected Sub imgfav_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles imgfav.Click
        Common.AddToFav(AgentID, "View Report")
        SuccessMessage("Report has been added to your favourite list")
        fillgrid()
    End Sub
    Protected Sub cboCampaigns_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboCampaigns.SelectedIndexChanged
        fillgrid()
    End Sub
#End Region
#Region "Utility"

    Private Sub AlertMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMFail"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub

    Private Sub SuccessMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMSuccess"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub
    Public Overrides Sub VerifyRenderingInServerForm(ByVal Control As Control)

    End Sub
#End Region

    
    
End Class
