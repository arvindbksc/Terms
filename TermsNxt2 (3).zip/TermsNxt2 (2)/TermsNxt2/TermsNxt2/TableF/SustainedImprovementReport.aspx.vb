﻿Imports com.nss.DBAccess
Imports System.Data
Imports System.Text
Partial Class TableF_SustainedImprovementReport
    Inherits System.Web.UI.Page
#Region "Properties"

    Property ProcessID() As Integer
        Get
            Return ViewState("ProcessID")
        End Get
        Set(ByVal value As Integer)
            ViewState("ProcessID") = value
            Session("ProcessID") = value
        End Set
    End Property
    Property CampaignID() As Integer
        Get
            Return ViewState("CampaignID")
        End Get
        Set(ByVal value As Integer)
            ViewState("CampaignID") = value
        End Set
    End Property

    Property AgentID() As String
        Get
            Return ViewState("AgentID")
        End Get
        Set(ByVal value As String)
            ViewState("AgentID") = value
        End Set
    End Property
    Property IsAdmin() As Boolean
        Get
            Return ViewState("IsAdmin")
        End Get
        Set(ByVal value As Boolean)
            ViewState("IsAdmin") = value
        End Set
    End Property
#End Region
#Region "Load"
    Private Sub LoadData()
        ValidUser()
        FillProcessCampaigns()
        FillCampaign()
        FillMonthYear()
    End Sub
    Private Sub FillMonthYear()
        For ictr = 1 To 12
            cboMonthFrom.Items.Add(New ListItem(MonthName(ictr), ictr))
            cboMonthTo.Items.Add(New ListItem(MonthName(ictr), ictr))
        Next
        cboMonthFrom.SelectedIndex = cboMonthFrom.Items.IndexOf(cboMonthFrom.Items.FindByValue(DateTime.Now.AddMonths(-1).Month))
        cboMonthTo.SelectedIndex = cboMonthTo.Items.IndexOf(cboMonthTo.Items.FindByValue(DateTime.Now.AddMonths(-1).Month))
        For ictr = DateTime.Now.Year To 2017 Step -1
            cboYearFrom.Items.Add(New ListItem(ictr, ictr))
            cboYearTo.Items.Add(New ListItem(ictr, ictr))
        Next
        cboYearFrom.SelectedIndex = cboYearFrom.Items.IndexOf(cboYearFrom.Items.FindByValue(DateTime.Now.AddMonths(-1).Year))
        cboYearTo.SelectedIndex = cboYearTo.Items.IndexOf(cboYearTo.Items.FindByValue(DateTime.Now.AddMonths(-1).Year))
    End Sub
    Private Sub FillProcessCampaigns()
        Dim db As New DBAccess("CRM")
        Dim dt As New DataTable
        Try
            db.slDataAdd("agentid", AgentID)
            db.slDataAdd("isadmin", IsAdmin)

            dt = db.ReturnTable("usp_getTablefprocess", , True)
            db = Nothing
            CboProcess.DataValueField = "ProcessID"
            CboProcess.DataTextField = "ProcessName"
            CboProcess.DataSource = dt
            CboProcess.DataBind()
            btnRefresh.Enabled = CboProcess.Items.Count > 0
        Catch ex As Exception
            AlertMessage(ex.Message.ToString())
        Finally
            db = Nothing
        End Try
    End Sub
    Private Sub FillCampaign()
        Common.FillCampaigns(cboCampaigns, AgentID, CboProcess.SelectedValue, CampaignID)
    End Sub
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        HumanMessage.Style.Item("visibility") = "hidden"
        If Not IsPostBack Then
            If Session("AgentID") <> "" Then
                ProcessID = Session("ProcessID")
                CampaignID = Session("CampaignID")
                AgentID = Session("AgentID")
                LoadData()
                PanelReports.Controls.Add(Common.GetMenu(Request.Url, AgentID, Request.ApplicationPath))
                fillgrid()
            End If
        End If
    End Sub
    Public starttime As DateTime, endtime As DateTime
    Dim Greencount As New ArrayList
    Dim totalrows As Integer = 0
    Private Sub fillgrid()
        'Get all metrics
        Dim db As New DBAccess
        Dim year, month, selmonth As Integer
        Dim monthname As String

        selmonth = cboMonthFrom.SelectedValue
        month = cboMonthFrom.SelectedValue - 3
        year = Convert.ToInt32(cboYearFrom.SelectedItem.Text)

        If month <= 0 Then
            year -= 1
            month += 12
        End If
        Dim dt As DataTable
        
        monthname = GetMonthName(month)
        db.slDataAdd("ProcessID", CboProcess.SelectedValue)
        db.slDataAdd("FromDate", year & month.ToString.PadLeft(2, "0") & "01")
        db.slDataAdd("ToDate", cboYearTo.SelectedValue & cboMonthTo.SelectedValue.PadLeft(2, "0") & "01")
        db.slDataAdd("CampaignId", cboCampaigns.SelectedValue)
        dt = db.ReturnTable("usp_TableFReport_Metrics", , True)
        db = Nothing

        'Add months
        Dim ctr As Integer
        'Date.Parse(cboYearFrom.SelectedValue & cboMonthFrom.SelectedValue & "01")

        starttime = Date.Parse(year & monthname & "01")
        endtime = Date.Parse(cboYearTo.SelectedValue & cboMonthTo.SelectedItem.Text & "01")
        ctr = DateDiff(DateInterval.Month, Date.Parse(cboYearFrom.SelectedValue & cboMonthFrom.SelectedItem.Text & "01"), Date.Parse(cboYearTo.SelectedValue & cboMonthTo.SelectedItem.Text & "01"))
        Dim c As Integer = 0
        While starttime <= endtime
            dt.Columns.Add(starttime.ToString("MMM") & "-" & starttime.Year & "(A/T)")
            starttime = starttime.AddMonths(1)

            Greencount.Add(0)
            c += 1
        End While

        Dim keys(1) As DataColumn
        keys(0) = dt.Columns("MetricID")
        dt.PrimaryKey = keys

        'Get Data
        db = New DBAccess
        Dim dtData As DataTable
        db.slDataAdd("ProcessID", CboProcess.SelectedValue)
        db.slDataAdd("FromDate", year & month.ToString.PadLeft(2, "0") & "01")
        db.slDataAdd("ToDate", cboYearTo.SelectedValue & cboMonthTo.SelectedValue.PadLeft(2, "0") & "01")
        db.slDataAdd("CampaignId", cboCampaigns.SelectedValue)
        dtData = db.ReturnTable("usp_TableF_ReportData", , True)
        db = Nothing


        'Fill the table
        Dim dr As DataRow, drtoupdate As DataRow

        Dim monthvalue As String

        Dim i As Integer = 0
        Dim monthcount As String = ""
        For Each dr In dtData.Rows
            drtoupdate = dt.Rows.Find(dr("metricID"))
            If drtoupdate Is Nothing Then
            Else
                starttime = Date.Parse(dr("year") & "-" & dr("Month").ToString.PadLeft(2, "0") & "-" & "01")

                monthvalue = IIf(IsDBNull(dr("Achievement")), "N/A", dr("Achievement").ToString)
                drtoupdate.Item(starttime.ToString("MMM") & "-" & starttime.Year & "(A/T)") = monthvalue
            End If
        Next
        dt.PrimaryKey = Nothing
        dt.Columns.Remove("MetricID")
        dt.Columns.Remove("Higherisbetter")
        dt.Columns.Remove("Sequence")
        dt.AcceptChanges()

        Dim dt1 As New DataTable
        dt1 = dt.Copy
        'For Each row1 As DataRow In dt.Rows
        Dim p, q, r As Double
        For z As Integer = 0 To dt.Rows.Count - 1
            For l As Integer = 7 To dt.Columns.Count - 1
                If Not dt.Rows(z)(l - 3).ToString.StartsWith("&") And Not IsDBNull(dt.Rows(z)(l - 3)) Then
                    p = Math.Round(Convert.ToDecimal(IIf(dt.Rows(z)(l - 3).ToString.StartsWith("N"), 0, dt.Rows(z)(l - 3))), 2)
                End If
                If Not dt.Rows(z)(l - 2).ToString.StartsWith("&") And Not IsDBNull(dt.Rows(z)(l - 2)) Then
                    q = Math.Round(Convert.ToDecimal(IIf(dt.Rows(z)(l - 2).ToString.StartsWith("N"), 0, dt.Rows(z)(l - 2))), 2)
                End If
                If Not dt.Rows(z)(l - 1).ToString.StartsWith("&") And Not IsDBNull(dt.Rows(z)(l - 1)) Then
                    r = Math.Round(Convert.ToDecimal(IIf(dt.Rows(z)(l - 1).ToString.StartsWith("N"), 0, dt.Rows(z)(l - 1))), 2)
                End If
                dt1.Rows(z)(l) = (p + q + r)
                dt1.Rows(z)(l) = Math.Round((p + q + r) / 3, 2)
                If Not dt.Rows(z)(l).ToString.StartsWith("N") Then
                    If IIf(IsDBNull(dt.Rows(z)(l)), 0, dt.Rows(z)(l)) > IIf(IsDBNull(dt1.Rows(z)(l)), 0, dt1.Rows(z)(l)) Then
                        dt1.Rows(z)(l) = "Improvement"
                    Else
                        dt1.Rows(z)(l) = "No Improvement"
                    End If
                Else
                    dt1.Rows(z)(l) = "N/A"
                End If

            Next
        Next
        dt1.Columns.Remove(dt1.Columns(4))
        dt1.Columns.Remove(dt1.Columns(4))
        dt1.Columns.Remove(dt1.Columns(4))
        'Bind the grid
        GridView1.Visible = True
        GridView1.DataSource = dt1
        GridView1.DataBind()
        'dt = Nothing
      
    End Sub
    Private Function ValidUser() As Boolean
        Dim db As New DBAccess("CRM")
        Dim dr As DataRow = db.ReturnRow("Select top 1 * from tbl_Config_TablefProcessUserMap where agentid='" & AgentID & "'")
        db = Nothing
        If dr Is Nothing Then
            Return False
        Else
            IsAdmin = dr("IsAdmin")
            Return True
        End If
    End Function
#End Region
#Region "grid ops"
    Protected Sub GridView1_RowDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles GridView1.RowDataBound
        Dim cell As Object
        If e.Row.RowType = DataControlRowType.DataRow Then
            Dim counter As Integer = 0
            For Each cell In e.Row.Cells

                If cell.Text.ToString.Contains("No Improvement") Then
                    cell.Attributes.Add("Style", "border: black 1px solid;background-color: red; color: white; font-weight: bold;")
                ElseIf cell.Text.ToString.Contains("Improvement") Then
                    cell.Attributes.Add("Style", "border: black 1px solid;background-color: green; color: white; font-weight: bold;")

                Else
                    cell.Attributes.Add("Style", "border: black 1px solid;")
                End If

                counter += 1
            Next
        Else
            For Each cell In e.Row.Cells
                cell.Attributes.Add("Style", "border-right: black 1px solid;    border-top: black 1px solid;    border-left: black 1px solid;    border-bottom: black 1px solid;")
            Next
        End If
    End Sub
#End Region
#Region "Event"
    Protected Sub btnRefresh_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnRefresh.Click
        fillgrid()
    End Sub
    Protected Sub CboProcess_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles CboProcess.SelectedIndexChanged
        FillCampaign()
        fillgrid()
    End Sub
    Protected Sub cboMonthFrom_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboMonthFrom.SelectedIndexChanged
        fillgrid()
    End Sub
    Protected Sub cboYearFrom_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboYearFrom.SelectedIndexChanged
        fillgrid()
    End Sub
    Protected Sub cboMonthTo_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboMonthTo.SelectedIndexChanged
        fillgrid()
    End Sub
    Protected Sub cboYearTo_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboYearTo.SelectedIndexChanged
        fillgrid()
    End Sub
    Protected Sub ImageButton1_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton1.Click
        fillgrid()
        GridViewExportUtil.Export(CboProcess.SelectedItem.Text & "-" & cboMonthFrom.SelectedItem.Text & ".xls", Me.GridView1)
    End Sub
    Protected Sub imgfav_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles imgfav.Click
        Common.AddToFav(AgentID, "Sustained Improvement Report")
        SuccessMessage("Report has been added to your favourite list")
        fillgrid()
    End Sub
    Protected Sub cboCampaigns_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboCampaigns.SelectedIndexChanged
        fillgrid()
    End Sub
#End Region
#Region "Utility"

    Private Sub AlertMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMFail"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub

    Private Sub SuccessMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMSuccess"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub
    Public Overrides Sub VerifyRenderingInServerForm(ByVal Control As Control)

    End Sub
#End Region
#Region "Support Function"
    Private Function GetMonthName(ByVal monthNum As Integer) As String
        Dim strDate As New DateTime(1, monthNum, 1)
        Return strDate.ToString("MMM")
    End Function
#End Region

   
End Class
