﻿Imports com.nss.DBAccess
Imports System.Data
Partial Class TableF_ListKCRP
    Inherits System.Web.UI.Page
#Region "Properties"
    Property CampaignID() As Integer
        Get
            Return 0 'ViewState("CampaignID")
        End Get
        Set(ByVal value As Integer)
            'ViewState("CampaignID") = value
            'Session("CampaignID") = value
        End Set
    End Property
   
    Property AgentID() As String
        Get
            Return ViewState("AgentID")
        End Get
        Set(ByVal value As String)
            ViewState("AgentID") = value
        End Set
    End Property
    Property EditMode() As Boolean
        Get
            Return ViewState("Mode")
        End Get
        Set(ByVal value As Boolean)
            ViewState("Mode") = value
        End Set
    End Property

    Property KCRPID() As String
        Get
            Return ViewState("KCRPID")
        End Get
        Set(ByVal value As String)
            ViewState("KCRPID") = value
        End Set
    End Property
   
    Property IsAdmin() As Boolean
        Get
            Return ViewState("IsAdmin")
        End Get
        Set(ByVal value As Boolean)
            ViewState("IsAdmin") = value
        End Set
    End Property
#End Region
#Region "Load"
    Private Sub FillGrid()
        Dim db As New DBAccess("CRM")
        GridView1.DataSource = db.ReturnTable("usp_Get_TableF_KCRPs", , True)
        GridView1.DataBind()
        db = Nothing
        lblReportName.Text = "KCRPs List"
    End Sub
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        HumanMessage.Style.Item("visibility") = "hidden"
        If Not IsPostBack Then
            If Session("AgentID") <> "" Then
                CampaignID = Session("CampaignID")
                AgentID = Session("AgentID")
                PanelReports.Controls.Add(Common.GetMenu(Request.Url, AgentID, Request.ApplicationPath))
                FillGrid()
            End If
        End If
    End Sub
#End Region
#Region "Event"
    Protected Sub ImageButton1_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton1.Click
        FillGrid()
        GridViewExportUtil.Export(lblReportName.Text & ".xls", Me.GridView1)
    End Sub
    Protected Sub btnAdd_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnAdd.Click
        btnremove.Visible = False
        btnOK.Visible = True
        lblkcrpid.Text = "New"
        txtnewkcrp.Text = ""
        txtkcrpdesc.Text = ""
        cboprocessType.SelectedValue = 1
        EditMode = False
        Dim str As String
        str = "$('#DialogBackground').height($(document).height()-10);$('#DialogBackground').width($(window).width());$('#DialogBackground').css('visibility','visible');$('#Pnlnewkcrp').css('visibility','visible');" & _
        " $('#Pnlnewkcrp').css('left',($(window).width() - $('#Pnlnewkcrp').width())/2); "
        ScriptManager.RegisterStartupScript(Page, Page.GetType(), "Movedialog", str, True)
    End Sub
    Protected Sub btnOK_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnOK.Click
        Dim db As New DBAccess("CRM")
        db.slDataAdd("KCRPName", txtnewkcrp.Text)
        db.slDataAdd("KCRPDescription", txtkcrpdesc.Text)
        db.slDataAdd("processType", cboprocessType.SelectedValue)
        If EditMode Then
            db.UpdateinTable("tbl_config_TableF_KCRP", " KCRPID=" & lblkcrpid.Text)
            SuccessMessage("KCRP " & txtnewkcrp.Text & " has been updated")
        Else
            db.InsertinTable("tbl_config_TableF_KCRP")
            SuccessMessage("New KCRP has been added")
        End If
        db = Nothing
        FillGrid()
    End Sub
    Protected Sub btnremove_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnremove.Click
        Dim db As New DBAccess("crm")
        db.slDataAdd("Active", 0)
        db.UpdateinTable("tbl_config_TableF_KCRP", " KCRPID=" & lblkcrpid.Text)
        db = Nothing
        SuccessMessage("KCRP " & txtnewkcrp.Text & " has been deleted")
        FillGrid()
    End Sub
    Protected Sub imgfav_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles imgfav.Click
        Common.AddToFav(AgentID, "KCRP List")
        SuccessMessage("Report has been added to your favourite list")
        fillgrid()
    End Sub
    Protected Sub cboprocessType_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboprocessType.SelectedIndexChanged
        Dim str As String
        str = "$('#DialogBackground').height($(document).height()-10);$('#DialogBackground').width($(window).width());$('#DialogBackground').css('visibility','visible');$('#Pnlnewkcrp').css('visibility','visible');" & _
        " $('#Pnlnewkcrp').css('left',($(window).width() - $('#Pnlnewkcrp').width())/2); "
        ScriptManager.RegisterStartupScript(Page, Page.GetType(), "Movedialog", str, True)
    End Sub
#End Region
#Region "Grid ops"
    Protected Sub GridView1_RowCommand(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewCommandEventArgs) Handles GridView1.RowCommand
        If e.CommandName = "change" Then
            btnremove.Visible = False
            btnOK.Visible = True
            KCRPID = e.CommandArgument
            Dim db As New DBAccess("crm")
            db.slDataAdd("kcrpid", KCRPID)
            Dim dr As DataRow = db.ReturnRow("select * from tbl_config_TableF_KCRP where kcrpid=" & KCRPID)
            db = Nothing
            lblkcrpid.Text = KCRPID
            txtnewkcrp.Text = dr("KCRPName")
            txtkcrpdesc.Text = dr("KCRPDEscription")
            cboprocessType.SelectedValue = dr("Processtype")

            EditMode = True
            Dim str As String
            str = "$('#DialogBackground').height($(document).height()-10);$('#DialogBackground').width($(window).width());$('#DialogBackground').css('visibility','visible');$('#Pnlnewkcrp').css('visibility','visible');" & _
            " $('#Pnlnewkcrp').css('left',($(window).width() - $('#Pnlnewkcrp').width())/2); "
            ScriptManager.RegisterStartupScript(Page, Page.GetType(), "Movedialog", str, True)
        ElseIf e.CommandName = "remove" Then
            btnremove.Visible = True
            btnOK.Visible = False
            KCRPID = e.CommandArgument
            Dim db As New DBAccess("crm")
            db.slDataAdd("kcrpid", KCRPID)
            Dim dr As DataRow = db.ReturnRow("select * from tbl_config_TableF_KCRP where kcrpid=" & KCRPID)
            db = Nothing
            lblkcrpid.Text = KCRPID
            txtnewkcrp.Enabled = False
            txtkcrpdesc.Enabled = False
            txtnewkcrp.Text = dr("KCRPName")
            txtkcrpdesc.Text = dr("KCRPDEscription")
            cboprocessType.SelectedValue = dr("Processtype")
            cboprocessType.Enabled = False
            EditMode = True
            Dim str As String
            str = "$('#DialogBackground').height($(document).height()-10);$('#DialogBackground').width($(window).width());$('#DialogBackground').css('visibility','visible');$('#Pnlnewkcrp').css('visibility','visible');" & _
            " $('#Pnlnewkcrp').css('left',($(window).width() - $('#Pnlnewkcrp').width())/2); "
            ScriptManager.RegisterStartupScript(Page, Page.GetType(), "Movedialog", str, True)
        End If
    End Sub
#End Region
#Region "--- Utility ---"

    Private Sub AlertMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMFail"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub

    Private Sub SuccessMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMSuccess"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub
#End Region

End Class
