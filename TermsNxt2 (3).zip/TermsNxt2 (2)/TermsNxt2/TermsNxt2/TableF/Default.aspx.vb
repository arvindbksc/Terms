﻿Imports com.nss.DBAccess
Imports System.Data
Partial Class TableF_Default
    Inherits System.Web.UI.Page
#Region "Properties"

    Property dtsummary() As DataTable
        Get
            Return ViewState("dtSummary")
        End Get
        Set(ByVal value As DataTable)
            ViewState("dtSummary") = value
        End Set
    End Property
    Property SupervisorID() As String
        Get
            Return ViewState("SupervisorID")
        End Get
        Set(ByVal value As String)
            ViewState("SupervisorID") = value
        End Set
    End Property
    Property TransID() As Integer
        Get
            Return ViewState("TransID")
        End Get
        Set(ByVal value As Integer)
            ViewState("TransID") = value
        End Set
    End Property
    Property UserID() As String
        Get
            Return ViewState("UserID")
        End Get
        Set(ByVal value As String)
            ViewState("UserID") = value
        End Set
    End Property

    Property CampaignID() As Integer
        Get
            Return 0 'ViewState("CampaignID")
        End Get
        Set(ByVal value As Integer)
            'ViewState("CampaignID") = value
            'Session("CampaignID") = value
        End Set
    End Property

    Property ProcessID() As Integer
        Get
            Return ViewState("ProcessID")
        End Get
        Set(ByVal value As Integer)
            ViewState("ProcessID") = value
            Session("ProcessID") = value
        End Set
    End Property
    Property AgentID() As String
        Get
            Return ViewState("AgentID")
        End Get
        Set(ByVal value As String)
            ViewState("AgentID") = value
        End Set
    End Property
    Property Month() As String
        Get
            Return ViewState("Month")
        End Get
        Set(ByVal value As String)
            ViewState("Month") = value
        End Set
    End Property
    Property Year() As Integer
        Get
            Return ViewState("Year")
        End Get
        Set(ByVal value As Integer)
            ViewState("Year") = value
        End Set
    End Property
    Property UsrID() As Integer
        Get
            Return ViewState("UsrID")
        End Get
        Set(ByVal value As Integer)
            ViewState("UsrID") = value
        End Set
    End Property
    Property LoginID() As Integer
        Get
            Return ViewState("LoginID")
        End Get
        Set(ByVal value As Integer)
            ViewState("LoginID") = value
        End Set
    End Property
    Property CurrentDate() As Date
        Get
            Return ViewState("CurrentDate")
        End Get
        Set(ByVal value As Date)
            ViewState("CurrentDate") = value
        End Set
    End Property
    Property IncentiveMonth() As String
        Get
            Return ViewState("IncentiveMonth")
        End Get
        Set(ByVal value As String)
            ViewState("IncentiveMonth") = value
        End Set
    End Property
    Property IncentiveYear() As Integer
        Get
            Return ViewState("IncentiveYear")
        End Get
        Set(ByVal value As Integer)
            ViewState("IncentiveYear") = value
        End Set
    End Property
    Property IsAdmin() As Boolean
        Get
            Return ViewState("IsAdmin")
        End Get
        Set(ByVal value As Boolean)
            ViewState("IsAdmin") = value
        End Set
    End Property
#End Region
#Region "Load"
    Private Sub LoadData()
        ValidUser()
        FillProcessCampaigns()
        FillCampaigns()
        FillMonthYear()
        'Dim db As New DBAccess("CRM")
        'Dim dr As DataRow = db.ReturnRow("SELECT getdate() as currentdate")
        'CurrentDate = dr("currentDate")
        'IncentiveMonth = MonthName(DatePart(DateInterval.Month, DateAdd(DateInterval.Month, -1, CurrentDate)))
        'IncentiveYear = DatePart(DateInterval.Year, DateAdd(DateInterval.Month, -1, CurrentDate))
        'db = Nothing

    End Sub
    Private Sub FillMonthYear()
        For ictr = 1 To 12
            cboMonth.Items.Add(New ListItem(MonthName(ictr), ictr))
        Next

        cboMonth.SelectedIndex = cboMonth.Items.IndexOf(cboMonth.Items.FindByValue(DateTime.Now.AddMonths(-1).Month))
        For ictr = DateTime.Now.Year To 2017 Step -1
            cboYear.Items.Add(New ListItem(ictr, ictr))
        Next
        cboYear.SelectedIndex = cboYear.Items.IndexOf(cboYear.Items.FindByValue(DateTime.Now.AddMonths(-1).Year))
    End Sub
    Private Sub FillProcessCampaigns()
        'Common.FillProcessCampaigns(CboProcess, cboCampaigns, AgentID, CampaignID)
        'Dim lstProcess As New ListItem
        'lstProcess.Value = 0
        'lstProcess.Text = "All"
        'If CboProcess.Items.Contains(lstProcess) Then
        '    CboProcess.Items.Remove(lstProcess)
        'End If
        '=========================================================

        Dim db As New DBAccess("CRM")
        Dim dt As New DataTable
        Try
            db.slDataAdd("agentid", AgentID)
            db.slDataAdd("isadmin", IsAdmin)
            'If IsAdmin Then
            '    CboProcess.DataSource = db.ReturnTable("SELECT Camp_ID, Process FROM tbl_Campaign_Mst WHERE isActive = 'Y' AND isPrimary = 1 and camp_id in (SELECT distinct CampaignID FROM [tbl_TableF_Definition]) ORDER BY Process", , False)
            'Else
            '    CboProcess.DataSource = db.ReturnTable("SELECT Camp_ID, Process FROM tbl_Campaign_Mst inner join tbl_tablef_campaignusermap on tbl_tablef_campaignusermap.campaignid=tbl_Campaign_Mst.camp_id and tbl_tablef_campaignusermap.userid =" & Session("userid") & " WHERE isActive = 'Y' AND isPrimary = 1 and camp_id in (SELECT distinct CampaignID FROM [tbl_TableF_Definition]) ORDER BY Process", , False)
            'End If
            dt = db.ReturnTable("usp_getTablefprocess", , True)
            db = Nothing
            CboProcess.DataValueField = "ProcessID"
            CboProcess.DataTextField = "ProcessName"
            CboProcess.DataSource = dt
            CboProcess.DataBind()
            btnRefresh.Enabled = CboProcess.Items.Count > 0
        Catch ex As Exception
            AlertMessage(ex.Message.ToString())
        Finally
            db = Nothing
        End Try
    End Sub
    Private Sub FillCampaigns()
        Dim db As New DBAccess("CRM")
        Dim dt As DataTable
        db.slDataAdd("ProcessId", CboProcess.SelectedValue)
        dt = db.ReturnTable("usp_GetTableFCampaigns", , True)
        db = Nothing
        If dt.Rows.Count <= 0 Then
            Dim dr As DataRow = dt.NewRow
            dr("Name") = "All"
            dr("CampaignId") = 0
            dt.Rows.Add(dr)
        End If
        cboCampaigns.DataTextField = "Name"
        cboCampaigns.DataValueField = "CampaignId"
        cboCampaigns.DataSource = dt
        cboCampaigns.DataBind()
        'Common.FillCampaigns(cboCampaigns, AgentID, CboProcess.SelectedValue, CampaignID)
    End Sub
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        HumanMessage.Style.Item("visibility") = "hidden"
        If Not IsPostBack Then
            If Session("AgentID") <> "" Then
                ProcessID = Session("ProcessID")
                CampaignID = Session("CampaignID")
                AgentID = Session("AgentID")
                LoadData()
                PanelReports.Controls.Add(Common.GetMenu(Request.Url, AgentID, Request.ApplicationPath))
                fillgrid()
            End If

        End If
    End Sub
    Private Function ValidUser() As Boolean
        Dim db As New DBAccess("CRM")
        Dim dr As DataRow = db.ReturnRow("Select top 1 * from tbl_Config_TablefProcessUserMap where agentid='" & AgentID & "'")
        db = Nothing
        If dr Is Nothing Then
            Return False
        Else
            IsAdmin = dr("IsAdmin")
            btnFreeze.Visible = IsAdmin
            btnUnFreeze.Visible = IsAdmin
            Return True
        End If
    End Function
    Private Sub fillgrid()
        Dim db As New DBAccess("CRM")
        Dim dt As DataTable
        db.slDataAdd("processID", CboProcess.SelectedValue)
        db.slDataAdd("year", cboYear.SelectedValue)
        db.slDataAdd("month", cboMonth.SelectedValue)
        db.slDataAdd("YYYYMMDD", cboYear.SelectedValue & cboMonth.SelectedValue.PadLeft(2, "0") & "01")
        db.slDataAdd("CampaignId", cboCampaigns.SelectedValue)
        dt = db.ReturnTable("usp_ShowMetricsForAProcess", , True)
        db = Nothing
        dt.Columns.Add("Target1")
        dt.Columns.Add("Achievement1")

        If Not dt.Rows.Count = 0 Then
            db = New DBAccess("CRM")
            Dim dt1 As DataTable
            dt1 = db.ReturnTable("select top 1 * FROM tbl_Data_TableF where processid =" & CboProcess.SelectedValue & " and [campaignid]=" & cboCampaigns.SelectedValue & " and [YYYYMMDD]=" & cboYear.SelectedItem.Text & cboMonth.SelectedItem.Value.PadLeft(2, "0") & "01", "", False)
            db = Nothing
            If dt1.Rows.Count = 0 Then
                dt.Columns("Target1").DefaultValue = ""
                dt.Columns("Achievement1").DefaultValue = ""
                db = New DBAccess("crm")
                Dim dt2 As DataTable
                db.slDataAdd("processID", CboProcess.SelectedValue)
                db.slDataAdd("year", cboYear.SelectedValue)
                db.slDataAdd("month", cboMonth.SelectedValue)
                db.slDataAdd("YYYYMMDD", cboYear.SelectedValue & cboMonth.SelectedValue.PadLeft(2, "0") & "01")
                db.slDataAdd("CampaignId", cboCampaigns.SelectedValue)
                dt2 = db.ReturnTable("usp_getPreviousMonthTarget", , True)

                For Each row1 As DataRow In dt.Rows
                    If dt2.Select("MetricID='" & row1.Item("MetricID") & "'").Length > 0 Then
                        row1.Item("Target1") = IIf(IsDBNull(dt2.Select("MetricID='" & row1.Item("MetricID") & "'")(0).Item("Target")), "N/A", dt2.Select("MetricID='" & row1.Item("MetricID") & "'")(0).Item("Target"))
                        'row1.Item("Achievement1") = IIf(IsDBNull(dt2.Select("MetricID='" & row1.Item("MetricID") & "'")(0).Item("Achievement")), "N/A", dt2.Select("MetricID='" & row1.Item("MetricID") & "'")(0).Item("Achievement"))
                    End If
                Next
            Else
                dt.Columns("Target1").DefaultValue = "N/A"
                dt.Columns("Achievement1").DefaultValue = "N/A"
                For Each row As DataRow In dt.Rows
                    'If row.Item("Target") = "" Or row.Item("Target") = Nothing Then
                    '    row.Item("Target") = "N/A"
                    'End If

                    row.Item("Target1") = IIf(IsDBNull(row.Item("Target")), "N/A", row.Item("Target"))
                    row.Item("Achievement1") = IIf(IsDBNull(row.Item("Achievement")), "N/A", row.Item("Achievement"))
                    'If row.Item("Achievement") = "" Or row.Item("Achievement") = Nothing Then
                    '    row.Item("Achievement") = "N/A"
                    'End If
                Next
            End If
        End If
        dt.Columns.Remove("Target")
        dt.Columns.Remove("Achievement")
        db = Nothing
        'lblNoData.Visible = (dt.Rows.Count = 0)
        If dt.Rows.Count > 0 Then
            GridView1.DataSource = dt
            GridView1.DataBind()

            lblReportName.Text = "Fill Metrics for " & CboProcess.SelectedItem.Text
            db = New DBAccess("crm")
            db.slDataAdd("processid", CboProcess.SelectedValue)
            db.slDataAdd("year", cboYear.SelectedValue)
            db.slDataAdd("month", cboMonth.SelectedValue)
            db.slDataAdd("YYYYMMDD", cboYear.SelectedValue & cboMonth.SelectedValue.PadLeft(2, "0") & "01")
            db.slDataAdd("CampaignId", cboCampaigns.SelectedValue)
            Dim isfrozen As Boolean = db.ReturnValue("usp_TableF_IsFrozen", True)
            GridView1.Enabled = Not isfrozen
            btnsave.Enabled = Not isfrozen
            btnFreeze.Enabled = Not isfrozen
            If isfrozen Then
                GridView1.BackImageUrl = "~/_assets/img/Frozen.JPG"
            Else
                GridView1.BackImageUrl = ""
            End If
        Else
            GridView1.DataSource = Nothing
            GridView1.DataBind()
        End If
        
        
    End Sub
#End Region
#Region "Support Function"
    Private Sub SaveMetricsDetails()
        Dim db As New DBAccess("CRM")
        Dim gridrow As GridViewRow
        db.BeginTrans()
        Dim txtTarget As TextBox, txtAchievement As TextBox

        Try
            db.slDataAdd("processid", CboProcess.SelectedValue)
            db.slDataAdd("month", cboMonth.SelectedValue)
            db.slDataAdd("year", cboYear.SelectedValue)
            db.slDataAdd("CampaignId", cboCampaigns.SelectedValue)
            db.Executeproc("usp_DeleteTableFData")

            For Each gridrow In GridView1.Rows
                txtTarget = CType(gridrow.FindControl("txtTarget"), TextBox)
                txtAchievement = CType(gridrow.FindControl("txtAchievement"), TextBox)
                ' If Not (txtTarget.Text.Trim = "" And txtAchievement.Text.Trim = "") Then


                If txtTarget.Text.Trim.ToUpper = "N/A" Or txtTarget.Text.Trim.ToUpper = "" Then
                    txtTarget.Text = -1
                End If
                If txtAchievement.Text.Trim.ToUpper = "N/A" Or txtAchievement.Text.Trim.ToUpper = "" Then
                    txtAchievement.Text = -1
                End If


                If IsNumeric(txtAchievement.Text) And IsNumeric(txtTarget.Text) Then
                    db.slDataAdd("AgentID", AgentID)
                    db.slDataAdd("ProcessID", CboProcess.SelectedValue)
                    db.slDataAdd("month", cboMonth.SelectedValue)
                    db.slDataAdd("year", cboYear.SelectedValue)
                    db.slDataAdd("MetricID", CType(gridrow.FindControl("lblMetricID"), Label).Text)
                    db.slDataAdd("Target", txtTarget.Text)
                    db.slDataAdd("Achievement", txtAchievement.Text)
                    db.slDataAdd("CampaignId", cboCampaigns.SelectedValue)
                    db.Executeproc("usp_InsertMetricsDetails")
                Else
                    AlertMessage("Achievement and Target should be numeric")
                End If

            Next
            db.CommitTrans()
            SuccessMessage("Data has been saved")
            fillgrid()
        Catch ex As Exception
            db.RollBackTrans()
            AlertMessage(ex.Message.ToString)
        Finally
            db = Nothing
        End Try
    End Sub
    Private Sub FreezeTheData()
        SaveMetricsDetails()
        Dim db As New DBAccess("CRM")
        db.slDataAdd("AgentID", AgentID)
        db.slDataAdd("ProcessID", CboProcess.SelectedValue)
        db.slDataAdd("yyyymmdd", cboYear.SelectedValue & cboMonth.SelectedValue.PadLeft(2, "0") & "01")
        db.slDataAdd("freeze", 1)
        db.slDataAdd("CampaignId", cboCampaigns.SelectedValue)
        db.Executeproc("usp_TableF_Freeze")
        db = Nothing
        SuccessMessage("Data has been freezed")
    End Sub
    Private Sub UnFreezeTheData()
        'SaveMetricsDetails()
        Dim db As New DBAccess("CRM")
        db.slDataAdd("AgentID", AgentID)
        db.slDataAdd("ProcessID", CboProcess.SelectedValue)
        db.slDataAdd("yyyymmdd", cboYear.SelectedValue & cboMonth.SelectedValue.PadLeft(2, "0") & "01")
        db.slDataAdd("freeze", 0)
        db.slDataAdd("CampaignId", cboCampaigns.SelectedValue)
        db.Executeproc("usp_TableF_Freeze")
        db = Nothing
        SuccessMessage("Data has been unfreezed")
    End Sub
#End Region
#Region "Event"
    Protected Sub btnsave_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnsave.Click
        SaveMetricsDetails()
    End Sub
    Protected Sub btnFreeze_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnFreeze.Click
        FreezeTheData()
        fillgrid()
    End Sub
    Protected Sub btnUnFreeze_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnUnFreeze.Click
        UnFreezeTheData()
        fillgrid()
    End Sub
    Protected Sub btnRefresh_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnRefresh.Click
        fillgrid()
    End Sub
    Protected Sub CboProcess_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles CboProcess.SelectedIndexChanged
        FillCampaigns()
        fillgrid()
    End Sub
    Protected Sub cboCampaigns_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboCampaigns.SelectedIndexChanged
        fillgrid()
    End Sub
    Protected Sub cboMonth_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboMonth.SelectedIndexChanged
        fillgrid()
    End Sub
    Protected Sub cboYear_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboYear.SelectedIndexChanged
        fillgrid()
    End Sub
    Protected Sub imgfav_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles imgfav.Click
        Common.AddToFav(AgentID, "Fill Metrics")
        SuccessMessage("Fill Metrics has been added to your favourite list")
        fillgrid()
    End Sub
#End Region
#Region "grid ops"
    Protected Sub GridView1_RowDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles GridView1.RowDataBound
        For Each row As GridViewRow In GridView1.Rows
            Dim txttarget1 As TextBox = CType(row.FindControl("txttarget"), TextBox)
            If IsAdmin Then
                txttarget1.ReadOnly = False
            Else
                txttarget1.ReadOnly = True
            End If
        Next
    End Sub
#End Region
#Region "Utility"

    Private Sub AlertMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMFail"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub

    Private Sub SuccessMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMSuccess"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub
    Public Overrides Sub VerifyRenderingInServerForm(ByVal Control As Control)

    End Sub
#End Region

    
    
End Class
