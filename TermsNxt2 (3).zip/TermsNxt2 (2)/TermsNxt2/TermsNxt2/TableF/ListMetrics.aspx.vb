﻿Imports com.nss.DBAccess
Imports System.Data
Partial Class TableF_ListMetrics
    Inherits System.Web.UI.Page
#Region "Properties"
    Property CampaignID() As Integer
        Get
            Return 0 'ViewState("CampaignID")
        End Get
        Set(ByVal value As Integer)
            'ViewState("CampaignID") = value
            'Session("CampaignID") = value
        End Set
    End Property

    Property AgentID() As String
        Get
            Return ViewState("AgentID")
        End Get
        Set(ByVal value As String)
            ViewState("AgentID") = value
        End Set
    End Property
    Property EditMode() As Boolean
        Get
            Return ViewState("Mode")
        End Get
        Set(ByVal value As Boolean)
            ViewState("Mode") = value
        End Set
    End Property

    Property KCRPID() As String
        Get
            Return ViewState("KCRPID")
        End Get
        Set(ByVal value As String)
            ViewState("KCRPID") = value
        End Set
    End Property

    Property IsAdmin() As Boolean
        Get
            Return ViewState("IsAdmin")
        End Get
        Set(ByVal value As Boolean)
            ViewState("IsAdmin") = value
        End Set
    End Property
    Property MetricID() As String
        Get
            Return ViewState("MetricID")
        End Get
        Set(ByVal value As String)
            ViewState("MetricID") = value
        End Set
    End Property
#End Region
#Region "Load"
    Private Sub FillGrid()
        Dim db As New DBAccess("CRM")
        db.slDataAdd("kcrpid", KCRPID)
        GridView1.DataSource = db.ReturnTable("usp_Get_TableF_Metrics", , True)
        GridView1.DataBind()
        db = Nothing
    End Sub
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        HumanMessage.Style.Item("visibility") = "hidden"
        If Not IsPostBack Then
            If Session("AgentID") <> "" Then
                CampaignID = Session("CampaignID")
                AgentID = Session("AgentID")
                PanelReports.Controls.Add(Common.GetMenu(Request.Url, AgentID, Request.ApplicationPath))
                KCRPID = Request.QueryString("kcrpid")
                FillGrid()
            End If
        End If
    End Sub
#End Region
#Region "Event"
    Protected Sub ImageButton1_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton1.Click
        FillGrid()
        GridViewExportUtil.Export(lblReportName.Text & ".xls", Me.GridView1)
    End Sub
    Protected Sub btnClose_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnClose.Click
        Response.Redirect("~/tablef/listkcrp.aspx")
    End Sub
    Protected Sub btnAdd_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnAdd.Click
        btnremove.Visible = False
        btnOK.Visible = True
        lblmetricid.Text = "New"
        lblkcrpid.Text = KCRPID
        txtnewmetric.Text = ""
        txtnewcspmetric.Text = ""
        txtmetricdesc.Text = ""
        ChkHigherIsBetter.Checked = False
        EditMode = False
        Dim str As String
        str = "$('#DialogBackground').height($(document).height()-10);$('#DialogBackground').width($(window).width());$('#DialogBackground').css('visibility','visible');$('#Pnlnewmetrics').css('visibility','visible');" & _
        " $('#Pnlnewmetrics').css('left',($(window).width() - $('#Pnlnewmetrics').width())/2); "
        ScriptManager.RegisterStartupScript(Page, Page.GetType(), "Movedialog", str, True)
    End Sub
    Protected Sub btnOK_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnOK.Click
        Dim db As New DBAccess("crm")
        db.slDataAdd("KCRPID", lblkcrpid.Text)
        db.slDataAdd("MetricName", txtnewmetric.Text)
        db.slDataAdd("CSPMetric", txtnewcspmetric.Text)
        db.slDataAdd("MetricDescription", txtmetricdesc.Text)
        db.slDataAdd("HigherIsBetter", ChkHigherIsBetter.Checked)
        If EditMode Then
            db.UpdateinTable("tbl_Config_Tablef_Metrics", " MetricID=" & MetricID)
            SuccessMessage("Metric " & txtnewmetric.Text & " has been updated")
        Else
            db.InsertinTable("tbl_Config_Tablef_Metrics")
            SuccessMessage("New Metrics has been added")
        End If
        db = Nothing
        FillGrid()
    End Sub
    Protected Sub btnremove_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnremove.Click
        Dim db As New DBAccess("CRM")
        db.slDataAdd("Active", 0)
        db.UpdateinTable("tbl_Config_Tablef_Metrics", " MetricID=" & lblmetricid.Text)
        db = Nothing
        SuccessMessage("Metric " & txtnewmetric.Text & " has been deleted")
        FillGrid()
    End Sub
#End Region
#Region "grid ops"
    Protected Sub GridView1_RowCommand(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewCommandEventArgs) Handles GridView1.RowCommand
        If e.CommandName = "change" Then
            btnremove.Visible = False
            btnOK.Visible = True
            MetricID = e.CommandArgument
            Dim db As New DBAccess("crm")
            db.slDataAdd("kcrpid", KCRPID)
            Dim dr As DataRow = db.ReturnRow("select * from tbl_Config_Tablef_Metrics where MetricID=" & MetricID)
            db = Nothing
            lblmetricid.Text = MetricID
            lblkcrpid.Text = dr("KCRPID")
            txtnewmetric.Text = dr("MetricName")
            txtnewcspmetric.Text = dr("CSPMetric")
            ChkHigherIsBetter.Checked = dr("HigherIsBetter")
            txtmetricdesc.Text = dr("MetricDEscription")
            EditMode = True
            Dim str As String
            str = "$('#DialogBackground').height($(document).height()-10);$('#DialogBackground').width($(window).width());$('#DialogBackground').css('visibility','visible');$('#Pnlnewmetrics').css('visibility','visible');" & _
            " $('#Pnlnewmetrics').css('left',($(window).width() - $('#Pnlnewmetrics').width())/2); "
            ScriptManager.RegisterStartupScript(Page, Page.GetType(), "Movedialog", str, True)
        ElseIf e.CommandName = "remove" Then
            btnremove.Visible = True
            btnOK.Visible = False
            MetricID = e.CommandArgument
            Dim db As New DBAccess("crm")
            db.slDataAdd("kcrpid", KCRPID)
            Dim dr As DataRow = db.ReturnRow("select * from tbl_Config_Tablef_Metrics where MetricID=" & MetricID)
            db = Nothing
            lblkcrpid.Text = KCRPID
            lblmetricid.Text = MetricID
            txtnewmetric.Enabled = False
            txtnewcspmetric.Enabled = False
            txtmetricdesc.Enabled = False
            ChkHigherIsBetter.Enabled = False
            lblkcrpid.Text = dr("KCRPID")
            txtnewmetric.Text = dr("MetricName")
            txtnewcspmetric.Text = dr("CSPMetric")
            ChkHigherIsBetter.Checked = dr("HigherIsBetter")
            txtmetricdesc.Text = dr("MetricDEscription")
            EditMode = True
            Dim str As String
            str = "$('#DialogBackground').height($(document).height()-10);$('#DialogBackground').width($(window).width());$('#DialogBackground').css('visibility','visible');$('#Pnlnewmetrics').css('visibility','visible');" & _
            " $('#Pnlnewmetrics').css('left',($(window).width() - $('#Pnlnewmetrics').width())/2); "
            ScriptManager.RegisterStartupScript(Page, Page.GetType(), "Movedialog", str, True)
        End If
    End Sub
#End Region
#Region "--- Utility ---"

    Private Sub AlertMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMFail"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub

    Private Sub SuccessMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMSuccess"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub
#End Region

   
End Class
