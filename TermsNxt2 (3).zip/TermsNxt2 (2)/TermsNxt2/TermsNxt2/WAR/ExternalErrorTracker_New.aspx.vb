﻿Imports com.nss.DBAccess
Imports System.Data
Imports System.Text
Imports System.Globalization
Imports System.Web.Services
Imports System.Linq
Imports System.Web.Script.Serialization
Partial Class WAR_ExternalErrorTracker_New
    Inherits System.Web.UI.Page



#Region "Properties"

    Property AgentID() As String
        Get
            Return ViewState("AgentID")
        End Get
        Set(ByVal value As String)
            ViewState("AgentID") = value
        End Set
    End Property

    Property CampaignID() As String
        Get
            Return ViewState("CampaignID")
        End Get
        Set(ByVal value As String)
            ViewState("CampaignID") = value
        End Set
    End Property

    Property ErrorId() As String
        Get
            Return ViewState("ErrorId")
        End Get
        Set(ByVal value As String)
            ViewState("ErrorId") = value
        End Set
    End Property

#End Region


#Region "Page Load"

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        HumanMessage.Style.Item("visibility") = "hidden"
        Try
            If Not IsPostBack Then
                If Session("AgentID") <> "" Then
                    AgentID = Session("AgentID")
                    CampaignID = Session("CampaignID")
                    PanelReports.Controls.Add(Common.GetMenu(Request.Url, AgentID, Request.ApplicationPath))
                    Common.FillProcesses(cboProcess, AgentID)
             
                End If
            End If

        Catch ex As Exception
            AlertMessage(ex.Message)
        End Try

    End Sub

#End Region

#Region "Functions"

    

    

    Private Sub OpenDialog()

        Dim str As String
        str = "$('#DialogBackground').height($(document).height()-5);$('#DialogBackground').width($(window).width());$('#DialogBackground').css('visibility','visible');$('#PanelExternalError').css('visibility','visible');" & _
        " $('#PanelExternalError').css('left',($(window).width() - $('#PanelExternalError').width())/2); "
        ScriptManager.RegisterStartupScript(Page, Page.GetType(), "Movedialog", str, True)
    End Sub

    Private Sub FillProcess()
        Try
            Common.FillProcesses(cboProcess, AgentID)
            Dim db As New DBAccess
            db.slDataAdd("Agentid", AgentID)
            cboProcess.SelectedValue = db.ReturnRow("usp_getAgentProcess", True)(4)
            db = Nothing
        Catch ex As Exception
            Throw ex
        End Try
    End Sub

#End Region



#Region "Utility"

    Private Sub AlertMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMFail"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub

    Private Sub SuccessMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMSuccess"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub
    Public Overrides Sub VerifyRenderingInServerForm(ByVal Control As Control)

    End Sub
#End Region



End Class
