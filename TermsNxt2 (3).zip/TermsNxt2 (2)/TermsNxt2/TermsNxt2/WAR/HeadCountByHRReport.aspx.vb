﻿Imports com.nss.DBAccess
Imports System.Data
Imports System.Data.SqlClient
Imports System.Web.UI.WebControls
Imports System.Web.UI.WebControls.GridView
Imports System.Windows.Forms
Imports System.Data.OleDb
Imports System.IO
Partial Class WSR_HeadCountByHRReport
    Inherits System.Web.UI.Page

#Region "--- Properties ---"
    Property CurrentDate() As Date
        Get
            Return ViewState("CurrentDate")
        End Get
        Set(ByVal value As Date)
            ViewState("CurrentDate") = value
        End Set
    End Property
    Property SupervisorID() As String
        Get
            Return ViewState("SupervisorID")
        End Get
        Set(ByVal value As String)
            ViewState("SupervisorID") = value
        End Set
    End Property
    Property UserID() As String
        Get
            Return ViewState("UserID")
        End Get
        Set(ByVal value As String)
            ViewState("UserID") = value
        End Set
    End Property
    Property AgentID() As String
        Get
            Return ViewState("AgentID")
        End Get
        Set(ByVal value As String)
            ViewState("AgentID") = value
        End Set
    End Property
    Property UserName() As String
        Get
            Return ViewState("username")
        End Get
        Set(ByVal value As String)
            ViewState("username") = value
        End Set
    End Property
    Property ProcessID() As Integer
        Get
            Return ViewState("ProcessID")
        End Get
        Set(ByVal value As Integer)
            ViewState("ProcessID") = value
            Session("ProcessID") = value
        End Set
    End Property
    Property ProcessName() As String
        Get
            Return ViewState("ProcessName")
        End Get
        Set(ByVal value As String)
            ViewState("ProcessName") = value
        End Set
    End Property
#End Region

#Region "--- Load ---"
    Private Sub LoadData()
        AgentID = Session("Agentid")
        Dim CurrMonday As DateTime = Today.AddDays((Today.DayOfWeek - DayOfWeek.Monday) * -1).ToString("dd-MMM-yyyy")
        ucDateFrom.value = CurrMonday
        ' Common.FillProcesses(cboProcess, AgentID)
        'GetHeadCountList(Now.Date, 0)
        'GetDateValidation()
    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        HumanMessage.Style.Item("visibility") = "hidden"
        If Not Me.IsPostBack Then
            'Button2.Attributes.Add("onClick", "javascript:history.back(); return false;")
            LoadData()
            PanelReports.Controls.Add(Common.GetMenu(Request.Url, AgentID, Request.ApplicationPath))
            lblReportName.CurrentPage = " Head Count "
        End If
    End Sub
#End Region

#Region "--- Utility ---"
    Private Sub AlertMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMFail"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub

    Private Sub SuccessMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMSuccess"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub

    Protected Sub HumanMsgbtn_Click(sender As Object, e As EventArgs) Handles HumanMsgBtn.Click
        HumanMessage.Style.Item("visibility") = "hidden"
    End Sub


#End Region

#Region "--- Function ---"
    Public Sub GetReport()
        Dim db As New DBAccess("CRM")
        db.slDataAdd("startDateOfWeek", ucDateFrom.yyyymmdd)
        Dim dt As DataTable
        dt = db.ReturnTable("USP_WSR_GET_HeadCountByHR", , True)
        db = Nothing
        HeadCountReport.DataSource = Nothing
        If dt.Rows.Count > 0 Then
            HeadCountReport.DataSource = dt
        End If
        HeadCountReport.DataBind()
    End Sub
#End Region

    Protected Sub ucDateFrom_Changed(sender As Object, e As EventArgs) Handles ucDateFrom.Changed
        Dim startdayofweek = ucDateFrom.value
        If (startdayofweek.DayOfWeek = 1) Then
            GetReport()

        Else
            Dim CurrMonday As DateTime = Today.AddDays((Today.DayOfWeek - DayOfWeek.Monday) * -1).ToString("dd-MMM-yyyy")
            ucDateFrom.value = CurrMonday
            AlertMessage("Please Select Monday As Start Day Of Week Only")
        End If

    End Sub


    Protected Sub ImageButton1_Click(sender As Object, e As ImageClickEventArgs) Handles ImageButton1.Click
        GridViewExportUtil.Export(lblReportName.CurrentPage & ".xls", Me.HeadCountReport)
    End Sub

    Protected Sub imgfav_Click(sender As Object, e As ImageClickEventArgs) Handles imgfav.Click
        Common.AddToFav(AgentID, "Head Countb By HR Report")
        SuccessMessage("Report has been added to your favorite list")
    End Sub
End Class
