﻿Imports com.nss.DBAccess
Imports System.Data
Imports System.Text
Imports System.Globalization
Imports System.Web.Services
Partial Class WSR_ApproveRejectUYSSuccessStories
    Inherits System.Web.UI.Page

#Region "Properties"

    Property AgentID() As String
        Get
            Return ViewState("AgentID")
        End Get
        Set(ByVal value As String)
            ViewState("AgentID") = value
        End Set
    End Property
    Property StoryID() As String
        Get
            Return ViewState("StoryID")
        End Get
        Set(ByVal value As String)
            ViewState("StoryID") = value
        End Set
    End Property

    Property IsSup() As Boolean
        Get
            Return ViewState("IsSup")
        End Get
        Set(ByVal value As Boolean)
            ViewState("IsSup") = value
        End Set
    End Property

    Property IsHR() As Boolean
        Get
            Return ViewState("IsHR")
        End Get
        Set(ByVal value As Boolean)
            ViewState("IsHR") = value
        End Set
    End Property

    Property IsMgr() As Boolean
        Get
            Return ViewState("IsMgr")
        End Get
        Set(ByVal value As Boolean)
            ViewState("IsMgr") = value
        End Set
    End Property
    Property Flag() As String
        Get
            Return ViewState("Flag")
        End Get
        Set(ByVal value As String)
            ViewState("Flag") = value
        End Set
    End Property

    Property strCC() As String
        Get
            Return ViewState("strCC")
        End Get
        Set(ByVal value As String)
            ViewState("strCC") = value
        End Set
    End Property


#End Region

#Region "Page Load"
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        HumanMessage.Style.Item("visibility") = "hidden"
        Try
            If Not IsPostBack Then
                AgentID = Session("Agentid")
                lblReportName.CurrentPage = "Approve/Reject UYS Success Stories"
                Common.FillProcesses(cboProcess, AgentID)
                BindStatus()
                PanelReports.Controls.Add(Common.GetMenu(Request.Url, AgentID, Request.ApplicationPath))
                'If Request.QueryString("Type") IsNot Nothing Then
                '    Type = Request.QueryString("Type")
                'Else
                '    Type = 0
                'End If
                GetUYSTrackerData(Today)
            Else
                GetUYSTrackerData(dpSelectDate.yyyymmdd)
            End If

        Catch ex As Exception
            AlertMessage(ex.Message)
        End Try

    End Sub
#End Region

#Region "Functions"

    Private Sub FillProcess()
        Try
            Common.FillProcesses(CboProcess, AgentID)
            Dim db As New DBAccess
            db.slDataAdd("Agentid", AgentID)
            If Request.QueryString("PID") IsNot Nothing Then
                cboProcess.SelectedValue = Request.QueryString("PID")
            Else
                cboProcess.SelectedValue = db.ReturnRow("usp_getAgentProcess", True)(4)
            End If
            db = Nothing
        Catch ex As Exception
            Throw ex
        End Try
    End Sub

    Private Sub BindStatus()
        Try
            Dim dt As New DataTable
            Dim db As New DBAccess("CRM")
            db.slDataAdd("KPAID", 29)
            db.slDataAdd("ProcessID", cboProcess.SelectedValue)
            dt = db.ReturnTable("usp_WSR_getStatus_fromKPA", , True)
            db = Nothing
            If dt.Rows.Count > 0 Then
                ddlStatus.DataTextField = "StatusText"
                ddlStatus.DataValueField = "StatusID"
                ddlStatus.DataSource = dt.Select("StatusID in ('24','25')").CopyToDataTable()
                ddlStatus.DataBind()
                ddlStatus.Items.Insert(0, New ListItem("--select--", "0"))
                ddlStatus.SelectedIndex = 0
            End If
        Catch ex As Exception
            Throw ex
        End Try
    End Sub

    Private Sub GetUYSTrackerData(ByVal date1 As String)
        Dim db As DBAccess
        Try
            db = New DBAccess("CRM")
            db.slDataAdd("agentID", AgentID)
            Dim ds As DataSet = db.ReturnDataset("[USP_GET_AgentRole]", True)
            
            IsSup = ds.Tables(0).Rows(0).Item("IsSupervisor")
            IsMgr = ds.Tables(0).Rows(0).Item("IsManager")
            IsHR = ds.Tables(0).Rows(0).Item("IsHR")
            If IsSup = True Or IsMgr = True Then
                Flag = 1
            ElseIf IsHR = True Then
                Flag = 2
            Else
                Flag = 0
                Response.Redirect("~/Unauthorized.htm")
            End If
            Dim dt As DataTable = New DataTable
            db = New DBAccess("CRM")
            db.slDataAdd("ProcessId", cboProcess.SelectedItem.Value)
            db.slDataAdd("flag", Flag)
            db.slDataAdd("Date", date1)
            dt = db.ReturnTable("[USP_WSR_GET_UYSTrackerData]", , True)
            db = Nothing
            gvUYSTracker.DataSource = dt
            gvUYSTracker.DataBind()

            If gvUYSTracker.Rows.Count > 0 Then
                pnlStatus.Visible = True
            Else
                pnlStatus.Visible = False
            End If


        Catch ex As Exception
            Throw ex
        End Try
    End Sub

    Private Sub Approve()
        Dim Flag As Boolean = False

        For Each row As GridViewRow In gvUYSTracker.Rows
            If row.RowType = DataControlRowType.DataRow Then
                Dim chkRow As CheckBox = TryCast(row.Cells(0).FindControl("CheckBox1"), CheckBox)
                If chkRow.Checked Then
                    Flag = True
                    Exit For
                End If
            End If
        Next
        If Flag = False Then
            AlertMessage("Select Story to Approve/Reject")
            Exit Sub
        End If
        Try
            Dim dt As DataTable = New DataTable
            If IsSup = True Or IsMgr = True Then
                Dim db As DBAccess
                Dim dtVH As DataTable
                Dim dtCC As DataTable
                Dim strTo As String
                db = New DBAccess("CRM")
                db.slDataAdd("ProcessID", cboProcess.SelectedValue.ToString)
                dtCC = db.ReturnTable("usp_GetManagerProcessWise", , True)
                db = Nothing
                db = New DBAccess("CRM")
                db.slDataAdd("Agentid", AgentID)
                db.slDataAdd("Flag", 1)
                dtVH = db.ReturnTable("usp_SupervisorEmails", , True)
                db = Nothing
                If dtVH.Rows.Count > 0 And dtCC.Rows.Count > 0 Then
                    strTo = dtVH.Rows(0).Item("MailTo")
                    strTo = strTo.Replace("Transporthelpdesk@NIITSMARTSERVE.com", "").Replace(",", "")

                    For i As Integer = 0 To dtCC.Rows.Count - 1
                        strCC &= dtCC.Rows(i).Item("EmailId") + ","
                    Next
                    strCC = strCC.Substring(0, strCC.Length - 1)  '' To remove the last Comma
                    'Dim mailCC As String = strTo + "," + strCC
                    Dim objWSMail As New ServiceReference2.MailSoapClient
                    Dim strFrom As String = System.Configuration.ConfigurationManager.AppSettings("FROM")
                    Dim MailSubject As String = "UYS Success Stories Approved"
                    Dim strMailBody As String = ""
                    strMailBody += "<html xmlns='http://www.w3.org/1999/xhtml'>"
                    strMailBody += "<body style='font-family: Verdana; font-size: .8em'>"
                    strMailBody += "UYS Success Stories Approved By Verticle Head. Details are given below:<br /><br />"
                    strMailBody += "<table border='1' width='90%' style='border: 1px solid; border-collapse: collapse; font-family: Verdana; font-size: .8em'>"
                    strMailBody += "<tr bgcolor='#B8CCE4'>"
                    strMailBody += "<td align='center'><b>Story Sent By</b></td>"
                    strMailBody += "<td align='center'><b>Success Stories</b></td>"
                    strMailBody += "<td align='center'><b>Date</b></td>"
                    strMailBody += "<td align='center'><b>Status</b></td>"
                    strMailBody += "<td align='center'><b>Remarks</b></td>"
                    strMailBody += "</tr>"
                    For Each row As GridViewRow In gvUYSTracker.Rows
                        If row.RowType = DataControlRowType.DataRow Then
                            Dim chkRow As CheckBox = TryCast(row.Cells(0).FindControl("CheckBox1"), CheckBox)
                            If chkRow.Checked Then

                                Dim StoryID As String = TryCast(row.Cells(2).FindControl("lblStoryID"), Label).Text
                                Dim str As Date = TryCast(row.Cells(4).FindControl("gvlblDate"), Label).Text
                                Dim dt1 As Integer = Integer.Parse(str.ToString("yyyyMMdd"))

                                strMailBody += "<tr >"
                                strMailBody += "<td align='center'>" & TryCast(row.Cells(3).FindControl("gvlblSentBy"), Label).Text & "</td>"
                                strMailBody += "<td align='center'>" & TryCast(row.Cells(1).FindControl("gvlblSuccessStory"), Label).Text & "</td>"
                                strMailBody += "<td align='center'>" & TryCast(row.Cells(4).FindControl("gvlblDate"), Label).Text & "</td>"
                                strMailBody += "<td align='center'>Pending For HR Approval</td>"
                                strMailBody += "<td align='center'>" & TryCast(row.Cells(6).FindControl("gvlblRemarks"), Label).Text & "</td>"
                                strMailBody += "</tr>"

                                db = New DBAccess("CRM")
                                db.slDataAdd("StoryID", StoryID)
                                db.slDataAdd("successStory", TryCast(row.Cells(1).FindControl("gvlblSuccessStory"), Label).Text)
                                db.slDataAdd("sentBy", TryCast(row.Cells(3).FindControl("lblAgentID"), Label).Text)
                                db.slDataAdd("Date", dt1)
                                db.slDataAdd("status", ddlStatus.SelectedValue)
                                db.slDataAdd("remarks", TryCast(row.Cells(6).FindControl("gvlblRemarks"), Label).Text)
                                db.slDataAdd("CreatedBy", AgentID)
                                db.slDataAdd("UpdatedBy", AgentID)
                                db.slDataAdd("IsApprovedByVerticleHead", True)
                                db.slDataAdd("IsApprovedByHR", False)
                                db.slDataAdd("ProcessId", Convert.ToInt32(cboProcess.SelectedValue))
                                db.Executeproc("USP_WSR_SET_UYSTracker")
                                db = Nothing

                            End If
                        End If
                    Next

                    strMailBody += "</table><br />"
                    strMailBody += "<div align='left'>If you are approving authority,"
                    '  strMailBody += "<a href=http://ggn-nss-web1:7225/WSR/ApproveRejectUYSSuccessStories.aspx?PID=" & cboProcess.SelectedValue.ToString & ">Click Here To Approve/Reject</a></div>"
                    strMailBody += "<a href=http://termsmonitor.niitsmartserve.com/WSR/ApproveRejectUYSSuccessStories.aspx?PID=" & cboProcess.SelectedValue.ToString & ">Click Here To Approve/Reject</a></div>"
                    strMailBody += "<br /><br /><hr/>This mail was sent using the "
                    strMailBody += "<a href='http://termsmonitor.niitsmartserve.com/'>TermsMonitor&reg;</a> Mail Service.We request you not to reply this message."
                    strMailBody += "<br /><br />In case you wish to report issues with this mail, please send mail to mailto:helpdesk@niitsmartserve.com <br /> "
                    strMailBody += "<br />This e-mail is confidential and may also be privileged.If you are not the intended recipient, please notify helpdesk immediately; you should not copy or use it for any purpose,nor disclose its contents to any other person."
                    strMailBody += "</body>"
                    strMailBody += "</html>"
                    SuccessMessage("Approved Successfully")
                    'objWSMail.MailSend("hrops@niitsmartserve.com", strMailBody, "", strCC, "", "<" & strFrom & ">", MailSubject)
                    objWSMail.MailSend("Akanksha.Khare@NIIT-Tech.com", strMailBody, "", "Akanksha.Khare@NIIT-Tech.com", "Akanksha.Khare@NIIT-Tech.com", "<" & strFrom & ">", MailSubject)
                    objWSMail = Nothing
                    GetUYSTrackerData(dpSelectDate.yyyymmdd)
                End If
            ElseIf IsHR = True Then
                Dim db As DBAccess
                Dim dtVH As DataTable
                Dim dtCC As DataTable
                Dim strTo As String

                db = New DBAccess("CRM")
                db.slDataAdd("ProcessID", cboProcess.SelectedValue.ToString)
                dtCC = db.ReturnTable("usp_GetManagerProcessWise", , True)
                db = Nothing

                db = New DBAccess("CRM")
                db.slDataAdd("Agentid", AgentID)
                db.slDataAdd("Flag", 1)
                dtVH = db.ReturnTable("usp_SupervisorEmails", , True)
                db = Nothing
                If dtVH.Rows.Count > 0 And dtCC.Rows.Count > 0 Then
                    strTo = dtVH.Rows(0).Item("MailTo")
                    strTo = strTo.Replace("Transporthelpdesk@NIITSMARTSERVE.com", "").Replace(",", "")

                    For i As Integer = 0 To dtCC.Rows.Count - 1
                        strCC &= dtCC.Rows(i).Item("EmailId") + ","
                    Next
                    strCC = strCC.Substring(0, strCC.Length - 1)  '' To remove the last Comma
                    Dim objWSMail As New ServiceReference2.MailSoapClient
                    Dim strFrom As String = System.Configuration.ConfigurationManager.AppSettings("FROM")
                    Dim MailSubject As String = "UYS Success Stories Approved"
                    Dim strMailBody As String = ""
                    strMailBody += "<html xmlns='http://www.w3.org/1999/xhtml'>"
                    strMailBody += "<body style='font-family: Verdana; font-size: .8em'>"
                    strMailBody += "<p>MailTo:" + strTo + " MailCC: " + strCC + " From: " + strFrom + "</p><br />"
                    strMailBody += "UYS Success Stories Approved By HR. Details are given below:<br /><br />"
                    strMailBody += "<table border='1' width='90%' style='border: 1px solid; border-collapse: collapse; font-family: Verdana; font-size: .8em'>"
                    strMailBody += "<tr bgcolor='#B8CCE4'>"
                    strMailBody += "<td align='center'><b>Story Sent By</b></td>"
                    strMailBody += "<td align='center'><b>Success Stories</b></td>"
                    strMailBody += "<td align='center'><b>Date</b></td>"
                    strMailBody += "<td align='center'><b>Status</b></td>"
                    strMailBody += "<td align='center'><b>Remarks</b></td>"
                    strMailBody += "</tr>"

                    For Each row As GridViewRow In gvUYSTracker.Rows
                        If row.RowType = DataControlRowType.DataRow Then
                            Dim chkRow As CheckBox = TryCast(row.Cells(0).FindControl("CheckBox1"), CheckBox)
                            If chkRow.Checked Then

                                Dim StoryID As String = TryCast(row.Cells(2).FindControl("lblStoryID"), Label).Text
                                Dim str As Date = TryCast(row.Cells(4).FindControl("gvlblDate"), Label).Text
                                Dim dt1 As Integer = Integer.Parse(str.ToString("yyyyMMdd"))

                                strMailBody += "<tr >"
                                strMailBody += "<td align='center'>" & TryCast(row.Cells(3).FindControl("gvlblSentBy"), Label).Text & "</td>"
                                strMailBody += "<td align='center'>" & TryCast(row.Cells(1).FindControl("gvlblSuccessStory"), Label).Text & "</td>"
                                strMailBody += "<td align='center'>" & TryCast(row.Cells(4).FindControl("gvlblDate"), Label).Text & "</td>"
                                strMailBody += "<td align='center'>Approved By HR</td>"
                                strMailBody += "<td align='center'>" & TryCast(row.Cells(6).FindControl("gvlblRemarks"), Label).Text & "</td>"
                                strMailBody += "</tr>"

                                db = New DBAccess("CRM")
                                db.slDataAdd("StoryID", StoryID)
                                db.slDataAdd("successStory", TryCast(row.Cells(1).FindControl("gvlblSuccessStory"), Label).Text)
                                db.slDataAdd("sentBy", TryCast(row.Cells(3).FindControl("lblAgentID"), Label).Text)
                                db.slDataAdd("Date", dt1)
                                db.slDataAdd("status", ddlStatus.SelectedValue)
                                db.slDataAdd("remarks", TryCast(row.Cells(6).FindControl("gvlblRemarks"), Label).Text)
                                db.slDataAdd("CreatedBy", AgentID)
                                db.slDataAdd("UpdatedBy", AgentID)
                                db.slDataAdd("IsApprovedByVerticleHead", True)
                                db.slDataAdd("IsApprovedByHR", True)
                                db.slDataAdd("ProcessId", Convert.ToInt32(cboProcess.SelectedValue))
                                db.Executeproc("USP_WSR_SET_UYSTracker")
                                db = Nothing

                            End If
                        End If
                    Next
                    strMailBody += "</table><br />"
                    strMailBody += "<br /><br /><hr/>This mail was sent using the "
                    strMailBody += "<a href='http://termsmonitor.niitsmartserve.com/'>TermsMonitor&reg;</a> Mail Service.We request you not to reply this message."
                    strMailBody += "<br /><br />In case you wish to report issues with this mail, please send mail to mailto:helpdesk@niitsmartserve.com <br /> "
                    strMailBody += "<br />This e-mail is confidential and may also be privileged.If you are not the intended recipient, please notify helpdesk immediately; you should not copy or use it for any purpose,nor disclose its contents to any other person."
                    strMailBody += "</body>"
                    strMailBody += "</html>"

                    SuccessMessage("Approved Successfully")
                    'objWSMail.MailSend(strTo, strMailBody, "", strCC, "", "<" & strFrom & ">", MailSubject)
                    objWSMail.MailSend("Akanksha.Khare@NIIT-Tech.com", strMailBody, "", "Akanksha.Khare@NIIT-Tech.com", "Akanksha.Khare@NIIT-Tech.com", "<" & strFrom & ">", MailSubject)
                    objWSMail = Nothing
                    GetUYSTrackerData(dpSelectDate.yyyymmdd)
                End If
            End If
        Catch ex As Exception
            Throw ex
        End Try

    End Sub

    Private Sub Reject()

        Dim Flag As Boolean = False

        For Each row As GridViewRow In gvUYSTracker.Rows
            If row.RowType = DataControlRowType.DataRow Then
                Dim chkRow As CheckBox = TryCast(row.Cells(0).FindControl("CheckBox1"), CheckBox)
                If chkRow.Checked Then
                    Flag = True
                    Exit For
                End If
            End If
        Next
        If Flag = False Then
            AlertMessage("Select Story to Approve/Reject")
            Exit Sub
        End If
                Try
                    
            If IsSup = True Or IsMgr = True Then

                Dim db As DBAccess
                Dim dtVH As DataTable
                Dim dtCC As DataTable
                Dim strTo As String

                db = New DBAccess("CRM")
                db.slDataAdd("ProcessID", cboProcess.SelectedValue.ToString)
                dtCC = db.ReturnTable("usp_GetManagerProcessWise", , True)
                db = Nothing

                db = New DBAccess("CRM")
                db.slDataAdd("Agentid", AgentID)
                db.slDataAdd("Flag", 1)
                dtVH = db.ReturnTable("usp_SupervisorEmails", , True)
                db = Nothing
                If dtVH.Rows.Count > 0 And dtCC.Rows.Count > 0 Then
                    strTo = dtVH.Rows(0).Item("MailTo")
                    strTo = strTo.Replace("Transporthelpdesk@NIITSMARTSERVE.com", "").Replace(",", "")

                    For i As Integer = 0 To dtCC.Rows.Count - 1
                        strCC &= dtCC.Rows(i).Item("EmailId") + ","
                    Next
                    strCC = strCC.Substring(0, strCC.Length - 1)  '' To remove the last Comma
                    'Dim mailCC As String = strTo + "," + strCC
                    Dim objWSMail As ServiceReference2.MailSoapClient
                    Dim strFrom As String = System.Configuration.ConfigurationManager.AppSettings("FROM")
                    Dim MailSubject As String = "UYS Success Stories Rejected"
                    Dim strMailBody As String = ""
                    strMailBody += "<html xmlns='http://www.w3.org/1999/xhtml'>"
                    strMailBody += "<body style='font-family: Verdana; font-size: .8em'>"
                    strMailBody += "UYS Success Stories Approved By Verticle Head. Details are given below:<br /><br />"
                    strMailBody += "<table border='1' width='90%' style='border: 1px solid; border-collapse: collapse; font-family: Verdana; font-size: .8em'>"
                    strMailBody += "<tr bgcolor='#B8CCE4'>"
                    strMailBody += "<td align='center'><b>Story Sent By</b></td>"
                    strMailBody += "<td align='center'><b>Success Stories</b></td>"
                    strMailBody += "<td align='center'><b>Date</b></td>"
                    strMailBody += "<td align='center'><b>Status</b></td>"
                    strMailBody += "<td align='center'><b>Remarks</b></td>"
                    strMailBody += "</tr>"
                    For Each row As GridViewRow In gvUYSTracker.Rows
                        If row.RowType = DataControlRowType.DataRow Then
                            Dim chkRow As CheckBox = TryCast(row.Cells(0).FindControl("CheckBox1"), CheckBox)
                            If chkRow.Checked Then

                                Dim StoryID As String = TryCast(row.Cells(2).FindControl("lblStoryID"), Label).Text
                                Dim str As Date = TryCast(row.Cells(4).FindControl("gvlblDate"), Label).Text
                                Dim dt1 As Integer = Integer.Parse(str.ToString("yyyyMMdd"))

                                strMailBody += "<tr >"
                                strMailBody += "<td align='center'>" & TryCast(row.Cells(3).FindControl("gvlblSentBy"), Label).Text & "</td>"
                                strMailBody += "<td align='center'>" & TryCast(row.Cells(1).FindControl("gvlblSuccessStory"), Label).Text & "</td>"
                                strMailBody += "<td align='center'>" & TryCast(row.Cells(4).FindControl("gvlblDate"), Label).Text & "</td>"
                                strMailBody += "<td align='center'>Rejected By Verticle Head</td>"
                                strMailBody += "<td align='center'>" & TryCast(row.Cells(6).FindControl("gvlblRemarks"), Label).Text & "</td>"
                                strMailBody += "</tr>"

                                db = New DBAccess("CRM")
                                db.slDataAdd("StoryID", StoryID)
                                db.slDataAdd("successStory", TryCast(row.Cells(1).FindControl("gvlblSuccessStory"), Label).Text)
                                db.slDataAdd("sentBy", TryCast(row.Cells(3).FindControl("lblAgentID"), Label).Text)
                                db.slDataAdd("Date", dt1)
                                db.slDataAdd("status", ddlStatus.SelectedValue)
                                db.slDataAdd("remarks", TryCast(row.Cells(6).FindControl("gvlblRemarks"), Label).Text)
                                db.slDataAdd("CreatedBy", AgentID)
                                db.slDataAdd("UpdatedBy", AgentID)
                                db.slDataAdd("IsApprovedByVerticleHead", True)
                                db.slDataAdd("IsApprovedByHR", False)
                                db.slDataAdd("ProcessId", Convert.ToInt32(cboProcess.SelectedValue))
                                db.Executeproc("USP_WSR_SET_UYSTracker")
                                db = Nothing
                            End If
                        End If
                    Next
                    strMailBody += "</table><br />"

                    strMailBody += "<br /><br /><hr/>This mail was sent using the "
                    strMailBody += "<a href='http://termsmonitor.niitsmartserve.com/'>TermsMonitor&reg;</a> Mail Service.We request you not to reply this message."
                    strMailBody += "<br /><br />In case you wish to report issues with this mail, please send mail to mailto:helpdesk@niitsmartserve.com <br /> "
                    strMailBody += "<br />This e-mail is confidential and may also be privileged.If you are not the intended recipient, please notify helpdesk immediately; you should not copy or use it for any purpose,nor disclose its contents to any other person."
                    strMailBody += "</body>"
                    strMailBody += "</html>"

                    AlertMessage("Rejected")
                    GetUYSTrackerData(dpSelectDate.yyyymmdd)
                    'objWSMail.MailSend(strCC, strMailBody, "", "", "", "<" & strFrom & ">", MailSubject)
                    objWSMail.MailSend("Akanksha.Khare@NIIT-Tech.com", strMailBody, "", "Akanksha.Khare@NIIT-Tech.com", "Akanksha.Khare@NIIT-Tech.com", "<" & strFrom & ">", MailSubject)
                    objWSMail = Nothing
                End If
            ElseIf IsHR = True Then
                Dim db As DBAccess
                Dim dtVH As DataTable
                Dim dtCC As DataTable
                Dim strTo As String

                db = New DBAccess("CRM")
                db.slDataAdd("ProcessID", cboProcess.SelectedValue.ToString)
                dtCC = db.ReturnTable("usp_GetManagerProcessWise", , True)
                db = Nothing

                db = New DBAccess("CRM")
                db.slDataAdd("Agentid", AgentID)
                db.slDataAdd("Flag", 1)
                dtVH = db.ReturnTable("usp_SupervisorEmails", , True)
                db = Nothing
                If dtVH.Rows.Count > 0 And dtCC.Rows.Count > 0 Then
                    strTo = dtVH.Rows(0).Item("MailTo")
                    strTo = strTo.Replace("Transporthelpdesk@NIITSMARTSERVE.com", "").Replace(",", "")

                    For i As Integer = 0 To dtCC.Rows.Count - 1
                        strCC &= dtCC.Rows(i).Item("EmailId") + ","
                    Next
                    strCC = strCC.Substring(0, strCC.Length - 1)  '' To remove the last Comma
                    Dim objWSMail As ServiceReference2.MailSoapClient
                    Dim strFrom As String = System.Configuration.ConfigurationManager.AppSettings("FROM")
                    Dim MailSubject As String = "UYS Success Stories Rejected"
                    Dim strMailBody As String = ""
                    strMailBody += "<html xmlns='http://www.w3.org/1999/xhtml'>"
                    strMailBody += "<body style='font-family: Verdana; font-size: .8em'>"
                    strMailBody += "<p>MailTo:" + strTo + " MailCC: " + strCC + " From: " + strFrom + "</p><br />"
                    strMailBody += "UYS Success Stories Approved By HR. Details are given below:<br /><br />"
                    strMailBody += "<table border='1' width='90%' style='border: 1px solid; border-collapse: collapse; font-family: Verdana; font-size: .8em'>"
                    strMailBody += "<tr bgcolor='#B8CCE4'>"
                    strMailBody += "<td align='center'><b>Story Sent By</b></td>"
                    strMailBody += "<td align='center'><b>Success Stories</b></td>"
                    strMailBody += "<td align='center'><b>Date</b></td>"
                    strMailBody += "<td align='center'><b>Status</b></td>"
                    strMailBody += "<td align='center'><b>Remarks</b></td>"
                    strMailBody += "</tr>"
                    For Each row As GridViewRow In gvUYSTracker.Rows
                        If row.RowType = DataControlRowType.DataRow Then
                            Dim chkRow As CheckBox = TryCast(row.Cells(0).FindControl("CheckBox1"), CheckBox)
                            If chkRow.Checked Then

                                Dim StoryID As String = TryCast(row.Cells(2).FindControl("lblStoryID"), Label).Text
                                Dim str As Date = TryCast(row.Cells(4).FindControl("gvlblDate"), Label).Text
                                Dim dt1 As Integer = Integer.Parse(str.ToString("yyyyMMdd"))

                                strMailBody += "<tr >"
                                strMailBody += "<td align='center'>" & TryCast(row.Cells(3).FindControl("gvlblSentBy"), Label).Text & "</td>"
                                strMailBody += "<td align='center'>" & TryCast(row.Cells(1).FindControl("gvlblSuccessStory"), Label).Text & "</td>"
                                strMailBody += "<td align='center'>" & TryCast(row.Cells(4).FindControl("gvlblDate"), Label).Text & "</td>"
                                strMailBody += "<td align='center'>Rejected By Verticle Head</td>"
                                strMailBody += "<td align='center'>" & TryCast(row.Cells(6).FindControl("gvlblRemarks"), Label).Text & "</td>"
                                strMailBody += "</tr>"

                                db = New DBAccess("CRM")
                                db.slDataAdd("StoryID", StoryID)
                                db.slDataAdd("successStory", TryCast(row.Cells(1).FindControl("gvlblSuccessStory"), Label).Text)
                                db.slDataAdd("sentBy", TryCast(row.Cells(3).FindControl("lblAgentID"), Label).Text)
                                db.slDataAdd("Date", dt1)
                                db.slDataAdd("status", ddlStatus.SelectedValue)
                                db.slDataAdd("remarks", TryCast(row.Cells(6).FindControl("gvlblRemarks"), Label).Text)
                                db.slDataAdd("CreatedBy", AgentID)
                                db.slDataAdd("UpdatedBy", AgentID)
                                db.slDataAdd("IsApprovedByVerticleHead", True)
                                db.slDataAdd("IsApprovedByHR", False)
                                db.slDataAdd("ProcessId", Convert.ToInt32(cboProcess.SelectedValue))
                                db.Executeproc("USP_WSR_SET_UYSTracker")
                                db = Nothing

                                db = New DBAccess("CRM")
                                db.slDataAdd("StoryID", StoryID)
                                db.slDataAdd("successStory", TryCast(row.Cells(1).FindControl("gvlblSuccessStory"), Label).Text)
                                db.slDataAdd("sentBy", TryCast(row.Cells(3).FindControl("lblAgentID"), Label).Text)
                                db.slDataAdd("Date", dt1)
                                db.slDataAdd("status", ddlStatus.SelectedValue)
                                db.slDataAdd("remarks", TryCast(row.Cells(6).FindControl("gvlblRemarks"), Label).Text)
                                db.slDataAdd("CreatedBy", AgentID)
                                db.slDataAdd("UpdatedBy", AgentID)
                                db.slDataAdd("IsApprovedByVerticleHead", True)
                                db.slDataAdd("IsApprovedByHR", True)
                                db.slDataAdd("ProcessId", Convert.ToInt32(cboProcess.SelectedValue))
                                db.Executeproc("USP_WSR_SET_UYSTracker")
                                db = Nothing
                            End If
                        End If
                    Next
                    strMailBody += "</table><br />"
                    strMailBody += "<br /><br /><hr/>This mail was sent using the "
                    strMailBody += "<a href='http://termsmonitor.niitsmartserve.com/'>TermsMonitor&reg;</a> Mail Service.We request you not to reply this message."
                    strMailBody += "<br /><br />In case you wish to report issues with this mail, please send mail to mailto:helpdesk@niitsmartserve.com <br /> "
                    strMailBody += "<br />This e-mail is confidential and may also be privileged.If you are not the intended recipient, please notify helpdesk immediately; you should not copy or use it for any purpose,nor disclose its contents to any other person."
                    strMailBody += "</body>"
                    strMailBody += "</html>"

                    GetUYSTrackerData(dpSelectDate.yyyymmdd)
                    AlertMessage("Rejected")
                    'objWSMail.MailSend(strTo, strMailBody, "", strCC, "", "<" & strFrom & ">", MailSubject)
                    objWSMail.MailSend("Akanksha.Khare@NIIT-Tech.com", strMailBody, "", "Akanksha.Khare@NIIT-Tech.com", "Akanksha.Khare@NIIT-Tech.com", "<" & strFrom & ">", MailSubject)
                    objWSMail = Nothing
                End If

            End If
                Catch ex As Exception
                    Throw ex
                End Try

    End Sub

#End Region

    Protected Sub gvUYSTracker_RowDataBound(sender As Object, e As GridViewRowEventArgs) Handles gvUYSTracker.RowDataBound
        If e.Row.RowType = DataControlRowType.DataRow Then
            e.Row.Attributes.Add("onmouseover", "MouseEvents(this, event)")
            e.Row.Attributes.Add("onmouseout", "MouseEvents(this, event)")
        End If
    End Sub

#Region "Utility"

    Private Sub AlertMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMFail"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub

    Private Sub SuccessMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMSuccess"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub
    Public Overrides Sub VerifyRenderingInServerForm(ByVal Control As Control)

    End Sub
#End Region

    Protected Sub ddlStatus_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ddlStatus.SelectedIndexChanged
    End Sub

    Protected Sub btnChangeStatus_Click(sender As Object, e As EventArgs) Handles btnChangeStatus.Click
        Try
            If ddlStatus.SelectedValue = "0" Then
                AlertMessage("Select Status")
                Return
            ElseIf ddlStatus.SelectedValue = "24" Then
                Approve()
            ElseIf ddlStatus.SelectedValue = "25" Then
                Reject()
            End If
        Catch ex As Exception
            AlertMessage(ex.Message)
        End Try
    End Sub

    Protected Sub cboProcess_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboProcess.SelectedIndexChanged
        Try
            BindStatus()
        Catch ex As Exception
            AlertMessage(ex.Message)
        End Try
    End Sub
End Class
