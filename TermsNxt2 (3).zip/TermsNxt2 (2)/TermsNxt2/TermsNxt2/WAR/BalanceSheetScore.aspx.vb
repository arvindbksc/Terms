﻿Imports com.nss.DBAccess
Imports System.Data
Partial Class Staffing_EWS_FillEWS
    Inherits System.Web.UI.Page
#Region "--- Properties ---"
    Property CurrentDate() As Date
        Get
            Return ViewState("CurrentDate")
        End Get
        Set(ByVal value As Date)
            ViewState("CurrentDate") = value
        End Set
    End Property
    Property CurrentLevel() As Integer
        Get
            Return ViewState("CurrentLevel")
        End Get
        Set(ByVal value As Integer)
            ViewState("CurrentLevel") = value
        End Set
    End Property
    Property SupervisorID() As String
        Get
            Return ViewState("SupervisorID")
        End Get
        Set(ByVal value As String)
            ViewState("SupervisorID") = value
        End Set
    End Property
    Property UserID() As String
        Get
            Return ViewState("UserID")
        End Get
        Set(ByVal value As String)
            ViewState("UserID") = value
        End Set
    End Property
    Property AgentID() As String
        Get
            Return ViewState("AgentID")
        End Get
        Set(ByVal value As String)
            ViewState("AgentID") = value
        End Set
    End Property
    Property UserName() As String
        Get
            Return ViewState("username")
        End Get
        Set(ByVal value As String)
            ViewState("username") = value
        End Set
    End Property
#End Region

#Region "--- Load ---"
    Private Sub LoadData()
        Dim db As New DBAccess("CRM")
        Dim dr As DataRow = db.ReturnRow("SELECT GetDate() AS CurrentDate", False)
        CurrentDate = dr("currentDate")
        db = Nothing
        'cboMonth.SelectedValue = CurrentDate.Month
        'cboYear.SelectedValue = CurrentDate.Year
    End Sub
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        HumanMessage.Style.Item("visibility") = "hidden"
        If Not IsPostBack Then
            lblReportName.CurrentPage = "Fill EWS"
            CurrentLevel = 2
            'Session("Agentid") = "NSS12108"
            'Session("UserID") = "NSS12108"
            AgentID = Session("Agentid")
            UserID = Session("UserID")
            UserName = Session("username")
            '----------- Check Freezed Status
            LoadData()
            'If Not FreezeStatus() Then
            '    'GdEWS.Enabled = False
            '    For Each gvr As GridViewRow In GdEWS.Rows
            '        gvr.Cells(1).Enabled = True
            '        gvr.Cells(2).Enabled = False
            '        gvr.Cells(3).Enabled = False
            '        gvr.Cells(4).Enabled = False
            '        gvr.Cells(5).Enabled = False
            '        gvr.Cells(6).Enabled = False
            '    Next
            '    btsave.Enabled = False
            '    btnSubmit.Enabled = False
            'Else
            '    GdEWS.Enabled = True
            '    btsave.Enabled = True
            '    btnSubmit.Enabled = True
            'End If
            SupervisorID = AgentID
            ' FillData(SupervisorID)
            'link2.Text = UserName & "(" & AgentID & ")"
            'PanelReports.Controls.Add(Common.GetMenu(Request.Url, AgentID, Request.ApplicationPath))
            'Image3.Visible = False
            'Image4.Visible = False
            'Image5.Visible = False
            'Image6.Visible = False
            'Image7.Visible = False
            'Image8.Visible = False
        End If
    End Sub
#End Region
    Dim dt As DataTable

#Region "--- Functions ---"
    
    
   
    
    
    
    
  
#End Region
#Region "--- Events ---"
  
    
    

    

    
#End Region
#Region "--- Side Links ---"
  
#End Region

#Region "--- Utility ---"
    Private Sub AlertMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMFail"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub
    Private Sub SuccessMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMSuccess"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub

#End Region

End Class
