﻿
Partial Class WSR_Default1
    Inherits System.Web.UI.Page

End Class
