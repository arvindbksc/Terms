﻿Imports com.nss.DBAccess
Imports System.Data
Imports System.Text
Imports System.Globalization
Imports System.Web.Services
Imports System.Linq
Imports System.Web.Script.Serialization

Partial Class WAR_ExternalErrorTracker
    Inherits System.Web.UI.Page


#Region "Properties"

    Property AgentID() As String
        Get
            Return ViewState("AgentID")
        End Get
        Set(ByVal value As String)
            ViewState("AgentID") = value
        End Set
    End Property

    Property CampaignID() As String
        Get
            Return ViewState("CampaignID")
        End Get
        Set(ByVal value As String)
            ViewState("CampaignID") = value
        End Set
    End Property

    Property ErrorId() As String
        Get
            Return ViewState("ErrorId")
        End Get
        Set(ByVal value As String)
            ViewState("ErrorId") = value
        End Set
    End Property

#End Region


#Region "Page Load"

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        HumanMessage.Style.Item("visibility") = "hidden"
        Try
            If Not IsPostBack Then
                If Session("AgentID") <> "" Then
                    AgentID = Session("AgentID")
                    CampaignID = Session("CampaignID")
                    PanelReports.Controls.Add(Common.GetMenu(Request.Url, AgentID, Request.ApplicationPath))
                    Common.FillProcesses(cboProcess, AgentID)
                    ResetFields()
                    BindAgents()
                    BindStatus()
                    lblMonthYear.Text = MonthName(Month(Date.Parse(Today)), True) & " " & Year(Date.Parse(Today))
                    GetComplaintData(Today)
                End If
            Else
                GetComplaintData(dpSelectDate.yyyymmdd)
            End If

        Catch ex As Exception
            AlertMessage(ex.Message)
        End Try

    End Sub

#End Region

#Region "Functions"

    Private Sub BindAgents()
        Try
            Dim dt As New DataTable
            Dim db As New DBAccess("Report")
            db.slDataAdd("processid", cboProcess.SelectedValue)
            db.slDataAdd("groupby", 3)
            dt = db.ReturnTable("usp_GetProcessAgents", , True)
            db = Nothing
            ddlAgent.DataTextField = "Agent Name"
            ddlAgent.DataValueField = "AgentID"
            ddlAgent.DataSource = dt
            ddlAgent.DataBind()
            ddlAgent.Items.Insert(0, New ListItem("--select--", "0"))
            ddlAgent.SelectedIndex = 0
        Catch ex As Exception
            Throw ex
        End Try


    End Sub

    Private Sub BindStatus()
        Try
            Dim dt As New DataTable
            Dim db As New DBAccess("CRM")
            db.slDataAdd("KPAID", 31)
            db.slDataAdd("ProcessID", cboProcess.SelectedValue)
            dt = db.ReturnTable("usp_WSR_getStatus_fromKPA", , True)
            db = Nothing
            If dt.Rows.Count > 0 Then
                If cboProcess.SelectedValue = 106 Then
                    ddlAcceptance.DataTextField = "StatusText"
                    ddlAcceptance.DataValueField = "StatusID"
                    ddlAcceptance.DataSource = dt.Select("StatusID in ('30','31')").CopyToDataTable()
                    ddlAcceptance.DataBind()
                    ddlAcceptance.Items.Insert(0, New ListItem("--select--", "0"))
                    ddlAcceptance.SelectedIndex = 0
                    ddlStatus.DataTextField = "StatusText"
                    ddlStatus.DataValueField = "StatusID"
                    ddlStatus.DataSource = dt.Select("StatusID in ('13','14')").CopyToDataTable()
                    ddlStatus.DataBind()
                    ddlStatus.Items.Insert(0, New ListItem("--select--", "0"))
                    ddlStatus.SelectedIndex = 0
                    ddlQCed.DataTextField = "StatusText"
                    ddlQCed.DataValueField = "StatusID"
                    ddlQCed.DataSource = dt.Select("StatusID in ('15','16')").CopyToDataTable()
                    ddlQCed.DataBind()
                    ddlQCed.Items.Insert(0, New ListItem("--select--", "0"))
                    ddlQCed.SelectedIndex = 0
                ElseIf cboProcess.SelectedValue = 101 Then
                    ddlStatus.DataTextField = "StatusText"
                    ddlStatus.DataValueField = "StatusID"
                    ddlStatus.DataSource = dt.Select("StatusID in ('13','14')").CopyToDataTable()
                    ddlStatus.DataBind()
                    ddlStatus.Items.Insert(0, New ListItem("--select--", "0"))
                    ddlStatus.SelectedIndex = 0
                End If

              
            End If
        Catch ex As Exception
            Throw ex
        End Try
    End Sub

    Private Sub OpenDialog()

        Dim str As String
        str = "$('#DialogBackground').height($(document).height()-5);$('#DialogBackground').width($(window).width());$('#DialogBackground').css('visibility','visible');$('#PanelExternalError').css('visibility','visible');" & _
        " $('#PanelExternalError').css('left',($(window).width() - $('#PanelExternalError').width())/2); "
        ScriptManager.RegisterStartupScript(Page, Page.GetType(), "Movedialog", str, True)
    End Sub

    Private Sub FillProcess()
        Try
            Common.FillProcesses(cboProcess, AgentID)
            Dim db As New DBAccess
            db.slDataAdd("Agentid", AgentID)
            cboProcess.SelectedValue = db.ReturnRow("usp_getAgentProcess", True)(4)
            db = Nothing
        Catch ex As Exception
            Throw ex
        End Try
    End Sub

    Private Sub GetComplaintData(ByVal DOC As String)
        Dim db As New DBAccess("CRM")
        Try
            Dim dt As DataTable = New DataTable
            db.slDataAdd("ProcessId", cboProcess.SelectedItem.Value)
            db.slDataAdd("ComplaintDate", DOC)
            dt = db.ReturnTable("USP_WSR_GET_ExternalErrorTrackerData", , True)
            db = Nothing
            If dt.Rows.Count > 0 Then
                btnAddNew.Visible = False
            Else
                btnAddNew.Visible = True
            End If
            If cboProcess.SelectedValue = 106 Then
                ResetFields()
                gvExternalComplaints.DataSource = dt
                gvExternalComplaints.DataBind()
            Else
                ResetFields()
                gvExternalComplaintsOAG.DataSource = dt
                gvExternalComplaintsOAG.DataBind()
            End If
            Common.hideDeleteOption(gvExternalComplaints)
        Catch ex As Exception
            Throw ex
        End Try
    End Sub

    Public Function InsertDetails() As String
        Dim db As DBAccess
        Dim HotelName, TransType, accpt, Sevrty, impact, Qced As String
        If Convert.ToInt32(cboProcess.SelectedValue) = 101 Then
            HotelName = txtCorrectiveAction.Text.Trim
            TransType = txtTransactionType.Text.Trim
            accpt = 0
            Sevrty = 0
            impact = txtImpact.Text.Trim
            Qced = 0
        Else
            HotelName = txtHotelName.Text.Trim
            TransType = txtRegnMgr.Text.Trim
            accpt = ddlAcceptance.SelectedValue
            Sevrty = ddlSeverity.SelectedItem.Text
            impact = txtResponse.Text.Trim
            Qced = ddlQCed.SelectedValue
        End If

        Try
            Dim msg As String = ""
            db = New DBAccess("CRM")
            db.slDataAdd("ID", ErrorId)
            db.slDataAdd("ProcessId", Convert.ToInt32(cboProcess.SelectedValue))
            db.slDataAdd("HotelName", HotelName)
            db.slDataAdd("Description", txtDescription.Text.Trim)
            db.slDataAdd("ComplaintDate", dpReportDate.yyyymmdd)
            db.slDataAdd("Month", lblMonthYear.Text.Trim)
            db.slDataAdd("RegionManager", TransType)
            db.slDataAdd("Acceptance", accpt)
            db.slDataAdd("Severity", Sevrty)
            db.slDataAdd("Response", impact)
            db.slDataAdd("ResponseDate", dpResponseDate.yyyymmdd)
            db.slDataAdd("Status", ddlStatus.SelectedValue)
            db.slDataAdd("FilledBy", AgentID)
            db.slDataAdd("LoadingDate", dpLoadingDate.yyyymmdd)
            db.slDataAdd("LoaderName", ddlAgent.SelectedValue)
            db.slDataAdd("Financial", txtFinancial.Text.Trim)
            db.slDataAdd("QCed", Qced)
            Dim result As DataTable = db.ReturnTable("USP_WSR_SET_ExternalErrorTracketData", , True)
            db = Nothing
            If result.Rows.Count > 0 Then
                For i = 1 To result.Rows.Count
                    Dim msgType = result.Rows(0).Item("MESSAGE_TYPE")
                    If msgType = "S" Then
                        SuccessMessage(result.Rows(0).Item("MESSAGE"))
                    Else
                        AlertMessage(result.Rows(0).Item("MESSAGE"))
                    End If
                Next
            End If
            Return msg
            GetComplaintData(dpSelectDate.yyyymmdd)
        Catch ex As Exception
            Throw ex
        End Try
    End Function

    Private Sub Reset()
        dpLoadingDate.value = Today
        ddlAgent.SelectedValue = 0
        dpReportDate.value = Today
        txtDescription.Text = ""
        txtRegnMgr.Text = ""
        txtHotelName.Text = ""
        txtResponse.Text = ""
        dpResponseDate.value = Today
        ddlAcceptance.SelectedValue = 0
        ddlSeverity.SelectedValue = 0
        ddlStatus.SelectedValue = 0
        ddlQCed.SelectedValue = 0
        txtFinancial.Text = ""
    End Sub

    Private Sub ResetFields()
        If cboProcess.SelectedValue = "101" Then
            gvExternalComplaintsOAG.Visible = True
            gvExternalComplaints.Visible = False
            lblMonth.Visible = False
            lblMonthYear.Visible = False
            lblLoadingDate.Text = "Issue Date:"
            dpLoadingDate.Visible = False
            dpIssueDate.Visible = True
            lblLoaderName.Text = "TM Name:"
            lblRegnMgr.Text = "Transaction Type:"
            txtRegnMgr.Visible = False
            txtTransactionType.Visible = True
            lblHotelName.Text = "Corrective Action:"
            txtHotelName.Visible = False
            txtCorrectiveAction.Visible = True
            lblResponse.Text = "Impact:"
            txtResponse.Visible = False
            txtImpact.Visible = True
            lblResponseDate.Visible = False
            dpResponseDate.Visible = False
            lblAcceptance.Visible = False
            ddlAcceptance.Visible = False
            ddlSeverity.Visible = False
            lblSeverity.Visible = False
            ddlQCed.Visible = False
            lblQCed.Visible = False
            txtFinancial.Visible = False
            lblFinancial.Visible = False
        Else
            gvExternalComplaints.Visible = True
            gvExternalComplaintsOAG.Visible = False
            lblMonth.Visible = True
            lblMonthYear.Visible = True
            lblLoadingDate.Text = "Loading Date:"
            dpLoadingDate.Visible = True
            dpIssueDate.Visible = False
            lblLoaderName.Text = "Loader Name:"
            lblRegnMgr.Text = "Region Manager:"
            txtRegnMgr.Visible = True
            txtTransactionType.Visible = False
            lblHotelName.Text = "Hotel Name:"
            txtHotelName.Visible = True
            txtCorrectiveAction.Visible = False
            lblResponse.Text = "Response:"
            txtResponse.Visible = True
            txtImpact.Visible = False
            lblResponseDate.Visible = True
            dpResponseDate.Visible = True
            lblAcceptance.Visible = True
            ddlAcceptance.Visible = True
            ddlSeverity.Visible = True
            lblSeverity.Visible = True
            ddlQCed.Visible = True
            lblQCed.Visible = True
            txtFinancial.Visible = True
            lblFinancial.Visible = True
        End If
    End Sub

#End Region

#Region "Events"

    Protected Sub btnSave_Click(sender As Object, e As EventArgs) Handles btnSave.Click
        Try
            Dim msg As String = ""
            If btnSave.Text = "Save" Then
                msg = InsertDetails()
                'SuccessMessage(msg)
                GetComplaintData(dpSelectDate.yyyymmdd)
            Else
                msg = InsertDetails()
                'SuccessMessage(msg)
                GetComplaintData(dpSelectDate.yyyymmdd)
            End If
        Catch ex As Exception
            AlertMessage(ex.Message)
        End Try
    End Sub

    Protected Sub gvExternalComplaints_RowCancelingEdit(sender As Object, e As GridViewCancelEditEventArgs) Handles gvExternalComplaints.RowCancelingEdit

    End Sub

    Protected Sub gvExternalComplaints_RowCommand(sender As Object, e As GridViewCommandEventArgs) Handles gvExternalComplaints.RowCommand
        Try
            If e.CommandName.ToLower = "addnew" Then
                ResetFields()
                ErrorId = String.Empty
                Reset()
                lblHeader.Text = "Add New External Error"
                btnSave.Text = "Save"
                OpenDialog()

            ElseIf e.CommandName.ToLower = "edit" Then

                btnSave.Text = "Update"
                Dim index As Integer = Convert.ToInt32(e.CommandArgument)
                ErrorId = CType(gvExternalComplaints.Rows(index).FindControl("hdnComplaintID"), Label).Text
                lblHeader.Text = "Update External Error For ErrorID:- " & CType(gvExternalComplaints.Rows(index).FindControl("hdnComplaintID"), Label).Text & ""
                dpLoadingDate.value = CType(gvExternalComplaints.Rows(index).FindControl("gvlblLoadingDate"), Label).Text
                ddlAgent.SelectedValue = CType(gvExternalComplaints.Rows(index).FindControl("gvhdnLoaderId"), HiddenField).Value
                dpReportDate.value = CType(gvExternalComplaints.Rows(index).FindControl("lblComplaintDate"), Label).Text
                txtDescription.Text = CType(gvExternalComplaints.Rows(index).FindControl("gvlblDescription"), Label).Text
                txtCorrectiveAction.Text = CType(gvExternalComplaints.Rows(index).FindControl("gvlblDescription"), Label).Text
                txtTransactionType.Text = CType(gvExternalComplaints.Rows(index).FindControl("gvlblDescription"), Label).Text
                txtRegnMgr.Text = CType(gvExternalComplaints.Rows(index).FindControl("gvlblRegionManager"), Label).Text
                txtHotelName.Text = CType(gvExternalComplaints.Rows(index).FindControl("gvlblHotelName"), Label).Text
                txtResponse.Text = CType(gvExternalComplaints.Rows(index).FindControl("gvlblResponse"), Label).Text
                dpReportDate.value = CType(gvExternalComplaints.Rows(index).FindControl("gvlblResponseDate"), Label).Text
                ddlAcceptance.SelectedValue = CType(gvExternalComplaints.Rows(index).FindControl("gvhdnAcceptanceId"), HiddenField).Value
                ddlSeverity.SelectedValue = CType(gvExternalComplaints.Rows(index).FindControl("hdnSeverity"), HiddenField).Value
                ddlStatus.SelectedValue = CType(gvExternalComplaints.Rows(index).FindControl("gvhdnStatusId"), HiddenField).Value
                ddlQCed.SelectedValue = CType(gvExternalComplaints.Rows(index).FindControl("gvhdnQCed"), HiddenField).Value
                txtFinancial.Text = CType(gvExternalComplaints.Rows(index).FindControl("lblComplaintDate"), Label).Text
                OpenDialog()

            ElseIf e.CommandName.ToLower = "delete" Then
            End If
        Catch ex As Exception
            AlertMessage(ex.Message)
        End Try
    End Sub

    Protected Sub gvExternalComplaints_RowDeleting(sender As Object, e As GridViewDeleteEventArgs) Handles gvExternalComplaints.RowDeleting
        Try
            Dim db As DBAccess = New DBAccess("CRM")
            db.slDataAdd("ProcessID", cboProcess.SelectedValue)
            db.slDataAdd("ID", CType(gvExternalComplaints.Rows(e.RowIndex).FindControl("hdnComplaintID"), Label).Text)
            db.slDataAdd("UpdatedBy", AgentID)
            db.Executeproc("usp_WSR_DEL_ExternalErrorTracker")
            db = Nothing
            GetComplaintData(dpSelectDate.yyyymmdd)
        Catch ex As Exception
            AlertMessage(ex.Message)
        End Try
    End Sub

    Protected Sub gvExternalComplaints_RowEditing(sender As Object, e As GridViewEditEventArgs) Handles gvExternalComplaints.RowEditing

    End Sub

    Protected Sub gvExternalComplaints_RowUpdating(sender As Object, e As GridViewUpdateEventArgs) Handles gvExternalComplaints.RowUpdating

    End Sub

    Protected Sub cboProcess_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboProcess.SelectedIndexChanged
        ResetFields()
        BindAgents()
        BindStatus()
        GetComplaintData(dpSelectDate.yyyymmdd)
    End Sub

    Protected Sub dpSelectDate_Changed(sender As Object, e As EventArgs) Handles dpSelectDate.Changed
        Try
            GetComplaintData(dpSelectDate.yyyymmdd)
        Catch ex As Exception
            AlertMessage(ex.Message)
        End Try
    End Sub

    Protected Sub dpLoadingDate_Changed(sender As Object, e As EventArgs) Handles dpLoadingDate.Changed
        Try
            Dim newDate = DateTime.ParseExact(dpLoadingDate.yyyymmdd, "yyyyMMdd", CultureInfo.InvariantCulture)
            If newDate > Today Then
                lblIsValidInput.Visible = True
                lblIsValidInput.Text = "Loading Date cannot be greater than Current Date"
                dpLoadingDate.value = Today
                OpenDialog()
            Else
                lblIsValidInput.Visible = False
                lblMonthYear.Visible = True
                lblMonthYear.Text = MonthName(Month(Date.Parse(dpLoadingDate.Text)), True) & " " & Year(Date.Parse(dpLoadingDate.Text))
                OpenDialog()
            End If
        Catch ex As Exception
            AlertMessage(ex.Message)
        End Try

    End Sub

    Protected Sub ddlAcceptance_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ddlAcceptance.SelectedIndexChanged
        Try
            OpenDialog()
        Catch ex As Exception
            AlertMessage(ex.Message)
        End Try
    End Sub

    Protected Sub ddlSeverity_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ddlSeverity.SelectedIndexChanged
        Try
            OpenDialog()
        Catch ex As Exception
            AlertMessage(ex.Message)
        End Try
    End Sub

    Protected Sub ddlStatus_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ddlStatus.SelectedIndexChanged
        Try
            OpenDialog()
        Catch ex As Exception
            AlertMessage(ex.Message)
        End Try
    End Sub

    Protected Sub ddlQCed_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ddlQCed.SelectedIndexChanged
        Try
            OpenDialog()
        Catch ex As Exception
            AlertMessage(ex.Message)
        End Try
    End Sub

    Protected Sub dpReportDate_Changed(sender As Object, e As EventArgs) Handles dpReportDate.Changed
        Try
            Dim newDate = DateTime.ParseExact(dpLoadingDate.yyyymmdd, "yyyyMMdd", CultureInfo.InvariantCulture)
            If newDate > Today Then
                lblIsValidInput.Visible = True
                lblIsValidInput.Text = "Complaint Date cannot be greater than Current Date"
                dpLoadingDate.value = Today
                OpenDialog()
            Else
                lblIsValidInput.Visible = False
                OpenDialog()
            End If
        Catch ex As Exception
            AlertMessage(ex.Message)
        End Try

    End Sub

    Protected Sub dpResponseDate_Changed(sender As Object, e As EventArgs) Handles dpResponseDate.Changed
        Try
            OpenDialog()
        Catch ex As Exception
            AlertMessage(ex.Message)
        End Try
    End Sub

    Protected Sub btnAddNew_Click(sender As Object, e As EventArgs) Handles btnAddNew.Click
        ResetFields()
        ErrorId = String.Empty
        Reset()
        OpenDialog()
        lblHeader.Text = "Add New External Error"
        
    End Sub

    Protected Sub dpIssueDate_Changed(sender As Object, e As EventArgs) Handles dpIssueDate.Changed
        Try
            Dim newDate = DateTime.ParseExact(dpLoadingDate.yyyymmdd, "yyyyMMdd", CultureInfo.InvariantCulture)
            If newDate > Today Then
                lblIsValidInput.Visible = True
                lblIsValidInput.Text = "Issue Date cannot be greater than Current Date"
                dpLoadingDate.value = Today
                OpenDialog()
            Else
                lblIsValidInput.Visible = False
                OpenDialog()
            End If
        Catch ex As Exception
            AlertMessage(ex.Message)
        End Try

    End Sub

    Protected Sub gvExternalComplaintsOAG_RowCancelingEdit(sender As Object, e As GridViewCancelEditEventArgs) Handles gvExternalComplaintsOAG.RowCancelingEdit

    End Sub

    Protected Sub gvExternalComplaintsOAG_RowCommand(sender As Object, e As GridViewCommandEventArgs) Handles gvExternalComplaintsOAG.RowCommand
        Try
            If e.CommandName.ToLower = "addnew" Then
                ResetFields()
                ErrorId = String.Empty
                Reset()
                lblHeader.Text = "Add New External Error"
                btnSave.Text = "Save"
                OpenDialog()

            ElseIf e.CommandName.ToLower = "edit" Then

                btnSave.Text = "Update"
                Dim index As Integer = Convert.ToInt32(e.CommandArgument)
                ErrorId = CType(gvExternalComplaintsOAG.Rows(index).FindControl("hdnComplaintID"), Label).Text
                lblHeader.Text = "Update External Error For ErrorID:- " & CType(gvExternalComplaintsOAG.Rows(index).FindControl("hdnComplaintID"), Label).Text & ""
                dpLoadingDate.value = CType(gvExternalComplaintsOAG.Rows(index).FindControl("gvlblLoadingDate"), Label).Text
                ddlAgent.SelectedValue = CType(gvExternalComplaintsOAG.Rows(index).FindControl("gvhdnLoaderId"), HiddenField).Value
                dpReportDate.value = CType(gvExternalComplaintsOAG.Rows(index).FindControl("lblComplaintDate"), Label).Text
                txtDescription.Text = CType(gvExternalComplaintsOAG.Rows(index).FindControl("gvlblDescription"), Label).Text
                txtCorrectiveAction.Text = CType(gvExternalComplaintsOAG.Rows(index).FindControl("gvlblHotelName"), Label).Text
                txtTransactionType.Text = CType(gvExternalComplaintsOAG.Rows(index).FindControl("gvlblRegionManager"), Label).Text
                txtImpact.Text = CType(gvExternalComplaintsOAG.Rows(index).FindControl("gvlblResponse"), Label).Text
                dpReportDate.value = CType(gvExternalComplaintsOAG.Rows(index).FindControl("gvlblResponseDate"), Label).Text
                ddlStatus.SelectedValue = CType(gvExternalComplaintsOAG.Rows(index).FindControl("gvhdnStatusId"), HiddenField).Value
                OpenDialog()

            ElseIf e.CommandName.ToLower = "delete" Then
            End If
        Catch ex As Exception
            AlertMessage(ex.Message)
        End Try
    End Sub

    Protected Sub gvExternalComplaintsOAG_RowDeleting(sender As Object, e As GridViewDeleteEventArgs) Handles gvExternalComplaintsOAG.RowDeleting
        Try
            Dim db As DBAccess = New DBAccess("CRM")
            db.slDataAdd("ProcessID", cboProcess.SelectedValue)
            db.slDataAdd("ID", CType(gvExternalComplaintsOAG.Rows(e.RowIndex).FindControl("hdnComplaintID"), Label).Text)
            db.slDataAdd("UpdatedBy", AgentID)
            db.Executeproc("usp_WSR_DEL_ExternalErrorTracker")
            db = Nothing
            GetComplaintData(dpSelectDate.yyyymmdd)
        Catch ex As Exception
            AlertMessage(ex.Message)
        End Try
    End Sub

    Protected Sub gvExternalComplaintsOAG_RowEditing(sender As Object, e As GridViewEditEventArgs) Handles gvExternalComplaintsOAG.RowEditing

    End Sub

    Protected Sub gvExternalComplaintsOAG_RowUpdating(sender As Object, e As GridViewUpdateEventArgs) Handles gvExternalComplaintsOAG.RowUpdating

    End Sub

#End Region

#Region "Utility"

    Private Sub AlertMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMFail"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub

    Private Sub SuccessMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMSuccess"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub
    Public Overrides Sub VerifyRenderingInServerForm(ByVal Control As Control)

    End Sub
#End Region

   
End Class