﻿Imports com.nss.DBAccess
Imports System.Data
Imports System.Data.SqlClient
Imports System.Web.UI.WebControls
Imports System.Web.UI.WebControls.GridView
Imports System.Windows.Forms
Imports System.Data.OleDb
Imports System.IO

Partial Class WSR_HeadCount
    Inherits System.Web.UI.Page
#Region "--- Properties ---"
    Property CurrentDate() As Date
        Get
            Return ViewState("CurrentDate")
        End Get
        Set(ByVal value As Date)
            ViewState("CurrentDate") = value
        End Set
    End Property
    Property SupervisorID() As String
        Get
            Return ViewState("SupervisorID")
        End Get
        Set(ByVal value As String)
            ViewState("SupervisorID") = value
        End Set
    End Property
    Property UserID() As String
        Get
            Return ViewState("UserID")
        End Get
        Set(ByVal value As String)
            ViewState("UserID") = value
        End Set
    End Property
    Property AgentID() As String
        Get
            Return ViewState("AgentID")
        End Get
        Set(ByVal value As String)
            ViewState("AgentID") = value
        End Set
    End Property
    Property UserName() As String
        Get
            Return ViewState("username")
        End Get
        Set(ByVal value As String)
            ViewState("username") = value
        End Set
    End Property
    Property ProcessID() As Integer
        Get
            Return ViewState("ProcessID")
        End Get
        Set(ByVal value As Integer)
            ViewState("ProcessID") = value
            Session("ProcessID") = value
        End Set
    End Property
    Property ProcessName() As String
        Get
            Return ViewState("ProcessName")
        End Get
        Set(ByVal value As String)
            ViewState("ProcessName") = value
        End Set
    End Property
#End Region

#Region "--- Load ---"
    Private Sub LoadData()
        Dim db As New DBAccess("CRM")
        Dim dr As DataRow = db.ReturnRow("SELECT GetDate() AS CurrentDate", False)
        CurrentDate = dr("currentDate")
        db = Nothing

        Common.FillProcesses(cboProcess, AgentID)
        GetHeadCountList(Now.Date, 0)
        GetDateValidation()
    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        HumanMessage.Style.Item("visibility") = "hidden"
        If Not Me.IsPostBack Then
            AgentID = Session("Agentid")
            'Button2.Attributes.Add("onClick", "javascript:history.back(); return false;")
            PanelReports.Controls.Add(Common.GetMenu(Request.Url, AgentID, Request.ApplicationPath))
            lblReportName.CurrentPage = " Head Count "
            LoadData()

        End If
    End Sub
#End Region
    Dim dt As DataTable

#Region "--- Functions ---"

    Private Sub GetHeadCountList(ByRef startdate As Date, ByRef IsLastWeekData As Boolean)
        'Dim startDate As String = ucDateFrom.Text
        Try
            btnSaveHeadCount.Visible = False
            Button2.Visible = False
            btnfillprevious.Visible = False

            Dim db As New DBAccess("CRM")
            Dim dt As DataTable
            Dim ds As DataSet
            db.slDataAdd("ProcessID", cboProcess.SelectedValue)
            db.slDataAdd("startDateOfWeek", startdate)
            db.slDataAdd("IsLastWeekData", IsLastWeekData)
            ds = db.ReturnDataset("usp_WSR_GET_HeadCountProcessWise", True)
            db = Nothing
            dt = ds.Tables(0)
            Dim dt1 = ds.Tables(1)
            HeadCountGrid.DataSource = dt
            HeadCountGrid.DataBind()
            If (dt.Rows.Count > 0) Then
                btnSaveHeadCount.Visible = True
                Button2.Visible = True
                btnfillprevious.Visible = True
                If (ds.Tables.Count > 1) Then
                    If ds.Tables(1).Rows.Count > 0 Then
                        Dim dr As DataRow = ds.Tables(1).Rows(0)
                        btnSaveHeadCount.Visible = Not Convert.ToBoolean(dr("Isfreeze"))

                    End If
                End If
            End If
            ' FillRolesDDl(ddlRole, ProcessID)
        Catch ex As Exception
            '  AlertMessage(ex.ToString)
        End Try
    End Sub

    Public Sub SaveHeadCountDetail(ByVal Id As Integer, ByVal IsInProduction As Boolean, ByVal IsBillable As Boolean)
        Try
            Dim db As New DBAccess("CRM")
            db.slDataAdd("Id", Id)
            'db.slDataAdd("EmpId", EmpId)
            db.slDataAdd("IsInProduction", IsInProduction)
            db.slDataAdd("IsBillable", IsBillable)
            db.slDataAdd("MarkedBy", AgentID)
            db.Executeproc("usp_WSR_SET_HeadCountDetail")
            db = Nothing
        Catch ex As Exception

        End Try
    End Sub

    Public Sub GetDateValidation()
        Dim LastMonday As DateTime = Today.AddDays((Today.DayOfWeek - DayOfWeek.Monday) * -1 - 7)
        Dim LastFriday As DateTime = Today.AddDays((Today.DayOfWeek - DayOfWeek.Friday) * -1 - 7)

        Dim CurrMonday As DateTime = Today.AddDays((Today.DayOfWeek - DayOfWeek.Monday) * -1)
        Dim CurrFriday As DateTime = Today.AddDays((Today.DayOfWeek - DayOfWeek.Friday) * -1)


        If Today.DayOfWeek = 1 Or Today.DayOfWeek = 2 Then
            IfromDate.InnerText = LastMonday.ToString("dd-MMM-yyyy")
            IendDate.InnerText = LastFriday.ToString("dd-MMM-yyyy")
        Else
            IfromDate.InnerText = CurrMonday.ToString("dd-MMM-yyyy")
            IendDate.InnerText = CurrFriday.ToString("dd-MMM-yyyy")
        End If
       
    End Sub

#End Region
#Region "--- Events ---"

    'Protected Sub ucDateFrom_Changed(ByVal sender As Object, ByVal e As System.EventArgs) Handles ucDateFrom.Changed
    '    ' fillgrid()
    '    'CheckAccess()
    'End Sub
    'Protected Sub UcDateTo_Changed(ByVal sender As Object, ByVal e As System.EventArgs) Handles UcDateTo.Changed
    '    ' fillgrid()
    '    ' CheckAccess()
    'End Sub
    'Protected Sub CboPeriod_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles CboPeriod.SelectedIndexChanged
    '    If CboPeriod.SelectedValue = 10 Then
    '        ucDateFrom.Visible = True
    '        UcDateTo.Visible = True
    '        lblAnd.Visible = True
    '        CheckAccess()
    '        fillgrid()
    '    Else
    '        ucDateFrom.Visible = False
    '        UcDateTo.Visible = False
    '        lblAnd.Visible = False
    '        CheckAccess()
    '        fillgrid()
    '    End If
    'End Sub





#End Region
#Region "--- Side Links ---"

#End Region

#Region "--- Utility ---"
    Private Sub AlertMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMFail"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub

    Private Sub SuccessMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMSuccess"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub


#End Region

    Protected Sub HeadCountGrid_RowDataBound(sender As Object, e As GridViewRowEventArgs) Handles HeadCountGrid.RowDataBound

    End Sub

    Protected Sub cboProcess_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboProcess.SelectedIndexChanged
        Try

            ProcessID = cboProcess.SelectedValue
            ProcessName = cboProcess.SelectedItem.Text
            GetHeadCountList(ucDateFrom.Text, 0)

        Catch ex As Exception
            AlertMessage(ex.Message)
        End Try
    End Sub

    Protected Sub btnSaveHeadCount_Click(sender As Object, e As EventArgs) Handles btnSaveHeadCount.Click
        Try
            Dim IsInProduction As Boolean = False
            Dim IsBillable As Boolean = False
            Dim Id As Integer
            For Each row As GridViewRow In HeadCountGrid.Rows
                IsInProduction = CType(row.FindControl("chkInProd"), System.Web.UI.WebControls.CheckBox).Checked
                IsBillable = CType(row.FindControl("chkIsBillable"), System.Web.UI.WebControls.CheckBox).Checked
                Id = CType(row.FindControl("hdnId"), HiddenField).Value
                SaveHeadCountDetail(Id, IsInProduction, IsBillable)
            Next
            SuccessMessage("Thanks For Updating..!!!")
        Catch ex As Exception
            AlertMessage(ex.Message)
        End Try
    End Sub

    Protected Sub ucDateFrom_Changed(sender As Object, e As EventArgs) Handles ucDateFrom.Changed
        Try
            Dim startdayofweek As Date = Convert.ToDateTime(ucDateFrom.Text)
            If (startdayofweek.DayOfWeek = 1) Then
                GetHeadCountList(ucDateFrom.Text, 0)
            Else
                ucDateFrom.value = Today.Date()
                AlertMessage("Please Select Monday As Start Day Of Week Only")
            End If
        Catch ex As Exception
            AlertMessage(ex.Message)
        End Try
    End Sub

    Protected Sub chkInProduction(ByVal sender As Object, ByVal e As EventArgs)
        '  ProcessID = 5
    End Sub

    'Protected Sub btnImport_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnUpload.Click
    '    If (FileUpload1.HasFile) Then
    '        Dim connString As String = ""
    '        Dim strFileType As String = Path.GetExtension(FileUpload1.FileName).ToLower()
    '        FileUpload1.SaveAs(Server.MapPath(FileUpload1.FileName))
    '        Dim path__1 As String = Server.MapPath(FileUpload1.PostedFile.FileName)
    '        'Connection String to Excel Workbook
    '        If strFileType.Trim() = ".xls" Then
    '            connString = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" & path__1 & ";Extended Properties=""Excel 8.0;HDR=Yes;IMEX=2"""
    '        ElseIf strFileType.Trim() = ".xlsx" Then
    '            connString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" & path__1 & ";Extended Properties=""Excel 12.0;HDR=Yes;"""
    '        End If
    '        Dim query As String = "SELECT [Name],[Designation],[DOJ] FROM [Process$]"
    '        Dim conexcel As New OleDbConnection(connString)
    '        'If conexcel.State = ConnectionState.Closed Then
    '        '    conexcel.Open()
    '        'End If
    '        Dim cmd As New OleDbCommand(query, conexcel)
    '        Dim da As New OleDbDataAdapter(cmd)
    '        Dim ds As New DataSet()
    '        da.Fill(ds)
    '        grvExcelData.DataSource = ds.Tables(0)
    '        grvExcelData.DataBind()
    '        da.Dispose()
    '        conexcel.Close()
    '        conexcel.Dispose()
    '        File.Delete(Server.MapPath(FileUpload1.PostedFile.FileName))
    '    End If
    'End Sub

    Protected Sub btnfillprevious_Click(sender As Object, e As EventArgs) Handles btnfillprevious.Click
        Try

            Dim Lastweekday As DateTime ', daysSinceMonday As Integer
            Lastweekday = DateTime.Today().AddDays(-7)
            Dim dt As Date = Lastweekday
            While dt.DayOfWeek <> DayOfWeek.Monday
                dt = dt.AddDays(-1)
            End While
            Dim monday As DateTime = Today.AddDays((Today.DayOfWeek - DayOfWeek.Monday) * -1)
            GetHeadCountList(ucDateFrom.Text, 1)


            'Dim today As Date = Date.Today
            'Dim dayIndex As Integer = today.DayOfWeek
            'If dayIndex < DayOfWeek.Monday Then
            '    dayIndex += 7 'Monday is first day of week, no day of week should have a smaller index
            'End If
            'Dim dayDiff As Integer = dayIndex - DayOfWeek.Monday
            'Dim monday As Date = today.AddDays(-dayDiff)

        Catch ex As Exception

        End Try
    End Sub

    Protected Sub imgfav_Click(sender As Object, e As ImageClickEventArgs) Handles imgfav.Click
        Common.AddToFav(AgentID, "Head count")
        SuccessMessage("Report has been added to your favorite list")
    End Sub


End Class
