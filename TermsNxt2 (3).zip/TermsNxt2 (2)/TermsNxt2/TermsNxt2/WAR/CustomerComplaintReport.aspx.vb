﻿Imports com.nss.DBAccess
Imports System.Data
Imports System.Text
Imports System.Globalization
Imports System.Web.Services
Partial Class WSR_CustomerComplaintReport
    Inherits System.Web.UI.Page
    Dim startday As Integer, endday As Integer
        Property AgentID() As String
            Get
                Return ViewState("AgentID")
            End Get
            Set(ByVal value As String)
                ViewState("AgentID") = value
            End Set
        End Property

        Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
            HumanMessage.Style.Item("visibility") = "hidden"
            Try
                If Not IsPostBack Then
                LblError.Visible = False
                AgentID = Session("Agentid")
                Common.FillProcesses(cboProcess, AgentID)
                PanelReports.Controls.Add(Common.GetMenu(Request.Url, AgentID, Request.ApplicationPath))
                FillCommonFilters()
                UcDateTo.Visible = False
                ucDateFrom.Visible = False
                lblAnd.Visible = False
                GetCustomerData()
                Else
                '   GetCustomerData()
                End If

            Catch ex As Exception
                AlertMessage(ex.Message)
            End Try

        End Sub
    Private Sub FillCommonFilters()
        Dim db As New DBAccess("CRM")
        Dim dt As DataTable = db.ReturnTable("select * from tbl_Reports_DatePeriods")
        db = Nothing
        Dim dr As DataRow = dt.NewRow
        dr(0) = 10
        dr(1) = "Between"
        dt.Rows.Add(dr)
        ddlPeriod.DataTextField = "Caption"
        ddlPeriod.DataValueField = "Period"
        ddlPeriod.DataSource = dt
        ddlPeriod.DataBind()
        db = New DBAccess
        dt = db.ReturnTable("Select * from tbl_Reports_GroupBy")
        db = Nothing

    End Sub
    Private Sub GetCustomerData()
        Try
            Dim db As New DBAccess("CRM")
            If ddlPeriod.SelectedValue = 10 Then
                startday = ucDateFrom.yyyymmdd
                endday = UcDateTo.yyyymmdd
            Else
                db = New DBAccess("CRM")
                db.slDataAdd("Period", ddlPeriod.SelectedValue)
                db.slDataAdd("ProcessID", cboProcess.SelectedValue)
                Dim dr As DataRow = db.ReturnRow("usp_GetStart_EndDateForAPeriod_Process", True)
                db = Nothing
                startday = dr(0)
                endday = dr(1)
            End If
            db = New DBAccess("CRM")
            Dim dt As DataTable = New DataTable
            db.slDataAdd("ProcessID", cboProcess.SelectedItem.Value)
            db.slDataAdd("DateFrom", startday)
            db.slDataAdd("DateTo", endday)
            dt = db.ReturnTable("USP_GET_Report_CustomerComplaints", , True)
            db = Nothing
            gvIssues.DataSource = dt
            gvIssues.DataBind()
            lblReportName.CurrentPage = "Customer Complaints Report Between " & IntegerToDateString(startday) & "  and " & IntegerToDateString(endday) & " for " & cboProcess.SelectedItem.Text & " process"
        Catch ex As Exception
            Throw ex
        End Try
    End Sub

    Private Function IntegerToDateString(ByVal d As Integer) As String
        Return d.ToString.Substring(0, 4) & "-" & d.ToString.Substring(4, 2) & "-" & d.ToString.Substring(6, 2)
    End Function


    Protected Sub cboProcess_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboProcess.SelectedIndexChanged
        Try
            GetCustomerData()
        Catch ex As Exception
            AlertMessage(ex.Message)
        End Try

    End Sub

#Region "Utility"

    Private Sub AlertMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMFail"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub

    Private Sub SuccessMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMSuccess"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub
    Public Overrides Sub VerifyRenderingInServerForm(ByVal Control As Control)

    End Sub
#End Region

    Protected Sub ddlPeriod_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ddlPeriod.SelectedIndexChanged
        Try
            If ddlPeriod.SelectedValue = 10 Then
                ucDateFrom.Visible = True
                UcDateTo.Visible = True
                lblAnd.Visible = True
            Else
                ucDateFrom.Visible = False
                UcDateTo.Visible = False
                lblAnd.Visible = False
                GetCustomerData()
            End If
        Catch ex As Exception
            AlertMessage(ex.Message)
        End Try
    End Sub

 
    Protected Sub btnRefresh_Click(sender As Object, e As ImageClickEventArgs) Handles btnRefresh.Click
        Try
            GetCustomerData()
        Catch ex As Exception
            AlertMessage(ex.Message)
        End Try
    End Sub

 
    Protected Sub btnFavourite_Click(sender As Object, e As ImageClickEventArgs) Handles btnFavourite.Click
        Try
            Common.AddToFav(AgentID, "Customer Complaint Report")
            SuccessMessage("Report has been added to your favourite list")
        Catch ex As Exception
            AlertMessage(ex.Message)
        End Try
    End Sub

    Protected Sub btnExcel_Click(sender As Object, e As ImageClickEventArgs) Handles btnExcel.Click
        Try
            GridViewExportUtil.Export(lblReportName.CurrentPage & ".xls", Me.gvIssues)
        Catch ex As Exception
            AlertMessage(ex.Message)
        End Try
    End Sub
End Class
