﻿Imports com.nss.DBAccess
Imports System.Data
Imports System.Text
Imports System.Globalization
Imports System.Web.Services
Imports System.Linq
Partial Class WSR_DLGTracker
    Inherits System.Web.UI.Page


#Region "Properties"

    Property AgentID() As String
        Get
            Return ViewState("AgentID")
        End Get
        Set(ByVal value As String)
            ViewState("AgentID") = value
        End Set
    End Property

    Property CampaignID() As String
        Get
            Return ViewState("CampaignID")
        End Get
        Set(ByVal value As String)
            ViewState("CampaignID") = value
        End Set
    End Property

    Property dtTenuredTM() As DataTable
        Get
            Return ViewState("dtTenuredTM")
        End Get
        Set(ByVal value As DataTable)
            ViewState("dtTenuredTM") = value
        End Set
    End Property

#End Region


#Region "Page Load"



    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        HumanMessage.Style.Item("visibility") = "hidden"
        Try
            If Not IsPostBack Then
                If Session("AgentID") <> "" Then
                    AgentID = Session("AgentID")
                    CampaignID = Session("CampaignID")
                    PanelReports.Controls.Add(Common.GetMenu(Request.Url, AgentID, Request.ApplicationPath))
                    Common.FillProcesses(cboProcess, AgentID)

                    If cboProcess.Items.Count > 0 Then
                        For j As Integer = cboProcess.Items.Count - 1 To 0 Step -1
                            If cboProcess.Items(j).Value = 9 Then
                                ' do Nothing
                            Else
                                cboProcess.Items.RemoveAt(j)
                            End If
                        Next

                    End If

                    GetDLGTrackerData(Today)
                    btnSave.Enabled = False
                    btnSave2.Enabled = False
                End If
            Else
                GetDLGTrackerData(dpSelectDate.yyyymmdd)
            End If

        Catch ex As Exception
            AlertMessage(ex.Message)
        End Try

    End Sub
#End Region

#Region "Functions"


    Private Sub SaveDLGTrackerData()
        Dim Str As String = ""
        Dim d = DateTime.ParseExact(dpSelectDate.yyyymmdd, "yyyyMMdd", CultureInfo.InvariantCulture)
        Dim offset As Integer = d.DayOfWeek - DayOfWeek.Monday
        Dim Monday As DateTime = d.AddDays(-offset)
        Dim Tuesday As DateTime = Monday.AddDays(1)
        Dim Wednesday As DateTime = Monday.AddDays(2)
        Dim Thursday As DateTime = Monday.AddDays(3)
        Dim Friday As DateTime = Monday.AddDays(4)
        Dim Saturday As DateTime = Monday.AddDays(5)
        Dim _dt As New DataTable
        _dt.Columns.Add("ParameterID")
        _dt.Columns.Add("Day")
        _dt.Columns.Add("Count")
        _dt.Columns.Add("StartDate")

        For j As Integer = 0 To gvTenuredTMs.Rows.Count - 1
            Dim id As String = CType(gvTenuredTMs.Rows(j).FindControl("hdnParameterId"), HiddenField).Value
            Dim txtMon As String = CType(gvTenuredTMs.Rows(j).FindControl("gvtxtMonCount"), TextBox).Text
            Dim txtTue As String = CType(gvTenuredTMs.Rows(j).FindControl("gvtxtTueCount"), TextBox).Text
            Dim txtWed As String = CType(gvTenuredTMs.Rows(j).FindControl("gvtxtWedCount"), TextBox).Text
            Dim txtThu As String = CType(gvTenuredTMs.Rows(j).FindControl("gvtxtThuCount"), TextBox).Text
            Dim txtFri As String = CType(gvTenuredTMs.Rows(j).FindControl("gvtxtFriCount"), TextBox).Text
            Dim txtSat As String = CType(gvTenuredTMs.Rows(j).FindControl("gvtxtSatCount"), TextBox).Text
           
            Dim _row0 = _dt.NewRow()
            _row0("ParameterID") = id
            _row0("Day") = "Monday"
            _row0("Count") = txtMon
            _row0("StartDate") = Monday
            _dt.Rows.Add(_row0)

            Dim _row1 = _dt.NewRow()
            _row1("ParameterID") = id
            _row1("Day") = "Tuesday"
            _row1("Count") = txtTue
            _row1("StartDate") = Tuesday
            _dt.Rows.Add(_row1)

            Dim _row2 = _dt.NewRow()
            _row2("ParameterID") = id
            _row2("Day") = "Wednesday"
            _row2("Count") = txtWed
            _row2("StartDate") = Wednesday
            _dt.Rows.Add(_row2)

            Dim _row3 = _dt.NewRow()
            _row3("ParameterID") = id
            _row3("Day") = "Thursday"
            _row3("Count") = txtThu
            _row3("StartDate") = Thursday
            _dt.Rows.Add(_row3)

            Dim _row4 = _dt.NewRow()
            _row4("ParameterID") = id
            _row4("Day") = "Friday"
            _row4("Count") = txtFri
            _row4("StartDate") = Friday
            _dt.Rows.Add(_row4)

            Dim _row5 = _dt.NewRow()
            _row5("ParameterID") = id
            _row5("Day") = "Saturday"
            _row5("Count") = txtSat
            _row5("StartDate") = Saturday
            _dt.Rows.Add(_row5)


        Next
        For j As Integer = 0 To GridView1.Rows.Count - 1
            Dim id As String = CType(GridView1.Rows(j).FindControl("hdnParameterId"), HiddenField).Value
            Dim txtMon As String = CType(GridView1.Rows(j).FindControl("gvtxtMonCount"), TextBox).Text
            Dim txtTue As String = CType(GridView1.Rows(j).FindControl("gvtxtTueCount"), TextBox).Text
            Dim txtWed As String = CType(GridView1.Rows(j).FindControl("gvtxtWedCount"), TextBox).Text
            Dim txtThu As String = CType(GridView1.Rows(j).FindControl("gvtxtThuCount"), TextBox).Text
            Dim txtFri As String = CType(GridView1.Rows(j).FindControl("gvtxtFriCount"), TextBox).Text
            Dim txtSat As String = CType(GridView1.Rows(j).FindControl("gvtxtSatCount"), TextBox).Text

            Dim _row0 = _dt.NewRow()
            _row0("ParameterID") = id
            _row0("Day") = "Monday"
            _row0("Count") = txtMon
            _row0("StartDate") = Monday
            _dt.Rows.Add(_row0)

            Dim _row1 = _dt.NewRow()
            _row1("ParameterID") = id
            _row1("Day") = "Tuesday"
            _row1("Count") = txtTue
            _row1("StartDate") = Tuesday
            _dt.Rows.Add(_row1)

            Dim _row2 = _dt.NewRow()
            _row2("ParameterID") = id
            _row2("Day") = "Wednesday"
            _row2("Count") = txtWed
            _row2("StartDate") = Wednesday
            _dt.Rows.Add(_row2)

            Dim _row3 = _dt.NewRow()
            _row3("ParameterID") = id
            _row3("Day") = "Thursday"
            _row3("Count") = txtThu
            _row3("StartDate") = Thursday
            _dt.Rows.Add(_row3)

            Dim _row4 = _dt.NewRow()
            _row4("ParameterID") = id
            _row4("Day") = "Friday"
            _row4("Count") = txtFri
            _row4("StartDate") = Friday
            _dt.Rows.Add(_row4)

            Dim _row5 = _dt.NewRow()
            _row5("ParameterID") = id
            _row5("Day") = "Saturday"
            _row5("Count") = txtSat
            _row5("StartDate") = Saturday
            _dt.Rows.Add(_row5)


        Next
        For j As Integer = 0 To GridView2.Rows.Count - 1
            Dim id As String = CType(GridView2.Rows(j).FindControl("hdnParameterId"), HiddenField).Value
            Dim txtMon As String = CType(GridView2.Rows(j).FindControl("gvtxtMonCount"), TextBox).Text
            Dim txtTue As String = CType(GridView2.Rows(j).FindControl("gvtxtTueCount"), TextBox).Text
            Dim txtWed As String = CType(GridView2.Rows(j).FindControl("gvtxtWedCount"), TextBox).Text
            Dim txtThu As String = CType(GridView2.Rows(j).FindControl("gvtxtThuCount"), TextBox).Text
            Dim txtFri As String = CType(GridView2.Rows(j).FindControl("gvtxtFriCount"), TextBox).Text
            Dim txtSat As String = CType(GridView2.Rows(j).FindControl("gvtxtSatCount"), TextBox).Text
          
            Dim _row0 = _dt.NewRow()
            _row0("ParameterID") = id
            _row0("Day") = "Monday"
            _row0("Count") = txtMon
            _row0("StartDate") = Monday
            _dt.Rows.Add(_row0)

            Dim _row1 = _dt.NewRow()
            _row1("ParameterID") = id
            _row1("Day") = "Tuesday"
            _row1("Count") = txtTue
            _row1("StartDate") = Tuesday
            _dt.Rows.Add(_row1)

            Dim _row2 = _dt.NewRow()
            _row2("ParameterID") = id
            _row2("Day") = "Wednesday"
            _row2("Count") = txtWed
            _row2("StartDate") = Wednesday
            _dt.Rows.Add(_row2)

            Dim _row3 = _dt.NewRow()
            _row3("ParameterID") = id
            _row3("Day") = "Thursday"
            _row3("Count") = txtThu
            _row3("StartDate") = Thursday
            _dt.Rows.Add(_row3)

            Dim _row4 = _dt.NewRow()
            _row4("ParameterID") = id
            _row4("Day") = "Friday"
            _row4("Count") = txtFri
            _row4("StartDate") = Friday
            _dt.Rows.Add(_row4)

            Dim _row5 = _dt.NewRow()
            _row5("ParameterID") = id
            _row5("Day") = "Saturday"
            _row5("Count") = txtSat
            _row5("StartDate") = Saturday
            _dt.Rows.Add(_row5)


        Next

        For j As Integer = 0 To GridView3.Rows.Count - 1
            Dim id As String = CType(GridView3.Rows(j).FindControl("hdnParameterId"), HiddenField).Value
            Dim txtMon As String = CType(GridView3.Rows(j).FindControl("gvtxtMonCount"), TextBox).Text
            Dim txtTue As String = CType(GridView3.Rows(j).FindControl("gvtxtTueCount"), TextBox).Text
            Dim txtWed As String = CType(GridView3.Rows(j).FindControl("gvtxtWedCount"), TextBox).Text
            Dim txtThu As String = CType(GridView3.Rows(j).FindControl("gvtxtThuCount"), TextBox).Text
            Dim txtFri As String = CType(GridView3.Rows(j).FindControl("gvtxtFriCount"), TextBox).Text
            Dim txtSat As String = CType(GridView3.Rows(j).FindControl("gvtxtSatCount"), TextBox).Text

            Dim _row0 = _dt.NewRow()
            _row0("ParameterID") = id
            _row0("Day") = "Monday"
            _row0("Count") = txtMon
            _row0("StartDate") = Monday
            _dt.Rows.Add(_row0)

            Dim _row1 = _dt.NewRow()
            _row1("ParameterID") = id
            _row1("Day") = "Tuesday"
            _row1("Count") = txtTue
            _row1("StartDate") = Tuesday
            _dt.Rows.Add(_row1)

            Dim _row2 = _dt.NewRow()
            _row2("ParameterID") = id
            _row2("Day") = "Wednesday"
            _row2("Count") = txtWed
            _row2("StartDate") = Wednesday
            _dt.Rows.Add(_row2)

            Dim _row3 = _dt.NewRow()
            _row3("ParameterID") = id
            _row3("Day") = "Thursday"
            _row3("Count") = txtThu
            _row3("StartDate") = Thursday
            _dt.Rows.Add(_row3)

            Dim _row4 = _dt.NewRow()
            _row4("ParameterID") = id
            _row4("Day") = "Friday"
            _row4("Count") = txtFri
            _row4("StartDate") = Friday
            _dt.Rows.Add(_row4)

            Dim _row5 = _dt.NewRow()
            _row5("ParameterID") = id
            _row5("Day") = "Saturday"
            _row5("Count") = txtSat
            _row5("StartDate") = Saturday
            _dt.Rows.Add(_row5)
        Next


        Dim db As DBAccess
        db = New DBAccess("CRM")
        Try

            db.BeginTrans()
            db.slDataAdd("StartDate", dpSelectDate.yyyymmdd)
            db.slDataAdd("ProcessID", cboProcess.SelectedValue)
            db.Executeproc("USP_DEL_DLGTrackerData")
            For Each row As DataRow In _dt.Rows
                db.slDataAdd("ID", String.Empty)
                db.slDataAdd("ProcessId", cboProcess.SelectedValue)
                db.slDataAdd("ParameterID", row.Item("ParameterID"))
                db.slDataAdd("Day", row.Item("Day"))
                db.slDataAdd("Count", row.Item("Count"))
                db.slDataAdd("StartDate", row.Item("StartDate"))
                db.slDataAdd("FilledBy", AgentID)
                db.Executeproc("USP_WSR_SET_DLGTrackerData")
            Next
            db.CommitTrans()


        Catch ex As Exception
            db.RollBackTrans()
            Throw ex
        Finally
            db = Nothing
            SuccessMessage("Saved Successfully")
        End Try


    End Sub

    Private Sub GetDLGTrackerData(ByVal date1 As String)
        Dim db As New DBAccess("CRM")
        Try
            'Dim dtTenuredTM As DataTable
            Dim ds As DataSet = New DataSet
            db.slDataAdd("StartDate", date1)
            db.slDataAdd("ProcessID", Convert.ToInt32(cboProcess.SelectedValue))
            ds = db.ReturnDataset("USP_WSR_GET_DLGTrackerFields", True)
            db = Nothing
            
            If ds.Tables(0).Rows.Count > 0 Then
                gvTenuredTMs.DataSource = ds.Tables(0)
                gvTenuredTMs.DataBind()
                For j As Integer = 0 To ds.Tables(0).Rows.Count - 1
                    If String.Compare(CType(gvTenuredTMs.Rows(j).FindControl("gvlblParameter"), Label).Text.Trim.ToLower, "expected attendance") = 0 Or String.Compare(CType(gvTenuredTMs.Rows(j).FindControl("gvlblParameter"), Label).Text.Trim, "Login Hours (Tenure TMs)") = 0 Then
                        CType(gvTenuredTMs.Rows(j).FindControl("gvtxtMonCount"), TextBox).Enabled = False
                        CType(gvTenuredTMs.Rows(j).FindControl("gvtxtTueCount"), TextBox).Enabled = False
                        CType(gvTenuredTMs.Rows(j).FindControl("gvtxtWedCount"), TextBox).Enabled = False
                        CType(gvTenuredTMs.Rows(j).FindControl("gvtxtThuCount"), TextBox).Enabled = False
                        CType(gvTenuredTMs.Rows(j).FindControl("gvtxtFriCount"), TextBox).Enabled = False
                        CType(gvTenuredTMs.Rows(j).FindControl("gvtxtSatCount"), TextBox).Enabled = False
                    End If
                Next
            End If
            If ds.Tables(1).Rows.Count > 0 Then
                GridView1.DataSource = ds.Tables(1)
                GridView1.DataBind()
                For j As Integer = 0 To ds.Tables(1).Rows.Count - 1
                    If String.Compare(CType(GridView1.Rows(j).FindControl("gvlblParameter"), Label).Text.Trim.ToLower, "expected attendance") = 0 Or String.Compare(CType(GridView1.Rows(j).FindControl("gvlblParameter"), Label).Text.Trim, "Login Hours (Tenure TMs)") = 0 Then
                        CType(GridView1.Rows(j).FindControl("gvtxtMonCount"), TextBox).Enabled = False
                        CType(GridView1.Rows(j).FindControl("gvtxtTueCount"), TextBox).Enabled = False
                        CType(GridView1.Rows(j).FindControl("gvtxtWedCount"), TextBox).Enabled = False
                        CType(GridView1.Rows(j).FindControl("gvtxtThuCount"), TextBox).Enabled = False
                        CType(GridView1.Rows(j).FindControl("gvtxtFriCount"), TextBox).Enabled = False
                        CType(GridView1.Rows(j).FindControl("gvtxtSatCount"), TextBox).Enabled = False
                    End If
                Next
            End If

            If ds.Tables(2).Rows.Count > 0 Then
                GridView2.DataSource = ds.Tables(2)
                GridView2.DataBind()
                For j As Integer = 0 To ds.Tables(2).Rows.Count - 1
                    If String.Compare(CType(GridView2.Rows(j).FindControl("gvlblParameter"), Label).Text.Trim, "Login Hours (Tenure TMs)") = 0 Then
                        CType(GridView2.Rows(j).FindControl("gvtxtMonCount"), TextBox).Enabled = False
                        CType(GridView2.Rows(j).FindControl("gvtxtTueCount"), TextBox).Enabled = False
                        CType(GridView2.Rows(j).FindControl("gvtxtWedCount"), TextBox).Enabled = False
                        CType(GridView2.Rows(j).FindControl("gvtxtThuCount"), TextBox).Enabled = False
                        CType(GridView2.Rows(j).FindControl("gvtxtFriCount"), TextBox).Enabled = False
                        CType(GridView2.Rows(j).FindControl("gvtxtSatCount"), TextBox).Enabled = False
                    End If
                Next
            End If

            If ds.Tables(3).Rows.Count > 0 Then
                GridView3.DataSource = ds.Tables(3)
                GridView3.DataBind()
                For j As Integer = 0 To ds.Tables(3).Rows.Count - 1
                    If String.Compare(CType(GridView3.Rows(j).FindControl("gvlblParameter"), Label).Text.Trim, "Login Hours (Tenure TMs)") = 0 Then
                        CType(GridView3.Rows(j).FindControl("gvtxtMonCount"), TextBox).Enabled = False
                        CType(GridView3.Rows(j).FindControl("gvtxtTueCount"), TextBox).Enabled = False
                        CType(GridView3.Rows(j).FindControl("gvtxtWedCount"), TextBox).Enabled = False
                        CType(GridView3.Rows(j).FindControl("gvtxtThuCount"), TextBox).Enabled = False
                        CType(GridView3.Rows(j).FindControl("gvtxtFriCount"), TextBox).Enabled = False
                        CType(GridView3.Rows(j).FindControl("gvtxtSatCount"), TextBox).Enabled = False
                    End If
                Next
            End If

        Catch ex As Exception
            Throw ex
        End Try
    End Sub

    Private Sub LoadTotal()
        Try
            For j As Integer = 0 To gvTenuredTMs.Rows.Count - 1
                Dim RMon, RTue, RWed, RThu, RFri, RSat As Integer
                Dim ULMon, ULTue, ULWed, ULThu, ULFri, ULSat As Integer
                Dim Mon, Tue, Wed, Thu, Fri, Sat As Integer
                Dim Mon2, Tue2, Wed2, Thu2, Fri2, Sat2 As TextBox
                Mon2 = CType(gvTenuredTMs.Rows(j).FindControl("gvtxtMonCount"), TextBox)
                Tue2 = CType(gvTenuredTMs.Rows(j).FindControl("gvtxtTueCount"), TextBox)
                Wed2 = CType(gvTenuredTMs.Rows(j).FindControl("gvtxtWedCount"), TextBox)
                Thu2 = CType(gvTenuredTMs.Rows(j).FindControl("gvtxtThuCount"), TextBox)
                Fri2 = CType(gvTenuredTMs.Rows(j).FindControl("gvtxtFriCount"), TextBox)
                Sat2 = CType(gvTenuredTMs.Rows(j).FindControl("gvtxtSatCount"), TextBox)
                If Validation(Mon2, Tue2, Wed2, Thu2, Fri2, Sat2) = True Then
                    If String.Compare(CType(gvTenuredTMs.Rows(j).FindControl("gvlblParameter"), Label).Text.Trim, "Rostered(Tenured TM's)") = 0 Then
                        RMon = Convert.ToDouble(CType(gvTenuredTMs.Rows(j).FindControl("gvtxtMonCount"), TextBox).Text)
                        RTue = Convert.ToDouble(CType(gvTenuredTMs.Rows(j).FindControl("gvtxtTueCount"), TextBox).Text)
                        RWed = Convert.ToDouble(CType(gvTenuredTMs.Rows(j).FindControl("gvtxtWedCount"), TextBox).Text)
                        RThu = Convert.ToDouble(CType(gvTenuredTMs.Rows(j).FindControl("gvtxtThuCount"), TextBox).Text)
                        RFri = Convert.ToDouble(CType(gvTenuredTMs.Rows(j).FindControl("gvtxtFriCount"), TextBox).Text)
                        RSat = Convert.ToDouble(CType(gvTenuredTMs.Rows(j).FindControl("gvtxtSatCount"), TextBox).Text)

                    ElseIf String.Compare(CType(gvTenuredTMs.Rows(j).FindControl("gvlblParameter"), Label).Text.Trim, "Unscheduled Leaves") = 0 Then
                        ULMon = Convert.ToDouble(CType(gvTenuredTMs.Rows(j).FindControl("gvtxtMonCount"), TextBox).Text)
                        ULTue = Convert.ToDouble(CType(gvTenuredTMs.Rows(j).FindControl("gvtxtTueCount"), TextBox).Text)
                        ULWed = Convert.ToDouble(CType(gvTenuredTMs.Rows(j).FindControl("gvtxtWedCount"), TextBox).Text)
                        ULThu = Convert.ToDouble(CType(gvTenuredTMs.Rows(j).FindControl("gvtxtThuCount"), TextBox).Text)
                        ULFri = Convert.ToDouble(CType(gvTenuredTMs.Rows(j).FindControl("gvtxtFriCount"), TextBox).Text)
                        ULSat = Convert.ToDouble(CType(gvTenuredTMs.Rows(j).FindControl("gvtxtSatCount"), TextBox).Text)

                    ElseIf String.Compare(CType(gvTenuredTMs.Rows(j).FindControl("gvlblParameter"), Label).Text.Trim, "Expected Attendance") = 0 Then
                        CType(gvTenuredTMs.Rows(j).FindControl("gvtxtMonCount"), TextBox).Text = Convert.ToDouble(RMon) - Convert.ToDouble(ULMon)
                        CType(gvTenuredTMs.Rows(j).FindControl("gvtxtTueCount"), TextBox).Text = Convert.ToDouble(RTue) - Convert.ToDouble(ULTue)
                        CType(gvTenuredTMs.Rows(j).FindControl("gvtxtWedCount"), TextBox).Text = Convert.ToDouble(RWed) - Convert.ToDouble(ULWed)
                        CType(gvTenuredTMs.Rows(j).FindControl("gvtxtThuCount"), TextBox).Text = Convert.ToDouble(RThu) - Convert.ToDouble(ULThu)
                        CType(gvTenuredTMs.Rows(j).FindControl("gvtxtFriCount"), TextBox).Text = Convert.ToDouble(RFri) - Convert.ToDouble(ULFri)
                        CType(gvTenuredTMs.Rows(j).FindControl("gvtxtSatCount"), TextBox).Text = Convert.ToDouble(RSat) - Convert.ToDouble(ULSat)

                    ElseIf String.Compare(CType(gvTenuredTMs.Rows(j).FindControl("gvlblParameter"), Label).Text.Trim, "TOS") = 0 Then
                        Mon = Convert.ToDouble(CType(gvTenuredTMs.Rows(j).FindControl("gvtxtMonCount"), TextBox).Text)
                        Tue = Convert.ToDouble(CType(gvTenuredTMs.Rows(j).FindControl("gvtxtTueCount"), TextBox).Text)
                        Wed = Convert.ToDouble(CType(gvTenuredTMs.Rows(j).FindControl("gvtxtWedCount"), TextBox).Text)
                        Thu = Convert.ToDouble(CType(gvTenuredTMs.Rows(j).FindControl("gvtxtThuCount"), TextBox).Text)
                        Fri = Convert.ToDouble(CType(gvTenuredTMs.Rows(j).FindControl("gvtxtFriCount"), TextBox).Text)
                        Sat = Convert.ToDouble(CType(gvTenuredTMs.Rows(j).FindControl("gvtxtSatCount"), TextBox).Text)

                    ElseIf String.Compare(CType(gvTenuredTMs.Rows(j).FindControl("gvlblParameter"), Label).Text.Trim, "Login Hours (Tenure TMs)") = 0 Then
                        CType(gvTenuredTMs.Rows(j).FindControl("gvtxtMonCount"), TextBox).Text = (Convert.ToDouble(RMon) - Convert.ToDouble(ULMon)) * Convert.ToDouble(Mon)
                        CType(gvTenuredTMs.Rows(j).FindControl("gvtxtTueCount"), TextBox).Text = (Convert.ToDouble(RTue) - Convert.ToDouble(ULTue)) * Convert.ToDouble(Tue)
                        CType(gvTenuredTMs.Rows(j).FindControl("gvtxtWedCount"), TextBox).Text = (Convert.ToDouble(RWed) - Convert.ToDouble(ULWed)) * Convert.ToDouble(Wed)
                        CType(gvTenuredTMs.Rows(j).FindControl("gvtxtThuCount"), TextBox).Text = (Convert.ToDouble(RThu) - Convert.ToDouble(ULThu)) * Convert.ToDouble(Thu)
                        CType(gvTenuredTMs.Rows(j).FindControl("gvtxtFriCount"), TextBox).Text = (Convert.ToDouble(RFri) - Convert.ToDouble(ULFri)) * Convert.ToDouble(Fri)
                        CType(gvTenuredTMs.Rows(j).FindControl("gvtxtSatCount"), TextBox).Text = (Convert.ToDouble(RSat) - Convert.ToDouble(ULSat)) * Convert.ToDouble(Sat)
                    
                    End If
                    If String.Compare(CType(gvTenuredTMs.Rows(j).FindControl("gvlblParameter"), Label).Text.Trim, "TOS") = 0 Then
                        CType(gvTenuredTMs.Rows(j).FindControl("gvtxtTotal"), TextBox).Text = (Convert.ToDouble(CType(gvTenuredTMs.Rows(j).FindControl("gvtxtMonCount"), TextBox).Text) + Convert.ToDouble(CType(gvTenuredTMs.Rows(j).FindControl("gvtxtTueCount"), TextBox).Text) + Convert.ToDouble(CType(gvTenuredTMs.Rows(j).FindControl("gvtxtWedCount"), TextBox).Text) + Convert.ToDouble(CType(gvTenuredTMs.Rows(j).FindControl("gvtxtThuCount"), TextBox).Text) + Convert.ToDouble(CType(gvTenuredTMs.Rows(j).FindControl("gvtxtFriCount"), TextBox).Text)) / 5
                    Else
                        CType(gvTenuredTMs.Rows(j).FindControl("gvtxtTotal"), TextBox).Text = Convert.ToDouble(CType(gvTenuredTMs.Rows(j).FindControl("gvtxtMonCount"), TextBox).Text) + Convert.ToDouble(CType(gvTenuredTMs.Rows(j).FindControl("gvtxtTueCount"), TextBox).Text) + Convert.ToDouble(CType(gvTenuredTMs.Rows(j).FindControl("gvtxtWedCount"), TextBox).Text) + Convert.ToDouble(CType(gvTenuredTMs.Rows(j).FindControl("gvtxtThuCount"), TextBox).Text) + Convert.ToDouble(CType(gvTenuredTMs.Rows(j).FindControl("gvtxtFriCount"), TextBox).Text) + Convert.ToDouble(CType(gvTenuredTMs.Rows(j).FindControl("gvtxtSatCount"), TextBox).Text)
                    End If
                Else
                    Exit Sub '''' this is the exit of gvTenuredTMs 
                End If
            Next
            For j As Integer = 0 To GridView1.Rows.Count - 1
                Dim RMon, RTue, RWed, RThu, RFri, RSat As Integer
                Dim ULMon, ULTue, ULWed, ULThu, ULFri, ULSat As Integer
                Dim Mon, Tue, Wed, Thu, Fri, Sat As Integer
                Dim Mon2, Tue2, Wed2, Thu2, Fri2, Sat2 As TextBox
                Mon2 = CType(GridView1.Rows(j).FindControl("gvtxtMonCount"), TextBox)
                Tue2 = CType(GridView1.Rows(j).FindControl("gvtxtTueCount"), TextBox)
                Wed2 = CType(GridView1.Rows(j).FindControl("gvtxtWedCount"), TextBox)
                Thu2 = CType(GridView1.Rows(j).FindControl("gvtxtThuCount"), TextBox)
                Fri2 = CType(GridView1.Rows(j).FindControl("gvtxtFriCount"), TextBox)
                Sat2 = CType(GridView1.Rows(j).FindControl("gvtxtSatCount"), TextBox)
                If Validation(Mon2, Tue2, Wed2, Thu2, Fri2, Sat2) = True Then
                    If String.Compare(CType(GridView1.Rows(j).FindControl("gvlblParameter"), Label).Text.Trim, "Rostered(Tenured TM's)") = 0 Then
                        RMon = Convert.ToDouble(CType(GridView1.Rows(j).FindControl("gvtxtMonCount"), TextBox).Text)
                        RTue = Convert.ToDouble(CType(GridView1.Rows(j).FindControl("gvtxtTueCount"), TextBox).Text)
                        RWed = Convert.ToDouble(CType(GridView1.Rows(j).FindControl("gvtxtWedCount"), TextBox).Text)
                        RThu = Convert.ToDouble(CType(GridView1.Rows(j).FindControl("gvtxtThuCount"), TextBox).Text)
                        RFri = Convert.ToDouble(CType(GridView1.Rows(j).FindControl("gvtxtFriCount"), TextBox).Text)
                        RSat = Convert.ToDouble(CType(GridView1.Rows(j).FindControl("gvtxtSatCount"), TextBox).Text)

                    ElseIf String.Compare(CType(GridView1.Rows(j).FindControl("gvlblParameter"), Label).Text.Trim, "Unscheduled Leaves") = 0 Then
                        ULMon = Convert.ToDouble(CType(GridView1.Rows(j).FindControl("gvtxtMonCount"), TextBox).Text)
                        ULTue = Convert.ToDouble(CType(GridView1.Rows(j).FindControl("gvtxtTueCount"), TextBox).Text)
                        ULWed = Convert.ToDouble(CType(GridView1.Rows(j).FindControl("gvtxtWedCount"), TextBox).Text)
                        ULThu = Convert.ToDouble(CType(GridView1.Rows(j).FindControl("gvtxtThuCount"), TextBox).Text)
                        ULFri = Convert.ToDouble(CType(GridView1.Rows(j).FindControl("gvtxtFriCount"), TextBox).Text)
                        ULSat = Convert.ToDouble(CType(GridView1.Rows(j).FindControl("gvtxtSatCount"), TextBox).Text)

                    ElseIf String.Compare(CType(GridView1.Rows(j).FindControl("gvlblParameter"), Label).Text.Trim, "Expected Attendance") = 0 Then
                        CType(GridView1.Rows(j).FindControl("gvtxtMonCount"), TextBox).Text = Convert.ToDouble(RMon) - Convert.ToDouble(ULMon)
                        CType(GridView1.Rows(j).FindControl("gvtxtTueCount"), TextBox).Text = Convert.ToDouble(RTue) - Convert.ToDouble(ULTue)
                        CType(GridView1.Rows(j).FindControl("gvtxtWedCount"), TextBox).Text = Convert.ToDouble(RWed) - Convert.ToDouble(ULWed)
                        CType(GridView1.Rows(j).FindControl("gvtxtThuCount"), TextBox).Text = Convert.ToDouble(RThu) - Convert.ToDouble(ULThu)
                        CType(GridView1.Rows(j).FindControl("gvtxtFriCount"), TextBox).Text = Convert.ToDouble(RFri) - Convert.ToDouble(ULFri)
                        CType(GridView1.Rows(j).FindControl("gvtxtSatCount"), TextBox).Text = Convert.ToDouble(RSat) - Convert.ToDouble(ULSat)

                    ElseIf String.Compare(CType(GridView1.Rows(j).FindControl("gvlblParameter"), Label).Text.Trim, "TOS") = 0 Then
                        Mon = Convert.ToDouble(CType(GridView1.Rows(j).FindControl("gvtxtMonCount"), TextBox).Text)
                        Tue = Convert.ToDouble(CType(GridView1.Rows(j).FindControl("gvtxtTueCount"), TextBox).Text)
                        Wed = Convert.ToDouble(CType(GridView1.Rows(j).FindControl("gvtxtWedCount"), TextBox).Text)
                        Thu = Convert.ToDouble(CType(GridView1.Rows(j).FindControl("gvtxtThuCount"), TextBox).Text)
                        Fri = Convert.ToDouble(CType(GridView1.Rows(j).FindControl("gvtxtFriCount"), TextBox).Text)
                        Sat = Convert.ToDouble(CType(GridView1.Rows(j).FindControl("gvtxtSatCount"), TextBox).Text)

                    ElseIf String.Compare(CType(GridView1.Rows(j).FindControl("gvlblParameter"), Label).Text.Trim, "Login Hours (Tenure TMs)") = 0 Then
                        CType(GridView1.Rows(j).FindControl("gvtxtMonCount"), TextBox).Text = (Convert.ToDouble(RMon) - Convert.ToDouble(ULMon)) * Convert.ToDouble(Mon)
                        CType(GridView1.Rows(j).FindControl("gvtxtTueCount"), TextBox).Text = (Convert.ToDouble(RTue) - Convert.ToDouble(ULTue)) * Convert.ToDouble(Tue)
                        CType(GridView1.Rows(j).FindControl("gvtxtWedCount"), TextBox).Text = (Convert.ToDouble(RWed) - Convert.ToDouble(ULWed)) * Convert.ToDouble(Wed)
                        CType(GridView1.Rows(j).FindControl("gvtxtThuCount"), TextBox).Text = (Convert.ToDouble(RThu) - Convert.ToDouble(ULThu)) * Convert.ToDouble(Thu)
                        CType(GridView1.Rows(j).FindControl("gvtxtFriCount"), TextBox).Text = (Convert.ToDouble(RFri) - Convert.ToDouble(ULFri)) * Convert.ToDouble(Fri)
                        CType(GridView1.Rows(j).FindControl("gvtxtSatCount"), TextBox).Text = (Convert.ToDouble(RSat) - Convert.ToDouble(ULSat)) * Convert.ToDouble(Sat)

                    End If
                    If String.Compare(CType(GridView1.Rows(j).FindControl("gvlblParameter"), Label).Text.Trim, "TOS") = 0 Then
                        CType(GridView1.Rows(j).FindControl("gvtxtTotal"), TextBox).Text = (Convert.ToDouble(CType(GridView1.Rows(j).FindControl("gvtxtMonCount"), TextBox).Text) + Convert.ToDouble(CType(GridView1.Rows(j).FindControl("gvtxtTueCount"), TextBox).Text) + Convert.ToDouble(CType(GridView1.Rows(j).FindControl("gvtxtWedCount"), TextBox).Text) + Convert.ToDouble(CType(GridView1.Rows(j).FindControl("gvtxtThuCount"), TextBox).Text) + Convert.ToDouble(CType(GridView1.Rows(j).FindControl("gvtxtFriCount"), TextBox).Text)) / 5
                    Else
                        CType(GridView1.Rows(j).FindControl("gvtxtTotal"), TextBox).Text = Convert.ToDouble(CType(GridView1.Rows(j).FindControl("gvtxtMonCount"), TextBox).Text) + Convert.ToDouble(CType(GridView1.Rows(j).FindControl("gvtxtTueCount"), TextBox).Text) + Convert.ToDouble(CType(GridView1.Rows(j).FindControl("gvtxtWedCount"), TextBox).Text) + Convert.ToDouble(CType(GridView1.Rows(j).FindControl("gvtxtThuCount"), TextBox).Text) + Convert.ToDouble(CType(GridView1.Rows(j).FindControl("gvtxtFriCount"), TextBox).Text) + Convert.ToDouble(CType(GridView1.Rows(j).FindControl("gvtxtSatCount"), TextBox).Text)
                    End If

                Else
                    Exit Sub
                End If
            Next

            For j As Integer = 0 To GridView2.Rows.Count - 1
                Dim RMon, RTue, RWed, RThu, RFri, RSat As Integer
                Dim Mon, Tue, Wed, Thu, Fri, Sat As Integer
                Dim Mon2, Tue2, Wed2, Thu2, Fri2, Sat2 As TextBox
                Mon2 = CType(GridView2.Rows(j).FindControl("gvtxtMonCount"), TextBox)
                Tue2 = CType(GridView2.Rows(j).FindControl("gvtxtTueCount"), TextBox)
                Wed2 = CType(GridView2.Rows(j).FindControl("gvtxtWedCount"), TextBox)
                Thu2 = CType(GridView2.Rows(j).FindControl("gvtxtThuCount"), TextBox)
                Fri2 = CType(GridView2.Rows(j).FindControl("gvtxtFriCount"), TextBox)
                Sat2 = CType(GridView2.Rows(j).FindControl("gvtxtSatCount"), TextBox)
                If Validation(Mon2, Tue2, Wed2, Thu2, Fri2, Sat2) = True Then
                    If String.Compare(CType(GridView2.Rows(j).FindControl("gvlblParameter"), Label).Text.Trim, "Rostered") = 0 Then
                        RMon = Convert.ToDouble(CType(GridView2.Rows(j).FindControl("gvtxtMonCount"), TextBox).Text)
                        RTue = Convert.ToDouble(CType(GridView2.Rows(j).FindControl("gvtxtTueCount"), TextBox).Text)
                        RWed = Convert.ToDouble(CType(GridView2.Rows(j).FindControl("gvtxtWedCount"), TextBox).Text)
                        RThu = Convert.ToDouble(CType(GridView2.Rows(j).FindControl("gvtxtThuCount"), TextBox).Text)
                        RFri = Convert.ToDouble(CType(GridView2.Rows(j).FindControl("gvtxtFriCount"), TextBox).Text)
                        RSat = Convert.ToDouble(CType(GridView2.Rows(j).FindControl("gvtxtSatCount"), TextBox).Text)

                    ElseIf String.Compare(CType(GridView2.Rows(j).FindControl("gvlblParameter"), Label).Text.Trim, "TOS") = 0 Then
                        Mon = Convert.ToDouble(CType(GridView2.Rows(j).FindControl("gvtxtMonCount"), TextBox).Text)
                        Tue = Convert.ToDouble(CType(GridView2.Rows(j).FindControl("gvtxtTueCount"), TextBox).Text)
                        Wed = Convert.ToDouble(CType(GridView2.Rows(j).FindControl("gvtxtWedCount"), TextBox).Text)
                        Thu = Convert.ToDouble(CType(GridView2.Rows(j).FindControl("gvtxtThuCount"), TextBox).Text)
                        Fri = Convert.ToDouble(CType(GridView2.Rows(j).FindControl("gvtxtFriCount"), TextBox).Text)
                        Sat = Convert.ToDouble(CType(GridView2.Rows(j).FindControl("gvtxtSatCount"), TextBox).Text)

                    ElseIf String.Compare(CType(GridView2.Rows(j).FindControl("gvlblParameter"), Label).Text.Trim, "Login Hours (Tenure TMs)") = 0 Then
                        CType(GridView2.Rows(j).FindControl("gvtxtMonCount"), TextBox).Text = Convert.ToDouble(RMon) * Convert.ToDouble(Mon)
                        CType(GridView2.Rows(j).FindControl("gvtxtTueCount"), TextBox).Text = Convert.ToDouble(RTue) * Convert.ToDouble(Tue)
                        CType(GridView2.Rows(j).FindControl("gvtxtWedCount"), TextBox).Text = Convert.ToDouble(RWed) * Convert.ToDouble(Wed)
                        CType(GridView2.Rows(j).FindControl("gvtxtThuCount"), TextBox).Text = Convert.ToDouble(RThu) * Convert.ToDouble(Thu)
                        CType(GridView2.Rows(j).FindControl("gvtxtFriCount"), TextBox).Text = Convert.ToDouble(RFri) * Convert.ToDouble(Fri)
                        CType(GridView2.Rows(j).FindControl("gvtxtSatCount"), TextBox).Text = Convert.ToDouble(RSat) * Convert.ToDouble(Sat)

                    End If
                    If String.Compare(CType(GridView2.Rows(j).FindControl("gvlblParameter"), Label).Text.Trim, "TOS") = 0 Then
                        CType(GridView2.Rows(j).FindControl("gvtxtTotal"), TextBox).Text = (Convert.ToDouble(CType(GridView2.Rows(j).FindControl("gvtxtMonCount"), TextBox).Text) + Convert.ToDouble(CType(GridView2.Rows(j).FindControl("gvtxtTueCount"), TextBox).Text) + Convert.ToDouble(CType(GridView2.Rows(j).FindControl("gvtxtWedCount"), TextBox).Text) + Convert.ToDouble(CType(GridView2.Rows(j).FindControl("gvtxtThuCount"), TextBox).Text) + Convert.ToDouble(CType(GridView2.Rows(j).FindControl("gvtxtFriCount"), TextBox).Text)) / 5
                    Else
                        CType(GridView2.Rows(j).FindControl("gvtxtTotal"), TextBox).Text = Convert.ToDouble(CType(GridView2.Rows(j).FindControl("gvtxtMonCount"), TextBox).Text) + Convert.ToDouble(CType(GridView2.Rows(j).FindControl("gvtxtTueCount"), TextBox).Text) + Convert.ToDouble(CType(GridView2.Rows(j).FindControl("gvtxtWedCount"), TextBox).Text) + Convert.ToDouble(CType(GridView2.Rows(j).FindControl("gvtxtThuCount"), TextBox).Text) + Convert.ToDouble(CType(GridView2.Rows(j).FindControl("gvtxtFriCount"), TextBox).Text) + Convert.ToDouble(CType(GridView2.Rows(j).FindControl("gvtxtSatCount"), TextBox).Text)
                    End If

                Else
                    Exit Sub
                End If
            Next

            For i As Integer = 0 To GridView3.Rows.Count - 1
                Dim RMon, RTue, RWed, RThu, RFri, RSat As Integer
                Dim Mon, Tue, Wed, Thu, Fri, Sat As Integer
                Dim Mon1, Tue1, Wed1, Thu1, Fri1, Sat1 As Integer
                For j As Integer = 0 To gvTenuredTMs.Rows.Count - 1
                    If String.Compare(CType(gvTenuredTMs.Rows(j).FindControl("gvlblParameter"), Label).Text.Trim, "Login Hours (Tenure TMs)") = 0 Then
                        RMon = Convert.ToDouble(CType(gvTenuredTMs.Rows(j).FindControl("gvtxtMonCount"), TextBox).Text)
                        RTue = Convert.ToDouble(CType(gvTenuredTMs.Rows(j).FindControl("gvtxtTueCount"), TextBox).Text)
                        RWed = Convert.ToDouble(CType(gvTenuredTMs.Rows(j).FindControl("gvtxtWedCount"), TextBox).Text)
                        RThu = Convert.ToDouble(CType(gvTenuredTMs.Rows(j).FindControl("gvtxtThuCount"), TextBox).Text)
                        RFri = Convert.ToDouble(CType(gvTenuredTMs.Rows(j).FindControl("gvtxtFriCount"), TextBox).Text)
                        RSat = Convert.ToDouble(CType(gvTenuredTMs.Rows(j).FindControl("gvtxtSatCount"), TextBox).Text)
                    End If
                Next
                For j As Integer = 0 To GridView1.Rows.Count - 1
                    If String.Compare(CType(GridView1.Rows(j).FindControl("gvlblParameter"), Label).Text.Trim, "Login Hours (Tenure TMs)") = 0 Then
                        Mon = Convert.ToDouble(CType(GridView1.Rows(j).FindControl("gvtxtMonCount"), TextBox).Text)
                        Tue = Convert.ToDouble(CType(GridView1.Rows(j).FindControl("gvtxtTueCount"), TextBox).Text)
                        Wed = Convert.ToDouble(CType(GridView1.Rows(j).FindControl("gvtxtWedCount"), TextBox).Text)
                        Thu = Convert.ToDouble(CType(GridView1.Rows(j).FindControl("gvtxtThuCount"), TextBox).Text)
                        Fri = Convert.ToDouble(CType(GridView1.Rows(j).FindControl("gvtxtFriCount"), TextBox).Text)
                        Sat = Convert.ToDouble(CType(GridView1.Rows(j).FindControl("gvtxtSatCount"), TextBox).Text)
                    End If
                Next
                For j As Integer = 0 To GridView2.Rows.Count - 1
                    If String.Compare(CType(GridView2.Rows(j).FindControl("gvlblParameter"), Label).Text.Trim, "Login Hours (Tenure TMs)") = 0 Then
                        Mon1 = Convert.ToDouble(CType(GridView2.Rows(j).FindControl("gvtxtMonCount"), TextBox).Text)
                        Tue1 = Convert.ToDouble(CType(GridView2.Rows(j).FindControl("gvtxtTueCount"), TextBox).Text)
                        Wed1 = Convert.ToDouble(CType(GridView2.Rows(j).FindControl("gvtxtWedCount"), TextBox).Text)
                        Thu1 = Convert.ToDouble(CType(GridView2.Rows(j).FindControl("gvtxtThuCount"), TextBox).Text)
                        Fri1 = Convert.ToDouble(CType(GridView2.Rows(j).FindControl("gvtxtFriCount"), TextBox).Text)
                        Sat1 = Convert.ToDouble(CType(GridView2.Rows(j).FindControl("gvtxtSatCount"), TextBox).Text)
                    End If
                Next
                If String.Compare(CType(GridView3.Rows(i).FindControl("gvlblParameter"), Label).Text.Trim, "Login Hours (Tenure TMs)") = 0 Then
                    CType(GridView3.Rows(i).FindControl("gvtxtMonCount"), TextBox).Text = Convert.ToDouble(RMon) + Convert.ToDouble(Mon) + Convert.ToDouble(Mon1)
                    CType(GridView3.Rows(i).FindControl("gvtxtTueCount"), TextBox).Text = Convert.ToDouble(RTue) + Convert.ToDouble(Tue) + Convert.ToDouble(Tue1)
                    CType(GridView3.Rows(i).FindControl("gvtxtWedCount"), TextBox).Text = Convert.ToDouble(RWed) + Convert.ToDouble(Wed) + Convert.ToDouble(Wed1)
                    CType(GridView3.Rows(i).FindControl("gvtxtThuCount"), TextBox).Text = Convert.ToDouble(RThu) + Convert.ToDouble(Thu) + Convert.ToDouble(Thu1)
                    CType(GridView3.Rows(i).FindControl("gvtxtFriCount"), TextBox).Text = Convert.ToDouble(RFri) + Convert.ToDouble(Fri) + Convert.ToDouble(Fri)
                    CType(GridView3.Rows(i).FindControl("gvtxtSatCount"), TextBox).Text = Convert.ToDouble(RSat) + Convert.ToDouble(Sat) + Convert.ToDouble(Sat)

                End If
                CType(GridView3.Rows(i).FindControl("gvtxtTotal"), TextBox).Text = Convert.ToDouble(CType(GridView3.Rows(i).FindControl("gvtxtMonCount"), TextBox).Text) + Convert.ToDouble(CType(GridView3.Rows(i).FindControl("gvtxtTueCount"), TextBox).Text) + Convert.ToDouble(CType(GridView3.Rows(i).FindControl("gvtxtWedCount"), TextBox).Text) + Convert.ToDouble(CType(GridView3.Rows(i).FindControl("gvtxtThuCount"), TextBox).Text) + Convert.ToDouble(CType(GridView2.Rows(i).FindControl("gvtxtFriCount"), TextBox).Text) + Convert.ToDouble(CType(GridView3.Rows(i).FindControl("gvtxtSatCount"), TextBox).Text)
            Next
            DisableFields()
        Catch ex As Exception
            Throw ex
        End Try
    End Sub

    Private Sub DisableFields()
        For j As Integer = 0 To gvTenuredTMs.Rows.Count - 1
            CType(gvTenuredTMs.Rows(j).FindControl("gvtxtMonCount"), TextBox).Enabled = False
            CType(gvTenuredTMs.Rows(j).FindControl("gvtxtTueCount"), TextBox).Enabled = False
            CType(gvTenuredTMs.Rows(j).FindControl("gvtxtWedCount"), TextBox).Enabled = False
            CType(gvTenuredTMs.Rows(j).FindControl("gvtxtThuCount"), TextBox).Enabled = False
            CType(gvTenuredTMs.Rows(j).FindControl("gvtxtFriCount"), TextBox).Enabled = False
            CType(gvTenuredTMs.Rows(j).FindControl("gvtxtSatCount"), TextBox).Enabled = False
            CType(gvTenuredTMs.Rows(j).FindControl("gvtxtTotal"), TextBox).Enabled = False
        Next
        For j As Integer = 0 To GridView1.Rows.Count - 1
            CType(GridView1.Rows(j).FindControl("gvtxtMonCount"), TextBox).Enabled = False
            CType(GridView1.Rows(j).FindControl("gvtxtTueCount"), TextBox).Enabled = False
            CType(GridView1.Rows(j).FindControl("gvtxtWedCount"), TextBox).Enabled = False
            CType(GridView1.Rows(j).FindControl("gvtxtThuCount"), TextBox).Enabled = False
            CType(GridView1.Rows(j).FindControl("gvtxtFriCount"), TextBox).Enabled = False
            CType(GridView1.Rows(j).FindControl("gvtxtSatCount"), TextBox).Enabled = False
            CType(GridView1.Rows(j).FindControl("gvtxtTotal"), TextBox).Enabled = False
        Next
        For j As Integer = 0 To GridView2.Rows.Count - 1
            CType(GridView2.Rows(j).FindControl("gvtxtMonCount"), TextBox).Enabled = False
            CType(GridView2.Rows(j).FindControl("gvtxtTueCount"), TextBox).Enabled = False
            CType(GridView2.Rows(j).FindControl("gvtxtWedCount"), TextBox).Enabled = False
            CType(GridView2.Rows(j).FindControl("gvtxtThuCount"), TextBox).Enabled = False
            CType(GridView2.Rows(j).FindControl("gvtxtFriCount"), TextBox).Enabled = False
            CType(GridView2.Rows(j).FindControl("gvtxtSatCount"), TextBox).Enabled = False
            CType(GridView2.Rows(j).FindControl("gvtxtTotal"), TextBox).Enabled = False
        Next
        For j As Integer = 0 To GridView3.Rows.Count - 1
            CType(GridView3.Rows(j).FindControl("gvtxtMonCount"), TextBox).Enabled = False
            CType(GridView3.Rows(j).FindControl("gvtxtTueCount"), TextBox).Enabled = False
            CType(GridView3.Rows(j).FindControl("gvtxtWedCount"), TextBox).Enabled = False
            CType(GridView3.Rows(j).FindControl("gvtxtThuCount"), TextBox).Enabled = False
            CType(GridView3.Rows(j).FindControl("gvtxtFriCount"), TextBox).Enabled = False
            CType(GridView3.Rows(j).FindControl("gvtxtSatCount"), TextBox).Enabled = False
            CType(GridView3.Rows(j).FindControl("gvtxtTotal"), TextBox).Enabled = False
        Next
        btnSave.Enabled = True
        btnSave2.Enabled = True
        btnLoadTotal.Text = "Edit"
        btnLoadTotal2.Text = "Edit"
    End Sub

    Private Sub EnableFields()
        For j As Integer = 0 To gvTenuredTMs.Rows.Count - 1
            If String.Compare(CType(gvTenuredTMs.Rows(j).FindControl("gvlblParameter"), Label).Text.Trim.ToLower, "expected attendance") = 0 Or String.Compare(CType(gvTenuredTMs.Rows(j).FindControl("gvlblParameter"), Label).Text.Trim, "Login Hours (Tenure TMs)") = 0 Then
                CType(gvTenuredTMs.Rows(j).FindControl("gvtxtMonCount"), TextBox).Enabled = False
                CType(gvTenuredTMs.Rows(j).FindControl("gvtxtTueCount"), TextBox).Enabled = False
                CType(gvTenuredTMs.Rows(j).FindControl("gvtxtWedCount"), TextBox).Enabled = False
                CType(gvTenuredTMs.Rows(j).FindControl("gvtxtThuCount"), TextBox).Enabled = False
                CType(gvTenuredTMs.Rows(j).FindControl("gvtxtFriCount"), TextBox).Enabled = False
                CType(gvTenuredTMs.Rows(j).FindControl("gvtxtSatCount"), TextBox).Enabled = False
                CType(gvTenuredTMs.Rows(j).FindControl("gvtxtTotal"), TextBox).Enabled = False
            Else
                CType(gvTenuredTMs.Rows(j).FindControl("gvtxtMonCount"), TextBox).Enabled = True
                CType(gvTenuredTMs.Rows(j).FindControl("gvtxtTueCount"), TextBox).Enabled = True
                CType(gvTenuredTMs.Rows(j).FindControl("gvtxtWedCount"), TextBox).Enabled = True
                CType(gvTenuredTMs.Rows(j).FindControl("gvtxtThuCount"), TextBox).Enabled = True
                CType(gvTenuredTMs.Rows(j).FindControl("gvtxtFriCount"), TextBox).Enabled = True
                CType(gvTenuredTMs.Rows(j).FindControl("gvtxtSatCount"), TextBox).Enabled = True
                CType(gvTenuredTMs.Rows(j).FindControl("gvtxtTotal"), TextBox).Enabled = False
            End If
           
        Next
        For j As Integer = 0 To GridView1.Rows.Count - 1
            If String.Compare(CType(GridView1.Rows(j).FindControl("gvlblParameter"), Label).Text.Trim.ToLower, "expected attendance") = 0 Or String.Compare(CType(GridView1.Rows(j).FindControl("gvlblParameter"), Label).Text.Trim, "Login Hours (Tenure TMs)") = 0 Then
                CType(GridView1.Rows(j).FindControl("gvtxtMonCount"), TextBox).Enabled = False
                CType(GridView1.Rows(j).FindControl("gvtxtTueCount"), TextBox).Enabled = False
                CType(GridView1.Rows(j).FindControl("gvtxtWedCount"), TextBox).Enabled = False
                CType(GridView1.Rows(j).FindControl("gvtxtThuCount"), TextBox).Enabled = False
                CType(GridView1.Rows(j).FindControl("gvtxtFriCount"), TextBox).Enabled = False
                CType(GridView1.Rows(j).FindControl("gvtxtSatCount"), TextBox).Enabled = False
                CType(GridView1.Rows(j).FindControl("gvtxtTotal"), TextBox).Enabled = False
            Else
                CType(GridView1.Rows(j).FindControl("gvtxtMonCount"), TextBox).Enabled = True
                CType(GridView1.Rows(j).FindControl("gvtxtTueCount"), TextBox).Enabled = True
                CType(GridView1.Rows(j).FindControl("gvtxtWedCount"), TextBox).Enabled = True
                CType(GridView1.Rows(j).FindControl("gvtxtThuCount"), TextBox).Enabled = True
                CType(GridView1.Rows(j).FindControl("gvtxtFriCount"), TextBox).Enabled = True
                CType(GridView1.Rows(j).FindControl("gvtxtSatCount"), TextBox).Enabled = True
                CType(GridView1.Rows(j).FindControl("gvtxtTotal"), TextBox).Enabled = False
            End If

        Next
        For j As Integer = 0 To GridView2.Rows.Count - 1
            If String.Compare(CType(GridView2.Rows(j).FindControl("gvlblParameter"), Label).Text.Trim, "Login Hours (Tenure TMs)") = 0 Then
                CType(GridView2.Rows(j).FindControl("gvtxtMonCount"), TextBox).Enabled = False
                CType(GridView2.Rows(j).FindControl("gvtxtTueCount"), TextBox).Enabled = False
                CType(GridView2.Rows(j).FindControl("gvtxtWedCount"), TextBox).Enabled = False
                CType(GridView2.Rows(j).FindControl("gvtxtThuCount"), TextBox).Enabled = False
                CType(GridView2.Rows(j).FindControl("gvtxtFriCount"), TextBox).Enabled = False
                CType(GridView2.Rows(j).FindControl("gvtxtSatCount"), TextBox).Enabled = False
            Else
                CType(GridView2.Rows(j).FindControl("gvtxtMonCount"), TextBox).Enabled = True
                CType(GridView2.Rows(j).FindControl("gvtxtTueCount"), TextBox).Enabled = True
                CType(GridView2.Rows(j).FindControl("gvtxtWedCount"), TextBox).Enabled = True
                CType(GridView2.Rows(j).FindControl("gvtxtThuCount"), TextBox).Enabled = True
                CType(GridView2.Rows(j).FindControl("gvtxtFriCount"), TextBox).Enabled = True
                CType(GridView2.Rows(j).FindControl("gvtxtSatCount"), TextBox).Enabled = True
                CType(GridView2.Rows(j).FindControl("gvtxtTotal"), TextBox).Enabled = False
            End If
           
        Next
       
        btnSave.Enabled = False
        btnSave2.Enabled = False
        btnLoadTotal.Text = "Load Total"
        btnLoadTotal2.Text = "Load Total"
    End Sub

    Private Sub Reset()
        For j As Integer = 0 To gvTenuredTMs.Rows.Count - 1
            CType(gvTenuredTMs.Rows(j).FindControl("gvtxtMonCount"), TextBox).Text = "0"
            CType(gvTenuredTMs.Rows(j).FindControl("gvtxtTueCount"), TextBox).Text = "0"
            CType(gvTenuredTMs.Rows(j).FindControl("gvtxtWedCount"), TextBox).Text = "0"
            CType(gvTenuredTMs.Rows(j).FindControl("gvtxtThuCount"), TextBox).Text = "0"
            CType(gvTenuredTMs.Rows(j).FindControl("gvtxtFriCount"), TextBox).Text = "0"
            CType(gvTenuredTMs.Rows(j).FindControl("gvtxtSatCount"), TextBox).Text = "0"
            CType(gvTenuredTMs.Rows(j).FindControl("gvtxtTotal"), TextBox).Text = "0"
        Next
        For j As Integer = 0 To GridView1.Rows.Count - 1
            CType(GridView1.Rows(j).FindControl("gvtxtMonCount"), TextBox).Text = "0"
            CType(GridView1.Rows(j).FindControl("gvtxtTueCount"), TextBox).Text = "0"
            CType(GridView1.Rows(j).FindControl("gvtxtWedCount"), TextBox).Text = "0"
            CType(GridView1.Rows(j).FindControl("gvtxtThuCount"), TextBox).Text = "0"
            CType(GridView1.Rows(j).FindControl("gvtxtFriCount"), TextBox).Text = "0"
            CType(GridView1.Rows(j).FindControl("gvtxtSatCount"), TextBox).Text = "0"
            CType(GridView1.Rows(j).FindControl("gvtxtTotal"), TextBox).Text = "0"
        Next
        For j As Integer = 0 To GridView2.Rows.Count - 1
            CType(GridView2.Rows(j).FindControl("gvtxtMonCount"), TextBox).Text = "0"
            CType(GridView2.Rows(j).FindControl("gvtxtTueCount"), TextBox).Text = "0"
            CType(GridView2.Rows(j).FindControl("gvtxtWedCount"), TextBox).Text = "0"
            CType(GridView2.Rows(j).FindControl("gvtxtThuCount"), TextBox).Text = "0"
            CType(GridView2.Rows(j).FindControl("gvtxtFriCount"), TextBox).Text = "0"
            CType(GridView2.Rows(j).FindControl("gvtxtSatCount"), TextBox).Text = "0"
            CType(GridView2.Rows(j).FindControl("gvtxtTotal"), TextBox).Text = "0"
        Next
        For j As Integer = 0 To GridView3.Rows.Count - 1
            CType(GridView3.Rows(j).FindControl("gvtxtMonCount"), TextBox).Text = "0"
            CType(GridView3.Rows(j).FindControl("gvtxtTueCount"), TextBox).Text = "0"
            CType(GridView3.Rows(j).FindControl("gvtxtWedCount"), TextBox).Text = "0"
            CType(GridView3.Rows(j).FindControl("gvtxtThuCount"), TextBox).Text = "0"
            CType(GridView3.Rows(j).FindControl("gvtxtFriCount"), TextBox).Text = "0"
            CType(GridView3.Rows(j).FindControl("gvtxtSatCount"), TextBox).Text = "0"
            CType(GridView3.Rows(j).FindControl("gvtxtTotal"), TextBox).Text = "0"
        Next
        btnSave.Enabled = False
        btnSave2.Enabled = False
        btnLoadTotal.Text = "Load Total"
        btnLoadTotal2.Text = "Load Total"
    End Sub

#End Region

#Region "Utility"

    Private Sub AlertMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMFail"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub

    Private Sub SuccessMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMSuccess"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub
    Public Overrides Sub VerifyRenderingInServerForm(ByVal Control As Control)

    End Sub
#End Region

    Protected Sub btnSave_Click(sender As Object, e As EventArgs) Handles btnSave.Click
        Try
            SaveDLGTrackerData()
        Catch ex As Exception
            AlertMessage(ex.Message)
        End Try
    End Sub

    Protected Sub cboProcess_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboProcess.SelectedIndexChanged
        Try
            GetDLGTrackerData(dpSelectDate.yyyymmdd)
        Catch ex As Exception
            AlertMessage(ex.Message)
        End Try
    End Sub

    Protected Sub dpSelectDate_Changed(sender As Object, e As EventArgs) Handles dpSelectDate.Changed
        Try
            GetDLGTrackerData(dpSelectDate.yyyymmdd)
        Catch ex As Exception
            AlertMessage(ex.Message)
        End Try
    End Sub


    Function Validation(ByVal txtMonInput As TextBox, ByVal txtTueInput As TextBox, ByVal txtWedInput As TextBox, ByVal txtThuInput As TextBox, ByVal txtFriInput As TextBox, ByVal txtSatInput As TextBox) As Boolean
        Dim flag As Boolean = True
        If txtMonInput.Text = "" Or txtTueInput.Text = "" Or txtWedInput.Text = "" Or txtThuInput.Text = "" Or txtFriInput.Text = "" Or txtSatInput.Text = "" Then
            lblValidation.Visible = True
            lblValidation.Text = "Please Enter Number in the Row"
            txtMonInput.BorderColor = Drawing.Color.Red
            txtTueInput.BorderColor = Drawing.Color.Red
            txtWedInput.BorderColor = Drawing.Color.Red
            txtThuInput.BorderColor = Drawing.Color.Red
            txtFriInput.BorderColor = Drawing.Color.Red
            txtSatInput.BorderColor = Drawing.Color.Red

            flag = False
            Return flag
        ElseIf Not IsInputNumeric(txtMonInput.Text) Or Not IsInputNumeric(txtTueInput.Text) Or Not IsInputNumeric(txtWedInput.Text) Or Not IsInputNumeric(txtThuInput.Text) Or Not IsInputNumeric(txtFriInput.Text) Or Not IsInputNumeric(txtSatInput.Text) Then
            lblValidation.Visible = True
            lblValidation.Text = "Please Enter Valid Number in the Row"
            txtMonInput.BorderColor = Drawing.Color.Red
            txtTueInput.BorderColor = Drawing.Color.Red
            txtWedInput.BorderColor = Drawing.Color.Red
            txtThuInput.BorderColor = Drawing.Color.Red
            txtFriInput.BorderColor = Drawing.Color.Red
            txtSatInput.BorderColor = Drawing.Color.Red
            flag = False
            Return flag
        Else
            lblValidation.Visible = False
            txtMonInput.BorderColor = Nothing
            txtTueInput.BorderColor = Nothing
            txtWedInput.BorderColor = Nothing
            txtThuInput.BorderColor = Nothing
            txtFriInput.BorderColor = Nothing
            txtSatInput.BorderColor = Nothing
            flag = True
            Return flag
        End If


    End Function


    '    If IsInputNumeric(CType(gvTenuredTMs.Rows(j).FindControl("gvtxtMonCount"), TextBox).Text) Then
    '        If Not Convert.ToDouble(txtMon) = 0.0 Then
    '            txtTotal.Text = Convert.ToDouble(txtMon) + Convert.ToDouble(txtTue) + Convert.ToDouble(txtWed) + Convert.ToDouble(txtThu) + Convert.ToDouble(txtFri) + Convert.ToDouble(txtSat)
    '        End If
    '        lblValidation.Visible = False
    '    Else
    '        lblValidation.Visible = True
    '        lblValidation.Text = "not valid number"
    '        Exit Sub
    '    End If

    'End Sub




    ''----------------GridViews Text Changed Events---------------------------

    'Protected Sub gvtxtMonCount_TextChanged(sender As Object, e As EventArgs)

    '    For j As Integer = 0 To gvTenuredTMs.Rows.Count - 1
    '        Dim txtMon As String = CType(gvTenuredTMs.Rows(j).FindControl("gvtxtMonCount"), TextBox).Text
    '        Dim txtTue As String = CType(gvTenuredTMs.Rows(j).FindControl("gvtxtTueCount"), TextBox).Text
    '        Dim txtWed As String = CType(gvTenuredTMs.Rows(j).FindControl("gvtxtWedCount"), TextBox).Text
    '        Dim txtThu As String = CType(gvTenuredTMs.Rows(j).FindControl("gvtxtThuCount"), TextBox).Text
    '        Dim txtFri As String = CType(gvTenuredTMs.Rows(j).FindControl("gvtxtFriCount"), TextBox).Text
    '        Dim txtSat As String = CType(gvTenuredTMs.Rows(j).FindControl("gvtxtSatCount"), TextBox).Text
    '        Dim txtTotal As TextBox = CType(gvTenuredTMs.Rows(j).FindControl("gvtxtTotal"), TextBox)
    '        If IsInputNumeric(CType(gvTenuredTMs.Rows(j).FindControl("gvtxtMonCount"), TextBox).Text) Then
    '            If Not Convert.ToDouble(txtMon) = 0.0 Then
    '                txtTotal.Text = Convert.ToDouble(txtMon) + Convert.ToDouble(txtTue) + Convert.ToDouble(txtWed) + Convert.ToDouble(txtThu) + Convert.ToDouble(txtFri) + Convert.ToDouble(txtSat)
    '            End If
    '            lblValidation.Visible = False
    '        Else
    '            lblValidation.Visible = True
    '            lblValidation.Text = "not valid number"
    '            Exit Sub
    '        End If
    '    Next

    '    For j As Integer = 0 To GridView1.Rows.Count - 1
    '        Dim txtMon As String = CType(GridView1.Rows(j).FindControl("gvtxtMonCount"), TextBox).Text
    '        Dim txtTue As String = CType(GridView1.Rows(j).FindControl("gvtxtTueCount"), TextBox).Text
    '        Dim txtWed As String = CType(GridView1.Rows(j).FindControl("gvtxtWedCount"), TextBox).Text
    '        Dim txtThu As String = CType(GridView1.Rows(j).FindControl("gvtxtThuCount"), TextBox).Text
    '        Dim txtFri As String = CType(GridView1.Rows(j).FindControl("gvtxtFriCount"), TextBox).Text
    '        Dim txtSat As String = CType(GridView1.Rows(j).FindControl("gvtxtSatCount"), TextBox).Text
    '        Dim txtTotal As TextBox = CType(GridView1.Rows(j).FindControl("gvtxtTotal"), TextBox)
    '        If IsInputNumeric(CType(GridView1.Rows(j).FindControl("gvtxtMonCount"), TextBox).Text) Then
    '            If Not Convert.ToDouble(txtMon) = 0.0 Then
    '                txtTotal.Text = Convert.ToDouble(txtMon) + Convert.ToDouble(txtTue) + Convert.ToDouble(txtWed) + Convert.ToDouble(txtThu) + Convert.ToDouble(txtFri) + Convert.ToDouble(txtSat)
    '            End If
    '            lblValidation.Visible = False
    '        Else
    '            lblValidation.Visible = True
    '            lblValidation.Text = "not valid number"
    '            Exit Sub
    '        End If
    '    Next

    '    For j As Integer = 0 To GridView2.Rows.Count - 1
    '        Dim txtMon As String = CType(GridView2.Rows(j).FindControl("gvtxtMonCount"), TextBox).Text
    '        Dim txtTue As String = CType(GridView2.Rows(j).FindControl("gvtxtTueCount"), TextBox).Text
    '        Dim txtWed As String = CType(GridView2.Rows(j).FindControl("gvtxtWedCount"), TextBox).Text
    '        Dim txtThu As String = CType(GridView2.Rows(j).FindControl("gvtxtThuCount"), TextBox).Text
    '        Dim txtFri As String = CType(GridView2.Rows(j).FindControl("gvtxtFriCount"), TextBox).Text
    '        Dim txtSat As String = CType(GridView2.Rows(j).FindControl("gvtxtSatCount"), TextBox).Text
    '        Dim txtTotal As TextBox = CType(GridView2.Rows(j).FindControl("gvtxtTotal"), TextBox)
    '        If IsInputNumeric(CType(GridView2.Rows(j).FindControl("gvtxtMonCount"), TextBox).Text) Then
    '            If Not Convert.ToDouble(txtMon) = 0.0 Then
    '                txtTotal.Text = Convert.ToDouble(txtMon) + Convert.ToDouble(txtTue) + Convert.ToDouble(txtWed) + Convert.ToDouble(txtThu) + Convert.ToDouble(txtFri) + Convert.ToDouble(txtSat)
    '            End If
    '            lblValidation.Visible = False
    '        Else
    '            lblValidation.Visible = True
    '            lblValidation.Text = "not valid number"
    '            Exit Sub
    '        End If
    '    Next
    'End Sub


    'Protected Sub gvtxtTueCount_TextChanged(sender As Object, e As EventArgs)
    '    For j As Integer = 0 To gvTenuredTMs.Rows.Count - 1
    '        Dim txtMon As String = CType(gvTenuredTMs.Rows(j).FindControl("gvtxtMonCount"), TextBox).Text
    '        Dim txtTue As String = CType(gvTenuredTMs.Rows(j).FindControl("gvtxtTueCount"), TextBox).Text
    '        Dim txtWed As String = CType(gvTenuredTMs.Rows(j).FindControl("gvtxtWedCount"), TextBox).Text
    '        Dim txtThu As String = CType(gvTenuredTMs.Rows(j).FindControl("gvtxtThuCount"), TextBox).Text
    '        Dim txtFri As String = CType(gvTenuredTMs.Rows(j).FindControl("gvtxtFriCount"), TextBox).Text
    '        Dim txtSat As String = CType(gvTenuredTMs.Rows(j).FindControl("gvtxtSatCount"), TextBox).Text
    '        Dim txtTotal As TextBox = CType(gvTenuredTMs.Rows(j).FindControl("gvtxtTotal"), TextBox)
    '        If IsInputNumeric(CType(gvTenuredTMs.Rows(j).FindControl("gvtxtTueCount"), TextBox).Text) Then
    '            If Not Convert.ToDouble(txtTue) = 0.0 Then
    '                txtTotal.Text = Convert.ToDouble(txtMon) + Convert.ToDouble(txtTue) + Convert.ToDouble(txtWed) + Convert.ToDouble(txtThu) + Convert.ToDouble(txtFri) + Convert.ToDouble(txtSat)
    '            End If
    '            lblValidation.Visible = False
    '        Else
    '            lblValidation.Visible = True
    '            lblValidation.Text = "not valid number"
    '            Exit Sub
    '        End If
    '    Next
    '    For j As Integer = 0 To GridView1.Rows.Count - 1
    '        Dim txtMon As String = CType(GridView1.Rows(j).FindControl("gvtxtMonCount"), TextBox).Text
    '        Dim txtTue As String = CType(GridView1.Rows(j).FindControl("gvtxtTueCount"), TextBox).Text
    '        Dim txtWed As String = CType(GridView1.Rows(j).FindControl("gvtxtWedCount"), TextBox).Text
    '        Dim txtThu As String = CType(GridView1.Rows(j).FindControl("gvtxtThuCount"), TextBox).Text
    '        Dim txtFri As String = CType(GridView1.Rows(j).FindControl("gvtxtFriCount"), TextBox).Text
    '        Dim txtSat As String = CType(GridView1.Rows(j).FindControl("gvtxtSatCount"), TextBox).Text
    '        Dim txtTotal As TextBox = CType(GridView1.Rows(j).FindControl("gvtxtTotal"), TextBox)
    '        If IsInputNumeric(CType(GridView1.Rows(j).FindControl("gvtxtTueCount"), TextBox).Text) Then
    '            If Not Convert.ToDouble(txtTue) = 0.0 Then
    '                txtTotal.Text = Convert.ToDouble(txtMon) + Convert.ToDouble(txtTue) + Convert.ToDouble(txtWed) + Convert.ToDouble(txtThu) + Convert.ToDouble(txtFri) + Convert.ToDouble(txtSat)
    '            End If
    '            lblValidation.Visible = False
    '        Else
    '            lblValidation.Visible = True
    '            lblValidation.Text = "not valid number"
    '            Exit Sub
    '        End If
    '    Next
    '    For j As Integer = 0 To GridView2.Rows.Count - 1
    '        Dim txtMon As String = CType(GridView2.Rows(j).FindControl("gvtxtMonCount"), TextBox).Text
    '        Dim txtTue As String = CType(GridView2.Rows(j).FindControl("gvtxtTueCount"), TextBox).Text
    '        Dim txtWed As String = CType(GridView2.Rows(j).FindControl("gvtxtWedCount"), TextBox).Text
    '        Dim txtThu As String = CType(GridView2.Rows(j).FindControl("gvtxtThuCount"), TextBox).Text
    '        Dim txtFri As String = CType(GridView2.Rows(j).FindControl("gvtxtFriCount"), TextBox).Text
    '        Dim txtSat As String = CType(GridView2.Rows(j).FindControl("gvtxtSatCount"), TextBox).Text
    '        Dim txtTotal As TextBox = CType(GridView2.Rows(j).FindControl("gvtxtTotal"), TextBox)
    '        If IsInputNumeric(CType(GridView2.Rows(j).FindControl("gvtxtTueCount"), TextBox).Text) Then
    '            If Not Convert.ToDouble(txtTue) = 0.0 Then
    '                txtTotal.Text = Convert.ToDouble(txtMon) + Convert.ToDouble(txtTue) + Convert.ToDouble(txtWed) + Convert.ToDouble(txtThu) + Convert.ToDouble(txtFri) + Convert.ToDouble(txtSat)
    '            End If
    '            lblValidation.Visible = False
    '        Else
    '            lblValidation.Visible = True
    '            lblValidation.Text = "not valid number"
    '            Exit Sub
    '        End If
    '    Next
    'End Sub


    'Protected Sub gvtxtWedCount_TextChanged(sender As Object, e As EventArgs)
    '    For j As Integer = 0 To gvTenuredTMs.Rows.Count - 1
    '        Dim txtMon As String = CType(gvTenuredTMs.Rows(j).FindControl("gvtxtMonCount"), TextBox).Text
    '        Dim txtTue As String = CType(gvTenuredTMs.Rows(j).FindControl("gvtxtTueCount"), TextBox).Text
    '        Dim txtWed As String = CType(gvTenuredTMs.Rows(j).FindControl("gvtxtWedCount"), TextBox).Text
    '        Dim txtThu As String = CType(gvTenuredTMs.Rows(j).FindControl("gvtxtThuCount"), TextBox).Text
    '        Dim txtFri As String = CType(gvTenuredTMs.Rows(j).FindControl("gvtxtFriCount"), TextBox).Text
    '        Dim txtSat As String = CType(gvTenuredTMs.Rows(j).FindControl("gvtxtSatCount"), TextBox).Text
    '        Dim txtTotal As TextBox = CType(gvTenuredTMs.Rows(j).FindControl("gvtxtTotal"), TextBox)
    '        If IsInputNumeric(CType(gvTenuredTMs.Rows(j).FindControl("gvtxtWedCount"), TextBox).Text) Then
    '            If Not Convert.ToDouble(txtMon) = 0.0 Then
    '                txtTotal.Text = Convert.ToDouble(txtMon) + Convert.ToDouble(txtTue) + Convert.ToDouble(txtWed) + Convert.ToDouble(txtThu) + Convert.ToDouble(txtFri) + Convert.ToDouble(txtSat)
    '            End If
    '            lblValidation.Visible = False
    '        Else
    '            lblValidation.Visible = True
    '            lblValidation.Text = "not valid number"
    '            Exit Sub
    '        End If

    '    Next
    '    For j As Integer = 0 To GridView1.Rows.Count - 1
    '        Dim txtMon As String = CType(GridView1.Rows(j).FindControl("gvtxtMonCount"), TextBox).Text
    '        Dim txtTue As String = CType(GridView1.Rows(j).FindControl("gvtxtTueCount"), TextBox).Text
    '        Dim txtWed As String = CType(GridView1.Rows(j).FindControl("gvtxtWedCount"), TextBox).Text
    '        Dim txtThu As String = CType(GridView1.Rows(j).FindControl("gvtxtThuCount"), TextBox).Text
    '        Dim txtFri As String = CType(GridView1.Rows(j).FindControl("gvtxtFriCount"), TextBox).Text
    '        Dim txtSat As String = CType(GridView1.Rows(j).FindControl("gvtxtSatCount"), TextBox).Text
    '        Dim txtTotal As TextBox = CType(GridView1.Rows(j).FindControl("gvtxtTotal"), TextBox)
    '        If IsInputNumeric(CType(GridView1.Rows(j).FindControl("gvtxtWedCount"), TextBox).Text) Then
    '            If Not Convert.ToDouble(txtMon) = 0.0 Then
    '                txtTotal.Text = Convert.ToDouble(txtMon) + Convert.ToDouble(txtTue) + Convert.ToDouble(txtWed) + Convert.ToDouble(txtThu) + Convert.ToDouble(txtFri) + Convert.ToDouble(txtSat)
    '            End If
    '            lblValidation.Visible = False
    '        Else
    '            lblValidation.Visible = True
    '            lblValidation.Text = "not valid number"
    '            Exit Sub
    '        End If
    '    Next
    '    For j As Integer = 0 To GridView2.Rows.Count - 1
    '        Dim txtMon As String = CType(GridView2.Rows(j).FindControl("gvtxtMonCount"), TextBox).Text
    '        Dim txtTue As String = CType(GridView2.Rows(j).FindControl("gvtxtTueCount"), TextBox).Text
    '        Dim txtWed As String = CType(GridView2.Rows(j).FindControl("gvtxtWedCount"), TextBox).Text
    '        Dim txtThu As String = CType(GridView2.Rows(j).FindControl("gvtxtThuCount"), TextBox).Text
    '        Dim txtFri As String = CType(GridView2.Rows(j).FindControl("gvtxtFriCount"), TextBox).Text
    '        Dim txtSat As String = CType(GridView2.Rows(j).FindControl("gvtxtSatCount"), TextBox).Text
    '        Dim txtTotal As TextBox = CType(GridView2.Rows(j).FindControl("gvtxtTotal"), TextBox)
    '        If IsInputNumeric(CType(GridView2.Rows(j).FindControl("gvtxtWedCount"), TextBox).Text) Then
    '            If Not Convert.ToDouble(txtMon) = 0.0 Then
    '                txtTotal.Text = Convert.ToDouble(txtMon) + Convert.ToDouble(txtTue) + Convert.ToDouble(txtWed) + Convert.ToDouble(txtThu) + Convert.ToDouble(txtFri) + Convert.ToDouble(txtSat)
    '            End If
    '            lblValidation.Visible = False
    '        Else
    '            lblValidation.Visible = True
    '            lblValidation.Text = "not valid number"
    '            Exit Sub
    '        End If
    '    Next
    'End Sub

    'Protected Sub gvtxtThuCount_TextChanged(sender As Object, e As EventArgs)
    '    For j As Integer = 0 To gvTenuredTMs.Rows.Count - 1
    '        Dim txtMon As String = CType(gvTenuredTMs.Rows(j).FindControl("gvtxtMonCount"), TextBox).Text
    '        Dim txtTue As String = CType(gvTenuredTMs.Rows(j).FindControl("gvtxtTueCount"), TextBox).Text
    '        Dim txtWed As String = CType(gvTenuredTMs.Rows(j).FindControl("gvtxtWedCount"), TextBox).Text
    '        Dim txtThu As String = CType(gvTenuredTMs.Rows(j).FindControl("gvtxtThuCount"), TextBox).Text
    '        Dim txtFri As String = CType(gvTenuredTMs.Rows(j).FindControl("gvtxtFriCount"), TextBox).Text
    '        Dim txtSat As String = CType(gvTenuredTMs.Rows(j).FindControl("gvtxtSatCount"), TextBox).Text
    '        Dim txtTotal As TextBox = CType(gvTenuredTMs.Rows(j).FindControl("gvtxtTotal"), TextBox)
    '        If IsInputNumeric(CType(gvTenuredTMs.Rows(j).FindControl("gvtxtThuCount"), TextBox).Text) Then
    '            If Not Convert.ToDouble(txtMon) = 0.0 Then
    '                txtTotal.Text = Convert.ToDouble(txtMon) + Convert.ToDouble(txtTue) + Convert.ToDouble(txtWed) + Convert.ToDouble(txtThu) + Convert.ToDouble(txtFri) + Convert.ToDouble(txtSat)
    '            End If
    '            lblValidation.Visible = False
    '        Else
    '            lblValidation.Visible = True
    '            lblValidation.Text = "not valid number"
    '            Exit Sub
    '        End If
    '    Next
    '    For j As Integer = 0 To GridView1.Rows.Count - 1
    '        Dim txtMon As String = CType(GridView1.Rows(j).FindControl("gvtxtMonCount"), TextBox).Text
    '        Dim txtTue As String = CType(GridView1.Rows(j).FindControl("gvtxtTueCount"), TextBox).Text
    '        Dim txtWed As String = CType(GridView1.Rows(j).FindControl("gvtxtWedCount"), TextBox).Text
    '        Dim txtThu As String = CType(GridView1.Rows(j).FindControl("gvtxtThuCount"), TextBox).Text
    '        Dim txtFri As String = CType(GridView1.Rows(j).FindControl("gvtxtFriCount"), TextBox).Text
    '        Dim txtSat As String = CType(GridView1.Rows(j).FindControl("gvtxtSatCount"), TextBox).Text
    '        Dim txtTotal As TextBox = CType(GridView1.Rows(j).FindControl("gvtxtTotal"), TextBox)
    '        If IsInputNumeric(CType(GridView1.Rows(j).FindControl("gvtxtThuCount"), TextBox).Text) Then
    '            If Not Convert.ToDouble(txtMon) = 0.0 Then
    '                txtTotal.Text = Convert.ToDouble(txtMon) + Convert.ToDouble(txtTue) + Convert.ToDouble(txtWed) + Convert.ToDouble(txtThu) + Convert.ToDouble(txtFri) + Convert.ToDouble(txtSat)
    '            End If
    '            lblValidation.Visible = False
    '        Else
    '            lblValidation.Visible = True
    '            lblValidation.Text = "not valid number"
    '            Exit Sub
    '        End If
    '    Next
    '    For j As Integer = 0 To GridView2.Rows.Count - 1
    '        Dim txtMon As String = CType(GridView2.Rows(j).FindControl("gvtxtMonCount"), TextBox).Text
    '        Dim txtTue As String = CType(GridView2.Rows(j).FindControl("gvtxtTueCount"), TextBox).Text
    '        Dim txtWed As String = CType(GridView2.Rows(j).FindControl("gvtxtWedCount"), TextBox).Text
    '        Dim txtThu As String = CType(GridView2.Rows(j).FindControl("gvtxtThuCount"), TextBox).Text
    '        Dim txtFri As String = CType(GridView2.Rows(j).FindControl("gvtxtFriCount"), TextBox).Text
    '        Dim txtSat As String = CType(GridView2.Rows(j).FindControl("gvtxtSatCount"), TextBox).Text
    '        Dim txtTotal As TextBox = CType(GridView2.Rows(j).FindControl("gvtxtTotal"), TextBox)
    '        If IsInputNumeric(CType(GridView2.Rows(j).FindControl("gvtxtThuCount"), TextBox).Text) Then
    '            If Not Convert.ToDouble(txtMon) = 0.0 Then
    '                txtTotal.Text = Convert.ToDouble(txtMon) + Convert.ToDouble(txtTue) + Convert.ToDouble(txtWed) + Convert.ToDouble(txtThu) + Convert.ToDouble(txtFri) + Convert.ToDouble(txtSat)
    '            End If
    '            lblValidation.Visible = False
    '        Else
    '            lblValidation.Visible = True
    '            lblValidation.Text = "not valid number"
    '            Exit Sub
    '        End If
    '    Next
    'End Sub


    'Protected Sub gvtxtFriCount_TextChanged(sender As Object, e As EventArgs)
    '    For j As Integer = 0 To gvTenuredTMs.Rows.Count - 1
    '        Dim txtMon As String = CType(gvTenuredTMs.Rows(j).FindControl("gvtxtMonCount"), TextBox).Text
    '        Dim txtTue As String = CType(gvTenuredTMs.Rows(j).FindControl("gvtxtTueCount"), TextBox).Text
    '        Dim txtWed As String = CType(gvTenuredTMs.Rows(j).FindControl("gvtxtWedCount"), TextBox).Text
    '        Dim txtThu As String = CType(gvTenuredTMs.Rows(j).FindControl("gvtxtThuCount"), TextBox).Text
    '        Dim txtFri As String = CType(gvTenuredTMs.Rows(j).FindControl("gvtxtFriCount"), TextBox).Text
    '        Dim txtSat As String = CType(gvTenuredTMs.Rows(j).FindControl("gvtxtSatCount"), TextBox).Text
    '        Dim txtTotal As TextBox = CType(gvTenuredTMs.Rows(j).FindControl("gvtxtTotal"), TextBox)
    '        If IsInputNumeric(CType(gvTenuredTMs.Rows(j).FindControl("gvtxtFriCount"), TextBox).Text) Then
    '            If Not Convert.ToDouble(txtMon) = 0.0 Then
    '                txtTotal.Text = Convert.ToDouble(txtMon) + Convert.ToDouble(txtTue) + Convert.ToDouble(txtWed) + Convert.ToDouble(txtThu) + Convert.ToDouble(txtFri) + Convert.ToDouble(txtSat)
    '            End If
    '            lblValidation.Visible = False
    '        Else
    '            lblValidation.Visible = True
    '            lblValidation.Text = "not valid number"
    '            Exit Sub
    '        End If
    '    Next
    '    For j As Integer = 0 To GridView1.Rows.Count - 1
    '        Dim txtMon As String = CType(GridView1.Rows(j).FindControl("gvtxtMonCount"), TextBox).Text
    '        Dim txtTue As String = CType(GridView1.Rows(j).FindControl("gvtxtTueCount"), TextBox).Text
    '        Dim txtWed As String = CType(GridView1.Rows(j).FindControl("gvtxtWedCount"), TextBox).Text
    '        Dim txtThu As String = CType(GridView1.Rows(j).FindControl("gvtxtThuCount"), TextBox).Text
    '        Dim txtFri As String = CType(GridView1.Rows(j).FindControl("gvtxtFriCount"), TextBox).Text
    '        Dim txtSat As String = CType(GridView1.Rows(j).FindControl("gvtxtSatCount"), TextBox).Text
    '        Dim txtTotal As TextBox = CType(GridView1.Rows(j).FindControl("gvtxtTotal"), TextBox)
    '        If IsInputNumeric(CType(GridView1.Rows(j).FindControl("gvtxtFriCount"), TextBox).Text) Then
    '            If Not Convert.ToDouble(txtMon) = 0.0 Then
    '                txtTotal.Text = Convert.ToDouble(txtMon) + Convert.ToDouble(txtTue) + Convert.ToDouble(txtWed) + Convert.ToDouble(txtThu) + Convert.ToDouble(txtFri) + Convert.ToDouble(txtSat)
    '            End If
    '            lblValidation.Visible = False
    '        Else
    '            lblValidation.Visible = True
    '            lblValidation.Text = "not valid number"
    '            Exit Sub
    '        End If
    '    Next
    '    For j As Integer = 0 To GridView2.Rows.Count - 1
    '        Dim txtMon As String = CType(GridView2.Rows(j).FindControl("gvtxtMonCount"), TextBox).Text
    '        Dim txtTue As String = CType(GridView2.Rows(j).FindControl("gvtxtTueCount"), TextBox).Text
    '        Dim txtWed As String = CType(GridView2.Rows(j).FindControl("gvtxtWedCount"), TextBox).Text
    '        Dim txtThu As String = CType(GridView2.Rows(j).FindControl("gvtxtThuCount"), TextBox).Text
    '        Dim txtFri As String = CType(GridView2.Rows(j).FindControl("gvtxtFriCount"), TextBox).Text
    '        Dim txtSat As String = CType(GridView2.Rows(j).FindControl("gvtxtSatCount"), TextBox).Text
    '        Dim txtTotal As TextBox = CType(GridView2.Rows(j).FindControl("gvtxtTotal"), TextBox)
    '        If IsInputNumeric(CType(GridView2.Rows(j).FindControl("gvtxtFriCount"), TextBox).Text) Then
    '            If Not Convert.ToDouble(txtMon) = 0.0 Then
    '                txtTotal.Text = Convert.ToDouble(txtMon) + Convert.ToDouble(txtTue) + Convert.ToDouble(txtWed) + Convert.ToDouble(txtThu) + Convert.ToDouble(txtFri) + Convert.ToDouble(txtSat)
    '            End If
    '            lblValidation.Visible = False
    '        Else
    '            lblValidation.Visible = True
    '            lblValidation.Text = "not valid number"
    '            Exit Sub
    '        End If
    '    Next
    'End Sub

    'Protected Sub gvtxtSatCount_TextChanged(sender As Object, e As EventArgs)
    '    For j As Integer = 0 To gvTenuredTMs.Rows.Count - 1
    '        Dim txtMon As String = CType(gvTenuredTMs.Rows(j).FindControl("gvtxtMonCount"), TextBox).Text
    '        Dim txtTue As String = CType(gvTenuredTMs.Rows(j).FindControl("gvtxtTueCount"), TextBox).Text
    '        Dim txtWed As String = CType(gvTenuredTMs.Rows(j).FindControl("gvtxtWedCount"), TextBox).Text
    '        Dim txtThu As String = CType(gvTenuredTMs.Rows(j).FindControl("gvtxtThuCount"), TextBox).Text
    '        Dim txtFri As String = CType(gvTenuredTMs.Rows(j).FindControl("gvtxtFriCount"), TextBox).Text
    '        Dim txtSat As String = CType(gvTenuredTMs.Rows(j).FindControl("gvtxtSatCount"), TextBox).Text
    '        Dim txtTotal As TextBox = CType(gvTenuredTMs.Rows(j).FindControl("gvtxtTotal"), TextBox)
    '        If IsInputNumeric(CType(gvTenuredTMs.Rows(j).FindControl("gvtxtFriCount"), TextBox).Text) Then
    '            If Not Convert.ToDouble(txtMon) = 0.0 Then
    '                txtTotal.Text = Convert.ToDouble(txtMon) + Convert.ToDouble(txtTue) + Convert.ToDouble(txtWed) + Convert.ToDouble(txtThu) + Convert.ToDouble(txtFri) + Convert.ToDouble(txtSat)
    '            End If
    '            lblValidation.Visible = False
    '        Else
    '            lblValidation.Visible = True
    '            lblValidation.Text = "not valid number"
    '            Exit Sub
    '        End If
    '    Next
    '    For j As Integer = 0 To GridView1.Rows.Count - 1
    '        Dim txtMon As String = CType(GridView1.Rows(j).FindControl("gvtxtMonCount"), TextBox).Text
    '        Dim txtTue As String = CType(GridView1.Rows(j).FindControl("gvtxtTueCount"), TextBox).Text
    '        Dim txtWed As String = CType(GridView1.Rows(j).FindControl("gvtxtWedCount"), TextBox).Text
    '        Dim txtThu As String = CType(GridView1.Rows(j).FindControl("gvtxtThuCount"), TextBox).Text
    '        Dim txtFri As String = CType(GridView1.Rows(j).FindControl("gvtxtFriCount"), TextBox).Text
    '        Dim txtSat As String = CType(GridView1.Rows(j).FindControl("gvtxtSatCount"), TextBox).Text
    '        Dim txtTotal As TextBox = CType(GridView1.Rows(j).FindControl("gvtxtTotal"), TextBox)
    '        If IsInputNumeric(CType(GridView1.Rows(j).FindControl("gvtxtSatCount"), TextBox).Text) Then
    '            If Not Convert.ToDouble(txtMon) = 0.0 Then
    '                txtTotal.Text = Convert.ToDouble(txtMon) + Convert.ToDouble(txtTue) + Convert.ToDouble(txtWed) + Convert.ToDouble(txtThu) + Convert.ToDouble(txtFri) + Convert.ToDouble(txtSat)
    '            End If
    '            lblValidation.Visible = False
    '        Else
    '            lblValidation.Visible = True
    '            lblValidation.Text = "not valid number"
    '            Exit Sub
    '        End If
    '    Next
    '    For j As Integer = 0 To GridView2.Rows.Count - 1
    '        Dim txtMon As String = CType(GridView2.Rows(j).FindControl("gvtxtMonCount"), TextBox).Text
    '        Dim txtTue As String = CType(GridView2.Rows(j).FindControl("gvtxtTueCount"), TextBox).Text
    '        Dim txtWed As String = CType(GridView2.Rows(j).FindControl("gvtxtWedCount"), TextBox).Text
    '        Dim txtThu As String = CType(GridView2.Rows(j).FindControl("gvtxtThuCount"), TextBox).Text
    '        Dim txtFri As String = CType(GridView2.Rows(j).FindControl("gvtxtFriCount"), TextBox).Text
    '        Dim txtSat As String = CType(GridView2.Rows(j).FindControl("gvtxtSatCount"), TextBox).Text
    '        Dim txtTotal As TextBox = CType(GridView2.Rows(j).FindControl("gvtxtTotal"), TextBox)
    '        If IsInputNumeric(CType(GridView2.Rows(j).FindControl("gvtxtSatCount"), TextBox).Text) Then
    '            If Not Convert.ToDouble(txtMon) = 0.0 Then
    '                txtTotal.Text = Convert.ToDouble(txtMon) + Convert.ToDouble(txtTue) + Convert.ToDouble(txtWed) + Convert.ToDouble(txtThu) + Convert.ToDouble(txtFri) + Convert.ToDouble(txtSat)
    '            End If
    '            lblValidation.Visible = False
    '        Else
    '            lblValidation.Visible = True
    '            lblValidation.Text = "not valid number"
    '            Exit Sub
    '        End If
    '    Next
    'End Sub


    Private Function IsInputNumeric(input As String) As Boolean
        'If String.IsNullOrWhiteSpace(input) Then Return False
        If IsNumeric(input) Then Return True
        Dim parts() As String = input.Split("/"c)
        If parts.Length <> 2 Then Return False
        Return IsNumeric(parts(0)) AndAlso IsNumeric(parts(1))
    End Function

    Protected Sub btnSave2_Click(sender As Object, e As EventArgs) Handles btnSave2.Click
        Try
            SaveDLGTrackerData()
        Catch ex As Exception
            AlertMessage(ex.Message)
        End Try
    End Sub

    Protected Sub btnCancel_Click(sender As Object, e As EventArgs) Handles btnCancel.Click
        Try
            Reset()
        Catch ex As Exception
            AlertMessage(ex.Message)
        End Try
    End Sub

    Protected Sub btnLoadTotal_Click(sender As Object, e As EventArgs) Handles btnLoadTotal.Click
        Try
            If btnLoadTotal.Text.ToLower = "load total" Then
                LoadTotal()
            ElseIf btnLoadTotal.Text.ToLower = "edit" Then
                EnableFields()
            End If

        Catch ex As Exception
            AlertMessage(ex.Message)
        End Try

    End Sub

    Protected Sub btnCancel2_Click(sender As Object, e As EventArgs) Handles btnCancel2.Click
        Try
            Reset()
        Catch ex As Exception
            AlertMessage(ex.Message)
        End Try
    End Sub

    Protected Sub btnLoadTotal2_Click(sender As Object, e As EventArgs) Handles btnLoadTotal2.Click
        Try
            If btnLoadTotal.Text.ToLower = "load total" Then
                LoadTotal()
            ElseIf btnLoadTotal.Text.ToLower = "edit" Then
                EnableFields()
            End If

        Catch ex As Exception
            AlertMessage(ex.Message)
        End Try

    End Sub
End Class
