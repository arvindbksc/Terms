﻿Imports com.nss.DBAccess
Imports System.Data
Imports System.Text
Imports System.Globalization
Imports System.Web.Services

Partial Class WSR_IDPTraining
    Inherits System.Web.UI.Page

#Region "Properties"
    Property AgentID() As String
        Get
            Return ViewState("AgentID")
        End Get
        Set(ByVal value As String)
            ViewState("AgentID") = value
        End Set
    End Property
   
    Property CurrentDate() As Date
        Get
            Return ViewState("CurrentDate")
        End Get
        Set(ByVal value As Date)
            ViewState("CurrentDate") = value
        End Set
    End Property
    Property UserName() As String
        Get
            Return ViewState("UserName")
        End Get
        Set(ByVal value As String)
            ViewState("UserName") = value
        End Set
    End Property
    Property TrainingID() As String
        Get
            Return ViewState("TrainingID")
        End Get
        Set(ByVal value As String)
            ViewState("TrainingID") = value
        End Set
    End Property
    Property UserID() As String
        Get
            Return ViewState("UserID")
        End Get
        Set(ByVal value As String)
            ViewState("UserID") = value
        End Set
    End Property
    
#End Region

#Region "Load Function"
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        HumanMessage.Style.Item("visibility") = "hidden"
        If (Not Page.IsPostBack) Then
            lblReportName.CurrentPage = "IDP Training"
            AgentID = Session("Agentid")
            UserID = Session("UserID")
            Common.FillProcesses(CboProcess, AgentID)
            PanelReports.Controls.Add(Common.GetMenu(Request.Url, AgentID, Request.ApplicationPath))
            BindAgents()
            BindStatus()
            FillData()
        Else
            FillData()
        End If

    End Sub
#End Region

#Region "Functions"
    Private Function CalculateDays() As Integer
        Dim days As Integer
        Try
            Dim dt1 As DateTime = Convert.ToDateTime(UcDatePicker1.Text)

            Dim dt2 As DateTime = Convert.ToDateTime(UcDatePicker2.Text)


            Dim ts As TimeSpan = dt2.Subtract(dt1)

            If Convert.ToInt32(ts.Days) >= 0 Then

                txtDays.Text = (Environment.NewLine & Convert.ToInt32(ts.Days)) + 1

            End If
            OpenDialog()
            If days = 0 Then
                days = 1
            End If
            Return days
        Catch ex As Exception
            AlertMessage(ex.Message)
        End Try

    End Function

    Private Sub InsertAgentDetails()
        Dim db As DBAccess
        Try
            If Validation() = True Then
                db = New DBAccess("CRM")
                db.slDataAdd("TrainId", TrainingID)
                db.slDataAdd("TrainingName", txtTrainingName.Text.Trim())
                db.slDataAdd("agentid", ddlAgent.SelectedValue)
                db.slDataAdd("DateFrom", UcDatePicker1.yyyymmdd)
                db.slDataAdd("dateTo", UcDatePicker2.yyyymmdd)
                db.slDataAdd("Days", txtDays.Text.Trim())
                db.slDataAdd("hours", txtHours.Text.Trim())
                db.slDataAdd("status", ddlStatus.SelectedValue)
                db.slDataAdd("comments", txtComment.Text)
                db.slDataAdd("filledBy", AgentID)
                db.slDataAdd("modifyBy", AgentID)
                db.slDataAdd("processId", Convert.ToInt32(CboProcess.SelectedItem.Value))
                db.Executeproc("usp_WSR_SET_IDPTraining")
                db = Nothing
                FillData()
            Else
                OpenDialog()
            End If
        Catch ex As Exception
            Throw ex
        End Try
    End Sub

    Private Sub OpenDialog()

        Dim str As String
        str = "$('#DialogBackground').height($(document).height()-5);$('#DialogBackground').width($(window).width());$('#DialogBackground').css('visibility','visible');$('#PanelIDPForm').css('visibility','visible');" & _
        " $('#PanelIDPForm').css('left',($(window).width() - $('#PanelIDPForm').width())/2); "
        ScriptManager.RegisterStartupScript(Page, Page.GetType(), "Movedialog", str, True)
    End Sub

    '<WebMethod> _
    'Public Shared Sub LoadData(ByVal DateFrom As String, ByVal DateTo As String, ByRef gv As GridView)
    '    Dim fun As WSR_IDPTraining = New WSR_IDPTraining()
    '    fun.FillData(DateFrom, DateTo, gv)
    'End Sub

    Private Sub FillData()
        Dim db As New DBAccess("CRM")
        Try
            Dim ds As DataSet = New DataSet
            db.slDataAdd("processId", CboProcess.SelectedValue)
            ds = db.ReturnDataset("usp_WSR_GET_IDPTrainings", True)
            db = Nothing
            lblMessage.Visible = False
            gvIDPTraining.DataSource = ds.Tables(0)
            gvIDPTraining.DataBind()
            Dim count = ds.Tables(1).Rows(0).Item("No Of Agents in Training")
            If ds.Tables(0).Rows.Count > 0 Then
                btnAddNewTraining.Visible = False
                lblCount.Visible = True
                lblCount.Text = "Number of People in Training:" + count.ToString()
            Else
                btnAddNewTraining.Visible = True
                lblCount.Visible = False
            End If
            For Each row As GridViewRow In gvIDPTraining.Rows
                If row.RowType = DataControlRowType.DataRow Then
                    Dim EndDate = TryCast(row.Cells(4).FindControl("lbldateto"), Label).Text
                    Dim Status = TryCast(row.Cells(7).FindControl("hdnStatus"), HiddenField).Value
                    If EndDate = Today And Status = 8 Then
                        lblMessage.Visible = True
                        lblMessage.Text = "Please Update Status of highlighted Rows Today after Completion Of Training "
                        row.BackColor = Drawing.Color.Orange
                        TryCast(row.Cells(9).FindControl("imgDelete"), ImageButton).Visible = True
                        TryCast(row.Cells(9).FindControl("imgEdit"), ImageButton).Visible = True
                        TryCast(row.Cells(7).FindControl("lblstatus"), Label).ForeColor = Drawing.Color.DarkBlue
                    ElseIf Status = 7 Then
                        TryCast(row.Cells(9).FindControl("imgDelete"), ImageButton).Visible = False
                        TryCast(row.Cells(9).FindControl("imgEdit"), ImageButton).Visible = False
                        TryCast(row.Cells(7).FindControl("lblstatus"), Label).ForeColor = Drawing.Color.Green
                    End If

                End If
            Next
            Dim previousDate As DateTime = DateTime.Now.Date.AddDays(-5)
            lblInfo.Text = "* You can fill training for " + Today + " only"
            Common.hideDeleteOption(gvIDPTraining)
        Catch ex As Exception
            Throw ex
            Exit Sub
        End Try
    End Sub

    Private Sub BindAgents()
        Try
            Dim dt As New DataTable
            Dim db As New DBAccess("Report")
            db.slDataAdd("processid", CboProcess.SelectedItem.Value)
            db.slDataAdd("groupby", 3)
            dt = db.ReturnTable("usp_GetProcessAgents", , True)
            db = Nothing
            ddlAgent.DataTextField = "Agent Name"
            ddlAgent.DataValueField = "AgentID"
            ddlAgent.DataSource = dt
            ddlAgent.DataBind()
            ddlAgent.Items.Insert(0, New ListItem("--select--", "0"))
            ddlAgent.SelectedIndex = 0
        Catch ex As Exception
            Throw ex
        End Try
        

    End Sub

    Private Sub BindStatus()
        Try
            Dim dt As New DataTable
            Dim db As New DBAccess("CRM")
            db.slDataAdd("KPAID", 17)
            db.slDataAdd("ProcessID", CboProcess.SelectedValue)
            dt = db.ReturnTable("usp_WSR_getStatus_fromKPA", , True)
            db = Nothing
            ddlStatus.DataTextField = "StatusText"
            ddlStatus.DataValueField = "StatusID"
            ddlStatus.DataSource = dt
            ddlStatus.DataBind()
            ddlStatus.Items.Insert(0, New ListItem("--select--", "0"))
            ddlStatus.SelectedIndex = 0
        Catch ex As Exception
            AlertMessage(ex.Message)
        End Try
    End Sub

    Private Sub Reset()
        Try
            ddlAgent.SelectedValue = "0"
            'Dim newDate = DateTime.ParseExact(dpSelectDate.yyyymmdd, "yyyyMMdd", CultureInfo.InvariantCulture)
            UcDatePicker1.value = Today
            UcDatePicker2.value = Today
            txtComment.Text = ""
            txtDays.Text = CalculateDays()
            txtHours.Text = ""
            ddlStatus.SelectedValue = "0"
            txtTrainingName.Text = ""
        Catch ex As Exception
            AlertMessage(ex.Message)
        End Try
    End Sub

    Private Function IsInputNumeric(input As String) As Boolean
        'If String.IsNullOrWhiteSpace(input) Then Return False
        If IsNumeric(input) Then Return True
        Dim parts() As String = input.Split("/"c)
        If parts.Length <> 2 Then Return False
        Return IsNumeric(parts(0)) AndAlso IsNumeric(parts(1))
    End Function

    Private Function validdate(ByVal selecteddate As DateTime) As Boolean
        Dim date1, date2 As Date
        date1 = Date.Parse(UcDatePicker1.Text)
        date2 = Date.Parse(UcDatePicker2.Text)
        If (DateTime.Compare(date1, date2) > 0) Then
            Return False
        Else : Return True
        End If
    End Function

    Private Function Validation() As Boolean
        Dim flag As Boolean = True

        If ddlAgent.SelectedValue = "0" Then
            lblIsValidInput.Visible = True
            lblIsValidInput.Text = "Please select Agent"
            flag = False
            ddlAgent.BorderColor = Drawing.Color.Red
            OpenDialog()
            Return flag
        Else
            lblIsValidInput.Visible = False
            ddlAgent.BorderColor = Nothing
        End If

        If txtTrainingName.Text = "" Then
            lblIsValidInput.Visible = True
            lblIsValidInput.Text = "Please Enter Training Name"
            flag = False
            txtTrainingName.BorderColor = Drawing.Color.Red
            OpenDialog()
            Return flag
        Else
            lblIsValidInput.Visible = False
            txtTrainingName.BorderColor = Nothing
        End If

        'If txtDays.Text = "" Then
        '    lblIsValidInput.Visible = True
        '    lblIsValidInput.Text = "Please Enter Days"
        '    flag = False
        '    txtDays.BorderColor = Drawing.Color.Red
        '    OpenDialog()
        '    Return flag
        'Else
        '    txtDays.BorderColor = Nothing
        'End If

        If txtHours.Text = "" Then
            lblIsValidInput.Visible = True
            lblIsValidInput.Text = "Please Enter Hours"
            flag = False
            txtHours.BorderColor = Drawing.Color.Red
            OpenDialog()
            Return flag
        Else
            lblIsValidInput.Visible = False
            txtHours.BorderColor = Nothing
        End If

        Dim hoursCount As Integer = (Convert.ToInt32(txtDays.Text) * 9)
        If Convert.ToInt32(txtHours.Text) > hoursCount Then
            lblIsValidInput.Visible = True
            lblIsValidInput.Text = "hours should be within " + hoursCount.ToString + ""
            flag = False
            OpenDialog()
            txtHours.BorderColor = Drawing.Color.Red
            Return flag
        Else
            lblIsValidInput.Visible = False
            txtHours.BorderColor = Nothing
        End If

        If ddlStatus.SelectedValue = "0" Then
            lblIsValidInput.Visible = True
            lblIsValidInput.Text = "Please select Status"
            flag = False
            ddlStatus.BorderColor = Drawing.Color.Red
            OpenDialog()
            Return flag
        Else
            lblIsValidInput.Visible = False
            ddlStatus.BorderColor = Nothing
        End If

        Dim ToDate = DateTime.ParseExact(UcDatePicker2.yyyymmdd, "yyyyMMdd", CultureInfo.InvariantCulture)
        Dim FromDate = DateTime.ParseExact(UcDatePicker1.yyyymmdd, "yyyyMMdd", CultureInfo.InvariantCulture)
        If FromDate > Today Then
            If ddlStatus.SelectedValue = 7 Or ddlStatus.SelectedValue = 8 Then
                lblIsValidInput.Visible = True
                lblIsValidInput.Text = "Status selected is not correct"
                flag = False
                ddlStatus.BorderColor = Drawing.Color.Red
                OpenDialog()
            Else
                lblIsValidInput.Visible = False
                ddlStatus.BorderColor = Nothing
            End If
        ElseIf ToDate > Today Then
            If ddlStatus.SelectedValue = 7 Or ddlStatus.SelectedValue = 9 Then
                lblIsValidInput.Visible = True
                lblIsValidInput.Text = "Status selected is not correct"
                flag = False
                ddlStatus.BorderColor = Drawing.Color.Red
                OpenDialog()
            Else
                lblIsValidInput.Visible = False
                ddlStatus.BorderColor = Nothing
            End If
        End If
        Return flag
    End Function

#End Region

#Region "Events"
    Protected Sub UcDatePicker1_Changed(ByVal sender As Object, ByVal e As System.EventArgs) Handles UcDatePicker1.Changed
        Try
            Dim selectedDate As DateTime = CDate(UcDatePicker1.Text)
            Dim previousDate As DateTime = DateTime.Now.Date.AddDays(-5)
            If (selectedDate < Today) Then
                lblIsValidInput.Visible = True
                lblIsValidInput.Text = "Date not in valid range"
                UcDatePicker1.value = Today
                CalculateDays()
                Exit Sub
            ElseIf Not validdate(UcDatePicker1.value) Then
                lblIsValidInput.Visible = True
                lblIsValidInput.Text = "Date not in valid range"
                UcDatePicker1.value = Today
                CalculateDays()
                Exit Sub
            Else
                lblIsValidInput.Visible = False
                CalculateDays()
            End If
        Catch ex As Exception
            AlertMessage(ex.Message)
        End Try
    
    End Sub

    Protected Sub UcDatePicker2_Changed(ByVal sender As Object, ByVal e As System.EventArgs) Handles UcDatePicker2.Changed
        If validdate(UcDatePicker2.value) Then
            CalculateDays()
            lblIsValidInput.Visible = False
        Else
            lblIsValidInput.Visible = True
            lblIsValidInput.Text = "Date not in valid range"
            UcDatePicker2.value = Today
            CalculateDays()
        End If
    End Sub


    Protected Sub btnSave_Click(sender As Object, e As EventArgs) Handles btnSave.Click
        Try
            If Validation() = True Then
                lblIsValidInput.Text = ""
                ddlAgent.BorderColor = Nothing
                txtTrainingName.BorderColor = Nothing
                txtDays.BorderColor = Nothing
                txtHours.BorderColor = Nothing
                ddlStatus.BorderColor = Nothing
                If btnSave.Text = "Save" Then
                    InsertAgentDetails()
                    SuccessMessage("Added Successfully")
                Else
                    InsertAgentDetails()
                    SuccessMessage("Updated Successfully")
                End If
            Else
                OpenDialog()
            End If
        Catch ex As Exception
            AlertMessage(ex.Message)
        End Try
    End Sub

    


    Protected Sub gvIDPTraining_RowCommand(sender As Object, e As GridViewCommandEventArgs) Handles gvIDPTraining.RowCommand
        Try

            If e.CommandName.ToLower = "edit" Then
                btnSave.Text = "Update"
                Dim index As Integer = Convert.ToInt32(e.CommandArgument)
                lblHeader.Text = "UPDATE IDP TRAINING : " + CType(gvIDPTraining.Rows(index).FindControl("hdnTrainId"), HiddenField).Value + ""
                TrainingID = CType(gvIDPTraining.Rows(index).FindControl("hdnTrainId"), HiddenField).Value
                ddlAgent.SelectedValue = CType(gvIDPTraining.Rows(index).FindControl("lblAgentID"), Label).Text
                txtTrainingName.Text = CType(gvIDPTraining.Rows(index).FindControl("lblTrainingName"), Label).Text
                UcDatePicker1.value = CType(gvIDPTraining.Rows(index).FindControl("lbldatefrm"), Label).Text
                UcDatePicker2.value = CType(gvIDPTraining.Rows(index).FindControl("lbldateto"), Label).Text
                txtDays.Text = CType(gvIDPTraining.Rows(index).FindControl("lblDays"), Label).Text
                txtHours.Text = CType(gvIDPTraining.Rows(index).FindControl("lblHours"), Label).Text
                txtComment.Text = CType(gvIDPTraining.Rows(index).FindControl("lblcmts"), Label).Text
                ddlStatus.SelectedValue = CType(gvIDPTraining.Rows(index).FindControl("hdnStatus"), HiddenField).Value
                ddlAgent.Enabled = False
                txtTrainingName.Enabled = False
                pnlDateFrom.Enabled = False
                OpenDialog()
            End If
            If e.CommandName.ToLower = "addnew" Then
                btnSave.Text = "Save"
                lblHeader.Text = "ADD NEW TRAINING"
                TrainingID = String.Empty
                ddlAgent.Enabled = True
                txtTrainingName.Enabled = True
                pnlDateFrom.Enabled = True
                Reset()
                OpenDialog()
            End If
        Catch ex As Exception
            AlertMessage(ex.Message)
        End Try
    End Sub

    Protected Sub gvIDPTraining_SelectedIndexChanged(sender As Object, e As EventArgs) Handles gvIDPTraining.SelectedIndexChanged

    End Sub

    Protected Sub CboProcess_SelectedIndexChanged(sender As Object, e As EventArgs) Handles CboProcess.SelectedIndexChanged
        Try
            FillData()
            BindAgents()
            BindStatus()
        Catch ex As Exception
            AlertMessage(ex.Message)
        End Try
    End Sub

    Protected Sub gvIDPTraining_RowEditing(sender As Object, e As GridViewEditEventArgs) Handles gvIDPTraining.RowEditing

    End Sub

    Protected Sub gvIDPTraining_RowDeleting(sender As Object, e As GridViewDeleteEventArgs) Handles gvIDPTraining.RowDeleting
        Try
            Dim db As DBAccess = New DBAccess("CRM")
            db.slDataAdd("ProcessID", CboProcess.SelectedItem.Value)
            db.slDataAdd("TrainingID", CType(gvIDPTraining.Rows(e.RowIndex).FindControl("hdnTrainId"), HiddenField).Value)
            db.slDataAdd("modifyBy", AgentID)
            'db.slDataAdd("ClosingRemarks", hdnRemarks.Value)
            db.Executeproc("usp_WSR_DeleteTraining")
            db = Nothing
            AlertMessage("Record Closed Successfully")
            FillData()
        Catch ex As Exception
            AlertMessage(ex.Message)
        End Try

    End Sub

    Protected Sub gvIDPTraining_RowUpdating(sender As Object, e As GridViewUpdateEventArgs) Handles gvIDPTraining.RowUpdating

    End Sub

    

    Protected Sub btnAddNewTraining_Click(sender As Object, e As EventArgs) Handles btnAddNewTraining.Click
        TrainingID = String.Empty
        ddlAgent.Enabled = True
        txtTrainingName.Enabled = True
        pnlDateFrom.Enabled = True
        Reset()
        OpenDialog()
        lblHeader.Text = "ADD NEW IDP TRAINING"
    End Sub

    Protected Sub txtHours_TextChanged(sender As Object, e As EventArgs) Handles txtHours.TextChanged
        Try
            If IsInputNumeric(txtHours.Text) Then
                lblIsValidInput.Visible = False
                OpenDialog()
            Else
                lblIsValidInput.Visible = True
                lblIsValidInput.Text = "not valid number"
                OpenDialog()
            End If
        Catch ex As Exception
            AlertMessage(ex.Message)
        End Try
    End Sub


#End Region

#Region "Utility"
    Private Sub AlertMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMFail"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub

    Private Sub SuccessMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMSuccess"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub
#End Region

    'Protected Sub btnExcel_Click(sender As Object, e As ImageClickEventArgs) Handles btnExcel.Click
    '    Try
    '        GridViewExportUtil.Export(lblReportName.CurrentPage & ".xls", Me.gvIDPTraining)
    '    Catch ex As Exception

    '    End Try
    'End Sub

    Protected Sub btnFavourite_Click(sender As Object, e As ImageClickEventArgs) Handles btnFavourite.Click
        Try
            Common.AddToFav(AgentID, "IDP Training")
            SuccessMessage("Report has been added to your favourite list")
        Catch ex As Exception
            AlertMessage(ex.Message)
        End Try
    End Sub

End Class






 