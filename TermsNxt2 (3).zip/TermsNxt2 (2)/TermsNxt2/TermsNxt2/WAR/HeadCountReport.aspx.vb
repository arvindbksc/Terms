﻿Imports com.nss.DBAccess
Imports System.Data
Imports System.Data.SqlClient
Imports System.Web.UI.WebControls
Imports System.Web.UI.WebControls.GridView
Imports System.Windows.Forms
Imports System.Linq



Partial Class WSR_HeadCountReport
    Inherits System.Web.UI.Page

#Region "--- Properties ---"
    Property CurrentDate() As Date
        Get
            Return ViewState("CurrentDate")
        End Get
        Set(ByVal value As Date)
            ViewState("CurrentDate") = value
        End Set
    End Property
    Property SupervisorID() As String
        Get
            Return ViewState("SupervisorID")
        End Get
        Set(ByVal value As String)
            ViewState("SupervisorID") = value
        End Set
    End Property
    Property UserID() As String
        Get
            Return ViewState("UserID")
        End Get
        Set(ByVal value As String)
            ViewState("UserID") = value
        End Set
    End Property
    Property AgentID() As String
        Get
            Return ViewState("AgentID")
        End Get
        Set(ByVal value As String)
            ViewState("AgentID") = value
        End Set
    End Property
    Property UserName() As String
        Get
            Return ViewState("username")
        End Get
        Set(ByVal value As String)
            ViewState("username") = value
        End Set
    End Property
    Property ProcessID() As Integer
        Get
            Return ViewState("ProcessID")
        End Get
        Set(ByVal value As Integer)
            ViewState("ProcessID") = value
            Session("ProcessID") = value
        End Set
    End Property
    Property ProcessName() As String
        Get
            Return ViewState("ProcessName")
        End Get
        Set(ByVal value As String)
            ViewState("ProcessName") = value
        End Set
    End Property
#End Region


#Region "--- Load ---"
    Private Sub LoadData()
        Dim db As New DBAccess("CRM")
        Dim dr As DataRow = db.ReturnRow("SELECT GetDate() AS CurrentDate", False)
        CurrentDate = dr("currentDate")
        db = Nothing

        Common.FillProcesses(cboProcess, AgentID)
        FillCommonFilters()
    End Sub
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        HumanMessage.Style.Item("visibility") = "hidden"
        If Not Me.IsPostBack Then
            AgentID = Session("Agentid")
            LoadData()
            PanelReports.Controls.Add(Common.GetMenu(Request.Url, AgentID, Request.ApplicationPath))
            lblReportName.CurrentPage = " Head Count Report "
        End If
    End Sub
#End Region
    Dim dt As DataTable


#Region "--- Function---"
    Private Sub FillCommonFilters()
        Dim db As New DBAccess
        Dim dt As DataTable = db.ReturnTable("select * from tbl_Reports_DatePeriods")
        db = Nothing
        Dim dr As DataRow = dt.NewRow
        dr(0) = 10
        dr(1) = "Between"
        dt.Rows.Add(dr)
    End Sub

    Private Sub GetReport(ByVal showdetail As Boolean, ByVal startDate As String, ByVal endDate As String)
        Try
            Dim db As New DBAccess("CRM")
            Dim dt As DataTable
            Dim Ds As DataSet
            db.slDataAdd("ProcessId", cboProcess.SelectedValue)
            db.slDataAdd("StartDate", startDate)
            db.slDataAdd("Enddate", endDate)
            db.slDataAdd("ShowDetail", showdetail)
            Ds = db.ReturnDataset("usp_WSR_GET_HeadCountReport", True)
            db = Nothing
            dt = Ds.Tables(0)
            If (showdetail = True) Then
                HeadCountReport.Visible = True
                pnltable.Visible = True
                HeadCountReport.DataSource = dt
                HeadCountReport.DataBind()
                Dim NoBillcount = (From dtrow In dt Where dtrow("IsBillable") = "--").Count
                Dim InProdcount = (From dtrow In dt Where dtrow("IsInProduction") = "Yes").Count
                spnttlHeadCount.InnerHtml = dt.Rows.Count
                spanHeadCount.InnerHtml = InProdcount
                spanNonBillCount.InnerHtml = NoBillcount

            Else
                pnltable.Visible = False
                HeadCountReport.Visible = False
                HeadCountGroupWise.DataSource = dt
                HeadCountGroupWise.DataBind()


            End If

        Catch ex As Exception
            '  AlertMessage(ex.ToString)
        End Try
    End Sub

    
#End Region



#Region "--- Utility ---"
    Private Sub AlertMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMFail"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub

    Private Sub SuccessMessage(ByVal msg As String)
        lblHumanMessage.Text = msg
        HumanMessage.CssClass = "HMSuccess"
        HumanMessage.Style.Item("visibility") = "visible"
    End Sub


#End Region


    Protected Sub HeadCountReport_RowDataBound(sender As Object, e As GridViewRowEventArgs) Handles HeadCountReport.RowDataBound

    End Sub

    Protected Sub cboProcess_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboProcess.SelectedIndexChanged
        ProcessID = cboProcess.SelectedValue
        ProcessName = cboProcess.SelectedItem.Text
        Dim startdate As String = txtStartDate.Text
        Dim enddate As String = txtEndDate.Text
        GetReport(0, startdate, enddate)

    End Sub

    Protected Sub HeadCountGroupWise_RowCommand(sender As Object, e As GridViewCommandEventArgs) Handles HeadCountGroupWise.RowCommand
        If (e.CommandName = "ShowDetail") Then
            Dim index As Integer = Convert.ToInt32(e.CommandArgument)
            Dim row As GridViewRow = HeadCountGroupWise.Rows(index)
            Dim startDte As String = CType(row.FindControl("hdnDate"), HiddenField).Value
            GetReport(1, startDte, txtEndDate.Text)
        End If
    End Sub

 
    Protected Sub txtEndDate_Changed(sender As Object, e As EventArgs) Handles txtEndDate.Changed
        Dim startdate As String = txtStartDate.Text
        Dim enddate As String = txtEndDate.Text
        GetReport(0, startdate, enddate)
    End Sub

    Protected Sub txtStartDate_Changed(sender As Object, e As EventArgs) Handles txtStartDate.Changed
        Dim startdate As String = txtStartDate.Text
        Dim enddate As String = txtEndDate.Text
        GetReport(0, startdate, enddate)
    End Sub

    Protected Sub ImageButton1_Click(sender As Object, e As ImageClickEventArgs) Handles ImageButton1.Click
        GridViewExportUtil.Export(lblReportName.CurrentPage & ".xls", Me.HeadCountReport)
    End Sub

    Protected Sub imgfav_Click(sender As Object, e As ImageClickEventArgs) Handles imgfav.Click
        Common.AddToFav(AgentID, "TAT Report")
        SuccessMessage("Report has been added to your favorite list")
    End Sub
End Class
