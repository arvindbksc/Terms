﻿Imports System.Text
Imports System.Security.Cryptography
Imports System.IO
''' <summary>
''' Utility class for handling encryption and hashing
''' </summary>
''' <remarks></remarks>
''' 
Namespace TermsNxt2

    Public Class RC4


        ''' <summary>
        ''' 
        ''' </summary>
        ''' <param name="clearText"></param>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Shared Function EncryptURL(clearText As String) As String
            Dim strEncryptionKey As String = System.Configuration.ConfigurationManager.AppSettings("EncryptionKey")
            'Dim EncryptionKey As String = "MAKV2SPBNI99212"
            Dim clearBytes As Byte() = Encoding.Unicode.GetBytes(clearText)
            Using encryptor As Aes = Aes.Create()
                Dim pdb As New Rfc2898DeriveBytes(strEncryptionKey, New Byte() {&H49, &H76, &H61, &H6E, &H20, &H4D,
             &H65, &H64, &H76, &H65, &H64, &H65,
             &H76})
                encryptor.Key = pdb.GetBytes(32)
                encryptor.IV = pdb.GetBytes(16)
                Using ms As New MemoryStream()
                    Using cs As New CryptoStream(ms, encryptor.CreateEncryptor(), CryptoStreamMode.Write)
                        cs.Write(clearBytes, 0, clearBytes.Length)
                        cs.Close()
                    End Using
                    clearText = Convert.ToBase64String(ms.ToArray())
                End Using
            End Using
            Return clearText

        End Function
        ''' <summary>
        ''' Returns an encrypted string based on the provided message and passkey
        ''' </summary>
        ''' <param name="message"></param>
        ''' <param name="key"></param>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Shared Function Encrypt(ByVal message As String, ByVal key As String) As String

            If message Is Nothing OrElse message.Length = 0 Then
                Throw New ArgumentNullException("message")
            End If

            If key Is Nothing OrElse key.Length = 0 Then
                Throw New ArgumentNullException("key")
            End If

            Dim returnValue As String = String.Empty

            returnValue = EnDeCrypt(message, key)
            'returnValue = StringToHex(returnValue)

            Return returnValue

        End Function

        ''' <summary>
        ''' Returns a decrypted string based on the provided message and passkey
        ''' </summary>
        ''' <param name="message"></param>
        ''' <param name="key"></param>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Shared Function Decrypt(ByVal message As String, ByVal key As String) As String

            If message Is Nothing OrElse message.Length = 0 Then
                Throw New ArgumentNullException("message")
            End If

            If key Is Nothing OrElse key.Length = 0 Then
                Throw New ArgumentNullException("key")
            End If

            Dim returnValue As String = String.Empty

            returnValue = HexToString(message)
            returnValue = EnDeCrypt(returnValue, key)

            Return returnValue

        End Function

        ''' <summary>
        ''' RC4 encryption method
        ''' </summary>
        ''' <param name="message"></param>
        ''' <param name="password"></param>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Private Shared Function EnDeCrypt(ByVal message As String, ByVal password As String) As String

            Dim i As Integer = 0
            Dim j As Integer = 0
            Dim cipher As New StringBuilder
            Dim returnCipher As String = String.Empty

            Dim sbox As Integer() = New Integer(256) {}
            Dim key As Integer() = New Integer(256) {}

            Dim intLength As Integer = password.Length

            Dim a As Integer = 0
            While a <= 255

                Dim ctmp As Char = (password.Substring((a Mod intLength), 1).ToCharArray()(0))

                key(a) = Microsoft.VisualBasic.Strings.Asc(ctmp)
                sbox(a) = a
                System.Math.Max(System.Threading.Interlocked.Increment(a), a - 1)
            End While

            Dim x As Integer = 0

            Dim b As Integer = 0
            While b <= 255
                x = (x + sbox(b) + key(b)) Mod 256
                Dim tempSwap As Integer = sbox(b)
                sbox(b) = sbox(x)
                sbox(x) = tempSwap
                System.Math.Max(System.Threading.Interlocked.Increment(b), b - 1)
            End While

            a = 1

            While a <= message.Length

                Dim itmp As Integer = 0

                i = (i + 1) Mod 256
                j = (j + sbox(i)) Mod 256
                itmp = sbox(i)
                sbox(i) = sbox(j)
                sbox(j) = itmp

                Dim k As Integer = sbox((sbox(i) + sbox(j)) Mod 256)

                Dim ctmp As Char = message.Substring(a - 1, 1).ToCharArray()(0)

                itmp = Asc(ctmp)

                Dim cipherby As Integer = itmp Xor k

                cipher.Append(Chr(cipherby))
                System.Math.Max(System.Threading.Interlocked.Increment(a), a - 1)
            End While

            returnCipher = cipher.ToString
            cipher.Length = 0

            Return returnCipher

        End Function

        ''' <summary>
        ''' Turns the provided string value into a hex value (for encryption)
        ''' </summary>
        ''' <param name="message"></param>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Private Shared Function StringToHex(ByVal message As String) As String

            Dim index As Long
            Dim maxIndex As Long
            Dim hexSb As New StringBuilder
            Dim hexOut As String = String.Empty

            maxIndex = Len(message)

            For index = 1 To maxIndex
                hexSb.Append(Right("0" & Hex(Asc(Mid(message, CInt(index), 1))), 2))
            Next

            hexOut = hexSb.ToString
            hexSb.Length = 0

            Return hexOut

        End Function

        ''' <summary>
        ''' Turns the provided hex value into a string value (for decryption)
        ''' </summary>
        ''' <param name="hex"></param>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Private Shared Function HexToString(ByVal hex As String) As String

            Dim index As Long
            Dim maxIndex As Long
            Dim sb As New StringBuilder
            Dim returnString As String = String.Empty

            maxIndex = Len(hex)

            For index = 1 To maxIndex Step 2
                sb.Append(Chr(CInt("&h" & Mid(hex, CInt(index), 2))))
            Next

            returnString = sb.ToString
            sb.Length = 0

            Return returnString

        End Function

    End Class
End Namespace