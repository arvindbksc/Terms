﻿Imports Microsoft.VisualBasic
Imports System
Imports System.Data
Imports System.Configuration
Imports System.IO
Imports System.Web
Imports System.Web.Security
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports System.Web.UI.WebControls.WebParts
Imports System.Web.UI.HtmlControls
Namespace TermsNxt2
    Public Class GridViewExportUtil
        Public Shared Sub PrintPreview(ByVal gv As Panel)
            ' HttpContext.Current.Response.Clear()
            'HttpContext.Current.Response.AddHeader("content-disposition", String.Format("attachment; filename={0}", fileName))
            'HttpContext.Current.Response.ContentType = "application/ms-excel"
            Dim sw As StringWriter = New StringWriter
            Dim htw As HtmlTextWriter = New HtmlTextWriter(sw)
            '  Create a form to contain the grid
            'Dim table As Table = New Table
            'table.GridLines = gv.GridLines
            ''  add the header row to the table
            'If (Not (gv.HeaderRow) Is Nothing) Then
            '    GridViewExportUtil.PrepareControlForExport(gv.HeaderRow)
            '    table.Rows.Add(gv.HeaderRow)
            'End If
            ''  add each of the data rows to the table
            'For Each row As GridViewRow In gv.Rows
            '    GridViewExportUtil.PrepareControlForExport(row)
            '    table.Rows.Add(row)
            'Next
            ''  add the footer row to the table
            'If (Not (gv.FooterRow) Is Nothing) Then
            '    GridViewExportUtil.PrepareControlForExport(gv.FooterRow)
            '    table.Rows.Add(gv.FooterRow)
            'End If
            '  render the table into the htmlwriter
            GridViewExportUtil.PrepareControlForExport(gv)
            gv.RenderControl(htw)
            '  render the htmlwriter into the response

            'HttpContext.Current.Response.Write(sw.ToString)
            'HttpContext.Current.Response.End()
        End Sub
        Public Shared Sub Export(ByVal fileName As String, ByVal gv As GridView)
            HttpContext.Current.Response.Clear()
            HttpContext.Current.Response.AddHeader("content-disposition", String.Format("attachment; filename={0}", fileName))
            HttpContext.Current.Response.ContentType = "application/ms-excel"
            HttpContext.Current.Response.Charset = "utf-8"
            HttpContext.Current.Response.ContentEncoding = System.Text.Encoding.GetEncoding("windows-1250")
            Dim sw As StringWriter = New StringWriter
            Dim htw As HtmlTextWriter = New HtmlTextWriter(sw)
            '  Create a form to contain the grid
            Dim table As Table = New Table
            table.GridLines = 3
            '  add the header row to the table
            If (Not (gv.HeaderRow) Is Nothing) Then
                GridViewExportUtil.PrepareControlForExport(gv.HeaderRow)
                table.Rows.Add(gv.HeaderRow)
            End If
            '  add each of the data rows to the table
            For Each row As GridViewRow In gv.Rows
                GridViewExportUtil.PrepareControlForExport(row)
                table.Rows.Add(row)
            Next
            '  add the footer row to the table
            If (Not (gv.FooterRow) Is Nothing) Then
                GridViewExportUtil.PrepareControlForExport(gv.FooterRow)
                table.Rows.Add(gv.FooterRow)
            End If
            '  render the table into the htmlwriter
            table.RenderControl(htw)
            '  render the htmlwriter into the response
            HttpContext.Current.Response.Write(sw.ToString)
            HttpContext.Current.Response.End()
        End Sub

        ' Replace any of the contained controls with literals
        Private Shared Sub PrepareControlForExport(ByVal control As Control)
            Dim i As Integer = 0

            Do While (i < control.Controls.Count)
                Dim current As Control = control.Controls(i)
                'If current.Visible = False Then
                '    control.Controls.Remove(current)
                '    i += 1
                '    Continue Do
                'End If
                If (TypeOf current Is LinkButton) Then
                    control.Controls.Remove(current)
                    control.Controls.AddAt(i, New LiteralControl(CType(current, LinkButton).Text))
                ElseIf (TypeOf current Is ImageButton) Then
                    control.Controls.Remove(current)
                    control.Controls.AddAt(i, New LiteralControl(CType(current, ImageButton).AlternateText))
                ElseIf (TypeOf current Is HyperLink) Then
                    control.Controls.Remove(current)
                    control.Controls.AddAt(i, New LiteralControl(CType(current, HyperLink).Text))
                ElseIf (TypeOf current Is DropDownList) Then
                    control.Controls.Remove(current)
                    Try
                        control.Controls.AddAt(i, New LiteralControl(CType(current, DropDownList).SelectedItem.Text))
                    Catch ex As Exception
                        control.Controls.AddAt(i, New LiteralControl(""))
                    End Try
                ElseIf (TypeOf current Is TextBox) Then
                    control.Controls.Remove(current)
                    control.Controls.AddAt(i, New LiteralControl(CType(current, TextBox).Text.Replace(Environment.NewLine, "<br />").Replace(Chr(10), "<br />")))
                    ' control.Controls.AddAt(i, New LiteralControl(CType(current, DropDownList).SelectedItem.Text))
                ElseIf (TypeOf current Is CheckBox) Then
                    control.Controls.Remove(current)
                    control.Controls.AddAt(i, New LiteralControl(IIf(CType(current, CheckBox).Checked, "Y", "N")))
                ElseIf (TypeOf current Is RadioButton) Then
                    control.Controls.Remove(current)
                    control.Controls.AddAt(i, New LiteralControl(IIf(CType(current, RadioButton).Checked, "X", "")))
                    'TODO: Warning!!!, inline IF is not supported ?
                ElseIf (TypeOf current Is Image) Then
                    control.Controls.Remove(current)
                ElseIf (TypeOf current Is CheckBoxList) Then
                    control.Controls.Remove(current)
                    For Each li As ListItem In CType(current, CheckBoxList).Items
                        control.Controls.AddAt(i, New LiteralControl(li.Text & "<br />"))
                    Next
                ElseIf (TypeOf current Is RequiredFieldValidator) Then
                    control.Controls.Remove(current)
                End If


                If current.HasControls Then
                    GridViewExportUtil.PrepareControlForExport(current)
                End If
                i = (i + 1)
            Loop
        End Sub


        ''' <summary>
        ''' Used With Microsoft.Office.interop.excel.dll
        ''' </summary>
        ''' <param name="sFile"></param>
        ''' <param name="Sheetname"></param>
        ''' <param name="dtTemp"></param>
        ''' <remarks></remarks>
        Public Shared Sub Export2ExcelConditional(ByVal sFile As String, ByVal Sheetname As String, ByVal dtTemp As DataTable)
            Dim _excel As New Microsoft.Office.Interop.Excel.Application
            Dim wBook As Microsoft.Office.Interop.Excel.Workbook
            Dim wSheet As Microsoft.Office.Interop.Excel.Worksheet

            wBook = _excel.Workbooks.Add()
            wSheet = wBook.ActiveSheet()
            wSheet.Name = "Data"

            Dim dt As System.Data.DataTable = dtTemp
            Dim dc As System.Data.DataColumn
            Dim dr As System.Data.DataRow
            Dim colIndex As Integer = 0
            Dim rowIndex As Integer = 0

            For Each dc In dt.Columns
                colIndex = colIndex + 1
                _excel.Cells(1, colIndex) = dc.ColumnName
                wSheet.Cells(1, colIndex).Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.LightGray)

            Next
            For Each dr In dt.Rows
                rowIndex = rowIndex + 1
                colIndex = 0
                For Each dc In dt.Columns
                    colIndex = colIndex + 1
                    _excel.Cells(rowIndex + 1, colIndex) = dr(dc.ColumnName)

                    'Conditional Coloring
                    If dc.ColumnName = "MonthScore" Then
                        If dr(dc.ColumnName) = "0" Then
                            wSheet.Cells(rowIndex + 1, colIndex).Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.Yellow)
                        Else
                            wSheet.Cells(rowIndex + 1, colIndex).Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.White)
                        End If
                    End If

                Next
            Next
            wSheet.Columns.AutoFit()
            Dim strFileName As String = sFile
            If System.IO.File.Exists(strFileName) Then
                System.IO.File.Delete(strFileName)
            End If

            wBook.SaveAs(strFileName)
            wBook.Close()
            _excel.Quit()
        End Sub


        Public Shared Sub Export2Excel(ByVal sFile As String, ByVal Sheetname As String, ByVal dtTemp As DataTable)
            Dim _excel As New Microsoft.Office.Interop.Excel.Application
            Dim wBook As Microsoft.Office.Interop.Excel.Workbook
            Dim wSheet As Microsoft.Office.Interop.Excel.Worksheet

            wBook = _excel.Workbooks.Add()
            wSheet = wBook.ActiveSheet()
            wSheet.Name = "TransactionSummary"

            Dim dt As System.Data.DataTable = dtTemp
            Dim dc As System.Data.DataColumn
            Dim dr As System.Data.DataRow
            Dim colIndex As Integer = 0
            Dim rowIndex As Integer = 0

            For Each dc In dt.Columns
                colIndex = colIndex + 1
                _excel.Cells(1, colIndex) = dc.ColumnName
                wSheet.Cells(1, colIndex).Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.LightGray)

            Next
            For Each dr In dt.Rows
                rowIndex = rowIndex + 1
                colIndex = 0
                For Each dc In dt.Columns
                    colIndex = colIndex + 1
                    _excel.Cells(rowIndex + 1, colIndex) = dr(dc.ColumnName)

                Next
            Next
            wSheet.Columns.AutoFit()
            Dim strFileName As String = sFile
            If System.IO.File.Exists(strFileName) Then
                System.IO.File.Delete(strFileName)
            End If

            wBook.SaveAs(strFileName)
            wBook.Close()
            _excel.Quit()
        End Sub



    End Class

End Namespace